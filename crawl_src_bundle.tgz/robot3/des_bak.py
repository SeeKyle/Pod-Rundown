from eng import *
import sys
OL=ramp((28,30,14),(56,60,26),(92,98,42),(138,144,64),(190,192,104))
BR=ramp((60,40,14),(110,78,26),(168,126,42),(214,176,72),(250,226,140))
MT=ramp((16,16,20),(36,36,42),(64,64,72),(104,104,114),(160,160,172))
CH=ramp((40,42,48),(80,84,92),(128,132,142),(180,184,194),(236,238,244))
BL=ramp((14,60,160),(30,110,230),(70,170,255),(160,225,255),(235,255,255))
CY=ramp((40,230,230),)*5
MS=ramp((26,36,18),(48,70,30),(80,110,46),(124,156,70),(176,204,110))
IR=ramp((22,20,22),(48,42,40),(82,72,64),(124,110,96),(176,160,138))
RU=ramp((50,22,10),(96,44,18),(146,72,30),(190,104,48),(226,150,90))
def dk(p,f=.78):return [tuple(int(v*f) for v in c) for c in p]
def leg(f,hip,foot,body,met,trim,piston=True,w=11,far=False):
    b=dk(body) if far else body;m=dk(met) if far else met;t=dk(trim) if far else trim;c=dk(CH) if far else CH
    kn=((hip[0]+foot[0])/2-3,(hip[1]+foot[1])/2-1)
    f.add(ell(hip[0],hip[1],4.5,4.5),m,'sph')
    f.add(seg(hip,kn,w,w-1),b)   # thigh armor
    if piston:f.cyl(((hip[0]+kn[0])/2+3,(hip[1]+kn[1])/2),((kn[0]+foot[0])/2+3,(kn[1]+foot[1])/2),2.2,c)
    f.add(seg(kn,(foot[0],foot[1]-4),w-2,w-3),b)   # shin armor
    f.add(ell(kn[0],kn[1],4.2,4.2),b,'sph')   # knee cap
    f.add(ell(foot[0],foot[1]-4,3,3),m,'sph')   # ankle
    f.add([(foot[0]-10,foot[1]),(foot[0]-8,foot[1]-4),(foot[0]+5,foot[1]-5),(foot[0]+7,foot[1]),],b)   # foot
    f.add(rect(foot[0]-10,foot[1]-1.4,foot[0]-5,foot[1]+.2),t)   # toe plate
    return kn
def gatling(f,sh,ang,L,spin,body,flash,far=True):
    el=pol(sh,ang,7)
    f.cyl(sh,el,5,dk(MT) if far else MT)
    hs=pol(el,ang,9);f.cyl(el,hs,10,body,9)   # drum housing
    end=pol(hs,ang,L);f.cyl(hs,end,6,CH,5)    # barrel cluster
    f.add(seg(pol(end,ang,-1.5),pol(end,ang,.8),7),MT)   # muzzle ring
    nx,ny=-math.sin(ang),math.cos(ang)
    for k in range(2,int(L)-1):
        p=pol(hs,ang,k);o=((k+spin)%3-1)*1.4;f.dot(p[0]+nx*o,p[1]+ny*o,CH[0])   # barrel gaps
    for k in range(3):p=pol(el,ang,2+k*3);f.dot(p[0]-nx*4,p[1]-ny*4,BR[3])
    if flash:
        for k in range(1,8):p=pol(end,ang,k+1);f.dot(p[0],p[1],(255,248,200) if k<3 else (255,190,70) if k<6 else (255,120,40))
        for o in(-2,2):p=pol(end,ang,3);f.dot(p[0]+nx*o,p[1]+ny*o,(255,190,70))
    return end
def blade_arm(f,sh,ang,body,met,trim,lean=0,L=21,pad=True,up=None,ua=7,fa=8):
    # 0.12.19 (Kyle): an elbow: upper arm (angle up) then the forearm and blade (angle ang); longer arm on Warhound
    el=pol(sh,(ang+.35) if up is None else up,ua);fs=pol(el,ang,fa)
    f.cyl(sh,el,5,met);f.add(ell(el[0],el[1],3.4,3.4),met,'sph')   # elbow joint
    f.add(seg(el,fs,10,9),body)   # gauntlet
    f.add(seg(pol(el,ang,2),pol(el,ang,6),10.5),trim)   # brass band
    f.add(ell(fs[0],fs[1],3.6,3.6),met,'sph')
    tip=pol(fs,ang,L);f.add(seg(fs,tip,5,1.4),BL,'cyl')
    if pad:
        f.add(oct(sh[0]-7,sh[1]-7,sh[0]+5,sh[1]+4,3),body)   # shoulder pad
        f.line((sh[0]-6,sh[1]-6),(sh[0]+3,sh[1]-6),trim[4])
        f.rivet(sh[0]-4,sh[1]-2,body);f.rivet(sh[0]+1,sh[1]-2,body)
def rack(f,x0,y0,x1,y1,body,pod,cols=3,rows_=2):
    f.add(oct(x0,y0,x1,y1,2),body)
    for r in range(rows_):
        for c in range(cols):
            x=x0+2.5+c*(x1-x0-4)/max(1,cols-1)*.92;y=y0+2.5+r*(y1-y0-4)/max(1,rows_-1)*.9
            f.dot(x,y,(16,10,10));f.dot(x+1,y,(16,10,10));f.dot(x,y+1,(255,80,50) if pod else (120,30,24));f.dot(x+1,y+1,(255,170,80) if pod>=2 else (90,24,20))
# ======== D: Warhound (hunched olive war-walker, brass trim, forward cockpit, twin exhausts, shoulder rack)
def D(p):
    g=p.get;b=g('bob',0)+g('sink',0);ln=g('lean',0);f=F(g('tilt',0))
    hip=(0,-30+b)
    nf=g('nf',(-6,0));ff=g('ff',(6,0))
    leg(f,(4,hip[1]+2),(ff[0],-ff[1]),OL,MT,BR,far=True)
    sh=(11+ln,-47+b)
    if not g('aim'):gatling(f,sh,1.72-.34*g('sw',0),12,g('spin',0),dk(OL),0)   # the cannon arm swings opposite the blade arm
    for x,h_ in ((9,10),(14,8)):f.cyl((x+ln,-58+b),(x+ln,-58-h_+b),4.5,MT);f.add(rect(x-2.5+ln,-59-h_+b,x+2.5+ln,-57-h_+b),BR)   # exhaust stacks
    if not g('tilt'):
        k=g('i',0)%4
        for (x,y,c) in [(9,-71-k,(170,170,170)),(10,-72-k,(130,130,130)),(14,-68-(k+2)%4,(150,150,150)),(13,-69-(k+2)%4,(110,110,110)),(9+(k>1),-74-k,(100,100,100))]:f.dot(x+ln,y+b,c)   # exhaust puffs drifting up
    pd=g('pod',0);rack(f,2+ln,-63+b-pd*2,17+ln,-52+b-pd*2,OL,pd)
    f.add(rect(-9+ln,-36+b,9+ln,-29+b),MT)   # pelvis
    f.line((-8+ln,-33+b),(8+ln,-33+b),BR[3])
    hull=[(-20+ln,-46+b),(-15+ln,-58+b),(8+ln,-61+b),(17+ln,-54+b),(15+ln,-40+b),(8+ln,-34+b),(-12+ln,-34+b),(-21+ln,-40+b)]
    f.add(hull,OL)
    f.seamline((-17+ln,-48+b),(12+ln,-48+b),OL);f.seamline((-2+ln,-58+b),(-4+ln,-36+b),OL)
    for x in range(-13,12,4):f.rivet(x+ln,-55+b+(x+13)*-.08,OL)
    f.line((-15+ln,-58+b),(8+ln,-61+b),BR[4])
    f.add(rect(-2+ln,-45+b,6+ln,-40+b),MT)   # vent
    for k in range(4):f.line((-1+k*2+ln,-44+b),(-1+k*2+ln,-41+b),MT[3])
    # cockpit head, low and forward
    f.add(oct(-25+ln,-53+b,-13+ln,-41+b,3),MT)
    f.add(rect(-25+ln,-50+b,-16+ln,-46+b),[(10,10,14)]*5,'flat');f.add(rect(-24+ln,-49+b,-17+ln,-47.2+b),[(20,10,8),(20,10,8),(60,235,235),(60,235,235),(60,235,235)] if not g('dim') else [(30,50,60)]*5,'flat')
    f.dot(-23+ln,-49+b,(230,255,255));f.line((-24+ln,-52+b),(-14+ln,-52+b),BR[3]);f.rivet(-15+ln,-44+b,MT)
    leg(f,(-5,hip[1]+2),(nf[0],-nf[1]),OL,MT,BR)
    # rest: upper arm hangs, elbow bent, forearm and blade thrust forward. Swings: the whole arm rotates as before.
    if g('blade') is None:up,fa=1.62+.42*g('sw',0),2.82+.26*g('sw',0)   # rest/walk: the whole arm swings from the shoulder, forearm follows
    else:up,fa=g('blade')+.55,g('blade')
    blade_arm(f,(-11+ln,-47+b),fa,OL,MT,BR,up=up,ua=9,fa=10)
    if g('aim'):gatling(f,(sh[0]-6,sh[1]+7),math.pi-.03+g('jit',0),19,g('spin',0),OL,g('flash'),far=False)   # kicks with each burst
    return f
# ======== E: Mossback (upright barrel-hull walker, dome head with round lens, mossy, big round pauldrons)
def E(p):
    g=p.get;b=g('bob',0)+g('sink',0);ln=g('lean',0);f=F(g('tilt',0))
    hip=(0,-29+b);nf=g('nf',(-6,0));ff=g('ff',(6,0))
    leg(f,(4,hip[1]+2),(ff[0],-ff[1]),MS,MT,BR,far=True,w=10)
    sh=(10+ln,-49+b)
    if not g('aim'):gatling(f,sh,1.72,11,g('spin',0),dk(MS),0)
    pd=g('pod',0);rack(f,7+ln,-66+b-pd*2,18+ln,-50+b-pd*2,MS,pd,cols=2,rows_=3)
    f.add(rect(-8+ln,-35+b,8+ln,-28+b),MT)
    f.cyl((ln,-60+b),(ln,-34+b),25,MS,23)   # barrel hull
    for y in(-55,-46,-39):f.seamline((-11+ln,y+b),(11+ln,y+b),MS)
    for y in(-52,-43):
        for x in(-9,-4,1,6):f.rivet(x+ln,y+b,MS)
    f.add(ell(-1+ln,-63+b,9,7.5),MS,'sph')   # dome head
    f.add(ell(-8+ln,-62+b,3.6,3.6),MT,'sph');f.add(ell(-8.4+ln,-62.4+b,2.3,2.3),CY if not g('dim') else [(30,50,60)]*5,'flat');f.dot(-9+ln,-63+b,(240,255,255))
    f.line((-6+ln,-70+b),(3+ln,-70+b),BR[3])
    # moss on the head and shoulders, rust streaks
    for (x,y) in [(-4,-70),(-2,-71),(0,-70),(2,-70),(-5,-69),(4,-69),(-6,-56),(-8,-53),(7,-57)]:f.dot(x+ln,y+b,(150,190,70));f.dot(x+ln+1,y+b,(96,130,40))
    for (x,y) in [(6,-40),(6,-38),(7,-37),(-10,-36)]:f.dot(x+ln,y+b,RU[2])
    leg(f,(-5,hip[1]+2),(nf[0],-nf[1]),MS,MT,BR,w=10)
    ba=g('blade',1.9);s2=(-11+ln,-49+b)
    blade_arm(f,s2,ba,MS,MT,BR,pad=False)
    f.add(ell(s2[0],s2[1]-1,7,6.5),MS,'sph')   # round pauldron
    f.dot(s2[0]-3,s2[1]-6,(150,190,70));f.dot(s2[0]-1,s2[1]-7,(150,190,70))
    if g('aim'):gatling(f,(sh[0]-6,sh[1]+8),math.pi-.03,19,g('spin',0),MS,g('flash'),far=False)
    return f
# ======== F: Rustjaw (iron-and-rust bulldog walker, grille jaw, tiny twin-eye head, massive shoulders)
def Fx(p):
    g=p.get;b=g('bob',0)+g('sink',0);ln=g('lean',0);f=F(g('tilt',0))
    hip=(0,-28+b);nf=g('nf',(-6,0));ff=g('ff',(6,0))
    leg(f,(4,hip[1]+2),(ff[0],-ff[1]),IR,MT,RU,far=True,w=12)
    sh=(13+ln,-50+b)
    if not g('aim'):gatling(f,sh,1.72,12,g('spin',0),dk(IR),0)
    pd=g('pod',0);rack(f,10+ln,-62+b-pd*2,21+ln,-48+b-pd*2,RU,pd,cols=2,rows_=3)
    f.add(rect(-9+ln,-34+b,9+ln,-27+b),MT)
    chest=[(-17+ln,-58+b),(12+ln,-60+b),(16+ln,-48+b),(11+ln,-33+b),(-13+ln,-33+b),(-21+ln,-44+b)]
    f.add(chest,IR)
    f.add([(-21+ln,-45+b),(-9+ln,-45+b),(-9+ln,-35+b),(-16+ln,-35+b)],MT)   # jaw grille
    for k in range(5):f.line((-19+k*2.4+ln,-44+b),(-17+k*2.2+ln,-36+b),BR[3] if k%2 else MT[3])
    f.seamline((-15+ln,-52+b),(13+ln,-52+b),IR)
    for x in range(-12,12,5):f.rivet(x+ln,-57+b,IR)
    for (x,y) in [(4,-47),(5,-45),(4,-44),(8,-40),(9,-39),(-4,-50),(-3,-49)]:f.dot(x+ln,y+b,RU[3] if (x+y)%2 else RU[2])   # rust streaks
    f.add(oct(-12+ln,-67+b,-1+ln,-58+b,2),MT)   # small head
    eye=[(60,235,235)]*5 if not g('dim') else [(30,50,60)]*5
    f.add(rect(-12+ln,-64+b,-9+ln,-62+b),eye,'flat');f.add(rect(-8+ln,-64+b,-5+ln,-62+b),eye,'flat')
    f.line((-11+ln,-67+b),(-2+ln,-67+b),BR[3])
    leg(f,(-5,hip[1]+2),(nf[0],-nf[1]),IR,MT,RU,w=12)
    s2=(-13+ln,-50+b);blade_arm(f,s2,g('blade',1.9),IR,MT,BR,pad=False)
    f.add(oct(s2[0]-9,s2[1]-8,s2[0]+6,s2[1]+5,4),IR)   # massive shoulder
    f.line((s2[0]-7,s2[1]-8),(s2[0]+4,s2[1]-8),BR[4]);f.rivet(s2[0]-5,s2[1]-3,IR);f.rivet(s2[0]+1,s2[1]-3,IR);f.dot(s2[0]-2,s2[1]+1,RU[3])
    if g('aim'):gatling(f,(sh[0]-8,sh[1]+9),math.pi-.03,20,g('spin',0),IR,g('flash'),far=False)
    return f
for nm,fn in (('D_Warhound',D),('E_Mossback',E),('F_Rustjaw',Fx)):
    S,meta=build(nm,fn)
    bg=Image.new('RGBA',S.size,(30,26,38,255));bg.alpha_composite(S);bg.resize((S.width*2,S.height*2),Image.NEAREST).save(f'/tmp/{nm}.png')
print(meta)
