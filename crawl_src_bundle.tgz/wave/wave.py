from PIL import Image, ImageDraw
import math, random
W,H=110,68
OUT=(18,52,128,255);BODY=(34,140,232,255);MID=(92,196,255,255);HI=(226,248,255,255)
def frame(seed):
    rnd=random.Random(seed)
    im=Image.new('RGBA',(W,H));d=ImageDraw.Draw(im)
    g=H-2
    # front crescent: outer edge bulges forward, inner edge curves back (the hero rides in the hollow)
    outer=[(64+32*math.sin(t*math.pi)+rnd.uniform(-1,1), 2+t*(g-4)) for t in [i/14 for i in range(15)]]
    inner=[(62+9*math.sin(t*math.pi*.95)+(0 if t<.85 else -8*(t-.85)/.15), 2+t*(g-12)) for t in [i/14 for i in range(15)]]
    # trailing tail along the ground with jagged spikes, shrinking toward the back
    tail_top=[];x=58
    spikes=[(52,15),(40,12),(29,9),(18,6),(9,4)]
    for sx,sh in spikes:
        sh+=rnd.randint(-1,1);tail_top+= [(sx+5,g-4-sh*0.35),(sx+1,g-4-sh),(sx-2,g-6)]
    tail_top.append((2,g-1))
    bottom=[(x,g-1+0.7*math.sin(x/11+seed)+0.25*math.sin(x/3.1)) for x in range(int(outer[-1][0]),2,-3)]   # gently rolling underside
    poly=outer+bottom+list(reversed(tail_top))+[(56,g-8)]+list(reversed(inner))
    d.polygon(poly,fill=BODY,outline=OUT)
    body=im.copy()
    # inner glow band near the front edge
    band=[(64+26*math.sin(t*math.pi), 6+t*(g-12)) for t in [i/12 for i in range(13)]]
    d.line(band,fill=MID,width=3)
    # streaks like the sketch's flame lines
    for k in range(3):
        off=rnd.uniform(-3,3);pts=[(70+18*math.sin(t*math.pi)+off-4*k, 12+k*6+t*(g-26-k*6)) for t in [i/8 for i in range(9)]]
        d.line(pts,fill=HI if k==0 else MID,width=1)
    for sx,sh in spikes[:3]:
        d.line([(sx+4,g-3),(sx,g-sh+2)],fill=MID,width=1)
    # keep the streaks inside the wave
    bp=body.load();ip=im.load()
    for y in range(H):
        for x in range(W):
            if bp[x,y][3]==0 and ip[x,y][3]: ip[x,y]=(0,0,0,0)
    # ground spray
    for i in range(10):
        x=rnd.randint(4,86);d.point((x,g+rnd.choice([0,1])),fill=HI if i%3==0 else MID)
    # clean outline pass: dark edge on every outside pixel
    px=im.load()
    for y in range(H):
        for x in range(W):
            if px[x,y][3] and any((0<=x+dx<W and 0<=y+dy<H and px[x+dx,y+dy][3]==0) for dx,dy in((1,0),(-1,0),(0,1),(0,-1))) and px[x,y]!=HI:
                px[x,y]=OUT
    return im
fr=[frame(7)]
import numpy as np
from scipy import ndimage as nd
def layers(im):
    a=np.array(im).astype(float);m=a[...,3]>0
    d=nd.distance_transform_cdt(m,metric='chessboard')   # 1 = outer edge pixel, 2 = next ring in, ...
    alpha=np.select([d==1,d==2,d==3,d==4],[95,150,195,225],245)   # see-through in layers from the edge inward
    hi=(a[...,0]>200)&(a[...,2]>240)                              # bright streaks stay solid
    alpha=np.where(hi,255,alpha);a[...,3]=np.where(m,alpha,0)
    # cooler core: the deep middle of the wave shifts toward a richer, darker blue
    core=d>=5;a[core,0]*=.72;a[core,1]*=.86
    return Image.fromarray(np.clip(a,0,255).astype(np.uint8))
fr=[layers(f) for f in fr]
sheet=Image.new('RGBA',(W,H))
for i,f in enumerate(fr):sheet.alpha_composite(f,(i*W,0))
sheet.save('/home/claude/pod2/crawl_wave.png')
pv=Image.new('RGBA',(W*5,H*5),(94,107,100,255));pv.alpha_composite(sheet.resize((W*5,H*5),Image.NEAREST));pv.save('wave_preview.png')
