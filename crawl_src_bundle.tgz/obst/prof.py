# Bakes a per-column height profile (hit shape) for every obstacle into OBST / CARS in crawl_src.js. Rerun after re-cutting sprites.
import json,re
from PIL import Image
P='/home/claude/pod2/'
c=open(P+'crawl_src.js').read()
sheets={None:Image.open(P+'crawl_obst.png').convert('RGBA'),'cars':Image.open(P+'crawl_cars.png').convert('RGBA')}
def bake(name):
    global c
    pat=r'const %s=(\{.*?\});'%name;m=re.search(pat,c,re.S);d=json.loads(m.group(1))
    for k,v in d.items():
        im=sheets[v.get('img')];px=im.load();prof=[]
        for b in range(0,v['fw'],2):   # one value per world px (2 sheet px)
            top=None
            for cx in (b,b+1):
                if cx>=v['fw']:continue
                for yy in range(v['fh']):
                    if px[v['x']+cx,v['y']+yy][3]>140:top=yy if top is None else min(top,yy);break
            prof.append(0 if top is None else max(0,v['fh']-1-top))
        v['prof']=prof
    c=c[:m.start(1)]+json.dumps(d,separators=(',',':'))+c[m.end(1):]
bake('OBST');bake('CARS')
open(P+'crawl_src.js','w').write(c)
print('ok')
