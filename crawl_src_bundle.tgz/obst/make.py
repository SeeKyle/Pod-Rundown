from PIL import Image, ImageFilter
import numpy as np
from collections import deque
R=Image.open('/mnt/user-data/uploads/9218701d-image.webp').convert('RGB')
F=Image.open('/mnt/user-data/uploads/ec066941-image.webp').convert('RGB')
def cut(src,box,isbg):
    a=np.array(src.crop(box)).astype(int);H,W,_=a.shape
    bgm=isbg(a);m=np.zeros((H,W),bool);q=deque()
    for y in range(H):
        for x in (0,W-1):
            if bgm[y,x]:m[y,x]=1;q.append((y,x))
    for x in range(W):
        for y in (0,H-1):
            if bgm[y,x] and not m[y,x]:m[y,x]=1;q.append((y,x))
    while q:
        y,x=q.popleft()
        for dy,dx in((1,0),(-1,0),(0,1),(0,-1)):
            yy,xx=y+dy,x+dx
            if 0<=yy<H and 0<=xx<W and not m[yy,xx] and bgm[yy,xx]:m[yy,xx]=1;q.append((yy,xx))
    return a,~m
def rockbg(a):
    r,g,b=a[...,0],a[...,1],a[...,2];return (b-r>10)&(r+g+b>230)
def parch(a):
    r,g,b=a[...,0],a[...,1],a[...,2];return (r>150)&(g>130)&(r-b>18)&(abs(r-g)<45)
def build(src,box,isbg,th,glob=False,tint=(0.82,0.84,0.95),ncol=14):
    if 'bush' in str(th):pass
    a,keep=cut(src,box,isbg)
    if glob:keep&=~isbg(a)
    rgba=np.dstack([a,keep*255]).astype(np.uint8);im=Image.fromarray(rgba,'RGBA')
    bb=im.getbbox();im=im.crop(bb)
    w=max(1,round(im.width*th/im.height))
    # premultiplied downscale so edges don't pick up background colour
    A=np.array(im).astype(float);al=A[...,3:]/255;pm=np.dstack([A[...,:3]*al,A[...,3:]])
    pmI=[Image.fromarray(pm[...,i].astype(np.float32),'F').resize((w,th),Image.BOX) for i in range(4)]
    P=np.dstack([np.array(c) for c in pmI]);alpha=P[...,3]
    rgb=np.where(alpha[...,None]>1,P[...,:3]/np.maximum(alpha[...,None],1)*255,0)
    rgb=rgb*np.array(tint)
    out=np.dstack([np.clip(rgb,0,255),np.where(alpha>110,255,0)]).astype(np.uint8)
    from scipy import ndimage
    lab,nl=ndimage.label(out[...,3]>0)
    if nl>1:
        sz=ndimage.sum(np.ones_like(lab),lab,range(1,nl+1));keepL=[i+1 for i,v in enumerate(sz) if v>=sz.max()*.25]
        out[...,3]=np.where(np.isin(lab,keepL),out[...,3],0)
    o=Image.fromarray(out,'RGBA');o=o.crop(o.getbbox())
    # palette snap for a clean, pixel-art read
    q=o.convert('RGB').quantize(ncol,method=Image.MEDIANCUT).convert('RGB');o=Image.fromarray(np.dstack([np.array(q),np.array(o)[...,3]]),'RGBA')
    # 1px dark outline
    a2=np.array(o);al2=a2[...,3]>0;pad=np.pad(al2,1);ring=(~al2)&(pad[:-2,1:-1]|pad[2:,1:-1]|pad[1:-1,:-2]|pad[1:-1,2:])
    big=np.zeros((a2.shape[0]+2,a2.shape[1]+2,4),np.uint8);big[1:-1,1:-1]=a2
    rp=np.pad(ring,1);big[rp]=(18,14,24,255)
    return Image.fromarray(big,'RGBA')
items=[  # name, src, box, bg, height(sheet px = 2/world px), lanes, block height (hitbox units, 0 = shots pass)
 ('rock_moss',R,(725,240,975,440),rockbg,34,1,34),
 ('rock_pile',R,(140,235,345,425),rockbg,28,1,26),
 ('rock_crack',R,(470,240,650,420),rockbg,32,1,32),
 ('rock_swirl',R,(145,515,315,705),rockbg,30,1,30),
 ('rock_dirt',R,(770,520,945,705),rockbg,30,1,30),
 ('rock_crumble',R,(765,795,955,970),rockbg,26,1,24),
 ('log_big',F,(284,46,430,110),parch,26,2,14),
 ('trunk',F,(522,44,590,147),parch,40,1,40),
 ('stump',F,(347,108,396,194),parch,30,1,30),
 ('bush_a',F,(323,448,397,517),parch,26,1,0),
 ('bush_b',F,(688,338,757,402),parch,26,1,0),
 ('deadtree',F,(28,28,178,232),parch,76,1,52),
]
ims=[];meta={}
for n,src,box,bg,th,lanes,blk in items:
    im=build(src,box,bg,th,glob=(src is F),tint=(0.8,1.0,0.85) if n.startswith('bush') else (0.82,0.84,0.95))
    if n=='log_big':
        im=im.resize((round(im.width*1.3),im.height),Image.NEAREST)
        # tilt it so it lies diagonally across the path (front end low-left, far end up-right)
        im=im.rotate(17,resample=Image.NEAREST,expand=True);im=im.crop(im.getbbox())
    ims.append((n,im,lanes,blk))
W=sum(i.width+2 for _,i,_,_ in ims);H=max(i.height for _,i,_,_ in ims)
S=Image.new('RGBA',(W,H));x=0
for n,im,lanes,blk in ims:
    S.alpha_composite(im,(x,H-im.height));meta[n]=dict(x=x,y=H-im.height,fw=im.width,fh=im.height,lanes=lanes,blk=blk);x+=im.width+2
S.save('/home/claude/pod2/crawl_obst.png',optimize=True)
import json;json.dump(meta,open('obst.json','w'));print(json.dumps(meta))
bg=Image.new('RGBA',(W,H),(30,24,36,255));bg.alpha_composite(S);bg.resize((W*4,H*4),Image.NEAREST).save('/tmp/obst.png')
# footprints: where each obstacle actually sits on the ground, per lane, in world px relative to its centre (sheet is 2 px/world px)
S2=np.array(Image.open('/home/claude/pod2/crawl_obst.png'))[...,3]>0
for n,D in meta.items():
    a=S2[D['y']:D['y']+D['fh'],D['x']:D['x']+D['fw']];H=a.shape[0];cx=D['fw']/2
    def span(r0,r1):
        cols=np.where(a[r0:r1].any(0))[0]
        return [round((cols.min()-cx)/2,1),round((cols.max()+1-cx)/2,1)] if len(cols) else [-2,2]
    if D['lanes']==2:
        D['foot']=[span(int(H*.7),H),span(0,int(H*.35))]   # front lane = lower-left end, far lane = upper-right end
    else:
        f=span(int(H*.72),H);w=f[1]-f[0];k=.12*w;D['foot']=[[f[0]+k,f[1]-k]]   # just the base, a little inside the outline
json.dump(meta,open('obst.json','w'));print({n:D['foot'] for n,D in meta.items()})
