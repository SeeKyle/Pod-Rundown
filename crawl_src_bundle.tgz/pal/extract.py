import numpy as np, os
from PIL import Image
from scipy import ndimage as nd
S=np.array(Image.open('pal_recolor.png').convert('RGBA')).astype(np.uint8);RGB=S[...,:3].astype(int)
bg=np.array([92,108,98]);fg=np.abs(RGB-bg).sum(2)>40
lab,n=nd.label(nd.binary_dilation(fg,iterations=2));objs=nd.find_objects(lab)
ROWS={'melee':(0,225),'ranged':(247,465),'reload':(487,685),'hurt':(714,894),'death':(927,1200)}
L,R,U=90,140,200;OUT='/home/claude/pod2/assets/heroes/flannel_pal/';os.makedirs(OUT,exist_ok=True)
for name,(y0,y1) in ROWS.items():
    comps=[]
    for i,sl in enumerate(objs):
        if not sl:continue
        cy=(sl[0].start+sl[0].stop)/2
        if not(y0<cy<y1):continue
        m=(lab[sl]==i+1)&fg[sl]
        if m.sum()<6:continue
        px=RGB[sl][m];dark=(px.sum(1)<120).mean()
        if sl[1].start<260 and dark>0.75:continue
        if sl[1].stop-sl[1].start>1500:continue
        comps.append((i,sl,m.sum()))
    bodies=sorted([c for c in comps if c[2]>1500],key=lambda c:c[1][1].start)
    groups=[[b] for b in bodies]
    for c in comps:
        if c in bodies:continue
        k=max([j for j,b in enumerate(bodies) if b[1][1].start<=c[1][1].start] or [0]);groups[k].append(c)
    frames=[]
    for gi,g in enumerate(groups):
        m=np.zeros(fg.shape,bool)
        for j,(i,sl,_) in enumerate(g):
            mm=(lab[sl]==i+1)&fg[sl]
            if j==0: mm=nd.binary_fill_holes(mm)   # the body: no see-through holes
            m[sl]|=mm
        ys,xs=np.nonzero(m);gy=ys.max()
        fy,fx=np.nonzero(m[gy-30:gy+1]);ax=int(np.median(fx))
        x0,y0b=ax-L,gy-U;c=np.zeros((U+8,L+R,4),np.uint8)
        for yy in range(max(0,y0b),min(S.shape[0],gy+8)):
            row=m[yy,max(0,x0):x0+L+R];px=S[yy,max(0,x0):x0+L+R].copy();px[...,3]=np.where(row,255,0)
            c[yy-y0b,max(0,x0)-x0:max(0,x0)-x0+len(row)]=px
        frames.append(np.ascontiguousarray(c[:,::-1]))
    Image.fromarray(np.concatenate(frames,1)).save(OUT+name+'.png');print(name,len(frames))
im=Image.open(OUT+'ranged.png');im.crop((0,0,230,im.height)).save(OUT+'idle.png');im.crop((0,0,230,im.height)).save(OUT+'walk.png')
