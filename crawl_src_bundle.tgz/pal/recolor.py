import numpy as np
from PIL import Image
from scipy import ndimage as nd
from skimage.color import rgb2hsv
S=np.array(Image.open('pal.jpg').convert('RGB')).astype(float);RGB=S/255
bg=np.array([92,108,98]);fg=np.abs(S-bg).sum(2)>40
hsv=rgb2hsv(RGB);H,Sa,V=hsv[...,0]*360,hsv[...,1],hsv[...,2]
lab,n=nd.label(nd.binary_dilation(fg,iterations=2));objs=nd.find_objects(lab)
out=S.copy()
JR=np.array([158,30,36.]);HB=np.array([58,34,22.])
upright={'death':(927,1200)}
for i,sl in enumerate(objs):
    if not sl:continue
    h=sl[0].stop-sl[0].start;w=sl[1].stop-sl[1].start
    m=(lab[sl]==i+1)&fg[sl]
    if m.sum()<1500 or w>1500:continue
    death=sl[0].start>920
    rows=np.arange(h)[:,None]/h
    hh,ss,vv=H[sl],Sa[sl],V[sl]
    mf=nd.binary_fill_holes(m);inner=nd.binary_erosion(mf,iterations=1)
    jacket=inner&(rows>.15)&(rows<.7)&(hh>=140)&(hh<=212)&(ss>=.1)&(vv>=.1)&(vv<=.62)
    head=(rows<.30) if not death else np.ones_like(rows,bool)
    hair=m&head&(((hh<=30)|(hh>=345))&(ss>=.45)&(vv>=.15)&(vv<=.62))
    o=out[sl]
    o[jacket]=np.clip(JR[None,:]*np.clip(vv[jacket]/.33,.45,1.5)[:,None],0,255)
    o[hair]=np.clip(HB[None,:]*np.clip(vv[hair]/.45,.55,1.6)[:,None],0,255)
    # longer ponytail: hang a tapered tail from the back of the bun (upright frames, facing right -> back is the left)
    if not death and hair.sum()>30:
        ys,xs=np.nonzero(hair);top=ys.min();bun=ys<top+(ys.max()-top)*.55
        bx=xs[bun].min();by=int(np.median(ys[bun][xs[bun]<bx+6]))
        L=34
        for k in range(L):
            t=k/L;cx=bx+1-int(6*np.sin(t*1.6))+int(3*t*t);cy=by+k
            half=max(1,int(5*(1-t)+1.5))
            for dx in range(-half,half+1):
                x=cx+dx;y=cy
                if 0<=y<h and 0<=x<w:
                    sk=(hh[y,x]<40)&(ss[y,x]<.5)&(vv[y,x]>.6)   # never paint over skin
                    if sk:continue
                    edge=abs(dx)==half
                    o[y,x]=HB*(.5 if edge else (1.05+.18*((k//4+dx)%2)))
    out[sl]=o
Image.fromarray(np.clip(out,0,255).astype(np.uint8)).save('pal_recolor.png')
