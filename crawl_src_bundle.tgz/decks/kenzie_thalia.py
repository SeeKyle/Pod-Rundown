from formulas import *
import importlib
C = 3
META = dict(file='Kenzie_Thalia', deck='Gitrog & Gates', icon='🐸', owner='Kenzie', colors=C,
            cmdr=['Thalia and The Gitrog Monster'], secret=[], archetype='Abzan Midrange & Removal', board=8, creatures=20)
TAGS = {
 'Thalia and The Gitrog Monster': T('first strike deathtouch 4/4; extra land drop; their creatures and nonbasics enter tapped; attacks sac and draw', tall(4, 4, 'P'), ramp(1, 4, land=1, nc=0), draw(1, 4, eng=1), politics(4, fort=0.5, eng=1)),
 'Aspect of Lamprey': T('lifelink aura; opponent discards two', answer(4, denial=1, discard=1), survive(4, life=3, eng=1)),
 'Auramancer': T('regrows an enchantment', survive(3, ret=1), body(2, 2)),
 'Battle Menu': T('modal: Knight, +0/+4, kill power 4+, or 4 life', answer(2, 'destroy', big=1, inst=1, cond=0.6), wide(2, 2)),
 'Blade Banish': T('exile power 4+', answer(4, 'exile', inst=1, cond=0.8)),
 'Bladebrand': T('cantrip deathtouch trick', draw(1, 2), answer(2, 'damage', inst=1, cond=0.4)),
 'Blood Pact': T('draw two', draw(2, 3, imm=1)),
 'Cabal Ritual': T('BBB burst, BBBBB with threshold', ramp(2, 2, kind='T')),
 'Calix, Guided by Fate': T('enchantments put counters out; copies enchantments on hit', board(1, 4, 3, cond=0.6), body(2, 2)),
 'Candletrap': T('pacifism; coven exiles', answer(1, 'bounce', cond=0.8)),
 'Cleansing Nova': T('wipe creatures or artifacts/enchantments', answer(5, wipe=1, kinds='cae')),
 'Defenestrate': T('kill a ground creature', answer(3, 'destroy', inst=1, cond=0.8)),
 'Diabolic Tutor': T('any card to hand', tutor('hand', 'a', 4)),
 'Disenchant': T('kill an artifact/enchantment', answer(2, 'destroy', inst=1, kinds='ae')),
 'Divine Light': T('fog for your creatures', survive(1, prevent=0.5)),
 'Eerie Ultimatum': T('return every differently named permanent from the yard', survive(7, mass=1)),
 'Ethereal Haze': T('creature fog', survive(1, fog=1, inst=1)),
 'Explosive Vegetation': T('two basics', ramp(2, 4, land=1, kind='L', color=1)),
 'Foul Orchard': T('tapped B/G', land(1, C, 'T')),
 'Gisa, Glorious Resurrector': T('steals every opposing creature that dies', wide(3, 4, eng=1), answer(4, denial=1, eng=1, kinds='g')),
 'Glorious Anthem': T('team +1/+1', board(1, 7, 3)),
 'Growing Ranks': T('populates every upkeep', wide(1, 4, eng=1, cost=0)),
 'Idyllic Tutor': T('enchantment to hand', tutor('hand', 't', 3)),
 'Indulging Patrician': T('lifelink flier; 3 life loss each when you gain 3', evasive(1, 'fly'), drain(3, 3)),
 'Judge Magister Gabranth': T('menace; grows when your things die', evasive(3, 'menace'), body(2, 2)),
 'Knight of the Ebon Legion': T('pumpable 1-drop that grows', tall(4, 1, cond=0.7), body(1, 2)),
 'Leinore, Autumn Sovereign': T('a counter every combat; coven draws', board(1, 1, 4), draw(1, 4, eng=1, restr=1)),
 'Massacre Wurm': T('-2/-2 to their team; 2 life per death', answer(6, wipe=1, oneside=1, cond=0.6), tall(6, 6), drain(4, 6)),
 'Nykthos Paragon': T('lifegain puts that many counters on the team', board(2, 7, 6, cond=0.6), body(4, 6)),
 'Open the Way': T('X lands from the top', ramp(3, 5, land=1, kind='L', color=1)),
 'Plague Wind': T('one-sided wipe', answer(9, wipe=1, oneside=1)),
 'Plummet': T('kill a flier', answer(2, 'destroy', inst=1, cond=0.6)),
 'Questing Beast': T('haste deathtouch 4/4; hard to block', tall(4, 4, haste=1), evasive(4, 'menace')),
 'Rankle, Master of Pranks': T('hasty flier; symmetric discard/draw/edict on hit', evasive(3, 'fly'), answer(4, 'edict', cond=0.5)),
 'Realms Uncharted': T('two lands to hand, two to the yard', ramp(1, 3, land=0, kind='L'), select(3, dig=4, inst=1)),
 "Reaper's Talisman": T('deathtouch on attack; drains 2 alone', drain(2, 1), pump(0, 1, equip=2)),
 'Resplendent Angel': T('flier; 5 life in a turn makes 4/4 Angels', evasive(3, 'fly'), wide(4, 3, eng=1, cost=1)),
 'Revitalize': T('3 life and a card', draw(1, 2, imm=1), survive(2, lifeoneoff=3)),
 'Shadewing Laureate': T('flier; counters when fliers die', evasive(2, 'fly'), body(2, 2)),
 'Smite the Monstrous': T('kill power 4+', answer(4, 'destroy', inst=1, cond=0.8)),
 'Sorcerous Spyglass': T('peek and shut off an activated ability', answer(2, denial=1, kinds='ap')),
 'Sorin, Vengeful Bloodlord': T('team lifelink on your turn; reanimates', survive(4, ret=1, eng=1, life=3)),
 'Staff of the Death Magus': T('1 life per black spell or Swamp', survive(3, life=1, eng=1)),
 'Strength of Unity': T('domain aura (+3/+3 here)', pump(3, 4, aura=1)),
 'The Meathook Massacre': T('scalable -X/-X wipe; drains on deaths', answer(4, wipe=1, cond=0.8), drain(2, 4)),
 'Torens, Fist of the Angels': T('creature spells make training Soldiers', wide(1, 3, eng=1)),
 'Tranquil Expanse': T('tapped G/W', land(1, C, 'T')),
 'Trelasarra, Moon Dancer': T('grows and scries on lifegain', board(1, 1, 2), select(2, scry=1, eng=1)),
 'Union of the Third Path': T('draw, gain life per card', draw(1, 3, imm=1), survive(3, lifeoneoff=5)),
 'Vorpal Sword': T('+2/+0 deathtouch; late game: hits win the game', pump(2, 1, equip=2), finish('Alt Win', 0, 8, cond=0.4)),
 'Vraska, Golgari Queen': T('sac for cards, kills cheap permanents, ultimate wins', draw(1, 4, eng=1), answer(4, 'destroy', kinds='caep', cond=0.8)),
 'Wooden Sphere': T('1 life per green spell', survive(1, life=1, eng=1)),
 'Llanowar Wastes': T('B/G pain land', land(1, C)),
 'Sunpetal Grove': T('G/W check land', land(1, C, 0.6)),
 'Temple Garden': T('G/W shock land', land(1, C, typed=1)),
 'The Haunt of Hightower': T('flying vampire that grows on discards', evasive(3, 'fly'), body(3, 3)),
}
COPY = {'Arcane Signet': 'thing', 'Dark Ritual': 'blood', 'Dig Up': 'korvold', 'Farseek': 'thing', 'Garruk, Cursed Huntsman': 'korvold',
        'Hardened Scales': 'eddie_miles', 'Mortify': 'blood', 'Rampant Growth': 'thing', 'Return to Dust': 'depala', 'Sunfall': 'eddie_kasla',
        'Teysa Karlov': 'turtle'}
for _n, _d in COPY.items():
    TAGS[_n] = importlib.import_module(_d).TAGS[_n]

# 0.12.362 tag audit (Kyle): effects the cards do that had no tag yet, and tags that didn't fit
add_tags(TAGS, 'Indulging Patrician', 'lifelink', survive(3, life=1, eng=1))
drop_tags(TAGS, "Reaper's Talisman", 'Equipment pump')   # no power boost, so no pump (utility gear rule)
add_tags(TAGS, 'Sorin, Vengeful Bloodlord', 'your team has lifelink on your turn; +2 pings', survive(4, life=4, eng=1), drain(1, 4))
add_tags(TAGS, 'The Haunt of Hightower', 'grows off milled/discarded cards; lifelink; attacks make them discard',
         tall(6, 6, cond=0.7), survive(6, life=3, eng=1), answer(6, denial=1, discard=1, eng=1, cond=0.6))
