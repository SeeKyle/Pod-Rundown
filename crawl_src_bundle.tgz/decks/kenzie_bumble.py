from formulas import *
import importlib
C = 3
META = dict(file='Kenzie_Bumbleflower', deck="Bumbleflower's Gifts", icon='🐰', owner='Kenzie', colors=C,
            cmdr=['Ms. Bumbleflower'], secret=[], archetype='Group Hug & Counters', board=8, creatures=22)
TAGS = {
 'Ms. Bumbleflower': T('every spell: an opponent draws, a counter and flying on a creature; second time a turn you draw two', board(1, 1, 4, cond=1), gives_ev(3, 'fly', 4, eng=1), draw(2, 4, eng=1, restr=1), politics(4, hug=1, eng=1)),
 "An Offer You Can't Refuse": T('1-mana counter for noncreature spells (they get two Treasures)', answer(1, counter='hard', inst=1, cond=0.8, kinds='s'), politics(1, hug=0.5)),
 'Baird, Steward of Argive': T('creatures pay 1 each to attack you', politics(4, tax=1, eng=1), body(2, 4)),
 'Bloodroot Apothecary': T('toxic 2; Treasures for both; poisons their token sacs', drain(0, 3, poison=1, cond=0.5), ramp(1, 3, kind='T', color=2), body(3, 3)),
 'Broken Wings': T('kill an artifact, enchantment or flier', answer(3, 'destroy', inst=1, kinds='cae', cond=0.8)),
 'Coiling Oracle': T('free land or card', draw(1, 2, nc=0), body(1, 1)),
 'Communal Brewing': T('opponents draw; your creatures enter with extra counters', board(3, 5, 3, cond=0.8), politics(3, hug=1)),
 'Coveted Jewel': T('draw three; taps for three; politics bait', ramp(3, 6, color=1), draw(3, 6), politics(6, hug=0.5)),
 "Fisher's Talent": T('draws every upkeep; Fish into Sharks into Octopi', draw(1, 4, eng=1), wide(3, 4, eng=1, cost=1)),
 'Generous Gift': T('destroy any permanent (they get an Elephant)', answer(3, 'destroy', inst=1, kinds='caepl')),
 'Ghirapur Orrery': T('extra lands for all; empty hands refill', ramp(1, 4, land=1, nc=1), draw(3, 4, eng=1, sym=1), politics(4, hug=1)),
 'Hoofprints of the Stag': T('draws turn into 4/4 fliers', wide(4, 2, eng=1, cost=1)),
 "Illusionist's Gambit": T('turns their attack on someone else', politics(4, redirect=1, inst=1), survive(4, fog=1, inst=1)),
 'Intellectual Offering': T('you and an opponent draw three; untap your stuff', draw(3, 5, sym=1, sym_ok=1, imm=1), politics(5, hug=1, inst=1)),
 'Jolly Gerbils': T('gifts draw you a card', draw(1, 2, eng=1, restr=1), body(2, 3)),
 'Jolrael, Mwonvuli Recluse': T('second draw each turn makes a Cat; late game makes the team huge', wide(2, 2, eng=1), finish('Burst', 15, 6, cond=0.4)),
 'Kalonian Hydra': T('trample hydra that doubles counters on attack', tall(8, 5), evasive(8, 'trample'), board(4, 4, 5, cond=0.6)),
 'Kwain, Itinerant Meddler': T('everyone may draw and gain 1', draw(1, 2, eng=1, sym=1, sym_ok=1), politics(2, hug=1, eng=1)),
 "Long River's Pull": T('counter a creature (any spell with the gift)', answer(2, counter='hard', anyspell=1, inst=1, kinds='s')),
 'Loran of the Third Path': T('kills an artifact/enchantment; you and an opponent draw', answer(3, 'destroy', kinds='ae'), draw(1, 3, eng=1, sym=1, sym_ok=1), politics(3, hug=1, eng=1)),
 'Managorger Hydra': T('grows on every spell cast by anyone', tall(8, 3, cond=0.8), evasive(8, 'trample')),
 'Martial Impetus': T('goads a creature and pumps attackers going elsewhere', politics(3, goad1=1, eng=1)),
 'Mr. Foxglove': T('lifelink; draws to match their hand or cheats a creature', draw(2, 5, eng=1), cheat(4, 0, 5, eng=1, odds=0.5), survive(5, life=3, eng=1)),
 'Octomancer': T('gift an 8/8; copies tokens every end step', wide(3, 5, eng=1), politics(5, hug=0.5)),
 'Peerless Recycling': T('regrow one or two permanents', survive(2, ret=2, inst=1)),
 'Perch Protection': T('four 2/2 fliers; gifted: total protection for a turn', wide(8, 6), survive(6, protall=1, inst=1)),
 'Perplexing Test': T('mass bounce tokens or nontokens', answer(5, wipe=1, wbounce=1, inst=1)),
 'Psychosis Crawler': T('*/* = hand; draws drain each opponent', drain(3, 5), tall(6, 5, cond=0.6)),
 'Realm-Cloaked Giant // Cast Off': T('wipe non-Giants, then a 7/7', answer(5, wipe=1), tall(7, 7)),
 'Riot Control': T('fog yourself and gain life', survive(3, fog=1, inst=1, lifeoneoff=6)),
 'Rishkar, Peema Renegade': T('counters on two; countered creatures tap for G', ramp(2, 3, nc=0), board(1, 2, 3, oneoff=1)),
 'Seaside Citadel': T('tapped Bant tri-land', land(2, C, 'T')),
 'Selvala, Explorer Returned': T('parley: G mana and life per nonland, everyone draws', ramp(1.5, 3, nc=0), draw(1, 3, eng=1, sym=1, sym_ok=1), politics(3, hug=1, eng=1)),
 'Simic Ascendancy': T('counters on creatures; 20 growth counters wins', board(1, 1, 2, cond=0.6), finish('Alt Win', 0, 2, cond=0.4)),
 'Snake Pit': T('Snakes when opponents cast blue/black', wide(1, 4, eng=1, cost=0)),
 'Sphinx of Enlightenment': T('5/5 flier, draw three (they draw one)', draw(3, 6), evasive(5, 'fly'), tall(5, 6)),
 'Spore Frog': T('sac: fog', survive(1, fog=1, sac=1)),
 'Steelburr Champion': T('grows when opponents cast noncreature spells; offspring', board(1, 1, 3, cond=0.8), body(1, 1)),
 'Tamiyo, Field Researcher': T('draws on combat damage; taps two permanents; ultimate free spells', draw(2, 4, eng=1), answer(4, cond=0.5, kinds='cap')),
 'Tempt with Bunnies': T('a card and a Rabbit, more if they accept', draw(2, 3), wide(2, 3), politics(3, hug=1)),
 'Tempt with Discovery': T('fetch lands, more if they accept', ramp(2, 4, land=1, kind='L'), politics(4, hug=1)),
 'Tenuous Truce': T('you and an opponent draw each turn; they won\'t attack you', draw(1, 2, eng=1, sym=1, sym_ok=1), politics(2, fort=1, hug=1)),
 'Thriving Grove': T('tapped G plus a color', land(1, C, 'T')),
 'Triskaidekaphile': T('no max hand; 13 cards wins; pay to draw', draw(1, 2, eng=1, restr=1), finish('Alt Win', 0, 2, cond=0.3)),
 'Twenty-Toed Toad': T('draws and grows on attacks; 20 counters or cards wins', draw(1, 4, eng=1, restr=1), finish('Alt Win', 0, 4, cond=0.3)),
 'Wear Down': T('kill one or two artifacts/enchantments', answer(2, 'destroy', extra=1, kinds='ae', cond=0.8)),
}
COPY = {'Adarkar Wastes': 'family', 'Arcane Signet': 'thing', 'Body of Knowledge': 'family', 'Brushland': 'eddie_cloud', 'Canopy Vista': 'thing',
 'Chasm Skulker': 'family', 'Command Tower': 'grim', 'Cultivate': 'thing', 'Evolving Wilds': 'mech', 'Exotic Orchard': 'thing', 'Faeburrow Elder': 'grim',
 'Farseek': 'thing', 'Fellwar Stone': 'mathas', 'Flooded Grove': 'thing', 'Forgotten Ancient': 'kotis', 'Glacial Fortress': 'thing', 'Hinterland Harbor': 'thing',
 'Mangara, the Diplomat': 'casino', 'Mind Stone': 'family', 'Overflowing Basin': 'dragons', 'Prairie Stream': 'thing', 'Promise of Loyalty': 'thing',
 'Razorverge Thicket': 'felothar', 'Reliquary Tower': 'mathas', 'Rites of Flourishing': 'thing', 'Seachrome Coast': 'family', 'Secret Rendezvous': 'eddie_cloud',
 'Skycloud Expanse': 'vile', 'Sol Ring': 'thing', 'Sungrass Prairie': 'thing', 'Sunpetal Grove': 'thing', 'Sunscorch Regent': 'family', 'Swiftfoot Boots': 'kykar',
 'Swords to Plowshares': 'mathas', 'Temple of Enlightenment': 'kykar', 'Temple of Mystery': 'kotis', 'Temple of Plenty': 'spider', 'Terramorphic Expanse': 'mech',
 'Thought Vessel': 'mathas', 'Thriving Heath': 'eddie_kasla', 'Thriving Isle': 'eddie_kasla', 'Wizard Class': 'eddie_vivi', 'Yavimaya Coast': 'thranduil'}
for _n, _d in COPY.items():
    TAGS[_n] = importlib.import_module(_d).TAGS[_n]

# 0.12.362 tag audit (Kyle): effects the cards do that had no tag yet, and tags that didn't fit
fix_land(TAGS, 'Command Tower', C)   # it came over from a 5-color deck; this deck has 3 colors
for _n in ("Long River's Pull", 'Peerless Recycling', 'Perch Protection', 'Wear Down'):
    add_tags(TAGS, _n, 'gift for an opponent', bargain())
add_tags(TAGS, 'Perch Protection', 'flying Birds', evasive(8, 'fly'))
