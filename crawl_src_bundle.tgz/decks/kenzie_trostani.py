from formulas import *
import importlib
C = 2
META = dict(file='Kenzie_Trostani', deck="Trostani's Choir", icon='🕊️', owner='Kenzie', colors=C,
            cmdr=["Trostani, Selesnya's Voice"], secret=[], archetype='Angels & Lifegain', board=10, creatures=24)
TAGS = {
 "Trostani, Selesnya's Voice": T('gains life equal to each creature\'s toughness; populates tokens', survive(4, life=4, eng=1), wide(2, 4, eng=1, cost=1), body(2, 5)),
 'Ajani, the Greathearted': T('team vigilance; +3 life; counters on everything', board(1, 8, 4, oneoff=1), survive(4, life=3, eng=1)),
 'Always Watching': T('nontoken anthem with vigilance', board(1, 8, 3)),
 'Angel of Deliverance': T('6/6 flier; delirium exiles a creature on damage', tall(6, 8), evasive(6, 'fly'), answer(8, 'exile', eng=1, cond=0.4)),
 'Angelic Quartermaster': T('flier; counters on two creatures', evasive(3, 'fly'), board(1, 2, 5, oneoff=1), body(3, 3)),
 "Bard's Bow": T('makes a 1/1 Hero wearing +2/+2 reach', pump(2, 3, equip=6), wide(1, 3)),
 'Bishop of Wings': T('angels gain 4 life; dying angels leave Spirits', survive(2, life=4, eng=1), wide(1, 2, eng=1, cost=1), body(1, 4)),
 'Blossoming Bogbeast': T('attacks: gain 2, team trample and +X/+X', board(2, 8, 5, cond=0.7), gives_ev(6, 'trample', 5, eng=1), survive(5, life=2, eng=1)),
 'Broken Wings': T('kill an artifact, enchantment or flier', answer(3, 'destroy', inst=1, kinds='cae', cond=0.8)),
 'Citywide Bust': T('wipe toughness 4+', answer(3, wipe=1, cond=0.6)),
 'Clarion Cathars': T('3/3 plus a 1/1', wide(1, 4), body(3, 3)),
 'Cradle of Vitality': T('lifegain turns into +1/+1 counters', board(2, 3, 4, cond=0.7)),
 'Crystal Fragments // Summon: Alexander': T('+1/+1 equip 1; flips into a fog saga that taps their team', pump(1, 1, equip=1), survive(7, prevent=0.5, part='Protect')),
 'Divine Sacrament': T('white anthem, double with threshold', board(1, 8, 3)),
 'Dusk // Dawn': T('wipe power 3+, regrow the small ones from the yard', answer(4, wipe=1, oneside=0, cond=0.7), survive(5, mass=0.3)),
 'Expose to Daylight': T('kill an artifact/enchantment; scry', answer(3, 'destroy', inst=1, kinds='ae')),
 'Favor of the Woods': T('blocks gain 3 life', survive(3, life=3, eng=1, part='Endure')),
 'Finale of Devastation': T('tutor any creature into play from deck or yard', tutor('bf', 't', 4), cheat(4, 0, 4, choose=1)),
 'Glorious Anthem': T('team +1/+1', board(1, 8, 3)),
 "Hedgewitch's Mask": T('+1/+1, can\'t be blocked by big creatures', pump(1, 1, equip=2), gives_ev(3, 'walk', 1, eng=1)),
 'Herald of War': T('flier that grows on attack; angels cost less', evasive(4, 'fly'), ramp(1, 5, nc=0, boost=True)),
 'Howl of the Night Pack': T('a 2/2 Wolf per Forest', wide(8, 7)),
 'Ignite the Beacon': T('two planeswalkers to hand', tutor('hand', 'n', 5, inst=1, count=2)),
 "Kinjalli's Sunwing": T('flier; their creatures enter tapped', evasive(2, 'fly'), politics(3, fort=0.5, eng=1)),
 'Krosan Verge': T('fetches a Forest and a Plains', land(2, C, 'T'), ramp(1, 0, land=1, kind='L', label='Ramp: Krosan Verge thins two lands')),
 'Linden, the Steadfast Queen': T('vigilance; white attackers gain 1 each', survive(3, life=3, eng=1), body(3, 3)),
 'Loot, Exuberant Explorer': T('extra land drop; digs creatures into play', ramp(1, 3, land=1, nc=0), cheat(4, 0, 6, eng=1)),
 'Loxodon Hierarch': T('4/4, gain 4; sac to regenerate the team', survive(4, life=4, mass=0.5, part='Protect'), tall(4, 4)),
 'Phial of Galadriel': T('any-color rock; doubles draws and lifegain when low', ramp(1, 3, color=2)),
 'Planar Cleansing': T('destroy every nonland permanent', answer(6, wipe=1, kinds='caep')),
 'Prism Ring': T('1 life per spell of a color', survive(1, life=1, eng=1)),
 'Prodigious Growth': T('+7/+7 trample aura', pump(7, 6, aura=1)),
 'Rally the Ranks': T('typal anthem (Angels)', board(1, 6, 2)),
 'Ravnica at War': T('exile every multicolored permanent', answer(4, wipe=1, wexile=1, cond=0.5, kinds='caep')),
 'Sanctify': T('kill an artifact/enchantment, gain 3', answer(2, 'destroy', kinds='ae')),
 'Scattered Groves': T('tapped G/W cycler', land(1, C, 'T')),
 'Seraph of Dawn': T('2/4 lifelink flier', evasive(2, 'fly'), survive(4, life=2, eng=1), body(2, 4)),
 'Shamanic Revelation': T('draw one per creature', draw(5, 5), survive(5, lifeoneoff=8)),
 "Sigarda's Vanguard": T('flash flier; double strike for different powers', evasive(3, 'fly'), finish('Burst', 12, 5, cond=0.6)),
 'Sigardian Savior': T('flier; reanimates two 2-drops', evasive(3, 'fly'), survive(5, ret=2)),
 'Sigil of the Empty Throne': T('enchantment spells make 4/4 Angels', wide(4, 5, eng=1, cost=1)),
 'Spear of Heliod': T('anthem; kills whatever hit you', board(1, 8, 3), politics(3, punish=1)),
 'Storm Herd': T('a 1/1 flier per life', wide(20, 10), finish('Burst', 20, 10, cond=0.5)),
 'Sunblast Angel': T('flier; destroys all tapped creatures', evasive(4, 'fly'), answer(6, wipe=1, oneside=1, cond=0.5), body(4, 5)),
 'Sunset Revelry': T('catch-up: life, two Humans, a card', survive(2, lifeoneoff=4), wide(1, 2), draw(1, 2)),
 'Trollhide': T('+2/+2 and regenerate', pump(2, 3, aura=1, protects=1)),
 'Twinblade Paladin': T('grows on lifegain; double strike at 25+', tall(5, 4, cond=0.8), finish('Burst', 10, 4, cond=0.5)),
 'Valkyrie Harbinger': T('lifelink flier that makes 4/4 Angels', evasive(4, 'fly'), wide(4, 6, eng=1, cost=1), survive(6, life=4, eng=1)),
 'Vivien on the Hunt': T('Rhinos, digs creatures, sac-tutors up the curve', wide(4, 6, eng=1), tutor('bf', 't', 6, eng=1, slow=1)),
 "Vivien's Arkbow": T('discard: puts a creature from the top into play', cheat(4, 2, 2, eng=1)),
 'Brushland': T('G/W pain land', land(1, C)),
 'Canopy Vista': T('G/W battle land', land(1, C, 0.6, typed=1)),
 'Command Tower': T('any commander color', land(2, C)),
 'Overgrown Farmland': T('G/W, untapped in multiplayer-ish', land(1, C, 0.6)),
 'Selesnya Sanctuary': T('G/W bounce land', land(1, C, 'T', label='Land: bounce land G/W')),
 'Sungrass Prairie': T('G/W filter land', land(1, C)),
}
COPY = {'Bastion Protector': 'eddie_cloud', 'Behemoth Sledge': 'eddie_cloud', 'Chromatic Lantern': 'thing', 'Darksteel Ingot': 'mech',
        'Keeper of the Accord': 'eddie_kasla', 'Lathiel, the Bounteous Dawn': 'spider', 'Luminous Broodmoth': 'felothar',
        'Return to Nature': 'dragons', 'Serra Redeemer': 'family', 'Strionic Resonator': 'modular', 'Swiftfoot Boots': 'kykar',
        'Swords to Plowshares': 'mathas', 'Zetalpa, Primal Dawn': 'grim'}
for _n, _d in COPY.items():
    TAGS[_n] = importlib.import_module(_d).TAGS[_n]

# 0.12.362 tag audit (Kyle): effects the cards do that had no tag yet, and tags that didn't fit
drop_tags(TAGS, "Bard's Bow", 'Wide')   # the 1/1 Hero is already counted by the automatic Job select rule
TAGS['Strionic Resonator'] = T('copies a Trostani lifegain or populate trigger', feeds('threats', eng=1, what='copies Trostani lifegain / populate triggers'))
add_tags(TAGS, 'Lathiel, the Bounteous Dawn', 'lifelink', survive(2, life=2, eng=1))
add_tags(TAGS, 'Prodigious Growth', 'trample', gives_ev(10, 'trample', 6))
add_tags(TAGS, 'Trollhide', 'regenerates', survive(3, ownkw=1, label='Survive (Protect): regenerate (MV:3)'))
add_tags(TAGS, 'Vivien on the Hunt', '+1: mill five, keep the creatures', draw(1.5, 6, eng=1))
fix_land(TAGS, 'Krosan Verge', C, 'T')
fix_land(TAGS, 'Command Tower', C)
