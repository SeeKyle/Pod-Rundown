from formulas import *
C = 2
V = 0.75  # crew 3+ vehicle
META = dict(file='Tame_Depala', deck='Tame Depala', icon='⚒️', owner='Kyle', colors=C,
            cmdr=['Depala, Pilot Exemplar'], secret=[], archetype='Dwarves & Vehicles', board=12, creatures=8)
TAGS = {
 'Depala, Pilot Exemplar': T('Dwarves +1/+1, crewed Vehicles +1/+1; whenever she taps (crewing!), pay X to dig for Dwarves and Vehicles',
    board(1, 10, 3), draw(2, 3, eng=1, restr=1)),
 'Aerial Responder': T('2/3 flying vigilance lifelink', evasive(2, 'fly'), survive(3, life=2, eng=1)),
 'Air Response Unit': T('3/3 flying vigilance vehicle, crew 1', evasive(3, 'fly'), body(3, 3)),
 "Amber Gristle O'Maul": T('haste; attacks: discard hand, draw per opponent attacked', draw(2, 4, eng=1, restr=1)),
 'An Unexpected Party // At the Door': T('Dwarves +2/+2; adventure makes X Dwarves', board(2, 10, 4), wide(4, 5)),
 'Balin, Loremaster': T('Dwarves entering: wheel your hand; with a story it burns each opponent', draw(2, 5, eng=1, restr=1), drain(2, 5, cond=0.5)),
 'Beamtown Beatstick': T('+1/+0 menace; hits make Treasure', pump(1, 1, equip=2, base=4), gives_ev(3, 'menace', 1, eng=1, cost=1), scale(ramp(1, 1), 0.5)),
 'Bifur, Melodic Rider': T('4/5; ETB/attack counter; Dwarf triggers happen twice', tall(5, 6), board(1, 3, 6)),
 "Blacksmith's Talent": T('Sword token; auto-equip each combat; level 3: double strike and haste', board(3, 4, 4)),
 'Bruenor Battlehammer': T('+2/+0 per Equipment; first equip each turn free', tall(5, 4), board(4, 3, 4), ramp(2, 4, boost=True)),
 'Celebrate the Mountain-king': T('exile a nonland permanent from each opponent; recruit', answer(4, 'exile', hits='any', extra=2, kinds='caep'), select(4, loot=1)),
 'Colossal Plow': T('crew 6; attacks add WWW and 3 life', scale(tall(6, 2), 0.5), scale(ramp(3, 2), 0.5), survive(2, life=1, eng=1)),
 'Colossus Hammer': T('+10/+10 (equip 8, free with Bruenor or Kíli)', pump(10, 1, equip=8, base=4)),
 "Conqueror's Galleon // Conqueror's Foothold": T('2/10 vehicle; after attacking becomes a card-drawing land', scale(draw(1, 4, eng=1), 0.6)),
 'Dáin Ironfoot': T('ETB: Axe; attacks give equipped attackers double strike', board(3, 4, 3)),
 'Dáin, Lord of the Iron Hills': T('with a story: creatures attacking you cost 1 each', politics(2, fort=1, tax=1, eng=1)),
 "Dáin's Company": T('ETB: dig 4 for a Dwarf or Equipment; lifelink', select(2, dig=4), survive(2, life=1, eng=1)),
 'Dragon Throne of Tarkir': T('equipped creature: 2, tap: team +X/+X and trample', board(4, 8, 4, cond=0.7)),
 'Dwalin, Weaponmaster': T('first strike; hone counters on every Equipment', board(1, 6, 2)),
 'Dwarven Mauler': T('equip costs 2 less on it', body(2, 1)),
 'Dwarven Recruiter': T('stack every Dwarf on top', tutor('top', 't', 3, count=3)),
 'Fearless Skald': T('backup double strike', board(3, 2, 5, oneoff=1), body(3, 2)),
 'Fire Diamond': T('tapped R rock', ramp(1, 2, nc=1)),
 'Gimli, Counter of Kills': T('4/3 trample; opposing deaths ping', tall(4, 4), evasive(4, 'trample'), drain(2, 4, cond=0.6)),
 'Giott, King of the Dwarves': T('double strike; loot when Dwarves or Equipment enter', select(2, loot=1, eng=1)),
 'Glóin the Mighty // Easy Pickings': T('RR every turn; adventure pings their team', ramp(2, 4), tall(4, 4), answer(3, wipe=1, oneside=1, cond=0.25)),
 'Goldvein Pick': T('+1/+1; hits make Treasure', pump(1, 2, equip=1, base=4), scale(ramp(1, 2), 0.5)),
 'Greatsword of Tyr': T('attack: counter and tap a blocker', pump(2, 2, equip=1, base=4), gives_ev(4, 'walk', 2, eng=1)),
 'Hammers of Moradin': T('myriad: attacks every opponent; taps a blocker each', wide(3, 3, eng=1), gives_ev(6, 'walk', 3, eng=1)),
 'Heart of Kiran': T('4/4 flying vigilance vehicle, crew 3', scale(tall(4, 2), V), evasive(4, 'fly')),
 'Iron Hills Blacksmith': T('double strike; ETB Axe', body(2, 1), board(1, 1, 2)),
 'Kellan, the Fae-Blooded // Birthright Boon': T('team +1/+0 per Equipment on Kellan; adventure tutors Equipment',
    board(2, 8, 3, cond=0.5), tutor('hand', 't', 2)),
 'Kíli the Resourceful': T('first equip free with a story; a card when Dwarves or Equipment enter', draw(1, 2, eng=1, restr=1), ramp(2, 2, boost=True)),
 'Knight Paladin': T('6/6 trample vehicle, crew 1; ETB 4 to each opponent', tall(6, 5), evasive(6, 'trample'), finish('Burst', 4, 5)),
 'Koll, the Forgemaster': T('equipped creatures dying come back to hand', survive(2, ret=1, eng=1)),
 'Magda, Brazen Outlaw': T('Dwarves +1/+0; tapped Dwarves (crewing too) make Treasure', board(1, 10, 2), ramp(2, 2, color=2)),
 'Mask of Memory': T('hits: draw 2 discard 1', select(2, loot=2, eng=1)),
 'Monologue Tax': T('opponents\' second spell gives you Treasure', scale(ramp(1, 3, nc=1, color=2), 0.6), politics(3, punish=1, eng=1)),
 'Nautiloid Ship': T('5/5 flying vehicle; eats a graveyard and steals from it', scale(tall(5, 4), V), evasive(5, 'fly'), answer(4, denial=1, kinds='g')),
 'Necron Monolith': T('7/7 flying indestructible vehicle; attacks make Necrons', scale(tall(7, 7, 'P'), V), evasive(7, 'fly'), wide(2, 7, eng=1)),
 'Orcrist, Goblin-cleaver': T('+2/+2 trample; hits make a Treasure per Dwarf', pump(2, 3, equip=3, base=4), gives_ev(4, 'trample', 3, eng=1), scale(ramp(3, 3), 0.5)),
 'Peacewalker Colossus': T('6/6 vehicle, crew 4; animates other vehicles', scale(tall(6, 3), V)),
 'Plundering Barbarian': T('ETB destroy an artifact or make Treasure', answer(3, 'destroy', kinds='a')),
 'Pre-War Formalwear': T('ETB reanimate a 3-drop and suit it up', survive(3, ret=1), pump(2, 3, equip=3, base=4)),
 'Prismatic Strands': T('prevent a color\'s damage; free flashback', survive(3, fog=1, inst=1), second_life('flashback fog', survive(0, fog=1, inst=1))),
 'Reckless Crew': T('a 2/1 Dwarf per Vehicle and Equipment, all suited up', wide(8, 4)),
 'Reconnaissance': T('pull attackers out of combat after triggers', survive(1, prot1=1, eng=1)),
 'Requisition Raid': T('destroy an artifact and an enchantment', answer(2, 'destroy', hits='2', extra=1, kinds='ae')),
 'Return to Dust': T('exile two artifacts/enchantments', answer(4, 'exile', hits='2', extra=1, inst=1, kinds='ae')),
 'Rover Blades': T('double strike equipment or 2/2 vehicle', pump(0, 3, equip=4, ds=1, base=4)),
 'Sentinel Sarah Lyons': T('haste; team +2/+2 after an artifact enters; battalion burns for artifact count',
    tall(4, 5, haste=1), board(2, 10, 5, cond=0.6), drain(6, 5, cond=0.6)),
 'Shattered Acolyte': T('lifelink; sac: destroy an artifact or enchantment', answer(2, 'destroy', hits='2', kinds='ae')),
 "Teshar, Ancestor's Apostle": T('flier; historic spells return a 3-drop creature', survive(4, ret=1, eng=1), evasive(2, 'fly')),
 'The Arkenstone // Seek the Heart': T('team +1/+1, a card every end step; adventure finds a legend',
    board(1, 10, 5), draw(1, 5, eng=1), tutor('hand', 't', 3)),
 'The Fantasticar': T('4/4 flying vehicle animated by noncreature spells', evasive(4, 'fly'), scale(tall(4, 3), 0.5)),
 'Thorin Oakenshield': T('trample; with a story your artifacts and creatures have ward 1', survive(2, protall=0.5)),
 'Thorin, Mountain-king': T('ETB: move all Equipment to one creature, it fights', answer(4, 'damage', cond=0.8), board(2, 1, 4)),
 'Toolcraft Exemplar': T('3/2 first strike with artifacts', body(3, 2)),
 'Two-Handed Axe // Sweeping Cleave': T('doubles power on attack; adventure double strike', pump(0, 3, equip=2, dbl=1, base=4)),
 "Vanquisher's Banner": T('Dwarves +1/+1; draw on every Dwarf', board(1, 10, 5), draw(1, 5, eng=1)),
 'Winnowing': T('everyone keeps one creature type: you keep your Dwarves', answer(3, wipe=1, oneside=1)),   # convoked: about 3 real mana
 # new lands
 'Dwarven Mine': T('Mountain; untapped with three Mountains and makes a Dwarf', land(0, C, 0.7, typed=1)),
 'Desert of the Fervent': T('tapped R, cycling', land(0, C, 'T', flex=1)),
 'Desert of the True': T('tapped W, cycling', land(0, C, 'T', flex=1)),
 'Drifting Meadow': T('tapped W, cycling', land(0, C, 'T', flex=1)),
 'Iron Hills': T('tapped R/W; sac for Dwarf counters', land(1, C, 'T', flex=1)),
 'Mech Hangar': T('colorless or any color for Vehicles/Pilots', land(1, C, flex=1)),
 "Slayers' Stronghold": T('colorless; haste and +2/+0', land(0, C, flex=1)),
 # reused tags (same card, other decks)
 "Cultivator's Caravan": T('any-color rock; 5/5 vehicle', ramp(1, 3, imm=1, nc=1, color=2), scale(tall(5, 3), V)),
 'Gold Myr': T('W dork', ramp(1, 2, nc=1, color=1)),
 'Mechtitan Core': T('combine five artifacts into a 10/10 flying trample lifelink haste',
    tall(10, 7, 'B', haste=1, cond=0.5), scale(evasive(10, 'fly', two=1), 0.5)),
 'Skysovereign, Consul Flagship': T('6/5 flying vehicle; 3 damage to a creature on ETB and attack',
    scale(tall(6, 5), V), evasive(6, 'fly'), answer(5, 'damage', hits='2', eng=1, kinds='cp')),
 'Clifftop Retreat': T('R/W check land', land(1, C, 0.6)),
 'Command Tower': T('any commander color', land(2, C)),
 "Rogue's Passage": T('colorless; 4: a creature can\'t be blocked',
    land(0, C), scale(gives_ev(10, 'unblock', 0, eng=1, cost=1), 0.75)),
 'Smoldering Crater': T('tapped R, cycling', land(0, C, 'T', flex=1)),
 'Wind-Scarred Crag': T('tapped R/W gain land', land(1, C, 'T')),
}

# 0.12.89 commander engine: these entries on the commander count x2 (always available from the command zone)
META['cmd_engine'] = {'Depala, Pilot Exemplar': ['draw']}

# 0.12.362 tag audit (Kyle): lands can only add this deck's own colors
fix_land(TAGS, 'Command Tower', C)
add_tags(TAGS, "Slayers' Stronghold", 'RW: +2/+0, vigilance and haste', gives_ev(0, 'fly', 0, eng=1, cost=1, label='Reach: haste for one creature (land)'))

# 0.12.362 tag audit (Kyle): effects the cards do that had no tag yet, and tags that didn't fit
add_tags(TAGS, 'Necron Monolith', 'indestructible', survive(7, ownkw=1))
add_tags(TAGS, 'Requisition Raid', 'spree: counters on your team', board(1, 8, 3, oneoff=1, cond=0.6))
add_tags(TAGS, 'Thorin Oakenshield', 'trample', evasive(3, 'trample'))
add_tags(TAGS, 'Thorin, Mountain-king', 'trample', evasive(3, 'trample'))
