/* 0.12.325 (Kyle) EVENTS. After every 3rd stage cleared (3, 6, 9, 12, 15, 18, ...) the team runs into an EVENT;
   after every 10th (10, 20, 30, ...) a MAJOR event. Every event is a multiple-choice window: a short story and 2-4 choices.
   Choices can pay out right away at camp, cost resources, hurt or heal people, or change the NEXT stage
   (how many zombies, loot, wrecks, how hard the zombies hit, a team-wide buff or debuff).

   WHY an event shows up: each event has a weight that reacts to how the run is going, so the events tell a story:
     low food/water -> food-and-water events more likely; lots of gold -> raiders and traders; injuries -> medics and doctors;
     many falls -> second-wind events; a Warhound or Engineer on the team -> scrap events; Downtown vs the lake -> different scenery;
     a run that's going great -> trouble finds you (raids, tougher hordes). The same event never shows twice in a row.
   Next-stage effects live on run.evNext (cleared once that stage is beaten); permanent ones on run.evPerm. */
const EV_EVERY=3,EV_MAJOR=10;
function eventKind(cleared){return cleared%EV_MAJOR===0?'major':cleared%EV_EVERY===0?'normal':null;}
function evCtx(s,run){const st=CFG.stage(run.stage,run.prestige);const T=run.team;const inj=T.reduce((a,k)=>a+((run.heroes[k]&&run.heroes[k].inj)||[]).length,0);
  const hungry=T.filter(k=>run.heroes[k]&&((run.heroes[k].hunger||0)>0||(run.heroes[k].thirst||0)>0)).length;
  return {s,run,T,city:st.biome&&st.biome.id==='city',gold:s.gold||0,parts:s.parts||0,food:run.food||0,water:run.water||0,inj,hungry,falls:run.falls||0,
    has:k=>T.includes(k),low:(run.food||0)+(run.water||0)<3,rich:(s.gold||0)>=250,hurt:T.filter(k=>run.heroes[k]&&(run.heroes[k].hpf==null?1:run.heroes[k].hpf)<.6).length};}
/* ---- effect helpers (all return a short log line) ---- */
const EVX={
  give(c,o){const L=[];const s=c.s,run=c.run;
    if(o.gold){s.gold=Math.max(0,(s.gold||0)+o.gold);L.push((o.gold>0?'+':'')+o.gold+' gold');}
    if(o.parts){s.parts=Math.max(0,(s.parts||0)+o.parts);L.push((o.parts>0?'+':'')+o.parts+' spare parts');}
    if(o.food){run.food=Math.max(0,(run.food||0)+o.food);L.push((o.food>0?'+':'')+o.food+' food');}
    if(o.water){run.water=Math.max(0,(run.water||0)+o.water);L.push((o.water>0?'+':'')+o.water+' water');}
    if(o.lucky){s.lucky=Math.max(0,(s.lucky||0)+o.lucky);L.push((o.lucky>0?'+':'')+o.lucky+' Lucky Die');}
    if(o.reroll){run.rerolls=(run.rerolls||0)+o.reroll;L.push('+'+o.reroll+' reroll');}
    if(o.med)for(const [m,n] of Object.entries(o.med)){run.med=run.med||{};run.med[m]=(run.med[m]||0)+n;L.push('+'+n+' '+MEDS[m].name);}
    return L.join(', ');},
  hp(c,pct,who){const ks=who||c.T;for(const k of ks){const H=c.run.heroes[k];if(!H||H.dead)continue;H.hpf=Math.max(.1,Math.min(1,(H.hpf==null?1:H.hpf)+pct));}
    return (pct>0?'+':'')+Math.round(pct*100)+'% HP to '+(who&&who.length===1?heroDef(who[0]).name:'everyone');},
  feed(c,n){for(const k of c.T){const H=c.run.heroes[k];if(!H||k==='robot')continue;H.hunger=Math.max(0,Math.min(3,(H.hunger||0)-n));H.thirst=Math.max(0,Math.min(3,(H.thirst||0)-n));}
    c.run.needFeed=n>0?[]:c.run.needFeed;return n>0?'everyone ate and drank':'everyone got hungrier and thirstier';},
  injure(c,k,id){const H=c.run.heroes[k];if(!H||k==='robot')return '';const ids=['leg','arm','wound','concuss'];id=id||ids[Math.floor(Math.random()*ids.length)];
    H.inj=H.inj||[];if(!H.inj.some(x=>x.id===id))H.inj.push({id,st:INJURY[id].st,fresh:1});return heroDef(k).name+' got a '+INJURY[id].name;},
  cure(c){for(const k of c.T){const H=c.run.heroes[k];if(H&&H.inj&&H.inj.length){const x=H.inj.shift();return 'cured '+heroDef(k).name+'\'s '+INJURY[x.id].name;}}return 'nobody needed it';},
  next(c,o,why){const E=c.run.evNext=c.run.evNext||{why:[]};for(const [k,v] of Object.entries(o)){if(k==='en'||k==='ambush')E[k]=(E[k]||0)+v;else E[k]=(E[k]||1)*v;}if(why)E.why.push(why);return 'next stage: '+why;},
  perm(c,o,why){const P=c.run.evPerm=c.run.evPerm||{why:[]};for(const [k,v] of Object.entries(o))P[k]=(P[k]||1)*v;if(why)P.why.push(why);return 'for the rest of the run: '+why;},
  rnd(a){return a[Math.floor(Math.random()*a.length)];},
  pick(c){return EVX.rnd(c.T.filter(k=>!(c.run.heroes[k]&&c.run.heroes[k].dead)));},
  roll(p,c){const lk=c.T.reduce((a,k)=>a+((c.s.heroes[k]&&c.s.heroes[k].insp&&INSP[c.s.heroes[k].insp]&&INSP[c.s.heroes[k].insp].mod&&INSP[c.s.heroes[k].insp].mod.luck)||0),0);return Math.random()<Math.min(.95,p+lk*.004);}};
const nm=k=>heroDef(k)?heroDef(k).name:k;
/* each choice: t = button text, d = what it does (shown under the button), need(c) -> false or a reason it can't be picked, fx(c) -> log line */
const EVENTS=[
 /* ---------- NORMAL ---------- */
 {id:'pantry',icon:'🥫',title:'The Untouched Pantry',w:c=>c.low?3:1,text:c=>c.city?'A corner store with its shutter half down. Behind the counter: shelves nobody has touched. Something is moving in the stock room.':'A hunting cabin with the door still locked. Through the window: canned food stacked to the ceiling. Something is scratching inside.',
  ch:[{t:'Clear the stock room and take it all',d:'+3 food, +3 water. One random person gets hurt (-25% HP).',fx:c=>{const k=EVX.pick(c);return EVX.give(c,{food:3,water:3})+'; '+EVX.hp(c,-.25,[k]);}},
      {t:'Grab what\'s by the door and go',d:'+1 food, +1 water.',fx:c=>EVX.give(c,{food:1,water:1})},
      {t:'Board it up and mark it for later',d:'Next stage: food and water drop 2x as often.',fx:c=>EVX.next(c,{supply:2},'food and water drop 2x as often')}]},
 {id:'trader',icon:'🧳',title:'A Trader on the Road',w:c=>c.rich?3:1.2,text:()=>'A wiry old man with a shopping cart full of junk waves you down. "Everything\'s for sale, friends. Everything."',
  ch:[{t:'Buy medicine (60 gold)',d:'A Splint and a Hemostat.',need:c=>c.gold<60&&'Not enough gold',fx:c=>EVX.give(c,{gold:-60,med:{splint:1,hemo:1}})},
      {t:'Buy supplies (40 gold)',d:'+2 food, +2 water.',need:c=>c.gold<40&&'Not enough gold',fx:c=>EVX.give(c,{gold:-40,food:2,water:2})},
      {t:'Sell him scrap',d:'-6 spare parts, +70 gold.',need:c=>c.parts<6&&'Not enough spare parts',fx:c=>EVX.give(c,{parts:-6,gold:70})},
      {t:'Wave him off',d:'Nothing happens.',fx:()=>'he shrugs and pushes his cart on'}]},
 {id:'raiders',icon:'🏴',title:'Raiders Want a Toll',w:c=>(c.rich?3:.8)*(c.gold>=50?1:.2),text:()=>'Three armed survivors block the road. "Nice gear. Pay up, or we take it from whoever we drop."',
  ch:[{t:'Pay the toll',d:'Lose 30% of your gold.',fx:c=>EVX.give(c,{gold:-Math.round(c.gold*.3)})},
      {t:'Fight them',d:'Keep your gold. 50/50: win and take theirs (+60 gold), or everyone takes a beating (-30% HP).',fx:c=>EVX.roll(.5,c)?'you ran them off: '+EVX.give(c,{gold:60}):'they hit hard before running: '+EVX.hp(c,-.3)},
      {t:'Take the long way around',d:'Next stage: 15% more zombies, but they never find you.',fx:c=>EVX.next(c,{foes:1.15},'15% more zombies (the long way)')}]},
 {id:'stranger',icon:'🩸',title:'A Bitten Stranger',w:c=>1,text:()=>'A woman sits against a wall, pressing a rag to her arm. "It\'s not a bite. I swear it\'s not a bite." She has a full backpack.',
  ch:[{t:'Patch her up',d:'Costs 1 Hemostat or 8 spare parts. She gives you her pack: +2 food, +2 water, +1 Lucky Die.',need:c=>!((c.run.med&&c.run.med.hemo)>0)&&c.parts<8&&'Need a Hemostat or 8 spare parts',fx:c=>{if(c.run.med&&c.run.med.hemo>0)c.run.med.hemo--;else c.s.parts-=8;return 'she thanks you: '+EVX.give(c,{food:2,water:2,lucky:1});}},
      {t:'Take the pack, leave her',d:'+2 food, +2 water. Morale drops: next stage everyone deals 8% less damage.',fx:c=>EVX.give(c,{food:2,water:2})+'; '+EVX.next(c,{dmg:.92},'everyone deals 8% less damage (guilt)')},
      {t:'Walk away',d:'Nothing happens.',fx:()=>'you leave her be'}]},
 {id:'cache',icon:'📦',title:'A Military Cache',w:c=>c.has('soldier')||c.has('eng')?2:1,text:()=>'A green crate under a tarp, stenciled with a unit number. It\'s padlocked and wired to something.',
  ch:[{t:'Pick the lock carefully',d:'70% chance: +12 spare parts and a Lucky Die. Otherwise it blows: everyone -20% HP.',fx:c=>EVX.roll(.7,c)?'it opens clean: '+EVX.give(c,{parts:12,lucky:1}):'BOOM: '+EVX.hp(c,-.2)},
      {t:'Smash it open',d:'+6 spare parts, guaranteed. The noise draws them: next stage has 10% more zombies.',fx:c=>EVX.give(c,{parts:6})+'; '+EVX.next(c,{foes:1.1},'10% more zombies (the noise)')},
      {t:'Leave it',d:'Nothing happens.',fx:()=>'better safe'}]},
 {id:'storm',icon:'⛈️',title:'A Storm Rolls In',w:c=>c.city?.6:1.5,text:()=>'The sky goes black and the rain comes down in sheets. The dead hate the cold, but so do you.',
  ch:[{t:'Wait it out',d:'Everyone rests: +20% HP, but you use up 1 food and 1 water.',need:c=>(c.food<1||c.water<1)&&'Need 1 food and 1 water',fx:c=>EVX.give(c,{food:-1,water:-1})+'; '+EVX.hp(c,.2)},
      {t:'Push through the storm',d:'Next stage: zombies move 10% slower in the mud, but you do too (-8% move speed).',fx:c=>EVX.next(c,{zspd:.9,mv:.92},'zombies 10% slower, you 8% slower (mud)')},
      {t:'Catch the rain',d:'+3 water.',fx:c=>EVX.give(c,{water:3})}]},
 {id:'pharmacy',icon:'💊',title:'A Looted Pharmacy',w:c=>(c.city?2:.5)*(c.inj?2:1),text:()=>'Glass everywhere, shelves stripped. But the back room door is still locked.',
  ch:[{t:'Break into the back room',d:'+1 Painkillers, +1 Splint. 40% chance a few zombies were locked in: one person gets hurt.',fx:c=>{let L=EVX.give(c,{med:{pills:1,splint:1}});if(!EVX.roll(.6,c))L+='; '+EVX.hp(c,-.3,[EVX.pick(c)]);return L;}},
      {t:'Search the floor',d:'+1 Painkillers.',fx:c=>EVX.give(c,{med:{pills:1}})}]},
 {id:'campfire',icon:'🔥',title:'Someone Else\'s Campfire',w:c=>c.city?.6:1.6,text:()=>'Warm coals, a pot still bubbling, and nobody around. Their tracks lead into the trees.',
  ch:[{t:'Eat their stew',d:'Everyone eats and drinks (Hunger and Thirst down 1).',fx:c=>EVX.feed(c,1)},
      {t:'Follow the tracks',d:'60% chance: you find their stash (+40 gold, +4 spare parts). Otherwise it\'s a trap: next stage starts with an ambush.',fx:c=>EVX.roll(.6,c)?'their stash: '+EVX.give(c,{gold:40,parts:4}):EVX.next(c,{ambush:1},'an ambush right at the start')},
      {t:'Leave it',d:'Nothing happens.',fx:()=>'not your food'}]},
 {id:'horde',icon:'🧟',title:'Horde Tracks',w:c=>c.falls?.6:1.4,text:()=>'Thousands of footprints in the dirt, all heading the same way you are.',
  ch:[{t:'Get ahead of them',d:'Next stage: 20% fewer zombies, but everyone starts at -15% HP from the forced march.',fx:c=>EVX.hp(c,-.15)+'; '+EVX.next(c,{foes:.8},'20% fewer zombies')},
      {t:'Hit them head on',d:'Next stage: 25% more zombies and everyone gets 50% more XP from kills.',fx:c=>EVX.next(c,{foes:1.25,xp:1.5},'25% more zombies, +50% XP')},
      {t:'Wait for them to pass',d:'Costs 1 food and 1 water. Nothing else changes.',need:c=>(c.food<1||c.water<1)&&'Need 1 food and 1 water',fx:c=>EVX.give(c,{food:-1,water:-1})}]},
 {id:'scrapheap',icon:'⚙️',title:'A Junkyard',w:c=>c.has('robot')||c.has('eng')?2.5:.8,text:()=>'Stacks of crushed cars and a crane that still has a little juice in it.',
  ch:[{t:'Strip it for an hour',d:'+10 spare parts. Next stage starts a little later at night: zombies hit 5% harder.',fx:c=>EVX.give(c,{parts:10})+'; '+EVX.next(c,{zdmg:1.05},'zombies hit 5% harder')},
      {t:'Grab what\'s on top',d:'+4 spare parts.',fx:c=>EVX.give(c,{parts:4})},
      {t:'Use the crane to block the road behind you',d:'Next stage: no stragglers come in loud (10% fewer zombies).',fx:c=>EVX.next(c,{foes:.9},'10% fewer zombies')}]},
 {id:'radio',icon:'📻',title:'A Voice on the Radio',w:c=>1,text:()=>'"...anyone out there... supply drop at the old ...ksshh... repeat..." The signal fades in and out.',
  ch:[{t:'Chase the signal',d:'Next stage: food, water and spare parts drop 1.5x as often, but 15% more zombies follow the same signal.',fx:c=>EVX.next(c,{supply:1.5,parts:1.5,foes:1.15},'more supplies, 15% more zombies')},
      {t:'Answer it',d:'50/50: they send a Lucky Die your way, or it was a lure (next stage: 20% more zombies).',fx:c=>EVX.roll(.5,c)?EVX.give(c,{lucky:1}):EVX.next(c,{foes:1.2},'20% more zombies (it was a lure)')},
      {t:'Turn it off',d:'Nothing happens.',fx:()=>'static'}]},
 {id:'kids',icon:'🎒',title:'Scavenger Kids',w:c=>c.low?.5:1,text:()=>'Two kids with slingshots and a wagon full of cans. They look scared of you and hungry.',
  ch:[{t:'Give them food (2 food)',d:'They tell you a safe route: next stage has 15% fewer zombies, and you get a Lucky Die.',need:c=>c.food<2&&'Need 2 food',fx:c=>EVX.give(c,{food:-2,lucky:1})+'; '+EVX.next(c,{foes:.85},'15% fewer zombies (safe route)')},
      {t:'Trade with them',d:'-20 gold, +2 food, +2 water.',need:c=>c.gold<20&&'Not enough gold',fx:c=>EVX.give(c,{gold:-20,food:2,water:2})},
      {t:'Let them be',d:'Nothing happens.',fx:()=>'they run off'}]},
 {id:'doctor',icon:'🩺',title:'A Doctor in Hiding',w:c=>c.inj?3:c.hurt?1.5:.4,text:()=>'A man in scrubs points a shotgun at you from a window. "I can help you. For a price."',
  ch:[{t:'Pay for treatment (50 gold)',d:'Cures one injury and heals everyone +30%.',need:c=>c.gold<50&&'Not enough gold',fx:c=>EVX.give(c,{gold:-50})+'; '+EVX.cure(c)+'; '+EVX.hp(c,.3)},
      {t:'Trade parts (8 spare parts)',d:'Heals everyone +25%.',need:c=>c.parts<8&&'Not enough spare parts',fx:c=>EVX.give(c,{parts:-8})+'; '+EVX.hp(c,.25)},
      {t:'Leave',d:'Nothing happens.',fx:()=>'he lowers the gun'}]},
 {id:'bridge',icon:'🌉',title:'The Broken Bridge',w:c=>c.city?.5:1.2,text:()=>'The bridge ahead is half gone. You could climb across the beams, or go the long way through the woods.',
  ch:[{t:'Climb the beams',d:'60% chance it goes fine. Otherwise someone falls and breaks a leg.',fx:c=>EVX.roll(.6,c)?'everyone made it':EVX.injure(c,EVX.pick(c),'leg')},
      {t:'Go through the woods',d:'Next stage: twice as many rocks, logs and stumps to search, and 10% more zombies.',fx:c=>EVX.next(c,{grove:2,foes:1.1},'2x searchable rocks and logs, 10% more zombies')}]},
 {id:'gunstore',icon:'🔫',title:'A Gun Store',w:c=>c.city?2:.4,text:()=>'The steel door is open a crack. Shell casings everywhere, and a smell you don\'t want to think about.',
  ch:[{t:'Go in and look for ammo',d:'Next stage: everyone deals +12% damage. 30% chance someone gets hurt inside.',fx:c=>{let L=EVX.next(c,{dmg:1.12},'+12% damage');if(!EVX.roll(.7,c))L+='; '+EVX.hp(c,-.3,[EVX.pick(c)]);return L;}},
      {t:'Check the counter only',d:'+5 spare parts.',fx:c=>EVX.give(c,{parts:5})}]},
 {id:'dogs',icon:'🐺',title:'Wild Dogs',w:c=>c.city?.8:1.3,text:()=>'A pack of thin, wild dogs circles your camp, growling. They\'re not dead. Just starving.',
  ch:[{t:'Throw them food (1 food)',d:'They leave you alone, and one follows you: next stage everyone moves 6% faster (they warn you of danger).',need:c=>c.food<1&&'Need 1 food',fx:c=>EVX.give(c,{food:-1})+'; '+EVX.next(c,{mv:1.06},'+6% move speed')},
      {t:'Scare them off',d:'40% chance one bites: a Deep Wound on someone.',fx:c=>EVX.roll(.6,c)?'they scatter':EVX.injure(c,EVX.pick(c),'wound')}]},
 {id:'church',icon:'⛪',title:'A Quiet Church',w:c=>c.falls?2:1,text:()=>'Candles still burn on the altar. Someone has been keeping them lit. There\'s a donation box.',
  ch:[{t:'Rest here a while',d:'Everyone +25% HP. Next stage starts with full energy.',fx:c=>EVX.hp(c,.25)+'; '+EVX.next(c,{en:1},'everyone starts with full energy')},
      {t:'Leave an offering (25 gold)',d:'+1 Lucky Die and +1 reroll.',need:c=>c.gold<25&&'Not enough gold',fx:c=>EVX.give(c,{gold:-25,lucky:1,reroll:1})},
      {t:'Rob the donation box',d:'+35 gold. Next stage: everyone takes 8% more damage (bad luck).',fx:c=>EVX.give(c,{gold:35})+'; '+EVX.next(c,{taken:1.08},'everyone takes 8% more damage (bad luck)')}]},
 {id:'fuel',icon:'⛽',title:'A Gas Station',w:c=>c.city?1.5:.8,text:()=>'The pumps are dry, but the tanker truck out back might not be.',
  ch:[{t:'Siphon fuel for camp',d:'+6 spare parts worth of fuel and a working lighter: next stage there are 50% more wrecked cars to loot.',fx:c=>EVX.give(c,{parts:6})+'; '+EVX.next(c,{cars:1.5},'50% more wrecked cars')},
      {t:'Rig the tanker to blow behind you',d:'Next stage: 15% fewer zombies. Costs 4 spare parts.',need:c=>c.parts<4&&'Need 4 spare parts',fx:c=>EVX.give(c,{parts:-4})+'; '+EVX.next(c,{foes:.85},'15% fewer zombies')},
      {t:'Raid the shop',d:'+1 food, +2 water.',fx:c=>EVX.give(c,{food:1,water:2})}]},
 {id:'teeg',icon:'🐻',title:'Tee Runs Into Old Friends',w:c=>c.has('teeg')?3:0,text:()=>'"Ayy, that\'s my homies!" A couple of guys Tee knows from back in the day are holed up in a corner store.',
  ch:[{t:'Let Tee catch up with them',d:'They share what they have: +2 food, +2 water, +30 gold.',fx:c=>EVX.give(c,{food:2,water:2,gold:30})},
      {t:'Ask them to roll with you for a stage',d:'Next stage: everyone deals +10% damage and takes 5% less.',fx:c=>EVX.next(c,{dmg:1.1,taken:.95},'+10% damage, 5% less damage taken')}]},
 {id:'smoke',icon:'🌿',title:'JP Finds a Stash',w:c=>c.has('jp')?3:0,text:()=>'JP stops dead. "Boys. Boys. Look what somebody left in this glovebox."',
  ch:[{t:'Celebrate',d:'Everyone +15% HP. Next stage everyone is a little slow (-6% move speed).',fx:c=>EVX.hp(c,.15)+'; '+EVX.next(c,{mv:.94},'-6% move speed')},
      {t:'Save it for trading',d:'+45 gold.',fx:c=>EVX.give(c,{gold:45})}]},
 {id:'ambush',icon:'⚠️',title:'It Was Too Quiet',w:c=>c.falls?.4:(c.run.stage>8?1.6:.8),text:()=>'Your camp is surrounded before anyone hears a thing. Moans in every direction.',
  ch:[{t:'Hold the camp',d:'Everyone -20% HP, but you keep everything.',fx:c=>EVX.hp(c,-.2)},
      {t:'Run and leave supplies behind',d:'Lose half your food and water.',fx:c=>EVX.give(c,{food:-Math.ceil(c.food/2),water:-Math.ceil(c.water/2)})},
      {t:'Light a fire and draw them off',d:'Costs 3 spare parts. Next stage starts with an ambush.',need:c=>c.parts<3&&'Need 3 spare parts',fx:c=>EVX.give(c,{parts:-3})+'; '+EVX.next(c,{ambush:1},'an ambush at the start')}]},
 {id:'well',icon:'🪣',title:'An Old Well',w:c=>c.water<2?3:.8,text:()=>'A stone well behind a farmhouse. The rope is good. The water looks clean. Mostly.',
  ch:[{t:'Drink up and fill the bottles',d:'+3 water. 25% chance it\'s bad: next stage everyone deals 6% less damage.',fx:c=>{let L=EVX.give(c,{water:3});if(!EVX.roll(.75,c))L+='; '+EVX.next(c,{dmg:.94},'-6% damage (bad water)');return L;}},
      {t:'Boil it first (1 spare part for fuel)',d:'+2 water, no risk.',need:c=>c.parts<1&&'Need 1 spare part',fx:c=>EVX.give(c,{parts:-1,water:2})}]},
 {id:'gambler',icon:'🎲',title:'The Dice Man',w:c=>(c.s.lucky||0)>0?1.5:1,text:()=>'A man in a stained suit sits on a crate, rolling dice. "Double or nothing, friend? The dead don\'t play, so I get bored."',
  ch:[{t:'Bet 50 gold',d:'50/50: win 100 gold or lose the 50.',need:c=>c.gold<50&&'Not enough gold',fx:c=>EVX.roll(.5,c)?EVX.give(c,{gold:50}):EVX.give(c,{gold:-50})},
      {t:'Bet a Lucky Die',d:'50/50: win 2 more or lose it.',need:c=>!((c.s.lucky||0)>0)&&'No Lucky Dice',fx:c=>EVX.roll(.5,c)?EVX.give(c,{lucky:2}):EVX.give(c,{lucky:-1})},
      {t:'Pass',d:'Nothing happens.',fx:()=>'he laughs'}]},
 /* ---------- MAJOR (every 10th stage) ---------- */
 {id:'m_outpost',major:1,icon:'🏰',title:'The Outpost',w:c=>1,text:()=>'A walled-off survivor outpost. Real beds, a mess hall, guards on the wall. They\'ll let you in, but nothing\'s free.',
  ch:[{t:'Rest and resupply',d:'Everyone back to full HP, everyone fed, +3 food, +3 water.',fx:c=>EVX.hp(c,1)+'; '+EVX.feed(c,3)+'; '+EVX.give(c,{food:3,water:3})},
      {t:'Trade with their armorer (150 gold)',d:'For the rest of the run: everyone deals +8% damage.',need:c=>c.gold<150&&'Not enough gold',fx:c=>EVX.give(c,{gold:-150})+'; '+EVX.perm(c,{dmg:1.08},'+8% damage')},
      {t:'Join their supply run',d:'+25 spare parts and +2 Lucky Dice, but next stage has 30% more zombies.',fx:c=>EVX.give(c,{parts:25,lucky:2})+'; '+EVX.next(c,{foes:1.3},'30% more zombies')}]},
 {id:'m_bunker',major:1,icon:'🚪',title:'The Bunker Door',w:c=>c.has('eng')||c.has('robot')||c.has('shoshi')?2:1,text:()=>'A steel blast door in the side of a hill, with a keypad that still has power. Whatever is inside has been sealed in since day one.',
  ch:[{t:'Hack the keypad',d:'60% chance: +3 Lucky Dice and +100 gold. Otherwise the alarm brings the horde: next 2 stages have 25% more zombies.',fx:c=>{if(EVX.roll(.6+(c.has('shoshi')||c.has('eng')?.15:0),c))return 'it opens: '+EVX.give(c,{lucky:3,gold:100});c.run.evNext2={foes:1.25};return EVX.next(c,{foes:1.25},'25% more zombies (and the stage after)');}},
      {t:'Pry it open (15 spare parts)',d:'Guaranteed: +2 Lucky Dice and a Splint, Hemostat and Painkillers.',need:c=>c.parts<15&&'Need 15 spare parts',fx:c=>EVX.give(c,{parts:-15,lucky:2,med:{splint:1,hemo:1,pills:1}})},
      {t:'Leave it sealed',d:'Nothing happens.',fx:()=>'some doors stay shut'}]},
 {id:'m_hospital',major:1,icon:'🏥',title:'The Field Hospital',w:c=>c.inj||c.hurt?2.5:.8,text:()=>'Army tents with red crosses, cots in rows. Most of them are empty. The supply tent is full.',
  ch:[{t:'Heal everyone',d:'Cures every injury and everyone back to full HP.',fx:c=>{let n=0;for(const k of c.T){const H=c.run.heroes[k];if(H&&H.inj){n+=H.inj.length;H.inj=[];}}return 'cured '+n+' injur'+(n===1?'y':'ies')+'; '+EVX.hp(c,1);}},
      {t:'Raid the supply tent',d:'+2 of each medicine (Splint, Hemostat, Painkillers).',fx:c=>EVX.give(c,{med:{splint:2,hemo:2,pills:2}})},
      {t:'Take their armor vests',d:'For the rest of the run: everyone takes 6% less damage.',fx:c=>EVX.perm(c,{taken:.94},'6% less damage taken')}]},
 {id:'m_horde',major:1,icon:'☠️',title:'The Great Horde',w:c=>c.falls?.6:1.4,text:()=>'From the hilltop you see it: a river of the dead, miles long, heading straight for the place you need to go.',
  ch:[{t:'Go through them',d:'Next stage: 40% more zombies, and everyone gets double XP. For the rest of the run: +5% damage (you know how to fight a horde now).',fx:c=>EVX.next(c,{foes:1.4,xp:2},'40% more zombies, double XP')+'; '+EVX.perm(c,{dmg:1.05},'+5% damage')},
      {t:'Wait for it to pass',d:'Costs 3 food and 3 water. Next stage: 30% fewer zombies.',need:c=>(c.food<3||c.water<3)&&'Need 3 food and 3 water',fx:c=>EVX.give(c,{food:-3,water:-3})+'; '+EVX.next(c,{foes:.7},'30% fewer zombies')},
      {t:'Find another way',d:'Next stage: zombies hit 15% harder (you\'re worn out), but there are twice as many wrecks and rocks to search.',fx:c=>EVX.next(c,{zdmg:1.15,cars:2,grove:2},'zombies hit 15% harder, 2x searchable stuff')}]},
 {id:'m_convoy',major:1,icon:'🚚',title:'A Stalled Convoy',w:c=>c.city?1.6:1,text:()=>'Six military trucks, nose to tail, doors open. Bodies in uniform. Some of them are still moving.',
  ch:[{t:'Clear the convoy',d:'Everyone -25% HP. +200 gold, +20 spare parts.',fx:c=>EVX.hp(c,-.25)+'; '+EVX.give(c,{gold:200,parts:20})},
      {t:'Grab the lead truck\'s crates and go',d:'+80 gold, +8 spare parts, +2 food.',fx:c=>EVX.give(c,{gold:80,parts:8,food:2})},
      {t:'Siphon the fuel tanks',d:'For the rest of the run: camp gets +2 spare parts every time you come back... starting next camp.',fx:c=>{c.run.evPerm=c.run.evPerm||{why:[]};c.run.evPerm.partsCamp=(c.run.evPerm.partsCamp||0)+2;c.run.evPerm.why.push('+2 spare parts every camp');return 'for the rest of the run: +2 spare parts every camp';}}]},
];
function pickEvent(s,run,kind){const c=evCtx(s,run);const pool=EVENTS.filter(E=>!!E.major===(kind==='major')&&E.id!==run.lastEvent);
  const ws=pool.map(E=>Math.max(0,E.w(c)));let tot=ws.reduce((a,b)=>a+b,0),r=Math.random()*tot;for(let i=0;i<pool.length;i++){r-=ws[i];if(r<=0)return pool[i];}return pool[0];}
/* next-stage and permanent effects -> the Game */
function evMods(run){const E=(run&&run.evNext)||{},P=(run&&run.evPerm)||{};const f=k=>(E[k]||1)*(P[k]||1);
  return {foes:f('foes'),gold:f('gold'),supply:f('supply'),parts:f('parts'),cars:f('cars'),grove:f('grove'),dmg:f('dmg'),taken:f('taken'),mv:f('mv'),zspd:f('zspd'),zdmg:f('zdmg'),xp:f('xp'),en:E.en||0,ambush:E.ambush||0};}
