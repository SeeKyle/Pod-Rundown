# Ambulance = Kyle's white van with ambulance tweaks: whiter paint, red side stripe, red cross panel, roof light bar.
from PIL import Image
import colorsys,random
im=Image.open('car1_cut.png').convert('RGBA');px=im.load();W,H=im.size;rnd=random.Random(3)
def body(c):  # light bluish/grey paint (not moss, not glass, not rust)
    r,g,b,a=c
    if a<128:return False
    h,l,s=colorsys.rgb_to_hls(r/255,g/255,b/255);return (l>.36 and .5<h<.66 and s<.5) or (l>.8 and s<.4)
# 1) whiten the paint a little (keep the shading)
for y in range(H):
    for x in range(W):
        r,g,b,a=px[x,y]
        if body(px[x,y]):
            h,l,sv=colorsys.rgb_to_hls(r/255,g/255,b/255);l=min(.84,l*1.3)+rnd.uniform(-.03,.02)-.05*max(0,(y-55)/40);sv*=.4;R,G,B=colorsys.hls_to_rgb(h,l,sv);px[x,y]=(int(R*255),int(G*255),int(B*255),a)
RED=(190,44,34);REDD=(128,32,26)
def paint(x,y,c,only_body=True):
    if 0<=x<W and 0<=y<H and px[x,y][3]>128 and (not only_body or body(px[x,y])):px[x,y]=c+(255,)
# 2) red stripe along cab door + side panel, and across the front face under the hood line
for x in range(140,313):
    for y in range(59,68):
        v=rnd.randint(-20,6);b0=(156,44,34) if y<66 else (112,32,26)
        paint(x,y,rnd.choice([(118,104,90),(100,70,50)]) if rnd.random()<.08 else (b0[0]+v,b0[1]+v//2,b0[2]+v//2))
# 3) worn red crosses: dull red, chipped, grimy, rust weeping out of the chips
def cross(cx,cy,R,arm):
    for y in range(cy-R,cy+R+1):
        for x in range(cx-R,cx+R+1):
            if not(0<=x<W and 0<=y<H) or px[x,y][3]<128 or not body(px[x,y]):continue
            v=rnd.randint(-16,6)-int(10*(y-cy+R)/(2*R));px[x,y]=(196+v,194+v,184+v,255)          # dingy off-white patch
            if abs(x-cx)<=arm or abs(y-cy)<=arm:
                if (abs(x-cx)<=arm and abs(y-cy)<=R-3) or (abs(y-cy)<=arm and abs(x-cx)<=R-3):
                    v=rnd.randint(-22,8);px[x,y]=(150+v,40+v//2,32+v//2,255)
    for i in range(int(R*1.6)):                                                                  # chips + dirt flecks
        x=cx+rnd.randint(-R,R);y=cy+rnd.randint(-R,R)
        if 0<=x<W and 0<=y<H and px[x,y][3]>128 and not (px[x,y][1]>px[x,y][0]+20):px[x,y]=rnd.choice([(120,112,100),(96,84,70),(150,140,124),(110,64,36)])+(255,)
    for i in range(max(2,R//4)):                                                                 # rust weeping down
        x=cx+rnd.randint(-R,R);y=cy+rnd.randint(-R//2,R)
        for j in range(rnd.randint(2,6)):paint(x,y+j,rnd.choice([(124,66,32),(98,52,26)]),False)
cross(250,36,14,3)
# old badge painted over with neighbouring paint
for y in range(39,53):
    for x in range(262,300):
        if px[x,y][3]>128 and not body(px[x,y]):px[x,y]=px[x,36]
# a few rust flecks back over the new paint so it still reads weathered
for i in range(16):
    x=rnd.randint(140,310);y=rnd.randint(18,80)
    if body(px[x,y]):
        for j in range(rnd.randint(1,3)):paint(x,y+j,rnd.choice([(140,74,36),(110,60,30),(160,96,56)]),False)
# 4) grimy light bar: dull lenses, dirt, a cracked lens, a bit of moss on it
for y in range(6,13):
    for x in range(104,138):
        c=(150,40,32) if x<117 else (170,98,44) if x<126 else (142,38,30)
        if y==6 or y==12 or x in(104,137):c=(30,28,30)
        elif y==7:c=tuple(min(255,v+22) for v in c)
        v=rnd.randint(-22,6)+(-14 if y>=10 else 0);c=tuple(max(0,min(255,q+v)) for q in c)
        if rnd.random()<.16:c=rnd.choice([(84,74,60),(70,62,52),(104,92,72)])
        px[x,y]=c+(255,)
for x,y in ((110,8),(121,8),(131,8)):px[x,y]=(206,170,120,255)
for x,y in ((113,9),(114,10),(115,9),(116,11)):px[x,y]=(40,36,36,255)   # crack
for x in range(126,135):
    for y in range(4,7+(x%3==0)):
        if rnd.random()<.7:px[x,y]=rnd.choice([(62,86,36),(84,108,46),(52,70,30)])+(255,)
im.save('car5_cut.png')
