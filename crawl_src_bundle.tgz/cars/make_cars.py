from PIL import Image, ImageDraw
import numpy as np, json
from scipy import ndimage
# world heights: hatchback/sedan/coupe roof ~0.85 of a person (people are ~23 world px), the van ~1.15; sheet = 2 px per world px
spec=[('car_hatch',0,20),('car_van',1,24),('car_sedan',2,21),('car_coupe',3,18),('car_muscle',4,19),('car_ambulance',5,24),('car_vw',6,22)]   # 0.12.74: + Kyle's overgrown VW van
ims=[];meta={}
for name,k,wh in spec:
    im=Image.open(f'car{k}_cut.png').convert('RGBA');a=np.array(im)
    lab,n=ndimage.label(a[...,3]>0);sz=ndimage.sum(np.ones_like(lab),lab,range(1,n+1));keep=np.isin(lab,[i+1 for i,v in enumerate(sz) if v>=sz.max()*.02]);a[~keep,3]=0
    im=Image.fromarray(a).crop(Image.fromarray(a).getbbox())
    th=wh*2;tw=round(im.width*th/im.height)
    A=np.array(im).astype(float);al=A[...,3:]/255;pm=np.dstack([A[...,:3]*al,A[...,3:]])
    ch=[np.array(Image.fromarray(pm[...,i].astype(np.float32),'F').resize((tw,th),Image.LANCZOS)) for i in range(4)]
    alpha=np.clip(ch[3],0,255);rgb=np.stack(ch[:3],-1)*255/np.maximum(alpha[...,None],1)
    rgb=rgb*np.array([.82,.82,.9])   # a touch darker and cooler so they sit in the night scene
    out=np.dstack([np.clip(rgb,0,255),np.where(alpha<30,0,np.clip((alpha-30)*1.3,0,255))]).astype(np.uint8)
    if name=='car_sedan':   # 0.12.29b: settle the clean white sedan into rubble and weeds like the others
        import random;rnd=random.Random(7);o=Image.fromarray(out,'RGBA');d=ImageDraw.Draw(o);W2,H2=o.size
        for i in range(70):
            x=rnd.uniform(-2,W2+2);y=H2-rnd.uniform(0,6);r=rnd.uniform(1.2,3.2)
            col=rnd.choice([(70,58,40),(92,74,50),(58,72,36),(84,104,46),(80,96,50),(50,44,36),(62,54,44)])
            d.ellipse([x-r,y-r*.7,x+r,y+r*.7],fill=col+(255,))
        for i in range(7):
            x=rnd.uniform(4,W2-4);h_=rnd.uniform(2,6);d.line([(x,H2-1),(x+rnd.uniform(-1.5,1.5),H2-1-h_)],fill=rnd.choice([(70,90,40),(88,108,50)])+(255,),width=1)
        out=np.array(o)
    ims.append((name,Image.fromarray(out,'RGBA')))
W=sum(i.width+2 for _,i in ims);H=max(i.height for _,i in ims);S=Image.new('RGBA',(W,H));x=0
for name,i in ims:
    S.alpha_composite(i,(x,H-i.height));a=np.array(i)[...,3]>0;h=i.height;rows=a[int(h*.72):]
    cols=np.where(rows.any(0))[0];cx=i.width/2;sp=[round((cols.min()-cx)/2*.92,1),round((cols.max()+1-cx)/2*.92,1)]
    meta[name]=dict(x=x,y=H-i.height,fw=i.width,fh=i.height,lanes=2,blk=round(h*.8),foot=[sp,sp],img='cars');x+=i.width+2
S.save('/home/claude/pod2/crawl_cars.png',optimize=True);json.dump(meta,open('cars.json','w'));print(meta)
bg=Image.new('RGBA',S.size,(30,26,38,255));bg.alpha_composite(S);bg.resize((S.width*3,S.height*3),Image.NEAREST).save('/tmp/carsheet.png')
