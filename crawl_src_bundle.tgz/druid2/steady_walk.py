# 0.12.50 (Kyle): smoother Druid walk. Lines every walk frame up on her torso (rows 14-36) so the body glides instead of hopping
# side to side; the legs and staff still move. Run after frames.py rebuilds crawl_druid.png.
import numpy as np
from PIL import Image
P='/home/claude/pod2/crawl_druid.png';FW,FH,N=64,56,8
im=Image.open(P).convert('RGBA');A=np.array(im);cx=[]
for i in range(N):
    al=A[0:FH,i*FW:(i+1)*FW,3]>0;ys,xs=np.nonzero(al);m=(ys>=14)&(ys<=36);cx.append(xs[m].mean())
ref=float(np.median(cx))
for i in range(N):
    d=int(round(ref-cx[i]));fr=A[0:FH,i*FW:(i+1)*FW].copy();A[0:FH,i*FW:(i+1)*FW]=np.roll(fr,d,axis=1)
Image.fromarray(A).save(P,optimize=True);print('shifts',[int(round(ref-c)) for c in cx])
