from PIL import Image
import numpy as np
S=np.array(Image.open('druid_orig.png').convert('RGBA'))
F0=S[:,0:64].copy();H,W=56,64
ys,xs=np.mgrid[0:H,0:W]
r,g,b,a=[F0[...,i].astype(int) for i in range(4)]
brown=(r>g+25)&(r>100)&(a>0)
dark=(a>0)&(r+g+b<190)
near_brown=np.zeros_like(brown)
for dy in(-1,0,1):
    for dx in(-1,0,1):near_brown|=np.roll(np.roll(brown,dy,0),dx,1)
skin=(g>140)&(b>120)
staff=(a>0)&(((xs<=28)&(brown|(dark&near_brown)))|((xs<=25)&~skin))&~((ys>=25)&(ys<=29)&(xs>=21))|((a>0)&(xs<=31)&(ys>=34)&brown)   # keep the hand with the arm (0.12.58: catch the staff's darker pixels too)
upper=(a>0)&~staff&(ys<=35)
lower=(a>0)&~staff&(ys>35)
hair=upper&(xs>=39)&(ys>=14)&(g>r)
def put(dst,src,mask,dx=0,dy=0):
    yy,xx=np.where(mask);ty,tx=yy+dy,xx+dx;ok=(ty>=0)&(ty<H)&(tx>=0)&(tx<W);dst[ty[ok],tx[ok]]=src[yy[ok],xx[ok]]
import math
SL=np.zeros_like(F0);SL[staff]=F0[staff];SLI=Image.fromarray(SL,'RGBA')
def staffT(dst,k=0,dy=0,dx=0,piv=27):
    ang=math.degrees(math.atan(k))   # +k leans the top back (right)
    if abs(ang)<1e-6:R=np.array(SLI)
    else:   # 0.12.58: rotate at 4x and pool back down so a thin tilted staff stays solid instead of breaking into dots
        Q=4;big=SLI.resize((W*Q,H*Q),Image.NEAREST).rotate(ang,resample=Image.NEAREST,center=(23*Q+Q/2,piv*Q+Q/2));B=np.array(big).reshape(H,Q,W,Q,4).transpose(0,2,1,3,4).reshape(H,W,Q*Q,4)
        cnt=(B[...,3]>0).sum(2);R=np.zeros((H,W,4),np.uint8)
        for y,x in zip(*np.nonzero(cnt>=4)):
            px=B[y,x][B[y,x,:,3]>0];v,c=np.unique(px.reshape(-1,4),axis=0,return_counts=True);R[y,x]=v[c.argmax()]
    m=R[...,3]>0;yy,xx=np.where(m);ny,nx=yy+dy,xx+dx;ok=(ny>=0)&(ny<H)&(nx>=0)&(nx<W);dst[ny[ok],nx[ok]]=R[yy[ok],xx[ok]]
GLOW=[(170,255,150,255),(225,255,205,255),(90,220,110,255)]
def dot(dst,x,y,c):
    if 0<=x<W and 0<=y<H:dst[y,x]=c
def tip(dst,k=0,dy=0,size=1):
    yy,xx=np.where(staff);i=np.argmin(yy);x0,y0=xx[i]-23,yy[i]-27;an=math.atan(k);x=int(round(23+x0*math.cos(an)+y0*math.sin(an)));y=int(round(27-x0*math.sin(an)+y0*math.cos(an)))+dy
    if size>=1:dot(dst,x,y-1,GLOW[1]);dot(dst,x+1,y,GLOW[0])
    if size>=2:
        for (ox,oy) in [(-1,-1),(1,-1),(0,-2),(-1,0),(2,0),(0,1)]:dot(dst,x+ox,y+oy,GLOW[0])
        dot(dst,x,y,GLOW[1]);dot(dst,x,y-1,(255,255,240,255))
def frame(up_dx=0,up_dy=0,k=0,sdy=0,hair_dx=0,tipsz=0,handglow=False):
    D=np.zeros_like(F0)
    put(D,F0,lower)
    put(D,F0,upper&~hair,up_dx,up_dy);put(D,F0,hair,up_dx+hair_dx,up_dy)
    staffT(D,k,sdy+up_dy,up_dx)
    if tipsz:tip(D,k,sdy+up_dy,tipsz)
    if handglow:
        for (x,y) in [(20,26),(19,27),(20,28),(21,25),(18,26)]:dot(D,x+up_dx,y+up_dy,GLOW[0])
        dot(D,19+up_dx,26+up_dy,GLOW[1])
    return D
rows={
 'walk':[S[:,i*64:(i+1)*64] for i in range(8)],
 'idle':[frame(0,0),frame(0,0,hair_dx=1),frame(0,1,hair_dx=1,tipsz=1),frame(0,1,hair_dx=0,tipsz=1),frame(0,1,hair_dx=-0),frame(0,0,hair_dx=0)],
 'melee':[frame(1,0,hair_dx=1),frame(-2,0,hair_dx=-1,handglow=True),frame(-1,0,handglow=True)],
 'ranged':[frame(1,0,k=-.45,tipsz=1,hair_dx=1),frame(-1,0,k=.45,tipsz=2),frame(-2,0,k=1.0,tipsz=2,hair_dx=-1),frame(-1,0,k=.4,tipsz=1)],   # 0.12.58 (Kyle): wind the staff back, swing it forward, thrust; the bolt leaves the staff head on frame 3
 'hurt':[frame(2,0,hair_dx=1),frame(1,0,)],
 'death':[S[:,0:64]],
}
out=Image.new('RGBA',(64*8,56*len(rows)));meta={};
for ri,(n,fs) in enumerate(rows.items()):
    for i,f in enumerate(fs):out.alpha_composite(Image.fromarray(f.astype(np.uint8),'RGBA'),(i*64,ri*56))
    meta[n]=dict(n=len(fs),y=ri*56)
out.save('/home/claude/pod2/crawl_druid.png',optimize=True)
import json;print(json.dumps(meta))
bg=Image.new('RGBA',out.size,(40,40,50,255));bg.alpha_composite(out);bg.resize((out.width*3,out.height*3),Image.NEAREST).save('/tmp/druidsheet.png')
