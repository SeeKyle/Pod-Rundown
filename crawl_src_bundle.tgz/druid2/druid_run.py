# 0.12.58 (Kyle): the Druid gets a real run row: each walk frame with a longer stride (legs stretched out from the hips),
# body leaning forward 2px, and a bounce on every other frame. Appended under the other rows of crawl_druid.png (row 7, y=336).
import numpy as np
from PIL import Image
P='/home/claude/pod2/crawl_druid.png';FW,FH,N=64,56,8
A=np.array(Image.open(P).convert('RGBA'))
H0=A.shape[0];out=np.zeros((max(H0,FH*7),A.shape[1],4),np.uint8);out[:H0]=A[:max(H0,FH*7)][:H0]
for i in range(N):
    fr=A[0:FH,i*FW:(i+1)*FW].copy();al=fr[...,3]>0;ys,xs=np.nonzero(al);hx=int(round(xs[(ys>=30)&(ys<=36)].mean()))
    new=np.zeros_like(fr)
    up=fr.copy();up[36:]=0;new_up=np.roll(up,-2,axis=1)
    lo=fr.copy();lo[:36]=0
    for y in range(36,FH):
        for x in range(FW):
            sx=hx+(x-hx)/1.35;x0=int(round(sx))
            if 0<=x0<FW and lo[y,x0,3]>0:new[y,x]=lo[y,x0]
    m=new_up[...,3]>0;new[m]=new_up[m]
    if i%2==1:new=np.roll(new,-1,axis=0)
    out[FH*6:FH*7,i*FW:(i+1)*FW]=new
Image.fromarray(out).save(P,optimize=True)
bg=Image.new('RGBA',(FW*N,FH*2),(40,40,50,255));bg.alpha_composite(Image.fromarray(np.concatenate([out[FH*3:FH*4],out[FH*6:FH*7]],0)));bg.resize((bg.width*3,bg.height*3),Image.NEAREST).save('/tmp/druidrun.png')
