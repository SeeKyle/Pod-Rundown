# Pod Rundown + Crypt Crawl: project handoff (as of v0.11.0)

Paste this whole file into the new chat and attach **Pod_Rundown_0.11.0.zip**. The zip is the full project, source code included. Everything below explains where things stand.

## 1. What the project is
- **Pod Rundown** is Kyle's website rating his Commander pod's decks (the pod is called "Dice Boys": Kyle, Cheez, and Kyle's son Leon).
  - Live site: https://seekyle.github.io/Pod-Rundown/
  - GitHub repo: SeeKyle/Pod-Rundown (published from branch `main` with GitHub Pages)
- **Crypt Crawl** is the side-scrolling auto-battler on the site. Heroes are based on the pod's decks. Players only pick the team, upgrades and loot, and can pause or change speed; all fighting is automatic.
- The site also has a **life tracker** (sideways and full-screen on phones, with retro status-bar faces on a sprite sheet).

## 2. Standing rules from Kyle
- After every update: publish to GitHub Pages, send the new zip, and include the site link with the update notes.
- Bump the version label each time. It appears in two places: the game's top bar (`crawl_ui.js`) and the cache-buster `crawl.js?v=...` in `index.html` and `template.html`.
- Don't ask questions to get started on a request; do your best, then list questions afterwards.
- Never draw likenesses of copyrighted or protected characters (commanders, Joel/Ellie, the original status-bar faces, etc.). Original art only. Images Kyle supplies (card back, faces sheet, sprite packs) are used as given.
- Kyle balances the game himself. Use his numbers exactly as he gives them, even when simulations show the game is hard.
- Make Crypt Crawl changes live by default unless he says "just show me first".

## 3. Where Crypt Crawl stands now (v0.11.0)
Kyle is rebuilding the game from the ground up. The old animation overhaul was rolled back, the old enemy roster and all abilities were removed, and new pieces are added one at a time.

**World**
- 3 biomes × 5 stages each, with a boss on stages 5, 10 and 15. Stage 15 is the end, then Prestige.
- Stages are 25% shorter than the old ones. The difficulty curve is stretched over the 15 stages.
- Backdrops are Ansimuz art packs that Kyle bought (license: may be used and edited, the raw assets may not be redistributed). Each is layered with parallax and has a tall gradient night sky with stars above it:
  1. **Blackwater Lake:** cabin and pine woods. The lake was replaced by a dirt trail with bones and a skull.
  2. **Hollowmere Cemetery:** a grave-dirt path in front of the fence, with a different bone layout (crossed bones, half-buried ribcage, a hand).
  3. **The Cathedral Corridor:** arches with a widened stone floor and blood splatters (no bones).
- The backdrop art is drawn at 0.75 scale. Source layers are in `50_Code/assets/biome*`.
- **Five lanes** (feet rows 188, 194, 200, 206, 212). Units drift between lanes, and every unit can stack on and walk through every other unit (a future "block" ability could turn that off per unit).
- **All units are drawn at half size** (`UNIT_SCALE = 0.5`). The werewolf is drawn at 0.6 of its earlier size. The werewolf leap distance was deliberately kept at 20 px.
- **Enemy density** starts at about 30% of the old rate and ramps to about 1.7× by the end of each stage.
- **Stage end:** after the last kill (or the boss dying), the heroes walk off the right edge and pick up any dropped loot on the way, then the "Stage Clear" screen appears.

**Enemies** (all on Kyle's small-number scale)
- **Zombie**, three looks with identical stats: a male in a blue shirt, a brunette with long hair, and a blonde with a purple top. All three have dripping blood.
  - 15 HP, 1d6 damage, attacks every 1.25 s, reach 12 + 9 body width, very slow (speed 8)
  - Armor 3, knockback resistance 0.35
  - 25% chance on hit to cause Bleed: 20 damage over 5 s, ignores armor, refreshes rather than stacking, shown as pulsing red rings and drips
  - Drops: item 4%, 2–5 gold 17.5%
  - Behavior: targets the closest hero in its own lane. Each second while more than 50 px from the front hero there's a 10% chance it drifts to a neighboring lane. It has a 2% per-second chance to switch to a closer hero.
- **Werewolf**, the first fast enemy (from a pack Kyle supplied; dark tattered shorts):
  - Zombie stats except 40 HP and speed 40
  - Hunts the back-line hero
  - Leap attack: jumps a 20 px gap for 10 damage, 8 s cooldown
  - Set count per stage: 1, 1, 2, 2, 3, then slowly more (cap 6), spawning between about 15% and 55% of the way through each stage
  - Uses the pack's run, attack, jump/fall and knockout frames
- **Bosses:** the old Gravelord, Crimson Countess and Maw are temporary placeholders at their original numbers. They keep only their basic attack, and they summon zombies.

**Heroes** (still the old deck-based sprites; Kyle plans to replace them with new sprites and his own stats)
- Max HP = Flat Health (0) + Stamina × 5. Stamina = the deck's land count ÷ 3, rounded up, so most heroes have 55–65 HP.
- Basic attack: 2d4. Base crit chance 10% for every hero (crit = ×1.75). Accuracy starts at 0.
- **All abilities are switched off** (spells, passives, signature moves, item procs, level-up picks) via `ABILITIES_OFF = true`. Items still give stat bonuses.
- Melee heroes hold a forward line (46% of the screen width) and press up to 28 px into nearby foes. Melee only hits enemies in its own lane and steps a lane toward the nearest foe. Ranged heroes shoot into any lane.

**Armor rule (Kyle's):**
- Each point from 1–20 reduces damage by 2%, each point from 21–40 by 1%, and each point from 41 up by 0.5%.
- Capped at 90%, which is reached at 100 armor.

**Aiming and hitboxes (0.11.0)**
- Every non-boss unit has a hitbox about its size (ruler units = full-size sprite pixels): zombie 16 × 46, werewolf 30 × 30, heroes 20 × 46 by default (`HERO_HITBOX`, per-hero overrides in `HERO_HB`). Across the lanes a body fills `depthHalf` = max(1.5, 0.12 × width) px either side of its feet.
- **Reticle (Kyle's design):** when a ranged unit (hero or non-boss enemy) fires, a shoot box is laid over the target where it stands. It is 3× the target's height. Its bottom sits at the feet (0.125 h) when close (≤40 px), the waist (0.5 h) at medium range and the chest (0.75 h) when far (≥170 px). Heights inside it are rolled as bottom + span × r^4 (`AIM_SHAPE.bunch`), so most shots land near the bottom. Side to side it is centred on the target, ±1 target width, bell-shaped. Accuracy shrinks both.
- Hit chance at 0 accuracy is about 63% close, 56% medium and 46% far (the werewolf up close went from about 34% to 63%; zombies at medium range went from about 90% to 56%). Tuning knobs: `AIM_RANGE`, `AIM_POINTS`, `AIM_SHAPE`.
- Shots fly in either direction and hit the first hitbox they pass through. `pierce` (style or enemy def) lets a shot go through extra bodies; nothing uses it yet. Enemy shots at heroes use the same reticle against hero hitboxes. Bosses still use the old height table.
- Fliers (none exist yet) keep their separate tighter table.

**Facing:** heroes and regular enemies turn around (`faceToward`, 0.22 s, no attacks mid-turn) only when the target is behind them. Lane walkers approach from whichever side they're on and must face the hero and be within reach for a blow to land. Back-line hunters (werewolf) switch to the nearest hero once the back line is gone. Knockback pushes away from the attacker.

**Energy:** every unit has 100 energy, refilling 10/s (`ENERGY.max` / `ENERGY.regen` are functions so they can become formulas). `spendEnergy(unit, cost)` is ready for abilities.

**Unit UI:** framed health bar with a tick every 10 HP, a yellow energy bar under heroes' health, and status pips (bleed, burn, slow, stun, shield, buff).

**Effects:** every damaging hit throws a blood spray away from the blow, with drops that land and fade on the ground.

**Ideas that were tried and dropped:**
- The v2 animation overhaul (it looked jittery). It is backed up at `/home/claude/pod2_v046` in the old workspace only.
- Custom podmate faces for the life tracker (couldn't match the original style closely enough).
- A naked zombie variant (declined).

**What Kyle plans next:** find sprite packs for new heroes, define the heroes' base abilities and stats, build abilities from scratch, then more enemy types. He also sketched a top-down view of the lane "bumpers" (lane borders at rows 191, 197, 203 and 209; edges at 185 and 215) for an upcoming design idea.

## 4. Code map (inside the zip, under 50_Code/)
- `crawl_src.js`: game engine (config, stages, enemies, lanes, aiming, combat).
- `crawl_ui.js`: rendering and menus.
- `build_crawl.py`: builds `crawl.js` from the source files plus the JSON data.
- `build_site.py`: builds `index.html` from `template.html`.
  - Note: rebuilding the site data can come out different from the live site. When only the game changed, the safe path is to copy the published `index.html` and edit just the `crawl.js?v=` version.
- `make_units.py`: packs the new unit sprites (`assets/enemies/*`) into `crawl_units.png` and atlas["units"].
- `make_crawl_bg2.py`: packs the backdrop layers into `crawl_bg.png` and atlas["bg"].
- `add_lands.py`: writes each deck's land count into `battler_data.json`, which drives Stamina.
- `make_zip.py <version>`: builds the zip.
- Publishing: copy `index.html`, `crawl.js`, `crawl.png`, `crawl_bg.png`, `crawl_units.png`, `card-back.jpg` and `faces.png` into the repo clone, then commit and push to `main`.
