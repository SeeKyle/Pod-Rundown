POD RUNDOWN 0.11.0 - READ ME FIRST
=================================================
Read and process these files in number order:

  00_READ_ME_FIRST.txt                  this file: the order, and the rules for using the files
  01_Overview_and_Workflow.txt          how scoring fits together, and the steps for adding a new deck
  02_Mana.txt ... 10_Politics.txt       one file per stat: what counts, the exact formulas, tagging notes,
                                        automatic card rules and deck-level checks for that stat
  11_Ratings_Groups_and_Repair.txt      points -> ratings, divides, groups, total, salt, Plan Tag bonus, Needs Repair
  12_Plan_Tags_and_Synergy.txt          every deck's Plan Tag rules (C/T) and synergy groups
  20+_Deck_*.txt                        one file per deck, best total first. Each has: deck header (ratings, points,
                                        deck-level checks), the site takeaway text, then every card with
                                          Card name
                                            INFO / ROLE / NOTE / TAGS / TOTAL   (the info and tags I built)
                                            CARD TEXT                           (the full official card text, no flavor)
  50_Code/                              the scoring engine (Python) and data files that build the website.
                                        Not numbered on purpose: the code imports them by name.

RULES FOR NEXT TIME
  - Card text: every card already has its full text in its deck file (and in 50_Code/card_text.json).
    Do NOT look card text up on the internet again for these cards. Only look up a card that isn't saved yet.
  - Tags are written as the formula calls (TAGS line), so a rule change = edit the formula and re-run.
  - Plan Tags (C = works with the commander, T = fits the deck plan) are shown on each card's ROLE line.
