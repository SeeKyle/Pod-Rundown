import os, shutil, subprocess, sys
V = sys.argv[1]
base = '/tmp/claude-0/zipout'; D = f'{base}/Pod_Rundown_{V}'
shutil.rmtree(base, ignore_errors=True); os.makedirs(D + '/50_Code/decks')
subprocess.run(['python3', 'make_docs.py', D, V], check=True, stdout=subprocess.DEVNULL)
import rules_docs
rules_docs.write(D, V)
open(f'{D}/00_READ_ME_FIRST.txt', 'w').write(f"""POD RUNDOWN {V} - READ ME FIRST
=================================================
Read and process these files in number order:

  00_READ_ME_FIRST.txt                  this file: the order, and the rules for using the files
  01_Overview_and_Workflow.txt          how scoring fits together, and the steps for adding a new deck
  02_Mana.txt ... 10_Politics.txt       one file per stat: what counts, the exact formulas, tagging notes,
                                        automatic card rules and deck-level checks for that stat
  11_Ratings_Groups_and_Repair.txt      points -> ratings, divides, groups, total, salt, Plan Tag bonus, Needs Repair
  12_Plan_Tags_and_Synergy.txt          every deck's Plan Tag rules (C/T) and synergy groups
  20+_Deck_*.txt                        one file per deck, best total first. Each has: deck header (ratings, points,
                                        deck-level checks), the site takeaway text, then every card with
                                          Card name
                                            INFO / ROLE / NOTE / TAGS / TOTAL   (the info and tags I built)
                                            CARD TEXT                           (the full official card text, no flavor)
  50_Code/                              the scoring engine (Python) and data files that build the website.
                                        Not numbered on purpose: the code imports them by name.

RULES FOR NEXT TIME
  - Card text: every card already has its full text in its deck file (and in 50_Code/card_text.json).
    Do NOT look card text up on the internet again for these cards. Only look up a card that isn't saved yet.
  - Tags are written as the formula calls (TAGS line), so a rule change = edit the formula and re-run.
  - Plan Tags (C = works with the commander, T = fits the deck plan) are shown on each card's ROLE line.
""")
for f in ['formulas', 'score', 'build_data', 'build_site', 'make_docs', 'make_zip', 'plan_tags', 'judge', 'takeaways_text', 'addtag', 'rules_docs', 'make_skull', 'make_bonepile', 'make_deaths', 'make_sky', 'stat_page', 'sim_data', 'story_kit', 'pod_outcomes', 'battler_data', 'rig', 'make_crawl_art', 'make_crawl_bg2', 'build_crawl', 'add_lands', 'make_units', 'make_crawl_bg2']:
    shutil.copy(f + '.py', f'{D}/50_Code/')
for f in os.listdir('decks'):
    if f.endswith('.py'): shutil.copy('decks/' + f, f'{D}/50_Code/decks/')
for f in ['card_text.json', 'inclusion.json', 'pt.json', 'raw_lists.json', 'fetch_order.json', 'all_names.json', 'card_info.txt', 'template.html', 'notes.html', 'pod_outcomes.json', 'sim_engine.js', 'sim_run_all.js', 'piss-boy.jpg', 'treasure.jpg', 'card-back.jpg', 'faces.png', 'battler_data.json', 'crawl_atlas.json', 'crawl_src.js', 'crawl_ui.js', 'crawl.js', 'crawl.png', 'crawl_bg.png', 'crawl_units.png']:
    shutil.copy(f, f'{D}/50_Code/')
shutil.copytree('assets', f'{D}/50_Code/assets')
shutil.copy('CRYPT_CRAWL_HANDOFF.md', f'{D}/')   # backdrop layers (Ansimuz packs + our edited paths)
subprocess.run(['zip', '-qr', f'Pod_Rundown_{V}.zip', f'Pod_Rundown_{V}'], cwd=base, check=True)
print(f'{base}/Pod_Rundown_{V}.zip')
