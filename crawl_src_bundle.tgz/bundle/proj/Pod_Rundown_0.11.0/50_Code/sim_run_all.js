const fs=require('fs');
let eng=fs.readFileSync('/tmp/claude-0/engine.js','utf8');
eng=eng.replace("const SIM=JSON.parse(document.getElementById('sim-data').textContent);","const SIM=JSON.parse(fs.readFileSync('/tmp/claude-0/simdata.json','utf8'));");
eng=eng.replace("if(k)k.kills++;o.bf=[];","if(k)k.kills++;o.bf=[];o.koT=t;o.koBy=k?k.name:null;");
eng=eng.replace("o.life=0;cmdKO=true;","o.life=0;cmdKO=true;o.cmdKO=1;");
if(!eng.includes('o.koT=t')||!eng.includes('o.cmdKO=1'))throw 'patch';
eval(eng+";global.runSim=runSim;global.shuf=shuf;");
const D=JSON.parse(fs.readFileSync('/tmp/claude-0/decks.json','utf8'));const names=D.map(d=>d.deck).sort();
const G=+process.argv[2]||60;const out={};let games=0;const t0=Date.now();
for(let a=0;a<18;a++)for(let b=a+1;b<18;b++)for(let c=b+1;c<18;c++)for(let d=c+1;d<18;d++){
  const pod=[a,b,c,d];const rows=pod.map(i=>D.find(x=>x.deck===names[i]));const sig={};
  for(let g=0;g<G;g++){const res=runSim(shuf([...rows]),false);games++;
    const order=[...res.P].sort((x,y)=>x.out-y.out); // 1st..4th
    const w=names.indexOf(res.win.name);
    const dead=order.slice(1).reverse(); // first knocked out first
    const key=w+':'+dead.map(p=>names.indexOf(p.name)).join(',');
    const s=sig[key]||(sig[key]={n:0,turns:[],kb:dead.map(()=>({})),cmd:0,time:0,koT:dead.map(()=>[])});
    s.n++;s.turns.push(res.turn);if(/TIME/.test(res.ending))s.time++;
    dead.forEach((p,i)=>{const k=p.koBy?names.indexOf(p.koBy):-1;s.kb[i][k]=(s.kb[i][k]||0)+1;if(p.koT)s.koT[i].push(p.koT);if(p.cmdKO)s.cmd++;});}
  const ent=Object.entries(sig).sort((x,y)=>y[1].n-x[1].n);const keep=new Set(ent.slice(0,8).map(x=>x[0]));
  const perW={};ent.forEach(([k])=>{const w=k.split(':')[0];perW[w]=(perW[w]||0)+1;if(perW[w]<=2)keep.add(k);});
  const wins={};ent.forEach(([k,s])=>{const w=k.split(':')[0];wins[w]=(wins[w]||0)+s.n;});
  const top=ent.filter(([k])=>keep.has(k)).map(([k,s])=>{
    const [w,d]=k.split(':');const med=a=>a.length?a.sort((x,y)=>x-y)[a.length>>1]:0;
    return [ +w, d.split(',').map(Number), s.kb.map(m=>+Object.entries(m).sort((x,y)=>y[1]-x[1])[0][0]), med(s.turns), s.koT.map(med), s.n, s.cmd?1:0, s.time*2>s.n?1:0 ];});
  out[pod.join(',')]={o:top,w:wins};}
fs.writeFileSync('/tmp/claude-0/outcomes.json',JSON.stringify({names,G,games,pods:out}));
console.log('games',games,'secs',(Date.now()-t0)/1000);
