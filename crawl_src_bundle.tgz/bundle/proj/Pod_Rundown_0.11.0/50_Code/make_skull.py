"""Pixel skull & crossbones for the life tracker's 0-life face, drawn at 24x30 and doubled like the status-bar sprites."""
from PIL import Image
import numpy as np, random
random.seed(7)
W,H=24,30
img=np.zeros((H,W,4),np.uint8)
PAL={'K':(36,18,8),'D':(122,98,62),'M':(176,150,104),'L':(222,204,160),'W':(250,240,212),'E':(14,6,4),'R':(170,16,16),'r':(96,8,8)}
grid=[[None]*W for _ in range(H)]
def inside_skull(x,y):
    cx,cy=11.5,9.5
    if ((x-cx)/9.6)**2+((y-cy)/9.2)**2<=1 and y<=15: return True
    if 6<=x<=17 and 14<=y<=20: return True    # jaw
    return False
# crossbones (behind the skull): two thick diagonals with knobby ends
def bone(x,y):
    for (x0,y0,x1,y1) in [(2,17,21,28),(21,17,2,28)]:
        t=max(0,min(1,((x-x0)*(x1-x0)+(y-y0)*(y1-y0))/((x1-x0)**2+(y1-y0)**2)))
        px,py=x0+t*(x1-x0),y0+t*(y1-y0)
        if (x-px)**2+(y-py)**2<=1.6: return True
    for (kx,ky) in [(2,16),(1,18),(3,18),(22,16),(21,18),(23,18) ,(1,28),(2,29),(3,27),(22,28),(21,29),(20,27)]:
        if (x-kx)**2+(y-ky)**2<=1.3: return True
    return False
for y in range(H):
    for x in range(W):
        s=inside_skull(x,y)
        if s or bone(x,y):
            # light from the top-left, banded like the sprites, with a little dither
            v=(x*0.55+y*0.75)/(W*0.55+H*0.75)+random.uniform(-.06,.06)
            if not s: v+=0.15
            grid[y][x]='W' if v<.18 else 'L' if v<.38 else 'M' if v<.58 else 'D'
# eye sockets, nose, teeth
for y in range(H):
    for x in range(W):
        if grid[y][x] is None: continue
        if ((x-7.5)/2.6)**2+((y-10.5)/2.4)**2<=1 or ((x-15.5)/2.6)**2+((y-10.5)/2.4)**2<=1: grid[y][x]='E'
        if 11<=x<=12 and 13<=y<=14: grid[y][x]='E'
        if y==14 and x in (10,13): grid[y][x]='E'
        if 17<=y<=18 and 7<=x<=16 and x%2==1: grid[y][x]='K'
        if y==16 and 7<=x<=16: grid[y][x]='D' if x%2 else 'L'
        if y==19 and 7<=x<=16: grid[y][x]='D'
# blood: from the left socket and the crown, like the bloody faces
for (x,y) in [(6,13),(6,14),(7,13),(6,15),(5,16),(16,13),(16,14),(17,15),(9,2),(9,3),(10,3),(10,4),(14,3),(14,4),(15,5)]:
    if grid[y][x] and grid[y][x]!='E': grid[y][x]='R' if (x+y)%3 else 'r'
# outline
out=[row[:] for row in grid]
for y in range(H):
    for x in range(W):
        if grid[y][x] and grid[y][x]!='E':
            for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)):
                nx,ny=x+dx,y+dy
                if not(0<=nx<W and 0<=ny<H) or grid[ny][nx] is None: out[y][x]='K';break
for y in range(H):
    for x in range(W):
        c=out[y][x]
        if c: img[y,x]=(*PAL[c],255)
im=Image.fromarray(img).resize((W*2,H*2),Image.NEAREST)
im.save('skull_face.png')
