"""Assemble crawl.js from crawl_src.js + crawl_ui.js + data/atlas JSON."""
import json, os
src = open('/home/claude/pod2/crawl_src.js').read()
ui = open('/home/claude/pod2/crawl_ui.js').read() if os.path.exists('/home/claude/pod2/crawl_ui.js') else ''
d = json.load(open('/home/claude/pod2/battler_data.json')); a = json.load(open('/home/claude/pod2/crawl_atlas.json'))
src = src.replace('__CRAWLDATA__', json.dumps(d, ensure_ascii=False, separators=(',', ':'))).replace('__CRAWLATLAS__', json.dumps(a, separators=(',', ':')))
import time
src = src.replace('/*__CRAWLUI__*/', ui).replace('__VER__', str(int(time.time())))
open('/home/claude/pod2/crawl.js', 'w').write(src)
print('crawl.js', len(src))
