"""Packs the hand-picked unit sprites (assets/enemies/*) into crawl_units.png and writes atlas['units'].
Every animation is stored facing LEFT (toward the heroes). Anchor = feet centre / ground line of frame 0 of each animation."""
import json, numpy as np
from PIL import Image
A='/home/claude/pod2/assets/enemies/'
# per unit: animation -> (file, frame width, flip-to-face-left, optional crop box (x0,y0,x1,y1) applied to every frame)
WOLF_CROP=(10,4,122,80)
UNITS={
 'zombie':  dict(walk=('zombie_walk_sheet.png',32,False,None),atk=('zombie_atk_sheet.png',64,True,None)),
 'zombie_f':dict(walk=('zombie_f_walk_sheet.png',32,False,None),atk=('zombie_f_atk_sheet.png',64,True,None)),
 'zombie_b':dict(walk=('zombie_b_walk_sheet.png',32,False,None),atk=('zombie_b_atk_sheet.png',64,True,None)),
 'werewolf':dict(walk=('run_sheet.png',128,True,WOLF_CROP),atk=('attack_sheet.png',128,True,WOLF_CROP),die=('ko_sheet.png',128,True,WOLF_CROP),jump=('jump_sheet.png',128,True,WOLF_CROP),fall=('fall_sheet.png',128,True,WOLF_CROP)),
}
DIRS={'zombie':'zombie','zombie_f':'zombie_f','zombie_b':'zombie_b','werewolf':'werewolf'}
sheets=[];meta={}
for k,anims in UNITS.items():
    meta[k]={}
    for an,(f,fw,flip,crop) in anims.items():
        im=Image.open(A+DIRS[k]+'/'+f).convert('RGBA');n=im.width//fw
        frs=[im.crop((i*fw,0,(i+1)*fw,im.height)) for i in range(n)]
        if crop: frs=[fr.crop(crop) for fr in frs]
        if flip: frs=[fr.transpose(Image.FLIP_LEFT_RIGHT) for fr in frs]
        a=np.array(frs[0])[...,3]>0;ys=np.where(a.any(1))[0];bot=ys.max()
        legs=np.where(a[max(0,bot-14):bot+1])[1];ax=int(np.median(legs))
        sheets.append((k,an,frs));meta[k][an]=dict(fw=frs[0].width,fh=frs[0].height,n=n,ax=ax,ay=int(bot))
W=sum(sum(fr.width for fr in frs) for _,_,frs in sheets);H=max(frs[0].height for _,_,frs in sheets)
x=0;out=Image.new('RGBA',(W,H))
for k,an,frs in sheets:
    meta[k][an]['x']=x;meta[k][an]['y']=0
    for fr in frs: out.alpha_composite(fr,(x,0));x+=fr.width
out.save('/home/claude/pod2/crawl_units.png',optimize=True)
a=json.load(open('/home/claude/pod2/crawl_atlas.json'));a['units']=meta;json.dump(a,open('/home/claude/pod2/crawl_atlas.json','w'))
print(out.size,{k:{a:(v['n'],v['ax'],v['ay']) for a,v in m.items()} for k,m in meta.items()})
