"""Writes each hero's land count (from its decklist) into battler_data.json -> Stamina = ceil(lands/3), 5 HP per point."""
import json
r=json.load(open('/home/claude/pod2/raw_lists.json'));ct=json.load(open('/home/claude/pod2/card_text.json'))
FILES={}
import glob,re
for f in glob.glob('/home/claude/pod2/decks/*.py'):
    t=open(f).read();m=re.search(r"file='([^']+)', deck=(['\"])(.+?)\2",t)
    if m: FILES[m.group(3)]=m.group(1)
def is_land(n):
    t=ct.get(n) or ct.get(n.split(' // ')[0]) or '';ls=t.split('\n');return len(ls)>1 and 'Land' in ls[1].split('—')[0]
d=json.load(open('/home/claude/pod2/battler_data.json'))
for h in d['heroes']: h['lands']=sum(c['q'] for c in r[FILES[h['deck']]] if is_land(c['name']))
json.dump(d,open('/home/claude/pod2/battler_data.json','w'),ensure_ascii=False)
print({h['key']:h['lands'] for h in d['heroes']})
