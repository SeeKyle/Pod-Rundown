"""Crypt Crawl art v2: detailed shaded pixel heroes / enemies / bosses / gothic backdrops (rendered with rig.py)."""
import numpy as np, math, json, random, sys
sys.path.insert(0, '/home/claude/pod2')
import rig
from rig import Canvas, Mat, outline_sel, quantize, K, hx
from PIL import Image
R = math.radians
def P(o, L, a): return (o[0] + L * math.sin(R(a)), o[1] + L * math.cos(R(a)))

M = {  # shared materials
 'steel': Mat('#9aa4b4', 'metal'), 'dsteel': Mat('#5a6070', 'metal'), 'iron': Mat('#3a3e48', 'metal'),
 'gold': Mat('#d9a836', 'gold'), 'bronze': Mat('#a8703a', 'gold'),
 'bone': Mat('#efe4c8', 'bone'), 'leather': Mat('#6a4a30', 'leather'), 'dleather': Mat('#3e2c22', 'leather'),
 'wood': Mat('#6b4a2a', 'leather', tex=0.08), 'eye': Mat('#120a10', 'matte'),
 'string': Mat('#d8d0c0', 'matte'),
}
def mat(spec, key, default):
    v = spec.get(key, default)
    return M[v] if isinstance(v, str) and v in M else (v if isinstance(v, Mat) else Mat(v, 'cloth'))

# ------------------------------------------------------------------ poses
def pose(kind, fr, wtype):
    """angles (deg, 0=down, +90=forward). fr 0-5 walk, 6 windup, 7 strike, 8 follow, 9 hurt, 10 dead(made later), 11 idle"""
    ranged = wtype in ('bow', 'crossbow', 'cannon', 'staff', 'orb', 'lantern')
    if fr == 9:
        return dict(nt=-6, ns=-16, ft=14, fs=2, lean=-16, bob=0, nu=-40, nf=-80, fu=-70, ff=-110, w=(0 if wtype in ('bow','crossbow','cannon') else -60))
    if fr in (10, 11):
        p = dict(nt=8, ns=2, ft=-7, fs=-3, lean=2, bob=0)
        if ranged: p.update(nu=55, nf=80, fu=20, ff=40, w=0 if wtype in ('bow','crossbow','cannon') else 170)
        else: p.update(nu=18, nf=60, fu=-6, ff=12, w=140)
        return p
    if fr < 6:
        ph = 2 * math.pi * fr / 6; s = math.sin(ph)
        nt, ft = 26 * s, -26 * s
        ns = nt - 42 * max(0, math.sin(ph + 2.2)); fs = ft - 42 * max(0, math.sin(ph + 2.2 + math.pi))
        p = dict(nt=nt, ns=ns, ft=ft, fs=fs, lean=4, bob=abs(math.cos(ph)) * 1.0)
        sw = 14 * s
        if ranged: p.update(nu=60, nf=85, fu=40 - sw * .3, ff=75, w=0 if wtype in('bow','crossbow','cannon') else 170)
        else: p.update(nu=25 + sw * .4, nf=80, fu=-sw, ff=30 - sw, w=150)
        return p
    base = dict(nt=18, ns=4, ft=-16, fs=-24, bob=0.6)
    if ranged:
        k = fr - 6
        return dict(base, lean=[0, 6, 3][k], nu=[55, 75, 70][k], nf=[80, 90, 88][k], fu=[60, 65, 40][k], ff=[120, 95, 70][k],
                    w=[0, 0, 0][k] if wtype in ('bow', 'crossbow', 'cannon') else [175, 120, 150][k], draw=[1, 0, 0][k])
    return [dict(base, lean=-4, nu=-130, nf=-160, fu=-30, ff=10, w=-125),
            dict(base, lean=14, nu=85, nf=100, fu=-40, ff=-20, w=105),
            dict(base, lean=8, nu=45, nf=40, fu=-20, ff=10, w=55)][fr - 6]

# ------------------------------------------------------------------ weapons
def weapon(c, kind, hand, ang, S, fr):
    wm = mat(S, 'wmat', 'steel'); gm = mat(S, 'gmat', 'gold')
    glow = Mat(S.get('glow', '#b44cff'), emit=True)
    if kind in ('sword', 'greatsword', 'dagger'):
        L = {'sword': 15, 'greatsword': 21, 'dagger': 8}[kind]; W = {'sword': 1.5, 'greatsword': 2.1, 'dagger': 1.2}[kind]
        base = P(hand, 2.5, ang); tip = P(hand, L + 2.5, ang)
        pa, pb = P(base, W, ang + 90), P(base, W, ang - 90)
        ta, tb = P(tip, W * 0.6, ang + 90), P(tip, W * .6, ang - 90); pt = P(tip, W * 1.6, ang)
        c.poly([pa, ta, pt, tb, pb], wm, bevel=(base, pt))
        c.capsule(P(hand, 2.2, ang + 90 + 0), P(hand, 2.2, ang - 90), 0.9, 0.9, gm) if False else c.capsule(P(base, W + 2, ang + 90), P(base, W + 2, ang - 90), 0.9, 0.9, gm)
        c.capsule(hand, P(hand, -3, ang), 0.9, 0.9, mat(S, 'grip', 'dleather')); c.ell(P(hand, -3.6, ang), 1.2, 1.2, gm)
    elif kind == 'spear':
        c.capsule(P(hand, -8, ang), P(hand, 16, ang), .7, .7, M['wood'])
        b = P(hand, 16, ang); t = P(hand, 23, ang)
        c.poly([P(b, 1.8, ang + 90), t, P(b, 1.8, ang - 90), P(b, -1, ang)], wm, bevel=(b, t))
    elif kind in ('hammer', 'maul', 'axe'):
        c.capsule(P(hand, -4, ang), P(hand, 13, ang), .8, .8, M['wood'])
        h = P(hand, 13, ang)
        if kind == 'axe':
            c.poly([P(h, 1, ang - 90), P(P(h, 6, ang - 90), 4, ang), P(P(h, 7, ang - 90), -3, ang), P(h, -2, ang)], wm, bevel=(h, P(h, 7, ang - 90)))
            c.poly([P(h, 1, ang + 90), P(P(h, 2.5, ang + 90), 1.5, ang), P(P(h, 2.5, ang + 90), -1.5, ang)], wm)
        else:
            sz = 3.6 if kind == 'hammer' else 4.2
            c.capsule(P(h, sz, ang + 90), P(h, sz, ang - 90), sz * .75, sz * .75, wm)
            if kind == 'maul':
                for a in (0, 90, 180, -90): c.ell(P(h, sz + .6, a + ang), .9, .9, M['steel'])
            else: c.ell(P(h, sz + .6, ang - 90), 1.4, 1.4, Mat(S.get('glow', '#ff8a1f'), emit=True))
    elif kind == 'staff':
        c.capsule(P(hand, -12, ang), P(hand, 10, ang), .8, .7, mat(S, 'staffmat', 'wood'))
        top = P(hand, 12, ang); c.ell(top, 2.4, 2.4, glow)
        c.capsule(P(top, 2.6, ang + 90), P(top, 1, ang + 60), .5, .4, gm); c.capsule(P(top, 2.6, ang - 90), P(top, 1, ang - 60), .5, .4, gm)
    elif kind == 'orb':
        c.ell(P(hand, 2.5, 90), 2.6, 2.6, glow)
    elif kind == 'lantern':
        c.capsule(hand, P(hand, 3, 0), .4, .4, M['iron'])
        lc = P(hand, 6, 0); c.ell(lc, 2.4, 3.0, glow); c.capsule(P(lc, 3, 180), P(lc, 3.4, 180), 2.2, 2.2, M['iron'])
        c.capsule(P(lc, 3, 0), P(lc, 3.2, 0), 2.0, 2.0, M['iron'])
    elif kind == 'bow':
        cx = P(hand, 0.5, 90)
        pts = [P(cx, 11, 180 + a) for a in range(-75, 76, 15)]
        pts = [(cx[0] + 5 * math.cos(R(a)) - 4, cx[1] - 11 * math.sin(R(a))) for a in range(-80, 81, 16)]
        for a, b in zip(pts, pts[1:]): c.capsule(a, b, .9, .9, mat(S, 'bowmat', 'wood'))
        sx = pts[0][0] - (4 if S.get('_draw') else 0)
        c.capsule(pts[0], (sx, cx[1]), .3, .3, M['string']); c.capsule((sx, cx[1]), pts[-1], .3, .3, M['string'])
        if S.get('_draw') or fr < 6: c.capsule((sx, cx[1]), (cx[0] + 4, cx[1]), .45, .45, M['wood'])
    elif kind == 'crossbow':
        c.capsule(P(hand, -3, 90), P(hand, 9, 90), 1.1, 1.0, M['wood'])
        f = P(hand, 7, 90); c.capsule(P(f, 5, 180), P(f, 5, 0), .9, .9, M['dsteel'])
        c.capsule(P(f, 5, 180), P(hand, -1, 90), .25, .25, M['string']); c.capsule(P(f, 5, 0), P(hand, -1, 90), .25, .25, M['string'])
    elif kind == 'cannon':
        c.capsule(P(hand, -2, 90), P(hand, 10, 90), 2.6, 2.3, mat(S, 'cmat', 'dsteel'))
        c.ell(P(hand, 10.6, 90), 1.6, 2.0, glow)
        for d in (2, 6): c.capsule(P(P(hand, d, 90), 2.8, 180), P(P(hand, d, 90), 2.8, 0), .7, .7, gm)
    elif kind == 'brick':
        if fr not in (7, 8):
            bc = P(hand, 1.2, ang); c.poly([P(P(bc, 2.6, ang), 1.6, ang + 90), P(P(bc, 2.6, ang), 1.6, ang - 90), P(P(bc, -2.6, ang), 1.6, ang - 90), P(P(bc, -2.6, ang), 1.6, ang + 90)],
                   Mat('#9a3a24', 'matte', tex=.2), normal=(.3, -.5, .8))
    elif kind == 'claws':
        for k in (-1, 0, 1): c.capsule(P(hand, 1, ang + k * 18), P(hand, 5, ang + k * 18), .6, .2, M['bone'])
    elif kind == 'shield':
        sc = P(hand, 1.5, 90)
        c.ell(sc, 4.2, 7.0, mat(S, 'shieldmat', 'steel')); c.ell(sc, 3.0, 5.6, mat(S, 'shieldface', '#7a1a1a'), )
        c.ell(sc, 1.2, 1.2, gm)

# ------------------------------------------------------------------ humanoid
def humanoid(c, S, fr, ox=0, ground=60):
    sc = S.get('scale', 1.0) * 1.1; stock = S.get('stock', 1.0)
    wt = S.get('weapon', 'sword')
    p = pose('h', fr, wt)
    Lt, Ls = 10.5 * sc, 10.5 * sc * S.get('shin', 1.0); Lu, Lf = 8 * sc, 7.5 * sc; tor = 13.5 * sc * S.get('torso', 1.0)
    skin = mat(S, 'skin', '#d9a07a'); cloth = mat(S, 'cloth', '#3a3048'); pants = mat(S, 'pants', '#2e2836')
    boots = mat(S, 'boots', 'dleather'); arm_m = mat(S, 'arms', S.get('cloth', '#3a3048'))
    # legs relative to hip
    def leg(t, s_):
        k = P((0, 0), Lt, t); f = P(k, Ls, s_); return k, f
    nk, nf = leg(p['nt'], p['ns']); fk, ff = leg(p['ft'], p['fs'])
    low = max(nf[1], ff[1]) + 2.0 * sc
    hip = (ox + S.get('cx', 32), ground - low - p['bob'] * sc)
    add = lambda a, b: (a[0] + b[0], a[1] + b[1])
    nk, nf, fk, ff = add(hip, nk), add(hip, nf), add(hip, fk), add(hip, ff)
    sh = P(hip, tor, 180 - p['lean']); neck = P(sh, 2.2 * sc, 180 - p['lean'])
    head = P(neck, 4.0 * sc, 180 - p['lean'] * .5); head = (head[0] + 1.0 * sc, head[1])
    fsh = (sh[0] - 1.6 * sc * stock, sh[1] + .6); nsh = (sh[0] + 1.2 * sc, sh[1] + .4)
    fe = P(fsh, Lu, p['fu']); fh = P(fe, Lf, p['ff'])
    ne = P(nsh, Lu, p['nu']); nh = P(ne, Lf, p['nf'])
    if p.get('draw') and wt == 'bow': fh = P(fe, Lf * .6, p['ff'])
    darker = lambda m_, f=0.72: Mat(m_.col * f, m_.kind, m_.spec * .6, m_.emit, m_.tex)
    # ---- back layers: wings, cape, shell, tail
    if S.get('wings'):
        wm = mat(S, 'wings', '#2a1a2a'); up = fr % 3 != 1
        base = P(sh, 2, -90); span = 16 * sc
        tips = [P(base, span * (1 - k * .18), (-150 if up else -115) + k * 22) for k in range(4)]
        c.poly([base] + tips + [P(base, 6 * sc, -40)], wm, normal=(-.3, -.2, .93), folds=1.4)
        for t_ in tips: c.capsule(base, t_, .7, .3, darker(wm, .6))
    if S.get('cape'):
        cm = mat(S, 'cape', '#7a1020'); fl = (math.sin(fr * 1.7) + 1) * 1.6
        bot = ground - 6 * sc
        c.poly([P(fsh, 1.5, -90), (sh[0] + 1, sh[1] - .5), (hip[0] - 3, bot + 1), (hip[0] - 9 * sc - fl, bot - 1), (hip[0] - 7 * sc - fl * .5, (sh[1] + bot) / 2)],
               cm, normal=(-.25, -.1, .96), folds=1.1)
    if S.get('tail'):
        tm = mat(S, 'tail', '#3a6a5a'); prev = (hip[0] - 3, hip[1] + 2)
        for k in range(6):
            nxt = (prev[0] - 3.2 * sc, prev[1] + 2.0 * math.sin(fr * 1.05 + k) + (1.2 if k < 2 else -.6))
            c.capsule(prev, nxt, 3.0 * sc * (1 - k * .13), 3.0 * sc * (1 - (k + 1) * .13), tm); prev = nxt
    if wt in ('bow',) and not S.get('serpent'):
        qb = P(sh, 1.5, -90); qt = (qb[0] - 3.5 * sc, qb[1] - 5 * sc)
        c.capsule((qb[0] - 1, qb[1] + 7 * sc), qt, 1.6 * sc, 1.4 * sc, mat(S, 'quiver', 'leather'))
        for j in range(3): c.capsule(qt, (qt[0] - 1.2 + j * 1.2, qt[1] - 3 * sc), .35, .3, Mat('#e8e0d0'))
    # ---- far arm (behind)
    c.capsule(fsh, fe, 1.7 * sc * stock, 1.4 * sc * stock, darker(arm_m)); c.capsule(fe, fh, 1.4 * sc * stock, 1.15 * sc * stock, darker(mat(S, 'forearm', S.get('arms', S.get('cloth', '#3a3048')))))
    c.ell(fh, 1.2 * sc, 1.2 * sc, darker(mat(S, 'hands', S.get('skin', '#d9a07a'))))
    if S.get('offhand'):
        weapon(c, S['offhand'], fh, 120 if fr != 7 else 95, dict(S, wmat=S.get('owmat', S.get('wmat', 'steel'))), fr)
    # ---- far leg
    if not S.get('serpent'):
        c.capsule(hip, fk, 2.3 * sc * stock, 1.8 * sc * stock, darker(pants)); c.capsule(fk, ff, 1.8 * sc * stock, 1.6 * sc * stock, darker(boots, .75))
        c.capsule(ff, (ff[0] + 2.8 * sc, ff[1] + .4), 1.6 * sc, 1.3 * sc, darker(boots, .75))
    if S.get('shell'):
        shm = mat(S, 'shell', '#7a5a2a'); c.ell(P(hip, tor * .55, 180 - p['lean']), 6.2 * sc, 8.2 * sc, shm, rot=R(-p['lean']) )
        c.ell(((hip[0]+sh[0])/2 - 4.5*sc, (hip[1]+sh[1])/2), 3.6 * sc, 6.8 * sc, Mat(shm.col * .75, 'bone'))
    # ---- torso
    if S.get('serpent'):
        tm = mat(S, 'tail', '#3a6a5a')
        c.capsule(hip, (hip[0] + 1, ground - 4), 3.4 * sc, 3.8 * sc, tm); c.capsule((hip[0] - 6, ground - 2.4), (hip[0] + 6, ground - 2.4), 2.6, 2.6, tm)
    else:
        c.capsule(hip, nk, 2.4 * sc * stock, 1.9 * sc * stock, pants); c.capsule(nk, nf, 1.9 * sc * stock, 1.7 * sc * stock, boots)
        c.capsule(nf, (nf[0] + 2.8 * sc, nf[1] + .4), 1.7 * sc, 1.4 * sc, boots)
        c.capsule(P(nk, 5.2 * sc, p['ns']), P(nk, 5.6 * sc, p['ns']), 2.1 * sc * stock, 2.1 * sc * stock, darker(boots, 1.25))
        if S.get('greaves'): c.capsule(nk, P(nk, 4, p['ns']), 2.4 * sc, 2.0 * sc, mat(S, 'greaves', 'steel'))
    # tapered torso: narrow waist, broad shoulders, two-tone split down the middle
    L_ = 180 - p['lean']; wa, sw_ = 3.4 * sc * stock, 5.6 * sc * stock
    c.poly([P(hip, wa, L_ - 90), P(hip, wa, L_ + 90), P(sh, sw_, L_ + 90), P(sh, sw_, L_ - 90)], cloth, bevel=(hip, sh))
    c.capsule(P(sh, sw_ - 1.5, L_ + 90), P(sh, sw_ - 1.5, L_ - 90), 1.8 * sc, 1.8 * sc, cloth)
    c.capsule(hip, P(hip, 2, L_), 3.4 * sc * stock, 3.4 * sc * stock, pants)
    if S.get('belly'): c.ell(P(hip, tor * .4, 180 - p['lean']), 5.4 * sc * stock, 5.2 * sc, mat(S, 'belly', '#c8b090'))
    if S.get('chest'):
        ch = mat(S, 'chest', 'steel'); cc = P(hip, tor * .62, 180 - p['lean'])
        c.ell((cc[0] + .6, cc[1]), 4.6 * sc * stock, 5.0 * sc, ch, rot=R(-p['lean']))
    if S.get('tabard'):
        tb = mat(S, 'tabard', '#6a1020'); top_ = P(hip, tor * .55, 180 - p['lean']); fl = math.sin(fr * 1.3) * .8
        c.poly([(top_[0] - 2.2 * sc, top_[1]), (top_[0] + 3.2 * sc, top_[1]), (hip[0] + 3.6 * sc + fl, hip[1] + 9 * sc), (hip[0] - 1.6 * sc + fl, hip[1] + 9 * sc)], tb, folds=2.0)
        if S.get('emblem'): c.ell((hip[0] + 1, hip[1] - 1 - tor * .1), 1.6, 1.8, mat(S, 'emblem', 'gold'))
    if S.get('ribs'):
        for k in range(4):
            y = P(hip, tor * (.45 + k * .13), 180 - p['lean'])
            c.capsule((y[0] - 3.4 * sc, y[1]), (y[0] + 3.6 * sc, y[1] + .4), .55, .55, M['bone'])
    if S.get('core'): c.ell(P(hip, tor * .68, 180 - p['lean']), 1.6 * sc, 1.6 * sc, Mat(S['core'], emit=True))
    if S.get('skirt'):
        sk = mat(S, 'skirt', S.get('cloth')); fl = math.sin(fr * 1.3) * .8
        c.poly([(hip[0] - 4.5 * sc, hip[1] - 2), (hip[0] + 4.5 * sc, hip[1] - 2), (hip[0] + 5.5 * sc + fl, hip[1] + S.get('skirtlen', 7) * sc), (hip[0] - 5.5 * sc + fl, hip[1] + S.get('skirtlen', 7) * sc)], sk, folds=2.2)
    c.capsule((hip[0] - 4.4 * sc * stock, hip[1] - 1.5), (hip[0] + 4.6 * sc * stock, hip[1] - 1.5), 1.1, 1.1, mat(S, 'belt', 'dleather'))
    # pouch on the belt, a cross-body strap, collar line, boot cuffs
    c.ell((hip[0] - 2.6 * sc * stock, hip[1] - .2), 1.4, 1.2, darker(mat(S, 'belt', 'dleather'), .85))
    if not S.get('chest') and not S.get('ribs') and not S.get('serpent'):
        c.capsule(P(sh, 4.2 * sc, L_ + 90), P(hip, 3.6 * sc, L_ - 90), .55, .55, mat(S, 'strap', 'dleather'))
    c.capsule(P(sh, 2.2 * sc, L_ + 90), P(sh, 2.4 * sc, L_ - 90), .7, .7, darker(cloth, .7))
    c.ell((hip[0] + 1, hip[1] - 1.5), 1.1, 1.0, mat(S, 'buckle', 'gold'))
    if S.get('pauldron'):
        pm = mat(S, 'pauldron', 'steel'); c.ell((nsh[0] - .5, nsh[1] + .8), 3.4 * sc * stock, 2.8 * sc, pm)
    if S.get('hoodback'): pass
    # ---- head
    h = S.get('head', 'human'); hr = 4.0 * sc
    sk = skin
    if h in ('human', 'dwarf', 'elf'):
        c.capsule(neck, head, 1.6 * sc, 1.6 * sc, darker(sk, .85))
        if S.get('hair') and S.get('long'):
            hm = mat(S, 'hairmat', S['hair']); c.capsule((head[0] - 2.4 * sc, head[1] - 1), (head[0] - 3.2 * sc, head[1] + 6 * sc), 2.4 * sc, 1.8 * sc, hm)
        c.ell(head, hr * .92, hr, sk)
        c.ell((head[0] + 2.0 * sc, head[1] - .3), .85, .7, Mat('#ece4d8')) if not S.get('eyem') else None
        c.ell((head[0] + 2.3 * sc, head[1] - .3), .5, .6, mat(S, 'eyem', 'eye'))
        c.capsule((head[0] + 1.2 * sc, head[1] - 1.4 * sc), (head[0] + 2.9 * sc, head[1] - 1.3 * sc), .3, .3, darker(sk, .55))
        c.capsule((head[0] + 2.4 * sc, head[1] + 1.9 * sc), (head[0] + 3.3 * sc, head[1] + 1.8 * sc), .25, .25, darker(sk, .55))
        if S.get('hair'):
            hm = mat(S, 'hairmat', S['hair'])
            c.ell((head[0] - .8, head[1] - 2.2 * sc), hr * .95, hr * .55, hm, cut=lambda X, Y: X < head[0] + 2.4 * sc)
            c.capsule((head[0] - 3.2 * sc, head[1] - 1.2), (head[0] - 2.8 * sc, head[1] + 1.8), 1.3 * sc, 1.0 * sc, hm)
        if S.get('ears'): c.capsule((head[0] - 1, head[1]), (head[0] - 3.5 * sc, head[1] - 3.6 * sc), .9, .3, sk)
        if S.get('beard'):
            bm = mat(S, 'beardmat', S['beard'])
            c.ell((head[0] + .8, head[1] + 2.6 * sc), 3.4 * sc, 3.2 * sc * S.get('beardlen', 1.0), bm, cut=lambda X, Y: Y > head[1] + .2)
            c.capsule((head[0] + 3.0 * sc, head[1] + .6), (head[0] + 3.4 * sc, head[1] + .6), .6, .6, sk)
    elif h == 'skull':
        c.capsule(neck, head, 1.2 * sc, 1.2 * sc, M['bone'])
        c.ell(head, hr * .92, hr, M['bone']); c.capsule((head[0] + .6, head[1] + 2.4 * sc), (head[0] + 3 * sc, head[1] + 2.6 * sc), 1.4 * sc, 1.2 * sc, M['bone'])
        c.ell((head[0] + 1.9 * sc, head[1] - .3), 1.7, 1.6, M['eye']); c.ell((head[0] + 2.1 * sc, head[1] - .2), .8, .8, Mat(S.get('eyeglow', '#a6ff2e'), emit=True))
        for k in range(3): c.capsule((head[0] + (1 + k * .9) * sc, head[1] + 2.0 * sc), (head[0] + (1 + k * .9) * sc, head[1] + 3.2 * sc), .25, .25, M['eye'])
    elif h == 'beast':
        c.capsule(neck, head, 2.4 * sc, 2.4 * sc, sk)
        c.ell(head, hr, hr * .9, sk); c.capsule(head, (head[0] + 5 * sc, head[1] + 1.2 * sc), 2.6 * sc, 1.8 * sc, sk)
        c.ell((head[0] + 1.8 * sc, head[1] - 1.0 * sc), .8, .7, Mat(S.get('eyeglow', '#ffd23f'), emit=True))
        c.capsule((head[0] + 3 * sc, head[1] + 2.6 * sc), (head[0] + 6 * sc, head[1] + 2.4 * sc), .5, .4, M['bone'])
        if S.get('horns'):
            hm = mat(S, 'hornmat', 'bone'); c.capsule((head[0] - 1, head[1] - 2.6 * sc), (head[0] - 5 * sc, head[1] - 6 * sc), 1.2, .4, hm)
    elif h == 'owl':
        om = sk; c.ell(head, hr * 1.15, hr * 1.05, om)
        c.capsule((head[0] - 2.5 * sc, head[1] - 3 * sc), (head[0] - 3.5 * sc, head[1] - 6 * sc), 1.2, .3, om); c.capsule((head[0] + 2.5 * sc, head[1] - 3 * sc), (head[0] + 3 * sc, head[1] - 6 * sc), 1.2, .3, om)
        for dx in (.4, 3.2): c.ell((head[0] + dx * sc, head[1] - .4), 1.5, 1.5, Mat('#ffd23f', emit=True)); c.ell((head[0] + dx * sc + .3, head[1] - .4), .6, .6, M['eye'])
        c.poly([(head[0] + 1.4 * sc, head[1] + 1), (head[0] + 3 * sc, head[1] + 1.5), (head[0] + 1.8 * sc, head[1] + 3.6)], Mat('#d9a836', 'bone'))
    elif h == 'beak':
        c.ell(head, hr, hr * .95, sk); c.capsule(head, (head[0] + 4 * sc, head[1] + 1.5), 2.6 * sc, 1.6 * sc, sk)
        c.ell((head[0] + 1.6 * sc, head[1] - .8), .8, .8, M['eye'])
        c.capsule((head[0] + 1, head[1] + 2.6), (head[0] + 4.2 * sc, head[1] + 2.4), .3, .3, darker(sk, .5))
    elif h == 'robot':
        c.capsule(neck, head, 1.6, 1.6, M['iron'])
        c.capsule((head[0] - 1, head[1] - 1), (head[0] + 1.5, head[1] + .8), hr * .95, hr * .9, mat(S, 'helm', 'steel'))
        c.capsule((head[0] + 0.5, head[1] - .4), (head[0] + 3.4 * sc, head[1] - .4), .9, .9, Mat(S.get('eyeglow', '#3ff0ff'), emit=True))
        c.capsule((head[0] - 1, head[1] - hr - .6), (head[0] - 1.5, head[1] - hr - 3), .5, .5, M['dsteel'])
    hat = S.get('hat')
    if hat:
        hm = mat(S, 'hatmat', 'steel')
        if hat == 'greathelm':
            c.capsule((head[0] - .5, head[1] - 1), (head[0] + .6, head[1] + 1.4), hr * 1.08, hr, hm)
            c.capsule((head[0] + 1.0, head[1] - .4), (head[0] + 4.4 * sc, head[1] - .4), .45, .45, M['eye'])
            if S.get('plume'): c.poly([(head[0] - 1, head[1] - hr), (head[0] - 6 * sc, head[1] - hr - 3), (head[0] - 9 * sc, head[1] - hr + 3), (head[0] - 2, head[1] - hr + 2)], mat(S, 'plume', '#a01020'), folds=2)
        elif hat == 'crown':
            gm = M['gold']; y0 = head[1] - hr * .7
            c.capsule((head[0] - hr * .9, y0), (head[0] + hr * .9, y0), 1.0, 1.0, gm)
            for k in (-1, 0, 1): c.poly([(head[0] + k * 2.6 * sc - 1, y0), (head[0] + k * 2.6 * sc, y0 - 3.2 * sc), (head[0] + k * 2.6 * sc + 1, y0)], gm, normal=(-.3, -.4, .87))
            c.ell((head[0], y0), .7, .7, Mat('#c8102e', 'gem'))
        elif hat == 'hood':
            c.ell((head[0] - 1.2, head[1] - .8), hr * 1.12, hr * 1.12, hm, cut=lambda X, Y: (X < head[0] - .2 * sc) | (Y < head[1] - hr * .55))
            c.poly([(head[0] - 3.5 * sc, head[1] - 2), (head[0] - 6 * sc, head[1] + 4 * sc), (head[0] - 1, head[1] + 4 * sc)], hm)
        elif hat == 'wizard':
            c.capsule((head[0] - hr * 1.4, head[1] - hr * .55), (head[0] + hr * 1.5, head[1] - hr * .55), 1.0, 1.0, hm)
            c.poly([(head[0] - hr * .9, head[1] - hr * .6), (head[0] - 2 * sc, head[1] - hr * 2.7), (head[0] - 5 * sc, head[1] - hr * 3.2), (head[0] + hr * .9, head[1] - hr * .6)], hm, folds=1.2)
            if S.get('hatband'): c.capsule((head[0] - hr * .85, head[1] - hr * .85), (head[0] + hr * .85, head[1] - hr * .85), .7, .7, mat(S, 'hatband', 'gold'))
        elif hat == 'horned':
            c.capsule((head[0] - .5, head[1] - 1.2), (head[0] + .5, head[1] - .2), hr * 1.0, hr * .85, hm, flat=0)
            for sgn in (-1, 1): c.capsule((head[0] + sgn * 2.4, head[1] - hr * .7), (head[0] + sgn * 5 * sc, head[1] - hr * 2), 1.2, .35, M['bone'])
        elif hat == 'horns':
            for sgn in (-1, 1): c.capsule((head[0] + sgn * 1.6, head[1] - hr * .8), (head[0] + sgn * 3.5 * sc - 1, head[1] - hr * 2.0), 1.1, .3, mat(S, 'hornmat', 'bone'))
        elif hat == 'goggles':
            c.ell((head[0] - .4, head[1] - 1.2), hr * 1.02, hr * .78, mat(S, 'hatmat', 'leather'), cut=lambda X, Y: Y < head[1] + .2)
            for dx in (.6, 3.0): c.ell((head[0] + dx * sc, head[1] - 2.1 * sc), 1.3, 1.3, Mat('#ffd23f', 'gem'));
        elif hat == 'circlet':
            c.capsule((head[0] - hr * .9, head[1] - hr * .55), (head[0] + hr * .85, head[1] - hr * .6), .55, .55, mat(S, 'hatmat', 'steel'))
            c.ell((head[0] + hr * .7, head[1] - hr * .6), .8, .8, Mat('#7dff9a', 'gem'))
        elif hat == 'mask':
            c.ell((head[0] + .8, head[1] - .4), hr * .95, hr * .55, hm, cut=lambda X, Y: X > head[0] - 1)
            c.ell((head[0] + 2.0 * sc, head[1] - .6), .8, .6, Mat('#ffd23f', emit=True))
        elif hat == 'tufts': pass
    # ---- near arm + weapon
    c.capsule(nsh, ne, 1.8 * sc * stock, 1.5 * sc * stock, arm_m)
    if S.get('bracer'): c.capsule(ne, P(ne, Lf * .7, p['nf']), 1.9 * sc * stock, 1.6 * sc * stock, mat(S, 'bracer', 'steel'))
    else: c.capsule(ne, nh, 1.5 * sc * stock, 1.25 * sc * stock, mat(S, 'forearm', S.get('arms', S.get('cloth', '#3a3048'))))
    if S.get('pauldron'): c.ell((nsh[0] + .2, nsh[1] + .2), 3.0 * sc * stock, 2.6 * sc, mat(S, 'pauldron', 'steel'))
    c.ell(nh, 1.3 * sc, 1.3 * sc, mat(S, 'hands', S.get('skin', '#d9a07a')))
    weapon(c, wt, nh, p['w'], dict(S, _draw=p.get('draw')), fr)

FR = 12
def laydown(img, ground=60):
    """dead frame: the idle pose tipped over onto its back (exact 90deg turn keeps pixels crisp)"""
    a = np.rot90(img, 1); ys, xs = np.nonzero(a[..., 3])
    out = np.zeros_like(img)
    if not len(ys): return out
    cut = a[ys.min():ys.max() + 1, xs.min():xs.max() + 1]; hh, ww = cut.shape[:2]
    H_, W_ = img.shape[:2]; ww = min(ww, W_); hh = min(hh, H_)
    x0 = max(0, W_ // 2 - ww // 2 - 4); y0 = max(0, ground + 1 - hh)
    out[y0:y0 + hh, x0:x0 + ww] = cut[:hh, :ww]; return out
def render(S, w=64, h=64, ncol=20, drawer=None):
    frames = []
    for fr in range(FR):
        c = Canvas(w, h)
        if drawer: drawer(c, S, {9: 0, 10: 0, 11: 0}.get(fr, fr))
        elif isinstance(S, list):
            humanoid(c, S[0], (fr + 3) % 6 if fr < 6 else fr, ox=-9); humanoid(c, S[1], fr, ox=9)
        else: humanoid(c, S, fr)
        frames.append(c.finish())
    frames = quantize(frames, ncol)
    frames = [outline_sel(f) for f in frames]
    frames[10] = laydown(frames[11], (60 if h == 64 else 44) * rig.RES)
    if isinstance(S, list) and not drawer:   # duo: lay each partner down on his own, side by side
        parts = []
        for k, ox in ((0, -9), (1, 9)):
            c = Canvas(w, h); humanoid(c, S[k], 11, ox=0); parts.append(laydown(outline_sel(quantize([c.finish()], ncol)[0]), 60 * rig.RES))
        out = np.zeros_like(frames[10]); 
        for k, pimg in enumerate(parts):
            sh_ = (14 if k else -14) * rig.RES; src = np.roll(pimg, sh_, axis=1); m = src[..., 3] > 0; out[m] = src[m]
        frames[10] = out
    return frames


# ------------------------------------------------------------------ special bodies
def golem(c, S, fr):
    ph = 2 * math.pi * (fr % 6) / 6; st = math.sin(ph) * (fr < 6); g = 60; bob = abs(math.cos(ph)) * 1.2 * (fr < 6)
    stone = mat(S, 'stone', '#7d8a72'); dk = Mat(stone.col * .7, 'matte', tex=.12)
    lean = {6: -4, 7: 12, 8: 6}.get(fr, 2)
    hip = (30, g - 15 - bob); sh = P(hip, 17, 180 - lean)
    for side, s_ in ((-1, dk), (1, stone)):
        k = P(hip, 8, side * 18 * st); f = P(k, 7, side * 10 * st)
        c.capsule(hip, k, 4.2, 3.6, s_); c.capsule(k, (f[0], g - 3), 3.6, 4.0, s_)
    c.capsule((hip[0] - 5, sh[1] + 3), (sh[0] - 6, sh[1] + 2), 4.5, 4.5, dk)
    c.capsule(hip, sh, 7.5, 10.5, Mat(stone.col, 'matte', tex=.14))
    for k in range(5):
        a = P(hip, 4 + k * 3, 180 - lean); c.capsule((a[0] - 6 + k % 2 * 3, a[1]), (a[0] - 2 + k % 2 * 3, a[1] + 1.5), .35, .35, Mat(stone.col * .45))
    if S.get('moss'):
        for k in range(7): c.ell((sh[0] - 7 + k * 2.2, sh[1] - 4 + (k % 3)), 1.6, 1.0, Mat('#4f7a2a', tex=.2))
    if S.get('crystals'):
        cm = Mat(S['crystals'], 'gem')
        for k, (dx, h, a) in enumerate(((-8, 9, -25), (-4, 12, -10), (1, 10, 8), (5, 8, 22), (-10, 6, -40))):
            b = (sh[0] + dx, sh[1] - 3); t_ = P(b, h, 180 + a)
            c.poly([P(b, 2.2, 90 + a), t_, P(b, 2.2, -90 + a)], cm, bevel=(b, t_))
    c.capsule((sh[0] - 6, sh[1] + 1), P((sh[0] - 6, sh[1] + 1), 13, -10 + st * 15), 3.6, 3.2, dk)
    for dx in (-6, 5): c.ell((sh[0] + dx, sh[1] - 1), 5.2, 4.4, Mat(stone.col * (0.8 if dx < 0 else 1.05), 'matte', tex=.15))
    head = (sh[0] + 2, sh[1] - 7)
    c.ell(head, 4.6, 4.4, stone); c.capsule((head[0] - 2, head[1] - 2.4), (head[0] + 4, head[1] - 2), 1.2, 1.2, dk); c.capsule((head[0] + 1, head[1] - .5), (head[0] + 4, head[1] - .5), .8, .8, Mat(S.get('eyeglow', '#ffd23f'), emit=True))
    ne = P((sh[0] + 4, sh[1] + 2), 8, {6: -120, 7: 85, 8: 50}.get(fr, 30)); nh = P(ne, 7, {6: -150, 7: 95, 8: 40}.get(fr, 70))
    c.capsule((sh[0] + 4, sh[1] + 2), ne, 4.2, 3.8, stone); c.capsule(ne, nh, 3.8, 4.4, stone)
    if S.get('weapon') == 'shield':
        sx = nh[0] + (3 if fr == 7 else 1)
        c.capsule((sx + 2, sh[1] - 4), (sx + 2, g - 12), 4.6, 4.6, mat(S, 'shieldmat', 'bronze'))
        c.capsule((sx + 2.6, sh[1] - 2), (sx + 2.6, g - 14), 3.0, 3.0, mat(S, 'shieldface', '#3a5a3a'))
        c.ell((sx + 3, (sh[1] + g - 16) / 2), 1.6, 1.6, M['gold'])
    else:
        c.ell(nh, 3.6, 3.6, Mat(S.get('crystals', '#6ff0ff'), 'gem'))

def dragon(c, S, fr):
    g = 60; ph = 2 * math.pi * (fr % 6) / 6; bob = abs(math.cos(ph)) * (fr < 6)
    body = mat(S, 'skin', '#3a7a3a'); belly = mat(S, 'belly', '#c8b070'); dk = Mat(body.col * .7, 'matte')
    bc = (28, g - 15 - bob)
    up = fr % 3 != 1; wm = mat(S, 'wings', '#2a4a2a')
    base = (bc[0] - 2, bc[1] - 5)
    tips = [P(base, 20 - k * 3, (-160 if up else -120) + k * 25) for k in range(4)]
    c.poly([base] + tips + [P(base, 7, -60)], wm, normal=(-.2, -.3, .93), folds=1.3)
    for t_ in tips: c.capsule(base, t_, .8, .3, Mat(wm.col * .6))
    prev = (bc[0] - 8, bc[1] + 1)
    for k in range(6):
        nxt = (prev[0] - 3, prev[1] + 2 * math.sin(fr + k) + .8); c.capsule(prev, nxt, 3.2 - k * .45, 2.8 - k * .45, body); prev = nxt
    for k, dx in enumerate((-6, 5)):
        st = math.sin(ph + k * math.pi) * 22 * (fr < 6)
        a = (bc[0] + dx - 1, bc[1] + 2); kk = P(a, 6, st); c.capsule(a, kk, 2.8, 2.2, dk); c.capsule(kk, (kk[0] + 1, g - 2), 2.2, 2.0, dk)
    c.ell(bc, 11, 7, body); c.ell((bc[0] + 1, bc[1] + 3.5), 8, 3.4, belly)
    for k, dx in enumerate((-4, 7)):
        st = math.sin(ph + k * math.pi + 1) * 22 * (fr < 6)
        a = (bc[0] + dx, bc[1] + 3); kk = P(a, 6, st); c.capsule(a, kk, 3.0, 2.4, body); c.capsule(kk, (kk[0] + 1.5, g - 2), 2.4, 2.2, body)
        c.capsule((kk[0] + 1.5, g - 2), (kk[0] + 4, g - 1.6), 1.4, 1, M['bone'])
    for k, (hc, ny, nx) in enumerate(((S['head1'], -16, 10), (S['head2'], -9, 13))):
        hm = Mat(hc, 'matte'); atk = fr == 7
        nb = (bc[0] + 6, bc[1] - 3); hd = (bc[0] + nx + (3 if atk else 0), bc[1] + ny - bob + (2 if atk else 0))
        mid = ((nb[0] + hd[0]) / 2 - 2, (nb[1] + hd[1]) / 2)
        c.capsule(nb, mid, 3.0, 2.6, hm); c.capsule(mid, hd, 2.6, 2.4, hm)
        c.ell(hd, 3.6, 3.0, hm); c.capsule(hd, (hd[0] + 5, hd[1] + 1), 2.4, 1.6, hm)
        c.capsule((hd[0] - 1, hd[1] - 2), (hd[0] - 4, hd[1] - 5), .9, .3, M['bone'])
        c.ell((hd[0] + 1.4, hd[1] - 1), .9, .8, Mat('#ffd23f', emit=True))
        if atk:
            fm = Mat('#ff8a1f' if k == 0 else '#9ae6ff', emit=True)
            for j in range(4): c.ell((hd[0] + 8 + j * 3.5, hd[1] + 1 + (j % 2)), 1.8 + j * .4, 1.4 + j * .3, fm)

def walker(c, S, fr):
    g = 60; ph = 2 * math.pi * (fr % 6) / 6; bob = abs(math.cos(ph)) * (fr < 6)
    met = M['dsteel']; met2 = Mat('#8a7a5a', 'metal')
    body = (30, g - 22 - bob)
    for k, dx in enumerate((-9, -4, 4, 9)):
        st = math.sin(ph + k * 1.6) * 3 * (fr < 6); kn = (body[0] + dx * 1.2 + st, body[1] - 4); ft = (body[0] + dx * 1.5 + st * 1.5, g - 1)
        m_ = Mat(met.col * (.7 if k % 2 else 1), 'metal')
        c.capsule((body[0] + dx * .5, body[1] + 2), kn, 1.6, 1.4, m_); c.capsule(kn, ft, 1.4, 1.0, m_)
    c.capsule((body[0] - 10, body[1]), (body[0] + 10, body[1]), 5.6, 5.6, met2)
    for dx in (-6, 0, 6): c.ell((body[0] + dx, body[1] + 2), .9, .9, M['gold'])
    c.ell((body[0] - 2, body[1] - 7), 6, 5, Mat('#4a6a7a', 'gem'), cut=lambda X, Y: Y < body[1] - 4)
    gh = (body[0] - 1, body[1] - 9 - bob * .3); gsk = Mat('#5fae3a', 'skin')
    c.ell(gh, 3.4, 3.2, gsk); c.capsule((gh[0] - 2, gh[1] - 1), (gh[0] - 6, gh[1] - 3), 1, .3, gsk)
    c.ell((gh[0] + 1.4, gh[1] - .4), .8, .8, Mat('#ff3a1a', emit=True))
    c.ell((gh[0] - .3, gh[1] - 2.6), 3.2, 1.6, M['leather'], cut=lambda X, Y: Y < gh[1] - 1.8)
    hand = (body[0] + 9, body[1] - 1); weapon(c, 'cannon', hand, 90, dict(S, glow='#ffd23f'), fr)
    c.capsule((body[0] - 9, body[1] - 5), (body[0] - 12, body[1] - 12), .6, .6, M['iron']); c.ell((body[0] - 12, body[1] - 13), 1, 1, Mat('#ff3a1a', emit=True))

HEROES = {
 'grim': dict(head='skull', eyeglow='#a6ff2e', cloth='#2a2034', chest='steel', pauldron='dsteel', pants='#24202c', boots='iron', arms='dsteel',
              bracer='steel', greaves='steel', cape='#5a1a7a', hat='crown', weapon='greatsword', tabard='#4a1a6a', emblem='gold'),
 'vile': [dict(head='owl', skin=Mat('#56648a', 'cloth', tex=.15), cloth='#1a2440', arms='#1a2440', skirt='#1a2440', skirtlen=12, cape='#3a1a5a', weapon='orb', glow='#c050ff', hands='#56648a', pants='#1a2440', boots='dleather'),
          dict(scale=.85, stock=1.35, skin='#5fae3a', ears=1, cloth='#7a1a1a', chest='leather', pauldron='iron', pants='#4a2a1a', arms='#5fae3a', weapon='maul', wmat='iron', hair='#2a1a10')],
 'felothar': dict(_d=golem, stone='#7d8a72', moss=1, weapon='shield', shieldmat='bronze', shieldface='#2f5a34'),
 'thing': dict(_d=golem, stone='#5a3e7a', crystals='#6ff0ff', weapon='fist', eyeglow='#ff4af0'),
 'kykar': dict(skin='#e0b090', beard='#e8e8f0', beardlen=1.4, cloth='#24467a', arms='#24467a', skirt='#24467a', skirtlen=12, hat='wizard', hatmat='#1e2e6a', hatband='gold',
               cape='#c8ccd8', weapon='staff', glow='#9ae6ff', pants='#24467a', wings='#d8dce8', belt='#a01a1a'),
 'depala': dict(scale=.84, stock=1.4, skin='#e0a070', beard='#d4561f', beardlen=1.5, hair='#d4561f', hat='goggles', hatmat='leather', cloth='#8a1a1a', chest='steel', pauldron='steel',
                arms='#8a1a1a', bracer='steel', pants='#4a3a2a', boots='iron', weapon='hammer', wmat='dsteel', glow='#ff8a1f'),
 'kotis': dict(serpent=1, skin='#3f8a7a', tail='#2f6a5a', hat='mask', hatmat='#120a14', cloth='#2a1840', chest='dleather', arms='#3f8a7a', weapon='dagger', offhand='dagger', cape='#1a3a2a', belt='#3a2a1a'),
 'dragons': dict(_d=dragon, skin='#3a7a3a', wings='#2a4a2a', head1='#c83a2a', head2='#2a6ac8'),
 'mathas': dict(skin='#a8302a', hat='horns', cloth='#1a1418', skirt='#1a1418', skirtlen=10, arms='#1a1418', chest='dleather', cape='#3a0a10', weapon='crossbow', pants='#24181c', hair='#120a10', bracer='bronze', boots='dleather'),
 'turtle': [dict(head='beak', skin='#5a9a3a', shell='#7a5a2a', cloth='#4a7a3a', chest='leather', tabard='#d8d0b8', arms='#5a9a3a', pants='#4a7a3a', weapon='sword', offhand='shield', shieldmat='bronze', shieldface='#2a5a2a', boots='leather'),
            dict(head='beak', skin='#4a8a4a', shell='#6a4a2a', cloth='#3a6a3a', chest='leather', tabard='#c8b890', arms='#4a8a4a', pants='#3a6a3a', weapon='spear', boots='leather')],
 'marina': dict(skin='#d8c8b0', hair='#140c18', long=1, cloth='#1e1428', skirt='#1e1428', skirtlen=14, arms='#1e1428', hat='wizard', hatmat='#2a1a3a', hatband='#5a2a6a',
                weapon='lantern', glow='#7dff9a', cape='#22402a', pants='#1e1428'),
 'korvold': dict(scale=1.08, stock=1.3, head='beast', skin='#5a2a5a', horns=1, eyeglow='#ffd23f', cloth='#4a1a3a', belly='#b89a6a', arms='#5a2a5a', hands='#5a2a5a', hat='crown',
                 wings='#3a5a2a', tail='#5a2a5a', weapon='claws', pants='#5a2a5a', boots='#5a2a5a'),
 'thranduil': dict(skin='#f0d8b8', hair='#f0e08a', long=1, ears=1, hat='circlet', cloth='#2f5a34', chest='leather', arms='#2f5a34', cape='#9aa0a8', weapon='bow', bowmat='#c8a060',
                   pants='#24402a', boots='leather', bracer='leather'),
 'joel': [dict(scale=.86, skin='#e0b090', hat='hood', hatmat='#3a4a2a', cloth='#6a2a1a', arms='#6a2a1a', weapon='bow', bowmat='#8a6a3a', pants='#2a3a5a', boots='leather', hair='#5a3a2a'),
          dict(scale=1.08, skin='#d0a080', beard='#8a8478', hair=None, cloth='#4a3a5a', chest='leather', arms='#4a3a5a', weapon='axe', wmat='dsteel', pants='#3a3428', boots='dleather', stock=1.15)],
 'robots': dict(head='robot', helm='steel', eyeglow='#3ff0ff', cloth='#34404e', chest='steel', pauldron='steel', arms='dsteel', bracer='steel', greaves='steel', pants='#2a3440',
                boots='iron', core='#3ff0ff', weapon='cannon', glow='#3ff0ff', stock=1.25, hands='dsteel'),
 'blood': dict(skin='#e8dfe8', hair='#f2f2f2', long=1, cloth='#d8d4dc', skirt='#d8d4dc', skirtlen=14, arms='#d8d4dc', tabard='#1a1018', emblem='#c8102e', wings='#1a1018',
               weapon='staff', glow='#ff2a3a', staffmat='#d8d8e0', pants='#d8d4dc', hat='circlet', hatmat='gold'),
 'mech': dict(_d=walker),
 'weather': dict(scale=1.12, stock=1.45, head='beast', skin=Mat('#e6eef6', 'cloth', tex=.18), eyeglow='#3fb0ff', cloth=Mat('#d6e2ee', 'cloth', tex=.2), arms=Mat('#d6e2ee', 'cloth', tex=.2),
                 hands='#c8d4e0', belly='#a8bcd0', weapon='staff', glow='#9ae6ff', pants=Mat('#d6e2ee', 'cloth', tex=.2), boots='#a8bcd0', cape='#3a5a8a'),
}
ENEMIES = {
 'ghoul': dict(scale=.92, skin='#b8b8a8', head='human', cloth='#3a3430', arms='#b8b8a8', hands='#b8b8a8', pants='#2a2624', weapon='claws', eyem=Mat('#ffd23f', emit=True), boots='#b8b8a8', torso=.85),
 'cultist': dict(hat='hood', hatmat='#2a1030', skin='#c8b8a8', cloth='#2a1030', arms='#2a1030', skirt='#2a1030', skirtlen=14, weapon='staff', glow='#7dff9a', staffmat='bone', pants='#2a1030', eyem=Mat('#7dff9a', emit=True)),
 'knight': dict(hat='greathelm', hatmat='dsteel', plume='#5a0a14', chest='dsteel', pauldron='iron', arms='iron', bracer='dsteel', greaves='dsteel', cloth='#2a2a34', pants='#2a2a34', boots='iron', weapon='sword', wmat='steel', tabard='#5a0a14', stock=1.15, hands='iron'),
 'wolfman': dict(scale=1.05, stock=1.3, head='beast', skin=Mat('#5a4434', 'cloth', tex=.22), eyeglow='#ffd23f', cloth=Mat('#4a3a2c', 'cloth', tex=.2), arms=Mat('#5a4434', 'cloth', tex=.2), hands='#5a4434', pants='#3a2e24', boots='#5a4434', weapon='claws', belly='#8a7458'),
 'hag': dict(hat='hood', hatmat='#24341e', skin='#8aa070', hair='#c8c8b8', long=1, cloth='#24341e', arms='#24341e', skirt='#24341e', skirtlen=14, weapon='staff', glow='#c050ff', pants='#24341e', eyem=Mat('#ffd23f', emit=True)),
 'zombie': dict(skin='#7a9a5a', cloth='#3a3446', arms='#7a9a5a', pants='#2e2a36', weapon='claws', hair='#2a2a1a', eyem=Mat('#ff3a1a', emit=True), lean=10),
 'drowned': dict(skin='#5a8a8a', cloth='#24343a', arms='#5a8a8a', pants='#1a2a2a', weapon='claws', eyem=Mat('#a6ff2e', emit=True), hair='#1a3a2a', long=1),
 'skeleton': dict(head='skull', eyeglow='#ff3a1a', cloth='#d8ccb0', arms='bone', hands='bone', pants='bone', boots='bone', ribs=1, stock=.6, weapon='sword', wmat='iron', chest=None),
 'archer': dict(head='skull', eyeglow='#ff3a1a', cloth='#d8ccb0', arms='bone', hands='bone', pants='bone', boots='bone', ribs=1, stock=.6, weapon='bow', hat='hood', hatmat='#3a2a24'),
 'thrall': dict(skin='#d8d0e0', hair='#120a14', cloth='#3a0a14', arms='#3a0a14', cape='#7a0a1a', weapon='claws', eyem=Mat('#ff1a1a', emit=True), pants='#1a0a10', chest='#5a0a1a'),
 'wraith': dict(serpent=1, tail='#16222a', head='skull', eyeglow='#7dff9a', hat='hood', hatmat='#16222a', cloth='#16222a', arms='#16222a', hands='bone', weapon='sword', wmat='iron', cape='#0e161c'),
}
# ------------------------------------------------------------------ creature enemies (drawn facing right, flipped later)
def bat(c, S, fr):
    up = fr % 2 == 0 or fr == 7; cy = 26 + (2 if up else -1)
    body = Mat('#3a2434', 'cloth', tex=.15); wing = Mat('#24141e', 'cloth')
    for side in (-1, 1):
        base = (24 + side * 2, cy - 1); tip = (24 + side * 19, cy + (-12 if up else 7))
        c.poly([base, (24 + side * 9, cy + (-9 if up else 3)), tip, (24 + side * 14, cy + (0 if up else 9)), (24 + side * 8, cy + (-1 if up else 6)), (24 + side * 5, cy + 4)], wing, normal=(.2, -.3, .93), folds=2)
        c.capsule(base, tip, .6, .3, Mat('#4a2a3a'))
    c.ell((24, cy + 1), 4.2, 5.0, body); c.ell((26, cy - 4), 3.4, 3.0, body)
    for dx in (-1.5, 2): c.capsule((26 + dx, cy - 6), (26 + dx * 1.4, cy - 9.5), .9, .3, body)
    c.ell((27.6, cy - 4.2), .8, .7, Mat('#ff2a1a', emit=True)); c.ell((25, cy - 4.2), .7, .6, Mat('#ff2a1a', emit=True))
    c.capsule((27, cy - 2), (27.4, cy - .6), .3, .2, M['bone'])
def ghost(c, S, fr):
    y = 24 + math.sin(fr * 1.05) * 2; sh = Mat('#9aaebe', 'cloth', tex=.12); 
    pts = [(14, y + 2)] + [(14 + k * 2.4, y + 16 + 2.4 * math.sin(k * 1.4 + fr * 1.1)) for k in range(9)] + [(34, y + 4)]
    c.poly(pts, sh, normal=(.2, -.2, .95), folds=1.6)
    c.ell((24, y), 10, 9, sh, cut=lambda X, Y: Y < y + 4)
    for dx in (-3.4, 3.4): c.ell((25 + dx, y - 1), 1.7, 2.6, Mat('#0e0a18')); c.ell((25 + dx, y - .4), .6, .6, Mat('#ff3a3a', emit=True))
    c.ell((25, y + 4.5), 2.0, 2.8 if fr == 7 else 1.6, Mat('#0e0a18'))
    if fr in (6, 7): c.capsule((32, y + 4), (40, y + 2), 1.6, 1.0, sh)
def gargoyle(c, S, fr):
    st = Mat('#6a6a7a', 'matte', tex=.18); dk = Mat('#4a4a5a', 'matte', tex=.18); up = fr % 2 == 0
    cy = 26 + (0 if up else 2)
    for side in (-1, 1):
        base = (22, cy - 4); tip = (22 + side * 3 - 14, cy + (-18 if up else -4))
        c.poly([base, tip, (tip[0] + 6, tip[1] + 6), (base[0] - 2, cy + 4)], dk, folds=2)
    c.ell((24, cy + 2), 6.5, 7.2, st); c.capsule((20, cy + 8), (18, cy + 15), 2.2, 2.0, dk); c.capsule((27, cy + 8), (29, cy + 15), 2.2, 2.0, st)
    c.ell((28, cy - 6), 4.4, 4.0, st)
    for dx in (-2, 2): c.capsule((28 + dx, cy - 9), (27 + dx * 2.2, cy - 14), 1.0, .3, M['bone'])
    c.ell((30.4, cy - 6.4), .9, .8, Mat('#ffd23f', emit=True)); c.capsule((29, cy - 3.5), (32, cy - 3.6), .5, .5, Mat('#1a1018'))
    c.capsule((29, cy - 1), (34 + (4 if fr == 7 else 0), cy + 3), 1.8, 1.5, st)
def hound(c, S, fr):
    ph = 2 * math.pi * (fr % 6) / 6; fur = Mat('#5a1a1a', 'cloth', tex=.22); dk = Mat('#3a0e10', 'cloth', tex=.2)
    bc = (22, 30 - abs(math.sin(ph)) * 1.5)
    c.capsule((bc[0] - 9, bc[1] - 1), (bc[0] - 15, bc[1] - 6 + math.sin(ph) * 2), 1.6, .8, dk)
    for k, dx in enumerate((-6, 6)):
        a = math.sin(ph + k * math.pi) * 28 * (fr < 6)
        b = (bc[0] + dx - 1, bc[1] + 2); kk = P(b, 6, a); c.capsule(b, kk, 2.2, 1.6, dk); c.capsule(kk, (kk[0] + 1, 43), 1.6, 1.2, dk)
    c.capsule((bc[0] - 8, bc[1]), (bc[0] + 7, bc[1] - 2), 5.0, 6.0, fur)
    for k, dx in enumerate((-5, 7)):
        a = math.sin(ph + k * math.pi + 1) * 28 * (fr < 6)
        b = (bc[0] + dx, bc[1] + 2); kk = P(b, 6, a); c.capsule(b, kk, 2.4, 1.8, fur); c.capsule(kk, (kk[0] + 1.4, 43), 1.8, 1.4, fur)
    hd = (bc[0] + 12 + (3 if fr == 7 else 0), bc[1] - 6)
    c.ell(hd, 4.2, 3.6, fur); c.capsule(hd, (hd[0] + 6, hd[1] + 1.6), 2.6, 1.6, fur)
    c.capsule((hd[0] - 1.5, hd[1] - 2), (hd[0] - 3, hd[1] - 6), 1.2, .3, dk)
    c.ell((hd[0] + 1.6, hd[1] - 1.2), .9, .7, Mat('#ffd23f', emit=True))
    for k in range(3): c.capsule((hd[0] + 3 + k * 1.2, hd[1] + 2.4), (hd[0] + 3 + k * 1.2, hd[1] + 3.6), .3, .2, M['bone'])
def spawn(c, S, fr):
    fl = Mat('#3a6a4a', 'skin', tex=.2); dk = Mat('#2a4a3a', 'skin')
    for k in range(5):
        b = (14 + k * 5, 34); a = 150 + k * 15 + math.sin(fr * 1.3 + k) * 25 + (40 if fr == 7 and k > 2 else 0)
        m1 = P(b, 7, a); m2 = P(m1, 6, a + 30 * math.sin(fr + k))
        c.capsule(b, m1, 1.8, 1.3, dk); c.capsule(m1, m2, 1.3, .5, dk)
    c.ell((24, 36), 11, 7, fl)
    for (x, y, r) in ((20, 34, 1.6), (27, 33, 2.0), (31, 36, 1.2)):
        c.ell((x, y), r, r, Mat('#ffe27a', emit=True)); c.ell((x + .4, y), r * .4, r * .7, Mat('#120a10'))
    c.capsule((18, 39), (30, 39.5), .6, .6, Mat('#120a10'))
def eyeb(c, S, fr):
    y = 22 + math.sin(fr * 1.05) * 2
    for k in range(5):
        b = (18 + k * 3, y + 7); m1 = (b[0] + math.sin(fr + k) * 3, b[1] + 7); m2 = (m1[0] + math.sin(fr * 1.4 + k) * 3, m1[1] + 6)
        c.capsule(b, m1, 1.4, 1.0, Mat('#6a2a4a', 'skin')); c.capsule(m1, m2, 1.0, .4, Mat('#6a2a4a', 'skin'))
    c.ell((24, y), 9, 9, Mat('#e8d8d0', 'skin', spec=.5))
    for k in range(4): c.capsule((17 + k * 2, y - 6 + k), (20 + k * 2, y - 3 + k), .3, .2, Mat('#c83a4a'))
    c.ell((28, y), 4.2, 4.6, Mat('#a8102e', 'gem')); c.ell((29, y), 1.6, 3.0 if fr != 7 else 1.0, Mat('#0a0608'))
def spider(c, S, fr):
    ph = 2 * math.pi * (fr % 6) / 6; ch = Mat('#2a1a2a', 'leather', spec=.3); leg = Mat('#1e121e', 'leather')
    for k in range(4):
        for side, m in ((-1, leg), (1, ch)):
            b = (22 + k * 2, 30); a = 60 + k * 28 + math.sin(ph + k + (side > 0) * math.pi) * 14
            kn = (b[0] + math.sin(R(180 - a)) * 9 * (1 if k > 1 else -1), 22 - k % 2 * 2); ft = (kn[0] + (4 if k > 1 else -4), 43)
            c.capsule(b, kn, 1.1, .9, m); c.capsule(kn, ft, .9, .4, m)
    c.ell((16, 30), 9, 7, ch); for_ = [c.capsule((10 + k * 3, 26), (12 + k * 3, 33), .5, .5, Mat('#8a1a2a')) for k in range(3)]
    c.ell((28, 31), 5, 4.4, ch)
    for (x, y) in ((31, 29), (32.4, 30.6), (30, 30.8)): c.ell((x, y), .7, .7, Mat('#ff2a1a', emit=True))
    c.capsule((32, 33), (34 + (2 if fr == 7 else 0), 35), .6, .3, M['bone'])
def leech(c, S, fr):
    ph = fr * 1.05; seg = Mat('#4a2a36', 'skin', tex=.2, spec=.5); prev = None
    for k in range(7):
        x = 10 + k * 4.4; y = 38 - abs(math.sin(ph + k * .7)) * (4 if fr < 6 else 1) - (6 if fr == 7 and k > 4 else 0)
        c.ell((x, y), 3.6 - abs(k - 3) * .25, 3.0, seg)
    hx_ = 10 + 6 * 4.4; hy = 38 - abs(math.sin(ph + 4.2)) * 4 - (6 if fr == 7 else 0)
    c.ell((hx_ + 2, hy), 2.4, 2.4, Mat('#1a0a10')); 
    for a in range(0, 360, 60): c.capsule((hx_ + 2, hy), (hx_ + 2 + 2.6 * math.cos(math.radians(a)), hy + 2.6 * math.sin(math.radians(a))), .35, .2, M['bone'])
CREATURES = {'leech': leech, 'bat': bat, 'ghost': ghost, 'gargoyle': gargoyle, 'hound': hound, 'spawn': spawn, 'eye': eyeb, 'spider': spider}

# ------------------------------------------------------------------ bosses (128x128, frames: idle0, idle1, attack)
def b_gravelord(c, fr):
    atk = fr == 2; b = fr % 2
    robe = Mat('#2a2432', 'cloth', tex=.1); robe2 = Mat('#1c1824', 'cloth', tex=.1); bone = M['bone']; rot = Mat('#5a6a44', 'skin', tex=.2)
    # scythe behind
    sx = 26 if not atk else 40
    c.capsule((sx, 122), (sx + (8 if not atk else 30), 18 if not atk else 22), 1.6, 1.6, M['wood'])
    top = (sx + (8 if not atk else 30), 18 if not atk else 22)
    blade = [top, (top[0] + 26, top[1] - 2), (top[0] + 38, top[1] + 14), (top[0] + 24, top[1] + 6), (top[0] + 2, top[1] + 6)] if atk else \
            [top, (top[0] - 22, top[1] - 6), (top[0] - 34, top[1] + 10), (top[0] - 20, top[1] + 4), (top[0] - 2, top[1] + 6)]
    c.poly(blade, Mat('#9aa4b4', 'metal'), bevel=(top, blade[2]))
    # robe body
    c.poly([(44, 46 + b), (86, 46 + b), (102, 124), (30, 124)], robe, folds=.55)
    for k in range(7): c.poly([(30 + k * 10, 124), (34 + k * 10, 116), (38 + k * 10, 124)], robe2)
    c.ell((64, 58 + b), 22, 16, robe2)
    for k in range(5): c.capsule((52, 54 + k * 5 + b), (76, 55 + k * 5 + b), 1.2, 1.2, bone)
    c.capsule((64, 50 + b), (64, 80 + b), 2.0, 2.0, bone)
    c.ell((56, 70 + b), 4, 3, rot); c.ell((72, 62 + b), 3, 3, rot)
    for dx in (-20, 20): c.ell((64 + dx, 46 + b), 10, 8, bone); c.ell((64 + dx, 46 + b), 7, 5, Mat('#3a3e48', 'metal'))
    hy = 30 + b + (3 if atk else 0)
    c.ell((66, hy), 13, 14, bone); c.capsule((60, hy + 8), (76, hy + 10), 6, 5, bone)
    for dx in (-4, 6): c.ell((66 + dx, hy - 1), 4, 4.4, M['eye']); c.ell((66 + dx + .5, hy - .5), 1.6, 1.6, Mat('#a6ff2e', emit=True))
    c.poly([(70, hy + 4), (72, hy + 7), (68, hy + 7)], M['eye'])
    for k in range(6): c.capsule((61 + k * 3, hy + 9), (61 + k * 3, hy + 13), .5, .5, M['eye'])
    for k in range(7):
        bx = 52 + k * 4.4; c.poly([(bx - 2, hy - 11), (bx, hy - 22 - (k % 2) * 6), (bx + 2, hy - 11)], M['gold'] if k % 3 == 1 else bone, normal=(.3, -.3, .9))
    c.capsule((52, hy - 11), (80, hy - 11), 1.8, 1.8, M['gold'])
    # arms
    sh = (86, 48 + b); e = (100, 30 if atk else 66); h_ = (108, 18 if atk else 80)
    c.capsule(sh, e, 5, 4.4, robe); c.capsule(e, h_, 3.6, 3, bone)
    for k in range(4): c.capsule(h_, (h_[0] + 4 + k, h_[1] + (-5 if atk else 6) + k), .9, .5, bone)
    if not atk: c.capsule((42, 50 + b), (32, 76), 5, 4.4, robe2); c.capsule((32, 76), (30, 86), 3.4, 2.8, bone)
    for k in range(10): c.ell((24 + k * 9, 124), 5, 2.6, Mat('#5a6a5a'))
def b_countess(c, fr):
    atk = fr == 2; b = fr % 2
    wing = Mat('#24101a', 'cloth'); wing2 = Mat('#4a0e1e', 'cloth'); 
    for side in (-1, 1):
        base = (64 + side * 8, 44); span = 54 if not atk else 58
        tips = [(64 + side * span * (1 - k * .2), 10 + k * 18 - b * 2 - (6 if atk else 0)) for k in range(5)]
        c.poly([base] + tips + [(64 + side * 10, 74)], wing2, normal=(side * .2, -.3, .93), folds=.9)
        for t_ in tips: c.capsule(base, t_, 1.4, .5, wing)
    c.poly([(54, 46), (74, 46), (90, 124), (38, 124)], Mat('#6a0a1a', 'cloth'), folds=.7)
    c.poly([(58, 52), (70, 52), (72, 124), (56, 124)], Mat('#a0102a', 'cloth'), folds=1.2)
    c.capsule((64, 46), (64, 70), 9, 7, Mat('#3a0a14', 'cloth')); c.poly([(60, 44), (68, 44), (64, 52)], Mat('#e8e0e8', 'skin'))
    c.poly([(50, 40), (78, 40), (72, 50), (56, 50)], Mat('#120a10', 'leather'))
    for dx in (-14, 14): c.ell((64 + dx, 44), 5, 4, Mat('#3a0a14', 'cloth'))
    hy = 30 + b
    c.capsule((58, hy - 2), (54, hy + 16), 5, 4, Mat('#140a14')); c.capsule((70, hy - 2), (74, hy + 16), 5, 4, Mat('#140a14'))
    c.ell((64, hy), 8, 10, Mat('#ece4ec', 'skin'))
    c.ell((64, hy - 7), 9, 5, Mat('#140a14'), cut=lambda X, Y: Y < hy - 3)
    for dx in (-3.4, 3.4): c.ell((64 + dx, hy), 1.6, 1.2, Mat('#ff1a1a', emit=True))
    c.capsule((61, hy + 6), (67, hy + 6), .7, .7, Mat('#7a0a1a')); c.capsule((62, hy + 6.5), (62, hy + 8), .4, .2, M['bone']); c.capsule((66, hy + 6.5), (66, hy + 8), .4, .2, M['bone'])
    for k in range(5): c.poly([(56 + k * 4, hy - 10), (58 + k * 4, hy - 16 - (k % 2) * 4), (60 + k * 4, hy - 10)], M['gold'], normal=(.3, -.3, .9))
    hand = (96, 40) if atk else (84, 76)
    c.capsule((74, 48), hand, 3, 2.4, Mat('#3a0a14', 'cloth')); c.ell(hand, 2.4, 2.4, Mat('#e8e0e8', 'skin'))
    if atk:
        for k in range(5): c.ell((104 + k * 4, 36 + (k % 2) * 6), 2.4, 1.6, Mat('#c8102e', emit=True))
def b_maw(c, fr):
    atk = fr == 2; b = fr % 2
    fl = Mat('#3a2a4a', 'skin', tex=.18); fl2 = Mat('#5a3a6a', 'skin', tex=.15); tm = Mat('#4a2a52', 'skin', tex=.15)
    for k in range(8):
        bx = 12 + k * 14; ph = k * 1.3 + fr * 1.1; pts = [(bx, 126)]
        for j in range(1, 6): pts.append((bx + math.sin(ph + j * .9) * (6 + j), 126 - j * (17 if not (atk and k % 2) else 21)))
        for j, (a, bb) in enumerate(zip(pts, pts[1:])): c.capsule(a, bb, 5 - j * .8, 4.2 - j * .8, tm if k % 2 else fl)
        for (x, y) in pts[2:]: c.ell((x + 2, y), 1, 1, Mat('#c050a0', 'skin'))
    c.ell((64, 84), 44, 34, fl); c.ell((64, 76), 36, 22, fl2, cut=lambda X, Y: Y < 80)
    mh = 13 if not atk else 20
    c.ell((64, 92 + b), 26, mh, Mat('#140810'))
    for k in range(13):
        x = 42 + k * 3.6; c.poly([(x - 1.6, 92 + b - mh * .8), (x, 92 + b - mh * .8 + 6), (x + 1.6, 92 + b - mh * .8)], M['bone'], normal=(0, -.4, .9))
        c.poly([(x - 1.6, 92 + b + mh * .85), (x, 92 + b + mh * .85 - 6), (x + 1.6, 92 + b + mh * .85)], M['bone'], normal=(0, .3, .9))
    for (x, y, r) in ((44, 64, 6), (64, 58, 8), (84, 64, 6), (54, 72, 3.4), (74, 72, 3.4), (34, 76, 3), (94, 76, 3)):
        c.ell((x, y), r, r, Mat('#f0e8d8', 'skin', spec=.5)); c.ell((x + (1 if b else -.5), y), r * .5, r * .6, Mat('#c8102e', 'gem')); c.ell((x + (1 if b else -.5), y), r * .2, r * .45, Mat('#0a0608'))
BOSSES = {'gravelord': b_gravelord, 'countess': b_countess, 'maw': b_maw}
def render_boss(k):
    frames = []
    for fr in range(3):
        c = Canvas(128, 128); BOSSES[k](c, fr); frames.append(c.finish())
    frames = quantize(frames, 40)
    return [outline_sel(f)[:, ::-1].copy() for f in frames]   # face left toward the heroes

def render_set(S, w=64, h=64, ncol=20, flip=False):
    if isinstance(S, str):
        fr = render({}, 48, 48, 22, drawer=CREATURES[S])
    elif isinstance(S, dict) and S.get('_d'):
        fr = render(S, w, h, ncol, drawer=S['_d'])
    elif isinstance(S, list):
        fr = render(S, 80, h, ncol)
    else: fr = render(S, w, h, ncol)
    if flip: fr = [f[:, ::-1].copy() for f in fr]
    return fr

if __name__ == '__main__' and len(sys.argv) == 1:
    rows = []
    for k, S in HEROES.items(): rows.append((k, render_set(S)))
    for k, S in ENEMIES.items(): rows.append((k, render_set(S, flip=True)))
    for k in CREATURES: rows.append((k, render_set(k, flip=True)))
    bim = Image.new('RGBA', (128 * 9, 128), (46, 36, 56, 255))
    for n, k in enumerate(BOSSES):
        for j, f in enumerate(render_boss(k)): bim.alpha_composite(Image.fromarray(f), ((n * 3 + j) * 128, 0))
    bim.resize((128 * 9 * 2, 256), Image.NEAREST).save('/tmp/claude-0/bosses.png')
    W = 6 * 84; im = Image.new('RGBA', (W, 70 * ((len(rows) + 1) // 2)), (46, 36, 56, 255))
    for n, (k, fr) in enumerate(rows):
        x0 = (n % 2) * (W // 2); y0 = (n // 2) * 70
        for j, f in enumerate((fr[0], fr[2], fr[7])):
            im.alpha_composite(Image.fromarray(f), (x0 + j * 84, y0))
    im.resize((W * 2, im.size[1] * 2), Image.NEAREST).save('/tmp/claude-0/lineup.png')

def pack():
    rig.RES = 2
    items = []
    for k, S in HEROES.items():
        items.append(('h_' + k, render_set(S)))
        if isinstance(S, list):
            for j, part in enumerate(S): items.append((f'h_{k}_{"ab"[j]}', render_set(part)))
    for k, S in ENEMIES.items(): items.append(('e_' + k, render_set(S, flip=True)))
    for k in CREATURES: items.append(('e_' + k, render_set(k, flip=True)))
    for k in BOSSES: items.append(('b_' + k, render_boss(k)))
    Wd = 4096; x = y = rowh = 0; atlas = {}; placed = []
    for name, frs in items:
        fh, fw = frs[0].shape[:2]; tot = fw * len(frs)
        if x + tot > Wd: x = 0; y += rowh; rowh = 0
        atlas[name] = [x, y, fw, fh, len(frs)]; placed.append((x, y, frs)); x += tot; rowh = max(rowh, fh)
    sheet = Image.new('RGBA', (Wd, y + rowh))
    for (x0, y0, frs) in placed:
        for i, f in enumerate(frs): sheet.alpha_composite(Image.fromarray(f), (x0 + i * f.shape[1], y0))
    sheet.save('/home/claude/pod2/crawl.png', optimize=True)
    json.dump(dict(sprites=atlas, bg={}, res=2), open('/home/claude/pod2/crawl_atlas.json', 'w'))
    import subprocess; subprocess.run(['python3', '/home/claude/pod2/make_crawl_bg2.py'], check=True)   # backdrops come from the Ansimuz packs
    print('sprites', sheet.size)
if len(sys.argv) > 1 and sys.argv[1] == 'pack': pack()
