"""Five 0-life faces for the life tracker (row 5, columns 2-6 of faces.png), all in the chunky doubled-pixel style:
2 skull and crossbones, 3 pile of bones, 4 rotting zombie head, 5 half-skull (face peeled away), 6 tombstone."""
from PIL import Image
import numpy as np, random, subprocess
subprocess.run(['python3', 'make_skull.py'], check=True); subprocess.run(['python3', 'make_bonepile.py'], check=True)
SRC='/mnt/user-data/attachments/6734f136-843c-56b4-843a-aebc7f6c2c50/601bceb5-image.png'
rows=[(3, 65), (69, 131), (135, 197), (201, 263), (267, 330), (333, 395)]
cols=[(4, 52), (56, 104), (108, 156), (160, 208), (212, 260), (264, 312), (316, 376), (380, 436)]
src=Image.open(SRC).convert('RGBA')
def cut(r,c):
    (y0,y1),(x0,x1)=rows[r],cols[c];cell=src.crop((x0-2,y0-2,x1+2,y1+2));a=np.array(cell);h,w=a.shape[:2]
    light=(a[:,:,:3].astype(int).min(2)>185);seen=np.zeros((h,w),bool);st=[(y,x) for y in range(h) for x in (0,w-1)]+[(y,x) for x in range(w) for y in (0,h-1)]
    while st:
        y,x=st.pop()
        if 0<=y<h and 0<=x<w and not seen[y,x] and light[y,x]: seen[y,x]=True;st+=[(y+1,x),(y-1,x),(y,x+1),(y,x-1)]
    a[seen,3]=0;return a
def sockets(a,cx_list,cy,rx,ry,col=(14,6,4)):
    h,w=a.shape[:2]
    for y in range(h):
        for x in range(w):
            for cx in cx_list:
                if ((x-cx)/rx)**2+((y-cy)/ry)**2<=1 and a[y,x,3]: a[y,x,:3]=col
random.seed(3)
# 4: rotting zombie: the bloodiest face, skin turned sickly green, hollow eyes, rot spots
z=cut(2,4).astype(int);h,w=z.shape[:2]
r,g,b=z[:,:,0],z[:,:,1],z[:,:,2]
red=(r>g+70)&(r>110)
skin=(r>=120)&(r>g)&(g>b)&~red
z[:,:,0]=np.where(red,96,np.where(skin,(r*0.62).astype(int),r));z[:,:,1]=np.where(red,40,np.where(skin,np.clip(g*0.92+18,0,255).astype(int),g));z[:,:,2]=np.where(red,22,np.where(skin,(b*0.5).astype(int),b))
z=z.astype(np.uint8);sockets(z,[w*0.36,w*0.64],h*0.44,w*0.085,h*0.055)
for _ in range(10):
    x,y=random.randint(int(w*.22),int(w*.78)),random.randint(int(h*.3),int(h*.85))
    if z[y,x,3] and z[y:y+2,x:x+2,3].all(): z[y:y+2,x:x+2,:3]=random.choice([(70,90,24),(48,60,18),(170,180,90)])
for y in range(int(h*.68),int(h*.75)):   # rotten grin
    for x in range(int(w*.36),int(w*.64)):
        if z[y,x,3]: z[y,x,:3]=(30,20,10) if (x%3==0 or y==int(h*.68)) else (200,190,140)
Z=Image.fromarray(z)
# 5: half skull: right half of the face peeled back to bone
hs=cut(3,4).astype(int);h,w=hs.shape[:2]
lum=(hs[:,:,0]*.3+hs[:,:,1]*.59+hs[:,:,2]*.11)
for y in range(h):
    for x in range(w):
        if hs[y,x,3] and x>w*0.5+ (2 if (y//3)%2 else -1):
            v=lum[y,x];hs[y,x,:3]=(250,240,212) if v>150 else (222,204,160) if v>110 else (176,150,104) if v>70 else (122,98,62)
hs=hs.astype(np.uint8);sockets(hs,[w*0.65],h*0.43,w*0.1,h*0.07)
for y in range(int(h*.66),int(h*.74)):
    for x in range(int(w*.52),int(w*.72)):
        if hs[y,x,3]: hs[y,x,:3]=(36,18,8) if x%3==0 else (240,230,200)
for y in range(h):   # torn edge in blood red
    x=int(w*0.5)+(2 if (y//3)%2 else -1)
    if 0<=x<w and hs[y,x,3]: hs[y,x,:3]=(150,14,14)
HS=Image.fromarray(hs)
# 6: tombstone with RIP, moss and a bone in the dirt
W,H=24,30;PAL={'K':(36,18,8),'S':(150,150,158),'s':(110,110,120),'G':(196,196,204),'g':(70,72,80),'m':(80,130,30),'d':(74,48,24),'D':(52,32,14),'L':(222,204,160),'M':(176,150,104)}
cv=[[None]*W for _ in range(H)]
for y in range(H):
    for x in range(W):
        if 4<=x<=19 and 6<=y<=25 and (y>=11 or ((x-11.5)/8)**2+((y-11)/5.3)**2<=1):
            v=(x-4)*0.06+(y-6)*0.03+random.uniform(-.12,.12);cv[y][x]='G' if v<.35 else 'S' if v<.8 else 's'
        if 25<=y<=29 and ((x-11.5)/12)**2+((y-29)/4.2)**2<=1: cv[y][x]='d' if random.random()<.75 else 'D'
LET={'R':["##.","#.#","##.","#.#","#.#"],'I':["#","#","#","#","#"],'P':["##.","#.#","##.","#..","#.."]}
ox=7
for ch in 'RIP':
    for yy,row in enumerate(LET[ch]):
        for xx,c in enumerate(row):
            if c=='#': cv[12+yy][ox+xx]='g'
    ox+=len(LET[ch][0])+1
for (x,y) in [(5,22),(6,23),(5,24),(18,20),(19,21),(18,22),(17,24),(6,15),(5,16)]: cv[y][x]='m'
for x in range(6,12): cv[27][x]='L' if x%2 else 'M'
cv[26][5]=cv[28][5]=cv[26][12]=cv[28][12]='L'
out=[row[:] for row in cv]
for y in range(H):
    for x in range(W):
        if cv[y][x] and cv[y][x] not in 'dD' :
            for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)):
                nx,ny=x+dx,y+dy
                if not(0<=nx<W and 0<=ny<H) or cv[ny][nx] is None: out[y][x]='K';break
t=np.zeros((H,W,4),np.uint8)
for y in range(H):
    for x in range(W):
        if out[y][x]: t[y,x]=(*PAL[out[y][x]],255)
TOMB=Image.fromarray(t).resize((W*2,H*2),Image.NEAREST)
# paste into the sheet
sheet=Image.open('faces.png').convert('RGBA');CW,CH=60,64
for c in range(2,8): sheet.paste(Image.new('RGBA',(CW,CH),(0,0,0,0)),(c*CW,5*CH))
for c,im in zip(range(2,7),[Image.open('skull_face.png').convert('RGBA'),Image.open('bonepile_face.png').convert('RGBA'),Z,HS,TOMB]):
    sheet.paste(im,(c*CW+(CW-im.width)//2,5*CH+(CH-im.height)//2),im)
sheet.quantize(colors=256,method=Image.Quantize.FASTOCTREE).save('faces.png',optimize=True)
prev=Image.new('RGBA',(CW*5,CH),(42,42,42,255));prev.alpha_composite(sheet.crop((2*CW,5*CH,7*CW,6*CH)))
prev.resize((CW*5*4,CH*4),Image.NEAREST).save('/tmp/claude-0/deaths.png')
