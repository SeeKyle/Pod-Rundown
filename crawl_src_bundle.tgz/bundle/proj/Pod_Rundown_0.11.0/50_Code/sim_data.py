"""Pod Sim card data (0.10.17): every deck's real list, boiled down to what the browser sim needs.
Built from the same tags the ratings use, so the sim plays each card the way it's scored."""
import re, json
import score

PT = json.load(open('/home/claude/pod2/pt.json'))

def _num(pat, s, d=0.0):
    m = re.search(pat, s)
    return float(m.group(1)) if m else d

def card_row(c, tough=False):
    row = dict(n=c['name'].split(' // ')[0], mv=int(c['mv']), t=c['type'][:1])
    pt = PT.get(c['name'])
    veh = 'Vehicle' in (score.CT_.get(c['name'], '').split('\n')[1] if '\n' in score.CT_.get(c['name'], '') else '')
    if (c['type'] == 'Creature' or veh) and pt:
        try:
            row['p'] = int(pt[0])
            if tough and int(pt[1]) > int(pt[0]): row['tp'] = int(pt[1])
        except Exception: row['p'] = 3
        if veh: row['v'] = 1
    if re.search(r'rather than pay the equip cost|[Ee]quip abilities you activate.{0,60}cost \{\d\} less|attach any number of target Equipment', score.CT_.get(c['name'], ''), re.S): row['fe'] = 1
    for e in c['entries']:
        k, lab, pts = e.get('kind'), e['label'], e['pts']
        if k == 'ramp':
            amt = e.get('amount', 1)
            if e.get('rkind') == 'E': row['r'] = row.get('r', 0) + amt
            elif e.get('rkind') == 'L': row['rl'] = row.get('rl', 0) + amt
            else: row['rt'] = row.get('rt', 0) + amt
        elif k == 'cheat':
            row['ch'] = 1
        elif k == 'draw':
            a = _num(r'Draw \(([\d.]+)', lab, 1)
            if '/turn' in lab: row['de'] = round(row.get('de', 0) + min(a, 2) * 0.6, 2)
            else: row['d'] = row.get('d', 0) + a
        elif k in ('tutor', 'select'):
            row['d'] = row.get('d', 0) + 0.5
        elif k == 'wide':
            a = _num(r'Wide \(([\d.]+)', lab, 2)
            if '/turn' in lab: row['we'] = row.get('we', 0) + a
            else: row['w'] = row.get('w', 0) + a
        elif k == 'board' and not e.get('pump'):
            row['b'] = row.get('b', 0) + _num(r'\(\+([\d.]+)', lab, 1)
        elif k == 'board' and e.get('pump'):
            row['u'] = row.get('u', 0) + _num(r'\(\+([\d.]+)', lab, 2)
            if 'Equipment' in lab: row['eq'] = int(round(e.get('eqpen', 0) / 0.05)) + 2
        elif k == 'evasive':
            row['ev'] = max(row.get('ev', 0), {'unblock': 1, 'shadow': .8, 'fly': .7, 'menace': .6, 'trample': .5, 'walk': .4}.get(e.get('ev', 'fly'), .5))
        elif k == 'givesev':
            row['ge'] = max(row.get('ge', 0), _num(r'x ([\d.]+)\)', lab, .5))
        elif k == 'drain':
            row['dr'] = row.get('dr', 0) + _num(r'Drain \(([\d.]+)', lab, 2)
        elif k == 'finish' and pts > 0.15 and 'Suit Up' not in lab:
            row['f'] = max(row.get('f', 0), _num(r'\(([\d.]+)\) \(MV', lab, 10) or 10)
            row['ft'] = {'Burst': 'B', 'Alt Win': 'A', 'Combo Piece': 'A', 'Extra Combat': 'C', 'Extra Turn': 'C', 'Damage Doubler': 'D', 'Overrun': 'O'}.get(e.get('ftype'), 'B')
        elif k == 'answer' and pts > 0.05:
            if e.get('wipe'):
                row['x'] = 2
                if e.get('oneside'): row['xo'] = e['oneside']
            elif 'c' in e.get('kinds', 'c') or e.get('atype') == 'Removal': row['x'] = max(row.get('x', 0), 1)
        elif k == 'survive' and e.get('part') == 'Protect':
            row['pr'] = 1
    return row

def build():
    info = score.load_info()
    out = {}
    for k in score.DECKS:
        r = score.score_deck(k, info)
        M = r['meta']
        lands = sum(1 for c in r['cards'] if c['is_land'])
        tg = M.get('sim_tough', False)   # creatures deal damage by toughness (Felothar)
        cm = [card_row(c, tg) for c in r['cards'] if c['commander']]
        lib = [card_row(c, tg) for c in r['cards'] if not c['is_land'] and not c['commander']]
        out[M['deck']] = dict(lands=lands, cmdr=cm, lib=lib, tough=1 if tg else 0)
    return out

if __name__ == '__main__':
    d = build()
    s = json.dumps(d, ensure_ascii=False, separators=(',', ':'))
    print(len(s))
    print(d['Tame Depala']['cmdr'], d['Tame Depala']['lib'][:6])
