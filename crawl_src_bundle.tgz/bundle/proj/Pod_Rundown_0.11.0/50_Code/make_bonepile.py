"""Pixel pile of bones (alternative 0-life face), same 24x30 doubled style as make_skull.py.
Each bone is drawn back to front with its own outline so the pile reads as separate bones."""
from PIL import Image
import numpy as np, random
random.seed(5)
W,H=24,30
PAL={'K':(36,18,8),'D':(122,98,62),'M':(176,150,104),'L':(222,204,160),'W':(250,240,212),'E':(14,6,4),'R':(170,16,16),'r':(96,8,8)}
canvas=[[None]*W for _ in range(H)]
def seg_d(x,y,x0,y0,x1,y1):
    t=max(0,min(1,((x-x0)*(x1-x0)+(y-y0)*(y1-y0))/((x1-x0)**2+(y1-y0)**2)))
    return ((x-(x0+t*(x1-x0)))**2+(y-(y0+t*(y1-y0)))**2)**.5
def draw(mask_fn, shade_fn):
    m=[[mask_fn(x,y) for x in range(W)] for y in range(H)]
    for y in range(H):
        for x in range(W):
            if m[y][x]: continue
            if any(0<=x+dx<W and 0<=y+dy<H and m[y+dy][x+dx] for dx,dy in ((1,0),(-1,0),(0,1),(0,-1))): canvas[y][x]='K'
    for y in range(H):
        for x in range(W):
            if m[y][x]: canvas[y][x]=shade_fn(x,y)
def bone(x0,y0,x1,y1):
    def mk(x,y): return seg_d(x,y,x0,y0,x1,y1)<=1.05 or (x-x0)**2+(y-y0)**2<=1.9 or (x-x1)**2+(y-y1)**2<=1.9
    def sh(x,y):
        # light on the upper side of the bone, darker underneath
        nx,ny=-(y1-y0),(x1-x0);L=(nx*nx+ny*ny)**.5;side=((x-x0)*nx+(y-y0)*ny)/L
        if ny>0: side=-side
        v=side+random.uniform(-.25,.25)
        return 'W' if v<-.7 else 'L' if v<.2 else 'M' if v<.8 else 'D'
    draw(mk,sh)
for b in [(2,28,12,22),(21,28,11,21),(1,24,10,28),(14,29,23,24),(5,20,19,27),(19,19,6,27),(3,22,15,18),(20,22,9,17)]:
    bone(*b)
# skull on top of the pile
def sk(x,y):
    return (((x-12)/6.6)**2+((y-9.5)/6.2)**2<=1 and y<=13) or (8<=x<=15 and 12<=y<=16)
def sksh(x,y):
    v=(x-6)*0.07+(y-4)*0.08+random.uniform(-.08,.08)
    return 'W' if v<.25 else 'L' if v<.75 else 'M' if v<1.05 else 'D'
draw(sk,sksh)
for y in range(H):
    for x in range(W):
        if not sk(x,y): continue
        if ((x-9.3)/1.9)**2+((y-9.5)/1.8)**2<=1 or ((x-14.7)/1.9)**2+((y-9.5)/1.8)**2<=1: canvas[y][x]='E'
        if x==12 and 11<=y<=12: canvas[y][x]='E'
        if y==14 and 9<=x<=14 and x%2==0: canvas[y][x]='K'
        if y==16: canvas[y][x]='M'
for (x,y) in [(9,12),(9,13),(10,13),(15,12),(15,13),(12,4),(12,5),(13,5),(7,23),(16,26)]:
    if canvas[y][x] and canvas[y][x] not in 'EK': canvas[y][x]='R' if (x+y)%3 else 'r'
img=np.zeros((H,W,4),np.uint8)
for y in range(H):
    for x in range(W):
        if canvas[y][x]: img[y,x]=(*PAL[canvas[y][x]],255)
Image.fromarray(img).resize((W*2,H*2),Image.NEAREST).save('bonepile_face.png')
