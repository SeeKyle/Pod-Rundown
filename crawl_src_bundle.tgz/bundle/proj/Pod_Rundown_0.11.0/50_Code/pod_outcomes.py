"""Pod Sim outcomes (0.10.19): turns the simulated games (every 4-deck pod x 100 games, run with the real decklists
by the card-level engine) into the outcome list the site picks from.
Each kept outcome: [winner, [1st out, 2nd out, 3rd out], [killer of each], game turns, [KO turn of each],
times seen, commander-damage KO, went to time, pick weight].
Calibration: the engine is rough (it over-rewards some decks and under-rewards others), so each winner's weight is
scaled by how its overall sim win rate compares with what its rating predicts. Matchup texture stays from the sims."""
import json, math, sys

def build(src='/tmp/claude-0/outcomes.json', data='/home/claude/pod2/data.json', out='/home/claude/pod2/pod_outcomes.json', keep=7):
    o = json.load(open(src)); N = o['names']; G = o['G']
    tot = {r['deck']: float(r['total']) for r in json.load(open(data))['decks']}
    wins = {n: 0 for n in N}; games = {n: 0 for n in N}; expect = {n: 0.0 for n in N}
    for key, v in o['pods'].items():
        ids = list(map(int, key.split(',')))
        ex = [math.exp(tot[N[i]] / 12) for i in ids]; s = sum(ex)
        for i, e in zip(ids, ex):
            games[N[i]] += G; expect[N[i]] += G * e / s
        for w, c in v['w'].items(): wins[N[int(w)]] += c
    cal = {n: max(0.25, min(8.0, (expect[n] / games[n]) / max(0.002, wins[n] / games[n]))) for n in N}
    pods = {}
    for key, v in o['pods'].items():
        lst = []
        for x in v['o']:
            x = list(x) + [round(x[5] * cal[N[x[0]]], 2)]
            lst.append(x)
        lst.sort(key=lambda x: -x[8])
        pods[key] = lst[:keep]
    res = dict(names=N, G=G, pods=pods)
    json.dump(res, open(out, 'w'), separators=(',', ':'), ensure_ascii=False)
    return res, cal, wins, games, expect

if __name__ == '__main__':
    res, cal, wins, games, expect = build()
    for n in sorted(cal, key=lambda n: -wins[n] / games[n]):
        print(f"{n:30} sim {100*wins[n]/games[n]:5.1f}%  rating-expected {100*expect[n]/games[n]:5.1f}%  x{cal[n]:.2f}")
    print('bytes', len(open('/home/claude/pod2/pod_outcomes.json').read()))
