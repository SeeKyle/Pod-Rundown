import ast, sys
def add(key, card, extra):
    fn = f'decks/{key}.py'; src = open(fn).read(); tree = ast.parse(src)
    lines = src.split('\n')
    for node in ast.walk(tree):
        if isinstance(node, ast.Dict):
            for k, v in zip(node.keys, node.values):
                if isinstance(k, ast.Constant) and k.value == card:
                    # end of call: insert before last ')'
                    ln, col = v.end_lineno - 1, v.end_col_offset - 1
                    line = lines[ln]
                    assert line[col] == ')', (card, line)
                    lines[ln] = line[:col] + ', ' + extra + line[col:]
                    open(fn, 'w').write('\n'.join(lines)); return
    raise KeyError((key, card))
