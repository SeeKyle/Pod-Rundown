import json, sys
sys.path.insert(0, '/home/claude/pod2')
from takeaways_text import TEXTS
from build_data import build
d, res, divs = build(TEXTS)
json.dump(d, open('/home/claude/pod2/data.json', 'w'), ensure_ascii=False)
t = open('/home/claude/pod2/template.html').read()
a = t.index("      <h2>What's new</h2>"); b = t.index('    </section>\n  </div>\n</div>\n\n<script>')
t = t[:a] + open('/home/claude/pod2/notes.html').read() + t[b:]
for x, y in [('<span class="ico">⏱️</span>Clock', '<span class="ico">🏁</span>Finish'),
             ('["clock","⏱️","Clock"]', '["clock","🏁","Finish"]'),
             ('Commanders score like any card, then get their Game Plan multiplier.', 'Commanders score like any card (no multiplier).'),
             ("· ⛔ Cheez's decks", "· Cheez = 🧀"), ("' ⛔'", "' 🧀'")]:
    assert x in t, x; t = t.replace(x, y)
import re as _re
t = _re.sub(r"(\w)\.owner==='Cheez'\?' 🧀':''", lambda m: f"{m.group(1)}.owner==='Cheez'?' 🧀':{m.group(1)}.owner==='Leon'?' 🪼':''", t)
t = t.replace("· Cheez = 🧀", "· Cheez = 🧀 · Leon = 🪼")
from stat_page import STATDOCS, RATING_MATH
t = t.replace('__STATDOCS__', json.dumps(dict(stats=STATDOCS, math=RATING_MATH), ensure_ascii=False).replace('</', '<\\/'))
from story_kit import KIT, PAIR
t = t.replace('__STORYKIT__', json.dumps(dict(KIT, __pair=PAIR), ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/'))
t = t.replace('__OUTCOMES__', open('/home/claude/pod2/pod_outcomes.json').read().replace('</', '<\\/'))
t = t.replace('__DATA__', json.dumps(d, ensure_ascii=False).replace('</', '<\\/'))
open('/home/claude/pod2/index.html', 'w').write(t)
for k in d['takeaways']: print(k['deck'], [(x['card'], x['read']) for x in k['repair']])
