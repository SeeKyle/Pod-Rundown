"""Pod Rundown 0.10 card formulas. Every helper returns a list of
(stat, points, label) entries for one card. Points are pre-divide."""

STATS = ['mana', 'cards', 'consistency', 'threats', 'finish', 'reach',
         'interaction', 'survival', 'politics']
CF = {1: 0.0, 2: 0.5, 3: 0.75, 4: 1.0, 5: 1.0}   # color factor

def _mvp(mv, rate, floor=1):
    return rate * max(0, mv - floor)

def E(stat, pts, label, **meta):
    d = {'stat': stat, 'pts': round(max(0.0, pts), 3), 'label': label}
    d.update(meta)
    return d

# ---------------- MANA ----------------
def ramp(amt, mv, imm=0, nc=0, color=0, mixed=0, land=0, kind='E', boost=False, label=None):
    s = 0.5 + 0.5 * amt + 0.25 * imm + 0.25 * nc
    if not boost:
        s += [0, 0.25, 0.5][color] + 0.25 * mixed + 0.25 * land
    s -= _mvp(mv, 0.25)
    s *= {'E': 1.0, 'L': 0.75, 'T': 0.5}[kind]
    lab = label or (f"Ramp{' (Boost)' if boost else ''} ({amt:g}) (MV:{mv})"
                    + {'E': '', 'L': ' One-Off Lasting', 'T': ' One-Off Temporary'}[kind])
    return [E('mana', s, lab, kind='ramp', amount=amt, rkind=kind, landramp=land)]

def fixing(extra, colors, label='Fixing'):
    return [E('mana', min(1.0, 0.4 * extra * CF[colors]), label, kind='fixing')]

def cheat(avg, pay, mv, choose=0, stays=1, kind='E', odds=1.0, eng=0, label=None):
    """odds: chance the free-play mode happens (0.5 when an opponent picks, e.g. a villainous choice).
    eng: repeats every turn (an engine that keeps putting plan cards into play)."""
    s = 0.5 + 0.25 * max(0, avg - pay) + 0.25 * choose + 0.25 * stays - _mvp(mv, 0.25)
    s *= {'E': 1.0, 'L': 0.75, 'T': 0.5}[kind] * odds
    o = f' ({int(odds*100)}% odds)' if odds < 1 else ''
    return [E('mana', s, label or f"Cheat{' Engine' if eng else ''} (Avg MV:{avg:g}) (MV:{mv}){o}", kind='cheat', odds=odds, eng=eng)]

def land(extra, colors, entry='U', flex=0, typed=0, life=0, label=None):
    """entry: 'U', 'T' or a float chance of entering untapped."""
    s = 0.4 * extra * CF[colors] + 0.15 * flex + 0.05 * typed - 0.05 * life
    mult = 1.0 if entry == 'U' else 0.5 if entry == 'T' else 0.5 + 0.5 * entry
    s = min(1.0, max(0.0, s) * mult)
    e = 'Untapped' if entry == 'U' else 'Tapped' if entry == 'T' else f'Untapped ({int(entry*100)}%)'
    return [E('mana', s, label or f'Land (Colors:+{extra}) {e}', kind='land', entry=entry, fix=extra > 0)]

# ---------------- CARDS ----------------
def draw(amt, mv, eng=0, imm=0, nc=1, src='H', free=0, wheel=0, thisturn=0, restr=0,
         sym=0, sym_ok=0, label=None):
    s = 0.25 + 0.5 * amt + 0.75 * eng + 0.25 * imm + 0.25 * nc
    s += {'H': 0, 'S': 0.25, 'O': 0.5}[src] + 0.25 * free + 0.5 * wheel
    s -= 0.5 * thisturn + 0.25 * restr + _mvp(mv, 0.25)
    if sym and not sym_ok:
        s *= 0.75
    if not eng:
        s *= 0.75
    src_name = {'H': 'Hand', 'S': 'Second Hand', 'O': 'Opponent Gas'}[src]
    return [E('cards', s, label or f"Draw ({amt:g}{'/turn' if eng else ''}) (MV:{mv}) {src_name}", kind='draw')]

# ---------------- CONSISTENCY ----------------
def tutor(dest, reach, mv, inst=0, nc=1, eng=0, slow=0, count=1, label=None):
    # 0.10.1: 'gy' (to the graveyard, in decks that use it from there) is worth the same as hand;
    # +0.25 for each extra card found
    s = 0.25 + {'top': 0.25, 'hand': 0.5, 'gy': 0.5, 'bf': 0.75}[dest] + {'n': 0, 't': 0.25, 'a': 1.0}[reach]
    s += 0.25 * max(0, count - 1)
    s += 0.25 * inst + 0.25 * nc + 0.75 * eng - 0.25 * slow - _mvp(mv, 0.25)   # 0.10.2 trial: was 0.5 per MV
    if not eng:
        s *= 0.75
    r = {'n': 'Narrow', 't': 'Type', 'a': 'Any'}[reach]
    return [E('consistency', s, label or f'Tutor ({r}) (MV:{mv})', kind='tutor')]

def select(mv, scry=0, dig=0, loot=0, inst=0, nc=1, eng=0, slow=0, onland=0, label=None):
    s = 0.25 + 0.15 * scry + 0.05 * dig + 0.25 * loot + 0.25 * inst + 0.25 * nc
    s += 0.75 * eng - 0.25 * slow - _mvp(mv, 0.5)
    if not eng:
        s *= 0.75
    if onland:
        s *= 0.5
    n = scry + dig + loot
    return [E('consistency', s, label or f'Select ({n:g}) (MV:{mv})', kind='select')]

# ---------------- THREATS ----------------
def tall(power, mv, lvl=0, hard=0, haste=0, cond=1.0, label=None):
    if power < 4 and lvl != 'B':
        return []
    s = 0.05 + 0.15 * power + {0: 0, 'P': 0.25, 'B': 0.5}[lvl] + 0.25 * hard + 0.25 * haste
    s = (s - _mvp(mv, 0.08, floor=3)) * cond   # 0.10.12: -0.08 per mana above 3 (was -0.10 above 1)
    tag = {0: '', 'P': ' Pressure', 'B': ' Bomb'}[lvl]
    return [E('threats', s, label or f'Threat: Tall ({power:g}){tag} (MV:{mv})', kind='tall', bomb=lvl == 'B')]

def nc_threat(mv, lvl='P', label=None):
    s = 0.05 + {'P': 0.25, 'B': 0.5}[lvl] - _mvp(mv, 0.10)
    return [E('threats', s, label or f"Threat: Must-Answer ({'Bomb' if lvl=='B' else 'Pressure'}) (MV:{mv})", kind='ncthreat')]

def wide(power, mv, eng=0, cost=0, label=None):
    s = 0.05 + 0.25 * power + 0.5 * eng - 0.25 * cost - _mvp(mv, 0.10)
    if not eng:
        s *= 0.75
    return [E('threats', s, label or f"Threat: Wide ({power:g}{'/turn' if eng else ''}) (MV:{mv})", kind='wide')]

def board(boost, creatures, mv, oneoff=0, cond=1.0, label=None):
    s = (0.05 + 0.10 * min(20, boost * creatures) - _mvp(mv, 0.10)) * cond
    if oneoff:
        s *= 0.75
    return [E('threats', s, label or f'Threat: Board Power (+{boost:g} x {creatures:g}) (MV:{mv})', kind='board')]

# ---------------- FINISH ----------------
def _dmg(d):
    d = min(d, 60)
    return 0.06 * min(d, 20) + 0.03 * max(0, d - 20)

def finish(typ, amt, mv, eng=0, inst=0, again=0, sym=0, cond=1.0, label=None):
    s = 0.05
    if typ == 'Alt Win':
        s += 1.5
    elif typ == 'Combo Piece':
        s += 0.5
    else:
        s += _dmg(amt)
    if typ == 'Extra Turn':
        s += 0.75
    if typ == 'Burst':
        s += 0.30
    s += 0.5 * eng + 0.25 * inst - 0.25 * again - _mvp(mv, 0.10)
    if sym:
        s *= 0.75
    s *= cond
    a = '' if typ in ('Alt Win', 'Combo Piece') else f' ({amt:g})'
    return [E('finish', s, label or f'Finish ({typ}){a} (MV:{mv})', kind='finish', ftype=typ)]

# ---------------- REACH ----------------
EV = {'unblock': 1.0, 'shadow': 0.8, 'fly': 0.7, 'menace': 0.6, 'trample': 0.5, 'walk': 0.4}

def evasive(power, ev, two=0, label=None):
    lvl = EV[ev] + 0.1 * two
    s = 0.05 + 0.10 * power * lvl
    return [E('reach', s, label or f'Reach: Evasive ({power:g} x {lvl:g})', kind='evasive', ev=ev)]

def gives_ev(power, ev, mv, eng=0, cost=0, oneoff=0, cond=1.0, label=None):
    lvl = EV[ev]
    s = 0.05 + 0.10 * power * lvl + 0.5 * eng - 0.25 * cost - _mvp(mv, 0.10)
    if oneoff:
        s *= 0.75
    s *= cond
    return [E('reach', s, label or f'Reach: Gives Evasion ({power:g} x {lvl:g}) (MV:{mv})', kind='givesev')]

def drain(dmg, mv, cond=1.0, label=None, poison=0, mill=0):
    d = dmg + 3 * poison + mill / 2
    s = (0.05 + 0.15 * d - _mvp(mv, 0.10)) * cond
    return [E('reach', s, label or f'Reach: Drain ({d:g}/cycle) (MV:{mv})', kind='drain')]

# ---------------- INTERACTION ----------------
REM = {'bounce': 0.25, 'damage': 0.40, 'edict': 0.40, 'destroy': 0.50, 'exile': 0.75,
       'steal': 0.75, 'steal_eot': 0.25}

def answer(mv, rem=None, big=0, hits='c', extra=0, counter=None, anyspell=0, wipe=0,
           wexile=0, oneside=0, wbounce=0, denial=0, dside=0, discard=0, inst=0, nc=1,
           eng=0, cond=1.0, kinds='c', label=None):
    """kinds: letters it can answer: c creature a artifact e enchantment p planeswalker
    l land g graveyard s spell."""
    s = 0.05
    if rem:
        s += REM[rem] + (0.25 if big else 0)
    s += {'c': 0, 'one': 0, '2': 0.25, 'any': 0.5}[hits]
    if extra >= 1:
        s += 0.5 + 0.25 * (extra - 1)
    if counter:
        s += {'hard': 0.75, 'soft': 0.40}[counter] + 0.25 * anyspell
    if wipe:
        s += 1.0 + 0.25 * wexile + 0.5 * oneside - 0.25 * wbounce   # 'later' cut applied at deck level
    if denial:
        s += 0.25 + 0.25 * dside + 0.25 * discard
    s += 0.25 * inst + 0.25 * nc + 0.5 * eng - _mvp(mv, 0.15)
    s = s * cond * 0.45
    what = 'Wipe' if wipe else 'Counter' if counter else 'Denial' if denial else 'Removal'
    return [E('interaction', s, label or f'Answer ({what}) (MV:{mv})', kind='answer',
              wipe=bool(wipe), kinds=kinds, atype=what, oneside=oneside)]

# ---------------- SURVIVAL ----------------
def survive(mv, prot1=0, protall=0, hexp=0, ind=0, ownkw=0, sac=0, sacfree=0, ret=0,
            mass=0, masssym=0, comeback=0, rebuild=0, life=0, lifeoneoff=0, fog=0,
            prevent=0, tough=0, bdt=0, bfly=0, inst=0, eng=0, label=None, part=None):
    s = 0.05
    s += 0.40 * prot1 + 0.75 * protall + 0.25 * hexp + 0.25 * ind + 0.10 * ownkw
    s += 0.25 * sac + 0.25 * sacfree
    if ret:
        s += 0.5 + 0.25 * (ret - 1)
    s += 1.5 * mass + 0.75 * masssym + 0.40 * comeback + 0.15 * rebuild
    s += 0.15 * (life / 3.0) + 0.15 * (lifeoneoff / 3.0) * 0.5
    s += 0.40 * fog + 0.50 * prevent
    if tough:
        s += 0.05 * tough + 0.25 * bdt + 0.15 * bfly
    s += 0.25 * inst + 0.5 * eng - _mvp(mv, 0.10)
    if part is None:
        part = 'Protect' if (prot1 or protall or sac or ownkw) else 'Recover' if (ret or mass or masssym or comeback or rebuild) else 'Endure'
    return [E('survival', s, label or f'Survive ({part}) (MV:{mv})', kind='survive', part=part)]

# ---------------- POLITICS ----------------
def politics(mv, hug=0, vote=0, monarch=0, fort=0, tax=0, punish=0, goad1=0, goadx=0,
             goadall=0, redirect=0, inst=0, eng=0, sym=0, label=None):
    s = 0.20 + 0.4 * hug + 0.4 * vote + 0.4 * monarch + 0.6 * fort + 0.5 * tax + 0.3 * punish
    s += 0.3 * goad1 + 0.25 * goadx + 0.75 * goadall + 0.4 * redirect
    s += 0.25 * inst + 0.5 * eng - _mvp(mv, 0.10)
    if sym:
        s *= 0.5
    levers = []
    if hug or vote or monarch: levers.append('Deals')
    if fort or tax or punish: levers.append('Deterrents')
    if goad1 or goadall or redirect: levers.append('Direction')
    return [E('politics', s, label or f"Politics ({'/'.join(levers)}) (MV:{mv})", kind='politics', levers=levers)]

def bargain():
    return [E('politics', 0.10, 'Politics (Bargain Chip)', kind='bargain', levers=[])]

# ---------------- 0.10.3 ----------------
def second_life(what, *parts, k=0.6):
    """Second Life: a card that does something again from the graveyard (flashback, encore,
    'exile this card from your graveyard: ...', granting its abilities to another creature).
    The graveyard effect is scored with the normal formulas, x0.6 (it has to get there and you pay again),
    plus 0.15 Cards for the extra use."""
    out = [E('cards', 0.15, f'Second Life: {what}', kind='second')]
    for p in parts:
        for e in p:
            out.append(dict(e, pts=round(e['pts'] * k, 3), label='Second Life: ' + e['label']))
    return out

def swing(size, mv, eng=0, inst=0, what='', label=None):
    """Swing Factor (0.10.6, Threats): can suddenly flip the standing of a game.
    size S = one player's spot flips, M = a player's life or board turns around, L = whole table resets."""
    s = {'S': 0.25, 'M': 0.5, 'L': 0.75}[size] + 0.5 * eng + 0.25 * inst - _mvp(mv, 0.07, floor=3)
    name = {'S': 'Small', 'M': 'Medium', 'L': 'Large'}[size]
    return [E('threats', s, label or f"Swing ({name}{', repeatable' if eng else ''}) {what} (MV:{mv})".replace('  ', ' '), kind='swing')]

def rebound(*parts):
    """Rebound: cast it again free next upkeep. Second use x0.8 (free, but a turn later)."""
    out = []
    for p in parts:
        for e in p:
            out.append(dict(e, pts=round(e['pts'] * 0.8, 3), label='Rebound: ' + e['label']))
    return out

# ---------------- 0.10.2 ----------------
def bloodthirst(power, n, mv, lvl=0, hard=0, haste=0, label=None):
    """Bloodthirst N: enters with N counters if an opponent was dealt damage this turn.
    n = number, or 'X' = the deck's usual damage on its own turn (set per deck as BT_X).
    Counted as a bigger threat: power + counters, x0.75 because you must deal damage first."""
    return tall(power + n, mv, lvl, hard, haste, cond=0.75,
                label=label or f'Threat: Tall ({power}+{n:g} bloodthirst) (MV:{mv})')

# ---------------- 0.10.1 additions ----------------
def feeds(stat, eng=0, what='', label=None):
    """Feeds the Plan: the card triggers the commander or a core engine.
    +0.15 once, +0.25 if it does it every turn."""
    return [E(stat, 0.25 if eng else 0.15, label or f'Feeds the Plan ({what})', kind='feeds')]

def body(power, tough):
    """Body floor for creatures scoring under 0.5: a body still attacks, blocks and crews."""
    return [E('threats', 0.05 + 0.03 * min(power, 4), f'Body ({power}/{tough}) attacker', kind='body'),
            E('survival', 0.02 * min(tough, 6), f'Body ({power}/{tough}) blocker', kind='body')]

def copy_engine(mult=1.5, what='creatures', odds=1.0):
    """0.10.12 Commander copy engine: the commander makes a token copy of each creature (of a kind) that enters.
    Every Plan Tag C creature's Tall threat counts x mult (scaled by odds). Put it on the commander."""
    return [E('threats', 0.0, f'Copy engine: {what} enter twice (Tall x{mult:g})', kind='copyengine', mult=1 + (mult - 1) * odds)]

def scale(lst, k):
    return [dict(e, pts=round(e['pts'] * k, 3)) for e in lst]

def T(note, *parts):
    out = []
    for p in parts:
        out += p
    return (note, out)

# ---------------- 0.10.16 ----------------
def pump(boost, mv, equip=None, aura=0, ds=0, dbl=0, base=3, protects=0, cond=1.0, label=None):
    """Pump Equipment / Aura on one creature.
    boost: power it adds. equip: equip cost (Equipment). aura=1 for an Aura.
    ds: gives double strike. dbl: doubles power on attack. base: power of the creature you usually suit up (3 by default).
    Threats: Board Power on one creature (double strike / doubling add the carrier's power again).
      Equipment: -0.05 per equip mana above 2 (refunded at deck level when the deck has free/cheap equips),
      +0.15 Survival because it moves to the next creature. Aura: x0.8 (removal takes both cards) unless it protects itself.
    Finish (Suit Up): one suited-up creature's hit = (base + boost) x2 for double strike x2 for doubling;
      at 6+ it's scored as a repeatable finisher at x0.5 (it still has to connect)."""
    pen = 0.05 * max(0, (equip or 0) - 2) if equip is not None else 0.0
    hit = (base + boost) * (2 if ds else 1) * (2 if dbl else 1)
    extra = hit - base
    k = 0.8 if (aura and not protects) else 1.0
    what = 'Aura' if aura else 'Equipment'
    out = []
    t = board(extra, 1, mv, cond=cond)[0]
    out.append(dict(t, pts=round(max(0.0, t['pts'] * k - pen), 3), label=f'Threat: {what} pump (+{extra:g} on one creature) (MV:{mv})',
                    kind='board', pump=1, eqpen=pen))
    if equip is not None:
        out.append(E('survival', 0.15, 'Equipment: moves to the next creature', kind='survive', part='Endure'))
    if hit >= 6:
        f = finish('Suit Up', min(hit, 40), mv, eng=0 if aura else 1, cond=cond)[0]
        out.append(dict(f, pts=round(max(0.0, f['pts'] * 0.5 * k - pen), 3), label=f'Finish (Suit Up): one creature hits for {hit:g} (MV:{mv})',
                        pump=1, eqpen=pen))
    return out
