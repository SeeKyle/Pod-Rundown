"""Writes the numbered rule documents (01-12) into the zip folder.
Prose is written here; every formula's exact code is pulled live from formulas.py so the docs never drift."""
import inspect, sys, json
sys.path.insert(0, '/home/claude/pod2')
import formulas as F
import plan_tags as P

def code(*names):
    out = []
    for n in names:
        obj = getattr(F, n)
        if callable(obj):
            out.append(inspect.getsource(obj).rstrip())
        else:
            out.append(f'{n} = {obj!r}')
    return '\n\n'.join(out)

HDR = lambda n, t: f"POD RUNDOWN {{V}} - {n:02d} {t}\n" + '=' * 70 + '\n'

DOCS = []

DOCS.append(('01_Overview_and_Workflow', 'OVERVIEW AND WORKFLOW', """
WHAT THIS IS
  Every card in every deck gets TAGS: calls to the formulas in files 02-10 (ramp(...), draw(...), tall(...)).
  Each formula returns points for one of 9 stats. A card can have several tags (one per thing it does).
  Card points add up per stat, the deck-level checks in each stat file adjust them, and file 11 turns
  points into the 1-15 ratings and the /90 total.

THE 9 STATS (one file each)
  02 Mana         ramp, cheating costs, lands and fixing
  03 Cards        card draw and card advantage from anywhere
  04 Consistency  tutors, selection, Hit-Rate, Plan B
  05 Threats      big bodies, tokens, team pumps, swing cards
  06 Finish       ways to end the game: burst, extra combats, alt wins, damage doublers
  07 Reach        evasion, giving evasion, drain/burn around blockers
  08 Interaction  removal, wipes, counterspells, denial
  09 Survival     protection, recursion, rebuilding, life and blockers
  10 Politics     deals, deterrents, direction (who gets hit), salt
  11 Ratings, groups, totals, salt and Needs Repair
  12 Plan Tags and Synergy Groups (per deck)

ADDING A NEW DECK (the order I follow)
  1. Save the decklist. Pull full card text ONLY for cards not already saved (card_text.json). Never re-fetch a saved card.
     Also save EDHREC salt and inclusion % and Scryfall MV / type / rarity / P/T for new cards.
  2. Write decks/<key>.py: META (deck name, icon, owner, colors, commander(s), secret commander(s)) and TAGS:
       'Card Name': T('short note', formula(...), formula(...)),
     Lands get land(...) (and select/ramp if they do more). Basics need no entry.
  3. Add the deck's Plan Tag rules (C and T) and 3-5 synergy groups to plan_tags.py (file 12).
  4. Run the score, then review card by card (repeat until a pass needs no changes):
       - every effect on the card has a tag; nothing is tagged that the card doesn't do
       - X costs use the deck's turn-7 mana; conditional effects use cond=0.3-0.8
       - commanders are tagged like any card
  5. Write the judge.py read (1-5 + why + fix idea) for likely Needs Repair cards, and the site takeaway text.
  6. Build the site, test, publish, rebuild the zip.

CARD HELPERS THAT CAN BE USED IN ANY STAT
""" + code('scale', 'second_life', 'rebound', 'body', 'feeds') + """

COMMANDERS
  Commanders score like any other card (no multiplier). Two commander-only rules:
  - Commander engine (file 04): a cheat effect on a commander counts as Consistency, not Mana.
  - Commander copy engine (file 05): copy_engine() on a commander multiplies its copied creatures' Tall threat.
"""))

DOCS.append(('02_Mana', 'MANA', """
WHAT COUNTS
  Ramp (rocks, dorks, land ramp, Treasure), cost reducers (boost=True), cheating cards into play,
  lands (extra colors, untapped or not), fixing.

FORMULAS
""" + code('CF', '_mvp', 'ramp', 'fixing', 'cheat', 'land') + """

TAGGING NOTES
  - kind 'E' = every turn, 'L' = one-off but lasting (a land), 'T' = one-off temporary (Treasure burst, rituals).
  - Cost reducers: ramp(amount, mv, boost=True). A reducer for one card type = scale it.
  - Lands: land(extra colors, deck colors C, entry 'U'/'T'/chance untapped). Snow-Covered basics are basics.
  - Cheat on a COMMANDER moves to Consistency (see 04). odds=0.5 when an opponent picks.

DECK-LEVEL CHECKS (Mana)
  - Land count: 36+ lands, or 33+ with 12+ ramp cards: +0.5. Under 33 lands: -0.5.
  - Untapped share: 75%+ of lands usually untapped: +0.25. Under 50%: -0.25.
  - Color strain: needs 5 x (colors - 1) fixing sources; -0.25 per 3 missing.
  - Land drops (goldfish sim): 70%+ games with 5 lands by T6 and 7 by T8: +0.75; 70%+ with 5 by T6: +0.5.

RATING
  Mana uses a FIXED divide of 4.00 (not second-best = 10), so strong ramp decks can pass 10.
"""))

DOCS.append(('03_Cards', 'CARDS', """
WHAT COUNTS
  Drawing cards, card advantage from second hand (graveyard, exile, top of library), opponents' cards,
  wheels, and Second Life value (a card used again).

FORMULAS
""" + code('draw') + """

TAGGING NOTES
  - src 'H' = from your hand/library normally, 'S' = second hand (graveyard, exile, top), 'O' = opponents' cards.
  - eng=1 for a repeating engine (each turn / each trigger). restr=1 if it needs a condition (connect, sacrifice).
  - sym=1 if opponents also draw. Second Life (file 01) adds +0.15 Cards for the extra use.
  - Cards often benefits from synergy groups and Plan Tags routed here (file 12).
"""))

DOCS.append(('04_Consistency', 'CONSISTENCY', """
WHAT COUNTS
  Tutors, card selection (scry, surveil, loot, dig), how often the deck sees its plan cards (Hit-Rate),
  how the deck works without its commander (Plan B), and commander engines.

FORMULAS
""" + code('tutor', 'select') + """

TAGGING NOTES
  - tutor dest: 'top', 'hand', 'gy' (graveyard decks, same value as hand), 'bf' (battlefield).
    reach: 'n' narrow, 't' a type, 'a' anything. count = cards found.
  - Selection on lands: onland=1 (temples).

COMMANDER ENGINE
  A cheat effect on the commander or secret commander is the deck's planned strategy, always available, so its
  value counts here instead of Mana. If it repeats (eng=1), every Plan Tag C card adds +0.5 x odds to Hit-Rate.

DECK-LEVEL CHECKS (Consistency)
  - Hit-Rate: K = plan-card weight (both Plan Tags 1, one tag 0.5, +0.25 Second Life, +free-drop bonus;
    tutors 1, selection 0.5). +3 x P(see 2 of K in your first 10 cards) + 1 x P(see 3).
  - Plan B: KB = cards with the deck-plan tag (T). +1.5 x P(see 2 of KB in 10 cards).
"""))

DOCS.append(('05_Threats', 'THREATS', """
WHAT COUNTS
  Big creatures (Tall), token makers (Wide), team pumps (Board), noncreature must-answers, Swing cards
  that flip a game, small evasive creatures (Quick Air).

FORMULAS
""" + code('tall', 'nc_threat', 'wide', 'board', 'swing', 'bloodthirst', 'copy_engine') + """

TAGGING NOTES
  - tall(power, mv): needs power 4+ (or lvl 'B'). lvl 'P' pressure, 'B' bomb. hard=1 hard to remove. cond for conditions.
    Mana penalty: -0.08 per MV above 3. Use effective MV for affinity / cost reduction.
  - wide(power per batch, mv, eng=1 if every turn). board(boost, creatures it hits, mv).
  - swing size S/M/L for cards that can flip the standing of a game (life swaps, mass copies, steal everything).

AUTOMATIC CARD RULES
  - Quick Air: an evasive creature that isn't a Tall threat gets 0.10 + 0.05 x power (max 3) + 0.10 x (3 - MV, min 0).
  - Commander copy engine: Plan Tag C creatures' Tall entries x (1 + (mult - 1) x odds). Miirym = x1.5.
  - Body floor: a creature scoring under 0.5 total gets a small body score (attacker here, blocker in Survival).

DECK-LEVEL CHECKS (Threats)
  - Threat variety: 4+ kinds (Tall, Wide, Board Power, Noncreature, Commander) +1; 1 or fewer -1.
  - Wide saturation: Wide points past 10 count half.
  - Air density: +0.60 x (number of Quick Air creatures / their average MV).

RATING
  Threats divide = second-best deck's points / 11 (0.10.19, same as every stat).
"""))

DOCS.append(('06_Finish', 'FINISH', """
WHAT COUNTS
  Ways to end the game: burst damage, extra combats, extra turns, damage doublers, overruns,
  alternate wins, combo pieces (finite, in-deck only), alpha-strike enablers (tap all blockers).

FORMULAS
""" + code('_dmg', 'finish', 'pump') + """

TAGGING NOTES
  - Pump Equipment and Auras (0.10.16) use pump(boost, mv, equip=cost or aura=1, ds, dbl, base, protects):
    Board Power on one creature in Threats, +0.15 Survival for Equipment (it moves on), Auras x0.8 (2-for-1 risk)
    unless they protect themselves, and a Suit Up finisher when one suited-up creature hits for 6+.
    base = the power of the creature the deck usually suits up (3 default; Depala's Dwarves 4, Kotis 5, Felothar walls 4 by toughness).
  - typ: 'Burst', 'Extra Combat', 'Extra Turn', 'Damage Doubler', 'Overrun', 'Alt Win', 'Combo Piece'.
  - amt = damage it adds in a typical swing. sym=1 if it helps opponents too. cond for setup.
  - Infinite combos never count. Cards from other decklists never combine.

DECK-LEVEL CHECKS (Finish)
  - Closer on time: finishers = cards with 0.3+ Finish points. +0.75 x P(see one in your first 13 cards).
  - Suit-up stack (0.10.16): 4+ pump Equipment/Auras and any double strike sources: +0.25 per double strike card (max 6) x min(1, pumps/8).
  - Free equips (0.10.16): a deck with cards that skip, cut or auto-attach equip costs gets every pump's equip-cost penalty back.
  - Finish divide: second-best deck = 11 (same as every stat since 0.10.19).
"""))

DOCS.append(('07_Reach', 'REACH', """
WHAT COUNTS
  Getting damage through: evasive keywords on your own creatures, giving evasion to others,
  and drain / burn / poison / mill that skips combat.

FORMULAS
""" + code('EV', 'evasive', 'gives_ev', 'drain') + """

TAGGING NOTES
  - EV levels: unblockable 1.0, shadow / small-can't-block 0.8, flying 0.7, menace 0.6, trample 0.5, landwalk 0.4.
  - evasive(power, kind) on any creature with the keyword (two=1 if it has two). gives_ev(power it lets through, kind, mv).
  - drain(damage per cycle across the table, mv); poison counts 3 each, mill counts half.
  - Haste enablers can use gives_ev(0, 'fly', mv, eng=1, label='Reach: team haste').
"""))

DOCS.append(('08_Interaction', 'INTERACTION', """
WHAT COUNTS
  Spot removal, board wipes, counterspells, denial (discard, stax, taxes, hate), tap-downs (cond 0.6).

FORMULAS
""" + code('REM', 'answer') + """

TAGGING NOTES
  - rem: bounce, damage, edict, destroy, exile, steal, steal_eot. hits: 'c' creature, '2' two types, 'any'.
  - kinds = letters it can answer: c creature, a artifact, e enchantment, p planeswalker, l land, g graveyard, s spell.
  - Tap-downs / stun: answer(..., 'bounce', cond=0.6). Lockdown auras: 'destroy' with cond 0.75.

AUTOMATIC CARD RULES
  - Later wipes: the first wipe counts full, every other wipe x0.6.

DECK-LEVEL CHECKS (Interaction)
  - Coverage: answers 4+ of creatures/artifacts/enchantments/planeswalkers/graveyards/spells +1; creatures only -1.
  - Answer on time: +1.0 x P(hold at least one answer by turn 4).
"""))

DOCS.append(('09_Survival', 'SURVIVAL', """
WHAT COUNTS
  Protection (hexproof, indestructible, sac outlets), recursion (return from graveyard), rebuilding,
  coming back, life gain, fogs, big blockers.

FORMULAS
""" + code('survive') + """

TAGGING NOTES
  - prot1 one creature, protall the team, ownkw the card protects itself (indestructible/hexproof/ward body).
  - ret = cards returned; mass / masssym = mass recursion (one-sided / symmetric); comeback = comes back itself.
  - life / lifeoneoff in points of life; tough/bdt/bfly for blockers (deathtouch / flying blockers).

AUTOMATIC CARD RULES
  - Vehicles: every Vehicle gets +0.15 Survival (dodges creature wipes).
  - Body floor blocker part (see 05).
"""))

DOCS.append(('10_Politics', 'POLITICS', """
WHAT COUNTS (three levers)
  Deals: group hug, votes, monarch, gifts, counterspells as leverage.
  Deterrents: pillowfort, taxes, punishers.
  Direction: goad, redirect, aiming removal at whoever you choose.

FORMULAS
""" + code('politics', 'bargain') + """

AUTOMATIC CARD RULES
  - Aim: single-target removal gets +0.10 Politics (Direction), up to 8 cards per deck.
  - Counterspell leverage: +0.15 Politics (Deals), up to 5 cards per deck.

DECK-LEVEL CHECKS (Politics)
  - Levers: +0.5 for each lever (Deals, Deterrents, Direction) with 3+ cards.
  - Salt: deck salt under 20 +1, 20-40 0, 40-60 -1, over 60 -2.

RATING
  Politics is rated on the SQUARE ROOT of its points (then the usual divide).
"""))

DOCS.append(('11_Ratings_Groups_and_Repair', 'RATINGS, GROUPS, TOTALS, SALT AND NEEDS REPAIR', """
FROM POINTS TO RATINGS
  - Each stat's points = sum of card points + the deck-level checks in that stat's file.
  - Divide (0.10.19): the second-highest deck's points = 11 (rating = points / divide, rounded half up),
    so the top one or two decks in every stat go over 10. Exception: Mana fixed divide 4.00;
  - Ratings: minimum 1, maximum 15.

GROUPS AND TOTAL
  Engine = Mana + Cards + Consistency; Offense = Threats + Finish + Reach; Defense = Interaction + Survival + Politics.
  Each group /30; a rating's points above 10 count half. Total = the three groups, /90.

PLAN TAG BONUS (every stat, see 12)
  A card with Plan Tag C (works with the commander) or T (fits the deck plan) gets +0.15 (one-off) or +0.25
  (repeating), +0.05 if both tags. It goes to the card's own best stat unless the deck routes it.

SYNERGY GROUPS (see 12)
  +0.005 per other card in the same group, max +0.15 per group, max 2 groups per card.

SALT
  Sum of each card's EDHREC salt; lands that only make mana count 0. Shown next to the total, not part of it
  (only the Politics salt check uses it).

NEEDS REPAIR (Garage)
  The 5 weakest links per deck from an equal blend of: the card's score rank in the deck, its EDHREC inclusion %
  rank across the pod, and my read of the card in that deck (judge.py, 1-5). Each pick shows why and two swaps
  (one budget, one any cost), both in the deck's colors and not already in the list (judge.py FIX2).
  Cards I rate good or great (4-5) are never listed: only cards worth replacing show up.

OWNERS
  Cheez's decks get 🧀 after the name, Leon's decks get 🪼.
"""))

def plan_doc():
    lines = ["""
PLAN TAGS (per deck)
  C = works alongside the commander(s).  T = fits the deck's main plan beyond the commander.
  Decided from each card's saved text with the rules below, plus hand calls (ADD / DROP).
  Hit-Rate and Plan B (file 04) and the Plan Tag bonus (file 11) use these.
"""]
    for k, r in P.RULES.items():
        lines.append(f"  [{k}]\n    C: {r['C'][0]}\n    T: {r['T'][0]}")
        a = P.ADD.get(k, {}); d = P.DROP.get(k, {})
        for t in ('C', 'T'):
            if a.get(t): lines.append(f"    added by hand to {t}: {', '.join(sorted(a[t]))}")
            if d.get(t): lines.append(f"    removed by hand from {t}: {', '.join(sorted(d[t]))}")
        if P.PLAN_STAT.get(k): lines.append("    Plan Tag bonus routed: " + ', '.join(f"{t} -> {st}" for t, st in P.PLAN_STAT[k].items()))
    lines.append("\nSYNERGY GROUPS (per deck): name -> stat the bonus goes to")
    for k, gs in P.GROUPS.items():
        lines.append(f"  [{k}] " + '; '.join(f"{g} -> {st}" for g, _, st in gs))
    return '\n'.join(lines) + '\n'

DOCS.append(('12_Plan_Tags_and_Synergy', 'PLAN TAGS AND SYNERGY GROUPS', None))

def write(D, V):
    for i, (fn, title, body) in enumerate(DOCS, 1):
        if body is None: body = plan_doc()
        open(f'{D}/{fn}.txt', 'w').write(HDR(i, title).replace('{V}', V) + body.lstrip('\n'))
    return [d[0] for d in DOCS]
