"""Pixel sky for the header (0.10.25): a bone-pale, blood-rimmed moon with a faint face in its seas, thin cloud wisps
lit from behind, a gnarled dead branch, 2-frame bats with red eyes, and grey graveyard fog.
Writes new/sky_assets.json (data URIs) and swaps them into template.html."""
from PIL import Image
import numpy as np, math, random, base64, io, json, re
random.seed(13); np.random.seed(13)
B4=np.array([[0,8,2,10],[12,4,14,6],[3,11,1,9],[15,7,13,5]])/16.0
def uri(im):
    b=io.BytesIO(); im.save(b,'PNG',optimize=True); return 'data:image/png;base64,'+base64.b64encode(b.getvalue()).decode()
def noise(n,seed,oct_=4):
    rng=np.random.RandomState(seed);out=np.zeros((n,n))
    for o in range(oct_):
        s=2**(o+2);g=rng.rand(s+1,s+1)
        ys=np.linspace(0,s,n,endpoint=False);xs=ys
        y0=ys.astype(int);x0=xs.astype(int);fy=(ys-y0)[:,None];fx=(xs-x0)[None,:]
        fy=fy*fy*(3-2*fy);fx=fx*fx*(3-2*fx)
        a=g[y0][:,x0];b=g[y0][:,x0+1];c=g[y0+1][:,x0];d=g[y0+1][:,x0+1]
        out+=((a*(1-fx)+b*fx)*(1-fy)+(c*(1-fx)+d*fx)*fy)/(2**o)
    return out/out.max()
# --- moon (72x72): bone white -> sickly ochre, dark maria that read as a faint grim face, blood-red rim
N=72;R=32;cx=cy=35.5
tones=[(26,12,16),(64,30,30),(110,70,52),(160,128,92),(204,186,146),(232,222,190),(250,246,226)]
nz=noise(N,7)
maria=[(26,27,6.5,.55),(45,27,6.5,.55),(36,37,2.6,.30),(36,48,9,.30),(18,44,4,.2),(52,16,3.5,.18)]  # eyes, nose, mouth, blotches
craters=[(52,48,4),(20,20,3),(56,36,2.5),(30,58,3),(44,10,2),(14,32,2),(60,24,2)]
m=np.zeros((N,N,4),np.uint8)
for y in range(N):
    for x in range(N):
        dx,dy=x-cx,y-cy;d=math.hypot(dx,dy)
        if d>R: continue
        z=math.sqrt(max(0,1-(d/R)**2));l=max(0,(dx/R)*0.45+(dy/R)*-0.35+z*0.82)
        v=0.18+0.9*l+(nz[y,x]-.5)*0.22
        for (mx,my,mr,k) in maria:
            md=math.hypot((x-mx)*(1.0 if mr<8 else .7),y-my)
            if md<mr: v-=k*(1-(md/mr)**2)
        for (ccx,ccy,cr) in craters:
            cd=math.hypot(x-ccx,y-ccy)
            if cd<cr: v-=0.3*(1-cd/cr)
            elif cd<cr+1.3 and (x-ccx)*0.45-(y-ccy)*0.35>0: v+=0.14
        t=max(0,min(.999,v))*(len(tones)-1);i=int(t);f=t-i;i=max(0,min(len(tones)-2,i))
        c=tones[i+1] if f>B4[y%4,x%4] else tones[i]
        if d>R-2.2 and (dx*0.45-dy*0.35)<0: c=(120,18,24) if (x+y)%2 else c   # blood rim on the shadow side
        m[y,x]=(*c,255)
moon=Image.fromarray(m)
# --- cloud wisp strip (120x18): thin, ragged, dark plum with a moonlit top edge
cw,ch=120,18;c=np.zeros((ch,cw,4),np.uint8);cn=noise(128,3)
for x in range(cw):
    h=(math.sin(x*0.09)+math.sin(x*0.21+1.3)*0.5+cn[5,x]*1.2)*2.2+7
    th=2.5+2.5*(math.sin(x*0.07+2)+1)*(cn[40,x])
    th*=min(1,x/30,(cw-1-x)/30)**1.3
    for y in range(ch):
        dd=abs(y-h)
        if dd<th and (th-dd)/th>B4[y%4,x%4]*0.7:
            c[y,x]=(34,22,40,235)
            if y<h-th+1.6: c[y,x]=(150,130,140,220)
cloud=Image.fromarray(c)
# --- fog strip (256x28), grey-violet, tiles horizontally
fw,fh=256,28;f=np.zeros((fh,fw,4),np.uint8)
for y in range(fh):
    for x in range(fw):
        a=(math.sin(2*math.pi*x/fw*3)+math.sin(2*math.pi*x/fw*7+1)*0.6+math.sin(2*math.pi*x/fw*13+2)*0.4+math.sin(2*math.pi*(x/fw*5)+y*0.4)*0.5)*0.28+(y/fh)*0.75-0.05
        if a>B4[y%4,x%4]: f[y,x]=(150,140,165,int(30+80*min(1,a)))
fog=Image.fromarray(f)
# --- bat, 2 frames of 24x12: scalloped wings, ears, red eyes
up=["X......................X",
    "XX....................XX",
    ".XX..................XX.",
    ".XXX.......X..X.....XXX.",
    "..XXXX.....XXXX...XXXX..",
    "..XXXXXX..XRXXRX.XXXXX..",
    "...XXXXXXXXXXXXXXXXXX...",
    "...XX.XXXXXXXXXXXX.XX...",
    "....X..X.XXXXXX.X..X....",
    "...........XX...........",
    "........................",
    "........................"]
dn=["........................",
    "........................",
    "...........X..X.........",
    "...........XXXX.........",
    "..........XRXXRX........",
    "....XXXXXXXXXXXXXXXX....",
    "..XXXXXXXXXXXXXXXXXXXX..",
    ".XXXXXX.XXXXXXXX.XXXXXX.",
    "XXX.XX...XXXXXX...XX.XXX",
    "XX...X....XXXX....X...XX",
    "X..........XX..........X",
    "........................"]
b=np.zeros((12,48,4),np.uint8)
for k,fr in enumerate((up,dn)):
    for y,row in enumerate(fr):
        for x,ch_ in enumerate(row):
            if ch_=='X': b[y,x+24*k]=(10,4,12,255)
            if ch_=='R': b[y,x+24*k]=(255,40,30,255)
bat=Image.fromarray(b)
# --- gnarled dead branch (96x64) reaching in from the right edge, tapered with knots and twigs
bw,bh=96,64;br=np.zeros((bh,bw,4),np.uint8)
def dot(x,y,w,col=(8,4,10,255)):
    for yy in range(int(y-w),int(y+w)+1):
        for xx in range(int(x-w),int(x+w)+1):
            if 0<=xx<bw and 0<=yy<bh and (xx-x)**2+(yy-y)**2<=w*w+.3: br[yy,xx]=col
def limb(x,y,ang,ln,w,d):
    if d==0 or ln<2.5: return
    steps=int(ln);
    for i in range(steps):
        ang+=random.uniform(-.18,.18);x+=math.cos(ang);y+=math.sin(ang);dot(x,y,max(.45,w*(1-i/steps*.35)))
    w2=w*.65
    limb(x,y,ang+random.uniform(-.45,.15),ln*.75,w2,d-1)
    if random.random()<.85: limb(x,y,ang+random.choice([-1,1])*random.uniform(.5,1.0),ln*.5,w2*.8,d-1)
    if random.random()<.4: limb(x,y,ang+random.uniform(.6,1.1),ln*.35,.5,1)
limb(96,10,math.pi*0.9,26,3.2,6)
limb(96,30,math.pi*1.05,14,2.0,4)
branch=Image.fromarray(br)
A={k:uri(v) for k,v in dict(moon=moon,cloud=cloud,fog=fog,bat=bat,branch=branch).items()}
json.dump(A,open('new/sky_assets.json','w'))
# swap into template.html (replace the data URI inside each sky class rule)
t=open('template.html').read()
for cls,key in [('sky-moon','moon'),('sky-cloud','cloud'),('sky-branch','branch'),('sky-bat','bat'),('sky-fog','fog')]:
    t,n=re.subn(r'(\.'+cls+r'\{[^}]*?url\()data:image/png;base64,[A-Za-z0-9+/=]+',lambda mm:mm.group(1)+A[key],t,count=1)
    assert n==1,cls
open('template.html','w').write(t)
prev=Image.new('RGBA',(360,140),(12,6,20,255))
prev.alpha_composite(moon.resize((144,144),Image.NEAREST),(10,0));prev.alpha_composite(cloud.resize((240,36),Image.NEAREST),(0,70))
prev.alpha_composite(branch.resize((192,128),Image.NEAREST),(168,0));prev.alpha_composite(bat.resize((144,36),Image.NEAREST),(190,96))
prev.alpha_composite(fog.resize((360,28),Image.NEAREST),(0,112))
prev.resize((720,280),Image.NEAREST).save('/tmp/claude-0/sky_prev.png')
