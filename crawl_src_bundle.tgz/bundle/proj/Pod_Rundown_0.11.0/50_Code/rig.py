"""Shaded-volume sprite renderer: characters are built from lit capsules, ellipsoids and polygons at 4x,
then downsampled, palette-quantized and outlined into crisp pixel art. Used by make_crawl_art.py."""
import numpy as np, math
from PIL import Image, ImageDraw
K = 4
RES = 1   # output pixels per logical unit (2 = double-detail sprites)
LIGHT = np.array([0.45, -0.75, 0.5]); LIGHT = LIGHT / np.linalg.norm(LIGHT)

def hx(s):
    s = s.lstrip('#'); return np.array([int(s[i:i+2], 16) for i in (0, 2, 4)], float)

class Mat:
    def __init__(s, col, kind='matte', spec=None, emit=False, tex=0.0):
        s.col = hx(col) if isinstance(col, str) else np.array(col, float)
        s.kind, s.emit, s.tex = kind, emit, tex
        s.spec = spec if spec is not None else {'metal': 0.9, 'gold': 0.8, 'gem': 1.0, 'bone': 0.25, 'skin': 0.12, 'leather': 0.2}.get(kind, 0.05)

class Canvas:
    def __init__(s, w, h):
        s.w, s.h = w, h; s.k = K * RES; s.res = RES; W, H = w * s.k, h * s.k
        s.rgb = np.zeros((H, W, 3)); s.a = np.zeros((H, W), bool)
        yy, xx = np.mgrid[0:H, 0:W]; s.yy, s.xx = yy + 0.5, xx + 0.5
    # --- lighting
    def _put(s, m, nx, ny, nz, mat, sl):
        if mat.emit:
            c = np.broadcast_to(mat.col, nx.shape + (3,)) * (0.85 + 0.3 * nz[..., None])
        else:
            d = np.clip(nx * LIGHT[0] + ny * LIGHT[1] + nz * LIGHT[2], 0, 1)
            # three clean tones (shadow / base / light) like hand-made pixel art
            d = np.where(d < 0.28, 0.0, np.where(d < 0.72, 0.5, 0.9))
            # wrap lighting + ambient, cool shadows
            amb = 0.5
            lit = amb + 0.62 * d
            c = mat.col[None, None, :] * lit[..., None]
            shadow_tint = np.array([0.82, 0.86, 1.08])
            c = c * (shadow_tint + (1 - shadow_tint) * np.clip(d, 0, 1)[..., None])
            if mat.spec > 0:
                # reflect for viewer (0,0,1)
                rz = 2 * (nx * LIGHT[0] + ny * LIGHT[1] + nz * LIGHT[2]) * nz - LIGHT[2]
                sp = (np.clip(rz, 0, 1) ** (14 if mat.kind in ('metal', 'gem', 'gold') else 6) > 0.5) * mat.spec * 0.8
                hi = np.array([255, 250, 235.]) if mat.kind != 'gold' else np.array([255, 240, 170.])
                c = c * (1 - sp[..., None]) + hi * sp[..., None]
            if mat.tex:
                n = np.sin(s.xx[sl] * 1.9 / s.res + s.yy[sl] * 0.7 / s.res) * np.sin(s.yy[sl] * 1.3 / s.res - s.xx[sl] * 0.4 / s.res)
                c = c * (1 + mat.tex * 0.5 * np.sign(n)[..., None] * (np.abs(n) > .6)[..., None])
        r = s.rgb[sl]; a = s.a[sl]
        r[m] = np.clip(c[m], 0, 255); a[m] = True
    def _box(s, x0, y0, x1, y1):
        k = s.k; X0, Y0 = max(0, int(x0 * k) - 2), max(0, int(y0 * k) - 2)
        X1, Y1 = min(s.w * k, int(x1 * k) + 3), min(s.h * k, int(y1 * k) + 3)
        return (slice(Y0, Y1), slice(X0, X1))
    def capsule(s, p0, p1, r0, r1, mat, flat=0.0):
        (x0, y0), (x1, y1) = p0, p1
        R = max(r0, r1)
        sl = s._box(min(x0, x1) - R, min(y0, y1) - R, max(x0, x1) + R, max(y0, y1) + R)
        X, Y = s.xx[sl] / s.k, s.yy[sl] / s.k
        dx, dy = x1 - x0, y1 - y0; L2 = dx * dx + dy * dy or 1e-6
        t = np.clip(((X - x0) * dx + (Y - y0) * dy) / L2, 0, 1)
        cx, cy = x0 + t * dx, y0 + t * dy; r = r0 + (r1 - r0) * t
        ex, ey = X - cx, Y - cy; d2 = ex * ex + ey * ey
        m = d2 <= r * r
        nx, ny = ex / r, ey / r; nz = np.sqrt(np.clip(1 - nx * nx - ny * ny, 0, 1))
        if flat: nz = nz * (1 - flat) + flat
        s._put(m, nx, ny, nz, mat, sl)
    def ell(s, c, rx, ry, mat, rot=0.0, cut=None):
        cx, cy = c; R = max(rx, ry)
        sl = s._box(cx - R, cy - R, cx + R, cy + R)
        X, Y = s.xx[sl] / s.k - cx, s.yy[sl] / s.k - cy
        cr, sr = math.cos(rot), math.sin(rot)
        u, v = (X * cr + Y * sr) / rx, (-X * sr + Y * cr) / ry
        m = u * u + v * v <= 1
        if cut is not None: m &= cut(X + cx, Y + cy)
        nu, nv = u, v
        nx, ny = nu * cr - nv * sr, nu * sr + nv * cr
        nz = np.sqrt(np.clip(1 - u * u - v * v, 0, 1))
        s._put(m, nx, ny, nz, mat, sl)
    def poly(s, pts, mat, normal=(0, 0, 1), bevel=None, folds=0.0):
        """flat polygon; bevel=(axis point a, b) splits light/dark along a ridge line (blades)."""
        xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
        sl = s._box(min(xs), min(ys), max(xs), max(ys))
        X0, Y0 = sl[1].start, sl[0].start
        if sl[1].stop <= X0 or sl[0].stop <= Y0: return
        im = Image.new('L', (sl[1].stop - X0, sl[0].stop - Y0), 0)
        ImageDraw.Draw(im).polygon([(x * s.k - X0, y * s.k - Y0) for x, y in pts], fill=255)
        m = np.array(im) > 127
        nx = np.full(m.shape, normal[0], float); ny = np.full(m.shape, normal[1], float); nz = np.full(m.shape, normal[2], float)
        if bevel:
            (ax, ay), (bx, by) = bevel
            X, Y = s.xx[sl] / s.k, s.yy[sl] / s.k
            side = np.sign((bx - ax) * (Y - ay) - (by - ay) * (X - ax))
            px, py = -(by - ay), (bx - ax); L = math.hypot(px, py) or 1
            nx = side * px / L * 0.75; ny = side * py / L * 0.75; nz = np.full(m.shape, 0.66)
        if folds:
            X = s.xx[sl] / s.k
            f = np.sin(X * folds) * 0.55
            nx = nx + f; nz = np.sqrt(np.clip(1 - nx * nx - ny * ny, 0.05, 1))
        s._put(m, nx, ny, nz, mat, sl)
    # --- finish
    def finish(s, outline=(14, 8, 16), palette=None):
        H, W = s.h * s.res, s.w * s.res
        rgb = s.rgb.reshape(H, K, W, K, 3); a = s.a.reshape(H, K, W, K)
        cov = a.mean(axis=(1, 3))
        # average only covered sub-pixels
        sm = (rgb * a[..., None]).sum(axis=(1, 3)); n = a.sum(axis=(1, 3))[..., None]
        col = np.where(n > 0, sm / np.maximum(n, 1), 0)
        alpha = cov >= 0.45
        img = np.zeros((H, W, 4), np.uint8); img[..., :3] = np.clip(col, 0, 255); img[..., 3] = alpha * 255
        return img

def outline_sel(img, dark=(16, 9, 18)):
    a = img[..., 3] > 0; H, W = a.shape; out = img.copy()
    o = np.zeros_like(a)
    o[1:, :] |= a[:-1, :]; o[:-1, :] |= a[1:, :]; o[:, 1:] |= a[:, :-1]; o[:, :-1] |= a[:, 1:]
    o &= ~a
    out[o] = (*dark, 255)
    # rim light from the upper-right so dark figures pop on dark backdrops
    up = np.zeros_like(a); up[1:, :] = ~a[:-1, :]; up[0, :] = True
    rt = np.zeros_like(a); rt[:, :-1] = ~a[:, 1:]; rt[:, -1] = True
    rim = a & (up | rt) & ~o
    c = out[..., :3].astype(float); c[rim] = np.clip(c[rim] * 1.22 + 14, 0, 255); out[..., :3] = c.astype(np.uint8)
    # inner rim: darken pixels on the bottom/right silhouette edge a touch
    return out

def quantize(frames, ncol=24):
    """shared palette across a character's frames"""
    W = sum(f.shape[1] for f in frames); H = max(f.shape[0] for f in frames)
    strip = np.zeros((H, W, 4), np.uint8); x = 0
    for f in frames: strip[:f.shape[0], x:x + f.shape[1]] = f; x += f.shape[1]
    rgb = Image.fromarray(strip[..., :3]); q = rgb.quantize(ncol, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE).convert('RGB')
    qa = np.array(q); res = []; x = 0
    for f in frames:
        g = f.copy(); g[..., :3] = qa[:f.shape[0], x:x + f.shape[1]]; res.append(g); x += f.shape[1]
    return res
