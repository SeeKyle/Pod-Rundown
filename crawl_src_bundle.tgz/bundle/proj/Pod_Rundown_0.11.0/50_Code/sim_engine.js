  const SIM=JSON.parse(document.getElementById('sim-data').textContent);
  const shuf=a=>{for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;};
  function mkPlayer(r){
    const S=SIM[r.deck];const deck=()=>shuf([...S.lib.map(c=>({...c})),...Array.from({length:S.lands},()=>({land:1}))]);
    let lib=deck(),hand=lib.splice(0,7);const nl=h=>h.filter(c=>c.land).length;
    if(nl(hand)<2||nl(hand)>5){lib=deck();hand=lib.splice(0,7);}
    return {r,tough:S.tough,name:r.deck,icon:r.icon,life:40,lib,hand,lands:0,ramp:0,bf:[],pump:0,de:0,we:0,dr:0,acc:0,
      cmdrs:S.cmdr.map(c=>({...c,tax:0,on:false,cmd:1})),cd:{},alive:true,out:0,kills:0,lastHit:null,mull:nl(hand)};
  }
  const pw=(p,c)=>Math.max(0,((p.tough&&c.tp&&p.bf.some(b=>b.cmd))?c.tp:(c.p||0))+(c.tok?0:p.pump));
  function draw(p,n){for(let i=0;i<n;i++){if(!p.lib.length)return;p.hand.push(p.lib.shift());}}
  function runSim(rows,log){
    const P=rows.map(mkPlayer);const L=[];const say=(t,s,cls)=>log&&L.push({t,s,cls});
    const alive=()=>P.filter(p=>p.alive);let round=0,ending='',cmdKO=false;
    const ko=(t)=>{for(const o of P)if(o.alive&&o.life<=0){o.alive=false;o.out=alive().length+1;const k=o.lastHit;if(k)k.kills++;o.bf=[];
      say(t,`☠️ ${o.icon} ${o.name} is knocked out${k?' by '+k.icon+' '+k.name:''}!`,'ko');}};
    const toZone=(o,c)=>{if(c.cmd){const z=o.cmdrs.find(x=>x.n===c.n);if(z){z.on=false;z.tax+=2;}}};
    while(alive().length>1&&round<20){
      round++;const t=round;
      for(const p of P){
        if(!p.alive||alive().length<2)continue;
        const opp=alive().filter(o=>o!==p);
        // untap, draw, engines
        p.bf.forEach(c=>c.sick=false);
        draw(p,t===1&&p===P[0]?0:1);p.acc+=p.de;while(p.acc>=1){draw(p,1);p.acc-=1;}
        if(p.we>0)p.bf.push({n:'tokens',p:Math.round(p.we),tok:1,sick:true});
        const li=p.hand.findIndex(c=>c.land);if(li>=0){p.hand.splice(li,1);p.lands++;}
        let mana=p.lands+p.ramp;
        // cast spells
        for(let guard=0;guard<12;guard++){
          const oppMax=Math.max(0,...opp.flatMap(o=>o.bf.map(c=>pw(o,c))));
          const oppPow=opp.reduce((s,o)=>s+o.bf.reduce((a,c)=>a+pw(o,c),0),0),myPow=p.bf.reduce((a,c)=>a+pw(p,c),0);
          const opts=[];
          p.cmdrs.forEach(c=>{if(!c.on&&c.mv+c.tax<=mana)opts.push([c,88+(c.de?6:0),c.mv+c.tax,true]);});
          p.hand.forEach(c=>{if(c.land||c.mv>mana)return;let s=20;
            if(c.r||c.rl)s=t<=5?100:30;
            if(c.p||c.tp||c.w||c.we)s=Math.max(s,50+(c.p||c.tp||c.w||0));
            if(c.d||c.de)s=Math.max(s,p.hand.length<=2?75:42);
            if(c.b||c.u)s=Math.max(s,p.bf.length?46:5);
            if(c.x===1)s=(oppMax>=4||opp.some(o=>o.bf.some(b=>b.cmd)))?Math.max(s,62):Math.min(s,8);
            if(c.x===2)s=(c.xo>=1?(t>=4&&oppPow>=8&&oppPow>myPow):(t>=5&&oppPow>=12&&oppPow>=2*myPow+4))?95:2;
            if(c.f)s=(opp.some(o=>o.life<=c.f*1.3)||t>=8)?Math.max(s,70):Math.min(s,15);
            if(c.dr)s=Math.max(s,40);
            if(c.ch)s=p.hand.some(x=>x.p&&!x.v&&x.mv>c.mv)?Math.max(s,85):Math.min(s,12);
            if(s>5)opts.push([c,s,c.mv,false]);});
          if(!opts.length)break;
          opts.sort((a,b)=>b[1]-a[1]||b[2]-a[2]);const [c,,cost,isCmd]=opts[0];mana-=cost;
          if(isCmd){c.on=true;p.bf.push({n:c.n,p:c.p||0,ev:c.ev||0,cmd:1,sick:true});p.de+=c.de||0;p.we+=c.we||0;p.dr+=c.dr||0;p.ramp+=c.r||0;p.pump+=c.b||0;
            say(t,`👑 ${p.icon} ${p.name} casts ${c.n}${c.tax?` (tax ${c.tax})`:''}.`);continue;}
          p.hand.splice(p.hand.indexOf(c),1);
          if(c.r)p.ramp+=c.r;if(c.rl)p.lands+=Math.round(c.rl);if(c.rt)mana+=Math.round(c.rt);
          if(c.d)draw(p,Math.floor(c.d+Math.random()));
          if(c.ch){const pool=p.hand.filter(x=>x.p&&!x.v);const big=pool.sort((a,b)=>b.p-a.p)[0];if(big&&big.mv>c.mv){p.hand.splice(p.hand.indexOf(big),1);p.bf.push({n:big.n,p:big.p,ev:big.ev||0,sick:true});say(t,`🌀 ${p.icon} ${p.name}'s ${c.n} cheats ${big.n} (${big.p} power) into play.`,'big');}}
          if(c.de)p.de+=c.de;if(c.we)p.we+=c.we;if(c.b)p.pump+=c.b;
          if(c.p||c.tp)p.bf.push({n:c.n,p:c.p||0,tp:c.tp,ev:c.ev||0,v:c.v,sick:!c.v&&true});
          if(c.w)p.bf.push({n:c.n+' tokens',p:Math.round(c.w),tok:1,sick:true});
          if(c.fe)p.freeEq=true;if(c.u||c.ge){(p.gear=p.gear||[]).push({c,on:null});}
          if(c.dr){if(c.t==='I'||c.t==='S'){opp.forEach(o=>{o.life-=Math.round(c.dr/3);o.lastHit=p;});}else p.dr+=c.dr;}
          if(c.f){const ft=c.ft||'B';
            if(ft==='B'){const o=opp.reduce((a,b)=>b.life<a.life?b:a);const d=Math.round(c.f*(c.t==='I'||c.t==='S'?1:0.6));o.life-=d;o.lastHit=p;say(t,`🔥 ${p.icon} ${p.name}'s ${c.n} hits ${o.icon} ${o.name} for ${d}.`,'big');}
            else if(ft==='A'){if(Math.random()<0.15){opp.forEach(o=>{o.life=0;o.lastHit=p;});say(t,`🌟 ${p.icon} ${p.name} assembles the win with ${c.n}!`,'big');}}
            else{p.boost=p.boost||{};p.boost[ft]=(p.boost[ft]||0)+(ft==='O'?Math.max(2,Math.round(c.f/Math.max(1,p.bf.length))):1);say(t,`🔥 ${p.icon} ${p.name} goes for it with ${c.n}${ft==='C'?' (extra combat)':ft==='D'?' (double damage)':' (team pump)'}!`,'big');}}
          if(c.x===1){let tg=null,to=null;opp.forEach(o=>o.bf.forEach(b=>{if(!tg||pw(o,b)+(b.cmd?2:0)>pw(to,tg)+(tg.cmd?2:0)){tg=b;to=o;}}));
            if(tg){to.bf.splice(to.bf.indexOf(tg),1);toZone(to,tg);say(t,`✨ ${p.icon} ${p.name}'s ${c.n} removes ${to.icon} ${tg.n}.`);}}
          if(c.x===2){P.forEach(o=>{if(o===p&&c.xo>=1)return;const keep=o===p&&c.xo?o.bf.filter((b,i)=>b.v||i%2===0):o.bf.filter(b=>b.v);o.bf.filter(b=>!keep.includes(b)&&b.cmd).forEach(b=>toZone(o,b));o.bf=keep;});say(t,`💥 ${p.icon} ${p.name} wipes the board with ${c.n}!`,'big');}
          if(log&&Math.max(c.p||0,p.tough?c.tp||0:0)>=5)say(t,`🗡️ ${p.icon} ${p.name} casts ${c.n} (${Math.max(c.p||0,p.tough?c.tp||0:0)} ${p.tough&&c.tp?'toughness':'power'}).`);
          else if(log&&(c.d>=3))say(t,`🃏 ${p.icon} ${p.name} refills with ${c.n}.`);
        }
        // attach Equipment (pay equip, or free with Bruenor/Kíli-style cards) and Auras (free, gone when the creature dies)
        if(p.gear){p.gear=p.gear.filter(g=>!(g.on&&!p.bf.includes(g.on)&&g.c.eq===undefined));let freeUsed=false;
          for(const g of p.gear){if(g.on&&!p.bf.includes(g.on))g.on=null;if(g.on)continue;const best=p.bf.filter(x=>!x.tok&&!x.v).sort((a,b)=>pw(p,b)-pw(p,a))[0];if(!best)break;
            let cost=g.c.eq===undefined?0:g.c.eq;if(p.freeEq&&!freeUsed&&cost>0){cost=0;freeUsed=true;}if(cost>mana)continue;mana-=cost;g.on=best;best.p+=g.c.u||0;best.ev=Math.max(best.ev||0,g.c.ge||0);}}
        // combat
        const bo=p.boost||{};p.boost={};const combats=1+(bo.C||0);const tmp=bo.O||0;p.pump+=tmp;
        for(let cb=0;cb<combats&&opp.some(o=>o.alive&&o.life>0);cb++){const liv=opp.filter(o=>o.life>0);
        const crew=p.bf.filter(c=>!c.v).length>=2;
        const ready=p.bf.filter(c=>!c.sick&&(!c.v||crew)&&pw(p,c)>0);
        if(ready.length){
          const w=liv.map(o=>(o.bf.reduce((a,c)=>a+pw(o,c),0)+4)*(1.25-(Number(o.r.control)||5)*0.04)*(o.life<=15?1.6:1)*(o.lastHit===p?1.3:1));
          let x=Math.random()*w.reduce((a,b)=>a+b),o=liv[0];for(let k=0;k<liv.length;k++){x-=w[k];if(x<=0){o=liv[k];break;}}
          const blockers=o.bf.filter(c=>!c.v).sort((a,b)=>pw(o,b)-pw(o,a));const maxB=blockers.length?pw(o,blockers[0]):0;
          const atk=ready.filter(c=>(c.ev||0)>=0.5||pw(p,c)>maxB||o.life<=15||Math.random()<0.25).sort((a,b)=>pw(p,b)-pw(p,a));
          let dmg=0,blocked=0;const cmdHits=[];
          for(const a of atk){const ap=pw(p,a);
            if((a.ev||0)>0&&Math.random()<a.ev){dmg+=ap;if(a.cmd)cmdHits.push([a,ap]);continue;}
            const bi=blockers.findIndex(b=>pw(o,b)>=ap);const chump=ap>=6&&o.life<=ap*2&&blockers.length;
            if(bi>=0||chump){const b=bi>=0?blockers[bi]:blockers[blockers.length-1];blockers.splice(blockers.indexOf(b),1);blocked++;
              if(ap>=pw(o,b)){o.bf.splice(o.bf.indexOf(b),1);toZone(o,b);}
              if(pw(o,b)>=ap){p.bf.splice(p.bf.indexOf(a),1);toZone(p,a);}
              continue;}
            dmg+=ap;if(a.cmd)cmdHits.push([a,ap]);}
          if(bo.D)dmg*=2;
          if(atk.length){o.life-=dmg;if(dmg>0)o.lastHit=p;
            cmdHits.forEach(([a,ap])=>{const k=p.name+a.n;o.cd[k]=(o.cd[k]||0)+ap;if(o.cd[k]>=21&&o.life>0){o.life=0;cmdKO=true;say(t,`⚔️ ${a.n} has dealt 21 commander damage to ${o.icon} ${o.name}!`,'big');}});
            if(log&&(dmg>=5||o.life<=0||blocked))say(t,`🗡️ ${p.icon} ${p.name} attacks ${o.icon} ${o.name} with ${atk.length} creature${atk.length>1?'s':''}${blocked?` (${blocked} blocked)`:''}: ${dmg} damage, ${Math.max(0,o.life)} left.`);}
        }
        }
        p.pump-=tmp;
        if(p.dr>0)opp.forEach(o=>{o.life-=Math.max(1,Math.round(p.dr/3));o.lastHit=p;});
        ko(t);
      }
      if(log&&round%2===0&&alive().length>1)say(round,'❤️ '+alive().map(q=>`${q.icon} ${Math.max(0,q.life)}`).join(' · '),'life');
    }
    const al=alive();let win;
    if(al.length===1){win=al[0];win.out=1;
      ending=cmdKO&&win.kills>=1&&Math.random()<1?(win.kills>=3?`FLAWLESS SWEEP — ${win.name} knocked out all three, commander damage included.`:`COMMANDER DAMAGE — ${win.name} finished it with a commander.`)
        :win.kills>=3?`FLAWLESS SWEEP — ${win.name} knocked out all three opponents.`:win.life<=10?`COMEBACK — ${win.name} survived on ${win.life} life.`:round<=7?`SPEED RUN — over by turn ${round}.`:`LAST ONE STANDING — ${win.name} outlasted the table.`;
    }else{al.sort((a,b)=>b.life-a.life);win=al[0];al.forEach((p,i)=>p.out=i+1);ending=`TIME CALLED — turn ${round}, ${win.name} ahead on life (${win.life}).`;}
    return {win,P,L,turn:round,ending};
  }
