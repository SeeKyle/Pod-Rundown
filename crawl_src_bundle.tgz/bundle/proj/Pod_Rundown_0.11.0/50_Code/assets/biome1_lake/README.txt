Biome 1 backdrop (Lake by Ansimuz, ansimuz.com — licensed for personal/commercial use, no redistribution of raw assets).
Layers back to front: back.png (48x160, tiles), moon.png (128x48), midle.png (544x160, tiles), trail.png (272x48, tiles; our dirt trail with bones, sits at y=112).
