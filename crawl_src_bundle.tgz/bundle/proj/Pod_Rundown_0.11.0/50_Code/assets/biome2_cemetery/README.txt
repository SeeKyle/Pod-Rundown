Cemetery by Ansimuz. Back to front: back, far-trees, trees, front-fog (y=79), fence (y=111), path.png (our grave-dirt path, 272x44, bottom of a 196-tall scene). All tile at 272.
