# 0.12.206 (Kyle) original pixel-art giant bat for Crypt Crawl: 4 flap frames, 1 swoop (wings swept back), 1 hurt, 1 dead. Faces LEFT.
from PIL import Image,ImageDraw
import json,math
FW,FH=52,34;CX,CY=26,17
OUT=(18,10,18);FUR=(70,46,58);FURL=(104,72,84);MEM=(52,30,58);MEML=(84,52,92);BONE=(132,104,120);EYE=(255,60,40);FANG=(240,232,220);EAR=(150,90,110)
def bat(d,wing,swoop=0,dead=0):
    # wing: angle factor -1 (down) .. 1 (up)
    bx,by=CX,CY
    for side in (-1,1):
        if swoop:
            o=-4 if side<0 else 0
            pts=[(bx+2,by-3+o),(bx+19,by-8+o),(bx+16,by-2+o),(bx+20,by+1+o),(bx+8,by+4+o),(bx+2,by+3+o)]
        else:
            ang=wing*1.0;L=22
            tip=(bx+side*L*math.cos(ang*.9),by-L*math.sin(ang*.9)*.8)
            elb=(bx+side*11*math.cos(ang*.6),by-11*math.sin(ang*.6)*.8-2)
            f1=(bx+side*16*math.cos(ang*.5),by-16*math.sin(ang*.5)*.6+6)
            f2=(bx+side*8,by+7)
            pts=[(bx+side*2,by-3),elb,tip,f1,(tip[0]*.4+f2[0]*.6,f2[1]-1),f2,(bx+side*2,by+4)]
        d.polygon(pts,fill=MEM,outline=OUT)
        if not swoop:
            d.line([(bx+side*2,by-3),elb,tip],fill=BONE);d.line([elb,f1],fill=MEML);d.line([elb,f2],fill=MEML)
    # body + head (facing left)
    d.ellipse([bx-5,by-4,bx+5,by+8],fill=FUR,outline=OUT);d.ellipse([bx-3,by-2,bx+3,by+5],fill=FURL)
    hx,hy=bx-1,by-6
    d.ellipse([hx-4,hy-3,hx+4,hy+4],fill=FUR,outline=OUT)
    d.polygon([(hx-4,hy-1),(hx-6,hy-8),(hx-1,hy-3)],fill=EAR,outline=OUT);d.polygon([(hx+1,hy-3),(hx+3,hy-9),(hx+4,hy-1)],fill=EAR,outline=OUT)
    if dead:d.line([(hx-3,hy),(hx-1,hy+1)],fill=OUT);d.line([(hx+1,hy),(hx+3,hy+1)],fill=OUT)
    else:d.point((hx-2,hy),fill=EYE);d.point((hx+2,hy),fill=EYE);d.point((hx-3,hy),fill=EYE)
    d.point((hx-1,hy+3),fill=FANG);d.point((hx+1,hy+3),fill=FANG)
    d.line([(bx-2,by+8),(bx-3,by+11)],fill=OUT);d.line([(bx+2,by+8),(bx+3,by+11)],fill=OUT)   # feet
A={}
def fr(**k):
    im=Image.new('RGBA',(FW,FH));bat(ImageDraw.Draw(im),**k);return im
A['fly']=[fr(wing=1),fr(wing=.35),fr(wing=-.45),fr(wing=.35)]
A['swoop']=[fr(wing=0,swoop=1)]
A['hurt']=[fr(wing=.9)]
A['death']=[fr(wing=-.8,dead=1).rotate(150,resample=Image.NEAREST)]
rows=list(A.items());SH=Image.new('RGBA',(FW*4,FH*len(rows)));meta={}
for r,(n,ims) in enumerate(rows):
    for i,im in enumerate(ims):SH.alpha_composite(im,(i*FW,r*FH))
    meta[n]=dict(fw=FW,fh=FH,n=len(ims),ax=CX,ay=CY,x=0,y=r*FH,img='bat')
SH.save('/home/claude/pod2/crawl_bat.png')
a=json.load(open('/home/claude/pod2/crawl_atlas.json'));a['bat']=meta;json.dump(a,open('/home/claude/pod2/crawl_atlas.json','w'))
pv=Image.new('RGBA',SH.size,(40,50,60,255));pv.alpha_composite(SH);pv.resize((SH.width*5,SH.height*5),0).save('/tmp/bat.png')
