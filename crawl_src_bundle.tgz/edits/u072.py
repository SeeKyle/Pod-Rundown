u='/home/claude/pod2/crawl_ui.js';t=open(u).read()
def rep(a,b,n=1):
    global t
    c=t.count(a);assert c==n,(c,a[:90]);t=t.replace(a,b)
i=t.index("        ${hungry.has(k)?(()=>{const f=fedOf(run,k),m=missingOf(run,k);");j=t.index("          :(k==='robot'?`<div",i)
t=t[:i]+r"""        ${k!=='robot'&&!run.heroes[k].dead?(()=>{const n=needsOf(run,k);const fc=upgT(run,'smoker')?.5:1;   /* 0.12.72 Hunger & Thirst tiers */
          const hc=['#7ee081','#ffd060','#ff9040','#ff4a3a'][n.h],tc=['#7fd0ff','#ffd060','#ff9040','#ff4a3a'][n.t];
          const hT=n.h?`Next stage: heals on them ${Math.round(HUNGER.heal[n.h]*100)}% weaker, ${Math.round(HUNGER.spd[n.h]*100)}% slower moving and attacking, -${HUNGER.acc[n.h]} accuracy, and they start with ${Math.round(HUNGER.hp[n.h]*100)}% less HP.`:'Well fed.';
          const tT=n.t?`Next stage: foggy head (Perception -${THIRST.perc[n.t]}, plans and focus -${THIRST.think[n.t]}, decisions ${Math.round((THIRST.slow[n.t]-1)*100)}% slower) and a slow life drain (${(THIRST.drain[n.t]*100).toFixed(2)}% of max HP a second).`:'Well watered.';
          return `<div class="cc-sub" style="font-size:11px;margin:4px 0 0">🍖 <b style="color:${hc};cursor:help" title="${esc(hT)}">${HUNGER.names[n.h]}</b> ${n.h?btn(`data-feed="${k}|food" ${run.food>=fc?'':'disabled'}`,'🥫 Eat','Use '+(fc<1?'half a ration (smoked)':'1 food')+': Hunger -'+(upgT(run,'kitchen')?2:1)):''} · 💧 <b style="color:${tc};cursor:help" title="${esc(tT)}">${THIRST.names[n.t]}</b> ${n.t?btn(`data-feed="${k}|water" ${run.water>=1?'':'disabled'}`,'💧 Drink','Use 1 water: Thirst -'+(upgT(run,'purifier')?2:1)):''}${n.h||n.t?'<span style="opacity:.75"> · it only gets worse if ignored</span>':''}</div>`;})()
"""+t[j:]
rep("bg.textContent='Go hungry? '+left.map(k=>heroDef(k).name+' -'+missingOf(run,k)*10+'%').join(', ')+' HP ▶';","bg.textContent='Leave hungry/thirsty? '+left.map(k=>{const n=needsOf(run,k);return heroDef(k).name+(n.h?' '+HUNGER.names[n.h]:'')+(n.t?' '+THIRST.names[n.t]:'');}).join(', ')+' ▶';")
rep("const left=(run.needFeed||[]).filter(k=>missingOf(run,k)&&!run.heroes[k].dead);","const left=run.team.filter(k=>missingOf(run,k)&&!run.heroes[k].dead);")
rep("${(run.needFeed||[]).some(k=>missingOf(run,k)&&run.heroes[k]&&!run.heroes[k].dead)?","${run.team.some(k=>missingOf(run,k)&&run.heroes[k]&&!run.heroes[k].dead)?")
# unit pips
rep("const PIPS=[","const PIPS=[['hunger','#ff9a40','food'],['thirst','#5ab8ff','drip'],")
rep("  if(k==='rain'){","  if(k==='food'){ctx.fillRect(x,y,3,1);ctx.fillRect(x+1,y+1,1,2);ctx.fillStyle='#ffd8a0';ctx.fillRect(x,y,1,1);}   // 0.12.72 hunger: a little drumstick\n  else if(k==='drip'){ctx.fillRect(x+1,y,1,1);ctx.fillRect(x,y+1,3,1);ctx.fillRect(x+1,y+2,1,1);ctx.fillStyle='#ff6a4a';ctx.fillRect(x+2,y+2,1,1);}   // thirst: a drop with a red fleck\n  else if(k==='rain'){")
t=t.replace("v0.12.71","v0.12.72")
open(u,'w').write(t);print('ok')
