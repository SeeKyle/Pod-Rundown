u='/home/claude/pod2/crawl_ui.js';t=open(u).read()
def rep(a,b,n=1):
    global t
    c=t.count(a);assert c==n,(c,a[:90]);t=t.replace(a,b)
rep("function beginStage(){\n  const s=SLOT(),run=s.run;panel.hidden=true;CC.paused=false;",
"""function beginStage(){
  const s=SLOT(),run=s.run;panel.hidden=true;CC.paused=false;
  /* 0.12.73 (Kyle) Retry: snapshot everything at the start of the stage (heroes, HP, items, herbs, kit, buffs, gold, parts, supplies, run state) */
  if(run.retries==null)run.retries=1;try{const r2=Object.assign({},run);delete r2.snap;run.snap=JSON.stringify({run:r2,gold:s.gold||0,parts:s.parts||0,heroes:s.heroes,best:s.best});}catch(e){run.snap=null;}""")
rep("  // defeat\n  sfx('die');","""  // defeat
  if((run.retries==null?1:run.retries)>0&&run.snap){sfx('die');CC.game=null;   /* 0.12.73: one retry per run (doesn't stack); beating the stage gives it back */
    const P=showPanel(`<div class="cc-h" style="color:#ff5a5a">YOUR PARTY HAS FALLEN</div><div class="cc-h2">Stage ${run.stage}${run.prestige?' · ★'+run.prestige:''}</div>
      <p class="cc-sub">You have <b style="color:#a6ff2e">1 retry</b> left this run. Retrying puts everything back exactly as it was when this stage started: every hero's HP, items, herbs and kit, your gold, parts and supplies. Beat the stage this time and you get the retry back. Fall again and the run is over.</p>
      <div class="cc-row" style="margin-top:12px"><button class="cc-btn go" data-retry>↻ RETRY STAGE ${run.stage}</button><button class="cc-btn warn" data-giveup>Give up the run</button></div>`);
    P.querySelector('[data-retry]').onclick=()=>{const S=JSON.parse(run.snap);s.run=S.run;s.run.snap=run.snap;s.run.retries=0;s.run.retryUsed=1;s.gold=S.gold;s.parts=S.parts;s.heroes=S.heroes;if(S.best)s.best=S.best;persist();beginStage();};
    P.querySelector('[data-giveup]').onclick=e=>{if(!confirmInline(e.currentTarget,'Really end the run?'))return;run.retries=0;run.snap=null;finishStage(g);};
    return;}
  sfx('die');""")
rep("    run.needFeed=run.team.filter(k=>k!=='robot');   /* 0.12.58: everyone needs food AND water at camp, except the Warhound */",
    "    run.needFeed=run.team.filter(k=>k!=='robot');   /* 0.12.58: everyone needs food AND water at camp, except the Warhound */\n    if(run.retryUsed){run.retryUsed=0;run.retries=1;run.campLog2='↻ Stage beaten on the retry: you get your retry back.';}   /* 0.12.73 */")
t=t.replace("v0.12.72","v0.12.73")
open(u,'w').write(t);print('ok')
