p='/home/claude/pod2/crawl_src.js';s=open(p).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:90]);s=s.replace(a,b)
# tables + functions (replace old fed model)
i=s.index("/* 0.12.58 (Kyle): every unit wants food AND water.");j=s.index("function triageBuild(",i)
s=s[:i]+r"""/* 0.12.72 (Kyle) Hunger & Thirst: tiers that only get worse while ignored. Every time the team gets back to camp each unit that eats and drinks
   goes up one tier of each (max 3); each food lowers Hunger by 1 and each water lowers Thirst by 1 (by 2 with the Camp Kitchen / Water Purifier).
   Whatever tier they leave camp at lasts the whole next stage. The Warhound needs neither. Hard-roguelike punishing on purpose. */
const HUNGER={names:['Satiated','Hungry','Very Hungry','Starving'],heal:[0,.15,.3,.5],spd:[0,.06,.13,.22],acc:[0,2,5,9],hp:[0,.1,.2,.35]};
const THIRST={names:['Quenched','Parched','Mildly Dehydrated','Severely Dehydrated'],perc:[0,2,4,7],think:[0,1,2,4],slow:[1,1.15,1.35,1.65],drain:[0,.0004,.001,.002]};
function needsOf(run,k){const hv=run.heroes&&run.heroes[k];return {h:(hv&&hv.hunger)||0,t:(hv&&hv.thirst)||0};}
function fedOf(run,k){const n=needsOf(run,k);return {food:!n.h,water:!n.t};}   // kept for the UI: true = nothing needed
function missingOf(run,k){if(k==='robot'||!run.team.includes(k))return 0;const n=needsOf(run,k);return n.h+n.t;}
function feedUnit(run,k,what){if(k==='robot')return false;const hv=run.heroes[k];if(!hv||hv.dead)return false;const key=what==='water'?'thirst':'hunger';if(!(hv[key]>0))return false;
  if(what==='water'){if(run.water<1)return false;run.water-=1;}else{const cost=upgT(run,'smoker')?.5:1;if(run.food<cost-1e-9)return false;run.food=Math.round((run.food-cost)*2)/2;}
  hv[key]=Math.max(0,hv[key]-(upgT(run,what==='water'?'purifier':'kitchen')?2:1));return true;}
/* Feed all: spends what's in the pack on whoever needs it most: the worst tiers first, then lowest HP; never wastes a ration on someone who's fine */
function feedAll(run){let n=0;for(let guard=0;guard<40;guard++){const L=run.team.filter(k=>k!=='robot'&&run.heroes[k]&&!run.heroes[k].dead&&missingOf(run,k));if(!L.length)break;
    const pick=(key)=>L.filter(k=>run.heroes[k][key]>0).sort((a,b)=>(run.heroes[b][key]-run.heroes[a][key])||((run.heroes[a].hpf==null?1:run.heroes[a].hpf)-(run.heroes[b].hpf==null?1:run.heroes[b].hpf)))[0];
    const a=pick('hunger'),b=pick('thirst');let did=0;if(a&&feedUnit(run,a,'food')){n++;did=1;}if(b&&feedUnit(run,b,'water')){n++;did=1;}if(!did)break;}return n;}
/* leaving camp: Hunger takes its bite out of their HP for the next stage (Thirst works during the stage) */
function campDepart(run){run.scoutNow=run.scoutPick||null;run.scoutTier=upgT(run,'tower');run.scoutOffers=null;run.scoutPick=null;const starved=[];
  for(const k of run.team){if(k==='robot')continue;const hv=run.heroes[k];if(!hv||hv.dead)continue;const n=needsOf(run,k);if(n.h)hv.hpf=Math.max(.05,(hv.hpf==null?1:hv.hpf)*(1-HUNGER.hp[n.h]));if(n.h||n.t)starved.push(k);}
  run.needFeed=[];run.fed={};return starved;}
"""+s[j:]
# camp arrival: everyone who eats gets one tier hungrier and thirstier; filtration = one free drink
rep("  const hungry=(run.needFeed||[]).filter(k=>run.team.includes(k)&&k!=='robot');run.needFeed=hungry;",
    "  const hungry=(run.needFeed||[]).filter(k=>run.team.includes(k)&&k!=='robot');run.needFeed=hungry;\n  for(const k of hungry){const hv=run.heroes[k];if(!hv||hv.dead)continue;hv.hunger=Math.min(3,(hv.hunger||0)+1);hv.thirst=Math.min(3,(hv.thirst||0)+1);}   /* 0.12.72 Hunger & Thirst */")
rep("if(w&&hungry.length&&Math.random()<[.25,.5,.75][w-1]){const k=hungry[Math.floor(Math.random()*hungry.length)];run.fed[k]={water:'auto'};log.push(`💧 Water Filtration gave ${heroDef(k).name} water`);}",
    "if(w&&hungry.length&&Math.random()<[.25,.5,.75][w-1]){const th=hungry.filter(k=>run.heroes[k].thirst>0);const k=th[Math.floor(Math.random()*th.length)];if(k){run.heroes[k].thirst=Math.max(0,run.heroes[k].thirst-1);log.push(`💧 Water Filtration gave ${heroDef(k).name} a drink`);}}")
# new buildings
rep("  smoker:{name:'Smokehouse',icon:'🍖',tiers:[125],txt:()=>'Smoked rations go further: one food feeds two units.'},",
    "  smoker:{name:'Smokehouse',icon:'🍖',tiers:[125],txt:()=>'Smoked rations go further: one food feeds two units.'},\n  kitchen:{name:'Camp Kitchen',icon:'🍲',tiers:[200],txt:()=>'Real cooked meals: each food lowers Hunger by 2 tiers instead of 1.'},   /* 0.12.72 food quality */\n  purifier:{name:'Water Purifier',icon:'🚰',tiers:[200],txt:()=>'Clean water: each water lowers Thirst by 2 tiers instead of 1.'},   /* 0.12.72 water quality */")
# in-game effects
rep("if(h.courage){h.atk*=1.2;h.acc-=10;}","if(h.courage){h.atk*=1.2;h.acc-=10;}{const sv=this.run&&this.run.heroes&&this.run.heroes[h.key];const hu=(sv&&sv.hunger)||0,th=(sv&&sv.thirst)||0;h.hunger=hu;h.thirst=th;if(hu)h.acc-=HUNGER.acc[hu];}   /* 0.12.72 hunger: shaky aim */")
rep("    this.mods=this.demo?scoutMods(null):scoutMods(this.run);","    for(const h of this.heroes)if(h.thirst>0){const T=h.thirst;addMood(h,{perc:-THIRST.perc[T],plan:-THIRST.think[T],exec:-THIRST.think[T]},1e9,'thirst');}   /* 0.12.72 thirst: foggy head */\n    this.mods=this.demo?scoutMods(null):scoutMods(this.run);")
rep("  healHero(h,amt,quiet,by){if(!h||!h.alive||amt<=0||h.dog)return;","  healHero(h,amt,quiet,by){if(!h||!h.alive||amt<=0||h.dog)return;if(h.hunger>0)amt*=1-HUNGER.heal[h.hunger];   /* 0.12.72: a starving body heals badly */")
rep("function dynMv(h){let m=1;","function dynMv(h){let m=1-(h.hunger>0?HUNGER.spd[h.hunger]:0);")
rep("*(h.lethalT>0?1.75:1);h.rT=(h.rT||0)+dt*h.rangedSpd*spdB;","*(h.lethalT>0?1.75:1)*(h.hunger>0?1-HUNGER.spd[h.hunger]:1);h.rT=(h.rT||0)+dt*h.rangedSpd*spdB*(h.hunger>0?1-HUNGER.spd[h.hunger]:1);")
rep("    u.thinkT=.12+4.2*Math.pow(1-trait(u,'plan'),1.5)+1.2*(1-trait(u,'pace'))+Math.random()*.25;return true;},","    u.thinkT=(.12+4.2*Math.pow(1-trait(u,'plan'),1.5)+1.2*(1-trait(u,'pace'))+Math.random()*.25)*(u.thirst>0?THIRST.slow[u.thirst]:1);return true;},   // 0.12.72: thirst slows decisions")
# thirst HP drain per second (in the cozy line area of gunner? better in step: add near dropLost in main step)
rep("    const T=this;const al=this.alive();this.dropLost();","    const T=this;const al=this.alive();this.dropLost();for(const h of this.heroes)if(h.alive&&h.thirst>0&&!this.over){h.hp-=h.max*THIRST.drain[h.thirst]*dt;if(h.hp<1)h.hp=1;}   /* 0.12.72: dehydration drains a little life (never kills on its own) */")
open(p,'w').write(s);print('ok')
