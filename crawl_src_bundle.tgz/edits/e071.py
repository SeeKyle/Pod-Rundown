p='/home/claude/pod2/crawl_src.js';s=open(p).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:90]);s=s.replace(a,b)
rep("/* leaving camp: anyone still hungry","""/* 0.12.71 (Kyle) Feed all: spends what's in the pack on whoever needs it, in order: most missing first (needs both before needs one),
   then lowest HP first. Smoked food (Smokehouse) costs half a ration as usual. Never spends on anyone who doesn't need it (the Warhound needs nothing). */
function feedAll(run){const L=(run.needFeed||[]).filter(k=>run.heroes[k]&&!run.heroes[k].dead&&missingOf(run,k)).sort((a,b)=>(missingOf(run,b)-missingOf(run,a))||((run.heroes[a].hpf==null?1:run.heroes[a].hpf)-(run.heroes[b].hpf==null?1:run.heroes[b].hpf)));
  let n=0;for(const k of L){const f=fedOf(run,k);if(!f.food&&feedUnit(run,k,'food'))n++;if(!fedOf(run,k).water&&feedUnit(run,k,'water'))n++;}return n;}
/* leaving camp: anyone still hungry""")
open(p,'w').write(s)
u='/home/claude/pod2/crawl_ui.js';t=open(u).read()
a="· 💧 <b>${run.water||0}</b> water</span>"
assert t.count(a)==1
t=t.replace(a,a+"""${(run.needFeed||[]).some(k=>missingOf(run,k)&&run.heroes[k]&&!run.heroes[k].dead)?` <button class="cc-btn" data-feedall style="padding:2px 8px;font-size:12px;vertical-align:middle" title="Feed and water everyone who needs it: most-needy and lowest HP first, never wastes supplies"><svg width="16" height="14" viewBox="0 0 16 14" style="vertical-align:-2px;image-rendering:pixelated"><rect x="1" y="5" width="7" height="8" fill="#b8642a"/><rect x="1" y="5" width="7" height="2" fill="#e8d0a0"/><rect x="2" y="8" width="5" height="3" fill="#e8302a"/><rect x="1" y="12" width="7" height="1" fill="#6a3a18"/><path d="M12 2 L14.5 7 A2.6 2.6 0 1 1 9.5 7 Z" fill="#4ab8ff"/><rect x="10.5" y="7" width="1" height="2" fill="#d8f4ff"/></svg> Feed all</button>`:''}""")
a="  P.querySelectorAll('[data-feed]').forEach(b=>b.onclick="
assert t.count(a)==1
t=t.replace(a,"  {const fa=P.querySelector('[data-feedall]');if(fa)fa.onclick=()=>{if(feedAll(run)){sfx('level');persist();showCamp();}else{fa.textContent='Not enough supplies';}};}\n"+a)
open(u,'w').write(t);print('ok')
