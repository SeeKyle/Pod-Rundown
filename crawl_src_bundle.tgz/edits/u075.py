u='/home/claude/pod2/crawl_ui.js';t=open(u).read()
def rep(a,b,n=1):
    global t
    c=t.count(a);assert c==n,(c,a[:90]);t=t.replace(a,b)
rep("XIMG.jp.src='crawl_jp.png?v=__VER__';","XIMG.jp.src='crawl_jp.png?v=__VER__';XIMG.eng=new Image();XIMG.eng.src='crawl_eng.png?v=__VER__';")
rep("      else if(h.jet&&U.jet){","      else if((h.building||h.repairing)&&U.kneel){A=U.kneel;f=Math.min(A.n-1,2+Math.floor(g.t*6)%Math.max(1,A.n-2));}   // 0.12.75 Engineer: kneeling, working\n      else if(h.jet&&U.jet){")
rep("  if(h.cast&&h.cast.T)return [h.cast.t/h.cast.T,'#ffd23f',1];","  if(h.cast&&h.cast.T)return [h.cast.t/h.cast.T,'#ffd23f',1];\n  if(h.building)return [h.building.t/h.building.T,'#ffb040',1];\n  if(h.repairing&&h.repairing.tgt){const T=h.repairing.tgt;return [T.hp/T.max,'#7ee081',1];}")
rep("const PIPS=[","const PIPS=[['kitHits','#c8d0dc','shield'],")
# buildings into the depth-sorted list
rep("  const items=[...(g.tentacles||[]).map(T=>[T.gy+.1,0,T.x,()=>drawTent(T)]),","  const items=[...(g.blds||[]).map(b=>[b.gy-.3,-1,b.x,()=>drawBld(b)]),...(g.tentacles||[]).map(T=>[T.gy+.1,0,T.x,()=>drawTent(T)]),")
rep("  const drawTent=T=>{","""  /* 0.12.75 Engineer's buildings, drawn from shapes: the watchtower (steel legs, X braces, chain-link panels, plank floors with low walls,
     a ladder up the whole thing and a sign per tier), the concrete barrier, the tesla coil and the car turret */
  const drawBld=b=>{const x=Math.round(b.x),gy=b.gy;ctx.save();if(b.hitT>0){ctx.globalAlpha=.75;}
    if(b.k==='tower'){const W=21,TH=30;const top=gy-TH*b.tier;
      shadow(ctx,x,gy,22);
      for(let i=0;i<b.tier;i++){const y0=gy-TH*i,y1=y0-TH;
        ctx.strokeStyle='rgba(170,180,190,.35)';ctx.lineWidth=.4;   // chain-link: diamond lattice on the lower part of each tier
        for(let k=-W;k<=W;k+=3){ctx.beginPath();ctx.moveTo(x+k,y0-1);ctx.lineTo(x+k+12,y0-13);ctx.stroke();ctx.beginPath();ctx.moveTo(x+k,y0-1);ctx.lineTo(x+k-12,y0-13);ctx.stroke();}
        ctx.fillStyle='#4a5058';ctx.fillRect(x-W-1,y0-14,2*W+2,1);
        ctx.strokeStyle='#6a7280';ctx.lineWidth=1.1;ctx.beginPath();ctx.moveTo(x-W+2,y0);ctx.lineTo(x+W-2,y1+2);ctx.moveTo(x+W-2,y0);ctx.lineTo(x-W+2,y1+2);ctx.stroke();   // X brace
        ctx.fillStyle='#6a4a2a';ctx.fillRect(x-W-3,y1,2*W+6,2.5);ctx.fillStyle='#8a6438';ctx.fillRect(x-W-3,y1,2*W+6,1);   // plank floor
        ctx.fillStyle='#4e5560';ctx.fillRect(x-W-3,y1-5,1.5,5);ctx.fillRect(x+W+1.5,y1-5,1.5,5);ctx.fillRect(x-W-3,y1-5,2*W+6,1.2);   // low wall rail
        const sx=x-6,sy=y0-24;ctx.fillStyle='#1a1410';ctx.fillRect(sx-1,sy-1,14,10);   // the tier's sign
        if(i===0){ctx.fillStyle='#f2f2ea';ctx.fillRect(sx,sy,12,8);ctx.fillStyle='#d0202a';ctx.fillRect(sx+5,sy+1,2,6);ctx.fillRect(sx+3,sy+3,6,2);}
        else if(i===1){ctx.fillStyle='#4a5a2a';ctx.fillRect(sx,sy,12,8);ctx.fillStyle='#d8b040';for(let q=0;q<3;q++){ctx.fillRect(sx+2+q*3,sy+2,2,5);ctx.fillStyle='#b08020';ctx.fillRect(sx+2+q*3,sy+2,2,1);ctx.fillStyle='#d8b040';}}
        else{ctx.fillStyle='#2a3a5a';ctx.fillRect(sx,sy,12,8);ctx.fillStyle='#9ad0ff';ctx.beginPath();ctx.arc(sx+4,sy+4,2,0,7);ctx.arc(sx+8,sy+4,2,0,7);ctx.fill();ctx.fillStyle='#1a1410';ctx.fillRect(sx+5.5,sy+3,1,2);}}
      ctx.fillStyle='#5a626e';ctx.fillRect(x-W,top,2.2,gy-top);ctx.fillRect(x+W-2.2,top,2.2,gy-top);ctx.fillStyle='#8a94a2';ctx.fillRect(x-W,top,.8,gy-top);ctx.fillRect(x+W-2.2,top,.8,gy-top);   // steel legs
      ctx.fillStyle='#7a5a34';ctx.fillRect(x+W+3,top-2,1,gy-top+2);ctx.fillRect(x+W+7,top-2,1,gy-top+2);for(let y=gy-2;y>top;y-=3)ctx.fillRect(x+W+3,y,5,.8);   // ladder all the way up
      if(b.tier>=3){ctx.fillStyle='#3a3f48';ctx.fillRect(x-W-3,top-14,2,9);ctx.fillRect(x+W+1,top-14,2,9);ctx.fillStyle='#6a4a2a';ctx.fillRect(x-W-4,top-15,2*W+8,2);}   // lookout roof
      if(b.hp<b.max){const w=30;ctx.fillStyle='#000a';ctx.fillRect(x-w/2-1,top-20,w+2,3);ctx.fillStyle='#ffd23f';ctx.fillRect(x-w/2,top-19,w*Math.max(0,b.hp/b.max),1);}}
    else if(b.k==='barrier'){shadow(ctx,x,gy,10);ctx.fillStyle='#22201e';ctx.beginPath();ctx.moveTo(x-9,gy+.5);ctx.lineTo(x+9,gy+.5);ctx.lineTo(x+6,gy-6);ctx.lineTo(x+4,gy-10);ctx.lineTo(x-4,gy-10);ctx.lineTo(x-6,gy-6);ctx.closePath();ctx.fill();
      ctx.fillStyle='#a8a49a';ctx.beginPath();ctx.moveTo(x-8,gy);ctx.lineTo(x+8,gy);ctx.lineTo(x+5.5,gy-6);ctx.lineTo(x+3.5,gy-9.5);ctx.lineTo(x-3.5,gy-9.5);ctx.lineTo(x-5.5,gy-6);ctx.closePath();ctx.fill();
      ctx.fillStyle='#c8c4b8';ctx.fillRect(x-3.5,gy-9.5,7,1);for(let k=-7;k<7;k+=3){ctx.fillStyle=(k/3|0)%2?'#e8c020':'#1a1a1a';ctx.fillRect(x+k,gy-4,3,1.4);}   // hazard band
      if(b.hp<b.max*.6){ctx.strokeStyle='#3a3630';ctx.lineWidth=.5;ctx.beginPath();ctx.moveTo(x-2,gy-9);ctx.lineTo(x,gy-5);ctx.lineTo(x-1,gy-1);ctx.stroke();}
      if(b.hp<b.max){ctx.fillStyle='#000a';ctx.fillRect(x-8,gy-14,16,3);ctx.fillStyle='#ffd23f';ctx.fillRect(x-7,gy-13,14*Math.max(0,b.hp/b.max),1);}}
    else if(b.k==='tesla'){shadow(ctx,x,gy,6);ctx.fillStyle='#3a3f48';ctx.fillRect(x-4,gy-4,8,4);ctx.fillStyle='#22262c';ctx.fillRect(x-1,gy-16,2,12);
      for(let y=gy-15;y<gy-5;y+=2){ctx.fillStyle='#c87a3a';ctx.fillRect(x-2.5,y,5,1);}ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,x,gy-19,3+Math.sin(g.t*12),'#6ad0ff',.5);glow(ctx,x,gy-19,1.4,'#e8fbff',1);
      if(Math.random()<.5){ctx.strokeStyle='rgba(160,230,255,.8)';ctx.lineWidth=.5;zig(x,gy-19,x+(Math.random()-.5)*12,gy-19+(Math.random()-.5)*10,3,1.5);}ctx.restore();
      ctx.fillStyle='#000a';ctx.fillRect(x-6,gy-25,12,2.5);ctx.fillStyle='#6ad0ff';ctx.fillRect(x-5,gy-24.5,10*Math.max(0,b.hp/b.max),1);}
    else if(b.k==='turret'){const d=b.face||-1,ty=gy-22;ctx.fillStyle='#2a2e34';ctx.fillRect(x-3,ty,6,4);ctx.fillStyle='#4a525c';ctx.fillRect(x-2,ty-3,5,3);ctx.fillStyle='#1a1c20';ctx.fillRect(d>0?x+2:x-9,ty-2,7,1.5);
      ctx.fillStyle='#e8c020';ctx.fillRect(x-3,ty+3,6,.8);if(b.hp<b.max){ctx.fillStyle='#000a';ctx.fillRect(x-6,ty-7,12,2.5);ctx.fillStyle='#ffd23f';ctx.fillRect(x-5,ty-6.5,10*Math.max(0,b.hp/b.max),1);}}
    ctx.restore();};
  const engFx=()=>{for(const S of g.satchels||[]){const y=S.gy-(S.hgt||0)*.5-2;ctx.fillStyle='#3a2a18';ctx.fillRect(S.x-3,y-3,6,4);ctx.fillStyle='#6a4a28';ctx.fillRect(S.x-3,y-3,6,1);ctx.fillStyle='#2a1c10';ctx.fillRect(S.x-1,y-5,2,2);   /* 0.12.75 satchel: canvas pouch, strap, blinking red light */
      if(Math.floor(g.t*3)%2){ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,S.x+2,y-2,1.6,'#ff2a1a',.9);ctx.restore();}}
    for(const f of g.fx){const k=f.t/f.life;if(f.k==='spark'){ctx.fillStyle=k<.4?'#fff6c0':'#ffb040';for(let i=0;i<3;i++)ctx.fillRect(f.x+Math.cos(i*2.1+f.x)*k*6,f.gy-4-Math.sin(i*2.1+f.x)*k*5+k*k*6,1,1);}
      else if(f.k==='tracer'){ctx.save();ctx.globalCompositeOperation='lighter';ctx.strokeStyle=`rgba(255,220,140,${1-k})`;ctx.lineWidth=.6;ctx.beginPath();ctx.moveTo(f.x0,f.y0);ctx.lineTo(f.x1,f.y1);ctx.stroke();glow(ctx,f.x0,f.y0,1.6,'#ffd080',.8*(1-k));ctx.restore();}}
    for(const h of g.alive())if(h.kitHits>0){ctx.fillStyle='rgba(200,208,220,.55)';ctx.fillRect(Math.round(g.heroX(h))-3,(h.gy||G)-14,6,1);}};
  const drawTent=T=>{""")
rep("  voidFx();slamDraw();","  engFx();voidFx();slamDraw();")
t=t.replace("v0.12.74","v0.12.75")
open(u,'w').write(t);print('ok')
