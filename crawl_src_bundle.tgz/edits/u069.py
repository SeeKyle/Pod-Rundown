u='/home/claude/pod2/crawl_ui.js';t=open(u).read()
def rep(a,b,n=1):
    global t
    c=t.count(a);assert c==n,(c,a[:90]);t=t.replace(a,b)
rep("  const pinnedDraw=()=>{","""  /* 0.12.69 Hatchet_Leap landing: a cracked-earth decal that lingers, dust clouds rolling out, pebbles thrown up, a short burst of energy */
  const slamDraw=()=>{for(const f of g.fx){if(f.k!=='crack')continue;const k=f.t/f.life,a=k>.7?(1-k)/.3:1;let sd=Math.floor(f.x*13+f.gy*7);const R=()=>{sd=(sd*9301+49297)%233280;return sd/233280;};
      ctx.save();ctx.globalAlpha=a;ctx.fillStyle='rgba(20,12,8,.35)';ctx.beginPath();ctx.ellipse(f.x,f.gy,f.r*.55,f.r*.16,0,0,7);ctx.fill();
      for(let i=0;i<8;i++){let ang=i/8*6.283+R()*.5,x=f.x,y=f.gy,L=f.r*(.55+R()*.6);ctx.beginPath();ctx.moveTo(x,y);
        for(let j=1;j<=3;j++){ang+=(R()-.5)*.7;x=f.x+Math.cos(ang)*L*j/3;y=f.gy+Math.sin(ang)*L*j/3*.28;ctx.lineTo(x,y);}
        ctx.strokeStyle='#1a0e08';ctx.lineWidth=1.1-.0*i;ctx.stroke();ctx.strokeStyle='rgba(200,150,100,.35)';ctx.lineWidth=.4;ctx.beginPath();ctx.moveTo(f.x,f.gy+.6);ctx.lineTo(x,y+.6);ctx.stroke();}
      ctx.restore();}
    for(const f of g.fx){if(f.k!=='slam')continue;const k=f.t/f.life;ctx.save();
      if(k<.35){ctx.globalCompositeOperation='lighter';glow(ctx,f.x,f.gy-4,f.r*(.5+k*2),'#ffb040',.45*(1-k/.35));glow(ctx,f.x,f.gy-3,4,'#fff0c0',.7*(1-k/.35));ctx.globalCompositeOperation='source-over';
        ctx.strokeStyle=`rgba(255,200,110,${.8*(1-k/.35)})`;ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(f.x,f.gy-1,f.r*(.4+k*3.4),f.r*(.12+k*.9),0,0,7);ctx.stroke();}
      for(let i=0;i<6;i++){const s=i%2?1:-1,d=f.r*(.3+k*1.4)*(1+i%3*.25),r=(2.2+i%3)*(.6+k*1.2);puffAt(f.x+s*d,f.gy-2-k*4-(i%3),r,.55*(1-k),'#9a8670');}   // dust rolling out both ways
      for(let i=0;i<10;i++){const a=((f.seed+i*2.4)%3.1)+.02,sp=18+(i*7%11)*2,px=f.x+Math.cos(a)*sp*k*1.4*(i%2?1:-1),py=f.gy-2-(Math.sin(a)*40*k-60*k*k)-2;
        if(py<f.gy){ctx.fillStyle=i%3?'#6a5a48':'#a89880';ctx.globalAlpha=1-k*.6;ctx.fillRect(px,py,i%4?1:1.5,i%4?1:1.5);}}   // pebbles
      ctx.restore();}};
  const pinnedDraw=()=>{""")
rep("  pinnedDraw();bottleDraw();","  slamDraw();pinnedDraw();bottleDraw();")
t=t.replace("v0.12.68","v0.12.69")
open(u,'w').write(t);print('ok')
