u='/home/claude/pod2/crawl_ui.js';t=open(u).read()
def rep(a,b,n=1):
    global t
    c=t.count(a);assert c==n,(c,a[:90]);t=t.replace(a,b)
rep("    const bx=h.x+(h.dodgeX||0)+(h.wanderX||0);plate(ctx,h,bx,G-(hbOf(h).h+17),22,true);};",
"""    const bx=h.x+(h.dodgeX||0)+(h.wanderX||0);plate(ctx,h,bx,G-(hbOf(h).h+17),22,true);
    {const cb=castBar(h);if(cb&&!PLATE_OFF){const w=18,x=Math.round(bx-w/2),y=Math.round(G-(hbOf(h).h+17))+6;const k=Math.max(0,Math.min(1,cb[0]));   /* 0.12.71: cast / channel / reload bar under the plate */
      ctx.fillStyle='#120a14';ctx.fillRect(x-1,y-1,w+2,3);ctx.fillStyle='#2a2430';ctx.fillRect(x,y,w,1);ctx.fillStyle=cb[1];ctx.fillRect(x,y,Math.max(1,Math.round(w*k)),1);
      if(cb[2]){ctx.fillStyle='#ffffff';ctx.globalAlpha=.55+.45*Math.sin(g.t*12);ctx.fillRect(x+Math.round(w*k)-1,y,1,1);ctx.globalAlpha=1;}}}};""")
rep("let PLATE_OFF=false;","""let PLATE_OFF=false;
/* 0.12.71 (Kyle): a cast/reload bar for anything that casts, channels or reloads: [progress 0..1, colour, still filling?]
   gold = casting, violet = channelling, grey = reloading, red = lazer charge/burn, green = smoking/repairs */
function castBar(h){const C=h.base&&h.base.char;if(!C||!h.alive)return null;const R=C.ranged;
  if(h.cast&&h.cast.T)return [h.cast.t/h.cast.T,'#ffd23f',1];
  if(h.lz&&R&&R.lazer){const L=R.lazer;return h.lz.t<L.charge?[h.lz.t/L.charge,'#ff4a3a',1]:[1-(h.lz.t-L.charge)/L.fire,'#ff8a6a',0];}
  if(h.lzReload>0&&R&&R.lazer)return [1-h.lzReload/R.lazer.reload,'#a8b0bc',1];
  if(h.syph)return [1-h.syph.t/((C.abilities||[]).find(a=>a.id==='syphon')||{dur:3}).dur,'#b070ff',0];
  if(h.nano)return [h.nano.t/((C.abilities||[]).find(a=>a.id==='nano')||{dur:5}).dur,'#5af0d0',1];
  if(h.smoking)return [h.smoking.t/2,'#7ee081',1];
  if(h.camping>0)return [1-h.camping/(h.campT0||1.8),'#ffb040',1];
  if(h.summonT>0)return [1-h.summonT/(h.summonT0||.8),'#b070ff',1];
  if(h.casting>0)return [1-h.casting/(h.castT0||.5),'#7ee081',1];
  if(h.setting&&h.setting.T)return [h.setting.t/h.setting.T,'#ffd23f',1];
  if(h.tossing&&h.tossing.T)return [h.tossing.t/h.tossing.T,'#ffd23f',1];
  if(h.volley>0)return [1-h.volley/(h.volleyT0||.6),'#ffd23f',1];
  if(h.blowing>0)return [1-h.blowing/(h.blowT0||.7),'#ffd23f',1];
  if(h.calling&&h.calling.T)return [h.calling.t/h.calling.T,'#ffd23f',1];
  if(R&&R.clip>0&&h.ammo<=0&&R.reload)return [(h.reloadT||0)/R.reload,'#a8b0bc',1];
  if(h.search&&h.search.T)return [h.search.t/h.search.T,'#9ad0ff',1];
  return null;}""")
t=t.replace("v0.12.70","v0.12.71")
open(u,'w').write(t);print('ok')
