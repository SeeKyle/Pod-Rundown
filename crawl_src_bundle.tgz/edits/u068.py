u='/home/claude/pod2/crawl_ui.js';t=open(u).read()
def rep(a,b,n=1):
    global t
    c=t.count(a);assert c==n,(c,a[:90]);t=t.replace(a,b)
# brick: a proper little brick, less tall (7x3 in half-size units), mortar edges, two frog holes
rep("    else if(p.kind==='brick'){ctx.save();ctx.translate(x,y);ctx.rotate(p.rot||0);ctx.fillStyle='#9a3a24';ctx.fillRect(-3,-2,6,4);ctx.fillStyle='#c8603a';ctx.fillRect(-3,-2,6,1);ctx.restore();}",
"""    else if(p.kind==='brick'){ctx.save();ctx.translate(x,y);ctx.rotate(p.rot||0);   /* 0.12.68: a real-looking brick (long and flat), tumbling */
      ctx.fillStyle='#4a1a10';ctx.fillRect(-4.5,-2,9,4);ctx.fillStyle='#a8442a';ctx.fillRect(-4,-1.5,8,3);ctx.fillStyle='#c9663e';ctx.fillRect(-4,-1.5,8,1);ctx.fillStyle='#8a3220';ctx.fillRect(-4,.5,8,1);
      ctx.fillStyle='#d8c8b0';ctx.globalAlpha=.55;ctx.fillRect(-4,-1.5,1,3);ctx.fillRect(3,-1.5,1,1);ctx.globalAlpha=1;ctx.fillStyle='#5a2214';ctx.fillRect(-2,-.5,1,1);ctx.fillRect(1,-.5,1,1);ctx.restore();}""")
# dart: tiny (about 4x2 at screen size), steel tip, dark shaft, red+cream tuft, green poison glint
rep("    else if(p.kind==='dart'){const d=(p.dir||1);ctx.fillStyle='#3a2a18';ctx.fillRect(d>0?x-5:x,y,5,1);ctx.fillStyle='#5fe04a';ctx.fillRect(d>0?x:x-1,y,1,1);ctx.fillStyle='#e8e0c8';ctx.fillRect(d>0?x-6:x+5,y-1,1,3);}",
"""    else if(p.kind==='dart'){const d=(p.dir||1),X=k=>d>0?x+k:x-k-1;   /* 0.12.68: a nicer tiny dart: steel needle, dark shaft, red and cream tuft, a drop of green poison */
      ctx.fillStyle='rgba(200,255,190,.18)';ctx.fillRect(d>0?x-11:x+2,y,9,1);ctx.fillStyle='#d8dde8';ctx.fillRect(X(1),y,2,1);ctx.fillStyle='#5fe04a';ctx.fillRect(X(0),y,1,1);ctx.fillStyle='#2a1e14';ctx.fillRect(d>0?x-4:x+1,y,4,1);
      ctx.fillStyle='#c8302a';ctx.fillRect(X(-5),y-1,1,3);ctx.fillStyle='#f0e6d0';ctx.fillRect(X(-6),y-1,1,1);ctx.fillRect(X(-6),y+1,1,1);ctx.fillStyle='#e04838';ctx.fillRect(X(-6),y,1,1);}""")
# yarrow: Pinning_Shot arrow bigger + bright motion trail
rep("ctx.strokeStyle='rgba(255,240,200,.35)';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(x-d*26,y);ctx.lineTo(x-d*4,y);ctx.stroke();ctx.restore();   // faint streak behind it\n      drawUnit(ctx,B,0,x,y,ART_SCALE/B.pre/HS*1.7,null,0,0,d<0);}",
"""if(p.pin){for(let i=0;i<5;i++){ctx.strokeStyle=`rgba(255,${200-i*25},${120-i*20},${.5-i*.09})`;ctx.lineWidth=3-i*.45;ctx.beginPath();ctx.moveTo(x-d*(10+i*9),y+i*.15);ctx.lineTo(x-d*(4+i*9),y);ctx.stroke();}glow(ctx,x,y,4,'#ffb050',.3);}   /* 0.12.68 Pinning_Shot: a hot motion trail */
      else{ctx.strokeStyle='rgba(255,240,200,.35)';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(x-d*26,y);ctx.lineTo(x-d*4,y);ctx.stroke();}ctx.restore();   // faint streak behind it
      drawUnit(ctx,B,0,x,y,ART_SCALE/B.pre/HS*(p.pin?2.4:1.7),null,0,0,d<0);}""")
# pinned fx (arrow through the legs into the ground, follows the zombie) + bottle in flight + glass shatter
rep("  const rainDraw=()=>{for(const f of g.fx)if(f.k==='stuck'){","""  const pinnedDraw=()=>{for(const f of g.fx){if(f.k!=='pinned')continue;const e=f.e;if(e&&!e.dead){f.x=e.x;f.gy=e.gy!=null?e.gy:G;}const k=f.t/f.life,a=k>.85?(1-k)/.15:1;
      const B=UNITS.archer&&UNITS.archer.arrow;const x=f.x-f.dir*1.5,y=f.gy-3.5;ctx.save();ctx.globalAlpha=a;ctx.translate(x,y);ctx.rotate(f.dir>0?.62:Math.PI-.62);   /* 0.12.68: the big arrow driven through the legs into the dirt */
      if(B)drawUnit(ctx,B,0,0,0,ART_SCALE/B.pre*1.25,a,0,0,false);else{ctx.fillStyle='#8a6a4a';ctx.fillRect(-9,-.5,12,1);}ctx.restore();
      ctx.fillStyle=`rgba(60,40,24,${.6*a})`;ctx.fillRect(Math.round(f.x+f.dir*1.5)-2,Math.round(f.gy)-.5,4,1.2);   // dirt kicked up where it bit in
      if(f.t<.25)for(let i=0;i<4;i++){ctx.fillStyle=`rgba(150,120,90,${1-f.t*4})`;ctx.fillRect(f.x+f.dir*2+(i-1.5)*1.6,f.gy-1-f.t*14*(1+i%2),1,1);}}};
  const bottleDraw=()=>{for(const B of g.bottles||[]){const y=B.gy-B.hgt*.5-6;ctx.save();ctx.translate(B.x,y);ctx.rotate(B.rot);   /* 0.12.68 Bottle_Distraction: a green glass bottle tumbling in a big arc */
      ctx.fillStyle='#1e4a2a';ctx.fillRect(-1.5,-3,3,5);ctx.fillRect(-.5,-5,1,2);ctx.fillStyle='#3c8a52';ctx.fillRect(-1,-2.5,1,4);ctx.fillStyle='#bfe8c8';ctx.fillRect(-1,-2.5,.6,2);ctx.fillStyle='#8a5a30';ctx.fillRect(-.5,-5.5,1,.8);ctx.restore();
      ctx.fillStyle='rgba(0,0,0,.25)';ctx.fillRect(B.x-1.5,B.gy-.5,3,1);}
    for(const f of g.fx){if(f.k!=='glass')continue;const k=f.t/f.life;ctx.save();ctx.globalAlpha=1-k;for(let i=0;i<9;i++){const a=i*.7+1,sp=10+((i*37)%7)*2.2,dx=Math.cos(a)*sp*Math.min(1,k*2.4),up=Math.sin(Math.min(1,k*2)*Math.PI)*(4+i%3*2);
        ctx.fillStyle=i%3?'#7fd49a':'#e8fff0';ctx.fillRect(f.x+dx,f.gy-1-up,1,1);}
      ctx.strokeStyle=`rgba(230,255,240,${.7*(1-k)})`;ctx.lineWidth=.6;ctx.beginPath();ctx.ellipse(f.x,f.gy-1,6+k*24,1.5+k*6,0,0,7);ctx.stroke();   // the noise rings out
      if(k<.5){ctx.fillStyle='#ffffff';ctx.font='bold 5px monospace';ctx.textAlign='center';ctx.fillText('CRASH!',f.x,f.gy-12-k*8);}ctx.restore();}};
  const rainDraw=()=>{for(const f of g.fx)if(f.k==='stuck'){""")
rep("  laser();waves();druidFx();robotFx();","  pinnedDraw();bottleDraw();laser();waves();druidFx();robotFx();")
# distracted zombies: a little '?' over their head
open(u,'w').write(t);print('ok')
