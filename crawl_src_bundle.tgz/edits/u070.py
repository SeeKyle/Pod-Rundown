u='/home/claude/pod2/crawl_ui.js';t=open(u).read()
def rep(a,b,n=1):
    global t
    c=t.count(a);assert c==n,(c,a[:90]);t=t.replace(a,b)
rep("['poisonT','#6aff4a','drop']","['poisonT','#6aff4a','rain']")
rep("  if(k==='drop'){ctx.fillRect(x+1,y,1,1);ctx.fillRect(x,y+1,3,2);}","  if(k==='rain'){ctx.fillRect(x+1,y-1,1,2);ctx.fillRect(x,y+1,3,2);ctx.fillStyle='#d8ffd0';ctx.fillRect(x,y+1,1,1);}   // 0.12.70: poison = a little green raindrop\n  else if(k==='drop'){ctx.fillRect(x+1,y,1,1);ctx.fillRect(x,y+1,3,2);}")
rep("drawUnit(ctx,A,fr,T.x,T.gy+1,1,null,T.hitT>0?(T.hitT-=1/60):0,0,T.face>0);ctx.restore();","drawUnit(ctx,A,fr,T.x,T.gy+1,T.big||1,null,T.hitT>0?(T.hitT-=1/60):0,0,T.face>0);ctx.restore();   // 0.12.70: Call_of_Cthulhu makes them 25% bigger")
rep("  const slamDraw=()=>{","""  /* 0.12.70 Syphon_Life: two twisting strands (black and violet) from his chest to the target's middle, motes of life drifting back into him;
     a burrow puff where Call_of_Cthulhu pulls a tentacle under; a green glint on his dagger during Lethal_Strikes */
  const voidFx=()=>{for(const h of g.alive()){if(h.key!=='cultist')continue;const hx=g.heroX(h),gy=h.gy||G;
      if(h.syph&&h.syph.tg&&!h.syph.tg.dead){const T=h.syph.tg,x0=hx+(h.face||1)*3,y0=gy-12,x1=T.x,y1=(T.gy!=null?T.gy:G)-(T.boss?30:12),L=Math.hypot(x1-x0,y1-y0)||1,nx=-(y1-y0)/L,ny=(x1-x0)/L;
        ctx.save();for(const [w,c,ph,amp] of [[3.2,'rgba(10,0,16,.75)',0,2.2],[1.6,'rgba(150,60,255,.85)',Math.PI,2],[.7,'rgba(230,200,255,.9)',Math.PI*.5,1.2]]){ctx.strokeStyle=c;ctx.lineWidth=w;ctx.beginPath();
          for(let i=0;i<=24;i++){const k=i/24,sw=Math.sin(k*12-g.t*14+ph)*amp*Math.sin(k*Math.PI),x=x0+(x1-x0)*k+nx*sw,y=y0+(y1-y0)*k+ny*sw;i?ctx.lineTo(x,y):ctx.moveTo(x,y);}ctx.stroke();}
        ctx.globalCompositeOperation='lighter';for(let i=0;i<5;i++){const k=1-((g.t*1.3+i/5)%1);glow(ctx,x0+(x1-x0)*k,y0+(y1-y0)*k+Math.sin(g.t*9+i)*1.5,1.3,i%2?'#ff5a8a':'#b070ff',.8);}
        glow(ctx,x1,y1,5,'#6a20c0',.35);glow(ctx,x0,y0,3,'#b070ff',.4);ctx.restore();}
      if(h.lethalT>0){ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,hx+(h.face||1)*7,gy-10,2.2,'#6aff4a',.35+.25*Math.sin(g.t*14));ctx.restore();}}
    for(const f of g.fx){if(f.k!=='burrow')continue;const k=f.t/f.life;for(let i=0;i<5;i++)puffAt(f.x+(i-2)*2.5,f.gy-1-k*5-(i%2),1.6+k*2,.6*(1-k),'#4a3a2c');}};
  const slamDraw=()=>{""")
rep("  slamDraw();pinnedDraw();","  voidFx();slamDraw();pinnedDraw();")
t=t.replace("v0.12.69","v0.12.70")
open(u,'w').write(t);print('ok')
