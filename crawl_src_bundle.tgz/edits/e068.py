p='/home/claude/pod2/crawl_src.js';s=open(p).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:90]);s=s.replace(a,b)
rep("      {id:'pal',name:'Call Traveling_Companion',en:30,cd:24,cast:.8,heal:.07},",
"""      // 0.12.68 (Kyle) Elite_Survivors (passive, replaces Call Traveling_Companion): his partner starts every stage beside him; he has the
      //   Scavenger perk built in; and while they're within 150 screen px (50 world) of each other both get +10% dodge.
      {id:'elite',name:'Elite_Survivors',passive:1,r:50,dodge:.1},""")
rep("  pal:'Call Traveling_Companion · 30 energy · 24s.","  elite:'Elite_Survivors (passive) · his Traveling_Companion starts every stage right beside him, he has the Scavenger perk built in (searches wrecks for medkits, batteries and scrap), and while the two of them are within 150px of each other both get +10% dodge.',\n  _pal_old:'Call Traveling_Companion · 30 energy · 24s.")
rep("const insP=u=>u&&u.insp&&INSP[u.insp]&&INSP[u.insp].passive;","const insP=u=>(u&&u.insp&&INSP[u.insp]&&INSP[u.insp].passive)||(u&&u.key==='flannel'&&(((u.base&&u.base.char)||CHAR.flannel).abilities||[]).some(a=>a.id==='elite')?'scavenger':undefined);   /* 0.12.68: Elite_Survivors = Scavenger built in (a deck perk still wins) */")
rep("    {const kt=upgT(this.run,'kennel');if(kt&&!this.demo)this.spawnDog(kt);}","    {const kt=upgT(this.run,'kennel');if(kt&&!this.demo)this.spawnDog(kt);}\n    for(const h of this.heroes)if((h.base.char&&h.base.char.abilities||[]).some(a=>a.id==='elite'))this.callPal(h,{heal:0});   /* 0.12.68 Elite_Survivors: she starts the stage beside him */")
rep("    if(this.rng()<h.dodge){this.text(h.x,this.G-52,'dodge','#9ae6ff');return false;}","    if(this.rng()<h.dodge+this.eliteDodge(h)){this.text(h.x,this.G-52,'dodge','#9ae6ff');return false;}")
rep("  hurtMinion(m,amt,from){if(!m||m.dead)return;","""  /* 0.12.68 Elite_Survivors: +10% dodge for Flannel_Man and his companion while they're within 50 world px of each other */
  eliteDodge(h){const fm=h&&h.key==='flannel'?h:h&&h.key==='flannel_pal'?h.owner:null;if(!fm||!fm.alive)return 0;const E=((fm.base.char&&fm.base.char.abilities)||[]).find(a=>a.id==='elite');if(!E)return 0;
    const pal=h.key==='flannel'?(this.pets||[]).find(p=>p.owner===fm&&p.key==='flannel_pal'&&p.alive):h;if(!pal||!pal.alive)return 0;return Math.abs(this.heroX(fm)-this.heroX(pal))<=E.r?E.dodge:0;}
  hurtMinion(m,amt,from){if(!m||m.dead)return;if(m.key==='flannel_pal'&&this.rng()<(m.dodge||0)+this.eliteDodge(m)){this.text(m.x,this.G-40,'dodge','#9ae6ff');return;}""")
rep("p.x=p.sx+(tx-p.sx)*u;p.y=p.sy+(ty-p.sy)*u-34*4*u*(1-u);","p.x=p.sx+(tx-p.sx)*u;p.y=p.sy+(ty-p.sy)*u-46*4*u*(1-u);")
rep("p.sure=1;p.stunCh=BB.stunCh;p.stunT=BB.stunT;p.spd=170;","p.sure=1;p.stunCh=BB.stunCh;p.stunT=BB.stunT;p.spd=136;")
rep("  abilities:[{id:'brick',name:'Brick Throw',en:25,cd:9,range:170,dmgMul:1.5,stunCh:.75,stunT:1.2}]};})();",
"""  abilities:[{id:'brick',name:'Brick Throw',en:25,cd:9,range:170,dmgMul:1.5,stunCh:.75,stunT:1.2},
    // 0.12.68 (Kyle) Bottle_Distraction: lobs a glass bottle in a big arc 450-500 screen px (150-167 world); it shatters and every zombie within
    //   ~180 screen px (60 world) turns and goes to check the noise for 2.5s (no attacks). IF a pack of 3+ is coming THEN throw it BEHIND them.
    {id:'bottle',name:'Bottle_Distraction',en:30,cd:16,min:150,max:167,r:60,dur:2.5,fly:1.1,min3:3}]};})();""")
rep(",brick:'brT'};",",brick:'brT',bottle:'boT'};")
i=s.index("    // ---- Brick Throw (the companion)")
j=s.index("h._forceBox=null;return;}}",i)+len("h._forceBox=null;return;}}")
s=s[:j]+"""
    // ---- 0.12.68 Bottle_Distraction (the companion): IF a pack of 3+ is bunched up THEN lob a bottle 150-167 world px out, just BEHIND them,
    //   so they turn around and walk away from us to check the noise
    {const BO=(C.abilities||[]).find(a=>a.id==='bottle');if(BO){if(h.boT==null)h.boT=BO.cd*.4;if(h.boT>0)h.boT-=dt;
      if(h.boT<=0&&(h.en||0)>=BO.en){const hx=this.heroX(h),live=this.enemies.filter(e=>!e.dead&&!e.boss&&!e.fly&&e.x>hx&&e.x<this.W&&!(e.distractT>0));let best=null,bn=0;
        for(const e of live){const n=live.filter(o=>Math.abs(o.x-e.x)<40).length;if(n>bn||(n===bn&&best&&e.x>best.x)){bn=n;best=e;}}
        if(best&&bn>=BO.min3){const pack=live.filter(o=>Math.abs(o.x-best.x)<40),far=Math.max(...pack.map(o=>o.x));const tx=Math.min(hx+BO.max,Math.max(hx+BO.min,far+22),this.W-6);
          if(tx-far>4&&spendEnergy(h,BO.en)){h.boT=BO.cd*(1-(h.cdr||0));h.animM=.45;h.face=1;const gy=best.gy!=null?best.gy:this.G;
            (this.bottles=this.bottles||[]).push({x0:hx+3,gy0:h.gy||this.G,x1:tx,gy1:gy,t:0,T:BO.fly,A:BO,src:h,rot:0});this.ev('whoosh',{});
            Comms.bubble(this,h,Comms.pick(['Hey! Over there!','Go fetch!','Look, shiny!','Catch!']),true);return;}}}}}"""+s[j:]
rep("    if(this.missiles&&this.missiles.length){for(const M of this.missiles){M.t+=dt;","""    if(this.bottles&&this.bottles.length){for(const B of this.bottles){B.t+=dt;B.x0-=scroll*dt;B.x1-=scroll*dt;B.rot+=dt*11;const u=Math.min(1,B.t/B.T);B.x=B.x0+(B.x1-B.x0)*u;B.gy=B.gy0+(B.gy1-B.gy0)*u;B.hgt=14*(1-u)+62*Math.sin(Math.PI*u);
        if(u>=1&&!B.done){B.done=1;this.ev('shatter',{});this.fx.push({k:'glass',x:B.x1,gy:B.gy1,t:0,life:.9,raw:1});
          for(const e of this.enemies){if(e.dead||e.boss||e.fly)continue;if(Math.abs(e.x-B.x1)<=B.A.r&&Math.abs((e.gy!=null?e.gy:this.G)-B.gy1)<=14){e.distractT=B.A.dur;e.distractX=B.x1+(this.rng()*2-1)*6;e.target=null;e.plan=null;}}}}
      this.bottles=this.bottles.filter(B=>!B.done);}
    if(this.missiles&&this.missiles.length){for(const M of this.missiles){M.t+=dt;""")
rep("      if(e.stun>0){e.stun-=dt;continue;}\n","""      if(e.stun>0){e.stun-=dt;continue;}
      if(e.distractT>0){e.distractT-=dt;e.distractX-=scroll*dt;e.x-=scroll*dt;const dx=e.distractX-e.x;if(Math.abs(dx)>2)e.x+=Math.sign(dx)*Math.min(Math.abs(dx),e.E.spd*(1-(e.slow||0))*dt);e.face=dx>0?1:-1;e.walkT=(e.walkT||0)+dt;continue;}   /* 0.12.68 Bottle_Distraction: they go check the noise */
""")
rep("  st8(h){const k=(h&&h.key)||'?';","  st8(h,own){if(!own&&h&&h.owner&&h.owner.key&&!h.dog)h=h.owner;   /* 0.12.68: companions/summons' numbers count for their owner; the Guard Dog keeps his own line */\n    const k=(h&&h.key)||'?';")
rep("if(h.key&&!this.demo)this.st8(h).taken+=amt;","if(h.key&&!this.demo)this.st8(h,1).taken+=amt;")
rep("this.fx.push({k:'stuck',x:e.x,gy:e.gy!=null?e.gy:this.G,t:0,life:PN.root,raw:1});}});p.pin=1;this.aim(p,h,tg);});",
    "this.fx.push({k:'pinned',e,x:e.x,gy:e.gy!=null?e.gy:this.G,dir:e.x>=h.x?1:-1,t:0,life:PN.root+.4,raw:1});}});p.pin=1;p.sure=1;h._forceBox='bot';this.aim(p,h,tg);h._forceBox=null;});   /* 0.12.68 (Kyle): auto-aimed at the legs, ignores accuracy */")
L=[l for l in s.split('\n') if not l.startswith("  _pal_old:")];open(p,'w').write('\n'.join(L))
print('ok')
