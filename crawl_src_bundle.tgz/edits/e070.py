p='/home/claude/pod2/crawl_src.js';s=open(p).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:90]);s=s.replace(a,b)
# abilities
i=s.index("  abilities:[\n    // Call_of_the_Deep: IF 2+ enemies are within 150px");j=s.index("const PAL_FRAC=1/3;",i)
s=s[:i]+"""  /* 0.12.70 (Kyle) Void_Cultist rework: no energy at all. His abilities cost LIFE (Syphon_Life is free and is how he gets it back). */
  abilities:[
    // Syphon_Life (free): IF an enemy is within ~330 screen px (110 world) AND (I'm hurt OR nothing is on me) THEN channel a swirling black-and-purple
    //   beam into it for 3s: 3 damage a second (scaled by his damage), and he heals for everything it drains. Breaks if it dies or gets away. 9s CD.
    {id:'syphon',name:'Syphon_Life',en:0,cd:9,dur:3,range:110,dps:3,heal:1},
    // Lethal_Strikes (10% of max life): IF a zombie is in dagger range and I can afford it THEN for 12s: +75% melee attack speed, -25% melee damage,
    //   Poisoned_Blade doubled (50%, 2 stacks), and Shooter/Slasher goes to 10 (all slasher). 20s CD.
    {id:'lethal',name:'Lethal_Strikes',en:0,hpCost:.1,cd:20,dur:12,spd:.75,dmg:.25,want:'close'},
    // Spawn_Tentacle (8% of max life, keeps the old tentacle): placed anywhere within 400 screen px (133 world), in the middle of the biggest pack.
    {id:'tentacle',name:'Spawn_Tentacle',en:0,hpCost:.08,cd:7,cast:.8,life:999,decay:.05,hp:15,steal:.2,reach:35,depth:10,every:1.4,dice:[2,6],kb:20,range:133},
    // Call_of_Cthulhu (15% of max life): 10s: Spawn_Tentacle's CD runs twice as fast, every tentacle is 25% bigger (reach too) and attacks 25% faster.
    //   On cast his tentacles burrow and re-emerge 200 screen px (67 world) in front of him, and a fear pulse goes out from him and from every tentacle:
    //   2s of fear and -25% move speed. IF 2+ tentacles are up OR 4+ zombies are coming, AND I can afford it THEN call. 30s CD.
    {id:'cthulhu',name:'Call_of_Cthulhu',en:0,hpCost:.15,cd:30,dur:10,size:.25,spd:.25,fear:2,slow:.25,r:45,move:67,cast:.9},
    // Poisoned_Blade (passive): a dagger hit that lands has a 25% chance to add 1 poison stack; EVERY dagger swing refreshes the poison on its target.
    {id:'blade',name:'Poisoned_Blade',passive:1,ch:.25,n:1}]};
"""+s[j:]
rep("const CD_KEY={nano:'nbT',","const CD_KEY={syphon:'syT',lethal:'leT',cthulhu:'ctT',nano:'nbT',")
rep("const CLOSE_AB=new Set(['dread',","const CLOSE_AB=new Set(['lethal','dread',")
rep("FAR_AB=new Set(['tentacle',","FAR_AB=new Set(['syphon','cthulhu','tentacle',")
rep("  cultist:{name:'Call_of_the_Deep · Blood_Pact · Spreading_Hex · Dread_Chant · Herald_of_Life_and_Death',cd:12,txt:'A hooded void cultist with a ritual dagger.'","  cultist:{name:'Syphon_Life · Lethal_Strikes · Spawn_Tentacle · Call_of_Cthulhu · Poisoned_Blade',cd:12,txt:'A hooded void cultist with a poisoned ritual dagger who pays for his magic in blood.'")
rep("Calls tentacles up out of the ground where the enemies bunch, curses the biggest threat, bleeds himself to empower his allies when a fight turns hard, and chants enemies into a panic when they swarm him.",
    "Pays for his magic in his own blood: tentacles up out of the middle of the pack, a frenzy of poisoned stabs, and Cthulhu's call to send everything fleeing. Then he drinks the life back out of them with a swirling void beam.")
# descriptions
i=s.index("  tentacle:'Call_of_the_Deep");j=s.index("\n",s.index("  herald:'Herald_of_Life_and_Death",i))
s=s[:i]+"""  syphon:'Syphon_Life · free · 9s. A swirling black and purple beam from his chest into an enemy up to 330px away for 3s: it drains 3 life a second (more with damage buffs) and heals him for all of it. This is how he pays for everything else.',
  lethal:'Lethal_Strikes · 10% of his life · 20s · 12s. A frenzy: +75% dagger speed, 25% less per hit, Poisoned_Blade doubled (50% chance, 2 stacks), and he goes all-in up close.',
  tentacle:'Spawn_Tentacle · 8% of his life · 7s. Raises a tentacle anywhere within 400px, right in the middle of the biggest pack. It can\\'t move, lashes 2d6 out to its reach, heals off what it hits, and withers 5% a second.',
  cthulhu:'Call_of_Cthulhu · 15% of his life · 30s · 10s. His tentacles burrow and burst back up 200px in front of him, and a wave of terror rolls out from him and every tentacle: 2s of fear and 25% slower. For 10s every tentacle is 25% bigger (longer reach) and lashes 25% faster, and Spawn_Tentacle comes back twice as fast.',
  blade:'Poisoned_Blade (passive) · a dagger hit that lands has a 25% chance to add a poison stack, and every dagger swing refreshes the poison already on the target.',"""+s[j:]
# remove old cultist logic block
i=s.index("    // ---- 0.12.21 Void_Cultist abilities");j=s.index("    // ---- Druid abilities",i);s=s[:i]+s[j:]
# new early block after robot block: insert before the stealth AI comment? put right before 'const mt=this.enemies.filter('
NEW=r"""    // ---- 0.12.70 Void_Cultist (Kyle's rework): life costs, all IF/THEN on the field; runs before the attack so Lethal_Strikes works up close
    if(h.key==='cultist'){const CB=id=>(C.abilities||[]).find(a=>a.id===id);const SY=CB('syphon'),LS=CB('lethal'),TN=CB('tentacle'),CT=CB('cthulhu');
      for(const [A,k] of [[SY,'syT'],[LS,'leT'],[TN,'tnT'],[CT,'ctT']])if(A){if(h[k]==null)h[k]=A.cd*.25;if(h[k]>0)h[k]-=dt*(k==='tnT'&&h.cthT>0?2:1);}
      if(h.lethalT>0)h.lethalT-=dt;if(h.cthT>0)h.cthT-=dt;
      if(h.summonT>0){h.summonT-=dt;h.pauseT=Math.max(h.pauseT||0,.05);return;}
      const live=this.enemies.filter(e=>!e.dead&&e.x<this.W+4),hx=this.heroX(h),hp=h.hp/h.max,afford=A=>A&&hp-A.hpCost>=.35;
      // Syphon_Life in progress: stand and drain
      if(h.syph){const S=h.syph,T=S.tg;S.t+=dt;S.acc+=dt;h.pauseT=Math.max(h.pauseT||0,.05);h.moving=false;if(T)h.face=T.x>=h.x?1:-1;
        if(!T||T.dead||Math.abs(T.x-hx)>SY.range*1.15||S.t>=SY.dur){h.syph=null;}
        else{while(S.acc>=.25){S.acc-=.25;const d=this.hitEnemy(T,SY.dps*.25*(h.atk/h.base.atk)*h.rangedDmg*(h.cryDmg||1),h,{sure:1,nocrit:1,quiet:1});if(d)this.healHero(h,d*SY.heal,true,h);}return;}}
      // IF Call_of_Cthulhu is ready AND (2+ tentacles are up OR 4+ zombies are coming) AND I can afford it THEN call
      const tents=(this.tentacles||[]).filter(T=>T.src===h&&T.anim!=='death');
      if(CT&&h.ctT<=0&&afford(CT)&&(tents.length>=2||live.filter(e=>e.x-hx<160).length>=4)&&this.payLife(h,CT.hpCost)){h.ctT=CT.cd*(1-(h.cdr||0));h.cthT=CT.dur;h.summonT=CT.cast;h.summonT0=CT.cast;
        Comms.bubble(this,h,Comms.pick(['Ph\'nglui mglw\'nafh!','HE WAKES!','Cthulhu fhtagn!','The deep calls you home!']),true);this.ev('wind',{});this.shake=Math.max(this.shake||0,.35);
        setTimeoutSafe(this,CT.cast*.7,()=>{if(!h.alive)return;const d=h.face||1,cx=this.heroX(h)+d*CT.move,ts=(this.tentacles||[]).filter(T=>T.src===h&&T.anim!=='death');
          ts.forEach((T,i)=>{this.fx.push({k:'burrow',x:T.x,gy:T.gy,t:0,life:.5,raw:1});T.x=Math.max(8,Math.min(this.W-8,cx+(i-(ts.length-1)/2)*16));T.gy=LANES[Math.max(0,Math.min(LANES.length-1,(h.laneI||2)+((i%3)-1)))]||T.gy;T.anim='emerge';T.aT=0;});
          for(const o of [{x:this.heroX(h),gy:h.gy||this.G}].concat(ts.map(T=>({x:T.x,gy:T.gy})))){this.fx.push({k:'dread',x:o.x,gy:o.gy,t:0,life:.8,raw:1,r:CT.r});
            for(const e of this.enemies){if(e.dead||e.boss)continue;if(Math.abs(e.x-o.x)<CT.r&&Math.abs((e.gy||this.G)-o.gy)<16){e.retreatT=Math.max(e.retreatT||0,CT.fear);e.fearT=CT.fear;e.slow=Math.max(e.slow||0,CT.slow);e.slowT=Math.max(e.slowT||0,CT.fear);}}}});
        return;}
      // IF zombies are bunched within 133 world AND I can afford it THEN Spawn_Tentacle in the middle of the biggest pack
      if(TN&&h.tnT<=0&&afford(TN)){const near=live.filter(e=>!e.fly&&Math.abs(e.x-hx)<=TN.range);let best=null,bn=0;for(const e of near){const n=near.filter(o=>Math.abs(o.x-e.x)<30).length+(e.boss?2:0);if(n>bn){bn=n;best=e;}}
        if(best&&(bn>=2||best.boss||best.max>=this.bb.maxE*.8)&&this.payLife(h,TN.hpCost)){h.tnT=TN.cd*(1-(h.cdr||0));h.summonT=TN.cast;h.summonT0=TN.cast;
          const pack=near.filter(o=>Math.abs(o.x-best.x)<30),tx=Math.max(8,Math.min(this.W-8,pack.reduce((a,o)=>a+o.x,0)/pack.length)),gy=best.gy!=null?best.gy:(h.gy||this.G);const mul=(h.atk/h.base.atk)*h.rangedDmg*(h.cryDmg||1);
          setTimeoutSafe(this,TN.cast*.7,()=>{if(!h.alive)return;(this.tentacles=this.tentacles||[]).push({x:tx,gy,t:0,life:TN.life,A:TN,src:h,mul,atkT:.6,anim:'emerge',aT:0,face:1,hp:TN.hp,max:TN.hp,swatT:0});this.ev('thorns',{});this.shake=Math.max(this.shake||0,.25);});
          Comms.say(this,h,'tentacle',{});return;}}
      // IF a zombie is in dagger range AND Lethal_Strikes is ready AND I can afford it THEN frenzy
      if(LS&&h.leT<=0&&afford(LS)&&live.some(e=>!e.fly&&Math.abs(e.x-hx)<26&&Math.abs((e.gy!=null?e.gy:this.G)-(h.gy||this.G))<4)&&this.payLife(h,LS.hpCost)){h.leT=LS.cd*(1-(h.cdr||0));h.lethalT=LS.dur;addMood(h,{range:10},LS.dur,'lethal');
        this.fx.push({k:'ring',x:h.x,y:(h.gy||this.G)-10,r:16,t:0,c:'#6aff4a'});Comms.bubble(this,h,Comms.pick(['Bleed for me!','Steel and venom!','Dance, little corpses!']));}
      // IF an enemy is in syphon range AND (I'm hurt OR nothing is on me) THEN drain it (free)
      if(SY&&h.syT<=0&&!h.syph){const T=live.filter(e=>Math.abs(e.x-hx)<=SY.range&&e.x>-4).sort((p,q)=>(hp<.6?Math.abs(p.x-hx)-Math.abs(q.x-hx):q.hp-p.hp))[0];const onMe=live.some(e=>!e.fly&&Math.abs(e.x-hx)<16);
        if(T&&(hp<.9||!onMe)){h.syT=SY.cd*(1-(h.cdr||0));h.syph={t:0,acc:0,tg:T};unstealth(h);this.ev('zap',{});return;}}}
"""
rep("    const mt=this.enemies.filter(e=>!e.dead&&!e.fly&&(e.boss?",NEW+"    const mt=this.enemies.filter(e=>!e.dead&&!e.fly&&(e.boss?")
# payLife helper
rep("  /* 0.12.67 Warhound: one Missile_Barrage-strength missile","  /* 0.12.70 Void_Cultist: pay life for an ability (never below 25%) */\n  payLife(h,c){if(h.hp-h.max*c<h.max*.25)return false;h.hp-=h.max*c;this.text(h.x+4,this.G-52,'-'+Math.round(h.max*c),'#c0102a');this.fx.push({k:'ring',x:h.x,y:(h.gy||this.G)-8,r:10,t:0,c:'#c0102a'});unstealth(h);return true;}\n  /* 0.12.67 Warhound: one Missile_Barrage-strength missile")
# melee speed + damage + poisoned blade
rep("*(h.key==='jp'?(h.highT>0?1.1:(h.soberT||0)>10?.9:1):1);h.rT=","*(h.key==='jp'?(h.highT>0?1.1:(h.soberT||0)>10?.9:1):1)*(h.lethalT>0?1.75:1);h.rT=")
rep("        const dealt=this.hitEnemy(mt,roll*(fell?1+RY.bonus:1),h,{});","""        const LT=h.lethalT>0?(C.abilities||[]).find(a=>a.id==='lethal'):null;const dealt=this.hitEnemy(mt,roll*(fell?1+RY.bonus:1)*(LT?1-LT.dmg:1),h,{});
        {const PBd=(C.abilities||[]).find(a=>a.id==='blade');if(PBd&&!mt.dead){if(mt.poison>0)mt.poisonT=POISON.dur;if(dealt&&this.rng()<PBd.ch*(LT?2:1))this.addPoison(mt,PBd.n*(LT?2:1));}}   /* 0.12.70 Poisoned_Blade */""")
# tentacles: Cthulhu buff
rep("      T.atkT-=dt;\n      if(T.anim==='idle'&&T.atkT<=0){const tg=this.enemies.filter(e=>!e.dead&&!e.fly&&Math.abs(e.x-T.x)<=A.reach+","      const big=T.src&&T.src.cthT>0?1.25:1;T.big=big;T.atkT-=dt*big;   /* 0.12.70 Call_of_Cthulhu: 25% bigger, longer reach, 25% faster */\n      if(T.anim==='idle'&&T.atkT<=0){const tg=this.enemies.filter(e=>!e.dead&&!e.fly&&Math.abs(e.x-T.x)<=A.reach*big+")
rep("const dx=(e.x-T.x)*dir;if(dx>=-4&&dx<=A.reach+(e.boss","const dx=(e.x-T.x)*dir;if(dx>=-4&&dx<=A.reach*(T.big||1)+(e.boss")
rep("heroDown(h){if(this.tryResurge(h))return;h.jet=null;","heroDown(h){if(this.tryResurge(h))return;h.syph=null;h.jet=null;")
open(p,'w').write(s);print('ok')
