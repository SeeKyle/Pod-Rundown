u='/home/claude/pod2/crawl_ui.js';t=open(u).read()
def ru(a,b):
    global t
    assert t.count(a)==1,a[:70];t=t.replace(a,b)
ru("    if(b.k==='tower'){const W=21,TH=30;const top=gy-TH*b.tier;\n      shadow(ctx,x,gy,22);","    if(b.k==='tower'){const W=9.5,TH=30;const top=gy-TH*b.tier;   /* 0.12.76: about 45% as wide as before */\n      shadow(ctx,x,gy,11);")
ru("for(let k=-W;k<=W;k+=3){ctx.beginPath();ctx.moveTo(x+k,y0-1);ctx.lineTo(x+k+12,y0-13);ctx.stroke();ctx.beginPath();ctx.moveTo(x+k,y0-1);ctx.lineTo(x+k-12,y0-13);ctx.stroke();}",
   "ctx.save();ctx.beginPath();ctx.rect(x-W,y0-14,2*W,14);ctx.clip();for(let k=-W-12;k<=W+12;k+=2.5){ctx.beginPath();ctx.moveTo(x+k,y0-1);ctx.lineTo(x+k+12,y0-13);ctx.stroke();ctx.beginPath();ctx.moveTo(x+k,y0-1);ctx.lineTo(x+k-12,y0-13);ctx.stroke();}ctx.restore();")
ru("const sx=x-6,sy=y0-24;ctx.fillStyle='#1a1410';ctx.fillRect(sx-1,sy-1,14,10);   // the tier's sign","ctx.save();ctx.translate(x-4.2,y0-23);ctx.scale(.7,.7);ctx.translate(-(x-6),-(y0-24));const sx=x-6,sy=y0-24;ctx.fillStyle='#1a1410';ctx.fillRect(sx-1,sy-1,14,10);   // the tier's sign (smaller now)")
ru("ctx.fillStyle='#1a1410';ctx.fillRect(sx+5.5,sy+3,1,2);}}","ctx.fillStyle='#1a1410';ctx.fillRect(sx+5.5,sy+3,1,2);}ctx.restore();}")
ru("if(b.hp<b.max){const w=30;ctx.fillStyle='#000a';ctx.fillRect(x-w/2-1,top-20,w+2,3);","if(b.hp<b.max){const w=20;ctx.fillStyle='#000a';ctx.fillRect(x-w/2-1,top-20,w+2,3);")
i=t.index("    else if(b.k==='barrier'){");j=t.index("    else if(b.k==='tesla'){",i)
t=t[:i]+r"""    else if(b.k==='barrier'){const w=7,h=17,L=x-w,R=x+w,T=gy-h;shadow(ctx,x,gy,10);   /* 0.12.76 (Kyle): one HESCO_Barrier cell, like his photos */
      ctx.fillStyle='#a8946c';ctx.fillRect(L,T,2*w,h);ctx.fillStyle='#c2ad84';ctx.fillRect(L+1,T+1,w-1,h-2);ctx.fillStyle='#8e7a56';ctx.fillRect(x+3,T+1,w-3,h-2);   // geotextile, lit from the left
      for(let yy=T+2;yy<gy;yy+=2.6){ctx.fillStyle='rgba(120,100,70,.35)';ctx.fillRect(L,yy,2*w,.5);}   // fabric bulging between the wires
      ctx.strokeStyle='rgba(70,72,74,.85)';ctx.lineWidth=.35;for(let xx=L+1.6;xx<R;xx+=2.4){ctx.beginPath();ctx.moveTo(xx,T);ctx.lineTo(xx,gy);ctx.stroke();}for(let yy=T+1.3;yy<gy;yy+=2.4){ctx.beginPath();ctx.moveTo(L,yy);ctx.lineTo(R,yy);ctx.stroke();}   // welded wire mesh
      ctx.fillStyle='#3e4246';for(const cx of[L,x,R-1])ctx.fillRect(cx,T-1,1,h+1);ctx.fillStyle='#7a8086';for(let yy=T;yy<gy;yy+=1.6)for(const cx of[L,x,R-1])ctx.fillRect(cx,yy,1,.6);   // coil-joint rods
      ctx.fillStyle='#5a4228';ctx.beginPath();ctx.moveTo(L-.5,T+.5);ctx.quadraticCurveTo(x-3,T-4,x,T-2.6);ctx.quadraticCurveTo(x+4,T-4.5,R+.5,T+.5);ctx.closePath();ctx.fill();ctx.fillStyle='#7a5c38';ctx.fillRect(x-4,T-2.6,3,1);   // dirt heaped over the top
      ctx.fillStyle='#c8b48a';ctx.fillRect(L,T,2*w,1);   // the fabric lip folded over the rim
      if(b.hp<b.max*.6){ctx.strokeStyle='#4a3a22';ctx.lineWidth=.5;ctx.beginPath();ctx.moveTo(x-3,T+4);ctx.lineTo(x-1,T+8);ctx.lineTo(x-3,T+11);ctx.stroke();ctx.fillStyle='#6a5030';ctx.fillRect(x-2,gy-1,4,1);}   // torn, dirt spilling
      if(b.hp<b.max){ctx.fillStyle='#000a';ctx.fillRect(x-8,T-8,16,3);ctx.fillStyle='#ffd23f';ctx.fillRect(x-7,T-7,14*Math.max(0,b.hp/b.max),1);}}
"""+t[j:]
t=t.replace("v0.12.75","v0.12.76")
open(u,'w').write(t);print('ok')
