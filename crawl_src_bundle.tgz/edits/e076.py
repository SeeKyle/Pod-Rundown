p='/home/claude/pod2/crawl_src.js';s=open(p).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:90]);s=s.replace(a,b)
# perched shots start up on the tower
rep("    const mz=MUZZLE[h.key]||[10,30];const y0=this.G-mz[1];","    const mz=MUZZLE[h.key]||[10,30];const lift=h.perch?(h.leapH||0)*.6:0;const y0=this.G-mz[1]-lift;   /* 0.12.76: up on the lookout, shots leave from up there */")
rep("p.h=h.fly?(this.G-h.y)/UNIT_SCALE:(h.key&&HERO_HB[h.key]?(MUZZLE[h.key]||[0,14])[1]/UNIT_SCALE:28);","p.h=(h.fly?(this.G-h.y)/UNIT_SCALE:(h.key&&HERO_HB[h.key]?(MUZZLE[h.key]||[0,14])[1]/UNIT_SCALE:28))+(h.perch?(h.leapH||0)*.6/UNIT_SCALE:0);")
# HESCO naming
rep("    //   Concrete barrier: blocks zombies in its lane and the ones next to it (they hit it instead); allies standing behind it +8 accuracy.","    //   HESCO_Barrier (0.12.76, was the concrete barrier): ONE wire-mesh, fabric-lined cell filled with dirt; blocks zombies in its lane and the ones next to it\n    //   (they hit it instead); allies standing behind it +8 accuracy.")
rep("CONCRETE BARRIER (16s, 3s): zombies in its lanes can\\'t pass and hit it instead; allies behind it +8 accuracy.","HESCO_BARRIER (16s, 3s): one tall wire-mesh cell filled with dirt; zombies in its lanes can\\'t pass and hit it instead; allies behind it +8 accuracy.")
rep("Bashes anything close","Halving the tower cooldown whenever one of his towers scrolls off behind the team keeps them coming. Bashes anything close")
rep("Comms.pick(['Barrier going up!','Wall them off!'])","Comms.pick(['HESCO going up!','Wall them off!','Filling a HESCO!'])")
# tower further up the road
rep("h.building={k:'tower',tier:1,t:0,T:BU.tower.T[0],x:Math.max(14,hx-12),gy};","h.building={k:'tower',tier:1,t:0,T:BU.tower.T[0],x:Math.max(20,Math.min(this.W-40,hx+45)),gy};   /* 0.12.76: well up the road so the team doesn't walk past it right away */")
rep("Comms.bubble(this,h,Comms.pick(['Putting up a tower.','Give me five seconds.','Cover me, building!']));return;}","h.walkTo=h.building.x;Comms.bubble(this,h,Comms.pick(['Putting up a tower.','Give me five seconds.','Cover me, building!']));return;}")
# he walks up to the spot before building: building waits until he's there
rep("      if(h.building){const W=h.building;W.t+=dt;","      if(h.building&&h.walkTo!=null){const d=h.walkTo-hx;if(Math.abs(d)>6&&onMeE(this,h)<2){h.x+=Math.sign(d)*Math.min(Math.abs(d),(MOVE.eng||15)*dt*1.4);h.face=d>0?1:-1;h.moving=true;h.walkT=(h.walkT||0)+dt;return;}h.walkTo=null;}\n      if(h.building){const W=h.building;W.t+=dt;")
# climbing + off-screen passive
rep("        if(o){b.occ=o;o.perch=b;o.acc+=b.A.perchAcc;","        if(o){b.occ=o;o.perch=b;o.climbT=0;o.acc+=b.A.perchAcc;")
rep("      if(b.occ){const o=b.occ;o.x=b.x;o.leapH=150;o.pauseT=Math.max(o.pauseT||0,.05);o.moving=false;}}",
    "      if(b.occ){const o=b.occ;o.pauseT=Math.max(o.pauseT||0,.05);o.moving=false;   /* 0.12.76: they slide up the ladder (about 1s), then step over to the middle */\n        if(o.climbT<1){if(o.climbT===0)o.x=b.x+14;o.climbT=Math.min(1,o.climbT+dt/1.1);o.x+=(b.x+14-o.x)*Math.min(1,dt*12);o.leapH=150*o.climbT;}else{o.x+=(b.x-o.x)*Math.min(1,dt*8);o.leapH=150;}}}")
rep("    this.blds=B.filter(b=>!b.gone&&b.x>-30);","""    for(const b of B){if(b.k==='tower'&&!b.gone&&b.x<=-14&&b.owner){b.gone=1;if(b.occ){const o=b.occ;o.perch=null;o.leapH=0;o.acc-=b.A.perchAcc;b.occ=null;}
        if(b.owner.twT>0){b.owner.twT/=2;this.text(this.heroX(b.owner),this.G-62,'tower CD ½','#ffd23f');}}}   /* 0.12.76 Build passive: a tower left behind halves the tower cooldown */
    this.blds=B.filter(b=>!b.gone&&b.x>-30);""")
open(p,'w').write(s);print('ok')
