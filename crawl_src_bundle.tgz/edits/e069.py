p='/home/claude/pod2/crawl_src.js';s=open(p).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:90]);s=s.replace(a,b)
rep("""    {id:'roll',name:'Log_Roll',en:25,cd:11,dist:120,spd:110,dice:[1,8],trip:.6,kb:30,depth:5,want:'any',range:90}]};""",
"""    // 0.12.69 (Kyle: replace Log_Roll with a passive of my choosing) Feller's_Rhythm (passive): every 3rd axe hit in a row (each within 3s of the
    //   last) is a FELLING blow: +50% damage and a 0.4s stagger (bosses don't stagger). "TIMBER!" pops over the target.
    {id:'rhythm',name:"Feller's_Rhythm",passive:1,n:3,window:3,bonus:.5,stun:.4}]};""")
rep("    {id:'leap',name:'Hatchet_Leap',en:40,cd:16,dur:.6,range:60,min:24,r:16,dice:[1,10],want:'close'},",
    "    // 0.12.69 (Kyle): the slam stuns: 1.2s right under him, down to 0.4s at the edge of the blast; a much bigger landing (cracked earth, dust, pebbles, a burst).\n    {id:'leap',name:'Hatchet_Leap',en:40,cd:16,dur:.6,range:60,min:24,r:16,dice:[1,10],want:'close',stun0:1.2,stun1:.4},")
rep("  roll:'Log_Roll · 20 energy · 8s. When he\\'s hurt and cornered, rolls back about 90px and can\\'t be hit during the roll.',",
    "  rhythm:'Feller\\'s_Rhythm (passive) · every 3rd axe hit in a row (each within 3s of the last) is a felling blow: +50% damage and a 0.4s stagger. TIMBER!',")
rep("  leap:'Hatchet_Leap · 40 energy · 16s. Double-jumps onto an enemy up to 180px away and slams down for 1d10 to everything around the landing.',",
    "  leap:'Hatchet_Leap · 40 energy · 16s. Double-jumps onto an enemy up to 180px away and slams down for 1d10 to everything around the landing, cracking the ground. Everything hit is stunned: 1.2s right under him, down to 0.4s at the edge.',")
rep("lumberjack:{name:'Whirl_Wind · Ground_Chop · Hatchet_Leap · Timber_Rage · Log_Roll'","lumberjack:{name:'Whirl_Wind · Ground_Chop · Hatchet_Leap · Timber_Rage · Feller\\'s_Rhythm'")
# leap landing: stun by distance + big landing fx
rep("for(const e of this.enemies){if(e.dead||e.fly)continue;if(Math.abs(e.x-h.x)<=LP.r+(e.boss?e.w:0)&&(e.boss||Math.abs((e.gy!=null?e.gy:this.G)-h.gy)<=8))this.hitEnemy(e,(this.rollDice(LP.dice)+flat)*mul,h,{kb:1});}",
    "this.fx.push({k:'crack',x:h.x,gy:h.gy||this.G,t:0,life:3.2,raw:1,r:LP.r},{k:'slam',x:h.x,gy:h.gy||this.G,t:0,life:.7,raw:1,r:LP.r,seed:Math.random()*99});\n          for(const e of this.enemies){if(e.dead||e.fly)continue;const dx=Math.abs(e.x-h.x);if(dx<=LP.r+(e.boss?e.w:0)&&(e.boss||Math.abs((e.gy!=null?e.gy:this.G)-h.gy)<=8)){this.hitEnemy(e,(this.rollDice(LP.dice)+flat)*mul,h,{kb:1});\n            if(!e.dead&&!e.boss&&LP.stun0){const q=Math.min(1,dx/LP.r);e.stun=Math.max(e.stun||0,LP.stun0-(LP.stun0-LP.stun1)*q);}}}   /* 0.12.69: stun, longest at the centre */")
# Log_Roll AI guard
rep("      {const lane=this.enemies.filter(e=>!e.dead&&!e.fly&&e.x-h.x>6&&e.x-h.x<=RL.range","      if(RL){const lane=this.enemies.filter(e=>!e.dead&&!e.fly&&e.x-h.x>6&&e.x-h.x<=RL.range")
# rhythm
rep("const dealt=this.hitEnemy(mt,roll,h,{});","""const RY=(C.abilities||[]).find(a=>a.id==='rhythm');let fell=0;if(RY){h.rhyN=(this.t-(h.rhyT==null?-99:h.rhyT)<=RY.window)?(h.rhyN||0)+1:1;h.rhyT=this.t;if(h.rhyN>=RY.n){h.rhyN=0;fell=1;}}   /* 0.12.69 Feller's_Rhythm */
        const dealt=this.hitEnemy(mt,roll*(fell?1+RY.bonus:1),h,{});if(fell&&!mt.dead){if(!mt.boss)mt.stun=Math.max(mt.stun||0,RY.stun);this.text(mt.x,mt.y-34,'TIMBER!','#ffc860');this.shake=Math.max(this.shake||0,.12);}""")
open(p,'w').write(s);print('ok')
