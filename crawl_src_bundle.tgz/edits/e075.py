p='/home/claude/pod2/crawl_src.js';s=open(p).read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:90]);s=s.replace(a,b)
rep("  jp:{atk:'gunner',proj:'bullet',reach:18,range:290,hp:1,dmg:1},","  jp:{atk:'gunner',proj:'bullet',reach:18,range:290,hp:1,dmg:1},\n  eng:{atk:'gunner',proj:'buck',reach:20,range:110,hp:1,dmg:1},   // 0.12.75 Engineer: wrench + sawn-off")
rep("const MOVE={jp:16,","const MOVE={eng:15,jp:16,")
rep("HERO_HB={jp:{w:20,h:46},","HERO_HB={eng:{w:20,h:46},jp:{w:20,h:46},")
rep("const MUZZLE={jp:[13,14],","const MUZZLE={eng:[12,14],jp:[13,14],")
rep("const CALL_COLOR={","const CALL_COLOR={eng:'#ffcc33',jp:'#ff9a3c',",1) if "jp:'#" not in s[s.index("const CALL_COLOR={"):s.index("const CALL_COLOR={")+400] else rep("const CALL_COLOR={","const CALL_COLOR={eng:'#ffcc33',")
rep("const NICK={","const NICK={eng:'Engineer',")
rep("  jp:{name:'Toke_Break · Protect_the_Familia · Shield_Bash · Trash_Talk',","  eng:{name:'Build · Repair · Modify · Satchel_Charge · Field_Plating',cd:20,txt:'Builds a watchtower, a concrete barrier and a tesla coil, fixes them and the Warhound, bolts auto-turrets onto wrecks, and blows things up with a satchel he sets off himself.',fn:()=>false},\n  jp:{name:'Toke_Break · Protect_the_Familia · Shield_Bash · Trash_Talk',")
rep("  jp:'Loud, lovable menace.","  eng:'Practical fixer. Hangs a little behind the front, works with his hands: puts up a watchtower behind the team and builds it up, drops a concrete barrier in front of a crowd, plants a tesla coil, bolts turrets onto wrecks and keeps it all patched together. Bashes anything close with a heavy wrench and blasts it with a sawn-off. Patient, very techy, a bit quiet; holds his satchel until the moment is right.',\n  jp:'Loud, lovable menace.")
rep(" jp:{aggr:6,"," eng:{aggr:4,aware:6,pace:4,lane:4,self:4,range:4,plan:7,energy:5,size:6,exec:8,grudge:3,pack:6,flair:3,talk:4,listen:7,perc:7,tech:10,nerve:6,noise:5,cover:6},   // 0.12.75 Engineer: Shooter/Slasher 4 (6 toward shooter), very techy\n jp:{aggr:6,")
# CHAR.eng
rep("// 0.12.21 Void_Cultist (Kyle): an original hooded cultist","""// 0.12.75 Engineer (Kyle): hard hat, red shirt + overalls, a heavy wrench and a sawn-off shotgun. Builds things.
CHAR.eng={name:'Engineer',role:'Wrench + Sawn-off Shotgun',combo:0,flatHp:0,stamina:9,hpPerStamina:5,armorPts:7,dodge:.04,kbRes:.35,
  melee:{dice:[2,6],every:1.9,reach:20,kb:34,hitAt:.3,stunCh:.25,stun:.8},   // heavy, slow wrench: hits hard, 25% to stun 0.8s
  ranged:{dice:[5,3],flat:0,every:.33,range:110,clip:2,reload:5,pellets:5,spread:1,anim:.3},   // 2 shells, 5 pellets each, ~0.33s apart, 5s reload
  acc:14,walkPenalty:10,crit:.08,critMul:1.8,luck:14,xp:0,run:1.8,turn:.22,enMax:100,enRegen:5,
  abilities:[
    // Build (a WC3-style spellbook: each building has its own cooldown). While he builds or repairs, his other cooldowns pause.
    //   Watchtower: tier 1 takes 5s; Modify adds tier 2 (5s) and tier 3 (7s). One shared health bar, +15% max HP per tier.
    //     T1 sign MEDICAL CROSS: allies within ~150 screen px regen 1% max HP a second.  T2 sign AMMO: allies nearby +15% ranged attack speed.
    //     T3 LOOKOUT: one ranged ally can climb up: +12 accuracy, +30% range, can't be hit until the tower falls. Empty, it gives allies nearby +5 accuracy.
    //   Concrete barrier: blocks zombies in its lane and the ones next to it (they hit it instead); allies standing behind it +8 accuracy.
    //   Tesla coil (my design): zaps the nearest zombie within ~135 screen px for 1d8 every 1.5s and arcs to one more; lasts 25s.
    {id:'build',name:'Build',en:25,cd:0,book:1,
      tower:{cd:30,T:[5,5,7],hp:60,per:.15,r:50,regen:.01,aspd:.15,acc:5,perchAcc:12,perchRange:.3},
      barrier:{cd:16,T:3,hp:80,depth:9,acc:8,behind:40},
      tesla:{cd:22,T:3,hp:30,life:25,r:45,every:1.5,dice:[1,8]}},
    // Repair: no cooldown, slow: fixes buildings (6 HP/s) and the Warhound (2% a second) while he stays next to them. Pauses his other cooldowns.
    {id:'repair',name:'Repair',en:0,cd:0,bld:6,mech:.02},
    // Modify: adds the next watchtower tier, or bolts an auto-turret onto a broken-down car (3-round bursts 0.25s apart, 1s reload, low accuracy).
    {id:'modify',name:'Modify',en:30,cd:14,turret:{T:4,hp:40,range:120,burst:3,gap:.25,reload:1,hit:.45,dice:[1,4]}},
    // Satchel_Charge: tosses a satchel that never goes off by itself; he sets it off when it's worth it (3+ zombies on it, or something big).
    //   The biggest blast in the game: 6d4 at the centre, falling off to 30% at ~100 screen px, with a HEAVY shove.
    {id:'satchel',name:'Satchel_Charge',en:35,cd:18,min:30,max:100,r:33,dice:[6,4],kb:95,fly:.8},
    // Field_Plating (passive, the armor kit): staying within ~60 screen px of an ally for 3s straps a plate kit on them: +25% armor and
    //   +15% knockback resistance until they take 3 hits. One kit per ally at a time.
    {id:'plating',name:'Field_Plating',passive:1,r:20,T:3,armor:.25,kb:.15,hits:3}]};
// 0.12.21 Void_Cultist (Kyle): an original hooded cultist""")
rep("const ABIL_DESC={","""const ABIL_DESC={
  build:'Build · 25 energy · a spellbook of three buildings, each with its own cooldown (he kneels to build; his other cooldowns pause meanwhile). WATCHTOWER (30s, 5s to build): chain-link, steel beams and a ladder; tier 1 (medical cross) heals allies near it 1% a second; Modify adds tier 2 (ammo sign: +15% ranged attack speed nearby) and tier 3 (lookout: one ranged ally climbs up for +12 accuracy and +30% range and can\\'t be hit until it falls; empty, it gives +5 accuracy nearby). Each tier adds 15% to its health. CONCRETE BARRIER (16s, 3s): zombies in its lanes can\\'t pass and hit it instead; allies behind it +8 accuracy. TESLA COIL (22s, 3s): zaps the nearest zombie for 1d8 every 1.5s and arcs to one more, for 25s.',
  repair:'Repair · free, no cooldown · slow: patches up his buildings (6 HP a second) and the Warhound (2% a second) while he stays beside them. His other cooldowns pause while he works.',
  modify:'Modify · 30 energy · 14s. Adds the next tier to his watchtower (5s, then 7s), or bolts an auto-turret onto a broken-down car: 3-round bursts 0.25s apart, 1s reload, not very accurate.',
  satchel:'Satchel_Charge · 35 energy · 18s. Tosses a satchel of explosives that never goes off on its own; he sets it off when it\\'s worth it. The biggest blast in the game: 6d4 at the centre, falling off outward, and a huge shove.',
  plating:'Field_Plating (passive) · stay next to an ally for 3s and he straps a plate kit on them: +25% armor and +15% knockback resistance until they take 3 hits.',""")
# findT range for perched
rep("const range=melee?st.reach*UNIT_SCALE+3:(st.range||170);","const range=melee?st.reach*UNIT_SCALE+3:(st.range||170)*(h.perch?1+((CHAR.eng.abilities[0].tower.perchRange)||.3):1);")
# wrench stun
rep("const dealt=this.hitEnemy(mt,roll*(fell?1+RY.bonus:1)*(LT?1-LT.dmg:1),h,{});","const dealt=this.hitEnemy(mt,roll*(fell?1+RY.bonus:1)*(LT?1-LT.dmg:1),h,{});if(dealt&&!mt.dead&&!mt.boss&&C.melee.stunCh&&this.rng()<C.melee.stunCh){mt.stun=Math.max(mt.stun||0,C.melee.stun);this.text(mt.x,mt.y-30,'CLANG','#d8dce8');}")
# perched + kit in hurtHero
rep("    if(h.key==='robot'){if(h.jet)amt=","    if(h.perch&&h.perch.hp>0)return false;   /* 0.12.75: up on the lookout, nothing can reach them */\n    if(h.kitHits>0){h.kitHits--;if(h.kitHits<=0){h.armorPts-=h.kitAdd||0;h.kbRes-=h.kitKb||0;h.kitAdd=0;h.kitKb=0;this.text(h.x,this.G-60,'plating gone','#b8c0cc');}}   /* Field_Plating */\n    if(h.key==='robot'){if(h.jet)amt=")
# enemies can't see perched
rep("const alSeen=al.filter(o=>!(o.stealthT>0))","const alSeen=al.filter(o=>!(o.stealthT>0)&&!(o.perch&&o.perch.hp>0))")
rep("if(e.target&&e.target.stealthT>0&&alSeen.length","if(e.target&&(e.target.stealthT>0||(e.target.perch&&e.target.perch.hp>0))&&alSeen.length")
# barrier blocks + zombies hit buildings: at the top of each enemy's update, after the stun/distract lines
rep("      if(e.distractT>0){e.distractT-=dt;","      if(this.blds&&!e.fly&&!e.boss)this.bldBlock(e,dt);   /* 0.12.75: barriers stop them; they hit buildings in their way */\n      if(e.distractT>0){e.distractT-=dt;")
# heal regen from tower T1 etc applied in stepEng; ranged speed buff via h.rT
rep("h.rT=(h.rT||0)+dt*h.rangedSpd*spdB*(h.hunger>0?1-HUNGER.spd[h.hunger]:1);","h.rT=(h.rT||0)+dt*h.rangedSpd*spdB*(h.hunger>0?1-HUNGER.spd[h.hunger]:1)*(h.ammoBuffT>0?1.15:1);")
# eng AI block: before mt
NEW=r"""    // ---- 0.12.75 Engineer: Build / Repair / Modify / Satchel_Charge (IF/THEN on the field). Building and repairing pause his other cooldowns.
    if(h.key==='eng'){const EB=id=>(C.abilities||[]).find(a=>a.id===id);const BU=EB('build'),RP=EB('repair'),MO=EB('modify'),SC=EB('satchel');
      const working=!!(h.building||h.repairing);
      if(!working){for(const k of ['twT','brT2','tsT','moT','scT'])if(h[k]>0)h[k]-=dt;}
      if(h.twT==null){h.twT=2;h.brT2=4;h.tsT=6;h.moT=3;h.scT=SC.cd*.3;}
      const hx=this.heroX(h),gy=h.gy||this.G,live=this.enemies.filter(e=>!e.dead&&e.x<this.W+4);const near=r=>live.filter(e=>!e.fly&&Math.abs(e.x-hx)<r).length;
      const B=this.blds=this.blds||[];const tower=B.find(b=>b.k==='tower'&&b.hp>0&&b.owner===h);
      // satchel: IF one of mine is out AND 3+ zombies (or a big one) are on it THEN set it off
      for(const S of this.satchels||[]){if(S.owner!==h||S.boom||S.t<S.T)continue;const on=live.filter(e=>!e.fly&&Math.abs(e.x-S.x)<S.A.r*.6&&Math.abs((e.gy!=null?e.gy:this.G)-S.gy)<12);
        if(on.length>=3||on.some(e=>e.boss||e.elite||e.max>=60)||(S.t>14&&on.length>=1)){this.satchelBoom(S);Comms.bubble(this,h,Comms.pick(['Fire in the hole!','Clacker time.','Boom.','Cover your ears!']),true);}}
      // in-progress work
      if(h.building){const W=h.building;W.t+=dt;h.pauseT=Math.max(h.pauseT||0,.05);h.moving=false;if(Math.random()<dt*6)this.fx.push({k:'spark',x:W.x+(Math.random()-.5)*10,gy:W.gy,t:0,life:.35,raw:1});
        if(onMeE(this,h)>=2&&W.t<W.T*.5){h.building=null;}else if(W.t>=W.T){h.building=null;this.finishBuild(h,W);}return;}
      if(h.repairing){const R=h.repairing,T=R.tgt;R.t+=dt;h.pauseT=Math.max(h.pauseT||0,.05);h.moving=false;
        const done=!T||(T.bld?(T.hp<=0||T.hp>=T.max):(!T.alive||T.hp>=T.max))||Math.abs((T.bld?T.x:this.heroX(T))-hx)>30||onMeE(this,h)>=2||R.t>6;
        if(done){h.repairing=null;}else{if(T.bld)T.hp=Math.min(T.max,T.hp+RP.bld*dt);else{this._mech=1;this.healHero(T,T.max*RP.mech*dt,true,h);this._mech=0;}if(Math.random()<dt*8)this.fx.push({k:'spark',x:(T.bld?T.x:this.heroX(T))+(Math.random()-.5)*8,gy:T.gy||this.G,t:0,life:.3,raw:1});return;}}
      const safe=near(40)===0,en=h.en||0;
      // IF there's a fight AND no tower of mine AND it's quiet right here THEN put a watchtower up a little behind me
      if(BU&&!tower&&h.twT<=0&&en>=BU.en&&safe&&live.length>=2&&spendEnergy(h,BU.en)){h.twT=BU.tower.cd;h.building={k:'tower',tier:1,t:0,T:BU.tower.T[0],x:Math.max(14,hx-12),gy};Comms.bubble(this,h,Comms.pick(['Putting up a tower.','Give me five seconds.','Cover me, building!']));return;}
      // IF my tower can go higher AND it's quiet AND Modify is ready THEN add a tier
      if(MO&&tower&&tower.tier<3&&h.moT<=0&&en>=MO.en&&safe&&Math.abs(tower.x-hx)<40&&spendEnergy(h,MO.en)){h.moT=MO.cd;h.building={k:'tier',tgt:tower,t:0,T:BU.tower.T[tower.tier],x:tower.x,gy:tower.gy};return;}
      // IF a pack of 3+ is coming down one lane 30-120 out THEN drop a concrete barrier in front of them
      if(BU&&h.brT2<=0&&en>=BU.en){let bl=null,bn=0;for(const l of LANES){const n=live.filter(e=>!e.fly&&!e.boss&&Math.abs((e.gy!=null?e.gy:this.G)-l)<=BU.barrier.depth&&e.x-hx>30&&e.x-hx<120).length;if(n>bn){bn=n;bl=l;}}
        if(bl!=null&&bn>=3&&!B.some(b=>b.k==='barrier'&&b.hp>0&&Math.abs(b.gy-bl)<6&&b.x>hx)&&spendEnergy(h,BU.en)){h.brT2=BU.barrier.cd;h.building={k:'barrier',t:0,T:BU.barrier.T,x:Math.min(this.W-20,hx+24),gy:bl};Comms.bubble(this,h,Comms.pick(['Barrier going up!','Wall them off!']));return;}}
      // IF 2+ zombies are within ~300 screen px THEN plant a tesla coil a little ahead
      if(BU&&h.tsT<=0&&en>=BU.en&&near(100)>=2&&near(20)===0&&spendEnergy(h,BU.en)){h.tsT=BU.tesla.cd;h.building={k:'tesla',t:0,T:BU.tesla.T,x:Math.min(this.W-20,hx+16),gy};return;}
      // IF a wreck is right here with no turret AND it's quiet THEN bolt a turret onto it
      if(MO&&h.moT<=0&&en>=MO.en&&safe){const car=(this.obst||[]).find(o=>/^car_/.test(o.k)&&!o.turret&&Math.abs(o.x-hx)<35&&o.x>20&&o.x<this.W-20);if(car&&spendEnergy(h,MO.en)){h.moT=MO.cd;h.building={k:'turret',car,t:0,T:MO.turret.T,x:car.x,gy:LANES[Math.max(...car.lanes)]};Comms.bubble(this,h,Comms.pick(['Let me mount something on this.','This wreck needs a gun.']));return;}}
      // Repair: IF a building of mine (or the Warhound) is hurt AND I'm beside it AND it's quiet THEN fix it
      if(RP&&safe){const T=B.filter(b=>b.hp>0&&b.hp<b.max*.75&&Math.abs(b.x-hx)<28).sort((p,q)=>p.hp/p.max-q.hp/q.max)[0]||this.alive().find(o=>o.key==='robot'&&o.hp<o.max*.6&&Math.abs(this.heroX(o)-hx)<24);if(T){h.repairing={tgt:T,t:0};return;}}
      // satchel: IF 3+ zombies are bunched 30-100 out THEN toss one onto them (he sets it off later)
      if(SC&&h.scT<=0&&en>=SC.en&&!(this.satchels||[]).some(S=>S.owner===h&&!S.boom)){let best=null,bn=0;for(const e of live){const d=e.x-hx;if(e.fly||d<SC.min||d>SC.max)continue;const n=live.filter(o=>Math.abs(o.x-e.x)<20).length;if(n>bn){bn=n;best=e;}}
        if(best&&bn>=3&&spendEnergy(h,SC.en)){h.scT=SC.cd;h.animM=.45;h.face=1;(this.satchels=this.satchels||[]).push({x0:hx+3,x:hx,x1:best.x-6,gy0:gy,gy:best.gy!=null?best.gy:gy,gy1:best.gy!=null?best.gy:gy,t:0,T:SC.fly,A:SC,owner:h});this.ev('whoosh',{});return;}}}
"""
rep("    // ---- 0.12.70 Void_Cultist (Kyle's rework)",NEW+"    // ---- 0.12.70 Void_Cultist (Kyle's rework)")
rep("function unstealth(u){","function onMeE(g,h){const x=g.heroX(h);return g.enemies.filter(e=>!e.dead&&!e.fly&&Math.abs(e.x-x)<16).length;}\nfunction unstealth(u){")
# Game methods
rep("  /* 0.12.70 Void_Cultist: pay life","""  /* 0.12.75 Engineer: buildings */
  finishBuild(h,W){const BU=(h.base.char.abilities||[]).find(a=>a.id==='build'),MO=(h.base.char.abilities||[]).find(a=>a.id==='modify');const B=this.blds=this.blds||[];this.ev('thorns',{});
    if(W.k==='tower'){const A=BU.tower;B.push({bld:1,k:'tower',tier:1,x:W.x,gy:W.gy,hp:A.hp,max:A.hp,A,owner:h,t:0,occ:null});this.text(W.x,W.gy-40,'WATCHTOWER','#ffd23f');}
    else if(W.k==='tier'){const T=W.tgt;if(T&&T.hp>0&&T.tier<3){T.tier++;const nm=T.A.hp*Math.pow(1+T.A.per,T.tier-1);T.hp+=nm-T.max;T.max=nm;this.text(T.x,T.gy-50,'TIER '+T.tier,'#ffd23f');}}
    else if(W.k==='barrier'){const A=BU.barrier;B.push({bld:1,k:'barrier',x:W.x,gy:W.gy,hp:A.hp,max:A.hp,A,owner:h,t:0});}
    else if(W.k==='tesla'){const A=BU.tesla;B.push({bld:1,k:'tesla',x:W.x,gy:W.gy,hp:A.hp,max:A.hp,A,owner:h,t:0,zT:.5});}
    else if(W.k==='turret'){const A=MO.turret;const car=W.car;if(car){car.turret=1;B.push({bld:1,k:'turret',car,x:car.x,gy:LANES[Math.max(...car.lanes)],hp:A.hp,max:A.hp,A,owner:h,t:0,rl:0,shots:0,sT:0});}}}
  bldBlock(e,dt){for(const b of this.blds){if(b.hp<=0)continue;const ey=e.gy!=null?e.gy:this.G;
      if(b.k==='barrier'&&Math.abs(ey-b.gy)<=b.A.depth&&e.x>b.x-2&&e.x<b.x+12){e.x=Math.max(e.x,b.x+10);e.bwT=(e.bwT||0)+dt;if(e.bwT>=(e.E&&e.E.atk||1.2)){e.bwT=0;e.anim=1;e.animT=.3;b.hp-=e.dmg;b.hitT=.15;}}
      else if(b.k!=='barrier'&&b.k!=='turret'&&Math.abs(e.x-b.x)<9&&Math.abs(ey-b.gy)<5){e.bwT=(e.bwT||0)+dt*.5;if(e.bwT>=(e.E&&e.E.atk||1.2)){e.bwT=0;b.hp-=e.dmg;b.hitT=.15;}}}}
  satchelBoom(S){S.boom=1;const A=S.A,h=S.owner;this.fx.push({k:'boom',x:S.x,gy:S.gy,t:0,life:1.3,raw:1,big:1},{k:'crack',x:S.x,gy:S.gy,t:0,life:4,raw:1,r:A.r*.8},{k:'slam',x:S.x,gy:S.gy,t:0,life:.9,raw:1,r:A.r,seed:Math.random()*99});this.ev('boom',{});this.shake=Math.max(this.shake||0,1);
    const mul=h&&h.base?(h.atk/h.base.atk)*(h.rangedDmg||1)*(hasPerk(h,'sapper')?1.25:1):1;
    for(const e of this.enemies){if(e.dead)continue;const dx=Math.abs(e.x-S.x)-(e.boss?e.w*.4:0),dz=e.fly?0:Math.abs((e.gy!=null?e.gy:this.G)-S.gy);const d=Math.hypot(Math.max(0,dx),dz*1.6);if(d>A.r)continue;const f=1-.7*d/A.r;
      this.hitEnemy(e,(this.rollDice(A.dice)+((h&&h.flatRanged)||0))*mul*f,h&&h.alive?h:null,{sure:1});if(!e.dead&&!e.boss){const res=(e.E&&e.E.kbRes)||0;e.kbv=Math.max(e.kbv||0,A.kb/100*40*8*(1-res)*f);e.kbDir=e.x>=S.x?1:-1;e.stun=Math.max(e.stun||0,.5*f);}}
    if(this.hardcore)for(const o of this.alive()){const d=Math.abs(this.heroX(o)-S.x);if(d<A.r&&Math.abs((o.gy||this.G)-S.gy)<14)this.hurtHero(o,this.rollDice(A.dice)*(1-.7*d/A.r)*.8,null);}
    for(const o of this.obst||[])if(/^car_/.test(o.k)&&Math.abs(o.x-S.x)<A.r&&o.alarmed==null&&!this.demo){o.alarmed=this.rng()<.5;if(o.alarmed)this.carAlarm(o);}}
  stepEng(dt,scroll){
    if(this.satchels&&this.satchels.length){for(const S of this.satchels){S.t+=dt;S.x0-=scroll*dt;S.x1-=scroll*dt;const u=Math.min(1,S.t/S.T);S.x=S.x0+(S.x1-S.x0)*u;S.hgt=50*Math.sin(Math.PI*u)*(u<1?1:0);if(S.x<-10)S.boom=1;}
      this.satchels=this.satchels.filter(S=>!S.boom);}
    const B=this.blds;if(!B||!B.length){this.engAuras(dt);return;}
    for(const b of B){b.t+=dt;b.x-=scroll*dt;if(b.hitT>0)b.hitT-=dt;if(b.car)b.x=b.car.x;
      if(b.k==='tesla'){b.hp-=b.max/b.A.life*dt;b.zT-=dt;if(b.zT<=0&&b.hp>0){const T=this.enemies.filter(e=>!e.dead&&Math.abs(e.x-b.x)<b.A.r).sort((p,q)=>Math.abs(p.x-b.x)-Math.abs(q.x-b.x))[0];
          if(T){b.zT=b.A.every;const mul=b.owner&&b.owner.base?(b.owner.atk/b.owner.base.atk):1;this.hitEnemy(T,this.rollDice(b.A.dice)*mul,b.owner&&b.owner.alive?b.owner:null,{sure:1});
            const pts=[[b.x,b.gy-20],[T.x,(T.gy!=null?T.gy:this.G)-12]];const T2=this.enemies.find(e=>!e.dead&&e!==T&&Math.abs(e.x-T.x)<25);
            if(T2){this.hitEnemy(T2,this.rollDice(b.A.dice)*mul*.6,b.owner&&b.owner.alive?b.owner:null,{sure:1});pts.push([T2.x,(T2.gy!=null?T2.gy:this.G)-12]);}
            this.fx.push({k:'bolt',pts,t:0,life:.25,raw:1});this.ev('zap',{});}else b.zT=.3;}}
      if(b.k==='turret'&&b.hp>0){const A=b.A;if(b.rl>0)b.rl-=dt;else{b.sT-=dt;if(b.sT<=0){const T=this.enemies.filter(e=>!e.dead&&e.x>b.x-20&&Math.abs(e.x-b.x)<A.range).sort((p,q)=>Math.abs(p.x-b.x)-Math.abs(q.x-b.x))[0];
          if(T){b.sT=A.gap;b.shots++;b.face=T.x>=b.x?1:-1;const ty=(T.gy!=null?T.gy:this.G)-12;this.fx.push({k:'tracer',x0:b.x+b.face*4,y0:b.gy-26,x1:T.x+(Math.random()-.5)*6,y1:ty+(Math.random()-.5)*8,t:0,life:.08,raw:1});this.ev('gun',{});
            if(this.rng()<A.hit)this.hitEnemy(T,this.rollDice(A.dice),b.owner&&b.owner.alive?b.owner:null,{sure:1,nocrit:1});
            if(b.shots>=A.burst){b.shots=0;b.rl=A.reload;}}else b.sT=.2;}}}}
    for(const b of B){if(b.hp<=0&&!b.gone){b.gone=1;this.fx.push({k:'poof',x:b.x,y:b.gy-14,t:0,big:true});if(b.car)b.car.turret=0;if(b.occ){const o=b.occ;o.perch=null;o.leapH=0;o.acc-=b.A.perchAcc;b.occ=null;}}}
    this.blds=B.filter(b=>!b.gone&&b.x>-30);
    this.engAuras(dt);}
  engAuras(dt){const B=this.blds||[];
    for(const o of this.alive()){if(o.ammoBuffT>0)o.ammoBuffT-=dt;o._bAcc=o._bAcc||0;let acc=0;
      for(const b of B){if(b.hp<=0)continue;const dx=this.heroX(o)-b.x,ad=Math.abs(dx),dz=Math.abs((o.gy||this.G)-b.gy);
        if(b.k==='tower'&&ad<b.A.r){if(b.tier>=1)this.healHero(o,o.max*b.A.regen*dt,true,b.owner);if(b.tier>=2)o.ammoBuffT=.3;if(b.tier>=3&&!b.occ)acc=Math.max(acc,b.A.acc);}
        if(b.k==='barrier'&&dx<0&&dx>-b.A.behind&&dz<=b.A.depth)acc=Math.max(acc,b.A.acc);}
      if(acc!==o._bAcc){o.acc+=acc-o._bAcc;o._bAcc=acc;}}
    // lookout: IF the tower is tier 3 and empty THEN the nearest ranged ally (not the Engineer) climbs up
    for(const b of B){if(b.k!=='tower'||b.tier<3||b.hp<=0)continue;if(b.occ&&(!b.occ.alive||b.x<12)){const o=b.occ;o.perch=null;o.leapH=0;o.acc-=b.A.perchAcc;b.occ=null;}
      if(!b.occ&&b.x>20){const o=this.alive().filter(o=>!o.pet&&o.key!=='eng'&&o.key!=='robot'&&o.base.char&&o.base.char.ranged&&!this.isMeleeHero(o)&&Math.abs(this.heroX(o)-b.x)<60).sort((p,q)=>Math.abs(this.heroX(p)-b.x)-Math.abs(this.heroX(q)-b.x))[0];
        if(o){b.occ=o;o.perch=b;o.acc+=b.A.perchAcc;Comms.bubble(this,o,Comms.pick(['Going up!','I have the high ground.','Nice view.']),true);}}
      if(b.occ){const o=b.occ;o.x=b.x;o.leapH=150;o.pauseT=Math.max(o.pauseT||0,.05);o.moving=false;}}
    // Field_Plating: IF the Engineer has been next to an ally for 3s AND they have no kit THEN strap one on
    for(const h of this.heroes){if(h.key!=='eng'||!h.alive)continue;const PL=(h.base.char.abilities||[]).find(a=>a.id==='plating');if(!PL)continue;
      for(const o of this.alive()){if(o===h||o.dog||o.kitHits>0)continue;if(Math.abs(this.heroX(o)-this.heroX(h))<PL.r&&Math.abs((o.gy||this.G)-(h.gy||this.G))<8){o.kitT=(o.kitT||0)+dt;if(o.kitT>=PL.T){o.kitT=0;o.kitHits=PL.hits;o.kitAdd=o.armorPts*PL.armor;o.armorPts+=o.kitAdd;o.kitKb=PL.kb;o.kbRes=(o.kbRes||0)+PL.kb;this.text(o.x,this.G-60,'+PLATING','#c8d0dc');this.ev('zap',{});}}else o.kitT=0;}}}
  /* 0.12.70 Void_Cultist: pay life""")
rep("    if(!this.tentacles||!this.tentacles.length)return;","    this.stepEng(dt,scroll);\n    if(!this.tentacles||!this.tentacles.length)return;")
rep("heroDown(h){if(this.tryResurge(h))return;h.syph=null;","heroDown(h){if(this.tryResurge(h))return;h.building=null;h.repairing=null;h.syph=null;")
open(p,'w').write(s);print('ok')
