import numpy as np, os
from PIL import Image
from scipy import ndimage as nd
OUT='/home/claude/pod2/assets/heroes/lumberjack/';os.makedirs(OUT,exist_ok=True)
def scale2x(a):
    h,w=a.shape[:2];o=np.zeros((h*2,w*2,4),a.dtype);P=np.pad(a,((1,1),(1,1),(0,0)),mode='edge')
    E=P[1:-1,1:-1];B=P[:-2,1:-1];D=P[1:-1,:-2];F=P[1:-1,2:];H=P[2:,1:-1]
    eq=lambda x,y:(x==y).all(-1)
    c1=eq(D,B)&~eq(B,F)&~eq(D,H);c2=eq(B,F)&~eq(B,D)&~eq(F,H);c3=eq(D,H)&~eq(D,B)&~eq(H,F);c4=eq(H,F)&~eq(D,H)&~eq(B,F)
    o[0::2,0::2]=np.where(c1[...,None],D,E);o[0::2,1::2]=np.where(c2[...,None],F,E);o[1::2,0::2]=np.where(c3[...,None],D,E);o[1::2,1::2]=np.where(c4[...,None],F,E)
    return o
def smooth4x(c):
    """Kyle (0.12.18): keep the flat colour regions, but make every edge a smooth curve instead of stair-steps and spikes.
    Upscale 8x, blur each colour region's mask and give every pixel to whichever colour is strongest there (a cheap
    vectorise), round the silhouette the same way, give it an even dark outline, then halve to 4x with area averaging."""
    a=c.copy();al=a[...,3]>0
    # drop light JPEG fringe pixels sitting on the silhouette edge (the white 'spikes')
    lum=a[...,:3].astype(int).sum(2);edge=al&(nd.binary_erosion(al)==0)
    a[edge&(lum>480),3]=0;al=a[...,3]>0
    K=8;up=np.kron(a,np.ones((K,K,1),np.uint8));A=up[...,3]>0
    cols=np.unique(up[A][:,:3],axis=0)
    best=np.zeros(A.shape);lab=np.full(A.shape,-1)
    for i,col in enumerate(cols):
        m=(up[...,:3]==col).all(-1)&A
        if m.sum()==0:continue
        b=nd.gaussian_filter(m.astype(float),4.0)
        better=b>best;best[better]=b[better];lab[better]=i
    sil=nd.gaussian_filter(A.astype(float),4.6)>.5
    sil=nd.binary_opening(sil,iterations=2)|(sil&nd.binary_erosion(A,iterations=3))   # trim hairline spurs, keep real thin parts
    out=np.zeros(up.shape,np.uint8);out[...,:3]=cols[np.clip(lab,0,None)];out[...,3]=np.where(sil,255,0)
    # even outline: a ring 4px wide (half a native pixel) of the darkest outline colour round the outside
    ring=nd.binary_dilation(sil,iterations=4)&~sil;dark=cols[np.argmin(cols.sum(1))]
    out[ring,:3]=np.minimum(dark,(40,26,30));out[ring,3]=255
    # halve to 4x with premultiplied area averaging (soft, anti-aliased edge)
    f=out.astype(float);f[...,:3]*=f[...,3:]/255
    h,w=f.shape[0]//2,f.shape[1]//2;f=f[:h*2,:w*2].reshape(h,2,w,2,4).mean((1,3))
    rgb=np.where(f[...,3:]>0,f[...,:3]*255/np.maximum(f[...,3:],1),0)
    return np.dstack([np.clip(rgb,0,255),f[...,3]]).astype(np.uint8)
SH={'a.jpg':(0,0),'b.jpg':(2,1)}
ROWS={'a.jpg':{'angry':(60,180),'bow':(205,320),'djump':(335,460),'fall':(470,605),'fun':(630,750),'hang':(755,895)},
      'b.jpg':{'spin':(60,175),'pullup':(195,315),'roll':(355,465),'run':(495,605),'sit':(635,750),'walk':(775,895)}}
BG=np.array([165,173,186])
for f,rows in ROWS.items():
    S=np.array(Image.open(f).convert('RGB')).astype(int);ox,oy=SH[f]
    A=S[oy::3,ox::3]
    # snap every art pixel to a small shared palette so edges are clean before upscaling (kills JPEG speckle)
    from scipy.cluster.vq import kmeans2
    m_=np.abs(A-BG).sum(2)>45;pts=A[m_].astype(float)
    np.random.seed(3);cent,lab_=kmeans2(pts,16,minit='++',seed=3)
    A2=A.copy();A2[m_]=np.clip(cent[lab_],0,255).astype(int);A=A2
    # snap every art pixel to the sheet's own palette (kills JPEG noise): cluster colours
    fg=np.abs(A-BG).sum(2)>45;fg[:,:530//3]=False
    for name,(y0,y1) in rows.items():
        y0//=3;y1//=3;m0=fg.copy();m0[:y0]=False;m0[y1:]=False
        lab,n=nd.label(nd.binary_dilation(m0,iterations=1));objs=nd.find_objects(lab);comps=[]
        for i,sl in enumerate(objs):
            if not sl:continue
            mm=(lab[sl]==i+1)&m0[sl]
            if mm.sum()<2:continue
            comps.append((i,sl,mm.sum(),(sl[1].start+sl[1].stop)/2))
        bodies=sorted([c for c in comps if c[2]>120],key=lambda c:c[3]);groups=[[b] for b in bodies]
        for c in comps:
            if c in bodies:continue
            k=int(np.argmin([abs(c[3]-b[3]) for b in bodies]));groups[k].append(c)
        frames=[]
        for g in groups:
            pass
        for g in groups:
            m=np.zeros(fg.shape,bool)
            for i,sl,_,_ in g:m[sl]|=(lab[sl]==i+1)&m0[sl]
            ys,xs=np.nonzero(m);gy=ys.max()
            band=m[max(0,gy-20):gy-8] if name in('walk','run') else m[gy-3:gy+1];fy,fx=np.nonzero(band);ax=int(np.median(fx))
            L,R,U=26,30,44;c=np.zeros((U+3,L+R,4),np.uint8)
            for yy in range(max(0,gy-U),gy+3):
                for xx in range(ax-L,ax+R):
                    if 0<=yy<A.shape[0] and 0<=xx<A.shape[1] and m[yy,xx]:c[yy-(gy-U),xx-(ax-L)]=[*A[yy,xx],255]
            al=c[...,3]>0;nb=nd.convolve(al.astype(int),np.ones((3,3)),mode='constant')-al
            lone=al&(nb<=1);c[lone,3]=0                       # single stray pixels sticking out
            frames.append(c)
        big=[smooth4x(fr) for fr in frames]        # 0.12.18: flat colours kept, edges smoothed into clean curves (see smooth4x)
        big=[np.ascontiguousarray(b[:,::-1]) for b in big]   # stored facing left
        Image.fromarray(np.concatenate(big,1)).save(OUT+name+'.png');print(name,len(frames),big[0].shape)
