from engine import *
BLADE=[(16,80,190),(50,150,250),(150,220,255),(235,255,255)]
GLOW_C=(60,235,235)
def mossy(pals,patches):
    def f(out,kid,s):
        if s.tilt:return
        for y in range(FH):
            for x in range(FW):
                i=kid[y,x]
                if i<0 or s.parts[i][1] not in pals:continue
                bx,by=x-OX-s.shift-s.lean,y-OY-s.bob
                h=((bx*73856093)^(by*19349663))%100
                for (px,py,r,kd) in patches:
                    if math.hypot(bx-px,(by-py)*1.25)<r+(.8 if h<45 else -.3):
                        if kd=='m':out[y,x]=(*((96,128,40) if h%3 else (150,182,70)),255)
                        else:out[y,x]=(*((122,62,30) if h%3 else (168,92,44)),255)
                        break
    return f
def legs(F,p,hip,pal,jp,thw=9,shw=8,foot=(8,4),kneeR=3.2,far=True,near=True):
    for side,key,dx in ((1,'ff',4),(-1,'nf',-4)):
        if (side>0 and not far) or (side<0 and not near):continue
        fx,lift=p.get(key,(side*5,0));hp=P(hip,(dx,2));ft=(fx,-2-lift);kn=((hp[0]+ft[0])/2-2,(hp[1]+ft[1])/2-1)
        pl=pal if side<0 else [tuple(int(v*.8) for v in c) for c in pal]
        F.add(seg(hp,kn,thw,thw-1),pl);F.add(seg(kn,ft,shw,shw-1),pl)
        F.add(oct(ft[0]-foot[0],ft[1]-foot[1],ft[0]+foot[0]*.6,ft[1]+1,2),pl)
        F.add(ell(kn[0],kn[1],kneeR,kneeR,10),jp if side<0 else [tuple(int(v*.8) for v in c) for c in jp])
# ---------------- A: Ironmoss Brute (bulky rounded lime armor, hunched, cyan visor slit)
GA=[(30,62,22),(74,134,38),(122,190,60),(186,238,108)];JA=[(30,26,40),(58,52,72),(92,86,110),(132,126,152)];MA=[(40,42,50),(80,84,96),(130,136,150),(190,196,210)]
def A(p):
    g=p.get;bob=g('bob',0)+g('sink',0);ln=g('lean',0);F=Frame(g('tilt',0));F.bob=bob;F.lean=ln
    hip=(0,-25+bob);
    legs(F,p,hip,GA,JA,far=True,near=False)
    # far shoulder + gatling (behind unless aiming)
    sh=(9+ln,-39+bob);ga=g('gun',1.4);el=pol(sh,ga,7);ge=pol(el,ga,g('aim',0)*11+13)
    gun=[(ell(sh[0],sh[1],7,6),GA),(seg(sh,el,6),JA),(seg(el,ge,7),MA),(ell(el[0],el[1],4.5,4.5,10),GA)]
    if not g('aim'):[F.add(*q) for q in gun]
    # back pod
    pd=g('pod',0);F.add(oct(8+ln,-56+bob-pd,17+ln,-36+bob-pd,2),[tuple(int(v*.8) for v in c) for c in GA])
    F.add(seg(P(hip,(0,-2)),(ln*.5,-31+bob),8),JA)   # waist
    F.add([(-14+ln,-48+bob),(11+ln,-48+bob),(12+ln,-42+bob),(7+ln,-29+bob),(-8+ln,-29+bob),(-14+ln,-40+bob)],GA)   # chest, tapered to the waist
    F.add(oct(-9+ln,-58+bob,5+ln,-45+bob,3),GA)   # head, sunk between the shoulders
    F.add(rect(-10+ln,-53+bob,-2+ln,-50.5+bob),[GLOW_C]*4,shade=False)   # visor slit
    legs(F,p,hip,GA,JA,far=False,near=True)
    # near arm: shoulder pad, arm, armored forearm, blade
    s2=(-9+ln,-41+bob);ba=g('blade',1.95);e2=pol(s2,ba+.3,7);f2=pol(e2,ba,7)
    F.add(seg(s2,e2,6),JA);F.add(seg(e2,f2,8,7),GA);F.add(ell(f2[0],f2[1],3.3,3.3,10),JA)
    tip=pol(f2,ba,g('bl',19));F.add(seg(f2,tip,4,1.4),BLADE)
    F.add(ell(s2[0]-1,s2[1]-3,8,7),GA)
    if g('aim'):[F.add(*q) for q in gun]
    # details
    for (x,y) in [(-6,-38),(4,-38),(-6,-32),(4,-32)]:F.dot(x+ln,y+bob,GA[3])
    F.line((-11+ln,-35+bob),(9+ln,-35+bob),GA[0])
    if not g('dim'):F.dot(-9+ln,-52+bob,(220,255,255))
    else:F.parts=[(pts,[(30,60,70)]*4,sh_,gl) if pal==[GLOW_C]*4 else (pts,pal,sh_,gl) for pts,pal,sh_,gl in F.parts]
    if pd>=2:
        for i,x in enumerate((10,13)):F.dot(x+ln,-57+bob-pd,(255,180,60));F.dot(x+ln,-58+bob-pd,(255,90,40))
    if g('flash'):
        for k in range(1,6):F.dot(ge[0]-k,ge[1],(255,240,170) if k<3 else (255,170,60))
        F.dot(ge[0]-2,ge[1]-1,(255,170,60));F.dot(ge[0]-2,ge[1]+1,(255,170,60))
    if g('aim'):
        sp=g('spin',0)
        for k in range(3,12):F.dot(pol(el,ga,k)[0],pol(el,ga,k)[1]+((k+sp)%3-1),MA[3] if (k+sp)%3==0 else MA[0])
    return F,mossy([GA],[(-4,-57,2.6,'m'),(3,-55,2,'m'),(-10,-44,2.2,'m'),(6,-30,2.1,'r'),(-12,-29,1.6,'r'),(12,-47,1.8,'m')])
# ---------------- B: Bulwark Walker (boxy olive war-walker, cockpit box, shoulder missile rack)
GB=[(40,42,22),(88,94,44),(134,140,70),(186,188,112)];JB=[(24,24,28),(50,50,56),(84,84,92),(124,124,132)];MB=[(34,34,38),(74,74,80),(120,120,128),(176,176,186)]
def B(p):
    g=p.get;bob=g('bob',0)+g('sink',0);ln=g('lean',0);F=Frame(g('tilt',0));F.bob=bob;F.lean=ln
    hip=(0,-24+bob)
    legs(F,p,hip,GB,JB,thw=8,shw=7,foot=(9,4),far=True,near=False)
    sh=(8+ln,-34+bob);ga=g('gun',1.35);el=pol(sh,ga,6);ge=pol(el,ga,g('aim',0)*12+14)
    gun=[(seg(sh,el,6),JB),(oct(el[0]-5,el[1]-4,el[0]+5,el[1]+4,2),GB),(seg(el,ge,6),MB)]
    if not g('aim'):[F.add(*q) for q in gun]
    pd=g('pod',0);F.add(oct(4+ln,-62+bob-pd,18+ln,-50+bob-pd,1),GB)   # missile rack
    F.add(rect(-5+ln,-28+bob,6+ln,-22+bob),JB)   # hip block
    F.add(oct(-15+ln,-52+bob,13+ln,-27+bob,3),GB)   # the big cockpit box
    F.add(rect(-15+ln,-46+bob,-3+ln,-43+bob),[(14,16,20)]*4,shade=False);F.add(rect(-14+ln,-45.5+bob,-5+ln,-44+bob),[GLOW_C]*4,shade=False)   # visor slit
    legs(F,p,hip,GB,JB,thw=8,shw=7,foot=(9,4),far=False,near=True)
    s2=(-10+ln,-36+bob);ba=g('blade',1.95);e2=pol(s2,ba+.3,6);f2=pol(e2,ba,6)
    F.add(seg(s2,e2,6),JB);F.add(seg(e2,f2,7,6),GB);F.add(rect(f2[0]-2.6,f2[1]-2.6,f2[0]+2.6,f2[1]+2.6),JB)
    tip=pol(f2,ba,g('bl',18));F.add(seg(f2,tip,4,1.4),BLADE)
    F.add(oct(s2[0]-5,s2[1]-4,s2[0]+4,s2[1]+5,2),GB)
    if g('aim'):[F.add(*q) for q in gun]
    # details: rivets, panel seams, rack tubes, hazard stripe on the leg
    for (x,y) in [(-13,-50),(11,-50),(-13,-29),(11,-29),(0,-50)]:F.dot(x+ln,y+bob,GB[3])
    F.line((-1+ln,-41+bob),(-1+ln,-29+bob),GB[0]);F.line((-14+ln,-38+bob),(12+ln,-38+bob),GB[0])
    for r in range(2):
        for c in range(3):F.dot(7+c*3.5+ln,-59+r*4+bob-pd,(255,70,50) if pd>=2 else (110,30,26));F.dot(7+c*3.5+ln,-58+r*4+bob-pd,(40,14,14))
    nf=p.get('nf',(-5,0));F.line((nf[0]-4,-12+bob*0),(nf[0]-1,-12),(230,190,40))
    if g('dim'):F.parts=[(pts,[(30,60,70)]*4,sh_,gl) if pal==[GLOW_C]*4 else (pts,pal,sh_,gl) for pts,pal,sh_,gl in F.parts]
    if g('flash'):
        for k in range(1,6):F.dot(ge[0]-k,ge[1],(255,240,170) if k<3 else (255,170,60))
        F.dot(ge[0]-2,ge[1]-1,(255,170,60));F.dot(ge[0]-2,ge[1]+1,(255,170,60))
    if g('aim'):
        sp=g('spin',0)
        for k in range(2,13):F.dot(pol(el,ga,k)[0],pol(el,ga,k)[1]+((k+sp)%3-1),MB[3] if (k+sp)%3==0 else MB[0])
    return F,mossy([GB],[(-10,-52,2.4,'m'),(6,-52,2,'m'),(10,-30,2,'r'),(-12,-31,1.6,'r'),(13,-62,1.8,'m')])
# ---------------- C: Cogbot (dark gunmetal, rounded head box, cyan visor bar, antenna, orange vents)
GC=[(26,28,36),(54,58,72),(90,96,114),(136,144,164)];JC=[(18,18,24),(38,40,50),(66,70,84),(100,104,120)];MC=GC;OR=(255,164,44)
def C(p):
    g=p.get;bob=g('bob',0)+g('sink',0);ln=g('lean',0);F=Frame(g('tilt',0));F.bob=bob;F.lean=ln
    hip=(0,-23+bob)
    legs(F,p,hip,GC,JC,thw=8,shw=8,foot=(8,4),kneeR=3.6,far=True,near=False)
    sh=(8+ln,-37+bob);ga=g('gun',1.4);el=pol(sh,ga,7);ge=pol(el,ga,g('aim',0)*11+12)
    gun=[(ell(sh[0],sh[1],5,5,10),JC),(seg(sh,el,5),GC),(ell(el[0],el[1],3.5,3.5,10),JC),(seg(el,ge,6),MC)]
    if not g('aim'):[F.add(*q) for q in gun]
    pd=g('pod',0);F.add(oct(7+ln,-54+bob-pd,15+ln,-38+bob-pd,2),JC)   # back pack
    F.add(rect(-5+ln,-28+bob,5+ln,-22+bob),JC)
    F.add(oct(-11+ln,-46+bob,10+ln,-27+bob,4),GC)   # body
    F.add(oct(-13+ln,-63+bob,7+ln,-46+bob,4),GC)   # head box
    F.add(oct(-13+ln,-59+bob,-1+ln,-54+bob,1),[(14,16,22)]*4,shade=False);F.add(rect(-12+ln,-58+bob,-2+ln,-55+bob),[GLOW_C]*4,shade=False)
    F.add(seg((2+ln,-63+bob),(2+ln,-69+bob),1.2),JC,shade=False)
    legs(F,p,hip,GC,JC,thw=8,shw=8,foot=(8,4),kneeR=3.6,far=False,near=True)
    s2=(-9+ln,-40+bob);ba=g('blade',1.95);e2=pol(s2,ba+.3,7);f2=pol(e2,ba,6)
    F.add(seg(s2,e2,5),GC);F.add(ell(e2[0],e2[1],3,3,10),JC);F.add(seg(e2,f2,6,6),GC);F.add(ell(f2[0],f2[1],3.2,3.2,10),JC)
    tip=pol(f2,ba,g('bl',18));F.add(seg(f2,tip,4,1.4),BLADE)
    F.add(ell(s2[0],s2[1],5.5,5.5,12),GC)
    if g('aim'):[F.add(*q) for q in gun]
    # orange vents, grille, antenna tip, rivets
    for k in range(3):F.line((-4+k*2+ln,-38+bob),(-4+k*2+ln,-33+bob),OR)
    for k in range(3):F.dot(4+ln,-60+k*2+bob,OR)
    F.dot(2+ln,-70+bob,OR);F.dot(2+ln,-69+bob,(255,220,150))
    for (x,y) in [(-9,-44),(8,-44),(-9,-29),(8,-29)]:F.dot(x+ln,y+bob,GC[3])
    F.line((s2[0]-2,s2[1]+5),(s2[0]+2,s2[1]+5),OR)
    if g('dim'):F.parts=[(pts,[(30,60,70)]*4,sh_,gl) if pal==[GLOW_C]*4 else (pts,pal,sh_,gl) for pts,pal,sh_,gl in F.parts]
    else:F.dot(-11+ln,-57+bob,(220,255,255))
    if g('flash'):
        for k in range(1,6):F.dot(ge[0]-k,ge[1],(255,240,170) if k<3 else (255,170,60))
        F.dot(ge[0]-2,ge[1]-1,(255,170,60));F.dot(ge[0]-2,ge[1]+1,(255,170,60))
    if g('aim'):
        sp=g('spin',0)
        for k in range(3,11):F.dot(pol(el,ga,k)[0],pol(el,ga,k)[1]+((k+sp)%3-1),GC[3] if (k+sp)%3==0 else GC[0])
    if pd>=2:F.dot(11+ln,-55+bob-pd,(255,90,40));F.dot(12+ln,-55+bob-pd,(255,180,60))
    return F,mossy([GC],[(-6,-63,2.6,'m'),(3,-62,1.8,'m'),(-10,-46,1.6,'m'),(7,-29,1.8,'r'),(-12,-50,1.4,'r')])
import sys
for nm,fn in (('A',A),('B',B),('C',C)):
    R=poses();rows={}
    for k,lst in R.items():
        rows[k]=[]
        for pz in lst:F,patch=fn(pz);rows[k].append(F.render(patch))
    S,meta=sheet('robot_'+nm,rows);gif('robot_'+nm,rows)
    bg=Image.new('RGBA',S.size,(36,30,46,255));bg.alpha_composite(S);bg.resize((S.width*2,S.height*2),Image.NEAREST).save(f'/tmp/robot_{nm}_prev.png')
print(meta)
