from PIL import Image, ImageDraw
import numpy as np, math
FW,FH=80,72;OX,OY=41,68
def rot(pts,ang,c):
    ca,sa=math.cos(ang),math.sin(ang);return [(c[0]+(x-c[0])*ca-(y-c[1])*sa,c[1]+(x-c[0])*sa+(y-c[1])*ca) for x,y in pts]
def rect(x0,y0,x1,y1):return [(x0,y0),(x1,y0),(x1,y1),(x0,y1)]
def oct(x0,y0,x1,y1,c=2):return [(x0+c,y0),(x1-c,y0),(x1,y0+c),(x1,y1-c),(x1-c,y1),(x0+c,y1),(x0,y1-c),(x0,y0+c)]
def seg(a,b,w,w2=None):
    w2=w if w2 is None else w2;dx,dy=b[0]-a[0],b[1]-a[1];L=math.hypot(dx,dy) or 1;nx,ny=-dy/L,dx/L
    return [(a[0]+nx*w/2,a[1]+ny*w/2),(b[0]+nx*w2/2,b[1]+ny*w2/2),(b[0]-nx*w2/2,b[1]-ny*w2/2),(a[0]-nx*w/2,a[1]-ny*w/2)]
def ell(cx,cy,rx,ry,n=14):return [(cx+rx*math.cos(t*2*math.pi/n),cy+ry*math.sin(t*2*math.pi/n)) for t in range(n)]
def P(a,d):return (a[0]+d[0],a[1]+d[1])
def pol(a,ang,L):return (a[0]+math.cos(ang)*L,a[1]+math.sin(ang)*L)
OUT=(14,12,20)
class Frame:
    def __init__(s,tilt=0,shift=0):s.parts=[];s.decal=[];s.tilt=tilt;s.shift=shift
    def add(s,pts,pal,shade=True,glow=False):s.parts.append((pts,pal,shade,glow))
    def dot(s,x,y,c):s.decal.append((x,y,c))
    def line(s,a,b,c):
        n=int(max(abs(b[0]-a[0]),abs(b[1]-a[1])))+1
        for i in range(n+1):t=i/max(1,n);s.dot(a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,c)
    def T(s,pts):
        if s.tilt:pts=rot(pts,s.tilt,(4,0))
        return [(OX+x-math.sin(s.tilt)*30+s.shift,OY+y) for x,y in pts]
    def render(s,patch=None):
        H,W=FH,FW;kid=np.full((H,W),-1,np.int32);s.bb=[]
        for i,(pts,pal,sh,gl) in enumerate(s.parts):
            m=Image.new('L',(W,H));ImageDraw.Draw(m).polygon(s.T(pts),fill=255);mm=np.array(m)>0;kid[mm]=i
            ys,xs=np.nonzero(mm);s.bb.append((xs.min(),ys.min(),xs.max(),ys.max()) if len(xs) else (0,0,1,1))
        out=np.zeros((H,W,4),np.uint8)
        def same(y,x,i):return 0<=y<H and 0<=x<W and kid[y,x]==i
        for y in range(H):
            for x in range(W):
                i=kid[y,x]
                if i<0:continue
                pts,pal,sh,gl=s.parts[i];c=pal[1]
                if sh:
                    x0,y0,x1,y1=s.bb[i];t=((x-x0)/max(1,x1-x0)*.45+(y-y0)/max(1,y1-y0)*.55)
                    c=pal[2] if t<.28 else (pal[0] if t>.78 else pal[1])   # volume: lit from the top-left
                    tl=not same(y-1,x,i) or not same(y,x-1,i);br=not same(y+1,x,i) or not same(y,x+1,i);br2=not same(y+2,x+1,i)
                    tl2=not same(y-2,x,i)
                    if br and not tl:c=tuple(int(v*.75) for v in pal[0])
                    elif tl and not br:c=pal[3] if (not same(y-1,x,i) and len(pal)>3) else pal[2]
                    elif tl2 and t<.6:c=pal[3] if len(pal)>3 and t<.35 else pal[2]
                    elif br2:c=pal[0]
                    # a darker seam where something in front overlaps this part
                    for dy,dx in((-1,0),(0,-1),(1,0),(0,1)):
                        if 0<=y+dy<H and 0<=x+dx<W and kid[y+dy,x+dx]>i and s.parts[kid[y+dy,x+dx]][2]:c=tuple(int(v*.55) for v in pal[0]);break
                out[y,x]=(*c,255)
        if patch:patch(out,kid,s)
        for x,y,c in s.decal:
            X,Y=s.T([(x,y)])[0];X,Y=int(round(X)),int(round(Y))
            if 0<=X<W and 0<=Y<H and out[Y,X,3]:out[Y,X]=(*c,255)
        a=out[...,3]>0;pad=np.pad(a,1);ring=(~a)&(pad[:-2,1:-1]|pad[2:,1:-1]|pad[1:-1,:-2]|pad[1:-1,2:])
        out[ring]=(*OUT,255)
        return out
def sheet(name,rows,order=('walk','idle','melee','ranged','missile','throw','hurt','death')):
    S=Image.new('RGBA',(FW*8,FH*len(order)));meta={}
    for r,n in enumerate(order):
        for i,f in enumerate(rows[n]):S.alpha_composite(Image.fromarray(f,'RGBA'),(i*FW,r*FH))
        meta[n]=dict(n=len(rows[n]),y=r*FH)
    S.save(f'/home/claude/robot2/{name}.png');return S,meta
def gif(name,rows,bg=(24,20,32)):
    seq=[];
    for n,rep,dur in [('idle',2,180),('walk',2,90),('melee',1,110),('ranged',3,50),('missile',1,150),('throw',1,130),('hurt',1,140),('death',1,180)]:
        for _ in range(rep):
            for f in rows[n]:
                im=Image.new('RGBA',(FW,FH),bg+(255,));im.alpha_composite(Image.fromarray(f,'RGBA'));seq.append((im.resize((FW*5,FH*5),Image.NEAREST).convert('P',palette=Image.ADAPTIVE),dur))
    seq[0][0].save(f'/home/claude/robot2/{name}.gif',save_all=True,append_images=[a for a,_ in seq[1:]],duration=[d for _,d in seq],loop=0,disposal=2)
# shared poses (same skeleton keys for every design)
def poses():
    R={}
    R['idle']=[dict(bob=b,spark=i) for i,b in enumerate([0,0,1,1])]
    W=[]
    for i in range(8):
        ph=i/8*2*math.pi;W.append(dict(bob=0 if i%4 in(0,2) else -1,nf=(-5+7*math.cos(ph),max(0,3*math.sin(ph))),ff=(5-7*math.cos(ph),max(0,-3*math.sin(ph))),swing=math.sin(ph),spark=i))
    R['walk']=W
    R['melee']=[dict(blade=-1.25,lean=1,spark=1),dict(blade=-2.3,lean=1,spark=2),dict(blade=math.pi+.05,lean=-2,spark=3,nf=(-8,0),slash=1),dict(blade=2.55,lean=-1,spark=4)]
    R['ranged']=[dict(gun=math.pi-.04,spin=s,flash=f,spark=s,aim=1) for s,f in [(0,0),(1,1),(2,0),(3,1)]]
    R['missile']=[dict(pod=p) for p in (0,2,4,2)]
    R['throw']=[dict(blade=-1.6,lean=1),dict(blade=-2.6,lean=1),dict(blade=math.pi+.4,lean=-1)]
    R['hurt']=[dict(tilt=.1,lean=2),dict(tilt=.04,lean=1)]
    R['death']=[dict(tilt=.2,dim=0),dict(tilt=.55,sink=2),dict(tilt=.95,sink=3,dim=1),dict(tilt=1.3,sink=4,dim=1),dict(tilt=1.5,sink=5,dim=1)]
    return R
