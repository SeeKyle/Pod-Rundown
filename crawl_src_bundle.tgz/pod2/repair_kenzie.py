# 0.12.312: Needs Repair for Kenzie's decks + Eddie's rebuilt Miles (prices: Scryfall, 2026-11-18)
P={"Rampant Growth":.30,"Arcane Signet":.34,"Nature's Lore":1.40,"Archangel of Thune":43.80,"Harmonize":.33,"Well of Lost Dreams":5.61,"Lifecrafter's Bestiary":.43,
"The Great Henge":62.98,"Cultivate":.32,"Kodama's Reach":1.88,"Three Visits":5.09,"Avacyn, Angel of Hope":42.49,"Felidar Sovereign":4.55,"Ajani's Pridemate":.28,
"Heliod, Sun-Crowned":21.78,"Smothering Tithe":61.48,"Phyrexian Arena":2.89,"Night's Whisper":.27,"Sylvan Library":27.00,"Ravenous Chupacabra":.90,
"Anguished Unmaking":.58,"Grave Pact":31.17,"Fellwar Stone":2.61,"Talisman of Hierarchy":.34,"Hydroid Krasis":.32,"Biomass Mutation":.30,"Herald of Secret Streams":7.72,
"Craterhoof Behemoth":26.11,"Explosive Vegetation":.33,"Howling Mine":2.00,"Temple Bell":6.67,"Kami of the Crescent Moon":7.75,"Edric, Spymaster of Trest":3.15,
"Ghostly Prison":7.12,"Propaganda":3.16,"Collective Restraint":13.46,"Armorcraft Judge":.29,"Branching Evolution":7.31,"Doubling Season":33.50,"Cathars' Crusade":8.45,
"Elite Scaleguard":.24,"Kalonian Hydra":6.85,"Avenger of Zendikar":.60,"Bred for the Hunt":.47,"Hunter's Insight":.43,"Guardian Project":3.65}
def S(*xs):
    return [dict(tier=t, card=c, why=w, usd=P[c]) for t, c, w in xs]
SB, MD, AC = 'Super budget', 'Medium', 'Any cost'
REPAIR_KZ = {
 'kenzie_trostani': [
  dict(card='Trollhide', read=1, why='Pump and regenerate on one creature; does almost nothing for the Angel plan.', swaps=S(
    (SB, 'Rampant Growth', 'ramp: Mana is one of the lowest stats'), (SB, 'Arcane Signet', 'a 2-mana rock that fixes'),
    (MD, 'Three Visits', 'two-mana ramp that grabs a dual'), (AC, 'Archangel of Thune', 'every life gain puts a counter on every creature'))),
  dict(card='Strionic Resonator', read=2, why='Copies a trigger, but the deck has few big ones worth copying.', swaps=S(
    (SB, 'Harmonize', 'three cards: Cards is the lowest stat'), (SB, "Lifecrafter's Bestiary", 'draws off every creature you cast'),
    (MD, 'Well of Lost Dreams', 'turns all that life gain into cards'), (AC, 'The Great Henge', 'mana, life, a counter and a card on every creature'))),
  dict(card='Prodigious Growth', read=2, why='Seven mana for a one-creature pump.', swaps=S(
    (SB, 'Cultivate', 'ramp plus a land in hand'), (SB, "Kodama's Reach", 'a second Cultivate'),
    (MD, 'Ghostly Prison', 'keeps attackers off you: politics the pod is short on'), (AC, 'Avacyn, Angel of Hope', 'makes the whole team indestructible'))),
  dict(card="Bard's Bow", read=2, why='Equipment that only helps one creature at a time.', swaps=S(
    (SB, "Ajani's Pridemate", 'grows on every life gain'), (SB, "Nature's Lore", 'untapped land ramp'),
    (MD, 'Felidar Sovereign', 'wins at 40 life, easy for this deck'), (AC, 'Heliod, Sun-Crowned', 'life gain becomes counters and lifelink for anything'))),
 ],
 'kenzie_thalia': [
  dict(card='Strength of Unity', read=1, why='A small aura pump in a removal deck.', swaps=S(
    (SB, 'Cultivate', 'ramp: Mana is low for the 6- to 9-drops'), (SB, "Kodama's Reach", 'more ramp plus a land in hand'),
    (MD, 'Three Visits', 'cheap ramp into a dual'), (AC, 'Smothering Tithe', 'Treasure every time an opponent draws'))),
  dict(card='Sorcerous Spyglass', read=1, why='Shuts off one activated ability: Interaction is already the top stat, and Cards is one of the lowest.', swaps=S(
    (SB, 'Harmonize', 'three cards: Cards is low'), (SB, "Night's Whisper", 'two cards for two mana'),
    (MD, 'Well of Lost Dreams', 'turns the life gain into cards'), (AC, 'Sylvan Library', 'picks your best draws every turn'))),
  dict(card='Candletrap', read=1, why='A weak Pacifism in a deck already stacked with answers; Threats and Finish are short.', swaps=S(
    (SB, 'Avenger of Zendikar', 'a Plant army that grows on every land drop (and you play two)'), (SB, "Ajani's Pridemate", 'grows on every life gain'),
    (MD, 'Kalonian Hydra', 'a fast-growing threat that closes games'), (AC, 'Craterhoof Behemoth', 'a finisher: Finish is the weakest stat'))),
  dict(card='Plummet', read=2, why='Only kills fliers, and the deck has plenty of better answers.', swaps=S(
    (SB, "Hunter's Insight", 'draws a pile off one big hit'), (SB, "Lifecrafter's Bestiary", 'draws off every creature you cast'),
    (MD, 'Temple Bell', 'cards for everyone, you first'), (AC, 'Archangel of Thune', 'life gain grows the whole team'))),
 ],
 'kenzie_bumble': [
  dict(card='Steelburr Champion', read=2, why='Grows slowly and only on noncreature spells from opponents.', swaps=S(
    (SB, 'Hydroid Krasis', 'cards, life and a flier'), (SB, 'Biomass Mutation', 'a finisher: Finish is low'),
    (MD, 'Herald of Secret Streams', 'countered creatures are unblockable'), (AC, 'Craterhoof Behemoth', 'ends the game out of nowhere'))),
  dict(card='Jolly Gerbils', read=2, why='Only draws off gifts, and Cards is already one of the top stats; Threats and Finish are short.', swaps=S(
    (SB, 'Avenger of Zendikar', 'a Plant army: Threats is low'), (SB, 'Elite Scaleguard', 'counters as it enters, and taps blockers every attack'),
    (MD, "Cathars' Crusade", 'every creature grows the whole team'), (AC, 'The Great Henge', 'mana, a counter and a card on every creature'))),
  dict(card='Coiling Oracle', read=3, why='One card and a 1/1.', swaps=S(
    (SB, 'Howling Mine', 'group hug classic: everyone draws'), (SB, 'Harmonize', 'three cards for you'),
    (MD, 'Kami of the Crescent Moon', 'everyone draws an extra card'), (AC, 'Doubling Season', 'doubles every counter you hand out'))),
  dict(card='Snake Pit', read=2, why='Only works when opponents cast blue or black.', swaps=S(
    (SB, 'Propaganda', 'attack tax: politics'), (SB, 'Edric, Spymaster of Trest', 'opponents draw when they hit others'),
    (MD, 'Ghostly Prison', 'attack tax'), (AC, 'Collective Restraint', 'a big attack tax with domain'))),
 ],
 'eddie_miles': [
  dict(card='Radha, Coalition Warlord', read=2, why='A small pump that needs domain and tapping.', swaps=S(
    (SB, 'Armorcraft Judge', 'draws a card per countered creature'), (SB, 'Elite Scaleguard', 'counters every time it enters, taps blockers'),
    (MD, 'Branching Evolution', 'doubles counters on creatures'), (AC, 'Doubling Season', 'doubles every counter'))),
  dict(card='Path of Discovery', read=2, why='Explore triggers, but few creatures with it.', swaps=S(
    (SB, 'Bred for the Hunt', 'draws when countered creatures connect'), (SB, "Hunter's Insight", 'a big draw spell: Cards is the lowest stat'),
    (MD, "Cathars' Crusade", 'counters on the team every creature'), (AC, 'Craterhoof Behemoth', 'a finisher: Finish is low'))),
  dict(card='Together Forever', read=2, why='Small support plus a pricey way to save one creature; Survival is already a top stat and Cards is the lowest.', swaps=S(
    (SB, 'Howling Mine', 'everyone draws extra: Cards is the lowest stat'), (SB, "Lifecrafter's Bestiary", 'draws off every creature you cast'),
    (MD, 'Temple Bell', 'cards for everyone, you first'), (AC, 'Sylvan Library', 'picks your best draws every turn'))),
  dict(card='Resourceful Defense', read=2, why='Moves counters but does little on its own.', swaps=S(
    (SB, 'Avenger of Zendikar', 'a Plant army that grows on landfall'), (SB, 'Guardian Project', 'draws on every new creature'),
    (MD, 'Kalonian Hydra', 'doubles counters on attack'), (AC, 'Archangel of Thune', 'every life gain grows the team'))),
 ],
}
