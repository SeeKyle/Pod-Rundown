# My read of each candidate (1 = weak link, 5 = strong in this deck) + why
J = {
'grim': {'Qarsi Revenant':(3,"A fine 3/3 flier with good keywords, but it doesn't cheat, ramp or find the Throne, and the deck's 3-slot is better spent on cascade."),
 'Venomous Changeling':(2,"A 1/3 that exists to be crafting fodder; any creature card does that job and this one does nothing on the board."),
 'Indoraptor, the Perfect Hybrid':(3,"Bloodthirst X makes it a real threat cast after a big combat (a 12-power hit means a 15/13 menace), but cast early it's a fragile 3/1 and its enrage aims at a random opponent."),
 'Scavenged Brawler':(3,"A fine 4/4 flier, but at 6 mana it competes with the deck's game-winning top end; its best use is from the graveyard (another 5 mana) to make a fatty fly, which is a lot of mana for one card."),
 'Ardent Plea':(4,"Always cascades into the Throne, so it's a tutor in disguise."),
 'Tempest Hart // Scan the Clouds':(3,"An instant loot early or an Elk that grows on big spells late; both halves are filler in a deck that wants to cheat out fatties."),
 'Symbiote Spider-Man':(3,"Weak on its own (a 2/4 rarely connects), but its real value is later: from the graveyard it hands its dig-and-keep ability to a 12-power trampler. Slow, two-step value."),
 'Silver Surfer, Galactus\'s Herald':(3,"A 4/5 flier whose real job is finding Galactus; once Galactus is drawn or out, it's a plain body in a deck full of bigger ones."),
 'Incarnation Technique':(2,"5 mana to mill 5 and hope a fatty lands; slower and less certain than a straight reanimation spell, and nothing here recurs it."),
 'Indominus Rex, Alpha':(3,"It only draws and gains keywords if you discard creature cards, which means throwing away the fatties this deck wants to cast or cheat in."),
 'Amphin Mutineer':(4,"Removal that hits anything, twice with encore."),
 'Shardless Agent':(5,"Always finds the Throne."),
 'Captivating Crew':(3,"Steal-and-swing is good late; slow early.")},
'thing': {'Single Combat':(3,"Every player keeps one creature: good when The Thing is your one, but it's the deck's third wipe and hits your own helpers too."),
 'Ultros, Obnoxious Octopus':(2,"Taps and stuns one creature per big spell; it doesn't feed The Thing or draw, and it's a soft answer at best."),
 'Thundertrap Trainer':(2,"A 1/2 that digs for one noncreature card; the deck already has better draw, so this is a slow cantrip on a body."),
 'Mega Flare':(3,"Only as good as your biggest creature: without The Thing out, it's a weak burn spell for 3."),
 'Echo, Perceptive Prodigy':(2,"Copying a creature trigger is cute, but it needs The Thing on board and doesn't do anything alone."),
 'Search for Glory':(2,"3 mana sorcery to fetch a legendary card; Time of Need does the same job better and cheaper."),
 'Time of Need':(4,"2-mana tutor for The Thing."),
 'Hurkyl, Master Wizard':(3,"Card advantage engine on noncreature turns."),
 'Lockjaw, Slobbering Teleporter':(4,"Makes The Thing unblockable."),
 "It's Clobberin' Time!":(3,"Flexible answer with rebound."),
 'Gogo, Master of Mimicry':(3,"Copies The Thing's trigger for a huge pump."),
 'Last Night Together':(4,"Extra combat with The Thing."),
 'Super Combo':(3,"Removal that scales with The Thing.")},
'kykar': {'Ral, Storm Conduit':(2,'A 4-mana planeswalker with small effects; the 2-drop pingers do more for less.'),
 'Spellgorger Weird':(3,'Grows with spells, but a ground creature in a deck whose threats are fliers.'),
 'Salvager of Secrets':(2,"A 5-mana 2/2 that returns one spell; slow for a deck whose curve tops out at 4."),
 'Micromancer':(2,"4 mana to tutor a 1-mana spell; the deck's best 1-drops aren't game-winning enough to be worth that."),
 'Befuddle':(2,"-4/-0 and a card is a fog for one creature, not an answer."),
 'Majestic Metamorphosis':(2,"Turns a token into a 4/4 flier and draws; okay with Zada but weak alone."),
 'Erratic Cyclops':(2,"A 0/8 that only matters on big spell turns."),
 'Monastery Swiftspear':(2,"A 1/2 haste attacker that doesn't make tokens, ping, or draw; in a 4-player pod it gets walled on turn 2."),
 'Startle':(2,"A 2-mana cantrip whose Zombie can't block and dies when it attacks; it triggers the spell payoffs, but every other cheap spell here does more."),
 'Desperate Ravings':(2,"Random discard can throw away Zada or Talrand."),
 'Essence Capture':(3,"Counterspell that grows something."),
 "Samut's Sprint":(3,"Great with Zada copying it to the team."),
 "River Song's Diary":(2,"Slow, symmetric graveyard effect."),
 'Frolicking Familiar // Blow Off Steam':(3,"Two spells in one card.")},
'mathas': {'Condemn':(3,"Only hits attackers and gives them life; a fine pillowfort piece, but weaker than the deck's other cheap removal."),
 "Knight of Dusk's Shadow":(1,"A 2/2 menace whose only job is stopping opponents gaining life, which rarely comes up; it doesn't swap, draw or protect."),
 'Termination Facilitator':(2,"Kills bounty creatures only once they're damaged; slow and needs setup on top of Mathas."),
 'Mystic Barrier':(3,"Pillowfort that steers attacks."),
 'Tallyman of Nurgle':(2,"A 2/3 lifelinker that only draws if a creature died; small impact for its slot."),
 'Deadly Tempest':(3,"Wipe plus drain, but it's the fifth wipe in the list."),
 'Starving Revenant':(3,"Card flow for life, on theme."),
 'Final Act':(3,"Flexible wipe, but redundant here."),
 "Curse of Fool's Wisdom":(2,"Drains one player for each card they draw; strong only against a heavy-draw deck, and otherwise it does little."),
 'Cursed Recording':(3,"Copies swap spells."),
 'Phyrexian Lens':(2,"A 3-mana rock that costs life every use; in a deck already paying life everywhere, a Talisman does this job cheaper."),
 'Toil // Trouble':(2,"Fused, it's okay; separately it's weak."),
 'Erebos, Bleak-Hearted':(4,"Draw engine and sac outlet.")},
'turtle': {'Level Up':(2,'An aura that grows one creature in a deck that wins by going wide; Leonardo already does better.'),
 'Roadkill Rodney':(2,"A small deathtouch body whose Mutagen trigger needs it to connect; it doesn't make tokens or grow the team."),
 'Kibo, Uktabi Prince':(2,"Gives everyone Bananas and only punishes on attack; the symmetric half helps opponents as much as you."),
 'Arcade Cabinet':(2,"3 mana for a few counters; Leonardo already does this every turn."),
 'Donatello, the Brains':(3,"Only adds one Mutagen per token batch; a 3-drop with almost no body, and the deck's other token boosters do far more."),
 'Biogenic Ooze':(4,"A growing army on its own."),
 'Game Over':(2,"A wipe that kills your own token army; you're the deck that loses most to it."),
 'Shellshock':(3,"One-sided removal per opponent."),
 'Killer Service':(3,"Food plus Rhinos; fine."),
 'Sam, Loyal Attendant':(2,"Food every combat is small in this deck."),
 'Here Comes a New Hero!':(3,"Draw plus a copy."),
 'Coin of Mastery':(2,"A slow rock."),
 'Scepter of Celebration':(3,"Makes tokens on hits.")},
'marina': {'Ritual of Soot':(2,"Only kills cheap creatures, at 4 mana; big threats live through it."),
 'Curse of Thirst':(1,"Pings for 2-3 a turn at best; it's the weakest curse, and the curse slot is better spent on one that steers the table."),
 "Curse of Death's Hold":(2,"-1/-1 to one player's board only kills small tokens."),
 'Curse of Misfortunes':(3,"5 mana for a curse that only finds more curses; slow, and most of the curses it finds are small."),
 'Meat Locker // Drowned Diner':(3,"Both doors are small: tapping down one creature, or draw 3 discard 1. Fine, but the other Rooms do much more for the same slot."),
 'Cruel Reality':(3,"A strong punisher curse."),
 'Polluted Cistern // Dim Oubliette':(2,"Self-mill without much payoff."),
 'Experimental Lab // Staff Room':(3,"Fine doors."),
 'Curse of Unbinding':(3,"Steals each upkeep."),
 'Cramped Vents // Access Maze':(4,"Removal plus a free-cast door."),
 'Bottomless Pool // Locker Room':(3,"Bounce plus draw."),
 'Secret Arcade // Dusty Parlor':(3,"Turns everything into enchantments for the enchantress engines.")},
'joel': {'Pawn of Ulamog':(2,"Only nontoken deaths make Spawn, and most of this deck's deaths are tokens."),
 'Thallid Soothsayer':(2,"2 mana per card is expensive when free sac outlets and better draw engines are in the deck."),
 'Eerie Gravestone':(2,"A slow cantrip artifact; fine but replaceable."),
 'Infested Thrinax':(3,"A 5-mana 4/4 whose Saproling trigger only counts nontoken deaths that turn; pricey for what it adds."),
 'Abby, Merciless Soldier':(3,"Gives an opponent a 4/4 to make your tokens; political, but that 4/4 often swings back at you."),
 'Venerated Stormsinger':(4,"Another drain payoff."),
 'Fatal Grudge':(3,"Edict effect."),
 'Vindictive Vampire':(4,"Drain payoff."),
 'Arnyn, Deathbloom Botanist':(3,"Drain on small deaths; overlaps the deck's better drain payoffs."),
 'Sifter of Skulls':(2,"Only nontoken deaths make Scions, and most of the deaths here are tokens."),
 'Psychotrope Thallid':(2,"Slow Saprolings and an expensive draw."),
 'Insidious Fungus':(3,"Flexible answer."),
 "Emrakul's Evangel":(3,"Sac outlet that makes Eldrazi.")},
'kotis': {'The Thirteenth Doctor':(2,'Its free-cast counters need Kotis to connect first, and untapping countered creatures rarely matters here.'),
 'Feral Invocation':(1,"+2/+2 with no evasion or card draw; the deck's other auras do the same job and draw or grant evasion."),
 'Baleful Eidolon':(2,"Deathtouch is low value on a voltron commander that wants evasion."),
 'Arcane Flight':(2,"Flying is good, but it's the weakest evasion aura in the list."),
 'Souvenir Snatcher':(3,"Flying mutate that steals."),
 'Dreamtail Heron':(3,"Flying mutate that draws."),
 'Grappling Hook':(4,"Double strike with Quietus Spike."),
 'Demonic Embrace':(3,"Flying and recursion."),
 'Dirge Bat':(4,"Flash removal."),
 'Audacity':(3,"Trample and card draw."),
 'Tower Winder':(2,"Finds Command Tower; a weak mana fix."),
 'Grisly Transformation':(2,"Intimidate is spotty evasion (artifact creatures and same-color creatures still block), so this is mostly a cantrip aura."),
 'Ivy, Gleeful Spellthief':(3,"Copies pump spells.")},
'mech': {'Exterminator Magmarch':(3,'A 5/3 that copies removal is nice, but the deck runs few removal spells to copy.'),
 'Workshop Assistant':(2,'A 1/2 that returns an artifact when it dies; a small body with a slow, conditional payoff.'),
 'Night Market Guard':(1,"A 3/1 for 3 that blocks two; it doesn't crew well, fly or draw, and it isn't really a robot payoff."),
 'Armored Transport':(1,"A 2/1 for 3 with a combat trick; it's crew fodder at best."),
 'Crackdown Construct':(2,"Grows only when you activate abilities, which this deck does little of.","Swap for Reckless Fireweaver: every artifact you play pings each opponent."),
 'Watchful Automaton':(1,"3 mana per scry 1 is a very weak ability on a small body."),
 'Golem Artisan':(3,"Gives an artifact creature evasion."),
 'Goliath Truck':(2,"A 4/4 vehicle that needs crew and only pumps one other attacker; the deck has stronger vehicles doing the same job."),
 'Mindlink Mech':(3,"Copies a creature's ability."),
 'Futurist Sentinel':(2,"A 6/6 vehicle with no ability; it needs crew 3 and adds nothing beyond its body."),
 'Treasure Keeper':(3,"Free spell on death."),
 'Malevolent Chandelier':(2,"A 6-mana 4/4 flier whose graveyard-tucking ability rarely matters; the deck has cheaper fliers via Cyberdrive Awakener."),
 'Scuttling Butler':(2,"A 4/1 that only gets double strike with two multicolored permanents out, which this deck rarely has.","Swap for Darksteel Plate: makes Eggman or a key Construct indestructible, the deck's weak spot."),
 "Tezzeret's Gatebreaker":(3,"Digs and finishes.")},
}

J['weather'] = {
 'Winter Blast':(2,"Taps X creatures for a turn and only hurts fliers; as a sorcery it clears blockers but can't stop an attack.","Swap for Blizzard Brawl: a 1-mana snow fight spell that also makes your creature indestructible, a real answer."),
 'Whiteout':(2,"Everyone loses flying for a turn: a narrow fog that also grounds your own Owl and Frostkite.","Swap for Ravenform: a snow sorcery that exiles a creature or artifact for good."),
 'Ride the Avalanche':(2,"Flash plus a few counters is cute, but it doesn't draw, remove or threaten anything.","Swap for Arcum's Astrolabe: a 1-mana snow cantrip that fixes all three colors and grows Isu."),
 'Frost Breath':(3,"Taps two creatures for a turn: decent tempo, but only a one-turn stall.","Swap for Swords to Plowshares: the deck has very few answers that remove a threat for good."),
 'Adarkar Windform':(2,"A 5-mana 3/3 flier whose flying-removal rarely matters.","Swap for Moritte of the Frost: a snow clone of your best creature with counters."),
 'Time of Ice':(3,"Locks two creatures for a couple of turns, then bounces tapped creatures; slow for 4 mana.","Swap for Cyclonic Rift: instant bounce early, a one-sided board reset late."),
 'Frozen Aether':(3,"Slows opponents a little but does nothing about what's already on the board.","Swap for Path to Exile or Swords to Plowshares; flag: this deck is low on permanent removal."),
 'Snow Devil':(2,"An aura that gives flying; a 2-for-1 waiting to happen if the creature dies.","Swap for Icehide Troll: a snow 2-drop that becomes an indestructible 4/3 with snow mana."),
 "Winter's Chill":(3,"Kills attackers only during combat, and they can pay 1 or 2 to save them.","Swap for Beast Within: instant, hits any permanent, and opponents can't pay their way out."),
 'Succumb to the Cold':(3,"Taps and stuns two creatures at instant speed: good tempo, still temporary.","Swap for Ravenform or Beast Within for a permanent answer."),
 'Heidar, Rimewind Master':(3,"Repeatable bounce is strong, but he's a 5-mana 3/3 that needs four snow permanents first.","Keep him and protect him: Training Grounds makes each bounce cost 1, so lead with it."),
 "Winter's Rest":(4,"A 2-mana lock on any creature, as long as you keep another snow permanent.","Keep."),
 'Radstorm':(2,"Proliferate with storm in a deck that rarely casts several spells a turn.","Swap for Blizzard Brawl or another cheap snow answer."),
 'Training Grounds':(3,"Discounts creature abilities: great with Avalanche Caller and Heidar, blank otherwise.","Swap for Birds of Paradise if you want the deck faster; keep if you lean on Caller and Heidar."),
 "Biomancer's Familiar":(3,"Same discount as Training Grounds on a 2/2 body; the adapt half does nothing here.","Swap for Birds of Paradise or Utopia Sprawl (a Forest aura) for real ramp."),
 'Icefall Regent':(4,"A flier that locks down a creature and taxes spells aimed at it.","Keep."),
}
J['blood'] = {
 'Blight Keeper':(2,"A 1-mana 1/1 flier whose drain costs 8 mana.","Swap for Patchwork Banner: name Bat for +1/+1 and an extra mana in a deck with a low mana score."),
 'Sonar Strike':(3,"Only hits attacking, blocking or tapped creatures.","Swap for Vanishing Verse: 2-mana instant exile for any monocolored permanent."),
 'Glidedive Duo':(2,"5 mana for a 3/3 flier and a 2-point drain.","Swap for Cliffhaven Vampire: a cheaper flier that pings on every life gain."),
 'Campaign of Vengeance':(3,"Great with a swarm of fliers, but a 5-mana enchantment that does nothing alone.","Swap for Exquisite Blood: with Sanguine Bond or Vito it ends the game."),
 'Gurmag Swiftwing':(2,"A 1/2 flier with first strike and haste; small for a card slot.","Swap for Vampire Nighthawk: flying, lifelink and deathtouch on a 2/3."),
 'Cast Down':(4,"Cheap instant creature removal; misses legends.","Keep."),
 'Momo, Rambunctious Rascal':(3,"A 1/1 flier whose 4 damage needs a tapped target.","Swap for Vanishing Verse or Infernal Grasp for removal that always works."),
 'Ruin-Lurker Bat':(3,"A 1-drop lifelink flier; descend rarely happens here.","Fine as a cheap Bat for Zoraline; swap for Fellwar Stone if you want more mana."),
 'Momo, Playful Pet':(3,"A 1/1 flying vigilance; small value when it leaves.","Swap for Talisman of Hierarchy: the deck's mana score is the lowest in the pod."),
 'Desecrated Tomb':(3,"Bats when creatures leave your graveyard; Zoraline and the recursion trigger it, but not often.","Swap for Bitterblossom: a flying token every turn and a life loss that turns on your Bats."),
 'Wax-Wane Witness':(2,"A 4-mana 2/4 flier that gets +1/+0 sometimes.","Swap for Twilight Prophet: a flier that drains and draws every upkeep."),
 'Moonrise Cleric':(3,"A 3-mana 2/3 flier that gains 1 on attack.","Swap for Arcane Signet-style ramp (Fellwar Stone) to fix the mana."),
 'Starfall Invocation':(4,"A wrath that can keep your best creature.","Keep."),
 'Epicure of Blood':(3,"A 5-mana 4/4 with no flying in a deck of fliers; the drain only adds 1 per life gain."),
 'Path of Bravery':(3,"The +1/+1 only works while you're at or above 40 life, which a life-swinging deck rarely stays at."),
 'Fracture':(3,"Can't touch creatures, the threats this deck fears most."),
 'Diresight':(3,"3 mana for two cards; fine, but slow next to the deck's engines."),
 "Hazel's Nocturne":(4,"Two creatures back plus a drain at instant speed."),
}
J['dragons'] = {
 'Destructor Dragon':(3,"A 6-mana 4/4 flier whose removal only happens when it dies.","Swap for Terror of the Peaks: every Dragon (and every Miirym copy) deals damage when it enters."),
 'Volcanic Dragon':(2,"A vanilla 4/4 flying haste for 6; every other Dragon here does more.","Swap for Goldspan Dragon: haste, Treasures on attack, and Miirym copies make two."),
 'Stingerback Terror':(2,"A 7/7 that shrinks by your hand size; with a full grip it's tiny.","Swap for Old Gnawbone: Treasures on every combat hit, doubled by Miirym."),
 'Shockmaw Dragon':(2,"6 mana for a 4/4 flier with a small ping on hit.","Swap for Herald's Horn: Dragons cost 1 less and you draw Dragons off the top."),
 'Draconic Muralists':(3,"A 4/3 ground body that finds a Dragon only when it dies.","Swap for Dragonlord's Servant: Dragons cost 1 less from turn 2."),
 'Hoarding Dragon':(3,"A 4/4 flier that sets aside an artifact you only get when it dies.","Swap for Cyclonic Rift; flag: the deck has few ways to handle someone else's big board."),
 'Forgestoker Dragon':(2,"A 6-mana 5/4 whose pings need it attacking and extra mana.","Swap for Terror of the Peaks or Scourge of Valkas."),
 'Jugan, the Rising Star':(3,"A 6-mana 5/5 flier; the counters only come when it dies.","Swap for Thundermaw Hellkite: its enter effect gets copied by Miirym."),
 'Juvenile Mist Dragon':(3,"A 4/3 flier that taps a creature per opponent for a turn.","Fine tempo; keep."),
 'Ancient Hellkite':(2,"7 mana for a 6/6 with a pinger that needs red mana while attacking.","Swap for Garruk's Uprising: draws a card for every 4+ power creature and gives the team trample."),
 'Stormbreath Dragon':(4,"A hasty 4/4 flier with protection from white.","Keep."),
 'Icefall Regent':(4,"A flier that locks down a creature.","Keep."),
}
J['korvold'] = {
 'Taste of Death':(3,"Everyone sacrifices three creatures, you too; fodder helps, but it can hit your engines.","Swap for Grave Pact: only your opponents lose creatures when yours die."),
 'Spawning Pit':(3,"A slow sacrifice outlet: two sacrifices make one 2/2.","Swap for Ashnod's Altar: every sacrifice is two mana and a Korvold draw."),
 'Outland Liberator // Frenzied Trapbreaker':(4,"A 2-drop that sacrifices to kill an artifact or enchantment.","Keep."),
 'Gluttonous Troll':(3,"Foods and a pump outlet; fine, but small for 4 mana.","Swap for Tireless Tracker: lands make Clues to sacrifice, and it grows."),
 'From Beyond':(3,"A Scion every upkeep is good fodder; the Eldrazi tutor finds nothing here.","Swap for Bitterblossom: a flying Faerie every turn for 2 mana."),
 'Caustic Caterpillar':(4,"A 1-drop that sacrifices to kill an artifact or enchantment.","Keep."),
 'Thrashing Brontodon':(4,"A 3/4 that sacrifices to kill an artifact or enchantment.","Keep."),
 'Vindictive Vampire':(4,"Pings each opponent when your creatures die.","Keep."),
 'Prossh, Skyraider of Kher':(3,"A second 6-drop; the Kobolds feed Korvold but come only once.","Swap for Phyrexian Altar: free sacrifices that make mana."),
 'Golden Egg':(3,"A Food that draws a card; filler.","Swap for Mind Stone: cheaper ramp you can still sacrifice to Korvold."),
 'Dig Up':(4,"A basic land early, a tutor late.","Keep."),
 'Fleshbag Marauder':(4,"An edict on a body you can sacrifice.","Keep."),
}

# Fix / upgrade ideas for the older decks' Needs Repair candidates (added 0.10.10)
IDEAS = {
'grim': {'Venomous Changeling': "Swap for Nature's Lore: the 7-to-12 drops want one more ramp spell more than another craft body.",
 'Incarnation Technique': "Swap for Reanimate or Animate Dead: 1-2 mana to put a fatty back, no milling luck.",
 "Silver Surfer, Galactus's Herald": "Keep it while Galactus is in the deck; if Galactus goes, swap it for Eternal Witness.",
 'Tempest Hart // Scan the Clouds': "Swap for Farseek: gets the big drops out a turn sooner.",
 'Scavenged Brawler': "Swap for Temur Ascendancy: haste for the whole team and a card for every big creature.",
 'Qarsi Revenant': "Swap for Violent Outburst: another 3-mana cascade that always finds the Throne.",
 'Indoraptor, the Perfect Hybrid': "Swap for Explosive Vegetation: two lands for the 7-drops.",
 'Symbiote Spider-Man': "Swap for Worldly Tutor: puts the exact fatty you need on top."},
'thing': {'Ultros, Obnoxious Octopus': "Swap for Swords to Plowshares: a 1-mana noncreature spell that grows The Thing and answers anything.",
 'Thundertrap Trainer': "Swap for Ponder: a 1-mana noncreature spell that feeds The Thing and digs.",
 'Echo, Perceptive Prodigy': "Swap for Lightning Greaves: keeps The Thing safe and hasty the turn he lands.",
 'Search for Glory': "Swap for Worldly Tutor: 1 mana, instant, finds The Thing or any creature.",
 'Mega Flare': "Swap for Beast Within: an answer that works without The Thing out.",
 'Gogo, Master of Mimicry': "Swap for Heroic Intervention: protects The Thing's counters from a wipe."},
'kykar': {'Salvager of Secrets': "Swap for Archmage Emeritus: draws a card on every instant or sorcery.",
 'Befuddle': "Swap for Swords to Plowshares; flag: the deck has almost no way to remove a creature already out.",
 'Micromancer': "Swap for Path to Exile, for the same reason: real creature removal.",
 'Erratic Cyclops': "Swap for Murmuring Mystic: a 1/5 wall that makes a flying Bird on every instant or sorcery.",
 'Startle': "Swap for Crimson Wisps: a 1-mana single-target cantrip (+1/+0 and haste); aimed at Zada it copies to every creature, so the whole team gets haste and you draw a card for each one.",
 'Ral, Storm Conduit': "Swap for Storm-Kiln Artist: a Treasure on every spell helps the low mana score."},
'mathas': {"Knight of Dusk's Shadow": "Swap for Vanishing Verse: 2-mana instant exile.",
 'Termination Facilitator': "Swap for Anguished Unmaking: exiles anything right away, and paying life fits the deck.",
 'Tallyman of Nurgle': "Swap for Mind Stone: cheap ramp that cashes in for a card later.",
 'Mystic Barrier': "Keep: it steers attacks away and fits the pillowfort plan.",
 "Curse of Fool's Wisdom": "Swap for Windborn Muse: a flier that taxes every attack aimed at you.",
 'Condemn': "Swap for Vanishing Verse or Path to Exile for removal that works on any turn."},
'marina': {'Curse of Thirst': "Swap for Curse of Opulence: you get Gold whenever someone attacks the cursed player.",
 'Ritual of Soot': "Swap for Austere Command: a wipe that also hits the big threats.",
 "Curse of Death's Hold": "Swap for Sigil of the Empty Throne: a 4/4 flying Angel for every enchantment you cast.",
 'Polluted Cistern // Dim Oubliette': "Swap for Setessan Champion: a counter and a card for every enchantment.",
 'Meat Locker // Drowned Diner': "Swap for Mesa Enchantress: draws on every enchantment."},
'joel': {'Eerie Gravestone': "Swap for Skullclamp: every token death draws two.",
 'Thallid Soothsayer': "Swap for Pitiless Plunderer: deaths make Treasure, which helps the mana.",
 'Sifter of Skulls': "Swap for Grave Pact: every death makes each opponent sacrifice.",
 'Abby, Merciless Soldier': "Swap for Bitterblossom: a flying token every turn without handing anyone a 4/4.",
 'Fatal Grudge': "Swap for Infernal Grasp: instant removal that kills anything."},
'turtle': {'Roadkill Rodney': "Swap for Anointed Procession: doubles every token.",
 'Game Over': "Swap for Heroic Intervention: protects the token army instead of killing it.",
 'Arcade Cabinet': "Swap for Parallel Lives: doubles every token.",
 'Kibo, Uktabi Prince': "Swap for Cathars' Crusade: every token grows the whole team.",
 'Donatello, the Brains': "Swap for Swords to Plowshares; flag: the deck is light on removal."},
'kotis': {'Feral Invocation': "Swap for Shadowspear: trample, lifelink, and it strips hexproof.",
 'Baleful Eidolon': "Swap for Lightning Greaves: keeps Kotis safe and hasty.",
 'Arcane Flight': "Swap for Bear Umbra: +2/+2, untaps your lands, and saves Kotis once.",
 'Tower Winder': "Swap for Talisman of Curiosity, or just a spare Forest or Island.",
 'Grisly Transformation': "Swap for Whispersilk Cloak: unblockable and shroud."},
'mech': {'Armored Transport': "Swap for Sai, Master Thopterist: a flier on every artifact you cast.",
 'Night Market Guard': "Swap for Infernal Grasp; flag: the deck is light on removal.",
 'Watchful Automaton': "Swap for Thought Monitor: an artifact Construct that draws two.",
 'Goliath Truck': "Swap for Lightning Greaves: keeps Dr. Eggman on the table.",
 'Futurist Sentinel': "Swap for Myr Battlesphere: a 4/7 Construct that brings four Myr and attacks for a lot."},
}
for _k, _d in IDEAS.items():
    for _n, _i in _d.items():
        if _n in J.get(_k, {}) and len(J[_k][_n]) == 2:
            J[_k][_n] = J[_k][_n] + (_i,)

J['robots'] = {
 'Vision, Spectral Synthezoid':(3,"8 mana for a 2/5 flier; the free spell every turn is strong, but only if it lives.","Swap for Wurmcoil Engine: a 6/6 robot wurm that splits into two more robots when it dies."),
 'Suspend Aggression':(3,"Exiles anything at instant speed, but its owner can recast it next turn.","Swap for Chaos Warp; flag: removal is low (six cards)."),
 'Vulshok Factory':(3,"A slow rock: the Golem needs many turns of charging to be big.","Swap for Mind Stone: cheaper ramp that cashes in for a card."),
 'Donatello, Mutant Mechanic':(3,"Turns a Talisman or rock into a 3/3 Robot each turn, but only at sorcery speed.","Swap for March of the Machines: every noncreature artifact becomes a Robot at once."),
 'Bosh, Iron Golem':(3,"8 mana; flinging artifacts is strong but slow.","Swap for Myr Battlesphere: 7 mana, four Myr robots and a huge attack."),
 "Mm'menon, Uthros Exile":(4,"Leon's jellyfish: a +1/+1 counter for every artifact that enters.","Keep (it's the jellyfish)."),
 'Scarecrone':(4,"Recursion: brings back an artifact creature every turn.","Keep (recursion)."),
 'Scuttling Doom Engine':(3,"A 6/6 for 6 that hits for 6 when it dies; solid but plain.","Swap for Hangarback Walker: a cheap robot that grows and turns into flying Thopters."),
 'The Vision':(4,"A flying engine that draws or protects itself on every noncreature spell.","Keep."),
 'Canoptek Wraith':(4,"An unblockable robot that fetches two lands.","Keep."),
 "Jhoira's Familiar":(4,"A 4-mana flier that makes artifacts and legends cost 1 less.","Swap for Mind Stone if you want the mana sooner."),
 'Vedalken Engineer':(3,"Not a robot, but 2 mana a turn for artifacts.","Keep for the ramp count."),
 'Krang, the All-Powerful':(4,"Doubles every draw trigger (Fateful Discovery, Jhoira, Canoptek Spyder).","Keep."),
}
J['robots'].update({
 'Promise of Loyalty':(3,"A symmetric wipe in a deck that wants a wide board; best when you keep a huge robot and the others can't attack you with theirs.","Keep as the only wipe; cast it with Kappa Cannoneer or a big Iron Man out."),
 'Insight Engine':(3,"Slow at first, but every activation draws one more card than the last.","Keep; start it early so it's drawing three or four a turn by the late game."),
 'Etherium Sculptor':(4,"Every artifact costs 1 less.","Keep."),
 'Iron Lad, Diverging Destiny':(4,"A flier that draws artifacts off the top.","Keep."),
 'Thopter Shop':(4,"Draws when artifact creatures die and makes flying Thopters.","Keep."),
})


J['felothar'] = {
 'Covetous Elegy':(2,"Everyone keeps two creatures, you included: this deck wants a wide wall of 0-power defenders, and Slaughter the Strong / Destined Confrontation already wipe while keeping all of them.","Swap for Assassin's Trophy: a 2-mana instant that answers anything."),
 'Spike Weaver':(3,"Three fogs on a 0/0 body; good defense, but it isn't a wall and adds nothing to the toughness attack plan.","Swap for Assault Formation: a backup Felothar (damage by toughness, defenders can attack) for 2 mana."),
 'Naga Vitalist':(3,"A plain 2-mana dork with only 2 toughness; it does nothing once Felothar turns toughness into damage.","Swap for Wall of Roots: mana, a 0/5 defender, and 5 damage under Felothar."),
 'Viridian Emissary':(3,"A 2/1 that only pays off when it dies; low toughness, so it's a weak attacker here.","Swap for Sakura-Tribe Elder: sacrifices for a land whenever you like (even mid-combat after blocking)."),
 "Martyr's Bond":(3,"6 mana for a deterrent that only fires when your stuff dies; slow as removal.","Swap for Anguished Unmaking: 3-mana instant exile for anything."),
 'Wall of Mourning':(3,"The exiled cards only come back with three different powers, and most of your walls are 0 power.","Swap for Tree of Perdition: a 0/13 defender that hits for 13 under Felothar, or swaps an opponent's life to 13."),
 'Destined Confrontation':(4,"A one-sided wipe here: your 0-power walls all stay."),
 'Wave of Reckoning':(4,"Every creature hits itself for its power: your walls take nothing."),
 'Finale of Eternity':(4,"Flexible removal early, full reanimation late."),
 'Bushmeat Poacher':(4,"Sac outlet that turns big toughness into life and a card."),
}
J['thranduil'] = {
 'Tajuru Preserver':(2,"Only stops edicts and forced sacrifices; doesn't help against wipes or targeted removal, the real threats to an Elf board.","Swap for Heroic Intervention: hexproof and indestructible for every Elf at instant speed."),
 'Biovisionary':(2,"Needs four copies in play; the deck's copy spells are better spent on Thranduil or an Elf lord.","Swap for Elvish Warmaster: an Elf token whenever Elves enter, and a team pump late."),
 'Trystan, Callous Cultivator // Trystan, Penitent Culler':(3,"Mill 3 and 2 life is small value for a 3-drop.","Swap for Ezuri, Renegade Leader: regenerates Elves and overruns the table."),
 'Nath of the Gilt-Leaf':(3,"5 mana for a random discard each turn; slow and doesn't stop what's on the board.","Swap for Beast Within: answers anything for 3 at instant speed."),
 'Nullmage Shepherd':(3,"Needs four creatures tapped to fire, which competes with your mana dorks.","Swap for Assassin's Trophy: 2-mana instant answer to any permanent."),
 "Moment's Peace":(3,"Fogs buy time, but this deck wants to be the one attacking; a wipe is the bigger threat.","Swap for Arcane Denial: counters the wipe that would kill your Elves."),
 'Greenseeker':(3,"Discarding cards to find basics is slow for a 1/1.","Swap for Elvish Harbinger: finds an Elf and taps for any color."),
 'Altar of Dementia':(3,"Milling isn't this deck's way to win; as a free sac outlet it's okay.","Swap for Ashnod's Altar: same free sacrifice, but makes 2 mana for Voice of the Woods and big X spells."),
 'Elrond of the White Council':(4,"The vote steals creatures or pumps your team: good either way."),
 'Greenweaver Druid':(4,"Two mana for a two-mana dork; fine."),
}
J['vile'] = {
 'Capital Punishment':(3,"Opponents choose how to pay, so they'll give up their least useful cards.","Swap for Anguished Unmaking: exile your choice of permanent for 3."),
 'Hearthborn Battler':(2,"2 damage only on second spells; a small body for a small effect.","Swap for Kederekt Parasite: every card an opponent draws pings them, so each wheel is 7 damage each."),
 'Byway Barterer':(3,"A wheel-for-two on a 3/3; small next to the deck's real wheels.","Swap for Sheoldred, the Apocalypse: every card they draw costs them 2, every card you draw gains you 2."),
 'Dusk Mangler':(3,"7 mana (plus an extra cost) for a one-shot edict and drain.","Swap for Underworld Dreams: each opponent loses 1 per card drawn, so a wheel is 7 each."),
 'Echo, Perceptive Prodigy':(2,"Needs a creature trigger to copy; alone it's a 1/4.","Swap for Notion Thief: steals the extra cards opponents draw off your wheels."),
 'World Map':(3,"Finds a land, doesn't make mana; slow for a 4-color deck full of 6-drops.","Swap for Talisman of Indulgence: a real 2-mana rock in your colors."),
 'Misty Knight, Hero for Hire':(3,"A rummage on a 3/1 body.","Swap for Smothering Tithe: a Treasure every time an opponent draws (wheels make tons)."),
 'Voracious Fell Beast':(4,"An edict for every opponent on a flier."),
}
J['depala'] = {
 'Toolcraft Exemplar':(2,"A 1/1 that's only a 3/2 on your turn; small Dwarf, early drop only.","Swap for Lightning Greaves: keeps Depala safe and gives fresh Dwarves haste to crew right away."),
 'Fearless Skald':(2,"5 mana for a 3/2 plus one backup counter.","Swap for Hofri Ghostforge: your Dwarves that die come back as Spirits to keep crewing and attacking."),
 'Rover Blades':(3,"Equip 4 for double strike is pricey; as a vehicle it's a 2/2.","Swap for Sword of the Animist: a land every time the equipped creature attacks."),
 'Air Response Unit':(3,"A 3/3 flier vehicle; fine filler but no extra value.","Swap for Smuggler's Copter: crew 1 flier that loots every attack and block."),
 'Shattered Acolyte':(3,"Artifact/enchantment removal on a 2/2; narrow.","Swap for Swords to Plowshares: 1-mana instant exile for the creature that matters."),
 "Conqueror's Galleon // Conqueror's Foothold":(3,"Crew 4 for a 2/10 that turns into a land after one attack.","Swap for Weatherlight: a crew 3 flier that digs for artifacts and legends every hit."),
 'Pre-War Formalwear':(4,"Reanimates a 3-drop Dwarf and suits it up."),
 'Prismatic Strands':(4,"Fog with free flashback; saves the team from a combat or burn wipe."),
}

# 0.10.16 Needs Repair: two replacement picks per card (budget, any cost). Colors checked against the commander's identity.
FIX2 = {
'grim': {
 'Venomous Changeling': ("Nature's Lore: instant-speed Forest fetch that gets the 7-to-12 drops out a turn sooner.", "Natural Order: sacrifice a green creature and put Ghalta-sized fatties straight into play."),
 'Incarnation Technique': ("Dread Return: reanimate any fatty for 4, and flash it back later off a sacrifice.", "Reanimate: 1 mana to put the best creature in any graveyard into play."),
 'Tempest Hart // Scan the Clouds': ("Farseek: a 2-mana land that can grab any of your typed duals.", "Three Visits: an untapped dual from your library for 2."),
 "Silver Surfer, Galactus's Herald": ("Eternal Witness: gets back a fatty or removal spell and blocks while you set up.", "Sneak Attack: drop a fatty with haste for one red mana, every turn."),
 'Scavenged Brawler': ("Temur Ascendancy: haste for the whole team and a card for every big creature.", "Ilharg, the Raze-Boar: puts a fatty from your hand onto the battlefield attacking every turn."),
},
'felothar': {
 'Covetous Elegy': ("Assassin's Trophy: a 2-mana instant that answers anything.", "Toxic Deluge: pay 3 or 4 life and their small creatures die while your 5-toughness walls stay."),
 'Spike Weaver': ("Assault Formation: a backup Felothar (damage by toughness, defenders can attack).", "Doran, the Siege Tower: the original toughness-damage card for every creature on the table."),
 'Naga Vitalist': ("Wall of Roots: mana, a 0/5 defender, and 5 damage under Felothar.", "Birds of Paradise: any color on turn 1 and a flier to carry Captain America's Shield."),
 'Viridian Emissary': ("Sakura-Tribe Elder: blocks, then sacrifices for a land at instant speed.", "Nature's Lore: an untapped land fetch at instant speed."),
 "Martyr's Bond": ("Anguished Unmaking: 3-mana instant exile for anything.", "Vindicate: 3 mana, destroy any permanent, lands included."),
},
'vile': {
 'Hearthborn Battler': ("Kederekt Parasite: every card an opponent draws pings them, so each wheel is 7 damage each.", "Orcish Bowmasters: pings and makes Orcs every time an opponent draws extra, so every wheel is a pile of damage."),
 'Echo, Perceptive Prodigy': ("Spiteful Visions: everyone draws an extra card and every draw pings, a second Nekusar.", "Notion Thief: steals the seven-card refills your opponents get off your wheels."),
 'Capital Punishment': ("Anguished Unmaking: exile your choice of permanent for 3.", "Toxic Deluge: a 3-mana wipe that kills anything with toughness X or less."),
 'Byway Barterer': ("Waste Not: every discard from your wheels makes Zombies, mana or cards.", "Sheoldred, the Apocalypse: every card they draw costs them 2, every card you draw gains you 2."),
 'Dusk Mangler': ("Underworld Dreams: each opponent loses 1 per card drawn, so a wheel is 7 each.", "Smothering Tithe: a Treasure every time an opponent draws (wheels make a pile)."),
},
'thing': {
 'Ultros, Obnoxious Octopus': ("Swords to Plowshares: a 1-mana noncreature spell that grows The Thing and answers anything.", "Cyclonic Rift: a 2-mana spell for The Thing early, a one-sided board reset late."),
 'Thundertrap Trainer': ("Ponder: a 1-mana noncreature spell that feeds The Thing and digs.", "Mystic Remora: 1 mana, feeds The Thing and draws off every noncreature spell they cast."),
 'Echo, Perceptive Prodigy': ("Lightning Greaves: keeps The Thing safe and hasty the turn he lands.", "Heroic Intervention: an instant noncreature spell that saves your board from a wipe."),
 'Search for Glory': ("Eladamri's Call: instant, finds The Thing or any creature for 2.", "Worldly Tutor: 1 mana, instant, puts The Thing on top."),
 'Mega Flare': ("Beast Within: an answer that works without The Thing out.", "Fierce Guardianship: free counterspell whenever The Thing is out."),
},
'dragons': {
 'Stingerback Terror': ("Hellkite Charger: a hasty flier that buys extra combats with spare mana.", "Old Gnawbone: Treasures on every combat hit, doubled by Miirym."),
 'Shockmaw Dragon': ("Herald's Horn: Dragons cost 1 less and you draw Dragons off the top.", "Urza's Incubator: every Dragon costs 2 less."),
 'Volcanic Dragon': ("Thunderbreak Regent: a 4-mana Dragon that punishes anyone targeting your Dragons.", "Goldspan Dragon: haste, Treasures on attack, and Miirym copies make two."),
 'Forgestoker Dragon': ("Scourge of Valkas: every Dragon (and copy) entering deals damage.", "Terror of the Peaks: every Dragon (and copy) entering deals its power as damage."),
 'Destructor Dragon': ("Dragonlord's Servant: every Dragon costs 1 less, for 2 mana.", "Ancient Copper Dragon: a pile of Treasures on every hit, and Miirym's copy rolls again."),
},
'depala': {
 'Toolcraft Exemplar': ("Swiftfoot Boots: keeps Depala safe and gives fresh Dwarves haste to crew right away.", "Puresteel Paladin: equips cost 0 with three artifacts and every Equipment draws a card."),
 'Fearless Skald': ("Hofri Ghostforge: your Dwarves that die come back as Spirits to keep crewing and attacking.", "Embercleave: flash, double strike and trample on the creature that matters, often for 2-3 mana."),
 'Air Response Unit': ("Smuggler's Copter: crew 1 flier that loots every attack and block.", "Sword of Fire and Ice: protection, damage and a card on every hit."),
 "Conqueror's Galleon // Conqueror's Foothold": ("Weatherlight: a crew 3 flier that digs for artifacts and legends every hit.", "Sword of Feast and Famine: untaps your lands and makes them discard on every hit."),
 'Shattered Acolyte': ("Swords to Plowshares: 1-mana instant exile for the creature that matters.", "Austere Command: a wipe you pick (keep your artifacts, kill their creatures)."),
},
'kykar': {
 'Salvager of Secrets': ("Archmage Emeritus: draws a card on every instant or sorcery.", "Rhystic Study: draws off every spell your opponents cast."),
 'Befuddle': ("Swords to Plowshares: real creature removal for 1.", "Cyclonic Rift: bounce one thing, or everything they have."),
 'Micromancer': ("Path to Exile: real creature removal for 1.", "Brazen Borrower: an instant bounce, then a flash flier."),
 'Startle': ("Crimson Wisps: a 1-mana single-target cantrip (+1/+0 and haste); aimed at Zada it copies to every creature.", "Expressive Iteration: 2 mana, look at three, keep and play two."),
 "River Song's Diary": ("Opt: a 1-mana instant cantrip that triggers Kykar.", "Mystic Remora: draws off every noncreature spell they cast, and triggers Kykar."),
},
'mathas': {
 "Knight of Dusk's Shadow": ("Despark: 2-mana instant exile for anything big.", "Vanishing Verse: 2-mana instant exile for any monocolored permanent."),
 'Termination Facilitator': ("Anguished Unmaking: exiles anything right away, and paying life fits the deck.", "Vindicate: destroys any permanent for 3."),
 'Tallyman of Nurgle': ("Mind Stone: cheap ramp that cashes in for a card later.", "Smothering Tithe: Treasure every time an opponent draws."),
 "Curse of Fool's Wisdom": ("Windborn Muse: a flier that taxes every attack aimed at you.", "Archangel of Tithes: taxes both their attacks and their blocks."),
 'Mystic Barrier': ("Crawlspace: no more than two creatures can attack you each combat.", "Teferi's Protection: phase out and take nothing for a full turn cycle."),
},
'kotis': {
 'Feral Invocation': ("Sword of Vengeance: +2/+0, first strike, vigilance, trample and haste on Kotis.", "Shadowspear: trample, lifelink, and it strips hexproof."),
 'Baleful Eidolon': ("Swiftfoot Boots: keeps Kotis safe and hasty.", "Lightning Greaves: equip 0, so Kotis is never unprotected."),
 'Arcane Flight': ("Bear Umbra: +2/+2, untaps your lands, and saves Kotis once.", "Sword of Feast and Famine: untaps your lands and makes them discard on every hit."),
 'Grisly Transformation': ("Whispersilk Cloak: unblockable and shroud.", "Sword of Fire and Ice: protection, damage and a card on every hit."),
 'Tower Winder': ("Talisman of Curiosity: a 2-mana rock in your colors.", "Birds of Paradise: any color on turn 1."),
},
'turtle': {
 'Roadkill Rodney': ("Intangible Virtue: every token +1/+1 and vigilance for 2.", "Anointed Procession: doubles every token."),
 'Arcade Cabinet': ("Secure the Wastes: an instant pile of tokens at end of turn.", "Parallel Lives: doubles every token."),
 'Game Over': ("Flawless Maneuver: free with your commander out; the whole army survives a wipe.", "Teferi's Protection: phase out and keep everything for a turn."),
 'Kibo, Uktabi Prince': ("Cathars' Crusade: every token grows the whole team.", "Craterhoof Behemoth: the army gets +X/+X and trample to end the game."),
 'Donatello, the Brains': ("Swords to Plowshares: 1-mana removal for a deck light on it.", "Cyclonic Rift: bounce one thing, or everything they have."),
},
'thranduil': {
 'Tajuru Preserver': ("Heroic Intervention: hexproof and indestructible for every Elf at instant speed.", "Fierce Guardianship: free counterspell for the wipe while Thranduil is out."),
 'Biovisionary': ("Elvish Warmaster: an Elf token whenever Elves enter, and a team pump late.", "Glimpse of Nature: draw a card for every creature you cast that turn."),
 'Trystan, Callous Cultivator // Trystan, Penitent Culler': ("Ezuri, Renegade Leader: regenerates Elves and overruns the table.", "Craterhoof Behemoth: every Elf gets huge with trample."),
 'Nath of the Gilt-Leaf': ("Beast Within: answers anything for 3 at instant speed.", "Cyclonic Rift: bounce one thing, or everything they have."),
 'Nullmage Shepherd': ("Assassin's Trophy: 2-mana instant answer to any permanent.", "Force of Vigor: free, kills two artifacts or enchantments on their turn."),
},
'joel': {
 'Eerie Gravestone': ("Midnight Reaper: a card every time a nontoken creature dies.", "Skullclamp: every token death draws two."),
 'Thallid Soothsayer': ("Pitiless Plunderer: deaths make Treasure, which helps the mana.", "Mayhem Devil: every sacrifice (Treasures too) pings anything."),
 'Sifter of Skulls': ("Butcher of Malakir: each of your deaths makes every opponent sacrifice.", "Grave Pact: every death makes each opponent sacrifice."),
 'Abby, Merciless Soldier': ("Ophiomancer: a deathtouch Snake to sacrifice every upkeep.", "Bitterblossom: a flying token every turn without handing anyone a 4/4."),
 'Fatal Grudge': ("Infernal Grasp: instant removal that kills anything.", "Deadly Rollick: free with your commander out, exiles any creature."),
},
'korvold': {
 'Taste of Death': ("Liliana's Triumph: a 2-mana edict for every opponent.", "Grave Pact: only your opponents lose creatures when yours die."),
 'Spawning Pit': ("Yahenni, Undying Partisan: a free sacrifice outlet that grows and turns indestructible.", "Phyrexian Altar: every sacrifice is a mana of any color and a Korvold draw."),
 'From Beyond': ("Tendershoot Dryad: a Saproling every upkeep, all fodder for Korvold.", "Bitterblossom: a flying Faerie every turn for 2 mana."),
 'Gluttonous Troll': ("Tireless Tracker: lands make Clues to sacrifice, and it grows.", "The Meathook Massacre: a scalable wipe, then every creature death drains."),
 'Golden Egg': ("Mind Stone: cheaper ramp you can still sacrifice to Korvold.", "Mana Vault: three mana on turn 1-2, then sacrifice it to Korvold."),
},
'robots': {
 'Suspend Aggression': ("Chaos Warp: removal for anything, flag: removal is low (six cards).", "Cyclonic Rift: bounce one thing, or everything they have."),
 'Donatello, Mutant Mechanic': ("March of the Machines: every noncreature artifact becomes a Robot at once.", "Wurmcoil Engine: a 6/6 robot wurm that splits into two more when it dies."),
 'Bosh, Iron Golem': ("Myr Battlesphere: 7 mana, four Myr robots and a huge attack.", "Steel Hellkite: a flying robot dragon that wipes out their cheap permanents."),
 'Scuttling Doom Engine': ("Hangarback Walker: a cheap robot that grows and turns into flying Thopters.", "Walking Ballista: a robot that grows with spare mana and shoots anything."),
 'Vedalken Engineer': ("Mind Stone: cheap ramp that draws a card later.", "Thran Dynamo: three colorless mana every turn for artifacts."),
},
'marina': {
 'Curse of Thirst': ("Curse of Opulence: you get Gold whenever someone attacks the cursed player.", "Sythis, Harvest's Hand: a card and a life for every enchantment you cast."),
 'Ritual of Soot': ("Hour of Revelation: a cheap wipe of everything except lands.", "Farewell: pick what to wipe (creatures, artifacts, graveyards) and keep your enchantments."),
 "Curse of Death's Hold": ("Sigil of the Empty Throne: a 4/4 flying Angel for every enchantment you cast.", "Archon of Sun's Grace: a flying Pegasus for every enchantment entering."),
 'Polluted Cistern // Dim Oubliette': ("Setessan Champion: a counter and a card for every enchantment.", "Sterling Grove: tutors an enchantment and protects the rest."),
 'Meat Locker // Drowned Diner': ("Mesa Enchantress: draws on every enchantment.", "Argothian Enchantress: shroud and a card for every enchantment."),
},
'blood': {
 'Campaign of Vengeance': ("Bastion of Remembrance: a drain whenever any of your creatures dies, for 3.", "Sorin, Vengeful Bloodlord: lifelink for your whole team on your turn and reanimation."),
 'Epicure of Blood': ("Cliffhaven Vampire: a cheap flier that drains on every life gain.", "Bloodletter of Aclazotz: a flier that doubles the life your opponents lose on your turn."),
 'Path of Bravery': ("Inspiring Overseer: a 3-mana flier that gains life and draws a card.", "Righteous Valkyrie: an Angel that gains life whenever another creature enters and pumps the team."),
 'Fracture': ("Infernal Grasp: instant removal for the creature that matters.", "Vindicate: destroys any permanent for 3."),
 'Diresight': ("Night's Whisper: two cards for 2 mana.", "Phyrexian Arena: an extra card every turn for the rest of the game."),
 'Blight Keeper': ("Patchwork Banner: name Bat for +1/+1 and an extra mana in a deck with a low mana score.", "Smothering Tithe: Treasure every time an opponent draws."),
 'Gurmag Swiftwing': ("Vampire Nighthawk: flying, lifelink and deathtouch on a 2/3.", "Exquisite Blood: every point they lose, you gain (and Vito turns it back on them)."),
 'Glidedive Duo': ("Cliffhaven Vampire: a cheaper flier that pings on every life gain.", "Bloodletter of Aclazotz: doubles the life your opponents lose on your turn."),
 'Sonar Strike': ("Infernal Grasp: instant removal that kills anything.", "Vanishing Verse: 2-mana instant exile for any monocolored permanent."),
 'Wax-Wane Witness': ("Twilight Prophet: a flier that drains and draws every upkeep.", "Bolas's Citadel: play off the top paying life, and gain it right back."),
},
'mech': {
 'Armored Transport': ("Sai, Master Thopterist: a flier on every artifact you cast.", "Urza, Lord High Artificer: taps your artifacts for mana and makes a Construct."),
 'Night Market Guard': ("Infernal Grasp: instant removal; flag: the deck is light on removal.", "Cyclonic Rift: bounce one thing, or everything they have."),
 'Watchful Automaton': ("Thought Monitor: an artifact Construct that draws two.", "The One Ring: protection for a turn and a growing pile of cards."),
 'Scuttling Butler': ("Darksteel Plate: makes Eggman or a key Construct indestructible.", "Fierce Guardianship: free counterspell to protect Eggman."),
 'Crackdown Construct': ("Reckless Fireweaver: every artifact you play pings each opponent.", "Wurmcoil Engine: a 6/6 Construct-sized robot that splits when it dies."),
},
'weather': {
 'Winter Blast': ("Blizzard Brawl: a 1-mana snow fight spell that also makes your creature indestructible.", "Cyclonic Rift: bounce one thing, or everything they have."),
 'Whiteout': ("Ravenform: a snow sorcery that exiles a creature or artifact for good.", "Austere Command: a wipe you choose (keep your big snow creatures)."),
 'Ride the Avalanche': ("Arcum's Astrolabe: a 1-mana snow cantrip that fixes all three colors and grows Isu.", "Sylvan Library: pick the best card of the top three every turn."),
 'Snow Devil': ("Icehide Troll: a snow 2-drop that becomes an indestructible 4/3 with snow mana.", "Sword of Fire and Ice: protection, damage and a card on every hit."),
 'Adarkar Windform': ("Moritte of the Frost: a snow clone of your best creature with counters.", "Esika's Chariot: two 2/2 Cats and a vehicle that copies a token every attack."),
},
}

# ---- 0.12.0: new decks and swaps (Nov 4, 2026) ----
J['robots'].update({
 "Saheeli's Artistry":(3,"6 mana sorcery for two copies; fine, but slow next to the deck's cheaper copy engines (Ultron, Mendicant Core)."),
 'Planetary Annihilation':(2,"Kills your own robots and lands too; a robot deck rarely wants a symmetric 6-damage wipe."),
})
FIX2.setdefault('robots', {}).update({
 "Saheeli's Artistry": ("Mirage Mirror: copy your best artifact or creature every turn for 2.", "Brudiclad, Telchor Engineer: every combat turns your tokens into copies of your best one."),
 'Planetary Annihilation': ("Swords to Plowshares: 1-mana exile that only hits what you aim at.", "Farewell: choose artifacts or creatures and keep your own side."),
})
J['mothman'] = {
 "Embalmer's Tools":(3,"A slow mill outlet; Altar of the Brood and Sidisi already mill more without tapping Zombies."),
 'Krosan Restorer':(3,"Untaps one land (three with threshold); weak ramp next to Cultivate-style cards."),
 'Havengul Runebinder':(3,"5 mana total per Zombie and it eats your graveyard creature that Scarab God wants."),
 'Llanowar Dead':(3,"A 2-drop dork that only makes black."),
 'Vengeful Dead':(3,"1 drain per Zombie death on a 3/2; small for a 4-drop."),
 'Grim Flowering':(3,"6 mana sorcery draw that depends on creature cards in the graveyard."),
}
FIX2['mothman'] = {
 "Embalmer's Tools": ("Stitcher's Supplier: mill 3 on the way in and out for one mana.", "Syr Konrad, the Grim: mill on demand and every creature hitting a graveyard pings each opponent."),
 'Krosan Restorer': ("Farhaven Elf: a basic onto the battlefield on a body.", "Three Visits: an untapped Forest dual for 2 at instant speed."),
 'Havengul Runebinder': ("Lord of the Accursed: Zombies +1/+1 and an activated team menace.", "Wilhelt, the Rotcleaver: Zombies dying make decayed Zombies and draw."),
 'Llanowar Dead': ("Birds of Paradise: any color in a 3-color deck.", "Deathrite Shaman: mana, graveyard hate and drain on a 1-drop."),
 'Vengeful Dead': ("Cemetery Reaper: makes Zombies from any creature card in a graveyard.", "Undead Warchief: Zombies cost 1 less and get +2/+1."),
 'Grim Flowering': ("Rishkar's Expertise: draw equal to your biggest creature's power and cast a free card.", "Rhystic Study: a card every time an opponent doesn't pay 1."),
}
J['casino'] = {
 'Grave Endeavor':(3,"7 mana instant; strong roll, but the deck has cheaper ways to get bodies back."),
 'Revivify':(3,"Only works on a turn your creatures died; often just returns cards to hand."),
 'Phyrexian Scriptures':(3,"Kills your nonartifact creatures too; Robots survive, Dragons don't."),
 'Treasure Chest':(3,"7 mana total for a random roll; 1 in 20 you lose 3 life."),
 'Danse Macabre':(3,"Everyone sacrifices first; you only win if your roll is high."),
 'Collector\'s Vault':(3,"2 mana a turn for a loot and one Treasure; slow."),
}
FIX2['casino'] = {
 'Grave Endeavor': ("Unearth: a free 3-drop back from the graveyard for 1 (cycles late).", "Dance of the Dead... no: Feed the Swarm budget; Teneb, the Harvester big"),
 'Revivify': ("Bastion of Remembrance: every creature death drains each opponent.", "Teferi's Protection: the whole board and life total safe for a turn."),
 'Phyrexian Scriptures': ("Wrath of the Skies: X wipe of artifacts/creatures/enchantments by MV; Robots tokens are MV 0.", "Austere Command: pick the halves, keep your artifacts."),
 'Treasure Chest': ("Hit the Mother Lode: dig a free spell and get Treasure for the difference.", "Pitiless Plunderer's partner Smothering Tithe: a Treasure every time an opponent draws."),
 'Danse Macabre': ("Feed the Swarm: kill a creature or enchantment for 2.", "Anguished Unmaking: instant exile anything."),
 'Collector\'s Vault': ("Mind Stone: a rock that cashes in for a card.", "Smothering Tithe: a Treasure every time an opponent draws."),
}
FIX2['casino']['Grave Endeavor'] = ("Unearth: return a 3-drop for 1 (or cycle it late).", "Teneb, the Harvester: an 6/6 flier that reanimates on every hit.")
J['scare'] = {
 'Equilibrium Adept':(2,"A 2/4 that impulses one card; it doesn't grow or mutate into anything."),
 'Picnic Ruiner // Stolen Goodies':(3,"A 2/2 for 2 that needs a big creature out; the adventure is the better half."),
 'Markov Blademaster':(3,"A 1/1 double striker; small in a deck of 6/6s."),
 'Medusa, Inhuman Queen':(3,"Grows only on noncreature spells; this deck is mostly creatures."),
 'Broodbirth Viper':(3,"A 3/3 for 5; myriad copies are small."),
 'Okaun, Eye of Chaos':(3,"Coin flips for size; without Zndrsplt out it's a 3/3 for 5."),
}
FIX2['scare'] = {
 'Equilibrium Adept': ("Pouncing Shoreshark: mutate for 2 with flash and a bounce.", "Nethroi... no: Vadrok, Apex of Thunder: mutate casts a free noncreature from the graveyard."),
 'Picnic Ruiner // Stolen Goodies': ("Gemrazer copy role: Auspicious Starrix, mutate exiles cards and casts permanents free.", "Brokkos, Apex of Forever: mutate from the graveyard over and over."),
 'Markov Blademaster': ("Cavern Whisperer: menace mutate that sneaks the big pile through.", "Lightning Greaves: free haste and shroud for each new mutate pile."),
 'Medusa, Inhuman Queen': ("Kogla, the Titan Ape: a 7/6 that fights on entry and returns Humans.", "Pathbreaker Ibex: attacking gives the team +X/+X and trample."),
 'Broodbirth Viper': ("Auspicious Starrix: mutate exiles until X permanents and casts them free.", "Nethroi, Apex of Death: mutate returns creatures with total power 10."),
 'Okaun, Eye of Chaos': ("Snapdax, Apex of the Hunt: mutate deals 4 damage on each pile.", "Vadrok, Apex of Thunder: mutate casts a free noncreature spell from the graveyard."),
}
FIX2['scare']['Equilibrium Adept'] = ("Pouncing Shoreshark: flash mutate for 2 that bounces a creature.", "Vadrok, Apex of Thunder: mutate casts a free noncreature spell from your graveyard.")
J['modular'] = {
 'Strider Harness':(2,"+1/+1 and haste for 3; Ring of Valkas and Lightning-style gear do more."),
 'Gate Smasher':(3,"Only fits toughness 4+; most of your creatures are small."),
 'Team Pennant':(3,"Small boost; cheap equip only on tokens."),
 'Stark Industries Executive':(3,"2 mana for one Treasure a turn on a 1/2."),
 'Chariot of Victory':(3,"Keywords only, no stats; Sword of Vengeance does more."),
 "Seer's Sundial":(3,"4 mana and 2 per card on landfall; slow draw."),
}
FIX2['modular'] = {
 'Strider Harness': ("Lightning Greaves: equip 0 haste and shroud.", "Puresteel Paladin... red: Hammer of Nazahn: auto-attach Equipment and indestructible."),
 'Gate Smasher': ("Bonesplitter: +2/+0 for equip 1.", "Sword of Fire and Ice: protection, damage and a card every hit."),
 'Team Pennant': ("Shadowspear: trample lifelink for equip 2.", "Sword of Feast and Famine: untap your lands and make them discard."),
 'Stark Industries Executive': ("Mind Stone: a rock that cashes in for a card.", "Smothering Tithe isn't red: Jeweled Lotus-free pick Mana Vault: three colorless right away."),
 'Chariot of Victory': ("Loxodon Warhammer: +3/+0 trample lifelink.", "Sword of Hearth and Home: blink and a land on every hit."),
 "Seer's Sundial": ("Mask of Memory: draw 2, discard 1 on every hit.", "Sram's Expertise is white: The One Ring: protection and a growing card engine."),
}
FIX2['modular']['Strider Harness'] = ("Lightning Greaves: equip 0, haste and shroud.", "Hammer of Nazahn: Equipment auto-attaches and the carrier is indestructible.")
FIX2['modular']['Stark Industries Executive'] = ("Mind Stone: a rock that cashes in for a card.", "Mana Vault: three colorless mana right away.")
FIX2['modular']["Seer's Sundial"] = ("Mask of Memory: draw 2, discard 1 on every hit.", "The One Ring: a turn of protection and a growing card engine.")
J['family'] = {
 'Viashino Heretic':(3,"Artifact removal on a 1/3; narrow."),
 'Solitary Sanctuary':(3,"One stun plus counters only when you tap their creatures."),
 'Kapsho Kitefins':(3,"6 mana for a 3/3 flier; strong only with lots of offspring."),
 "Hylda's Crown of Winter":(3,"Taps one creature a turn for mana you'd rather spend on offspring."),
 'Shattered Acolyte':(3,"Artifact/enchantment removal on a 2/2; narrow."),
 'Illusory Ambusher':(3,"Draw only if it takes damage; 4/1 dies to anything."),
}
FIX2['family'] = {
 'Viashino Heretic': ("Abrade: instant, kills a creature or artifact.", "Anguished Unmaking isn't in color: Comet Storm: X damage to as many targets as you want."),
 'Solitary Sanctuary': ("Thousand-Faced Shadow: ninjutsu flier that copies itself (offspring copies too).", "Brago, King Eternal: blinks your ETB creatures every hit."),
 'Kapsho Kitefins': ("Glasspool Mimic: a copy of your best ETB creature for 3.", "Spark Double: copy your best creature without the legend rule."),
 "Hylda's Crown of Winter": ("Mind Stone: a rock that cashes in for a card.", "Smothering Tithe: a Treasure every time an opponent draws."),
 'Shattered Acolyte': ("Swords to Plowshares: 1-mana exile for any creature.", "Teferi's Protection: save the board for a turn."),
 'Illusory Ambusher': ("Faerie Mastermind: flash flier that draws when opponents draw extra.", "Rhystic Study: a card every time an opponent doesn't pay 1."),
}
FIX2['family']['Viashino Heretic'] = ("Abrade: instant, kills a creature or an artifact.", "Comet Storm: X damage split across as many targets as you like.")
J['spider'] = {
 'Venom Blast':(3,"Sorcery fight for 4; fine but slow."),
 'Future Flight':(3,"Aura draws 2 but puts a 2-for-1 risk on one Spider."),
 'Goliath, Mass Manipulator':(3,"2/2 that needs 5 more mana once to do anything."),
 'Ezekiel Sims, Spider-Totem':(3,"5 mana for a +2/+2 each combat."),
 'Spider-Man Noir':(3,"Only grows lone attackers; Spiders want to attack wide."),
 'The Clone Saga':(3,"Slow saga; the copy is the only strong chapter."),
}
FIX2['spider'] = {
 'Venom Blast': ("Swords to Plowshares: 1-mana instant exile.", "Anguished Unmaking: instant exile anything."),
 'Future Flight': ("Rhystic Study: a card every time an opponent doesn't pay 1.", "Sylvan Library: pick the best of three every turn."),
 'Goliath, Mass Manipulator': ("Birds of Paradise: any-color mana on turn one in five colors.", "Noble Hierarch: mana and exalted every turn."),
 'Ezekiel Sims, Spider-Totem': ("Shared Animosity: every attacker gets +1/+0 per other Spider attacking.", "Craterhoof Behemoth: one swing ends the game."),
 'Spider-Man Noir': ("Kodama's Reach: two basics, one to hand.", "Smothering Tithe: a Treasure every time an opponent draws."),
 'The Clone Saga': ("Kindred Discovery: a card each time a Spider enters or attacks.", "Door of Destinies: every Spider spell grows the whole team."),
}
J['zurgo'] = {
 "Patrician's Scorn":(2,"Only hits enchantments; narrow in this pod."),
 'Herald of Dromoka':(3,"Vigilance for Warriors on a 2/2."),
 'Voldaren Thrillseeker':(3,"Backup 2 and a fling; small."),
 'Thunderwolf Cavalry':(3,"5 mana 4/4; good only if it connects."),
 'Thwart the Grave':(3,"6 mana reanimation; slow."),
 'Ignition Team':(3,"7 mana; counters depend on tapped lands."),
}
FIX2['zurgo'] = {
 "Patrician's Scorn": ("Swords to Plowshares: 1-mana instant exile.", "Anguished Unmaking: instant exile anything."),
 'Herald of Dromoka': ("Lightning Greaves: haste and shroud for each new copy.", "Adeline, Resplendent Cathar: a Human token at each opponent every attack."),
 'Voldaren Thrillseeker': ("Goblin Bombardment: fling tokens at will.", "Purphoros, God of the Forge: every creature entering deals 2 to each opponent."),
 'Thunderwolf Cavalry': ("Iroas, God of Victory: menace and no damage to attackers.", "Anointed Procession isn't needed: Kaalia of the Vast: drop Angels, Demons and Dragons attacking."),
 'Thwart the Grave': ("Feed the Swarm... no: Unearth: return a 3-drop for 1.", "Teneb, the Harvester: reanimate on every hit."),
 'Ignition Team': ("Mardu Ascendancy: a Goblin token every attack.", "Anointed Procession: doubles your tokens."),
}
FIX2['zurgo']['Thunderwolf Cavalry'] = ("Iroas, God of Victory: menace for the team and no damage to attackers.", "Kaalia of the Vast: drops Angels, Demons and Dragons straight into the attack.")
FIX2['zurgo']['Thwart the Grave'] = ("Unearth: return a 3-drop for 1 (or cycle it late).", "Teneb, the Harvester: a 6/6 flier that reanimates on every hit.")
FIX2['scare']['Picnic Ruiner // Stolen Goodies'] = ("Auspicious Starrix: mutate exiles cards and casts permanents free.", "Vadrok, Apex of Thunder: mutate casts a free noncreature spell from your graveyard.")
FIX2['scare']['Broodbirth Viper'] = ("Pouncing Shoreshark: flash mutate for 2 that bounces a creature.", "Craterhoof Behemoth: one swing ends the game.")
FIX2['casino']['Treasure Chest'] = ("Hit the Mother Lode: dig for a free spell and Treasure for the difference.", "Smothering Tithe: a Treasure every time an opponent draws.")
FIX2['zurgo']['Herald of Dromoka'] = ("Lightning Greaves: haste and shroud for each new Warrior.", "Adeline, Resplendent Cathar: a Human token at each opponent every attack.")
FIX2['family']['Solitary Sanctuary'] = ("Swords to Plowshares: 1-mana instant exile for the creature that matters.", "Teferi, Time Raveler... no: Fractured Identity: exile their best permanent and get a copy of it.")
FIX2['family']['Solitary Sanctuary'] = ("Swords to Plowshares: 1-mana instant exile for the creature that matters.", "Fractured Identity: exile their best nonland permanent and every opponent copies... no, you get a copy.")
FIX2['family']['Solitary Sanctuary'] = ("Swords to Plowshares: 1-mana instant exile for the creature that matters.", "Fractured Identity: exile an opponent's best nonland permanent and each other player gets a token copy.")
FIX2['family']["Hylda's Crown of Winter"] = ("Chaos Warp: instant answer to any permanent.", "Cyclonic Rift: overload to bounce every opponent's nonland permanent.")
# Kyle (Nov 4): Garage swaps aim at each deck's weak spots, not only removal.
FIX2['family']['Solitary Sanctuary'] = ("Rally of Wings: untap your fliers and give them +2/+2 for a big swing (Finish is the weak spot).", "Akroma's Will: team flying, double strike, lifelink and protection to close the game.")
FIX2['family']["Hylda's Crown of Winter"] = ("Talisman of Conviction: a 2-mana R/W rock (Mana is low).", "Smothering Tithe: a Treasure every time an opponent draws.")
FIX2['spider']['Venom Blast'] = ("Kindred Discovery: name Spider, draw on every Spider entering or attacking (Cards is low).", "Craterhoof Behemoth: one swing ends the game (Finish is low).")
FIX2['spider']['Ezekiel Sims, Spider-Totem'] = ("Shared Animosity: every attacking Spider gets +1/+0 per other attacking Spider.", "Akroma's Will: team flying, double strike, lifelink and protection.")
FIX2['zurgo']["Patrician's Scorn"] = ("Boros Charm: team indestructible, or 4 to a player (Survival is the weak spot).", "Teferi's Protection: the whole board and life total safe for a turn.")
FIX2['casino']['Phyrexian Scriptures'] = ("Painful Truths: draw up to three for 3 (Cards is low).", "Black Market Connections: Treasure, cards or tokens every turn.")
FIX2['casino']['Danse Macabre'] = ("Phyrexian Arena: an extra card every upkeep.", "Sheoldred, the Apocalypse: you gain on every draw, they lose on theirs.")
FIX2['modular']['Strider Harness'] = ("Chaos Warp: instant answer to any permanent (Interaction is low).", "The One Ring: a turn of protection and a growing card engine (Cards is low).")
FIX2['modular']['Gate Smasher'] = ("Abrade: instant removal for a creature or an artifact.", "Sword of Fire and Ice: protection, damage and a card every hit.")
FIX2['modular']['Team Pennant'] = ("Mask of Memory: draw 2, discard 1 on every hit.", "Sword of Feast and Famine: untap your lands and make them discard.")
FIX2['mothman']["Embalmer's Tools"] = ("Putrefy: instant kill for a creature or artifact (Interaction is low).", "Assassin's Trophy: instant exile of any permanent for 2.")
FIX2['scare']['Medusa, Inhuman Queen'] = ("Heroic Intervention: the team gets hexproof and indestructible (Survival is low).", "Lightning Greaves: free haste and shroud for each new mutate pile.")
