"""Crypt Crawl backdrops from the Ansimuz packs (assets/biome*): packs every layer into crawl_bg.png and writes atlas['bg']."""
import json
from PIL import Image
A='/home/claude/pod2/assets/'
# per biome: scale, y offset of the art (logical px, at that scale), sky fill colour, layers back->front
# layer: file, y (in art px), parallax speed, tile width (None = drawn once and repeats every 'period' px of travel), x for once-layers
B={
 'grave':dict(dir='biome1_lake',scale=.75,oy=97,fill='#001b27',top='#000a12',layers=[
    ('back.png',0,.04,48),('moon.png',0,.0,None,dict(x=230,period=0)),('midle.png',0,.35,544),('trail.png',112,1.0,272)]),
 'manor':dict(dir='biome2_cemetery',scale=.75,oy=69,fill='#1a4652',top='#06141c',layers=[
    ('back.png',0,.04,272),('far-trees.png',0,.12,272),('trees.png',0,.28,272),('front-fog.png',79,.5,272),('fence.png',111,.75,272),('path.png',152,1.0,272)]),
 'city':dict(dir='biome4_city',scale=.75,oy=67,fill='#001628',top='#000a14',layers=[   # 0.12.108 (Kyle) Downtown
    ('sky.png',-140,.04,48),('far.png',-140,.12,272),('mid.png',-140,.35,544),('street.png',152,1.0,272)]),
 'bog':dict(dir='biome3_cathedral',scale=.75,oy=44,fill='#5a2236',top='#1e0a16',layers=[
    ('sky.png',0,.04,160),('far_buildings.png',0,.12,160),('near-buildings.png',0,.3,None,dict(x=130,period=420)),('arches_floor.png',0,1.0,320)]),
}
imgs=[];meta={}
for k,b in B.items():
    for L in b['layers']:
        im=Image.open(A+b['dir']+'/'+L[0]).convert('RGBA');imgs.append((k,L[0],im))
# shelf pack
W=1100;x=y=rowh=0;pos={}
for k,n,im in sorted(imgs,key=lambda t:-t[2].height):
    if x+im.width>W:x=0;y+=rowh+2;rowh=0
    pos[(k,n)]=(x,y);x+=im.width+2;rowh=max(rowh,im.height)
sheet=Image.new('RGBA',(W,y+rowh))
for k,n,im in imgs: sheet.alpha_composite(im,pos[(k,n)])
sheet.save('/home/claude/pod2/crawl_bg.png',optimize=True)
G=190
for k,b in B.items():
    s=b['scale'];oy=b['oy'];layers=[]
    for L in b['layers']:
        n=L[0];im=Image.open(A+b['dir']+'/'+n);px,py=pos[(k,n)]
        e=dict(r=[px,py,im.width,im.height],y=round(oy+L[1]*s,2),sp=L[2],w=round(im.width*s,2),h=round(im.height*s,2))
        if L[3]:e['tile']=round(L[3]*s,2)
        else:e.update(once=L[4])
        layers.append(e)
    meta[k]=dict(fill=b['fill'],top=b['top'],artTop=oy,layers=layers)
a=json.load(open('/home/claude/pod2/crawl_atlas.json'));a['bg']=meta
json.dump(a,open('/home/claude/pod2/crawl_atlas.json','w'))
print(sheet.size,json.dumps(meta)[:400])
