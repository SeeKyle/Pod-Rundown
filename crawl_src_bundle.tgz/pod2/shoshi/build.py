"""Shoshi_the_Fixer (Kyle's cousin, his tech guy). Built from the CraftPix freebie bandit sheet Kyle sent, reworked:
- every pixel snapped to a named colour (the webp blur and the background halo are gone), then recoloured:
  the bandit's mask comes off (his face shows, with glasses and a headset mic), the brown pants become dark jeans,
  the hoodie stays purple (a nod to Life360, where he works) with a small white logo, the boots stay brown;
- edges cleaned: stray pixels removed, pin-holes filled, and one even dark outline drawn all the way round."""
import pickle, json
import numpy as np
from PIL import Image
F=pickle.load(open('/tmp/shoshi_src/frames.pkl','rb'))
C=np.load('/tmp/shoshi_src/pal.npy')
OUT=(14,10,20)
HOOD=[(22,16,34),(34,26,52),(48,36,70),(62,48,90),(80,64,112)]
JEANS=[(24,30,54),(34,44,76),(48,62,102),(66,84,130),(92,112,158)]
SKIN=[(122,74,52),(176,118,84),(222,166,126),(240,196,160)]
GUN=[(30,32,38),(52,56,64),(84,90,100)]
BOOT=[(46,30,22),(70,46,32)]
def hexs(c): return '%02x%02x%02x'%tuple(int(v) for v in c)
role={}
for k,c in enumerate(C):
    h=hexs(c)
    role[k]=h
# semantic map by palette colour (from the cluster report)
SEM={'060304':'out','08080d':'out','190808':'out','0e0918':'out',
     '191522':'hood0','251c31':'hood1','332640':'hood2','3d2f4b':'hood3','413051':'hood3','443256':'hood4',
     '2c1d1a':'pants0','422822':'pants1','572f28':'pants2','4f372f':'pants2','66392e':'pants3','7b4433':'pants3','995b3d':'pants4',
     '845a46':'skin1','c88550':'skin2','eaa77f':'skin3',
     '27312f':'teal','333833':'gun','464f47':'fringe','4e534e':'fringe'}
def nearest(rgb):
    d=((C-rgb)**2).sum(1);return hexs(C[d.argmin()])
def build_frame(b,alpha,name):
    H,W=alpha.shape
    ys,xs=np.where(alpha);top,bot=ys.min(),ys.max();hgt=max(1,bot-top)
    img=np.zeros((H,W,4),np.uint8)
    lying=name=='dead'
    for y,x in zip(ys,xs):
        s=SEM.get(nearest(b[y,x]),'fringe');rel=(y-top)/hgt
        if s=='fringe': continue
        if s=='out': c=OUT
        elif s.startswith('hood'): c=HOOD[int(s[-1])]
        elif s.startswith('pants'):
            i=int(s[-1])
            if not lying and rel<.36: c=HOOD[max(0,min(4,i))]          # the bandit's scarf -> hoodie collar
            elif not lying and rel>.93: c=BOOT[0 if i<2 else 1]          # boots stay brown
            else: c=JEANS[i]
        elif s.startswith('skin'): c=SKIN[int(s[-1])]
        elif s=='teal':
            c=SKIN[1] if (not lying and rel<.2) else GUN[0]               # mask -> face; otherwise the gun
        elif s=='gun':
            c=SKIN[0] if (not lying and rel<.2) else GUN[1]
        img[y,x,:3]=c;img[y,x,3]=255
    fixups(img,top,bot,name)
    clean(img)
    return img,top,bot
SKINSET={tuple(c) for c in SKIN};JSET={tuple(c) for c in JEANS};HSET={tuple(c) for c in HOOD}
def fixups(img,top,bot,name):
    H,W=img.shape[:2];a=img[:,:,3]>0;hgt=max(1,bot-top)
    ys,xs=np.where(a);cx=np.median(xs)
    for y,x in zip(ys,xs):
        c=tuple(int(v) for v in img[y,x,:3]);rel=(y-top)/hgt
        n4=[(y+dy,x+dx) for dy,dx in ((1,0),(-1,0),(0,1),(0,-1))]
        edge=any(not(0<=yy<H and 0<=xx<W) or not a[yy,xx] for yy,xx in n4)
        if c in SKINSET:
            if name=='attack' and x>cx+34:                       # the muzzle flash, not a hand
                img[y,x,:3]=(255,232,140) if c in (SKIN[2],SKIN[3]) else (255,170,60);continue
            if rel<.4 and edge and name!='dead':                 # blur halo round the hood -> outline
                img[y,x,:3]=OUT;continue
            nbj=sum(1 for dy in (-1,0,1) for dx in (-1,0,1) if 0<=y+dy<H and 0<=x+dx<W and a[y+dy,x+dx] and tuple(img[y+dy,x+dx,:3]) in JSET)
            if name!='attack' and name!='dead' and rel>.68: img[y,x,:3]=JEANS[3];continue   # no skin below the hands
            nbs=sum(1 for dy in (-1,0,1) for dx in (-1,0,1) if (dy or dx) and 0<=y+dy<H and 0<=x+dx<W and a[y+dy,x+dx] and tuple(img[y+dy,x+dx,:3]) in SKINSET)
            if nbj>=4 and nbs<=1: img[y,x,:3]=JEANS[3]          # lone orange specks in the jeans (not the hands)
        elif c in HSET and rel<.4 and edge and c in (HOOD[3],HOOD[4]):
            img[y,x,:3]=OUT
def auto_pistol(img,frame_i):
    '''replace the little pistol with a machine pistol: longer slide, vent holes, a long magazine under the grip'''
    H,W=img.shape[:2];a=img[:,:,3]>0
    sk=[(y,x) for y,x in zip(*np.where(a)) if tuple(img[y,x,:3]) in SKINSET]
    if not sk: return
    # the gun hand = the right-most skin pixel that is not part of the flash
    hy,hx=max(sk,key=lambda p:p[1])
    # wipe the old gun to the right of the hand (dark pixels), keep the flash (bright)
    for y in range(max(0,hy-4),min(H,hy+4)):
        for x in range(hx+1,min(W,hx+16)):
            if a[y,x] and int(img[y,x,:3].astype(int).sum())<240: img[y,x,3]=0
    G0,G1,G2=(26,28,34),(58,62,72),(110,116,128)
    def P(x,y,c):
        if 0<=x<W and 0<=y<H: img[y,x,:3]=c;img[y,x,3]=255
    for x in range(hx-1,hx+11):          # slide/barrel
        P(x,hy-2,G0);P(x,hy-1,G1 if x<hx+9 else G0);P(x,hy,G0)
    for x in range(hx+1,hx+9,2): P(x,hy-1,G2)   # vent holes catching the light
    P(hx+11,hy-1,G0)                          # muzzle
    for k in range(5):                        # long magazine hanging under the grip
        P(hx,hy+1+k,G0);P(hx+1,hy+1+k,G1 if k<4 else G0)
    P(hx+3,hy+1,G0);P(hx+4,hy+1,G0)           # trigger guard
    if frame_i in (2,3,4):                    # burst muzzle flash
        fx=hx+12
        for k in range(3+frame_i):
            P(fx+k,hy-1,(255,236,150) if k<2 else (255,170,60))
        P(fx+1,hy-2,(255,200,90));P(fx+1,hy,(255,200,90))
        if frame_i==3: P(fx+5,hy-3,(255,170,60));P(fx+5,hy+1,(255,170,60))
    if frame_i in (2,4): P(hx+2,hy-4,(220,180,80));P(hx+1,hy-5,(200,150,60))   # spent casing flying up
def nb(a,y,x):
    H,W=a.shape;n=0
    for dy in (-1,0,1):
        for dx in (-1,0,1):
            if (dy or dx) and 0<=y+dy<H and 0<=x+dx<W and a[y+dy,x+dx]: n+=1
    return n
def clean(img):
    a=img[:,:,3]>0;H,W=a.shape
    for _ in range(2):   # stray pixels off, pin-holes filled
        for y in range(H):
            for x in range(W):
                n=nb(a,y,x)
                if a[y,x] and n<=1: a[y,x]=False;img[y,x,3]=0
                elif not a[y,x] and n>=6:
                    nbc=[img[y+dy,x+dx,:3] for dy in (-1,0,1) for dx in (-1,0,1) if 0<=y+dy<H and 0<=x+dx<W and a[y+dy,x+dx]]
                    img[y,x,:3]=np.median(np.array(nbc),axis=0);img[y,x,3]=255;a[y,x]=True
    # one even dark outline all the way round: outer edge pixels that aren't already dark get an outline pixel outside them
    o=np.zeros_like(a)
    o[1:,:]|=a[:-1,:];o[:-1,:]|=a[1:,:];o[:,1:]|=a[:,:-1];o[:,:-1]|=a[:,1:]
    o&=~a
    for y,x in zip(*np.where(o)):
        # only where the neighbouring body pixel is a light colour (avoid doubling an existing outline)
        lt=[img[y+dy,x+dx,:3].sum() for dy,dx in ((1,0),(-1,0),(0,1),(0,-1)) if 0<=y+dy<H and 0<=x+dx<W and a[y+dy,x+dx]]
        if lt and max(lt)>130: img[y,x,:3]=OUT;img[y,x,3]=255
def face(img,top):
    """glasses over his eyes and a headset mic"""
    H,W=img.shape[:2]
    for y in range(top+2,min(H,top+10)):
        xs=[x for x in range(W) if img[y,x,3] and tuple(img[y,x,:3]) in (SKIN[2],SKIN[3])]
        if len(xs)>=2:
            x0,x1=min(xs),max(xs)
            for x in range(x0-1,x1+2):
                if 0<=x<W: img[y-1,x,:3]=OUT;img[y-1,x,3]=255
            for x in range(x0,x1+1): img[y,x,:3]=(156,206,232) if (x-x0)%3!=2 else OUT
            if x0-2>=0: img[y,x0-2,:3]=OUT
            for k in range(3):   # headset boom down toward the mouth, with a green light
                yy=y+2+k;xx=x0-1+k
                if yy<H and 0<=xx<W: img[yy,xx,:3]=(30,30,36);img[yy,xx,3]=255
            if y+4<H and 0<=x0+2<W: img[y+4,x0+2,:3]=(96,224,124)
            return
def logo(img,top,bot):
    y=int(top+(bot-top)*.3)
    xs=[x for x in range(img.shape[1]) if img[y,x,3] and tuple(img[y,x,:3]) in [tuple(c) for c in HOOD]]
    if xs:
        x=xs[len(xs)*2//3];img[y,x,:3]=(236,236,250)
        if img[y,x+1,3]: img[y,x+1,:3]=(176,150,236)
CW,CH=112,84;AX,AY=46,80
def phone(img,top,bot,k):
    """he checks his phone: a small dark phone in the front hand, screen glowing teal, a faint glow on his face"""
    H,W=img.shape[:2];a=img[:,:,3]>0;hgt=bot-top
    sk=[(y,x) for y,x in zip(*np.where(a)) if tuple(img[y,x,:3]) in SKINSET and .45<(y-top)/hgt<.7]
    if not sk: return
    hy,hx=max(sk,key=lambda p:p[1])
    ph_y,ph_x=hy-2,hx-1
    for dy in range(4):
        for dx in range(3):
            y,x=ph_y+dy,ph_x+dx
            if 0<=y<H and 0<=x<W:
                img[y,x,:3]=(20,20,26) if (dx in (0,2) or dy in (0,3)) else ((120,240,220) if (k+dy)%3 else (190,255,240));img[y,x,3]=255
    # a few signal bits floating up off the phone
    for j in range(2):
        y,x=ph_y-3-((k*2+j*3)%6),ph_x+1+j*2
        if 0<=y<H and 0<=x<W: img[y,x,:3]=(140,255,230);img[y,x,3]=255
frames={}
for name in ['idle','walk','run','attack','hurt','dead']:
    lst=[]
    for i,(b,alpha,_) in enumerate(F[name]):
        img,top,bot=build_frame(b,alpha,name)
        if name!='dead' or i==0: face(img,top);logo(img,top,bot)
        if name=='attack': auto_pistol(img,i)
        lst.append((img,top,bot))
    frames[name]=lst
# melee = a point-blank burst: the first three attack frames, flash only on the last
mel=[]
for i in (0,1,3):
    b,alpha,_=F['attack'][i];img,top,bot=build_frame(b,alpha,'attack');face(img,top);logo(img,top,bot);auto_pistol(img,i if i<3 else 2);mel.append((img,top,bot))
frames['melee']=mel
use=[]
for k in range(4):
    b,alpha,_=F['idle'][k%len(F['idle'])];img,top,bot=build_frame(b,alpha,'idle');face(img,top);logo(img,top,bot);phone(img,top,bot,k);use.append((img,top,bot))
frames['use']=use
order=[('idle','idle'),('walk','walk'),('run','run'),('ranged','attack'),('melee','melee'),('use','use'),('hurt','hurt'),('death','dead')]
sheet=Image.new('RGBA',(CW*8,CH*len(order)),(0,0,0,0));meta={}
for r,(an,src) in enumerate(order):
    for i,(img,top,bot) in enumerate(frames[src]):
        ys,xs=np.where(img[:,:,3]>0)
        head=[x for y,x in zip(ys,xs) if y<top+14] or list(xs)
        hx=float(np.mean(head));ox=int(round(AX-hx));oy=int(AY-bot)
        cell=Image.new('RGBA',(CW,CH),(0,0,0,0));im=Image.fromarray(img,'RGBA')
        cell.paste(im,(ox,oy),im);sheet.alpha_composite(cell,(i*CW,r*CH))
    meta[an]=dict(fw=CW,fh=CH,n=len(frames[src]),ax=AX,ay=AY,x=0,y=r*CH,img='shoshi',pre=round(72/152,4),art=1,pk=1.65)
sheet.save('/home/claude/pod2/crawl_shoshi.png',optimize=True)
json.dump(meta,open('/home/claude/pod2/shoshi/meta.json','w'))
A=json.load(open('/home/claude/pod2/crawl_atlas.json'));[v.__setitem__('faceR',1) for v in meta.values() if isinstance(v,dict)];A['units']['shoshi']=meta;json.dump(A,open('/home/claude/pod2/crawl_atlas.json','w'))
print(json.dumps({k:v['n'] for k,v in meta.items()}))
