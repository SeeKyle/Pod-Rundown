"""Cut the bandit sheet Kyle sent into native-resolution frames (the sheet is 2x upscaled, webp-blurred)."""
import sys, json
import numpy as np
from PIL import Image
SRC='/tmp/shoshi_src/'
def load(n): return np.array(Image.open(SRC+n+'.webp').convert('RGB')).astype(int)
def bands(a, y0, y1, x0=270):
    bg=a[5,5];m=np.abs(a[y0:y1,x0:]-bg).sum(axis=2)>45
    cols=np.where(m.any(axis=0))[0]+x0;segs=[];prev=None
    for x in cols:
        if prev is None or x>prev+14: segs.append([x,x])
        else: segs[-1][1]=x
        prev=x
    return segs
rows={'idle':('main',65,208),'walk':('main',296,440),'run':('main',520,656),'attack':('main',736,872),'hurt':('main',945,1080),'dead':('dead',60,208)}
FW,FH=96,80
out={}
for name,(src,y0,y1) in rows.items():
    a=load(src);bg=a[5,5]
    segs=bands(a,y0,y1)
    frames=[]
    for (x0,x1) in segs:
        if x1-x0<20: continue   # muzzle flashes / stray bits merged later
        cx0,cx1=x0-60,x1+60
        crop=a[y0-6:y1+4,max(0,cx0):cx1]
        # 2x -> 1x: average each 2x2 block
        h=(crop.shape[0]//2)*2;w=(crop.shape[1]//2)*2;crop=crop[:h,:w]
        b=crop.reshape(h//2,2,w//2,2,3).mean(axis=(1,3))
        alpha=(np.abs(b-bg).sum(axis=2)>34)
        frames.append((b,alpha,max(0,cx0)))
    out[name]=frames
# report sizes
for k,v in out.items(): print(k,len(v),[f[0].shape for f in v][:2])
np.save('/tmp/shoshi_src/frames.npy',np.array([0]))
import pickle;pickle.dump(out,open('/tmp/shoshi_src/frames.pkl','wb'))
