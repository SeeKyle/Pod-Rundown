"""0.12.175 (Kyle): the Soldier (player character) and the Screamer (zombie), from CraftPix's free packs Kyle downloaded:
'Free Soldier Sprite Sheets Pixel Art' (Soldier_1) and 'Free Zombie Sprite Sheet Pack Pixel Art' (Zombie Woman). License: https://craftpix.net/file-licenses/
Both sheets face right (faceR)."""
import json, numpy as np
from PIL import Image
S='/tmp/cpx/sol/Soldier_1/';Z='/tmp/cpx/zom/Zombie Woman/'
def frames(path,fw):
    im=Image.open(path).convert('RGBA');n=im.width//fw;return [im.crop((i*fw,0,(i+1)*fw,im.height)) for i in range(n)]
def bbox(im):
    a=np.array(im)[:,:,3]>0;ys,xs=np.where(a);return int(xs.min()),int(ys.min()),int(xs.max()),int(ys.max())
def _old(im):
    a=np.array(im)[:,:,3]>0;ys,xs=np.where(a);return xs.min(),ys.min(),xs.max(),ys.max()
def sheet(rows,fw,fh,name,ax,ay,pre,extra=None):
    W=max(len(f) for _,f in rows)*fw;out=Image.new('RGBA',(W,fh*len(rows)),(0,0,0,0));meta={}
    for r,(an,fr) in enumerate(rows):
        for i,f in enumerate(fr): out.alpha_composite(f,(i*fw,r*fh))
        meta[an]=dict(fw=fw,fh=fh,n=len(fr),ax=ax,ay=ay,x=0,y=r*fh,img=name,pre=pre,art=1,faceR=1,**(extra or {}))
    out.save('/home/claude/pod2/crawl_%s.png'%name,optimize=True);return meta
# ---- Soldier: cells 128x128, feet at the bottom row; anchor = the middle of his body in the idle pose
sol={k:frames(S+f+'.png',128) for k,f in [('shot2','Shot_2'),('idle','Idle'),('walk','Walk'),('run','Run'),('ranged','Shot_1'),('melee','Attack'),('reload','Recharge'),('throw','Grenade'),('hurt','Hurt'),('death','Dead'),('boom','Explosion')]}
x0,y0,x1,y1=bbox(sol['idle'][0]);
a=np.array(sol['idle'][0])[:,:,3]>0;legs=np.where(a[y1-6:y1+1].any(0))[0];AX=int(round(legs.mean()));AY=y1+1
H=y1-y0+1;PRE=round(.4737*H/68,4)   # same height on screen as Shoshi
rows=[(k,sol[k]) for k in ['idle','walk','run','ranged','melee','reload','throw','hurt','death','shot2']]   # 0.12.199: shot2 = Suppressing_Fire
meta=sheet(rows,128,128,'soldier',AX,AY,PRE,{'pk':1.5})
meta['death']['fall']=0
# grenade explosion frames on their own row in the same image, used by the Frag_Grenade blast
im=Image.open('/home/claude/pod2/crawl_soldier.png');W=max(im.width,128*len(sol['boom']));big=Image.new('RGBA',(W,im.height+128),(0,0,0,0));big.alpha_composite(im,(0,0))
for i,f in enumerate(sol['boom']): big.alpha_composite(f,(i*128,im.height))
bx0=min(bbox(f)[0] for f in sol['boom'] if np.array(f)[:,:,3].any());by1=max(bbox(f)[3] for f in sol['boom'] if np.array(f)[:,:,3].any())
big.save('/home/claude/pod2/crawl_soldier.png',optimize=True)
xs=[];[xs.extend([bbox(f)[0],bbox(f)[2]]) for f in sol['boom'] if np.array(f)[:,:,3].any()]
FRAG=dict(fw=128,fh=128,n=len(sol['boom']),ax=int((min(xs)+max(xs))/2),ay=int(by1)+1,x=0,y=im.height,img='soldier',pre=PRE,art=1)
# ---- Screamer: cells 96x96
zw={k:frames(Z+f+'.png',96) for k,f in [('walk','Run'),('atk','Attack_1'),('scream','Scream'),('idle','Idle'),('die','Dead'),('hurt','Hurt')]}
x0,y0,x1,y1=bbox(zw['idle'][0]);a=np.array(zw['idle'][0])[:,:,3]>0;legs=np.where(a[y1-5:y1+1].any(0))[0];ZX=int(round(legs.mean()));ZY=y1+1
ZH=y1-y0+1;ZPRE=round(.88*ZH/38,4)   # a touch taller than a regular zombie (36 px at .88): thin and lanky
zm=sheet([(k,zw[k]) for k in ['walk','atk','scream','idle','die','hurt']],96,96,'screamer',ZX,ZY,ZPRE)
A=json.load(open('/home/claude/pod2/crawl_atlas.json'))
# 0.12.199 (Kyle): the smoke cloud from the same pack (Soldier_3/Smoke.png, 22 frames) for the Soldier's Smoke_Grenade
SM=frames('/tmp/cpx/sol/Soldier_3/Smoke.png',128);im=Image.open('/home/claude/pod2/crawl_soldier.png');W2=max(im.width,128*len(SM));big2=Image.new('RGBA',(W2,im.height+128),(0,0,0,0));big2.alpha_composite(im,(0,0))
for i,f in enumerate(SM): big2.alpha_composite(f,(i*128,im.height))
big2.save('/home/claude/pod2/crawl_soldier.png',optimize=True)
SMOKE=dict(fw=128,fh=128,n=len(SM),ax=64,ay=120,x=0,y=im.height,img='soldier')
A['units']['soldier']=meta;A['units']['screamer']=zm;A['frag']=FRAG;A['smoke']=SMOKE
json.dump(A,open('/home/claude/pod2/crawl_atlas.json','w'))
print('soldier',AX,AY,H,PRE,{k:v['n'] for k,v in meta.items()});print('screamer',ZX,ZY,ZH,ZPRE,{k:v['n'] for k,v in zm.items()});print('frag',FRAG)
