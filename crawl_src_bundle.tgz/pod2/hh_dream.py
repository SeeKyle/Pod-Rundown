# 0.12.1: Heavy Hitters (8 per deck) and The Dream (3 per deck), rewritten from scratch from the current lists.
# Card names must match the decklists exactly (checked in build).
H = {}
def add(k, hh, dream): H[k] = dict(hh=[dict(card=c, text=t) for c, t in hh], dream=[dict(name=n, text=t) for n, t in dream])

add('grim', [
 ("Ghalta and Mavren", "A 12/12 trampler that makes a big Dinosaur or a pile of lifelink Vampires every attack."),
 ("Throne of the Grim Captain // The Grim Captain", "The secret commander: mills toward its own craft, then flips into a 7/7 that makes everyone sacrifice."),
 ("Altar of the Wretched // Wretched Bonemass", "Sacrifice a fatty, draw its power. A 12-power creature is a full new hand."),
 ("Galactus, Devourer of Worlds", "12/12 flying, trampling, indestructible, and it eats a permanent on the way in."),
 ("Ghalta, Primal Hunger", "Costs about 4 here. A turn-5 12/12 trampler is a two-hit kill."),
 ("Prime Speaker Zegana", "Enters as big as your biggest creature and draws that many."),
 ("The Coming of Galactus", "Removal, a two-turn drain, then a free 16/16 flying trampler."),
 ("Zetalpa, Primal Dawn", "Flying, double strike, trample, indestructible: 16 damage a swing that almost nothing stops."),
], [
 ("Turn-5 Ghalta", "Faeburrow Elder and a bounce land on turns 2-3, a cascade into the Throne on 4, then Ghalta for about 4 mana on 5. Kenrith gives the team haste and trample the turn after."),
 ("The Captain Sets Sail", "The Throne mills its four types into the yard and crafts on turn 6. The Grim Captain swings: everyone sacrifices, and a crafted Ghalta comes back attacking."),
 ("Two From the Grave", "Incarnation Technique with demonstrate mills ten and returns two fatties. Altar of the Wretched eats one of them for a new hand while the other attacks."),
])
add('thing', [
 ("Cosmic Crucible", "4 mana every turn, and your first noncreature spell each turn gets copied."),
 ("Recurring Insight", "Draw as many cards as an opponent's hand, then do it again next turn (rebound)."),
 ("Mind into Matter", "Draw X, then put a permanent with MV X or less into play for free."),
 ("Akroma's Will", "With The Thing out: team flying, double strike, indestructible and protection. Game over."),
 ("Bruce Banner // The Incredible Hulk", "XX: draw X, and he flips into an 8/8 that takes extra combats."),
 ("The Unagi of Kyoshi Island", "A 5/5 flash ward that gives you two cards whenever an opponent draws a second card."),
 ("Tellah, Great Sage", "Noncreature spells make tokens, big ones draw two, huge ones blast every opponent."),
 ("Hraesvelgr of the First Brood", "A 5/5 flier: every noncreature spell makes a creature (The Thing) unblockable."),
], [
 ("Clobberin' Time", "Turn 6 The Thing, turn 7 two noncreature spells: +8 counters. Hraesvelgr makes him unblockable and a 13/13 trampler starts taking chunks."),
 ("Copy Machine", "Cosmic Crucible copies Mind into Matter: two free permanents and a hand full of cards, and The Thing gets counters for both."),
 ("Green Goliath", "Bruce Banner draws five, flips into the Hulk, and Akroma's Will makes every creature a flying double striker for the extra combat."),
])
add('mathas', [
 ("Axis of Mortality", "Every upkeep two players swap life totals. You decide who's at 40."),
 ("Peer into the Abyss", "Draw half your library and go to half life, then swap it back up."),
 ("Profane Transfusion", "Swap life with someone, and get a Horror as big as the gap."),
 ("Seizan, Perverter of Truth", "Everyone draws 2 and loses 2 every upkeep; you're the one who wants that."),
 ("Soul Conduit", "6 mana: two players swap life totals, again and again."),
 ("Bounty Board", "Fixes your mana and spreads bounty counters for Mathas to cash in."),
 ("Sower of Discord", "A 6/6 flier that links two players' damage."),
 ("Necrologia", "End step: pay X life, draw X. Fuel for the next swap."),
], [
 ("The Big Swap", "Turn 6 Peer into the Abyss on yourself (draw 30, go to 15), Necrologia down to 3 at end step, then Axis of Mortality swaps you with a player at 40."),
 ("Bounty Season", "Bounty Board and Mathas tag three creatures. Every removal spell after that draws a card, and the table's best threats are gone by turn 8."),
 ("Horror Show", "Profane Transfusion swaps with the leader and makes a 30-power Horror. Seizan keeps everyone drawing while their life drains away."),
])
add('marina', [
 ("Unholy Annex // Ritual Chamber", "Draw every end step; the second door makes a 6/6 flying Demon that drains."),
 ("Sanctum Weaver", "One mana per enchantment. By turn 5 it taps for 6."),
 ("Bello, Bard of the Brambles", "On your turn, your big enchantments become 4/4 indestructible hasty creatures."),
 ("Dollmaker's Shop // Porcelain Gallery", "Attacks make Toys; the second door makes your creatures as big as your creature count."),
 ("Curse of Disturbance", "Every attack on the cursed player makes Zombies for you."),
 ("Curse of Verbosity", "Every attack on the cursed player draws you cards."),
 ("Curse of Bloodletting", "The cursed player takes double damage."),
 ("Hallowed Haunting", "Enchantments make Spirits, and at seven enchantments the team flies."),
], [
 ("Open House", "Turn 2 Sanctum Weaver, turn 4 Marina finds three Rooms. The doors open one after another while the Weaver pays for them."),
 ("Haunted Parade", "Bello turns your Rooms into 4/4 hasty attackers, Hallowed Haunting gives them flying, and Curse of Bloodletting doubles the damage on one player."),
 ("Demon in the Attic", "Unholy Annex draws every turn, then the Ritual Chamber door opens: a 6/6 flying Demon that drains every end step."),
])
add('mech', [
 ("One with the Machine", "Draw cards equal to your biggest artifact's MV. A Gearhulk turns it into a 6-card refill."),
 ("Tezzeret, Master of the Bridge", "Creatures get affinity, and +2 drains X per artifact you control."),
 ("The Belligerent", "A 5/5 vehicle: every attack makes Treasure and plays from the top."),
 ("Rise and Shine", "Overload: every noncreature artifact you have becomes a 4/4."),
 ("Mighty Servant of Leuk-o", "A 6/6 trample ward vehicle that draws two when two creatures crew it."),
 ("Mechtitan Core", "Combine five artifacts into a 10/10 flying, trampling, lifelinking, hasty titan."),
 ("Skysovereign, Consul Flagship", "A 6/5 flying vehicle that deals 3 to a creature every time it enters or attacks."),
 ("Foreboding Steamboat", "A 5/7 vehicle: everyone exiles two creatures until it leaves."),
], [
 ("Mech Uprising", "Turn 6 Rise and Shine overload: six artifacts become 4/4s, and Tezzeret's +2 drains for all of them next turn."),
 ("Assemble!", "Mechtitan Core eats five artifacts into a 10/10 flying, lifelinking haster, and One with the Machine draws ten off it."),
 ("Full Fleet", "Cultivator's Caravan, The Belligerent and Skysovereign all crewed by turn 7: three big vehicles that dodge sorcery-speed wipes."),
])
add('kotis', [
 ("Quietus Spike", "Deathtouch, and every hit halves their life. With Kotis that's half their life plus that many free spells."),
 ("Saddle of the Cavalier", "+3/+3 and small creatures can't block. Kotis hits for 5 and steals 5."),
 ("Aqueous Form", "Unblockable for 1 mana: the cheapest way to make sure Kotis connects."),
 ("Security Bypass", "Unblockable when attacking alone, and it connives on every hit."),
 ("Mindleecher", "A 5/5 flying mutate: play opponents' top cards when it attacks."),
 ("Gonti, Night Minister", "Combat damage from any of your creatures lets you play their cards."),
 ("Villainous Wealth", "Cast an opponent's top X cards for free."),
 ("Fireshrieker", "Double strike for 2: Kotis's trigger happens twice."),
], [
 ("Fangs Out", "Turn 4 Kotis, turn 5 Aqueous Form: every hit exiles their top cards and casts the best ones free."),
 ("Double Robbery", "Saddle of the Cavalier and Fireshrieker on Kotis: he hits for 5 twice, stealing two piles of 5 cards in one combat."),
 ("Spike to the Heart", "Quietus Spike plus evasion: every swing halves a life total, so a player at 40 is at 10 after two hits."),
])
add('joel', [
 ("Grave Venerations", "Monarch, a creature back every end step, and every death drains."),
 ("Skullclamp", "Equip 1 on a Saproling: it dies and draws two. The best draw engine in the pod."),
 ("Tendershoot Dryad", "A Saproling every upkeep, every player's."),
 ("Mycoloth", "Devours your tokens, then makes a Saproling per counter every upkeep."),
 ("Goblin Bombardment", "Free sacrifice outlet: every token is 1 damage anywhere."),
 ("Slimefoot and Squee", "Makes Saprolings, and brings itself and another creature back."),
 ("The Mycotyrant", "As big as your Fungi and Saprolings, with trample."),
 ("Arnyn, Deathbloom Botanist", "Every small creature dying drains 2, which pays for Ellie's life costs."),
], [
 ("Spore Season", "Turn 3 Skullclamp, turn 4 Tendershoot: every upkeep's Saproling becomes two cards, and Joel grows off every token death."),
 ("Endless Night", "Grave Venerations makes you monarch. Every end step brings a creature back, and Goblin Bombardment turns each death into a drain."),
 ("Fungal Bloom", "Mycoloth devours eight tokens on turn 6. Eight Saprolings an upkeep feed Ellie, and Arnyn drains 2 for each one."),
])
add('turtle', [
 ("Jetmir, Nexus of Revels", "3 creatures: +1/+0 and vigilance. 6: trample. 9: double strike for the whole team."),
 ("Hazel of the Rootbloom", "Taps tokens for mana and copies a token every end step."),
 ("King Darien XLVIII", "Anthem, Soldier tokens, and a sacrifice that makes tokens hexproof and indestructible."),
 ("Beledros Witherbloom", "A 4/4 flier, a Pest every upkeep, and 10 life to untap your lands."),
 ("Academy Manufactor", "Clue, Food and Treasure all at once."),
 ("Foot Chopper", "A flying Ninja: sacrifice it on a hit to draw its power."),
 ("Mycoloth", "Devours tokens, then makes Saprolings every upkeep."),
 ("Boss's Chauffeur", "Enters huge, grows, and dies into Citizens."),
], [
 ("Turtle Parade", "Turn 3 token maker, turn 4 Leonardo, turn 5 Jetmir: every token batch puts counters on the team, and nine creatures means double strike."),
 ("Cowabunga", "Hazel copies a token every end step while Michelangelo makes Food and counters each attack, so the board doubles every two turns."),
 ("Shell Shock", "King Darien makes your tokens hexproof and indestructible in response to a wipe. Next turn Jetmir's 9-creature double strike swings."),
])
add('kykar', [
 ("Zada, Hedron Grinder", "Secret commander: every spell that targets Zada copies onto every creature you control."),
 ("Feather, the Redeemed", "Secret commander: spells that target your creatures come back to hand."),
 ("Balmor, Battlemage Captain", "Every instant and sorcery gives the team +1/+0 and trample."),
 ("Talrand, Sky Summoner", "Every instant and sorcery makes a 2/2 flying Drake."),
 ("Sorcerer Class", "Loots, lets creatures tap for spell mana, and burns at level 3."),
 ("Charmbreaker Devils", "A random spell back every upkeep, and +4/+0 per spell."),
 ("God-Eternal Kefnet", "Copies the spells you draw, and comes back when it dies."),
 ("Crackling Drake", "A flier as big as your spells in the graveyard and exile."),
], [
 ("Zada's Rage", "Eight Spirits out, a pump spell on Zada: it copies onto every creature, Balmor adds +1/+0 and trample on top, and the swing is 40+."),
 ("Feather Storm", "Feather returns a cheap trick every turn. Kykar makes a Spirit per spell and Talrand a Drake per spell: three fliers a turn."),
 ("Kefnet's Gift", "Kefnet copies a drawn wheel or burn spell, Charmbreaker Devils returns it next upkeep, and the flock swings into an empty board."),
])
add('weather', [
 ("Marit Lage's Slumber", "Scry on every snow permanent, and a 20/20 flying indestructible Marit Lage at ten snow permanents."),
 ("Cosmic Crucible", "4 mana every turn, and your first noncreature spell each turn gets copied."),
 ("Cone of Cold", "Taps every opposing creature, usually for two turns."),
 ("Rimefeather Owl", "A flier as big as your snow permanents, 10+ here."),
 ("The Pride of Hull Clade", "A 2/15 wall that gets cheap with big butts, and draws its toughness on a hit."),
 ("Become the Avalanche", "Draw per 4+ power creature, then the team gets +X/+X."),
 ("Ascendant Spirit", "A snow mana sink that grows into a 6/6 flier that draws."),
 ("Abominable Treefolk", "A trampler as big as your snow count that freezes a creature."),
], [
 ("Snow Day", "Turn 2 dork, turn 3 Rime Tender, turn 5 Isu: every land drop is a free snow card off the top, and Marit Lage wakes by turn 7."),
 ("Whiteout Conditions", "Cone of Cold taps every opposing creature for two turns while Rimefeather Owl and Ascendant Spirit fly in unopposed."),
 ("The Long Winter", "Cosmic Crucible copies Become the Avalanche: draw two handfuls and give the team +X/+X twice, then the Abominable Treefolk tramples through."),
])
add('blood', [
 ("Darkstar Augur", "A flier that draws an extra card every upkeep (two with offspring)."),
 ("Lunar Convocation", "End-step drains and Bats, and pay 2 life to draw."),
 ("Valley Questcaller", "Other Bats get +1/+1 and every Bat entering scries."),
 ("Aclazotz, Deepest Betrayal // Temple of the Dead", "A 4/4 flying lifelinker: attacks make everyone discard, and it comes back as a land."),
 ("Etchings of the Chosen", "Bats +1/+1, and sacrifice one to make another indestructible."),
 ("Star Charter", "A flier that digs four for a small creature every end step."),
 ("Momo, Friendly Flier", "A 1-drop flier that makes your fliers cost 1 less."),
 ("Stargaze", "Look at 2X, keep X, lose X life. Zoraline gives it back."),
], [
 ("Bond and Swarm", "Turn 3 Zoraline, turn 4 Valley Questcaller, turn 5 Lunar Convocation: every Bat attack gains life, and every end step drains."),
 ("Night of the Bats", "Darkstar Augur with offspring draws two a turn, Momo makes every Bat cheap, and eight fliers swing on turn 7."),
 ("The Betrayal", "Aclazotz attacks and everyone discards, the lifelink pays for Stargaze, and Etchings keeps the Bats alive through a wipe."),
])
add('dragons', [
 ("Lathliss, Dragon Queen", "A 6/6 flier: a 5/5 Dragon token for each other Dragon, and Miirym copies her too."),
 ("Earthquake Dragon", "A 10/10 flying trampler that costs less per Dragon and comes back to hand."),
 ("Atarka, World Render", "Attacking Dragons get double strike."),
 ("Dragonhawk, Fate's Tempest", "Exiles X cards to play, and the rest burn."),
 ("Drakuseth, Maw of Flames", "A 7/7 flier whose attacks shoot 4, 3 and 3."),
 ("Skyline Despot", "Monarch makes a 5/5 Dragon every upkeep."),
 ("Savage Ventmaw", "Every attack adds six mana to cast more Dragons."),
 ("Dragon's Hoard", "Fixes mana and draws a card per Dragon that entered."),
], [
 ("Double Dragons", "Turn 4 Miirym, turn 5 Lathliss: her copy makes two 5/5s and every Dragon after that makes four bodies."),
 ("Dragon Rider", "Savage Ventmaw attacks, adds six mana, and you cast two Dragons after combat. Miirym copies both."),
 ("Sky on Fire", "Atarka gives every attacking Dragon double strike, and Drakuseth plus its copy shoot 20 damage before blockers."),
])
add('korvold', [
 ("Goblin Bombardment", "Free sacrifice outlet: every token is 1 damage and a Korvold card."),
 ("Kingpin, Wilson Fisk", "Two Treasures on your first sacrifice each turn."),
 ("Priest of Forgotten Gods", "Sacrifice two: a drain, an edict, two mana and a card."),
 ("Academy Manufactor", "Clue, Food and Treasure all at once: three things to sacrifice."),
 ("Deadly Dispute", "Sacrifice for two cards and a Treasure (three cards with Korvold)."),
 ("Lagomos, Hand of Hatred", "A hasty trampler every combat, and a tutor after five deaths."),
 ("Spawning Pit", "A free sac outlet that turns every two sacrifices into a 2/2 to sacrifice again."),
 ("Brass's Bounty", "A Treasure per land: about eight cards with Korvold."),
], [
 ("The Feast", "Turn 5 Korvold, turn 6 Brass's Bounty: eight Treasures, eight sacrifices, eight cards, and a 12/12 flier."),
 ("Pit Stop", "Four tokens go through Spawning Pit for four cards, the two Spawns go through for two more, and Korvold is a 10/10 by the end of the turn."),
 ("Bombs Away", "Goblin Bombardment flings every token; each one draws a card and grows Korvold, and the pings finish a player."),
])
add('robots', [
 ("Iron Man, Master of Machines", "A flier that gets +1/+0 per artifact and draws on attack."),
 ("Kappa Cannoneer", "Ward 4, and it grows and goes unblockable whenever an artifact enters."),
 ("Iron Man, Bleeding Edge", "Copies an artifact spell every turn."),
 ("Edgar, King of Figaro", "Draws a card for every artifact you control (about 8)."),
 ("Tri-Sentinel, Act of Vengeance", "A 7/7 flying menace trampler that shoots a creature per opponent."),
 ("Urza, Prince of Kroog", "Artifact creatures +2/+2, and 6 mana copies an artifact."),
 ("Arcbound Shikari", "A counter on every other artifact creature; every copy does it again."),
 ("Surge Conductor", "Every nontoken artifact entering proliferates: the counters grow every turn."),
], [
 ("Roll Out", "Optimus bolsters every end step while Surge Conductor proliferates on every artifact, so the Robots grow twice a turn."),
 ("Suit Up", "Iron Man, Bleeding Edge copies Kappa Cannoneer; both grow and go unblockable on every artifact, and Urza adds +2/+2."),
 ("Copy Shop", "Two copies of Arcbound Shikari put two counters on the team, and Edgar draws eight off the pile of artifacts."),
])
add('felothar', [
 ("Canopy Gargantuan", "A 7/7 flier: every upkeep, every other creature gets counters equal to its toughness."),
 ("Baldin, Century Herdmaster", "Everything deals damage equal to toughness on your turn, and attacks pump up to 100 creatures."),
 ("Betor, Kin to All", "Draws at 10 total toughness, untaps the team at 20, halves an opponent at 40."),
 ("Doran, Besieged by Time", "Toughness creatures cost less and get +X/+X attacking or blocking."),
 ("Shadrix Silverquill", "A 2/5 flying double striker that hands out gifts every combat."),
 ("MacCready, Lamplight Mayor", "Small-power attackers gain skulk: your walls are nearly unblockable."),
 ("Axebane Guardian", "Taps for one mana per defender."),
 ("Zetalpa, Primal Dawn", "Flying, double strike, indestructible: an 8-toughness wall that hits for 16."),
], [
 ("Wall Street", "Felothar, then Baldin: every wall swings for its toughness, and MacCready's skulk means nothing blocks them."),
 ("Growth Spurt", "Canopy Gargantuan doubles every wall's toughness each upkeep; with Felothar out, that's double the damage."),
 ("Betor's Blessing", "Twenty toughness out untaps the team every end step, and at forty Betor halves an opponent's life."),
])
add('thranduil', [
 ("Elvish Archdruid", "Elves +1/+1, and G per Elf."),
 ("Maralen, Fae Ascendant", "A 4/5 flier: every Elf entering exiles two of an opponent's cards to cast free."),
 ("Elven Chorus", "Cast creatures off the top, and every creature taps for any color."),
 ("Priest of Titania", "G per Elf on the battlefield."),
 ("Lathril, Blade of the Elves", "Hits make Elves, and ten Elves drain 10 from each opponent."),
 ("Voice of the Woods", "Tap five Elves: a 7/7 trampler."),
 ("Rhystic Study", "A card every time someone doesn't pay 1."),
 ("Moment's Peace", "A fog, twice (flashback): two turns of the table's attacks gone."),
], [
 ("Elf Rush", "Turn 1 dork, turn 2 Priest of Titania, turn 3 Archdruid: 8+ mana on turn 4 and Thranduil plus two Elves on the same turn."),
 ("The Elvenking's Court", "Legendary Elves drop one after another; each one draws two with Thranduil, and Maralen casts two of their cards for free."),
 ("Ten Thousand Elves", "Lathril's hits fill the board, Moment's Peace stops the counterattack twice, and tapping ten Elves drains 10 from everyone."),
])
add('vile', [
 ("Jace's Archivist", "Tap: everyone wheels. Every wheel is a burn spell with Vial Smasher out."),
 ("Naktamun Lorespinner // Wheel of Fortune", "Wheel of Fortune, cast again when a hand is small."),
 ("Blood for the Blood God!", "A new hand of eight and 8 damage to each opponent."),
 ("Magus of the Wheel", "Sacrifice: Wheel of Fortune."),
 ("Windfall", "Everyone discards and draws the biggest hand."),
 ("Knollspine Dragon", "A 7/5 flier: discard your hand, draw the damage you dealt."),
 ("Kefka, Dancing Mad", "End step: cast their graveyard cards free (all the cards they just wheeled away)."),
 ("Seizan, Perverter of Truth", "Everyone loses 2 and draws 2 every upkeep."),
], [
 ("Wheel of Misfortune", "Turn 4 Vial Smasher and Ishai, turn 5 Jace's Archivist: every wheel draws seven, and Vial Smasher burns a random opponent for each first spell."),
 ("Blood Money", "Blood for the Blood God! deals 8 to each opponent after a wheel turn of burn; three players at 40 are at 20 by turn 7."),
 ("Kefka's Party", "Windfall empties every hand into the graveyard, and Kefka casts the best of them for free at end step."),
])
add('depala', [
 ("Magda, Brazen Outlaw", "Dwarves +1/+0, and every tapped Dwarf (crewing too) makes Treasure."),
 ("Kíli the Resourceful", "First equip free, and a card when Dwarves or Equipment enter."),
 ("Bruenor Battlehammer", "+2/+0 per Equipment, and the first equip each turn is free."),
 ("Necron Monolith", "A 7/7 flying indestructible vehicle whose attacks make Necrons."),
 ("Sentinel Sarah Lyons", "Haste, team +2/+2 after an artifact enters, and battalion burns."),
 ("An Unexpected Party // At the Door", "Dwarves +2/+2, and the adventure makes X Dwarves."),
 ("Colossus Hammer", "+10/+10, free to equip with Bruenor or Kíli."),
 ("Orcrist, Goblin-cleaver", "+2/+2 trample, and hits make a Treasure per Dwarf."),
], [
 ("Mine Cart Madness", "Turn 3 Depala, turn 4 Magda: every crew makes Treasure, and the Monolith comes down turn 5."),
 ("Hammer Time", "Bruenor equips Colossus Hammer free on a hasty Dwarf: a 15-power swing on turn 5."),
 ("Party at the Door", "An Unexpected Party makes five Dwarves, crews every vehicle, and Magda turns them into ten Treasures."),
])
add('mothman', [
 ("Army of the Damned", "Thirteen 2/2 Zombies, and flashback for thirteen more."),
 ("The Scarab God", "Every upkeep opponents lose life per Zombie; reanimates anything as a 4/4 Zombie."),
 ("Vault 12: The Necropolis", "Rad counters for everyone, then Zombie Mutants equal to all the rad counters."),
 ("Zul Ashur, Lich Lord", "Tap: cast a Zombie from your graveyard."),
 ("Josu Vess, Lich Knight", "Kicked: eight 2/2 menace Zombie Knights."),
 ("Gisa, the Hellraiser", "Zombies +1/+1 and menace, and crimes make more Zombies."),
 ("Screeching Scorchbeast", "A 5/5 flying menace: milled nonland cards make Zombie Mutants."),
 ("Grave Titan", "Two Zombies when it enters and on every attack."),
], [
 ("Night of the Living Dead", "Army of the Damned on turn 8: thirteen Zombies, Gisa makes them 3/3 menace, and The Scarab God drains 13 each upkeep."),
 ("Fallout", "The Wise Mothman spreads rad counters, Vault 12 turns them into a Zombie Mutant army, and the milled cards make more."),
 ("Endless Horde", "Zul Ashur recasts a Zombie every turn and Havengul Runebinder puts a counter on every Zombie each activation."),
])
add('casino', [
 ("Ancient Gold Dragon", "A 7/10 flier: hits roll a d20 for that many Faerie Dragons, and Mr. House makes Robots off it."),
 ("Ancient Copper Dragon", "A 6/5 flier: hits roll a d20 for that many Treasures."),
 ("Component Pouch", "Rolls d20s for counters, then spends them for mana."),
 ("Reckless Endeavor", "Roll two d12: one hits every creature, the other makes that many Treasures."),
 ("Smaug the Magnificent", "A hasty flier: Treasure every upkeep, and attacks deal damage equal to your Treasures."),
 ("Goldspan Dragon", "A hasty flier: Treasure on attack, and Treasures make two mana."),
 ("Hoarding Ogre", "Every attack rolls a d20 for one to three Treasures."),
 ("Chaos Dragon", "A 4/4 flying haster for 3 that rolls on every attack."),
], [
 ("Jackpot", "Mr. House out, Ancient Copper Dragon hits: a d20 roll of 15 makes 15 Treasures, and the roll itself makes Robots."),
 ("Roll the Bones", "Barbarian Class and Wyll roll an extra die and drop the lowest, so every Mr. House roll is 4+ and every die makes a Robot."),
 ("House Always Wins", "Smaug with twelve Treasures out hits for 12. Goldspan turns those Treasures into 24 mana for the next round of dragons."),
])
add('scare', [
 ("Giant Adephage", "A 7/7 trampler that copies itself on every hit."),
 ("Professor Hulk", "A 6/6 trampler that draws as many cards as the damage it deals."),
 ("Hraesvelgr of the First Brood", "A 5/5 flier: noncreature spells make a creature unblockable."),
 ("Goreclaw, Terror of Qal Sisma", "Power 4+ creatures cost 2 less, and they attack with +1/+1 and trample."),
 ("Xyris, the Writhing Storm", "A flier: opponents' extra draws make Snakes, and hits make you both draw."),
 ("Nikya of the Old Ways", "Lands make double mana."),
 ("Cold-Eyed Selkie", "Islandwalk, and hits draw that many."),
 ("Warren Instigator", "Double strike: Illuna mutates on top and hits for 12 in the air."),
], [
 ("Build a Monster", "Turn 6 Illuna mutates onto Warren Instigator: a 6/6 flying, trampling double striker that also flips a free permanent."),
 ("Copycat", "Giant Adephage connects and copies itself; Goreclaw gives the copies trample, and two more connect next turn."),
 ("Brain Food", "Professor Hulk hits for 6 and draws six, and Nikya's double mana casts them all the same turn."),
])
add('modular', [
 ("Helm of the Host", "A hasty token copy of the equipped creature every combat. Gilgamesh copies are nonlegendary, so they keep coming."),
 ("Desert Were-Worm", "+2/+0 per Mountain, and 12 power attacks untap for an extra combat."),
 ("Quietus Spike", "Deathtouch, and every hit halves their life."),
 ("Embercleave", "Flash, cheaper per attacker, +1/+1 double strike trample."),
 ("Maximum Carnage", "Everyone must attack someone else, then RRR, then 5 to each opponent."),
 ("Lavaleaper", "Everything has haste, and basics make double mana."),
 ("Strength-Testing Hammer", "Every attack rolls a d6 for power, and the biggest creature draws."),
 ("Extraplanar Lens", "Imprint a Mountain: every Mountain makes double mana."),
], [
 ("Gilgamesh's Arsenal", "Gilgamesh enters with a haste Equipment from the top six, attacks the same turn, and his attack trigger drops in a second load of gear."),
 ("Spiked Strike", "Quietus Spike plus Embercleave's double strike: the first hit halves their life, the second halves it again."),
 ("Host of Heroes", "Helm of the Host copies Gilgamesh every combat; every copy digs six for more Equipment on entering and attacking."),
])
add('family', [
 ("Archon of Coronation", "A 5/5 flier: monarch, and damage doesn't make you lose life."),
 ("Skyhunter Strike Force", "A flier, and with your commander out the team has melee."),
 ("Bident of Thassa", "Your creatures draw on hits, and you can force their creatures to attack."),
 ("Belladonna Took", "Tokens entering gain life, then draw, then put counters on the team each turn."),
 ("Idol of Oblivion", "Draws when you made a token, and becomes a 10/10."),
 ("Selfless Spirit", "Sacrifice: team indestructible."),
 ("Luminous Broodmoth", "Your creatures without flying come back with flying."),
 ("Kapsho Kitefins", "Every creature entering taps an opposing creature; an offspring copy taps two."),
], [
 ("Family Reunion", "Zinnia out, every 1-power offspring makes a copy, and Skyhunter Strike Force gives the whole flying family melee."),
 ("Tap Them All", "Kapsho Kitefins and its offspring tap two blockers per creature you cast; the fliers swing into an empty board."),
 ("Royal Family", "Archon of Coronation keeps the monarch safe, and Bident of Thassa draws a card for every family member that connects."),
])
add('spider', [
 ("Shelob, Child of Ungoliant", "An 8/8: Spiders get deathtouch and ward, and its victims become Food copies."),
 ("Majestic Myriarch", "Twice your creature count, and it copies every keyword Cosmic Spider-Man gives the team."),
 ("Silk, Web Weaver", "Creature spells make Citizens, and 5 mana gives the team +2/+2 and vigilance."),
 ("Goliath, Mass Manipulator", "Power-up on turn 7: a 4/4 that draws about three."),
 ("Spinneret and Spiderling", "Grows on Spider attacks, and big hits draw."),
 ("Araña, Heart of the Spider", "Attacks put a counter out, and modified hits draw."),
 ("Heroes' Podium", "Legends +1/+1 per other legend, and it digs for legends."),
 ("Biorganic Carapace", "+2/+2, and hits draw per modified creature."),
], [
 ("Spider-Verse", "Cosmic Spider-Man gives every Spider flying, first strike, trample, lifelink and haste; Silk's +2/+2 turns six Spiders into a lethal swing."),
 ("Web of Doom", "Shelob gives every Spider deathtouch and ward: nothing blocks them, and anything they hit becomes Food."),
 ("Mighty Myriarch", "Majestic Myriarch copies all five of Cosmic's keywords and hits as a 14/14 flying, lifelinking first striker."),
])
add('zurgo', [
 ("Mardu Siegebreaker", "Deathtouch haste: copies your creature at each opponent on attack, and Zurgo keeps the Warrior copies."),
 ("Duke Ulder Ravengard", "A creature gets haste and myriad every combat."),
 ("Infantry Shield", "Menace, and mobilize equal to the creature's power. Zurgo keeps the tokens."),
 ("Calamity, Galloping Inferno", "Saddled attacks make two attacking copies."),
 ("Greven, Predator Captain", "Menace, grows with life lost, and sacrifices on attack to draw its power."),
 ("Tectonic Giant", "Attacks burn each opponent for 3 or draw."),
 ("Raiders' Spoils", "Team +1/+0, and Warriors connecting draw."),
 ("Ogre Chitterlord", "Menace, and two Rats on enter and attack."),
], [
 ("The Decree", "Turn 3 Zurgo, turn 4 Infantry Shield: every attack makes Warriors that stay, and the army doubles by turn 6."),
 ("Myriad Mayhem", "Duke Ulder gives Mardu Siegebreaker myriad: copies at every opponent, all Warriors, all kept by Zurgo."),
 ("Spoils of War", "Raiders' Spoils pumps twenty Warrior tokens and every one that connects draws a card."),
])
