"""0.12.143 (Kyle): JP, the Engineer and Flannel_Man share one art pack, so their idles were identical. Build new idle rows out of
their own frames and append them under each sheet (idempotent: re-running rebuilds from the stored original idle):
  JP:       takes a knee: the kneel frames looped (crouched, ready).
  Engineer: bounces a grenade at his hip (toss frames). Only Flannel_Man keeps a hand in his pocket.
Flannel_Man keeps the original idle."""
import json
from PIL import Image
A='/home/claude/pod2/'
at=json.load(open(A+'crawl_atlas.json'));U=at['units']
PLAN={'jp':[('kneel',2),('kneel',3),('kneel',4),('kneel',5),('kneel',5),('kneel',4),('kneel',3),('kneel',4)],
      'eng':[('toss',0),('toss',0),('toss',1),('toss',1),('toss',0),('toss',0),('toss',1),('toss',0)]}   # bouncing a grenade at his hip (no hand in pocket: that's Flannel_Man's)
for k,seq in PLAN.items():
    u=U[k];orig=u.get('idle0',u['idle']);u['idle0']=orig
    im=Image.open(A+f'crawl_{k}.png').convert('RGBA')
    base_h=orig.get('sheetH',None) or max(v['y']+v['fh'] for n,v in u.items() if isinstance(v,dict) and v.get('img')==k and n not in('idle','idle0'))
    fw,fh=orig['fw'],orig['fh']
    sheet=Image.new('RGBA',(max(im.width,fw*len(seq)),base_h+fh),(0,0,0,0));sheet.alpha_composite(im.crop((0,0,im.width,base_h)),(0,0))
    for i,(row,f) in enumerate(seq):
        r=u[row] if row!='idle' else orig
        sheet.alpha_composite(im.crop((r['x']+f*fw,r['y'],r['x']+(f+1)*fw,r['y']+fh)),(i*fw,base_h))
    sheet.save(A+f'crawl_{k}.png',optimize=True)
    new=dict(orig);new.update(y=base_h,n=len(seq),x=0);new['sheetH']=base_h;u['idle']=new;orig['sheetH']=base_h
    print(k,'new idle row at',base_h,'frames',len(seq))
json.dump(at,open(A+'crawl_atlas.json','w'))
