"""Writes the numbered rule documents (01-12) into the zip folder.
Prose is written here; every formula's exact code is pulled live from formulas.py so the docs never drift."""
import inspect, sys, json
sys.path.insert(0, '/home/claude/pod2')
import formulas as F
import plan_tags as P

def code(*names):
    out = []
    for n in names:
        obj = getattr(F, n)
        if callable(obj):
            out.append(inspect.getsource(obj).rstrip())
        else:
            out.append(f'{n} = {obj!r}')
    return '\n\n'.join(out)

HDR = lambda n, t: f"POD RUNDOWN {{V}} - {n:02d} {t}\n" + '=' * 70 + '\n'

DOCS = []

DOCS.append(('01_Overview_and_Workflow', 'OVERVIEW AND WORKFLOW', """
WHAT THIS IS
  Every card in every deck gets TAGS: calls to the formulas in files 02-10 (ramp(...), draw(...), tall(...)).
  Each formula returns points for one of 9 stats. A card can have several tags (one per thing it does).
  Card points add up per stat, the deck-level checks in each stat file adjust them, and file 11 turns
  points into the 1-15 ratings and the /90 total.

THE 9 STATS (one file each)
  02 Mana         ramp, cheating costs, lands and fixing
  03 Cards        card draw and card advantage from anywhere
  04 Consistency  tutors, selection, Hit-Rate, Plan B
  05 Threats      big bodies, tokens, team pumps, swing cards
  06 Finish       ways to end the game: burst, extra combats, alt wins, damage doublers
  07 Reach        evasion, giving evasion, drain/burn around blockers
  08 Interaction  removal, wipes, counterspells, denial
  09 Survival     protection, recursion, rebuilding, life and blockers
  10 Politics     deals, deterrents, direction (who gets hit), salt
  11 Ratings, groups, totals, salt and Needs Repair
  12 Plan Tags and Synergy Groups (per deck)

ADDING A NEW DECK (the order I follow)
  1. Save the decklist. Pull full card text ONLY for cards not already saved (card_text.json). Never re-fetch a saved card.
     Also save EDHREC salt and inclusion % and Scryfall MV / type / rarity / P/T for new cards.
  2. Write decks/<key>.py: META (deck name, icon, owner, colors, commander(s), secret commander(s)) and TAGS:
       'Card Name': T('short note', formula(...), formula(...)),
     Lands get land(...) (and select/ramp if they do more). Basics need no entry.
  3. Add the deck's Plan Tag rules (C and T) and 3-5 synergy groups to plan_tags.py (file 12).
  4. Run the score, then review card by card (repeat until a pass needs no changes):
       - every effect on the card has a tag; nothing is tagged that the card doesn't do
       - X costs use the deck's turn-7 mana; conditional effects use cond=0.3-0.8
       - commanders are tagged like any card
  5. Write the judge.py read (1-5 + why + fix idea) for likely Needs Repair cards, and the site takeaway text.
  6. Build the site, test, publish, rebuild the zip.
  NOTE on Crypt Crawl distances: when Kyle gives a distance in pixels he means SCREEN pixels. The normal game is 1152px wide
  for 384 world px, so divide his number by 3 (800px -> 267 world, 250px -> 83 world).
  7. LAST, once everything above is done: give the deck its Crypt Crawl INSPIRATION bonus.
     Add one entry to INSP in crawl_src.js:  'Deck Name':{o:'Owner',why:'one line tying it to the deck',mod:{...},sl:{...}}
     How to pick it (Kyle's rules):
       - Tie it to what the deck is best at, using its final stats and theme (the biggest ramp deck in the pod gets energy regen,
         top Survival gets armor, top Finish gets melee damage, evasive/flying decks get dodge, lifelink gets life steal, and so on).
       - Keep it small, and make it UNIQUE: no two decks may have the same bonus. If the obvious stat is taken, give two smaller
         stats instead of one (each smaller than a single-stat bonus would be).
       - Sizes for one stat (doubled in 0.12.4 at Kyle's request): Accuracy +8-12, Crit +4-6%, Dodge +2-4%, Armor +4-6, Stamina +2,
         Luck +4-10, XP +12%, Knockback resist +20%, Max energy +20-24, Energy regen +0.5-1.5/s (base is 5/s), Life steal +4-6%,
         Move +12%, Melee/Ranged damage +10-20%, Melee/Ranged speed +16-20%, Melee knockback +30.
         Slider moves are +-2 (a move that would go past 0 or 10 doesn't happen).
         Slider moves can go EITHER way: the low end of a slider isn't worse, just different (Kyle). Most decks give a stat AND a
         slider move that fits the deck's personality (e.g. walls -> Calculated, dice/casino -> Showoff, thieves -> Selfish).
       - Every stat used needs a plain-language line in INSP_HELP (shown to players under the pick).
       - Any stat on the character sheet can be used. If one isn't in INSP_LABEL yet, add it there and apply it in Game.recalc().
       - Re-check that every deck's bonus is still unique, then rebuild the crawl (build_crawl.py) and the site.

CARD HELPERS THAT CAN BE USED IN ANY STAT
""" + code('scale', 'second_life', 'rebound', 'body', 'feeds') + """

COMMANDERS
  Commanders score like any other card (no multiplier). Two commander-only rules:
  - Commander engine (file 04): a cheat effect on a commander counts as Consistency, not Mana.
  - Commander copy engine (file 05): copy_engine() on a commander multiplies its copied creatures' Tall threat.
  - 0.12.89 Commander engine (Kyle): a commander's own repeatable ability (activated, or every turn / every attack with no other
    card needed) counts x2, since it's always on hand from the command zone. List the entry kinds per deck in META['cmd_engine'].

AUTOMATIC MECHANIC TAGS (0.12.89, read from card text in score.py, so every deck gets them the same way)
  - Convoke (0.12.91): tag a convoke card at the REAL cost it's usually cast for (its MV minus what the board pays), and
    the scorer adds +0.06 Mana per mana the board pays (mana left over for other spells). Bodies = creatures + 2 per token maker. 60+ bodies: you pay about 2 at most;
    40+: you pay about 3; 25+: the board pays 2; fewer: 1.
  - Ninjutsu / Sneak: Reach as if unblockable for its own power x0.6 (needs an unblocked attacker), +0.10 Survival (returns the attacker).
  - Job select: +0.08 Threats, +0.02 Survival (the 1/1 Hero it makes and attaches to).
  - Ward N: +0.08 + 0.05 x N Survival (max 0.30); Ward with a non-mana cost counts as Ward 3.
  - 0.12.90 Unblockable (and protection from creatures) also adds Finish: evasive 0.05 + 0.025 x power (max 0.30); gives_ev 0.05 + 0.02 x power
    (+0.10 if repeatable, x0.75 one-off, max 0.35); ninjutsu x0.6.
  - Evasion values (0.12.88): protection from creatures 1.3, unblockable 1.25, shadow 0.8, flying 0.7, menace 0.7, trample 0.5, landwalk 0.4.
"""))

DOCS.append(('02_Mana', 'MANA', """
WHAT COUNTS
  Ramp (rocks, dorks, land ramp, Treasure), cost reducers (boost=True), cheating cards into play,
  lands (extra colors, untapped or not), fixing.

FORMULAS
""" + code('CF', '_mvp', 'ramp', 'fixing', 'cheat', 'land') + """

TAGGING NOTES
  - kind 'E' = every turn, 'L' = one-off but lasting (a land), 'T' = one-off temporary (Treasure burst, rituals).
  - Cost reducers: ramp(amount, mv, boost=True). A reducer for one card type = scale it.
  - Lands: land(extra colors, deck colors C, entry 'U'/'T'/chance untapped). Snow-Covered basics are basics.
  - Cheat on a COMMANDER moves to Consistency (see 04). odds=0.5 when an opponent picks.

DECK-LEVEL CHECKS (Mana)
  - Land count: 36+ lands, or 33+ with 12+ ramp cards: +0.5. Under 33 lands: -0.5.
  - Untapped share: 75%+ of lands usually untapped: +0.25. Under 50%: -0.25.
  - Color strain: needs 5 x (colors - 1) fixing sources; -0.25 per 3 missing.
  - Land drops (goldfish sim): 70%+ games with 5 lands by T6 and 7 by T8: +0.75; 70%+ with 5 by T6: +0.5.

RATING
  Mana uses a FIXED divide of 4.00 (not second-best = 10), so strong ramp decks can pass 10.
"""))

DOCS.append(('03_Cards', 'CARDS', """
WHAT COUNTS
  Drawing cards, card advantage from second hand (graveyard, exile, top of library), opponents' cards,
  wheels, and Second Life value (a card used again).

FORMULAS
""" + code('draw') + """

TAGGING NOTES
  - src 'H' = from your hand/library normally, 'S' = second hand (graveyard, exile, top), 'O' = opponents' cards.
  - eng=1 for a repeating engine (each turn / each trigger). restr=1 if it needs a condition (connect, sacrifice).
  - sym=1 if opponents also draw. Second Life (file 01) adds +0.15 Cards for the extra use.
  - Cards often benefits from synergy groups and Plan Tags routed here (file 12).
"""))

DOCS.append(('04_Consistency', 'CONSISTENCY', """
WHAT COUNTS
  Tutors, card selection (scry, surveil, loot, dig), how often the deck sees its plan cards (Hit-Rate),
  how the deck works without its commander (Plan B), and commander engines.

FORMULAS
""" + code('tutor', 'select') + """

TAGGING NOTES
  - tutor dest: 'top', 'hand', 'gy' (graveyard decks, same value as hand), 'bf' (battlefield).
    reach: 'n' narrow, 't' a type, 'a' anything. count = cards found.
  - Selection on lands: onland=1 (temples).

COMMANDER ENGINE
  A cheat effect on the commander or secret commander is the deck's planned strategy, always available, so its
  value counts here instead of Mana. If it repeats (eng=1), every Plan Tag C card adds +0.5 x odds to Hit-Rate.

DECK-LEVEL CHECKS (Consistency)
  - Hit-Rate: K = plan-card weight (both Plan Tags 1, one tag 0.5, +0.25 Second Life, +free-drop bonus;
    tutors 1, selection 0.5). +3 x P(see 2 of K in your first 10 cards) + 1 x P(see 3).
  - Plan B: KB = cards with the deck-plan tag (T). +1.5 x P(see 2 of KB in 10 cards).
"""))

DOCS.append(('05_Threats', 'THREATS', """
WHAT COUNTS
  Big creatures (Tall), token makers (Wide), team pumps (Board), noncreature must-answers, Swing cards
  that flip a game, small evasive creatures (Quick Air).

FORMULAS
""" + code('tall', 'nc_threat', 'wide', 'board', 'swing', 'bloodthirst', 'copy_engine') + """

TAGGING NOTES
  - tall(power, mv): needs power 4+ (or lvl 'B'). lvl 'P' pressure, 'B' bomb. hard=1 hard to remove. cond for conditions.
    Mana penalty: -0.08 per MV above 3. Use effective MV for affinity / cost reduction.
  - wide(power per batch, mv, eng=1 if every turn). board(boost, creatures it hits, mv).
  - swing size S/M/L for cards that can flip the standing of a game (life swaps, mass copies, steal everything).

AUTOMATIC CARD RULES
  - Quick Air: an evasive creature that isn't a Tall threat gets 0.10 + 0.05 x power (max 3) + 0.10 x (3 - MV, min 0).
  - Commander copy engine: Plan Tag C creatures' Tall entries x (1 + (mult - 1) x odds). Miirym = x1.5.
  - Body floor: a creature scoring under 0.5 total gets a small body score (attacker here, blocker in Survival).

DECK-LEVEL CHECKS (Threats)
  - Threat variety: 4+ kinds (Tall, Wide, Board Power, Noncreature, Commander) +1; 1 or fewer -1.
  - Wide saturation: Wide points past 10 count half.
  - Air density: +0.60 x (number of Quick Air creatures / their average MV).

RATING
  Threats divide = second-best deck's points / 11 (0.10.19, same as every stat).
"""))

DOCS.append(('06_Finish', 'FINISH', """
WHAT COUNTS
  Ways to end the game: burst damage, extra combats, extra turns, damage doublers, overruns,
  alternate wins, combo pieces (finite, in-deck only), alpha-strike enablers (tap all blockers).

FORMULAS
""" + code('_dmg', 'finish', 'pump') + """

TAGGING NOTES
  - Pump Equipment and Auras (0.10.16) use pump(boost, mv, equip=cost or aura=1, ds, dbl, base, protects):
    Board Power on one creature in Threats, +0.15 Survival for Equipment (it moves on), Auras x0.8 (2-for-1 risk)
    unless they protect themselves, and a Suit Up finisher when one suited-up creature hits for 6+.
    base = the power of the creature the deck usually suits up (3 default; Depala's Dwarves 4, Kotis 5, Felothar walls 4 by toughness).
  - Utility gear is not a finisher (0.12.0, Kyle): the Suit Up finisher needs boost 3+, double strike or a damage doubler.
    Every Equipment/Aura is tagged by what it really does: a keyword it grants = gives_ev/survive/etc., a small or
    no power boost = pump(1-2) or no pump at all, mana/land = ramp, tokens = wide. Never count a card twice in one stat.
  - typ: 'Burst', 'Extra Combat', 'Extra Turn', 'Damage Doubler', 'Overrun', 'Alt Win', 'Combo Piece'.
  - amt = damage it adds in a typical swing. sym=1 if it helps opponents too. cond for setup.
  - Infinite combos never count. Cards from other decklists never combine.

  - Suit Up stacking (0.12.1): only the first four Suit Up finishers count fully; #5-8 count x0.5, #9+ x0.25.

DECK-LEVEL CHECKS (Finish)
  - Closer on time: finishers = cards with 0.3+ Finish points. +0.75 x P(see one in your first 13 cards).
  - Suit-up stack (0.10.16): 4+ pump Equipment/Auras and any double strike sources: +0.25 per double strike card (max 6) x min(1, pumps/8).
  - Free equips (0.10.16): a deck with cards that skip, cut or auto-attach equip costs gets every pump's equip-cost penalty back.
  - Finish divide: second-best deck = 11 (same as every stat since 0.10.19).
"""))

DOCS.append(('07_Reach', 'REACH', """
WHAT COUNTS
  Getting damage through: evasive keywords on your own creatures, giving evasion to others,
  and drain / burn / poison / mill that skips combat.

FORMULAS
""" + code('EV', 'evasive', 'gives_ev', 'drain') + """

TAGGING NOTES
  - EV levels: unblockable 1.0, shadow / small-can't-block 0.8, flying 0.7, menace 0.6, trample 0.5, landwalk 0.4.
  - evasive(power, kind) on any creature with the keyword (two=1 if it has two). gives_ev(power it lets through, kind, mv).
  - drain(damage per cycle across the table, mv); poison counts 3 each, mill counts half.
  - Haste enablers can use gives_ev(0, 'fly', mv, eng=1, label='Reach: team haste').
"""))

DOCS.append(('08_Interaction', 'INTERACTION', """
WHAT COUNTS
  Spot removal, board wipes, counterspells, denial (discard, stax, taxes, hate), tap-downs (cond 0.6).

FORMULAS
""" + code('REM', 'answer') + """

TAGGING NOTES
  - rem: bounce, damage, edict, destroy, exile, steal, steal_eot. hits: 'c' creature, '2' two types, 'any'.
  - kinds = letters it can answer: c creature, a artifact, e enchantment, p planeswalker, l land, g graveyard, s spell.
  - Tap-downs / stun: answer(..., 'bounce', cond=0.6). Lockdown auras: 'destroy' with cond 0.75.

AUTOMATIC CARD RULES
  - Later wipes: the first wipe counts full, every other wipe x0.6.

DECK-LEVEL CHECKS (Interaction)
  - Coverage: answers 4+ of creatures/artifacts/enchantments/planeswalkers/graveyards/spells +1; creatures only -1.
  - Answer on time: +1.0 x P(hold at least one answer by turn 4).
"""))

DOCS.append(('09_Survival', 'SURVIVAL', """
WHAT COUNTS
  Protection (hexproof, indestructible, sac outlets), recursion (return from graveyard), rebuilding,
  coming back, life gain, fogs, big blockers.

FORMULAS
""" + code('survive') + """

TAGGING NOTES
  - prot1 one creature, protall the team, ownkw the card protects itself (indestructible/hexproof/ward body).
  - ret = cards returned; mass / masssym = mass recursion (one-sided / symmetric); comeback = comes back itself.
  - life / lifeoneoff in points of life; tough/bdt/bfly for blockers (deathtouch / flying blockers).

AUTOMATIC CARD RULES
  - Vehicles: every Vehicle gets +0.15 Survival (dodges creature wipes).
  - Body floor blocker part (see 05).
"""))

DOCS.append(('10_Politics', 'POLITICS', """
WHAT COUNTS (three levers)
  Deals: group hug, votes, monarch, gifts, counterspells as leverage.
  Deterrents: pillowfort, taxes, punishers.
  Direction: goad, redirect, aiming removal at whoever you choose.

FORMULAS
""" + code('politics', 'bargain') + """

AUTOMATIC CARD RULES
  - Aim: single-target removal gets +0.10 Politics (Direction), up to 8 cards per deck.
  - Counterspell leverage: +0.15 Politics (Deals), up to 5 cards per deck.

DECK-LEVEL CHECKS (Politics)
  - Levers: +0.5 for each lever (Deals, Deterrents, Direction) with 3+ cards.
  - Salt: deck salt under 20 +1, 20-40 0, 40-60 -1, over 60 -2.

RATING
  Politics is rated on the SQUARE ROOT of its points (then the usual divide).
"""))

DOCS.append(('11_Ratings_Groups_and_Repair', 'RATINGS, GROUPS, TOTALS, SALT AND NEEDS REPAIR', """
FROM POINTS TO RATINGS
  - Each stat's points = sum of card points + the deck-level checks in that stat's file.
  - Divide (0.10.19): the second-highest deck's points = 11 (rating = points / divide, rounded half up),
    so the top one or two decks in every stat go over 10. Exception: Mana fixed divide 4.00;
  - Ratings: minimum 1, maximum 15.

GROUPS AND TOTAL
  Engine = Mana + Cards + Consistency; Offense = Threats + Finish + Reach; Defense = Interaction + Survival + Politics.
  Each group /30; a rating's points above 10 count half. Total = the three groups, /90.

PLAN TAG BONUS (every stat, see 12)
  A card with Plan Tag C (works with the commander) or T (fits the deck plan) gets +0.15 (one-off) or +0.25
  (repeating), +0.05 if both tags. It goes to the card's own best stat unless the deck routes it.

SYNERGY GROUPS (see 12)
  +0.005 per other card in the same group, max +0.15 per group, max 2 groups per card.

SALT
  Sum of each card's EDHREC salt; lands that only make mana count 0. Shown next to the total, not part of it
  (only the Politics salt check uses it).

NEEDS REPAIR (Garage), 0.12.0 method (Kyle's rules)
  Picking the 5 weak links per deck (hand-picked, repair_data.py):
    - Start from the deck's game plan and its lowest stats: what is the deck missing?
    - A card is weak when it does little for this deck's plan, is slow or narrow next to what it could be, or only
      fills a job a better card does. Use the score rank and EDHREC inclusion % as a guide, not the answer.
    - Never list a card I rate good or great (4-5), and never list a deck's key engines (e.g. Skullclamp in an
      aristocrats deck).
    - Do NOT flag removal or politics just because it's off-plan: the pod is light on both, so keep them when able.
  - 4 picks per deck (0.12.1). Check both faces of double-faced cards against the deck before suggesting a card.
  - One-time payoffs (Power-up, Exhaust, demonstrate, flashback, an activate-only-once ability) get a turn-7 check: cast it on
    turn 7 (or topdeck it that turn), use the ability, and score what that really does in this deck.
  - Think about whether the deck NEEDS to push damage through (a commander with a combat-damage trigger): evasion and
    double strike on that commander are worth more there.
  The 4 swaps per weak card: two Super budget (under about $2.50), one Medium ($5-20), one Any cost.
    - Swaps should round out the deck's weaknesses or improve its plan, not only add removal. Pick what the deck needs
      (draw, ramp, finish, protection or removal) for that slot.
    - Source: the commander's EDHREC page (inclusion % and synergy %), filtered to cards that do the job, then my own
      picks where EDHREC has nothing fitting. The best true upgrade matters more than variety; the same card can be
      suggested for several decks if it really improves each one.
    - Every swap: in the deck's colors, Commander-legal, not already in the list, not repeated inside one deck.
      Prices from Scryfall (cheapest printing where checked).

GENERAL RULES FROM KYLE (all decks)
  - Keep removal and politics cards in when you can; the pod is weak in both.
  - When Kyle says what matters for ONE deck, that's for that deck's plan only (see the deck notes in file 12),
    not a rule for every deck.

OWNERS
  Cheez's decks get 🧀 after the name, Leon's decks get 🪼.
"""))

DECK_NOTES = {   # deck-specific calls from Kyle (they apply to that deck only)
  'kotis': "Kotis has to connect: evasion (flying, unblockable) and double strike are key. Double strike doubles his steal trigger.",
  'korvold': "Any free, repeatable sacrifice outlet is on plan (Spawning Pit, Goblin Bombardment): every sacrifice is a card.",
  'mathas': "Bounty is a subtheme (keep Termination Facilitator). Spell copies (Cursed Recording) can copy a big drain or swap.",
  'thranduil': "Only legendary Elves trigger Thranduil's draw; check before suggesting an Elf cut. Fogs like Moment's Peace are strong here.",
  'robots': "The deck runs few lands, so Planetary Annihilation barely hurts the land base but kills dorks. +1/+1 counters and copies are a subtheme (Arcbound Shikari, Surge Conductor).",
  'blood': "Don't suggest cutting Bats unless there are plenty of Bats and enough draw to find more.",
  'family': "Zinnia gives every creature spell an offspring copy: creatures with strong enter or attack triggers are worth double. Kapsho Kitefins is removal once copied.",
  'marina': "Keep enchantment density high: an enchantment cut should be replaced by an enchantment.",
  'weather': "Themed around a mythic winter storm: swaps lean toward snow/ice/storm cards, but don't have to be. Snow Devil stays for its name; prefer cutting off-theme cards (like Urban Evolution) first.",
  'scare': "Build a big creature: a mutate onto a double striker gives the whole pile double strike.",
  'zurgo': "Zurgo keeps Warrior tokens, so 'sacrifice at end of turn' tokens mostly stay. Copy makers are on plan.",
  'dragons': "Miirym wants a full hand of Dragons; prefer cutting non-Dragons unless the deck draws enough.",
  'mech': "Tezzeret's Gatebreaker gets better with more ramp; lean toward ramp swaps.",
  'mothman': "Havengul Runebinder puts a counter on every Zombie; Vengeful Dead scales with a big Zombie board.",
  'casino': "Attempted Murder stays (removal, and rolling a pile of dice is the fun). Any die roll is good for Mr. House, and d20 cards are the best dice cards (bigger die = better roll). Keep Arcane Signet; "
            "cut the weakest Treasure maker before it. Knuckles is a proxy, so it stays out. The deck is named Dice Boys Casino.",
  'joel': "Skullclamp is a core draw engine for the aristocrats plan; never list it as a weak link.",
  'modular': "Gilgamesh is the main commander; the other legends are swap-in commanders to lower the bracket (Freya the weakest). Haste Equipment is key: Gilgamesh's enter trigger can attach it, so he attacks (second trigger) the turn he lands.",
  'robots': "Rebuilt in 0.12.0: +1 Island, +1 Plains, cut Crater and Fields.",
}

def plan_doc():
    lines = ["""
PLAN TAGS (per deck)
  C = works alongside the commander(s).  T = fits the deck's main plan beyond the commander.
  Decided from each card's saved text with the rules below, plus hand calls (ADD / DROP).
  Hit-Rate and Plan B (file 04) and the Plan Tag bonus (file 11) use these.
"""]
    for k, r in P.RULES.items():
        lines.append(f"  [{k}]\n    C: {r['C'][0]}\n    T: {r['T'][0]}")
        a = P.ADD.get(k, {}); d = P.DROP.get(k, {})
        for t in ('C', 'T'):
            if a.get(t): lines.append(f"    added by hand to {t}: {', '.join(sorted(a[t]))}")
            if d.get(t): lines.append(f"    removed by hand from {t}: {', '.join(sorted(d[t]))}")
        if P.PLAN_STAT.get(k): lines.append("    Plan Tag bonus routed: " + ', '.join(f"{t} -> {st}" for t, st in P.PLAN_STAT[k].items()))
        if DECK_NOTES.get(k): lines.append("    Kyle's notes for this deck: " + DECK_NOTES[k])
    lines.append("\nSYNERGY GROUPS (per deck): name -> stat the bonus goes to")
    for k, gs in P.GROUPS.items():
        lines.append(f"  [{k}] " + '; '.join(f"{g} -> {st}" for g, _, st in gs))
    return '\n'.join(lines) + '\n'

DOCS.append(('12_Plan_Tags_and_Synergy', 'PLAN TAGS AND SYNERGY GROUPS', None))

def write(D, V):
    for i, (fn, title, body) in enumerate(DOCS, 1):
        if body is None: body = plan_doc()
        open(f'{D}/{fn}.txt', 'w').write(HDR(i, title).replace('{V}', V) + body.lstrip('\n'))
    return [d[0] for d in DOCS]
