import os, shutil, subprocess, sys
V = sys.argv[1]
base = '/tmp/claude-0/zipout'; D = f'{base}/Pod_Rundown_{V}'
shutil.rmtree(base, ignore_errors=True); os.makedirs(D + '/50_Code/decks')
subprocess.run(['python3', 'make_docs.py', D, V], check=True, stdout=subprocess.DEVNULL)
import rules_docs
rules_docs.write(D, V)
import glob as _g
os.makedirs(D + '/Rules', exist_ok=True)
for _f in _g.glob(D + '/[01][0-9]_*.txt'):
    if not _f.endswith('00_READ_ME_FIRST.txt'): shutil.move(_f, D + '/Rules/')
open(f'{D}/00_READ_ME_FIRST.txt', 'w').write(f"""POD RUNDOWN {V} - READ ME FIRST
=================================================
Read and process these files in number order:

  00_READ_ME_FIRST.txt                  this file: the order, and the rules for using the files
  Rules/ (read 01-12 in order)
    01_Overview_and_Workflow.txt        how scoring fits together, and the steps for adding a new deck
    02_Mana.txt ... 10_Politics.txt     one file per stat: what counts, the exact formulas, tagging notes,
                                        automatic card rules and deck-level checks for that stat
    11_Ratings_Groups_and_Repair.txt    points -> ratings, divides, groups, total, salt, Plan Tag bonus, Needs Repair
    12_Plan_Tags_and_Synergy.txt        every deck's Plan Tag rules (C/T) and synergy groups
  01_HOW_TO_UPDATE_AND_ZIP_IT.txt       how to build, publish and back up the site and game, and what 'Zip it' means
  Deck_Lists/<player>/<deck>/           plain_list.txt (the list as sent), scoring_tags_*.py (the tagged version), full text + tags
  Crypt_Crawl/                          the game source, build script and the to-do list
  Player_Decks/Kyle, /Cheez, /Leon, /Eddie      one file per deck (numbered 20+ by pod rank, best total first). Each has: deck header (ratings, points,
                                        deck-level checks), the site takeaway text, then every card with
                                          Card name
                                            INFO / ROLE / NOTE / TAGS / TOTAL   (the info and tags I built)
                                            CARD TEXT                           (the full official card text, no flavor)
  50_Code/                              the scoring engine (Python) and data files that build the website.
                                        Not numbered on purpose: the code imports them by name.

RULES FOR NEXT TIME
  - Card text: every card already has its full text in its deck file (and in 50_Code/card_text.json).
    Do NOT look card text up on the internet again for these cards. Only look up a card that isn't saved yet.
  - Tags are written as the formula calls (TAGS line), so a rule change = edit the formula and re-run.
  - Plan Tags (C = works with the commander, T = fits the deck plan) are shown on each card's ROLE line.
  - Needs Repair: follow the 0.12.0 method in Rules/11 (plan and weakness first, 4 swaps per card: 2 super budget,
    1 medium $5-20, 1 any cost, EDHREC-backed). Don't flag removal or politics just for being off-plan.
  - Equipment/Auras are tagged by what they do; utility gear (no keyword, small or no boost) is not a finisher (Rules/06).
  - Deck-specific calls from Kyle live with that deck (Rules/12, "Kyle's notes"); they are not pod-wide rules.
  - Network: if the shell can't reach Scryfall/EDHREC, use the desktop app's built-in browser at api.scryfall.com
    (batch /cards/collection, 75 names per call) and json.edhrec.com/pages/commanders/<slug>.json.
""")
for f in ['repair_data', 'hh_dream', 'formulas', 'score', 'build_data', 'build_site', 'make_docs', 'make_zip', 'plan_tags', 'judge', 'takeaways_text', 'addtag', 'rules_docs', 'make_skull', 'make_bonepile', 'make_deaths', 'make_sky', 'stat_page', 'sim_data', 'story_kit', 'pod_outcomes', 'battler_data', 'rig', 'make_crawl_art', 'make_crawl_bg2', 'build_crawl', 'add_lands', 'make_units', 'make_crawl_bg2']:
    shutil.copy(f + '.py', f'{D}/50_Code/')
for f in os.listdir('decks'):
    if f.endswith('.py'): shutil.copy('decks/' + f, f'{D}/50_Code/decks/')
for f in ['card_text.json', 'inclusion.json', 'pt.json', 'raw_lists.json', 'fetch_order.json', 'all_names.json', 'card_info.txt', 'template.html', 'notes.html', 'pod_outcomes.json', 'sim_engine.js', 'sim_run_all.js', 'piss-boy.jpg', 'treasure.jpg', 'card-back.jpg', 'faces.png', 'battler_data.json', 'crawl_atlas.json', 'crawl_src.js', 'crawl_ui.js', 'crawl.js', 'crawl.png', 'crawl_bg.png', 'crawl_units.png']:
    shutil.copy(f, f'{D}/50_Code/')
shutil.copytree('assets', f'{D}/50_Code/assets')
os.makedirs(f'{D}/50_Code/tools', exist_ok=True)   # 0.12.1: Needs Repair tools (picks, EDHREC-backed swap generator) and their data
for f in ['repair_v2.py', 'repair_v3.py', 'repair_edh.py', 'repair_fix.py', 'repair_draft.py']:
    shutil.copy('/home/claude/work/' + f, f'{D}/50_Code/tools/')
for f in ['edh_info.txt', 'edh_cand.json', 'edhrec_top.txt', 'swapinfo.txt', 'cmdr_ci.json']:
    shutil.copy('/home/claude/data/' + f, f'{D}/50_Code/tools/')
shutil.copy('CRYPT_CRAWL_HANDOFF.md', f'{D}/')   # backdrop layers (Ansimuz packs + our edited paths)
# ---- 0.12.83 (Kyle: "Zip it") extra folders so a new chat can pick everything up from this one zip
import json as _json, importlib as _il, sys as _sys
_sys.path.insert(0, 'decks')
_raw = _json.load(open('raw_lists.json'))
_OWN_LABEL = {'Kyle': 'Kyle (Me)', 'Cheez': 'Cheez', 'Leon': 'Leon', 'Eddie': 'Eddie'}
import score as _score
for _k in _score.DECKS:
    _M = _il.import_module(_k).META
    _o = _OWN_LABEL.get(_M['owner'], _M['owner']); _safe = _M['deck'].replace('/', '-').replace(':', '')
    _dd = f"{D}/Deck_Lists/{_o}/{_safe}"; os.makedirs(_dd, exist_ok=True)
    with open(f"{_dd}/plain_list.txt", 'w') as _f:   # the plain list, like the ones Kyle sends
        _f.write(f"// {_M['deck']} ({_M['owner']})\n// Commander: {' + '.join(_M['cmdr'])}\n")
        for _c in _raw[_M['file']]:
            _f.write(f"{_c['q']} {_c['name']}" + (f"  // {_c['note']}" if _c.get('note') else '') + "\n")
    shutil.copy(f"decks/{_k}.py", f"{_dd}/scoring_tags_{_k}.py")   # the tagged version the scorer uses
    _pd = f"{D}/Player_Decks/{_M['owner']}"
    if os.path.isdir(_pd):
        for _x in os.listdir(_pd):
            import re as _re
            if _re.sub(r'[^a-z0-9]', '', _x.split('_Deck_', 1)[-1][:-4].lower()) == _re.sub(r'[^a-z0-9]', '', _M['deck'].lower().replace('&', 'and')):
                shutil.copy(f"{_pd}/{_x}", f"{_dd}/full_card_text_and_tags_{_x}")
os.makedirs(f"{D}/Crypt_Crawl", exist_ok=True)
for f in ['crawl_src.js', 'crawl_ui.js', 'build_crawl.py', 'make_units.py', 'battler_data.py']:
    if os.path.exists(f): shutil.copy(f, f"{D}/Crypt_Crawl/")
if os.path.exists('/tmp/devbranch/CRAWL_TODO.md'): shutil.copy('/tmp/devbranch/CRAWL_TODO.md', f"{D}/Crypt_Crawl/CRAWL_TODO.md")
open(f"{D}/01_HOW_TO_UPDATE_AND_ZIP_IT.txt", 'w').write(open('/home/claude/pod2/HOW_TO_UPDATE.txt').read().replace('__V__', V))
subprocess.run(['zip', '-qr', f'Pod_Rundown_{V}.zip', f'Pod_Rundown_{V}'], cwd=base, check=True)
print(f'{base}/Pod_Rundown_{V}.zip')
