# "Zip it": structured docs zip (make_zip.py) + resume doc + an exact copy of every working folder
import os, shutil, subprocess, sys
V = sys.argv[1]
subprocess.run(['python3', 'make_zip.py', V], check=True)
base = '/tmp/claude-0/zipout'; D = f'{base}/Pod_Rundown_{V}'
shutil.copy('00_RESUME_HERE.md', D + '/')
if os.path.exists('/tmp/devrepo/CRAWL_TODO.md'): shutil.copy('/tmp/devrepo/CRAWL_TODO.md', D + '/Crypt_Crawl/CRAWL_TODO.md')
F = D + '/FULL_PROJECT'; os.makedirs(F + '/tmp_tools', exist_ok=True)
ign = shutil.ignore_patterns('music', '__pycache__', '*.zip', 'node_modules')
for d in ['pod2', 'dog', 'bat', 'work', 'data']:
    if os.path.isdir('/home/claude/' + d): shutil.copytree('/home/claude/' + d, f'{F}/{d}', ignore=ign)
for f in ['pub.sh', 'smoke.py', 'treeui.py', 'pgtest.py', 'show.py', 'tagidx.json']:
    if os.path.exists('/tmp/' + f): shutil.copy('/tmp/' + f, F + '/tmp_tools/')
os.remove(f'{base}/Pod_Rundown_{V}.zip')
subprocess.run(['zip', '-qr', f'Pod_Rundown_{V}.zip', f'Pod_Rundown_{V}'], cwd=base, check=True)
print(f'{base}/Pod_Rundown_{V}.zip')
