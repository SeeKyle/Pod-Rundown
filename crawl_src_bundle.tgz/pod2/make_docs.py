import json, ast, os, sys, textwrap
sys.path.insert(0, '/home/claude/pod2'); sys.path.insert(0, '/home/claude/pod2/decks')
from score import run, STATS, STAT_NAME, BASICS, PT
from judge import J
from takeaways_text import TEXTS
from build_data import build
CT = json.load(open('card_text.json'))
INC = json.load(open('inclusion.json'))
res, divs = run()
data, _, _ = build(TEXTS)
TK = {t['deck']: t for t in data['takeaways']}
raw = json.load(open('raw_lists.json'))
VERSION = sys.argv[2] if len(sys.argv) > 2 else '0.10'
OUT = sys.argv[1]
order = sorted(res, key=lambda r: -r['total'])

def tag_sources(key):
    src = open(f'decks/{key}.py').read()
    tree = ast.parse(src)
    out = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Dict):
            for k, v in zip(node.keys, node.values):
                if isinstance(k, ast.Constant) and isinstance(v, ast.Call) and getattr(v.func, 'id', '') == 'T':
                    seg = ast.get_source_segment(src, v)
                    out[k.value] = ' '.join(seg.split())
    return out

for n, r in enumerate(order, 20):
    M = r['meta']; key = r['key']
    srcs = tag_sources(key)
    tk = TK[M['deck']]
    repair = {x['card']: (i + 1, x) for i, x in enumerate(tk['repair'])}
    rank_of = {c['name']: i + 1 for i, c in enumerate(sorted([c for c in r['cards'] if not c['is_land']], key=lambda c: -c['total']))}
    L = []
    L.append(f"POD RUNDOWN {VERSION} — DECK FILE: {M['deck']} {M['icon']}")
    L.append('=' * 70)
    L.append(f"Owner: {M['owner']}   Archetype: {M['archetype']}   Colors: {M['colors']}")
    L.append(f"Commander(s): {', '.join(M['cmdr'])}" + (f"   Secret commander(s): {', '.join(M['secret'])}" if M.get('secret') else ''))
    L.append(f"Pod rank: #{order.index(r)+1} of {len(order)}   Total {r['total']:g}/90   Engine {r['engine']:g}  Offense {r['offense']:g}  Defense {r['defense']:g}   Salt {r['salt']}")
    L.append('Ratings: ' + '  '.join(f"{STAT_NAME[s]} {r['rating'][s]}" for s in STATS))
    L.append('Points (after deck checks): ' + '  '.join(f"{STAT_NAME[s]} {r['final'][s]:.2f}" for s in STATS))
    L.append(f"Lands {r['lands']}   Avg nonland MV {r['avg_mv']}   5 lands by T6: {r['land_drop']:.0%}")
    L.append('')
    L.append('DECK-LEVEL CHECKS')
    for s in STATS:
        for a, note in r['adj'][s]:
            L.append(f"  [{STAT_NAME[s]}] {note}")
    L.append('')
    tx = TEXTS[key]
    L.append('SITE TAKEAWAY TEXT (what the website shows)')
    L.append('  Tagline: ' + tx['tagline'])
    L.append('  Feel: ' + tx['feel'])
    for i, ph in enumerate(tx['phases']): L.append(f'  Phase {i+1}: ' + ph)
    for w in tx['wins']: L.append(f"  Win - {w['name']}: {w['text']}")
    for f in tx['fears']: L.append('  Fear: ' + f)
    for f in tx['tips']: L.append('  Tip: ' + f)
    L.append('  Lands: ' + tx['land'])
    L.append('  Removal: ' + tx['removal_text'])
    for h in tx['hh']: L.append(f"  Heavy Hitter - {h['card']}: {h['text']}")
    for d in tx['dream']: L.append(f"  Dream - {d['name']}: {d['text']}")
    for x in tx['xcards']: L.append(f"  X card - {x['card']}: {x['text']}")
    L.append('')
    L.append('HOW TO READ EACH CARD BELOW')
    L.append('  Card name')
    L.append('    INFO  - count, mana value, type, rarity, EDHREC salt, EDHREC inclusion %, P/T, our rank in this deck')
    L.append('    ROLE  - commander / Plan Tag (C = works with the commander, T = fits the deck plan) / Needs Repair pick')
    L.append('    NOTE  - the short note I wrote when tagging')
    L.append('    TAGS  - the formula calls used (source), then each scored entry: stat, points, label')
    L.append('    TOTAL - card total across all stats')
    L.append('    CARD TEXT - the full official card text (no flavor text). Use this; never look it up again.')
    L.append('')
    L.append('=' * 70)
    seen = set()
    cards_by_name = {}
    for c in r['cards']:
        cards_by_name.setdefault(c['name'], []).append(c)
    for item in raw[M['file']]:
        name = item['name']
        if name in seen: continue
        seen.add(name)
        cs = cards_by_name.get(name, [])
        c = cs[0] if cs else None
        L.append('')
        L.append(name)
        if name in BASICS:
            L.append(f"    INFO  - x{item['q']} basic land (no score)")
            L.append('    CARD TEXT')
            L += ['      ' + x for x in CT[name].split('\n')]
            continue
        info = [f"x{item['q']}", f"MV {c['mv']:g}", c['type'], f"rarity {c['rarity']}", f"salt {c['salt']}"]
        if name in INC: info.append(f"EDHREC {INC[name]:.2f}%")
        if name in PT: info.append(f"P/T {PT[name][0]}/{PT[name][1]}")
        if not c['is_land']: info.append(f"rank #{rank_of[name]} of {len(rank_of)} nonland")
        L.append('    INFO  - ' + ' · '.join(info))
        role = []
        if c['commander']: role.append('COMMANDER')
        if c['secret']: role.append('SECRET COMMANDER')
        if c.get('plan'): role.append('PLAN TAG ' + ' + '.join({'C': 'C (works with the commander)', 'T': 'T (fits the deck plan)'}[x] for x in sorted(c['plan'])))
        if name in repair:
            i, x = repair[name]
            role.append(f"NEEDS REPAIR #{i} (my read: {x['read']}; blend {x['blend']}) — {x['why']}")
            for _s in x.get('swaps', []): role.append(f"{_s['tier'].upper()} SWAP (~${_s['usd']:g}): {_s['card']}, {_s['why']}")
            if x.get('budget'): role.append('BUDGET SWAP: ' + x['budget'])
            if x.get('anycost'): role.append('ANY-COST SWAP: ' + x['anycost'])
            if not x.get('budget') and x.get('idea'): role.append('FIX: ' + x['idea'])
        elif name in J.get(key, {}):
            role.append(f"my read: {['','weak','below average','okay','good','great'][J[key][name][0]]} — {J[key][name][1]}")
        if role: L.append('    ROLE  - ' + ' | '.join(role))
        L.append('    NOTE  - ' + (c['note'] or '-'))
        L.append('    TAGS  - ' + srcs.get(name, '(none)'))
        for e in c['entries']:
            L.append(f"            {STAT_NAME[e['stat']]:<11} {e['pts']:6.3f}  {e['label']}")
        L.append(f"    TOTAL - {c['total']:.3f}  (" + ', '.join(f"{STAT_NAME[s]} {c['stats'][s]:.2f}" for s in STATS if c['stats'][s] > 0) + ')')
        L.append('    CARD TEXT')
        L += ['      ' + x for x in CT[name].split('\n')]
    import os as _os; _pd = f"{OUT}/Player_Decks/{M['owner']}"; _os.makedirs(_pd, exist_ok=True)
    fn = f"{_pd}/{n}_Deck_{M['deck'].replace(' ', '_').replace(',', '').replace(chr(39), '').replace('&', 'and')}.txt"
    open(fn, 'w').write('\n'.join(L) + '\n')
    print(fn, len(L))
