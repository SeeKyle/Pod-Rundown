"""0.12.183 (Kyle): the Skeleton_Archer enemy, from CraftPix's 'Free Skeleton Pixel Art Sprite Sheets' (Skeleton_Archer).
License: https://craftpix.net/file-licenses/  The sheet faces right (faceR)."""
import json, numpy as np
from PIL import Image
S='/tmp/cpx/skel/Skeleton_Archer/'
def frames(f):
    im=Image.open(S+f+'.png').convert('RGBA');n=im.width//128;return [im.crop((i*128,0,(i+1)*128,128)) for i in range(n)]
rows=[('walk','Walk'),('atk','Shot_1'),('idle','Idle'),('die','Dead'),('hurt','Hurt')]
fr={k:frames(f) for k,f in rows}
a=np.array(fr['idle'][0])[:,:,3]>0;ys,xs=np.where(a);y1=int(ys.max());AX=int(round(np.where(a[y1-5:y1+1].any(0))[0].mean()));AY=y1+1;H=int(ys.max()-ys.min()+1)
PRE=round(.88*H/38,4)   # a little taller than a zombie (36 px at .88)
W=max(len(v) for v in fr.values())*128;out=Image.new('RGBA',(W,128*len(rows)),(0,0,0,0));meta={}
for r,(k,_) in enumerate(rows):
    for i,f in enumerate(fr[k]): out.alpha_composite(f,(i*128,r*128))
    meta[k]=dict(fw=128,fh=128,n=len(fr[k]),ax=AX,ay=AY,x=0,y=r*128,img='skel',pre=PRE,faceR=1)
out.save('/home/claude/pod2/crawl_skel.png',optimize=True)
A=json.load(open('/home/claude/pod2/crawl_atlas.json'));A['units']['skarcher']=meta;json.dump(A,open('/home/claude/pod2/crawl_atlas.json','w'))
print(AX,AY,H,PRE,{k:v['n'] for k,v in meta.items()})
