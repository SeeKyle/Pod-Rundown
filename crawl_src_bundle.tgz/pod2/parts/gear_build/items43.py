ITEMS=[
('Rusty Shiv',lambda:tint(shade('iron',0,0),(150,80,40),.5)),('Slingshot',slingshot),('Butcher Cleaver',lambda:shade('iron',11,10)),
('Revolver Cylinder',lambda:ocal('colt_peacemaker')),('Crossbow Bolt Case',lambda:shade('steel',12,7)),('Hatchet of the Woods',lambda:shade('bronze',10,0)),
('Sawed-Off',lambda:jest(4,3)),('Morningstar',lambda:shade('iron',15,4)),('Tesla Gauntlet',tesla_gauntlet),('Grenade Bandolier',bandolier),
('Katana of the Crit',lambda:jest(13,0,45)),('Flare Gun',lambda:jest(9,1)),('Drum-Fed Tommy',lambda:jest(8,3)),('Longbow of the Wind',lambda:shade('steel',12,18)),
('Flamethrower Pack',lambda:jest(0,7)),('Excalibur (Rusted)',lambda:tint(shade('steel',5,7),(190,150,90),.3)),
('Leather Jacket',lambda:armory('leather_jacket')),('Padded Gambeson',lambda:armory('quilted_armor')),('Riot Vest',lambda:jest(7,0)),
('Chainmail Shirt',lambda:armory('chainmail_jacket')),('Spiked Pauldrons',lambda:armory('studded_jacket_alt')),('Ghillie Suit',lambda:noise(tint(armory('cloak'),(80,120,50),.8),[(60,96,40),(98,130,60),(120,110,60)],.45)),
('Kevlar Plate',lambda:tint(armory('breastplate'),(70,80,60),.75)),('Knight Breastplate',lambda:armory('breastplate')),('Hazmat Suit',lambda:tint(armory('cloth_robe'),(230,200,40),.75)),
('Samurai Do',lambda:tint(armory('studded_jacket'),(170,30,40),.65)),('Bomb Suit',lambda:tint(armory('platemail'),(110,120,70),.7)),('Crimson Plate',lambda:tint(armory('platemail'),(190,30,40),.6)),('Exo-Frame',exo),
('Lucky Penny',coin),('Rabbit Foot',rabbitfoot),('Zippo Lighter',zippo),('Energy Drink',can),('Medic Pouch',medpouch),('Walkie-Talkie',walkie),('Holy Relic',relic),
('Stopwatch',stopwatch),('Druid Seed Pouch',seedpouch),('Dog Tags',dogtags),('Necro Tome',tome),('Golden Dice',golddie),('Dice-Boys Pin',dicepin)]