import json,random
exec(open('gearlib.py').read())
exec(open('items43.py').read())   # ITEMS: 43 hand-made (name, fn)
R43=['C','C','U','U','U','R','R','R','E','E','E','E','L','L','M','M','C','C','U','U','R','R','R','E','E','E','L','L','M','C','C','U','U','R','R','R','E','E','E','L','L','M']
RI={'C':0,'U':1,'R':2,'E':3,'L':4,'M':5}
G=[]   # (name,slot,rar,kind,iconfn)
SL43=['W']*16+['A']*13+['T']*13
K43=['melee','bow','melee','gun','bow','melee','gun','melee','gun','gun','melee','gun','gun','bow','gun','melee']+['armor']*13+['trinket']*13
for (n,f),r,sl,k in zip(ITEMS,R43,SL43,K43):G.append((n,sl,RI[r],k,f))
# ---- medieval melee from Shade, in metal tiers
MET=[('iron','Iron',0),('bronze','Bronze',1),('steel','Steel',2),('gold','Gilded',3)]
SW=[((0,0),'Shortsword'),((0,4),'Broadsword'),((0,7),'Longsword'),((0,8),'Claymore'),((3,9),'Rapier'),((0,11),'Scimitar'),((0,13),'Falchion'),((5,5),'Bastard Sword'),((6,0),'Serrated Blade'),((8,5),'Flamberge'),((0,15),'Spear'),((0,16),'Halberd'),((0,21),'Trident'),((10,1),'Battle Axe'),((10,2),'Greataxe'),((13,4),'Mace'),((10,21),'Warhammer'),((18,0),'Double Axe'),((10,8),'Hand Axe'),((17,5),'Spiked Flail')]
rng=random.Random(7)
for i,((r,c),nm) in enumerate(SW):
    for sh,adj,rr in MET:
        if (i+rr)%2==1 and rr in (1,3):continue   # not every weapon in every metal
        G.append((f'{adj} {nm}','W',rr,'melee',(lambda sh=sh,r=r,c=c:shade(sh,r,c))))
for (r,c),nm,rr in [((12,18),'Recurve Bow',1),((15,20),'Composite Bow',2),((12,7),'Heavy Crossbow',3),((10,18),'Hunting Bow',0),((16,19),'Repeater Crossbow',4)]:
    G.append((nm,'W',rr,'bow',(lambda r=r,c=c:shade('steel',r,c))))
# ---- guns from Jestan
JG=[((1,1),'Snub Revolver',0),((2,1),'Service Pistol',0),((3,1),'Pocket Pistol',0),((5,1),'Hand Cannon',2),((6,1),'Auto Pistol',1),((12,1),'Machine Pistol',2),((0,2),'Compact SMG',1),((2,2),'Suppressed SMG',2),((6,2),'Raider SMG',2),((9,2),'Vector SMG',3),((11,2),'Grease Gun',1),((1,3),'Pump Shotgun',1),((2,3),'Riot Shotgun',2),((5,3),'Double-Barrel',0),((8,3),'Drum Shotgun',3),((9,3),'Combat Shotgun',3),((1,4),'Battle Rifle',2),((2,4),'Lever Rifle',1),((4,4),'Bullpup Carbine',3),((6,4),'Desert Rifle',2),((10,4),'Assault Carbine',2),((13,4),'Woodland Rifle',1),((16,4),'Grenade Rifle',4),((1,5),'Hunting Rifle',1),((5,5),'Marksman Rifle',3),((9,5),'Jungle Sniper',4),((11,5),'Bolt Sniper',3),((13,5),'Anti-Material Rifle',5),((1,6),'Squad LMG',3),((3,6),'Belt-Fed LMG',4),((7,6),'Heavy MG',4),((2,7),'Rocket Launcher',4),((3,7),'Bazooka',3),((1,8),'Thumper Launcher',4),((2,8),'Chainsaw',5),((3,8),'Mounted Gun',5),((10,0),'Spiked Bat',0),((11,0),'Fire Axe',1),((12,0),'Crowbar',0),((9,0),'Combat Knife',1),((14,0),'Machete',1)]
for (r,c),nm,rr in JG:
    k='melee' if c==0 else 'gun'
    G.append((nm,'W',rr,k,(lambda r=r,c=c:jest(r,c))))
for f,nm,rr in [('musket','Flintlock Musket',1),('winchester_30-30','Frontier Rifle',2),('m1_garand','Old Garand',2),('mosin-nagant_1891','Long Nagant',1),('lever_action_shotgun','Lever Shotgun',2),('357_revolver','Magnum Revolver',3),('mauser_c96','Broomhandle',2),('tokarev_tt-33','Tokarev',1),('pump_action_rifle','Pump Rifle',1),('air_rifle','Pellet Gun',0)]:
    G.append((nm,'W',rr,'gun',(lambda f=f:ocal(f))))
# ---- armor from Idylwild
AR_N=[('leather_cap','Leather Cap',0),('cloth_hood','Cloth Hood',0),('cloth_robe','Wanderer Robe',0),('cloth_pants','Cloth Pants',0),('cloth_shoes','Cloth Shoes',0),('cloth_gloves','Cloth Gloves',0),('tattered_shirt','Tattered Shirt',0),
 ('leather_pants','Leather Pants',0),('leather_boots','Leather Boots',1),('leather_gloves','Leather Gloves',0),('leather_bracers','Leather Bracers',1),('leather_jacket_alt','Duster Jacket',1),
 ('studded_helmet','Studded Helm',1),('studded_jacket','Studded Jerkin',1),('studded_pants','Studded Leggings',1),('studded_boots','Studded Boots',1),('studded_gloves','Studded Gloves',1),
 ('chainmail_coif','Chain Coif',2),('chainmail_pants','Chain Leggings',2),('chainmail_boots','Chain Boots',2),('chainmail_gloves','Chain Gloves',2),('chainmail_alt','Hauberk',2),
 ('platemail_helmet','Plate Helm',3),('platemail_pants','Plate Greaves',3),('greaves','Sabatons',3),('gauntlets','Plate Gauntlets',3),('close_helmet','Close Helm',3),('platemail','Full Plate',4),('horned_helmet','Horned Helm',2),('iron_bracers','Iron Bracers',2),
 ('wooden_buckler','Wooden Buckler',0),('wood_kite_shield','Wooden Kite Shield',1),('iron_buckler','Iron Buckler',2),('kite_shield','Kite Shield',3),('tower_shield','Tower Shield',4),('wood_kite_shield_alt','Painted Shield',2),('cloak','Traveler Cloak',1)]
for f,nm,rr in AR_N:G.append((nm,'A',rr,'armor',(lambda f=f:armory(f))))
for f,col,nm,rr in [('leather_jacket',(30,30,34),'Biker Jacket',1),('cloth_robe',(235,235,230),'Lab Coat',1),('cloth_robe',(220,120,30),'Firefighter Coat',3),('cloth_pants',(80,100,60),'Camo Pants',1),('leather_boots',(40,36,34),'Combat Boots',2),('leather_gloves',(200,170,90),'Work Gloves',0),('leather_cap',(230,190,40),'Hard Hat',1),('platemail',(40,60,140),'Football Pads',2),('breastplate',(30,40,90),'Police Vest',2),('quilted_armor',(90,80,60),'Flak Jacket',2),('close_helmet',(60,70,50),'Tank Helmet',3),('gauntlets',(60,200,230),'Power Gloves',4),('platemail_helmet',(200,200,210),'Visor Helm',4),('cloak',(30,20,40),'Night Cloak',3),('cloak',(170,40,40),'Hero Cape',5),('studded_jacket_alt',(120,90,60),'Cowboy Vest',1)]:
    G.append((nm,'A',rr,'armor',(lambda f=f,col=col:tint(armory(f),col,.65))))
# ---- trinkets: Idylwild rings/necklaces + custom drawings
for f,nm,rr in [('copper_ring','Copper Ring',0),('iron_ring','Iron Ring',1),('silver_ring','Silver Ring',2),('gold_ring','Gold Ring',3)]:G.append((nm,'T',rr,'trinket',(lambda f=f:armory(f))))
for (x,y),nm,rr in [((0,4),'Crescent Pendant',1),((1,4),'Ruby Pendant',2),((2,4),'Emerald Pendant',3),((3,4),'Sapphire Amulet',4)]:
    G.append((nm,'T',rr,'trinket',(lambda x=x,y=y:fit(Image.open(AR+'armory.png').convert('RGBA').crop((192+x*32,128,192+x*32+32,160))))))
def d_horseshoe():
    a=canvas(32,32);ell(a,(5,4,27,28),(170,176,186));ell(a,(10,9,22,26),(0,0,0,0));rect(a,(10,20,22,30),(0,0,0,0))
    for (x,y) in [(7,10),(6,16),(25,10),(26,16)]:px(a,x,y,(80,80,90));return done(a)
def d_clover():
    a=canvas(32,32)
    for (x,y) in [(9,6),(17,6),(9,14),(17,14)]:ell(a,(x,y,x+8,y+8),(60,170,60))
    line(a,[(16,18),(20,29)],(40,120,40),2);return done(a)
def d_chip(c):
    def f():
        a=canvas(32,32);ell(a,(4,4,27,27),c);ell(a,(9,9,22,22),(240,240,240));ell(a,(11,11,20,20),c)
        for (x,y) in [(15,4),(15,25),(4,15),(25,15)]:rect(a,(x,y,x+2,y+2),(240,240,240))
        return done(a)
    return f
def d_card():
    a=canvas(32,32);rect(a,(8,4,23,27),(245,245,240));rect(a,(10,6,12,9),(200,30,30));poly(a,[(16,11),(21,17),(16,23),(11,17)],(200,30,30));return done(a)
def d_tape():
    a=canvas(32,32);rect(a,(3,8,28,24),(40,40,46));rect(a,(6,11,25,18),(220,200,120));ell(a,(9,12,14,17),(40,40,46));ell(a,(18,12,23,17),(40,40,46));return done(a)
def d_headphones():
    a=canvas(32,32);ell(a,(5,3,27,25),(40,40,46));ell(a,(8,6,24,24),(0,0,0,0));rect(a,(4,15,9,26),(200,40,60));rect(a,(23,15,28,26),(200,40,60));return done(a)
def d_compass():
    a=canvas(32,32);ell(a,(5,5,26,26),(200,170,90));ell(a,(8,8,23,23),(240,236,220));poly(a,[(16,9),(18,16),(16,22),(14,16)],(200,40,40));poly(a,[(16,16),(18,16),(16,22),(14,16)],(60,60,70));return done(a)
def d_flashlight():
    a=canvas(32,32);rect(a,(6,13,20,19),(50,54,60));poly(a,[(20,11),(26,8),(26,24),(20,21)],(80,86,96));poly(a,[(26,9),(31,6),(31,26),(26,23)],(255,240,150));return done(a)
def d_keys():
    a=canvas(32,32);ell(a,(4,4,13,13),(200,170,60));ell(a,(7,7,10,10),(0,0,0,0));line(a,[(11,11),(24,24)],(190,196,204),2);rect(a,(20,22,22,26),(190,196,204));rect(a,(23,19,26,21),(190,196,204));return done(a)
def d_whistle():
    a=canvas(32,32);rect(a,(6,12,22,20),(200,200,210));ell(a,(16,10,28,22),(200,200,210));ell(a,(20,13,25,18),(60,60,70));line(a,[(6,12),(3,6)],(160,40,40));return done(a)
def d_map():
    a=canvas(32,32);poly(a,[(4,7),(12,4),(20,7),(28,4),(28,25),(20,28),(12,25),(4,28)],(220,200,150));line(a,[(12,4),(12,25)],(180,160,110));line(a,[(20,7),(20,28)],(180,160,110));line(a,[(7,20),(14,14),(22,18),(25,10)],(200,40,40));return done(a)
def d_bandana(c):
    def f():
        a=canvas(32,32);poly(a,[(3,8),(29,8),(16,28)],c)
        for (x,y) in [(8,11),(14,12),(20,11),(16,17),(12,15),(19,16)]:px(a,x,y,(240,240,240))
        return done(a)
    return f
def d_cap():
    a=canvas(32,32);rect(a,(7,10,25,14),(200,160,60));for_=[(x,9-((x-16)**2)//40) for x in range(7,26)]
    for x,y in for_:rect(a,(x,y,x,10),(200,160,60))
    for i in range(7,26,3):px(a,i,14,(150,110,40));return done(a)
def d_knife():
    a=canvas(32,32);poly(a,[(6,22),(20,8),(23,8),(23,11),(9,25)],(200,206,214));rect(a,(4,22,10,28),(140,30,30));return done(a)
def d_lockpick():
    a=canvas(32,32);line(a,[(6,26),(24,8)],(170,176,186),1);line(a,[(24,8),(27,8)],(170,176,186));line(a,[(8,26),(26,12)],(140,146,156),1);rect(a,(3,24,9,29),(60,60,70));return done(a)
def d_cigar():
    a=canvas(32,32);rect(a,(4,14,24,18),(130,80,40));rect(a,(18,14,20,18),(200,40,40));rect(a,(24,14,26,18),(240,120,40));
    for (x,y) in [(27,11),(28,8),(27,5)]:px(a,x,y,(180,180,180))
    return done(a)
def d_bulletneck():
    a=canvas(32,32);line(a,[(6,3),(16,16),(26,3)],(70,70,70));rect(a,(14,15,18,26),(200,160,60));poly(a,[(14,15),(16,10),(18,15)],(190,120,60));return done(a)
def d_book(c):
    def f():
        a=canvas(32,32);rect(a,(6,5,25,28),c);rect(a,(6,5,9,28),tuple(int(v*.7) for v in c));rect(a,(23,7,26,27),(220,214,200));rect(a,(12,12,20,14),(240,220,140));return done(a)
    return f
def d_die(c,pip=(20,20,20)):
    def f():
        a=canvas(32,32);poly(a,[(16,3),(28,9),(16,15),(4,9)],c);poly(a,[(4,9),(16,15),(16,29),(4,22)],tuple(int(v*.85) for v in c));poly(a,[(28,9),(16,15),(16,29),(28,22)],tuple(int(v*.7) for v in c))
        for (x,y) in [(16,9),(9,16),(12,21),(20,17),(24,22),(22,12)]:rect(a,(x,y,x+1,y+1),pip)
        return done(a)
    return f
def d_can(c):
    def f():
        a=canvas(32,32);rect(a,(10,6,21,28),c);rect(a,(10,5,21,6),(190,196,200));rect(a,(10,28,21,29),(190,196,200));rect(a,(11,7,12,27),tuple(min(255,v+50) for v in c));rect(a,(13,14,19,18),(245,245,245));return done(a)
    return f
def d_coin(c,c2):
    def f():
        a=canvas(32,32);ell(a,(6,6,25,25),c);ell(a,(8,8,23,23),c2);ell(a,(12,11,19,20),c);px(a,10,10,(255,255,240));return done(a)
    return f
def d_watch():
    a=canvas(32,32);rect(a,(14,2,18,5),(200,170,60));ell(a,(5,6,27,28),(220,180,70));ell(a,(8,9,24,25),(250,246,230));line(a,[(16,17),(16,11)],(30,30,30));line(a,[(16,17),(20,17)],(30,30,30));return done(a)
def d_vial(c):
    def f():
        a=canvas(32,32);rect(a,(13,3,19,7),(140,100,60));rect(a,(12,7,20,10),(200,220,230));ell(a,(8,10,24,28),(200,220,230));ell(a,(10,15,22,27),c);px(a,12,14,(255,255,255));return done(a)
    return f
def d_radio():
    a=canvas(32,32);rect(a,(4,10,28,26),(150,40,40));rect(a,(6,13,16,23),(40,40,46));ell(a,(19,13,26,20),(220,220,220));line(a,[(8,10),(20,3)],(160,160,160));return done(a)
def d_grenadecharm():
    a=canvas(32,32);ell(a,(9,10,23,27),(84,98,60));rect(a,(14,5,18,10),(150,150,150));line(a,[(18,6),(24,4)],(150,150,150));return done(a)
EXTRA_T=[('Lucky Horseshoe',1,d_horseshoe),('Four-Leaf Clover',2,d_clover),('Red Poker Chip',0,d_chip((190,30,40))),('Blue Poker Chip',1,d_chip((40,70,190))),('Black Poker Chip',3,d_chip((30,30,36))),('Ace of Hearts',2,d_card),
 ('Mixtape',1,d_tape),('Studio Headphones',2,d_headphones),('Old Compass',1,d_compass),('Flashlight',0,d_flashlight),('Car Keys',0,d_keys),('Coach Whistle',1,d_whistle),('Treasure Map',3,d_map),
 ('Red Bandana',0,d_bandana((180,30,30))),('Blue Bandana',1,d_bandana((40,60,160))),('Bottle Cap Crown',2,d_cap),('Pocket Knife',0,d_knife),('Lockpick Set',1,d_lockpick),('Lucky Cigar',2,d_cigar),('Bullet Necklace',2,d_bulletneck),
 ('Field Manual',1,d_book((70,100,60))),('Holy Book',3,d_book((230,226,215))),('Dream Journal',2,d_book((60,90,170))),('Forbidden Codex',5,d_book((120,20,30))),
 ('Bone Die',0,d_die((230,224,200))),('Red Casino Die',1,d_die((200,30,40),(250,250,250))),('Blue Glass Die',3,d_die((70,120,220),(250,250,250))),('Crit Die',4,d_die((40,40,46),(255,210,60))),
 ('Cola Can',0,d_can((200,30,30))),('Grape Soda',1,d_can((120,50,160))),('Protein Shake',2,d_can((90,90,100))),
 ('Silver Dollar',2,d_coin((170,176,186),(205,210,220))),('Gold Doubloon',4,d_coin((200,150,40),(240,200,80))),('Pocket Watch',3,d_watch),
 ('Healing Vial',1,d_vial((200,40,50))),('Mana Vial',2,d_vial((50,100,220))),('Elixir of Haste',4,d_vial((240,200,40))),('Boombox',3,d_radio),('Grenade Charm',2,d_grenadecharm)]
for nm,rr,f in EXTRA_T:G.append((nm,'T',rr,'trinket',f))
# ---------- procs
TRIG={'gun':['basicR','basicR','hit','crit','kill','every5'],'bow':['basicR','crit','kill','hit'],'melee':['basicM','basicM','hit','crit','kill','every5'],
 'armor':['taken','taken','dodge','low','healed','start'],'trinket':['cast','kill','crit','healOther','healed','start','every5','hit','allyDown']}
EFF={'gun':['shot','burn','bleed','stun','slow','pierce','double','mark','haste','dmgbuff','nade','chain','energy'],'bow':['pierce','shot','bleed','poison','slow','mark','root','haste'],
 'melee':['bleed','double','stun','kb','blast','poison','burn','dmgbuff','haste','heal','skeleton'],
 'armor':['shield','heal','reflect','armor','block','move','healTeam','stunBack','kbBack','blastSelf','energy'],
 'trinket':['energy','heal','healTeam','shield','dmgbuff','haste','move','banner','bloom','mark','gold','skeleton','chain','reload','nade']}
CH=[(3,5),(5,7),(7,9),(9,12),(12,16),(16,25)]
SAFE={'start':['shield','dmgbuff','haste','move','banner','energy','heal','armor','block'],'low':['shield','heal','block','healTeam','armor','blastSelf'],'allyDown':['dmgbuff','haste','shield','heal','healTeam','banner'],'healOther':['shield','heal','energy','haste','dmgbuff','bloom'],'healed':['dmgbuff','haste','energy','shield','armor','move'],'every5':None,'cast':None}
STAT={'W':[('dmgPct',[2,3,4,5,7,9]),('crit',[1,1.5,2,3,4,5]),('acc',[2,3,4,6,8,10])],'A':[('armor',[1,1,2,2,3,4]),('hpPct',[3,4,5,7,9,12]),('dodge',[1,1.5,2,3,4,5]),('kbRes',[4,6,8,10,12,15])],
 'T':[('luck',[3,4,6,8,10,14]),('enRegen',[.2,.3,.4,.5,.7,.9]),('cdr',[2,3,4,5,6,8]),('move',[2,3,4,5,6,8]),('xp',[3,4,6,8,10,12])]}
ICONS=[];DB=[];names=set()
rng=random.Random(11)
for i,(nm,sl,r,k,f) in enumerate(G):
    if nm in names:continue
    names.add(nm);ICONS.append(f())
    tr=TRIG[k];ef=EFF[k];np_=2 if r>=4 else 1;procs=[]
    used=set()
    for j in range(np_):
        t=tr[(i*3+j*5)%len(tr)]
        pool=SAFE.get(t) or ef
        pool=[e for e in pool if e in ef or t in SAFE] or ef
        e=pool[(i*7+j*3+len(nm))%len(pool)]
        if (t,e) in used:e=pool[(i*7+j*3+len(nm)+1)%len(pool)]
        used.add((t,e));lo,hi=CH[r] if j==0 else CH[max(0,r-2)]
        procs.append({'t':t,'e':e,'lo':lo,'hi':hi})
    sts=STAT[sl];s1=sts[(i+len(nm))%len(sts)];st={s1[0]:s1[1][r]}
    if r>=4:s2=sts[(i+len(nm)+1)%len(sts)];st[s2[0]]=s2[1][r]
    DB.append({'id':len(DB),'n':nm,'s':sl,'r':r,'k':k,'st':st,'p':procs})
# atlas
cols=16;rows=(len(ICONS)+cols-1)//cols;atl=Image.new('RGBA',(cols*32,rows*32))
for i,im in enumerate(ICONS):atl.alpha_composite(im,((i%cols)*32,(i//cols)*32))
atl.save('/home/claude/pod2/crawl_gear.png')
json.dump(DB,open('/home/claude/pod2/gear_db.json','w'))
from collections import Counter
print(len(DB),Counter(d['s'] for d in DB),Counter(d['r'] for d in DB))
