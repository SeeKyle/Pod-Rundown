import numpy as np,sys,json,glob
from PIL import Image,ImageDraw
sys.path.insert(0,'/tmp/tg/w')
from px import canvas,poly,ell,rect,line,px,outline
OUT=(18,14,20)
J=Image.open(glob.glob('/tmp/icons/c3a956d9*/TheUltimateWeaponsPack/TheUltimateWeaponsPack_Sheet.png')[0]).convert('RGBA')
SH={k:Image.open(f'/tmp/icons/65d77c6c-16x16_weapons_rpg_icons/16x16 Weapons RPG Icons/{k}-weapons.png').convert('RGBA') for k in ['iron','steel','gold','bronze']}
AR='/tmp/icons/9a258be9-idylwilds_armory/'
OC='/tmp/icons/27c403fd-firearm-ocal/32x32/'
def fit(im,size=32,pad=1):
    a=np.array(im);m=a[...,3]>0
    if not m.any():return Image.new('RGBA',(size,size))
    ys,xs=np.where(m);im=im.crop((xs.min(),ys.min(),xs.max()+1,ys.max()+1))
    w,h=im.size;s=min((size-2*pad)/w,(size-2*pad)/h)
    s=max(1,int(s)) if s>=1 else s
    nw,nh=max(1,int(w*s)),max(1,int(h*s))
    im=im.resize((nw,nh),Image.NEAREST);c=Image.new('RGBA',(size,size));c.alpha_composite(im,((size-nw)//2,(size-nh)//2));return c
def jest(r,c,rot=0):
    t=J.crop((c*48,r*24,(c+1)*48,(r+1)*24))
    if rot:t=t.rotate(rot,expand=True,resample=Image.NEAREST)
    return fit(t)
def shade(sheet,r,c):return fit(SH[sheet].crop((c*16,r*16,(c+1)*16,(r+1)*16)))
def armory(n):return fit(Image.open(AR+n+'.png').convert('RGBA'))
def ocal(n):return fit(Image.open(glob.glob(OC+'*/'+n+'.png')[0]).convert('RGBA'))
def tint(im,col,amt=.6):
    a=np.array(im).astype(float);m=a[...,3]>0
    lum=(a[...,:3].mean(-1,keepdims=True))/255
    t=np.array(col,float)[None,None,:]*(.35+lum*1.1)
    a[...,:3]=np.where(m[...,None],a[...,:3]*(1-amt)+np.clip(t,0,255)*amt,a[...,:3])
    return Image.fromarray(a.clip(0,255).astype(np.uint8))
def noise(im,cols,p=.35,seed=1):
    a=np.array(im);rng=np.random.default_rng(seed);m=(a[...,3]>0)&(rng.random(a.shape[:2])<p)
    idx=rng.integers(0,len(cols),a.shape[:2])
    for i,c in enumerate(cols):a[m&(idx==i),:3]=c
    return Image.fromarray(a)
def done(a):outline(a,OUT);return Image.fromarray(a)
# ---------- custom icons ----------
def slingshot():
    a=canvas(32,32);W=(150,96,52);WD=(108,64,32)
    line(a,[(16,28),(16,17)],W,3);line(a,[(16,18),(9,7)],W,3);line(a,[(16,18),(23,7)],W,3)
    rect(a,(15,22,17,27),WD);line(a,[(9,7),(16,13),(23,7)],(200,170,140),1);ell(a,(14,11,18,15),(110,70,50));return done(a)
def bandolier():
    a=canvas(32,32);line(a,[(3,4),(29,28)],(120,84,48),5)
    for i,(x,y) in enumerate([(9,8),(16,14),(23,21)]):
        ell(a,(x-4,y-4,x+3,y+4),(84,98,60));rect(a,(x-1,y-6,x+1,y-4),(150,150,150));px(a,x+2,y-6,(150,150,150))
    return done(a)
def coin():
    a=canvas(32,32);ell(a,(6,6,25,25),(184,108,60));ell(a,(8,8,23,23),(214,140,80));ell(a,(12,11,19,20),(184,108,60));px(a,10,10,(255,220,180));px(a,11,9,(255,220,180));return done(a)
def rabbitfoot():
    a=canvas(32,32);ell(a,(4,2,11,9),(200,170,60));ell(a,(6,4,9,7),(0,0,0,0))
    poly(a,[(9,8),(14,10),(26,22),(24,28),(17,27),(10,14)],(222,214,196))
    ell(a,(17,20,28,30),(222,214,196))
    for (x,y) in [(19,28),(22,29),(25,27)]:px(a,x,y,(170,160,150))
    for (x,y) in [(13,13),(16,17),(19,20),(15,12)]:px(a,x,y,(196,188,170))
    rect(a,(9,8,11,10),(190,160,60));return done(a)
def zippo():
    a=canvas(32,32);rect(a,(10,12,21,28),(170,176,186));rect(a,(10,12,21,13),(210,214,222));rect(a,(10,8,21,11),(150,156,166));rect(a,(13,8,13,11),(90,90,96));rect(a,(16,8,16,11),(90,90,96))
    poly(a,[(15,7),(18,1),(20,5),(19,7)],(255,170,40));poly(a,[(16,7),(18,3),(19,7)],(255,236,120));rect(a,(11,14,12,26),(220,224,230));return done(a)
def can():
    a=canvas(32,32);rect(a,(10,6,21,28),(40,180,90));rect(a,(10,5,21,6),(190,196,200));rect(a,(10,28,21,29),(190,196,200));poly(a,[(13,12),(19,12),(14,22)],(255,240,90));poly(a,[(18,14),(16,24),(14,22)],(255,240,90));rect(a,(11,7,12,27),(90,220,140));return done(a)
def medpouch():
    a=canvas(32,32);rect(a,(6,10,25,27),(150,40,40));rect(a,(6,10,25,14),(120,30,30));rect(a,(13,4,18,10),(90,90,90));rect(a,(14,15,17,25),(245,245,245));rect(a,(11,18,20,21),(245,245,245));return done(a)
def walkie():
    a=canvas(32,32);rect(a,(10,9,21,29),(40,44,50));rect(a,(18,1,19,9),(30,30,34));rect(a,(12,11,19,17),(120,200,120));
    for y in range(20,27,2):rect(a,(12,y,19,y),(70,74,82));px(a,21,12,(200,40,40));return done(a)
def relic():
    a=canvas(32,32);line(a,[(8,3),(16,16),(24,3)],(200,170,90),1);rect(a,(14,14,18,30),(230,196,90));rect(a,(9,18,23,21),(230,196,90));ell(a,(14,18,18,22),(120,200,255));return done(a)
def stopwatch():
    a=canvas(32,32);rect(a,(14,2,18,5),(170,176,186));ell(a,(5,6,27,28),(190,196,204));ell(a,(8,9,24,25),(242,240,232));line(a,[(16,17),(16,10)],(30,30,30));line(a,[(16,17),(21,19)],(200,40,40));px(a,16,17,(30,30,30));
    for (x,y) in [(16,10),(23,17),(16,24),(9,17)]:px(a,x,y,(90,90,90));return done(a)
def seedpouch():
    a=canvas(32,32);ell(a,(6,10,26,29),(140,100,60));rect(a,(12,7,20,12),(120,84,50));line(a,[(11,10),(21,10)],(200,170,90));poly(a,[(16,7),(10,1),(14,6)],(80,180,70));poly(a,[(16,7),(23,2),(18,7)],(100,200,80));ell(a,(13,17,19,23),(90,170,70));return done(a)
def dogtags():
    a=canvas(32,32);line(a,[(6,2),(12,14)],(160,160,166));line(a,[(26,2),(18,14)],(160,160,166))
    for x0,y0 in [(8,12),(15,15)]:
        rect(a,(x0,y0,x0+8,y0+13),(184,190,198));rect(a,(x0+1,y0+3,x0+7,y0+3),(120,124,132));rect(a,(x0+1,y0+6,x0+6,y0+6),(120,124,132));rect(a,(x0+1,y0+9,x0+5,y0+9),(120,124,132))
    return done(a)
def tome():
    a=canvas(32,32);rect(a,(6,5,25,28),(70,30,90));rect(a,(6,5,9,28),(50,20,66));rect(a,(23,7,26,27),(220,214,200));ell(a,(12,11,21,20),(120,230,140));ell(a,(15,13,18,18),(30,10,30));px(a,16,15,(255,255,255));return done(a)
def golddie():
    a=canvas(32,32);poly(a,[(16,3),(28,9),(16,15),(4,9)],(255,224,110));poly(a,[(4,9),(16,15),(16,29),(4,22)],(220,170,50));poly(a,[(28,9),(16,15),(16,29),(28,22)],(180,130,30))
    for (x,y) in [(16,9),(9,16),(12,21),(20,17),(24,22),(22,12)]:rect(a,(x,y,x+1,y+1),(70,40,10));return done(a)
def dicepin():
    a=canvas(32,32);ell(a,(3,3,28,28),(170,40,50));ell(a,(6,6,25,25),(30,26,40));rect(a,(9,10,16,17),(245,245,245));rect(a,(15,15,22,22),(245,245,245))
    for (x,y) in [(10,11),(14,15),(12,13)]:px(a,x,y,(20,20,20))
    for (x,y) in [(16,16),(20,16),(16,20),(20,20),(18,18)]:px(a,x,y,(20,20,20))
    return done(a)
def tesla_gauntlet():
    a=canvas(32,32);rect(a,(8,14,20,28),(110,90,60));rect(a,(8,12,22,16),(150,120,70));ell(a,(17,6,27,16),(90,96,110));ell(a,(20,9,24,13),(120,220,255))
    for (x,y) in [(25,4),(27,2),(28,6),(29,3)]:px(a,x,y,(160,240,255))
    return done(a)
def exo():
    im=tint(armory('platemail'),(120,170,220),.55);a=np.array(im)
    for y in range(8,26,4):
        for x in range(10,22):
            if a[y,x,3]>0 and x%3==0:a[y,x,:3]=(120,240,255)
    return Image.fromarray(a)
