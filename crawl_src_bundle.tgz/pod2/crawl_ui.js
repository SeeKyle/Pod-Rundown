// ======================================================================= UI (browser only)
const IMG=new Image();IMG.src='crawl.png?v=__VER__';const BGI=new Image();BGI.src='crawl_bg.png?v=__VER__';
const SP=ATLAS.sprites,BGA=ATLAS.bg,RES=ATLAS.res||1;const UNITS=ATLAS.units||{};const UIMG=new Image();UIMG.src='crawl_units.png?v=__VER__';const RAIN={f:{fw:5,fh:18,n:1,ax:2,ay:17,x:0,y:0,img:'rain'},s:{fw:5,fh:11,n:1,ax:2,ay:10,x:8,y:7,img:'rain'}};
const CAMPF={fw:34,fh:40,ax:17,ay:37,y:0,img:'camp'};
const XIMG={wraith:new Image(),harvest:new Image(),cityob:new Image(),cars:new Image(),cultist:new Image(),tentacle:new Image(),robot:new Image(),obst:new Image(),lumberjack:new Image(),camp:new Image(),druid:new Image(),tornado:new Image(),vine:new Image(),thorn:new Image(),rain:new Image(),flannel:new Image(),boom:new Image(),pal:new Image(),chibi:new Image(),wave:new Image(),archer:new Image()};XIMG.archer.src='crawl_archer.png?v=__VER__';XIMG.wave.src='crawl_wave.png?v=__VER__';XIMG.chibi.src='crawl_chibi.png?v=__VER__';XIMG.flannel.src='crawl_flannel.png?v=__VER__';XIMG.jp=new Image();XIMG.jp.src='crawl_jp.png?v=__VER__';XIMG.eng=new Image();XIMG.eng.src='crawl_eng.png?v=__VER__';XIMG.shoshi=new Image();XIMG.shoshi.src='crawl_shoshi.png?v=__VER__';XIMG.skel=new Image();XIMG.skel.src='crawl_skel.png?v=__VER__';XIMG.knight=new Image();XIMG.knight.src='crawl_knight.png?v=__VER__';XIMG.carcher=new Image();XIMG.carcher.src='crawl_carcher.png?v=__VER__';XIMG.csorc=new Image();XIMG.csorc.src='crawl_csorc.png?v=__VER__';XIMG.soldier=new Image();XIMG.soldier.src='crawl_soldier.png?v=__VER__';XIMG.screamer=new Image();XIMG.screamer.src='crawl_screamer.png?v=__VER__';XIMG.flame=new Image();XIMG.flame.src='crawl_flame.png?v=__VER__';XIMG.rain.src='crawl_rain.png?v=__VER__';XIMG.druid.src='crawl_druid.png?v=__VER__';XIMG.camp.src='crawl_campfire.png?v=__VER__';XIMG.lumberjack.src='crawl_lumberjack.png?v=__VER__';XIMG.tornado.src='crawl_fx_tornado.png?v=__VER__';XIMG.vine.src='crawl_fx_vine.png?v=__VER__';XIMG.thorn.src='crawl_fx_thorn.png?v=__VER__';
const TORN={fw:96,fh:96,n:16,ax:48,ay:90,x:0,y:0,img:'tornado',art:1},VINE={fw:260,fh:116,n:7,ax:130,ay:110,x:0,y:0,img:'vine',art:1};
const THORNS=[[0,35,53],[37,67,79],[106,36,82],[144,87,74]].map(([x,w,h])=>({fw:w,fh:h,n:1,ax:w/2,ay:81,x,y:82-h,img:'thorn',art:1}));XIMG.pal.src='crawl_pal.png?v=__VER__';XIMG.dog=new Image();XIMG.dog.src='crawl_dog.png?v=__VER__';XIMG.bat=new Image();XIMG.bat.src='crawl_bat.png?v=__VER__';XIMG.edward=new Image();XIMG.edward.src='crawl_edward.png?v=__VER__';XIMG.cheez=new Image();XIMG.cheez.src='crawl_cheez.png?v=__VER__';XIMG.obst.src='crawl_obst.png?v=__VER__';XIMG.cityob.src='crawl_cityob.png?v=__VER__';XIMG.harvest.src='crawl_harvest.png?v=__VER__';XIMG.wraith.src='crawl_wraith.png?v=__VER__';XIMG.cars.src='crawl_cars.png?v=__VER__';XIMG.robot.src='crawl_robot.png?v=__VER__';XIMG.cultist.src='crawl_cultist.png?v=__VER__';XIMG.tentacle.src='crawl_tentacle.png?v=__VER__';XIMG.boom.src='crawl_boom.png?v=__VER__';
const WAVE={fw:110,fh:68,n:1,ax:48,ay:63,x:0,y:0,img:'wave'};   // Wave Dash energy wave (3 flickering frames)
const BOOM={fw:128,fh:131,n:15,ax:64,ay:128,x:0,y:0,img:'boom',art:1};   // explosion frames from Kyle's sheet (15 frames, half size)
const ART_SCALE=21/152;   // full-detail character art drawn at the in-game size Kyle liked (his 152px-tall art = 21 world px)
const GQ=2;   // the game canvas renders at 2x its old pixel density so full-detail art stays clean (pixel art still draws crisp)
const $=(s,r)=>(r||document).querySelector(s);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const fmt=n=>Math.round(n).toLocaleString('en-US');
// ---------------------------------------------------------------- sound (tiny WebAudio blips)
let AC=null,muted=false;try{muted=localStorage.getItem('podrundown-crawl-mute')==='1';}catch(e){}
// ---- 0.12.35 music: one original track (Night Shift, made for the game) + four dark-synth tracks from OpenGameArt (all CC0 / public domain),
//   streamed from OpenGameArt like the old loop. ⏭ cycles them; a track that won't load is skipped automatically.
const OGA='https://opengameart.org/sites/default/files/';
const TRACKS=[{name:'Night Shift',by:'made for Crypt Crawl',info:'gritty pulse + sax',src:['music/nightshift.ogg','music/nightshift.mp3']},
  {name:'Dark Night',by:'Alex McCulloch (Pro Sensory)',info:'dark synthwave rock',src:[OGA+'dark_night.mp3']},
  {name:'Nova',by:'SpringySpringo',info:'melancholy dark synthwave',src:[OGA+'nova.mp3']},
  {name:'Futility Belt',by:'iamoneabe',info:'long darksynth / synthpop',src:[OGA+'futilitybelt.mp3']},
  {name:'Dark Things',by:'iamoneabe',info:'short dark synth loop',src:[OGA+'dark_things_loop.mp3']},
  {name:'Zombie Main',by:'Augmentality (Brandon Morris), CC0',info:'eerie zombie-game menu music',src:[OGA+'zombie%20main%20music.ogg']},   /* 0.12.219 (Kyle): more creepy tracks, all CC0 from OpenGameArt */
  {name:'Insistent',by:'yd, CC0',info:'dark, quiet horror loop',src:[OGA+'Insistent.ogg']},
  {name:'Dark Cavern',by:'Paul Wortmann, CC0',info:'creepy ambient: moans, wind, creaks',src:[OGA+'dark_cavern_ambient_002.ogg']},
  {name:'Ambient Horror',by:'ShggothSlave, CC0',info:'long ambient horror piece',src:[OGA+'ambient_horror_song.mp3']}];
let BGM=null,musicMuted=false,musicVol=.45,trackI=0,trackFails=0;try{musicMuted=localStorage.getItem('podrundown-crawl-music-mute')==='1';const v=localStorage.getItem('podrundown-crawl-music-vol');if(v!=null)musicVol=+v;
  const ti=+localStorage.getItem('podrundown-crawl-music-track');if(ti>=0&&ti<TRACKS.length)trackI=ti;}catch(e){}
function trackSrc(i){const s=TRACKS[i].src;const a=new Audio();return s.find(x=>!x.endsWith('.ogg')||a.canPlayType('audio/ogg; codecs="vorbis"'))||s[s.length-1];}
function musicStart(){try{if(!BGM){BGM=new Audio();BGM.loop=true;BGM.preload='auto';
      BGM.addEventListener('error',()=>{if(++trackFails<TRACKS.length){const T=musicNext(true);if(typeof flash==='function'&&!root.hidden)flash('♫ couldn\'t load that one, now: '+T.name,1800);}});
      BGM.addEventListener('playing',()=>{trackFails=0;});BGM.src=trackSrc(trackI);}
  BGM.volume=musicVol;if(!musicMuted&&musicVol>0)BGM.play().catch(()=>{});else BGM.pause();}catch(e){}}
function musicNext(auto){trackI=(trackI+1)%TRACKS.length;if(!auto)trackFails=0;try{localStorage.setItem('podrundown-crawl-music-track',trackI);}catch(_){}
  try{if(BGM){BGM.pause();BGM.src=trackSrc(trackI);BGM.load();}}catch(e){}musicStart();try{const tb=document.querySelector('#cc [data-a="track"]');if(tb)tb.title='Next track (now: '+TRACKS[trackI].name+')';}catch(_){}return TRACKS[trackI];}
function musicStop(){try{if(BGM)BGM.pause();}catch(e){}}
function sfx(k,o){if(muted)return;try{AC=AC||new (window.AudioContext||window.webkitAudioContext)();const t=AC.currentTime;
  const tone=(f,d,type,v,f2)=>{const o=AC.createOscillator(),g=AC.createGain();o.type=type||'square';o.frequency.setValueAtTime(f,t);if(f2)o.frequency.exponentialRampToValueAtTime(f2,t+d);
    g.gain.setValueAtTime(v||.05,t);g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g);g.connect(AC.destination);o.start(t);o.stop(t+d);};
  if(k==='hit')tone(180,.06,'square',.025,90);if(k==='crit')tone(520,.1,'square',.04,180);
  if(k==='level'){[523,659,784,1046].forEach((f,i)=>{const o=AC.createOscillator(),g=AC.createGain();o.type='square';o.frequency.value=f;g.gain.setValueAtTime(.04,t+i*.07);g.gain.exponentialRampToValueAtTime(.0001,t+i*.07+.12);o.connect(g);g.connect(AC.destination);o.start(t+i*.07);o.stop(t+i*.07+.13);});}
  if(k==='glass'){   /* 0.12.228 bottle smash: a sharp crack, bright tinkling shards, then (if it drew any) a few low zombie grunts */
    const n=Math.floor(AC.sampleRate*.3),b=AC.createBuffer(1,n,AC.sampleRate),c=b.getChannelData(0);for(let i=0;i<n;i++)c[i]=(Math.random()*2-1)*Math.pow(1-i/n,6);
    const s=AC.createBufferSource(),f=AC.createBiquadFilter(),g=AC.createGain();s.buffer=b;f.type='highpass';f.frequency.value=3000;g.gain.value=.35;s.connect(f);f.connect(g);g.connect(AC.destination);s.start(t);
    for(let i=0;i<9;i++){const dt=.02+Math.random()*.35,o=AC.createOscillator(),gg=AC.createGain();o.type='sine';o.frequency.value=3500+Math.random()*4500;gg.gain.setValueAtTime(.03+Math.random()*.03,t+dt);gg.gain.exponentialRampToValueAtTime(.0001,t+dt+.06+Math.random()*.06);o.connect(gg);gg.connect(AC.destination);o.start(t+dt);o.stop(t+dt+.15);}
    const z=Math.min(3,(o&&o.n)||0);for(let i=0;i<z;i++){const t0=t+.55+i*(.35+Math.random()*.25),d=.45+Math.random()*.3,os=AC.createOscillator(),fl=AC.createBiquadFilter(),gn=AC.createGain(),lfo=AC.createOscillator(),lg=AC.createGain();
      os.type='sawtooth';const f0=70+Math.random()*40;os.frequency.setValueAtTime(f0,t0);os.frequency.linearRampToValueAtTime(f0*1.25,t0+d*.4);os.frequency.linearRampToValueAtTime(f0*.8,t0+d);lfo.frequency.value=22+Math.random()*10;lg.gain.value=12;lfo.connect(lg);lg.connect(os.frequency);
      fl.type='lowpass';fl.frequency.value=700;gn.gain.setValueAtTime(0,t0);gn.gain.linearRampToValueAtTime(.12,t0+.06);gn.gain.exponentialRampToValueAtTime(.001,t0+d);os.connect(fl);fl.connect(gn);gn.connect(AC.destination);os.start(t0);lfo.start(t0);os.stop(t0+d);lfo.stop(t0+d);}
    return;}
  if(k==='clunk'){tone(70,.22,'sine',.5,40);tone(150,.1,'square',.08,90);   /* 0.12.222 (Kyle) Toolbox_Toss: a heavy metal box clunking into something, tools rattling inside */
    const n=Math.floor(AC.sampleRate*.35),b=AC.createBuffer(1,n,AC.sampleRate),c=b.getChannelData(0);for(let i=0;i<n;i++){const q=i/n;c[i]=(Math.random()*2-1)*Math.pow(1-q,4)*.9+((i%Math.floor(AC.sampleRate/1700))<3?.25*Math.pow(1-q,2):0);}
    const s=AC.createBufferSource(),f=AC.createBiquadFilter(),g=AC.createGain();s.buffer=b;f.type='bandpass';f.frequency.value=2300;f.Q.value=3;g.gain.value=.45;s.connect(f);f.connect(g);g.connect(AC.destination);s.start(t);
    for(const [dt,fq] of [[.07,3100],[.13,2600],[.2,3400]]){const o=AC.createOscillator(),gg=AC.createGain();o.type='triangle';o.frequency.value=fq;gg.gain.setValueAtTime(.04,t+dt);gg.gain.exponentialRampToValueAtTime(.0001,t+dt+.05);o.connect(gg);gg.connect(AC.destination);o.start(t+dt);o.stop(t+dt+.06);}return;}
  if(k==='rifle'){const d=.7,n=Math.floor(AC.sampleRate*d),buf=AC.createBuffer(1,n,AC.sampleRate),ch=buf.getChannelData(0);   /* 0.12.201 (Kyle) JP's Kar98: a loud sharp crack with a rolling echo */
    for(let i=0;i<n;i++){const q=i/n;ch[i]=(Math.random()*2-1)*(Math.pow(1-q,5)+.22*Math.pow(1-q,1.6)*(q>.12?1:0));}
    const s=AC.createBufferSource(),f=AC.createBiquadFilter(),g=AC.createGain();s.buffer=buf;f.type='lowpass';f.frequency.value=3200;g.gain.value=.85;s.connect(f);f.connect(g);g.connect(AC.destination);s.start(t);
    tone(110,.3,'sine',.45,38);tone(2200,.04,'square',.06,900);return;}
  if(k==='nail'){const d=.09,n=Math.floor(AC.sampleRate*d),buf=AC.createBuffer(1,n,AC.sampleRate),ch=buf.getChannelData(0);   /* 0.12.268 (Kyle): Edward's nail gun: a soft pneumatic thup, not a gunshot */
    for(let i=0;i<n;i++)ch[i]=(Math.random()*2-1)*Math.pow(1-i/n,5);
    const s=AC.createBufferSource(),f=AC.createBiquadFilter(),g=AC.createGain();s.buffer=buf;f.type='lowpass';f.frequency.value=900;g.gain.value=.07;
    s.connect(f);f.connect(g);g.connect(AC.destination);s.start(t);tone(210,.05,'sine',.035,120);}
  if(k==='gun'||k==='biggun'){const big=k==='biggun',d=big?.45:.16,n=Math.floor(AC.sampleRate*d),buf=AC.createBuffer(1,n,AC.sampleRate),ch=buf.getChannelData(0);
    for(let i=0;i<n;i++)ch[i]=(Math.random()*2-1)*Math.pow(1-i/n,big?2.2:3.5);
    const s=AC.createBufferSource(),f=AC.createBiquadFilter(),g=AC.createGain();s.buffer=buf;f.type='lowpass';f.frequency.value=big?2400:1800;g.gain.value=big?.55:.16;
    s.connect(f);f.connect(g);g.connect(AC.destination);s.start(t);tone(big?90:140,big?.35:.12,'sine',big?.35:.09,big?32:60);if(big)tone(1400,.06,'square',.03,500);}
  if(k==='shriek'){const d=1.25,g=AC.createGain(),f=AC.createBiquadFilter();f.type='bandpass';f.frequency.value=1400;f.Q.value=1.2;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.265,t+.08);g.gain.setValueAtTime(.265,t+d*.7);   /* 0.12.201 (Kyle): ~17% quieter */g.gain.exponentialRampToValueAtTime(.001,t+d);   /* 0.12.175 the Screamer's shriek: two detuned saws wailing up and cracking, with a raspy noise layer */
    for(const det of [0,23]){const o=AC.createOscillator(),lfo=AC.createOscillator(),lg=AC.createGain();o.type='sawtooth';o.frequency.setValueAtTime(700+det,t);o.frequency.linearRampToValueAtTime(1500+det,t+.25);o.frequency.linearRampToValueAtTime(1250+det,t+.8);o.frequency.linearRampToValueAtTime(820+det,t+d);
      lfo.frequency.value=9+det/10;lg.gain.value=60;lfo.connect(lg);lg.connect(o.frequency);o.connect(f);lfo.start(t);o.start(t);o.stop(t+d);lfo.stop(t+d);}
    {const n=Math.floor(AC.sampleRate*d),b=AC.createBuffer(1,n,AC.sampleRate),c=b.getChannelData(0);for(let i=0;i<n;i++)c[i]=(Math.random()*2-1)*.35;const s=AC.createBufferSource();s.buffer=b;s.connect(f);s.start(t);}
    f.connect(g);g.connect(AC.destination);}
  if(k==='shotgun'){const d=.6,n=Math.floor(AC.sampleRate*d),buf=AC.createBuffer(1,n,AC.sampleRate),ch=buf.getChannelData(0);for(let i=0;i<n;i++)ch[i]=(Math.random()*2-1)*Math.pow(1-i/n,3);   /* 0.12.158 one big loud shotgun blast */
    const s=AC.createBufferSource(),f=AC.createBiquadFilter(),g=AC.createGain();s.buffer=buf;f.type='lowpass';f.frequency.setValueAtTime(5000,t);f.frequency.exponentialRampToValueAtTime(400,t+d);g.gain.value=.9;
    s.connect(f);f.connect(g);g.connect(AC.destination);s.start(t);tone(70,.45,'sine',.55,28);tone(2200,.04,'square',.06,600);}
  if(k==='boom'){const d=1.1,n=Math.floor(AC.sampleRate*d),buf=AC.createBuffer(1,n,AC.sampleRate),ch=buf.getChannelData(0);for(let i=0;i<n;i++)ch[i]=(Math.random()*2-1)*Math.pow(1-i/n,1.6);
    const s=AC.createBufferSource(),f=AC.createBiquadFilter(),g=AC.createGain();s.buffer=buf;f.type='lowpass';f.frequency.setValueAtTime(1600,t);f.frequency.exponentialRampToValueAtTime(220,t+d);g.gain.value=.7;
    s.connect(f);f.connect(g);g.connect(AC.destination);s.start(t);tone(60,.8,'sine',.5,24);}
  if(k==='lazer'){const d=(o&&o.d)||1,out=AC.createGain(),lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.value=2200;out.gain.setValueAtTime(.0001,t);out.gain.exponentialRampToValueAtTime(.09,t+.04);out.gain.setValueAtTime(.09,t+d-.08);out.gain.exponentialRampToValueAtTime(.0001,t+d);
    const am=AC.createGain();am.gain.value=.55;const lfo=AC.createOscillator();lfo.frequency.value=48;const lg=AC.createGain();lg.gain.value=.45;lfo.connect(lg);lg.connect(am.gain);   /* the bzzzz: two buzzy tones chopped 48 times a second */
    for(const [f,ty,v] of [[92,'sawtooth',.9],[184,'square',.35],[1240,'sine',.12]]){const os=AC.createOscillator(),g2=AC.createGain();os.type=ty;os.frequency.setValueAtTime(f,t);if(f>1000)os.frequency.exponentialRampToValueAtTime(820,t+d);g2.gain.value=v;os.connect(g2);g2.connect(am);os.start(t);os.stop(t+d);}
    am.connect(lp);lp.connect(out);out.connect(AC.destination);lfo.start(t);lfo.stop(t+d);}
  if(k==='flame'){if(t-(sfx.lastFlame||0)<.3)return;sfx.lastFlame=t;const d=.55,n=Math.floor(AC.sampleRate*d),buf=AC.createBuffer(1,n,AC.sampleRate),ch=buf.getChannelData(0);let b=0;
    for(let i=0;i<n;i++){b=b*.82+(Math.random()*2-1)*.18;ch[i]=(b*2.2+(Math.random()*2-1)*.35)*Math.min(1,i/(AC.sampleRate*.04))*Math.pow(1-i/n,.7)*(.8+.2*Math.sin(i/AC.sampleRate*60));}   /* roaring, flickering rumble */
    const src=AC.createBufferSource(),bp=AC.createBiquadFilter(),lp2=AC.createBiquadFilter(),g2=AC.createGain();src.buffer=buf;bp.type='bandpass';bp.frequency.setValueAtTime(700,t);bp.frequency.linearRampToValueAtTime(1100,t+d);bp.Q.value=.6;lp2.type='lowpass';lp2.frequency.value=2600;g2.gain.value=.32;
    src.connect(bp);bp.connect(lp2);lp2.connect(g2);g2.connect(AC.destination);src.start(t);tone(70,.45,'sine',.12,45);}
  if(k==='alarm'){const V=(o&&o.vol)||1,v=(o&&o.v)||0,g0=AC.createGain(),f=AC.createBiquadFilter();f.type='lowpass';f.frequency.value=2600;g0.gain.value=.075*V;f.connect(g0);g0.connect(AC.destination);   /* 0.12.203 alarm variants: wee-woo, whoop, chirp */
    const os=AC.createOscillator();os.type=v===1?'sawtooth':'square';
    if(v===0){os.frequency.setValueAtTime(980,t);os.frequency.setValueAtTime(720,t+.42);}
    else if(v===1){os.frequency.setValueAtTime(520,t);os.frequency.exponentialRampToValueAtTime(1350,t+.85);}
    else{for(let i=0;i<6;i++)os.frequency.setValueAtTime(i%2?1500:1150,t+i*.12);}
    const ga=AC.createGain();ga.gain.setValueAtTime(0,t);ga.gain.linearRampToValueAtTime(1,t+.03);ga.gain.setValueAtTime(1,t+(v===2?.7:.8));ga.gain.linearRampToValueAtTime(0,t+(v===2?.74:.86));
    os.connect(ga);ga.connect(f);os.start(t);os.stop(t+.9);}
  if(k==='bell'){const d=1.1,gn=AC.createGain(),BV=(o&&o.vol)||1;gn.gain.setValueAtTime(0,t);for(let i=0;i<d*28;i++){const tt=t+i/28;gn.gain.setValueAtTime(.05*BV,tt);gn.gain.exponentialRampToValueAtTime(.004,tt+.03);}gn.gain.setValueAtTime(0,t+d);gn.connect(AC.destination);
    for(const f of [2330,3110,4480]){const o=AC.createOscillator();o.type=f>4000?'sine':'square';o.frequency.value=f;const g2=AC.createGain();g2.gain.value=f>4000?.6:.35;o.connect(g2);g2.connect(gn);o.start(t);o.stop(t+d);}}
  if(k==='dash'){tone(240,.25,'sawtooth',.05,900);tone(1200,.2,'sine',.04,300);}
  if(k==='shout'){tone(160,.5,'sawtooth',.07,120);tone(240,.45,'square',.04,200);}
  if(k==='bow'){tone(320,.09,'triangle',.06,120);tone(900,.05,'sine',.03,400);}
  if(k==='heal'){[660,880,1320].forEach((f,i)=>{const o=AC.createOscillator(),gn=AC.createGain();o.type='sine';o.frequency.value=f;gn.gain.setValueAtTime(.035,t+i*.06);gn.gain.exponentialRampToValueAtTime(.0001,t+i*.06+.25);o.connect(gn);gn.connect(AC.destination);o.start(t+i*.06);o.stop(t+i*.06+.26);});}
  if(k==='thorns'){tone(110,.35,'square',.06,50);tone(70,.4,'sawtooth',.05,40);}
  if(k==='wind'){const d=1.6,n=Math.floor(AC.sampleRate*d),buf=AC.createBuffer(1,n,AC.sampleRate),ch=buf.getChannelData(0);for(let i=0;i<n;i++)ch[i]=(Math.random()*2-1)*Math.sin(Math.PI*i/n);
    const s2=AC.createBufferSource(),f2=AC.createBiquadFilter(),g2=AC.createGain();s2.buffer=buf;f2.type='bandpass';f2.frequency.setValueAtTime(500,t);f2.frequency.linearRampToValueAtTime(1400,t+d);g2.gain.value=.25;s2.connect(f2);f2.connect(g2);g2.connect(AC.destination);s2.start(t);}
  if(k==='camp'){tone(1800,.04,'square',.03,1200);setTimeout(()=>tone(220,.6,'triangle',.05,120),180);}
  if(k==='whoosh'){tone(300,.18,'sawtooth',.03,90);}
  if(k==='boss')tone(70,1.2,'sawtooth',.08,40);if(k==='clear')tone(392,.5,'triangle',.07,784);if(k==='die')tone(220,.6,'sawtooth',.06,55);
}catch(e){}}
// ---------------------------------------------------------------- pixel font (3x5) for numbers + a few letters
const FONT={'0':'111101101101111','1':'010110010010111','2':'111001111100111','3':'111001111001111','4':'101101111001001','5':'111100111001111','6':'111100111101111','7':'111001010010010','8':'111101111101111','9':'111101111001111','+':'000010111010000',
  'm':'000111111101101','i':'010000010010010','s':'011100010001110','d':'001001111101111','o':'000111101101111','g':'111101111001110','e':'111101111100111','L':'100100100100111','V':'101101101101010',' ':'000000000000000','x':'000101010101000'};
function ptext(ctx,s,x,y,col,sc){sc=sc||1;
  if([...s].some(ch=>!FONT[ch])){ctx.save();ctx.font=`${8*sc}px "Press Start 2P",monospace`;ctx.textAlign='center';ctx.textBaseline='top';ctx.fillStyle='#0c0810';ctx.fillText(s.toUpperCase(),Math.round(x)+1,Math.round(y)+1);ctx.fillStyle=col;ctx.fillText(s.toUpperCase(),Math.round(x),Math.round(y));ctx.restore();return;}const w=s.length*4*sc;let cx=Math.round(x-w/2);y=Math.round(y);
  for(const ch of s){const g=FONT[ch];if(g){ctx.fillStyle='#0c0810';for(let i=0;i<15;i++)if(g[i]==='1')ctx.fillRect(cx+(i%3)*sc+sc,y+Math.floor(i/3)*sc+sc,sc,sc);
    ctx.fillStyle=col;for(let i=0;i<15;i++)if(g[i]==='1')ctx.fillRect(cx+(i%3)*sc,y+Math.floor(i/3)*sc,sc,sc);}cx+=4*sc;}}
// ---------------------------------------------------------------- renderer
function spr(ctx,name,fr,x,y,flip,alpha,flash){const a=SP[name];if(!a)return;const [sx,sy,w,h,n]=a;fr=Math.max(0,Math.min(n-1,fr|0));const dw=w/RES,dh=h/RES;
  const X=Math.round(x*RES)/RES,Y=Math.round(y*RES)/RES;
  ctx.save();if(alpha!=null)ctx.globalAlpha=alpha;
  if(flip){ctx.translate(X+dw,Y);ctx.scale(-1,1);ctx.drawImage(IMG,sx+fr*w,sy,w,h,0,0,dw,dh);}
  else ctx.drawImage(IMG,sx+fr*w,sy,w,h,X,Y,dw,dh);
  if(flash>0){ctx.globalCompositeOperation='lighter';ctx.globalAlpha=Math.min(1,flash*6)*.7;if(flip)ctx.drawImage(IMG,sx+fr*w,sy,w,h,0,0,dw,dh);else ctx.drawImage(IMG,sx+fr*w,sy,w,h,X,Y,dw,dh);}
  ctx.restore();}
const FW=a=>a[2]/RES,FH=a=>a[3]/RES;
// new hand-picked unit sprites: one image per frame strip, drawn with the feet on the ground line
function unitFrame(e,U){const A=e.animT>0&&U.atk?U.atk:U.walk;let fr;
  if(e.scrT>0&&U.scream){const T=e.E.scream.T,k=1-e.scrT/T,n=U.scream.n;return [U.scream,k<.3?Math.floor(k/.3*2):2+Math.floor(k*14)%(n-2)];}   /* 0.12.175 Screamer: rears back, then shrieks (last frames looping) */
  if(e.leapA&&U.jump){const v=e.leapA.t/e.leapA.dur;const J=v<.5?U.jump:U.fall;return [Object.assign({},J,{ay:U.walk.ay-Math.round(Math.sin(Math.PI*Math.min(1,v))*14)}),Math.min(J.n-1,Math.floor((v<.5?v*2:(v-.5)*2)*J.n))];}   // leap arc
  if(A===U.atk){const dur=e.E.animAtk||.3;fr=Math.min(A.n-1,Math.floor((1-e.animT/dur)*A.n));return [A,fr];}
  if(U.idle&&e.moving===false)return [U.idle,Math.floor(e.walkT*6)%U.idle.n];
  return [A,Math.floor(e.walkT*(e.E.fps||7))%A.n];}
let GHOST_A=1;   /* 0.12.107: <1 while drawing the Shadow_Clone */
function drawUnit(ctx,A,fr,x,gy,sc,alpha,flash,rot,flip){const IM=A.img?XIMG[A.img]:UIMG;if(!IM||!IM.complete)return;ctx.save();ctx.translate(Math.round(x*RES)/RES,Math.round(gy*RES)/RES);if(rot)ctx.rotate(rot);{const sx=sc*(A.sx||1);ctx.scale(flip?-sx:sx,sc);}if(alpha!=null)ctx.globalAlpha=alpha*GHOST_A;else if(GHOST_A<1)ctx.globalAlpha*=GHOST_A;
  if(A.art){ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';}const sx=A.x+fr*A.fw;ctx.drawImage(IM,sx,A.y,A.fw,A.fh,-A.ax,-A.ay-1,A.fw,A.fh);
  if(flash>0){ctx.globalCompositeOperation='lighter';ctx.globalAlpha=Math.min(1,flash*6)*.7;ctx.drawImage(IM,sx,A.y,A.fw,A.fh,-A.ax,-A.ay-1,A.fw,A.fh);}ctx.restore();}
/* 0.12.117 (Kyle): downtown street lamps are lit live. Each lamp has a kind and its own timing (seed), so along the
   two-screen loop some hum steadily, some stutter, one sputters on and off, one is dying, one is dead, and one hangs by its wire.
   The faulty ones throw sparks now and then: they fall, most burn out in the air, a few land and flicker out on the pavement. */
const LH=(n)=>{const v=Math.sin(n*12.9898+78.233)*43758.5453;return v-Math.floor(v);};
let LAMP_HALO=null;
function lampHalo(){if(LAMP_HALO)return LAMP_HALO;const c=document.createElement('canvas');c.width=60;c.height=80;const x=c.getContext('2d'),im=x.createImageData(60,80);
  for(let yy=0;yy<80;yy++)for(let xx=0;xx<60;xx++){const dx=xx-30,dy=yy-10,r=Math.hypot(dx,dy*(dy>0?.42:1.6)),a=Math.max(0,62-r*3.1);if(a>0){const i=(yy*60+xx)*4;im.data[i]=255;im.data[i+1]=186;im.data[i+2]=90;im.data[i+3]=a;}}
  x.putImageData(im,0,0);return LAMP_HALO=c;}
function lampLevel(k,t,sd){
  if(k==='dead'||k==='broken')return 0;
  if(k==='ok')return .94+.06*Math.sin(t*47+sd*9);
  if(k==='flicker'){const burst=((t*.21+sd)%1)<.3;if(!burst)return 1;const n=LH(Math.floor(t*17)+sd*977);return n<.4?0:n<.55?.35:1;}
  if(k==='sputter'){const P=7+sd*4,ph=((t+sd*20)%P)/P;if(ph>.42)return 0;const n=LH(Math.floor(t*11)+sd*311);return (ph<.04||n<.12)?(n<.5?0:.5):1;}
  if(k==='dying'){const n=LH(Math.floor(t*6)+sd*53);const surge=((t*.13+sd)%1)<.05;return surge?(LH(Math.floor(t*20))<.5?1:.2):(n<.15?.05:.32+.06*Math.sin(t*30));}
  return 1;}
function drawLamps(ctx,L,x0,y0,W,t){const s=L.w/L.r[2],gy=y0+L.ground*s;const H=lampHalo();
  for(const [ax,ay,k,sd] of L.lamps){const hx=x0+ax*s,hy=y0+ay*s;if(hx<-40||hx>W+40)continue;
    // spark events: a lamp shorts out every few seconds (not every period, so it never feels metronomic)
    let flash=0;const spk=k==='flicker'||k==='broken'||k==='sputter'||k==='dying';
    if(spk){const P=(k==='broken'?2.2:3.5)+sd*4,ofs=sd*7,e=Math.floor((t+ofs)/P),dt=t+ofs-e*P;
      if(LH(e*7.1+sd*13)<(k==='broken'?.75:.5)&&dt<2){if(dt<.1)flash=1-dt/.1;
        const N=4+Math.floor(LH(e+sd)*7),G=150*s/.75;
        for(let i=0;i<N;i++){const h1=LH(e*31+i*7+sd*100),h2=LH(e*17+i*3+sd*50),h3=LH(e*13+i*11+sd*70);
          const vx=(h1-.5)*40*s,vy=(-4-h2*22)*s,life=.12+h3*.9;
          const tl=(-vy+Math.sqrt(vy*vy+2*G*(gy-hy)))/G;   // when it would reach the pavement
          if(dt<Math.min(life,tl)){const px=hx+vx*dt,py=hy+vy*dt+.5*G*dt*dt,age=dt/Math.min(life,tl);
            ctx.globalAlpha=1-age*.5;ctx.fillStyle=age<.25?'#fffbe0':age<.6?'#ffd040':'#ff8a20';ctx.fillRect(px,py,1,1);
            ctx.globalAlpha=.4*(1-age);ctx.fillRect(px-vx*.02,py-(vy+G*dt)*.02,1,1);}
          else if(tl<=life&&dt<tl+.55){const px=hx+vx*tl,q=(dt-tl)/.55;   // landed: sputters on the ground, then goes out
            if(LH(Math.floor(dt*24)+i*5+e)>q*.9){ctx.globalAlpha=1-q;ctx.fillStyle=q<.3?'#ffd040':'#ff6a20';ctx.fillRect(px,gy-1,1,1);}}}
        ctx.globalAlpha=1;}}
    if(k==='broken'){if(flash>0){ctx.globalAlpha=flash*.8;ctx.fillStyle='#d8f0ff';ctx.fillRect(hx-1,hy-2,2,2);ctx.globalAlpha=flash*.35;ctx.drawImage(H,hx-12*s,hy-8*s,24*s,30*s);ctx.globalAlpha=1;}continue;}
    const b=Math.min(1,lampLevel(k,t,sd)+flash);if(b<=.02)continue;
    ctx.globalAlpha=b;ctx.drawImage(H,hx-29.5*s,hy-11*s,60*s,80*s);
    ctx.fillStyle='#ffd682';ctx.fillRect(hx-2.5*s,hy-1*s,6*s,2*s);ctx.fillStyle='#fff0c8';ctx.fillRect(hx-.5*s,hy+.5*s,2*s,1*s);ctx.globalAlpha=1;}}
function drawBG(ctx,g,W,oy){
  // layered parallax backdrops (Ansimuz packs): each layer scrolls at its own speed, the walking path at full speed
  const b=BGA[g.st.biome.id]||BGA.grave;const d=g.dist+(g.demo?g.t*8:0);
  // tall night sky above the (smaller) backdrop art: a gradient up to darker, with a few stars
  {const gr=ctx.createLinearGradient(0,-oy,0,(b.artTop||0)-oy+20);gr.addColorStop(0,b.top||b.fill);gr.addColorStop(1,b.fill);ctx.fillStyle=gr;ctx.fillRect(0,0,W,CFG.H);
   ctx.fillStyle='rgba(255,255,255,.55)';for(let i=0;i<40;i++){const sx=((i*97+13)%W),sy=((i*53)%Math.max(8,(b.artTop||60)-6))-oy;if(sy>0&&(i+Math.floor(g.t*1.5))%7)ctx.fillRect(Math.round(sx-((d*.01)%W+W)%W+W)%W,sy,1,1);}}
  for(const L of b.layers){const y=L.y-oy;const r=L.r;
    if(L.tile){const off=((d*L.sp)%L.tile+L.tile)%L.tile;for(let x=-off;x<W;x+=L.tile){ctx.drawImage(BGI,r[0],r[1],r[2],r[3],Math.round(x*RES)/RES,y,L.w,L.h);if(L.lamps)drawLamps(ctx,L,Math.round(x*RES)/RES,y,W,g.t);}}
    else{const o=L.once;let x=o.x-d*L.sp;if(o.period){const P=o.period+L.w;x=((x%P)+P)%P-L.w;}if(x<W&&x+L.w>0)ctx.drawImage(BGI,r[0],r[1],r[2],r[3],Math.round(x*RES)/RES,y,L.w,L.h);}}
}
// projectiles: larger, readable shapes with a soft glow and a short trail
function glow(ctx,x,y,r,c,a){ctx.globalAlpha=a;ctx.fillStyle=c;ctx.beginPath();ctx.arc(x,y,r,0,7);ctx.fill();ctx.globalAlpha=1;}
function drawProj(ctx,p,x,y,c,t){const k=p.kind;
  if(k==='shard'||k==='frost'){glow(ctx,x,y,6,c,.18);ctx.fillStyle=c;ctx.beginPath();ctx.moveTo(x+5,y);ctx.lineTo(x,y-3);ctx.lineTo(x-6,y);ctx.lineTo(x,y+3);ctx.fill();ctx.fillStyle='#ffffff';ctx.fillRect(x,y-1,3,1);return;}
  if(k==='plasma'){glow(ctx,x,y,6,c,.2);ctx.fillStyle=c;ctx.fillRect(x-6,y-2,9,4);ctx.fillStyle='#e8ffff';ctx.fillRect(x-3,y-1,6,2);return;}
  if(k==='shell'){ctx.fillStyle='#2a2a30';ctx.beginPath();ctx.arc(x,y,3,0,7);ctx.fill();ctx.fillStyle=(Math.floor(t*20)%2)?'#ffd23f':'#ff7a1a';ctx.fillRect(x-4,y-3,2,2);return;}
  if(k==='fire'){for(let i=0;i<3;i++)glow(ctx,x-i*4,y+(i%2),4-i,i?'#ff5a1a':'#ffb040',.7-i*.2);ctx.fillStyle='#fff4b0';ctx.fillRect(x-1,y-1,2,2);return;}
  if(k==='wisp'){glow(ctx,x,y,5,c,.25);ctx.fillStyle=c;ctx.beginPath();ctx.arc(x,y,3,0,7);ctx.fill();ctx.fillRect(x-7,y-1+Math.round(Math.sin(t*12)),5,2);ctx.fillStyle='#0c1a10';ctx.fillRect(x,y-1,1,1);ctx.fillRect(x+2,y-1,1,1);return;}
  if(k==='zap'){glow(ctx,x,y,6,c,.22);ctx.strokeStyle='#e8ffff';ctx.beginPath();ctx.moveTo(x-7,y);ctx.lineTo(x-4,y-2);ctx.lineTo(x-1,y+1);ctx.lineTo(x+3,y-1);ctx.stroke();ctx.fillStyle=c;ctx.fillRect(x+2,y-2,3,3);return;}
  // orbs: bolt, orb, blood, skull, hex and anything else
  glow(ctx,x,y,7,c,.16);glow(ctx,x-4,y,3,c,.35);ctx.fillStyle=c;ctx.beginPath();ctx.arc(x,y,3.2,0,7);ctx.fill();ctx.fillStyle='#ffffff';ctx.fillRect(x-1,y-1,2,2);
}
function shadow(ctx,x,y,w){ctx.fillStyle='rgba(0,0,0,.35)';ctx.beginPath();ctx.ellipse(Math.round(x),Math.round(y),w,2.5,0,0,7);ctx.fill();}
const MINI={bat:'e_bat',spirit:'e_ghost',raise:'e_skeleton',spore:'e_spawn',drone:'e_eye'};
const HS=UNIT_SCALE;   // units, effects and projectiles are drawn at half size so the world reads bigger
function shrinkAt(ctx,x,y,s){ctx.translate(x,y);ctx.scale(s,s);ctx.translate(-x,-y);}
// 0.11 unit status plate: framed health bar (a tick every 10 HP), energy bar under it, and status pips above it
const PIPS=[['kitHits','#c8d0dc','shield'],['hunger','#ff9a40','food'],['thirst','#5ab8ff','drip'],['poulticeT','#9ae08a','drop'],['rageT','#ff3a2a','up'],['cozyT','#ffb040','up'],['poisonT','#6aff4a','rain'],['shoutT','#ff7a1a','up'],['bleedT','#d01830','drop'],['burnT','#ff8a1f','flame'],['slow','#9ae6ff','snow'],['stun','#ffffff','star'],['shield','#7fd8ff','shield'],['buffT','#ffd23f','up']];
function pip(ctx,x,y,c,k){ctx.fillStyle='#120a14';ctx.fillRect(x-1,y-1,5,5);ctx.fillStyle=c;
  if(k==='food'){ctx.fillRect(x,y,3,1);ctx.fillRect(x+1,y+1,1,2);ctx.fillStyle='#ffd8a0';ctx.fillRect(x,y,1,1);}   // 0.12.72 hunger: a little drumstick
  else if(k==='drip'){ctx.fillRect(x+1,y,1,1);ctx.fillRect(x,y+1,3,1);ctx.fillRect(x+1,y+2,1,1);ctx.fillStyle='#ff6a4a';ctx.fillRect(x+2,y+2,1,1);}   // thirst: a drop with a red fleck
  else if(k==='rain'){ctx.fillRect(x+1,y-1,1,2);ctx.fillRect(x,y+1,3,2);ctx.fillStyle='#d8ffd0';ctx.fillRect(x,y+1,1,1);}   // 0.12.70: poison = a little green raindrop
  else if(k==='drop'){ctx.fillRect(x+1,y,1,1);ctx.fillRect(x,y+1,3,2);}else if(k==='flame'){ctx.fillRect(x+1,y,1,1);ctx.fillRect(x,y+1,3,1);ctx.fillRect(x+1,y+2,1,1);}
  else if(k==='snow'){ctx.fillRect(x+1,y,1,3);ctx.fillRect(x,y+1,3,1);}else if(k==='star'){ctx.fillRect(x,y,1,1);ctx.fillRect(x+2,y,1,1);ctx.fillRect(x+1,y+1,1,1);ctx.fillRect(x,y+2,1,1);ctx.fillRect(x+2,y+2,1,1);}
  else if(k==='shield'){ctx.fillRect(x,y,3,2);ctx.fillRect(x+1,y+2,1,1);}else{ctx.fillRect(x+1,y,1,3);ctx.fillRect(x,y+1,3,1);}}
let PLATE_OFF=false;
/* 0.12.71 (Kyle): a cast/reload bar for anything that casts, channels or reloads: [progress 0..1, colour, still filling?]
   gold = casting, violet = channelling, grey = reloading, red = lazer charge/burn, green = smoking/repairs */
function castBar(h){const C=h.base&&h.base.char;if(!C||!h.alive)return null;const R=C.ranged;
  if(h.cast&&h.cast.T)return [h.cast.t/h.cast.T,'#ffd23f',1];
  if(h.building)return [h.building.t/h.building.T,'#ffb040',1];
  if(h.repairing&&h.repairing.tgt){const T=h.repairing.tgt;return [T.hp/T.max,'#7ee081',1];}
  if(h.lz&&R&&R.lazer){const L=R.lazer;return h.lz.t<L.charge?[h.lz.t/L.charge,'#ff4a3a',1]:[1-(h.lz.t-L.charge)/L.fire,'#ff8a6a',0];}
  if(h.lzReload>0&&R&&R.lazer)return [1-h.lzReload/R.lazer.reload,'#a8b0bc',1];
  if(h.syph)return [1-h.syph.t/((C.abilities||[]).find(a=>a.id==='syphon')||{dur:3}).dur,'#b070ff',0];
  if(h.nano)return [h.nano.t/((C.abilities||[]).find(a=>a.id==='nano')||{dur:5}).dur,'#5af0d0',1];
  if(h.smoking)return [h.smoking.t/2,'#7ee081',1];
  if(h.camping>0)return [1-h.camping/(h.campT0||1.8),'#ffb040',1];
  if(h.summonT>0)return [1-h.summonT/(h.summonT0||.8),'#b070ff',1];
  if(h.casting>0)return [1-h.casting/(h.castT0||.5),'#7ee081',1];
  if(h.setting&&h.setting.T)return [h.setting.t/h.setting.T,'#ffd23f',1];
  if(h.tossing&&h.tossing.T)return [h.tossing.t/h.tossing.T,'#ffd23f',1];
  if(h.volley>0)return [1-h.volley/(h.volleyT0||.6),'#ffd23f',1];
  if(h.blowing>0)return [1-h.blowing/(h.blowT0||.7),'#ffd23f',1];
  if(h.calling&&h.calling.T)return [h.calling.t/h.calling.T,'#ffd23f',1];
  if(R&&R.clip>0&&h.ammo<=0&&R.reload)return [(h.reloadT||0)/R.reload,'#a8b0bc',1];
  if(h.search&&h.search.T)return [h.search.t/h.search.T,'#9ad0ff',1];
  return null;}   /* the camp scene draws its heroes without health plates */
function plate(ctx,u,x,y,w,hero,col){if(PLATE_OFF)return;x=Math.round(x-w/2);y=Math.round(y);const pct=Math.max(0,Math.min(1,u.hp/u.max));
  ctx.fillStyle='#120a14';ctx.fillRect(x-1,y-1,w+2,hero?6:4);ctx.fillStyle='#3a1a24';ctx.fillRect(x,y,w,2);
  ctx.fillStyle=col||(pct>.5?'#4fd46a':pct>.25?'#ffb020':'#e8303a');ctx.fillRect(x,y,Math.round(w*pct),2);
  if(u.max>=20){ctx.fillStyle='rgba(18,10,20,.55)';const n=Math.floor(u.max/10);for(let i=1;i<n;i++){const tx=x+Math.round(w*i*10/u.max);if(tx<x+w)ctx.fillRect(tx,y,1,1);}}
  if(hero){const e=u.enMax?Math.max(0,(u.en||0)/u.enMax):1;ctx.fillStyle='#2a2410';ctx.fillRect(x,y+3,w,1);ctx.fillStyle='#ffd23f';ctx.fillRect(x,y+3,Math.round(w*e),1);}
  let px=x;for(const [k,c,sh] of PIPS)if(u[k]>0){pip(ctx,px+1,y-6,c,sh);px+=5;}}
function drawGame(ctx,g,W,oy){
  const RR=ctx.canvas.width/W;ctx.setTransform(RR,0,0,RR,0,0);ctx.imageSmoothingEnabled=false;ctx.save();
  if(g.shake>0)ctx.translate(Math.round((Math.random()-.5)*4*g.shake),Math.round((Math.random()-.5)*3*g.shake));
  if(g.bgImg){ctx.imageSmoothingEnabled=true;ctx.drawImage(g.bgImg,0,0,W,ctx.canvas.height/RR);ctx.imageSmoothingEnabled=false;}else drawBG(ctx,g,W,oy);ctx.translate(0,-oy);const G=g.G;
  for(const l of g.loot||[]){const x=Math.round(l.x),y=(l.gy||G)-1;ctx.save();shrinkAt(ctx,x,y+1,HS);
    if(l.kind==='gold'){const n=l.big?7:4;ctx.fillStyle='#7a5a10';ctx.fillRect(x-n,y-2,n*2,2);ctx.fillStyle='#d9a836';for(let i=0;i<n;i++)ctx.fillRect(x-n+1+i*2,y-3-(i%2),2,2);ctx.fillStyle='#ffe27a';ctx.fillRect(x-1,y-5,2,2);
      if(Math.floor(g.t*4+l.x)%3===0){ctx.fillStyle='#ffffff';ctx.fillRect(x+2,y-7,1,1);}}
    else if(l.kind==='food'){ctx.fillStyle='#3a2a18';ctx.fillRect(x-3,y-7,6,7);ctx.fillStyle='#b07a3a';ctx.fillRect(x-2,y-6,4,5);ctx.fillStyle='#e8d0a0';ctx.fillRect(x-2,y-5,4,2);ctx.fillStyle='#d8d8d8';ctx.fillRect(x-3,y-8,6,1);}   /* a tin can */
    else if(l.kind==='water'){ctx.fillStyle='#1a2a38';ctx.fillRect(x-2,y-9,4,9);ctx.fillStyle='#7fd0ff';ctx.fillRect(x-1,y-7,2,6);ctx.fillStyle='#e8f6ff';ctx.fillRect(x-1,y-10,2,2);}   /* a bottle */
    else if(l.kind==='lucky'){const gl=.5+.5*Math.sin(l.t*6);ctx.fillStyle=`rgba(125,255,154,${.25+.25*gl})`;ctx.fillRect(x-6,y-11,12,12);ctx.fillStyle='#0c2410';ctx.fillRect(x-4,y-9,8,8);ctx.fillStyle='#7dff9a';ctx.fillRect(x-3,y-8,6,6);ctx.fillStyle='#ffd23f';ctx.fillRect(x-2,y-7,1,1);ctx.fillRect(x+1,y-4,1,1);ctx.fillRect(x-1,y-6+0,1,1);ctx.fillRect(x,y-5,1,1);}   /* 0.12.281 a glowing green-and-gold Lucky Die */
    else if(l.kind==='parts'){ctx.fillStyle='#2a2a2e';ctx.fillRect(x-4,y-4,8,4);ctx.fillStyle='#9aa0a8';ctx.fillRect(x-3,y-3,3,2);ctx.fillRect(x+1,y-4,2,3);ctx.fillStyle='#c87a3a';ctx.fillRect(x-1,y-5,2,2);}   /* a little pile of bolts and gears */
    else{const c=(CFG.rarity.find(r=>r.id===l.item.rar)||CFG.rarity[0]).col;const by=Math.round(Math.sin(g.t*4)*1.5);glow(ctx,x,y-6+by,7,c,.25);
      ctx.fillStyle='#5a3a1a';ctx.fillRect(x-4,y-8+by,8,6);ctx.fillStyle=c;ctx.fillRect(x-4,y-8+by,8,2);ctx.fillRect(x-1,y-6+by,2,2);ctx.fillStyle='#ffffff';ctx.fillRect(x+3,y-11+by,1,1);}ctx.restore();}
  for(const z of g.zones||[]){const k=Math.min(1,z.t/z.T);const pulse=.25+.25*Math.sin(g.t*18);ctx.save();
    ctx.fillStyle=z.c;ctx.globalAlpha=z.t>=z.T?.6*(1-(z.t-z.T)/.25):(.12+.25*k+pulse*.3*k);ctx.beginPath();ctx.ellipse(z.cx,G+2,z.hw,6,0,0,7);ctx.fill();
    ctx.globalAlpha=.9;ctx.strokeStyle=z.c;ctx.beginPath();ctx.ellipse(z.cx,G+2,z.hw*k,6*k,0,0,7);ctx.stroke();ctx.restore();}
  // minions
  for(const m of g.minions){ctx.save();shrinkAt(ctx,m.x,G,HS);const n=MINI[m.kind]||'e_ghost';const a=SP[n];shadow(ctx,m.x,G,6);
    const sc=(m.small?.5:.62)*(1+.15*(m.stacks||0));ctx.save();ctx.translate(m.x,G-(n==='e_skeleton'?60:44)*sc);ctx.scale(sc,sc);spr(ctx,n,m.animT>0?6+Math.min(2,Math.floor((.3-m.animT)/.1)):Math.floor(g.t*(m.moving?16:6))%6,-FW(a)/2,0,true,.9,m.hitFlash);ctx.restore();
    const mw=12,mp=Math.max(0,m.hp/m.max);ctx.fillStyle='#120a14';ctx.fillRect(Math.round(m.x-mw/2)-1,Math.round(G-(n==='e_skeleton'?60:44)*sc)-3,mw+2,3);ctx.fillStyle='#7dff9a';ctx.fillRect(Math.round(m.x-mw/2),Math.round(G-(n==='e_skeleton'?60:44)*sc)-2,Math.round(mw*mp),1);ctx.restore();}
  // heroes (back to front)
  const hs=g.heroes.concat((g.pets||[]).filter(p=>p.alive||(p.dog&&p.downed))).sort((a,b)=>a.x-b.x);   // a downed dog lies there until someone helps him up
  for(const h of hs)if(!h.alive&&h.downed){const gy=h.gy||G,k=Math.min(1,(h.revT||0)/(h.revNeed||5)),p=.5+.5*Math.sin(g.t*5);ctx.save();ctx.strokeStyle=`rgba(125,255,154,${.25+.2*p})`;ctx.lineWidth=1;ctx.beginPath();ctx.arc(h.x,gy-20,4,0,7);ctx.stroke();
    if(k>0){ctx.strokeStyle='#7dff9a';ctx.lineWidth=1.6;ctx.beginPath();ctx.arc(h.x,gy-20,4,-Math.PI/2,-Math.PI/2+k*6.283);ctx.stroke();}ctx.fillStyle='#7dff9a';ctx.fillRect(h.x-.5,gy-22,1,4);ctx.fillRect(h.x-2,gy-20.5,4,1);ctx.restore();}   // downed: a + to help them up, filling as an ally stands on them
  for(const h of hs)if(!h.alive){const gy=h.gy||G;ctx.save();shrinkAt(ctx,h.x,gy,HS);const U=UNITS[h.skin||h.key];if(U&&U.death)drawUnit(ctx,U.death,U.death.n-1,h.x,gy-(U.death.fall?2:0),U.death.pre?ART_SCALE/U.death.pre/HS:U.death.art?ART_SCALE/HS:1,.9,0,U.death.fall?((h.face||1)>0?1.45:-1.45):0,((h.face||1)>0)!==!!U.death.faceR);else spr(ctx,'h_'+h.key,10,h.x-32,gy-60,false,.85);ctx.restore();}
  for(const f of g.fx)if(f.k==='corpse'&&UNITS[f.skin||f.type]){ctx.save();shrinkAt(ctx,f.x,f.gy!=null?f.gy:G,HS);ctx.restore();const U=UNITS[f.skin||f.type],k=f.t/f.life;const fall=Math.min(1,k*3.2);
    if(U.die){const fr=Math.min(U.die.n-1,Math.floor(k/.7*U.die.n));const E2=CFG.enemies[f.type]||{};drawUnit(ctx,U.die,fr,f.x,f.gy!=null?f.gy:G,HS*(E2.scale||1)*(f.elite?1.1:1)*(U.die.pre?.88/U.die.pre:1),k>.75?(1-k)*4:1,0,0,!!U.die.faceR);continue;}
    drawUnit(ctx,U.walk,0,f.x+fall*3,f.gy!=null?f.gy:G+(f.lane||0),HS*(f.elite?1.1:1),Math.min(1,2.2*(1-k)),0,-fall*Math.PI/2*.96);}
  for(const f of g.fx)if(f.k==='corpse'){const n='e_'+f.type,a=SP[n];if(!a||UNITS[f.type])continue;const k=f.t/f.life;const big=FH(a)===64;
    const y=f.fly?Math.min(G-44,f.y-FH(a)/2+f.t*160):G-(big?60:44)+(f.lane||0);ctx.save();if(f.elite){ctx.translate(f.x,y+FH(a));ctx.scale(1.22,1.22);spr(ctx,n,10,-FW(a)/2,-FH(a),false,Math.min(1,2.2*(1-k)));}else spr(ctx,n,10,f.x-FW(a)/2,y,false,Math.min(1,2.2*(1-k)));ctx.restore();}
  const laser=()=>{for(const h of g.heroes){const K=h.cast;if(!h.alive||!K||!K.tgt||K.tgt.dead)continue;const T=K.tgt,mz=MUZZLE[h.key]||[10,30];
      const x0=g.heroX(h)+(h.face<0?-1:1)*mz[0],y0=(h.gy||g.G)-mz[1],tx=T.x,ty=(T.gy!=null&&!T.fly?T.gy:g.G)-(T.type==='werewolf'?18:38)*HS*((T.E&&T.E.scale)||1);
      const k=K.t/K.T;ctx.save();ctx.globalCompositeOperation='lighter';ctx.strokeStyle=`rgba(255,40,40,${.35+.45*k})`;ctx.lineWidth=.6+k*.6;ctx.setLineDash(k>.75?[]:[3,2]);
      ctx.beginPath();ctx.moveTo(x0,y0);ctx.lineTo(tx,ty);ctx.stroke();ctx.setLineDash([]);glow(ctx,tx,ty,3+3*k,'#ff2828',.35+.3*Math.sin(g.t*30));ctx.restore();}};
  const traps=()=>{const T0=UNITS.flannel&&UNITS.flannel.tripbomb,BB=UNITS.flannel&&UNITS.flannel.bombball;if(!T0)return;for(const T of g.traps||[]){
      if(T.how&&T.how!=='plant'&&BB){   /* 0.12.58 thrown/tossed Proximity_Bomb: just the ball, spinning through the air, rolling, then blinking once armed */
        const y=T.gy-(T.air||0);ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(Math.round(T.x-3+(T.air||0)*.05),T.gy-1,6,1.5);ctx.save();ctx.translate(T.x,y-3.5);ctx.rotate(T.spin||0);
        drawUnit(ctx,BB,0,0,3.5,.5*HS,1,0,0,false);ctx.restore();
        if(T.live){const p=.5+.5*Math.sin(g.t*6);ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,T.x,y-3,7+2*p,'#ff2a1a',.35+.25*p);ctx.restore();if(p>.5){ctx.fillStyle='#ff4030';ctx.fillRect(Math.round(T.x)-.5,Math.round(y-7.5),1,1);}}   /* 0.12.59: activated (6d4): the rust-mine red glow */
        continue;}
      if(T.live&&T.t>=T.A.arm){const p=.5+.5*Math.sin(g.t*6);ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,T.x-2,T.gy-4,8+2*p,'#ff2a1a',.3+.2*p);ctx.restore();}
      ctx.save();shrinkAt(ctx,T.x,T.gy,HS);
      drawUnit(ctx,T0,0,T.x,T.gy,.5,T.t<T.A.arm?.55+.45*Math.sin(g.t*20)**2:1,0,0,false);ctx.restore();}};
  // Wave Dash: a blue crescent of energy (about 1.5x his height) riding his sword, with fading afterimages
  // Wave Dash: Kyle's wave shape (tall front crescent he rides in, jagged tail along the ground), pixel art, with afterimages
  // Wave Dash: Kyle's wave (his pick of the three), riding ahead of the warrior, with afterimages and lightning crackling around it
  const zap=(x0,y0,len,ang)=>{ctx.beginPath();ctx.moveTo(x0,y0);let x=x0,y=y0;const n=4;for(let i=0;i<n;i++){x+=Math.cos(ang)*len/n+(Math.random()-.5)*3;y+=Math.sin(ang)*len/n+(Math.random()-.5)*3;ctx.lineTo(x,y);}ctx.stroke();};
  const waves=()=>{for(const h of g.alive()){const D=h.dash;if(!D)continue;const G0=h.gy||g.G,fl=(h.face||1)<0,s=fl?-1:1;
      D.trail.forEach((x,i)=>drawUnit(ctx,WAVE,0,x,G0,.5,.12+.1*i/D.trail.length,0,0,fl));
      ctx.save();ctx.globalCompositeOperation='lighter';drawUnit(ctx,WAVE,0,h.x,G0,.5,.5,0,0,fl);ctx.restore();drawUnit(ctx,WAVE,0,h.x,G0,.5,.88,0,0,fl);
      ctx.save();ctx.globalCompositeOperation='lighter';
      for(let k=0;k<4;k++){const t=Math.random();const cx=h.x+s*(9+14*Math.sin(t*Math.PI)+Math.random()*4),cy=G0-1-t*32;   // along the front crescent
        ctx.strokeStyle=k%2?'rgba(170,230,255,.9)':'rgba(255,255,255,.95)';ctx.lineWidth=.5;zap(cx,cy,4+Math.random()*6,Math.random()*6.28);}
      for(let k=0;k<2;k++){const tx=h.x-s*(4+Math.random()*24);ctx.strokeStyle='rgba(140,210,255,.8)';ctx.lineWidth=.5;zap(tx,G0-2-Math.random()*6,3+Math.random()*4,-Math.PI/2+(Math.random()-.5));}   // along the tail
      if(Math.random()<.5)glow(ctx,h.x+s*(14+Math.random()*8),G0-6-Math.random()*24,2.5,'#e8fbff',.6);ctx.restore();}};
  // Arrow_Rain: arrows falling out of the sky, and the ones stuck in the ground
  /* 0.12.69 Hatchet_Leap landing: a cracked-earth decal that lingers, dust clouds rolling out, pebbles thrown up, a short burst of energy */
  /* 0.12.70 Syphon_Life: two twisting strands (black and violet) from his chest to the target's middle, motes of life drifting back into him;
     a burrow puff where Call_of_Cthulhu pulls a tentacle under; a green glint on his dagger during Lethal_Strikes */
  const voidFx=()=>{for(const h of g.alive()){if(h.key!=='cultist')continue;const hx=g.heroX(h),gy=h.gy||G;
      if(h.syph&&h.syph.tg&&!h.syph.tg.dead){const T=h.syph.tg,x0=hx+(h.face||1)*3,y0=gy-12,x1=T.x,y1=(T.gy!=null?T.gy:G)-(T.boss?30:12),L=Math.hypot(x1-x0,y1-y0)||1,nx=-(y1-y0)/L,ny=(x1-x0)/L;
        ctx.save();for(const [w,c,ph,amp] of [[3.2,'rgba(10,0,16,.75)',0,2.2],[1.6,'rgba(150,60,255,.85)',Math.PI,2],[.7,'rgba(230,200,255,.9)',Math.PI*.5,1.2]]){ctx.strokeStyle=c;ctx.lineWidth=w;ctx.beginPath();
          for(let i=0;i<=24;i++){const k=i/24,sw=Math.sin(k*12-g.t*14+ph)*amp*Math.sin(k*Math.PI),x=x0+(x1-x0)*k+nx*sw,y=y0+(y1-y0)*k+ny*sw;i?ctx.lineTo(x,y):ctx.moveTo(x,y);}ctx.stroke();}
        ctx.globalCompositeOperation='lighter';for(let i=0;i<5;i++){const k=1-((g.t*1.3+i/5)%1);glow(ctx,x0+(x1-x0)*k,y0+(y1-y0)*k+Math.sin(g.t*9+i)*1.5,1.3,i%2?'#ff5a8a':'#b070ff',.8);}
        glow(ctx,x1,y1,5,'#6a20c0',.35);glow(ctx,x0,y0,3,'#b070ff',.4);ctx.restore();}
      if(h.lethalT>0){ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,hx+(h.face||1)*7,gy-10,2.2,'#6aff4a',.35+.25*Math.sin(g.t*14));ctx.restore();}}
    for(const f of g.fx){if(f.k!=='burrow')continue;const k=f.t/f.life;for(let i=0;i<5;i++)puffAt(f.x+(i-2)*2.5,f.gy-1-k*5-(i%2),1.6+k*2,.6*(1-k),'#4a3a2c');}};
  const slamDraw=()=>{for(const f of g.fx){if(f.k!=='crack')continue;const k=f.t/f.life,a=k>.7?(1-k)/.3:1;let sd=Math.floor(f.x*13+f.gy*7);const R=()=>{sd=(sd*9301+49297)%233280;return sd/233280;};
      ctx.save();ctx.globalAlpha=a;ctx.fillStyle='rgba(20,12,8,.35)';ctx.beginPath();ctx.ellipse(f.x,f.gy,f.r*.55,f.r*.16,0,0,7);ctx.fill();
      for(let i=0;i<8;i++){let ang=i/8*6.283+R()*.5,x=f.x,y=f.gy,L=f.r*(.55+R()*.6);ctx.beginPath();ctx.moveTo(x,y);
        for(let j=1;j<=3;j++){ang+=(R()-.5)*.7;x=f.x+Math.cos(ang)*L*j/3;y=f.gy+Math.sin(ang)*L*j/3*.28;ctx.lineTo(x,y);}
        ctx.strokeStyle='#1a0e08';ctx.lineWidth=1.1-.0*i;ctx.stroke();ctx.strokeStyle='rgba(200,150,100,.35)';ctx.lineWidth=.4;ctx.beginPath();ctx.moveTo(f.x,f.gy+.6);ctx.lineTo(x,y+.6);ctx.stroke();}
      ctx.restore();}
    for(const f of g.fx){if(f.k!=='slam')continue;const k=f.t/f.life;ctx.save();
      if(k<.35){ctx.globalCompositeOperation='lighter';glow(ctx,f.x,f.gy-4,f.r*(.5+k*2),'#ffb040',.45*(1-k/.35));glow(ctx,f.x,f.gy-3,4,'#fff0c0',.7*(1-k/.35));ctx.globalCompositeOperation='source-over';
        ctx.strokeStyle=`rgba(255,200,110,${.8*(1-k/.35)})`;ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(f.x,f.gy-1,f.r*(.4+k*3.4),f.r*(.12+k*.9),0,0,7);ctx.stroke();}
      for(let i=0;i<6;i++){const s=i%2?1:-1,d=f.r*(.3+k*1.4)*(1+i%3*.25),r=(2.2+i%3)*(.6+k*1.2);puffAt(f.x+s*d,f.gy-2-k*4-(i%3),r,.55*(1-k),'#9a8670');}   // dust rolling out both ways
      for(let i=0;i<10;i++){const a=((f.seed+i*2.4)%3.1)+.02,sp=18+(i*7%11)*2,px=f.x+Math.cos(a)*sp*k*1.4*(i%2?1:-1),py=f.gy-2-(Math.sin(a)*40*k-60*k*k)-2;
        if(py<f.gy){ctx.fillStyle=i%3?'#6a5a48':'#a89880';ctx.globalAlpha=1-k*.6;ctx.fillRect(px,py,i%4?1:1.5,i%4?1:1.5);}}   // pebbles
      ctx.restore();}};
  const pinnedDraw=()=>{for(const f of g.fx){if(f.k!=='pinned')continue;const e=f.e;if(e&&!e.dead){f.x=e.x;f.gy=e.gy!=null?e.gy:G;}const k=f.t/f.life,a=k>.85?(1-k)/.15:1;
      const B=UNITS.archer&&UNITS.archer.arrow;const x=f.x-f.dir*1.5,y=f.gy-3.5;ctx.save();ctx.globalAlpha=a;ctx.translate(x,y);ctx.rotate(f.dir>0?.62:Math.PI-.62);   /* 0.12.68: the big arrow driven through the legs into the dirt */
      if(B)drawUnit(ctx,B,0,0,0,ART_SCALE/B.pre*2,a,0,0,false);else{ctx.fillStyle='#8a6a4a';ctx.fillRect(-9,-.5,12,1);}ctx.restore();
      ctx.fillStyle=`rgba(60,40,24,${.6*a})`;ctx.fillRect(Math.round(f.x+f.dir*1.5)-2,Math.round(f.gy)-.5,4,1.2);   // dirt kicked up where it bit in
      if(f.t<.25)for(let i=0;i<4;i++){ctx.fillStyle=`rgba(150,120,90,${1-f.t*4})`;ctx.fillRect(f.x+f.dir*2+(i-1.5)*1.6,f.gy-1-f.t*14*(1+i%2),1,1);}}};
  const bottleDraw=()=>{for(const B of g.bottles||[]){const y=B.gy-B.hgt*.5-6;ctx.save();ctx.translate(B.x,y);ctx.rotate(B.rot);   /* 0.12.68 Bottle_Distraction: a green glass bottle tumbling in a big arc */
      ctx.fillStyle='#1e4a2a';ctx.fillRect(-1.5,-3,3,5);ctx.fillRect(-.5,-5,1,2);ctx.fillStyle='#3c8a52';ctx.fillRect(-1,-2.5,1,4);ctx.fillStyle='#bfe8c8';ctx.fillRect(-1,-2.5,.6,2);ctx.fillStyle='#8a5a30';ctx.fillRect(-.5,-5.5,1,.8);ctx.restore();
      ctx.fillStyle='rgba(0,0,0,.25)';ctx.fillRect(B.x-1.5,B.gy-.5,3,1);}
    for(const f of g.fx){if(f.k!=='glass')continue;const k=f.t/f.life;ctx.save();ctx.globalAlpha=1-k;for(let i=0;i<9;i++){const a=i*.7+1,sp=10+((i*37)%7)*2.2,dx=Math.cos(a)*sp*Math.min(1,k*2.4),up=Math.sin(Math.min(1,k*2)*Math.PI)*(4+i%3*2);
        ctx.fillStyle=i%3?'#7fd49a':'#e8fff0';ctx.fillRect(f.x+dx,f.gy-1-up,1,1);}
      ctx.strokeStyle=`rgba(230,255,240,${.7*(1-k)})`;ctx.lineWidth=.6;ctx.beginPath();ctx.ellipse(f.x,f.gy-1,6+k*24,1.5+k*6,0,0,7);ctx.stroke();   // the noise rings out
      if(k<.5){ctx.fillStyle='#ffffff';ctx.font='bold 5px monospace';ctx.textAlign='center';ctx.fillText('CRASH!',f.x,f.gy-12-k*8);}ctx.restore();}};
  /* 0.12.105 Grenade_Launcher rounds: a stubby 40mm grenade. In the air it points the way it's flying (nose down on the way in,
     steeper from the tower); once it hits the ground it tumbles and rolls, and blinks red while the fuse runs. */
  const nadeDraw=()=>{for(const N of g.glNades||[]){const y=N.gy-N.z*.6-2;let ang;
      if(N.st==='fly'){const vy=-N.vz*.6;ang=Math.atan2(vy,N.vx);}else ang=N.rot;
      ctx.fillStyle='rgba(0,0,0,.28)';ctx.fillRect(N.x-1.5,N.gy-.5,3,1);
      ctx.save();ctx.translate(N.x,y);ctx.rotate(ang);ctx.scale(.7,.7);   /* 0.12.161 (Kyle): a little smaller */
      ctx.fillStyle='#3e4a2a';ctx.fillRect(-2.2,-1.2,3.2,2.4);   /* olive body */
      ctx.fillStyle='#c9a24a';ctx.fillRect(-2.6,-1.2,.8,2.4);   /* brass case base */
      ctx.fillStyle=N.st!=='fly'&&N.vx===0&&Math.floor(N.fuseT*12)%2?'#ff3a2a':'#8a9a5a';ctx.beginPath();ctx.moveTo(1,-1.2);ctx.lineTo(2.6,0);ctx.lineTo(1,1.2);ctx.closePath();ctx.fill();   /* ogive nose (blinks while the fuse runs) */
      ctx.fillStyle='#ffd23f';ctx.fillRect(-.6,-1.2,.5,2.4);   /* yellow HE band */
      ctx.restore();}};
  const rainDraw=()=>{for(const f of g.fx)if(f.k==='stuck'){const k=f.t/f.life;drawUnit(ctx,RAIN.s,0,f.x,f.gy+1,.5,k>.7?(1-k)/.3:1,0,0,false);}
    for(const R of g.rain||[]){if(R.t<0)continue;const k=Math.min(1,R.t/R.T);drawUnit(ctx,RAIN.f,0,R.x,R.gy-(1-k)*90,.5,1,0,0,false);}};
  // Druid effects: Mend sparkle, Bloom vine heart on the healed ally, Thorn Eruption spikes, Cyclone tornadoes
  // 0.12.17 Moss_Mech effects: arc blade glow and slashes, chain lightning, missiles and their smoke trails, grenades and smoke clouds
  const zig=(x0,y0,x1,y1,n,amp)=>{ctx.beginPath();ctx.moveTo(x0,y0);for(let i=1;i<n;i++){const k=i/n;ctx.lineTo(x0+(x1-x0)*k+(Math.random()*2-1)*amp*.4,y0+(y1-y0)*k+(Math.random()*2-1)*amp);}ctx.lineTo(x1,y1);ctx.stroke();};
  const puffAt=(x,y,r,a,shade)=>{ctx.globalAlpha=a;ctx.fillStyle=shade||'#c9d2da';ctx.beginPath();ctx.arc(x,y,r,0,7);ctx.fill();ctx.fillStyle='#eef3f6';ctx.beginPath();ctx.arc(x-r*.3,y-r*.35,r*.55,0,7);ctx.fill();ctx.globalAlpha=1;};
  const robotFx=()=>{
    /* 0.12.67 Warhound: pilot light on the flamethrower; the Targeted Lazer (lens charge, a thick pulsing red beam angled down from his hull to
       a target reticle on the ground, ground fire riding the tip, blue arcs when Arc Surge is on); the blue jetpack flames + shield; nano glow */
    for(const h of g.alive())if(h.key==='robot'){const d=(h.face||1)>0?1:-1,hx=g.heroX(h),gy=h.gy||g.G,lift=(h.leapH||0)*1.2*HS;ctx.save();ctx.globalCompositeOperation='lighter';
      if(!h.jet&&!h.nano){const px=hx+d*(h.animM>0||h.lz?17.7:14.1),py=gy-(h.animM>0||h.lz?22:13)-lift;glow(ctx,px,py,1.6+Math.random()*.4,'#ff9a30',.55);glow(ctx,px,py,.7,'#fff0b0',.9);}
      if(h.lz){const C2=h.base.char.ranged.lazer,L=h.lz,ex=hx+d*8.2,ey=gy-25.5-lift,tx=L.tx,ty=L.gy-1.5,S=h.surgeT>0;
        if(L.t<C2.charge){const k=L.t/C2.charge;glow(ctx,ex,ey,1.2+2.5*k,'#ff2a1a',.35+.4*k);ctx.strokeStyle=`rgba(255,60,40,${.35+.5*k})`;ctx.lineWidth=.6;ctx.beginPath();ctx.ellipse(tx,ty+1,6*(1-k)+2,2*(1-k)+1,0,0,7);ctx.stroke();
          ctx.setLineDash([1.5,2]);ctx.strokeStyle=`rgba(255,80,60,${.25*k})`;ctx.beginPath();ctx.moveTo(ex,ey);ctx.lineTo(tx,ty);ctx.stroke();ctx.setLineDash([]);}
        else{const fl=.75+.25*Math.sin(g.t*40);for(const [w,c] of [[S?4.4:3.4,`rgba(255,20,10,${.28*fl})`],[S?2.2:1.7,`rgba(255,70,40,${.7*fl})`],[.7,'rgba(255,235,225,.95)']]){ctx.strokeStyle=c;ctx.lineWidth=w;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(ex,ey);ctx.lineTo(tx,ty);ctx.stroke();}
          glow(ctx,ex,ey,3,'#ff3020',.6);glow(ctx,tx,ty,(S?8.3:6.7)*.9,'#ff4010',.22);glow(ctx,tx,ty,2.2,'#fff0d0',.85);
          if(S&&Math.random()<.8){ctx.strokeStyle='rgba(150,220,255,.9)';ctx.lineWidth=.5;const m=Math.random();zig(ex+(tx-ex)*m,ey+(ty-ey)*m,ex+(tx-ex)*(m+.15),ey+(ty-ey)*(m+.15)+(Math.random()-.5)*4,3,1.5);}
          ctx.restore();ctx.save();fireBit(tx-d*1.5,L.gy+1,.3,4+Math.floor(g.t*12)%4,.9);fireBit(tx-d*4.5,L.gy+1,.2,4+Math.floor(g.t*12+2)%4,.7);ctx.globalCompositeOperation='lighter';}}
      if(h.jet){const bx=hx-d*9,by=gy-9-lift;for(const o of[-1.3,1.3])blueFire(bx+o,by,.3+Math.random()*.06,4+Math.floor(g.t*14+(o>0?2:0))%4,.95,1);
        glow(ctx,bx,by+5,4.5,'#3a8cff',.35);ctx.strokeStyle=`rgba(120,200,255,${.5+.2*Math.sin(g.t*20)})`;ctx.lineWidth=.9;ctx.beginPath();ctx.ellipse(hx,gy-16-lift,14,19,0,0,7);ctx.stroke();glow(ctx,hx,gy-16-lift,16,'#4aa8ff',.1);}
      if(h.nano)glow(ctx,hx,gy-15,15,'#5af0d0',.08+.05*Math.sin(g.t*8));
      if(h.surgeT>0&&!h.lz&&Math.random()<.5){ctx.strokeStyle='rgba(150,220,255,.85)';ctx.lineWidth=.5;zig(hx+d*8,gy-26-lift,hx+d*(8+Math.random()*4),gy-21-lift,3,1.2);}
      ctx.restore();}
    for(const f of g.fx){const k=f.t/f.life;
      if(f.k==='arc'){const d=f.dir,cx=f.x+d*6,cy=f.gy-10,R=f.big?13:10;ctx.save();ctx.globalCompositeOperation='lighter';ctx.globalAlpha=1-k;ctx.lineCap='round';
        for(const [w,c] of [[3.2,'rgba(30,140,255,.6)'],[1.3,'rgba(200,245,255,.95)']]){ctx.strokeStyle=c;ctx.lineWidth=w;ctx.beginPath();const a0=d>0?-1.25:Math.PI+1.25,a1=d>0?1.1:Math.PI-1.1,s=a0+(a1-a0)*Math.min(1,k*2.2);ctx.arc(cx-d*4,cy,R,Math.min(a0,s),Math.max(a0,s));ctx.stroke();}
        ctx.strokeStyle='rgba(170,230,255,.9)';ctx.lineWidth=.6;zig(cx,cy-8,cx+d*6,cy+6,4,1.6);ctx.restore();continue;}
      if(f.k==='bolt'){ctx.save();ctx.globalCompositeOperation='lighter';ctx.globalAlpha=1-k;for(const [w,c] of (f.c==='y'?[[2.4,'rgba(255,220,60,.7)'],[.8,'rgba(255,255,220,1)']]:f.c==='v'?[[2.4,'rgba(140,50,255,.7)'],[.8,'rgba(230,200,255,1)']]:[[2.4,'rgba(40,150,255,.7)'],[.8,'rgba(230,250,255,1)']])){ctx.strokeStyle=c;ctx.lineWidth=w;for(let i=1;i<f.pts.length;i++){const [a,b]=f.pts[i-1],[x,y]=f.pts[i];zig(a,b,x,y,5,2.2);}}
        for(const [x,y] of f.pts)glow(ctx,x,y,3,'#6fd0ff',.4*(1-k));ctx.restore();continue;}
      if(f.k==='puff'){const r=(1.2+2.6*k)*f.s;puffAt(f.x-1.5*k,f.y-3*k,r,.55*(1-k),k<.15?'#ffb860':'#aab4bd');continue;}}
    for(const M of g.missiles||[]){const u=Math.min(1,M.t/M.T),du=.02;const nx=M.x0+(M.tx-M.x0)*Math.min(1,u+du),nh=(1-Math.min(1,u+du))*23+46*Math.sin(Math.PI*Math.min(1,u+du));
      const y=M.gyNow-M.hgt,ang=Math.atan2(-(nh-M.hgt),nx-M.x);ctx.save();ctx.translate(M.x,y);ctx.rotate(ang);
      ctx.fillStyle='#2f3a33';ctx.fillRect(-3.5,-1,6,2);ctx.fillStyle='#6f8a63';ctx.fillRect(-3,-1,4.5,1);ctx.fillStyle='#c84a2a';ctx.fillRect(2.5,-1,1.5,2);ctx.fillStyle='#1d2420';ctx.fillRect(-4.5,-1.8,1.5,3.6);   // body, stripe, red nose, fins
      ctx.globalCompositeOperation='lighter';glow(ctx,-5,0,2.2,'#ff9a30',.7);glow(ctx,-4.6,0,1,'#fff0b0',1);ctx.restore();}
    for(const N of g.nades||[]){const y=N.gyNow-N.hgt;ctx.save();ctx.translate(N.x,y);ctx.rotate(N.t*14);ctx.fillStyle='#3d4a40';ctx.fillRect(-1.5,-1.5,3,3);ctx.fillStyle='#9aa69a';ctx.fillRect(-1.5,-1.5,1,1);ctx.restore();
      if(Math.random()<.5)puffAt(N.x,y,.9,.5);}
    for(const S of g.clouds||[]){if(S.A&&S.A.sprite&&ATLAS.smoke){const M=ATLAS.smoke,k=S.t/S.life,sc=S.r*2.1/120,sd=S.seed||0;   /* 0.12.199 (Kyle): the pack's smoke: puffs up, then the full-cloud middle frames are reused as slow, drifting, mirrored variations so it hangs there, then it thins out */
        if(S.t<.9){drawUnit(ctx,M,Math.min(13,Math.floor(S.t/.9*14)),S.x,S.gy+3,sc,.9,0,0,false);continue;}
        if(k>=.86){const fr=Math.min(M.n-1,18+Math.floor((k-.86)/.14*4));drawUnit(ctx,M,fr,S.x,S.gy+3,sc,.9,0,0,(sd%2)===1);continue;}
        const L=[[0,0,1,.9,.35],[-.42,1.5,.72,.7,.5],[.4,1,.68,.65,.62]];ctx.save();
        for(let i=0;i<L.length;i++){const [ox,oy,ss,al,sp]=L[i];const ph=g.t*sp+sd*.37+i*1.7,a=Math.floor(ph),u=ph-a;const f1=13+(a+i)%5,f2=13+(a+i+1)%5,fl=((a+i+sd)%2)===1,dx=Math.sin(g.t*.4+i*2)*2;
          drawUnit(ctx,M,f1,S.x+ox*S.r+dx,S.gy+3+oy,sc*ss,al*(1-u),0,0,fl);drawUnit(ctx,M,f2,S.x+ox*S.r+dx,S.gy+3+oy,sc*ss,al*u,0,0,!fl);}
        ctx.restore();continue;}   /* 0.12.199 the Soldier's smoke: the pack's own cloud sprite, puffing up, hanging, then thinning out */
      const k=S.t/S.life,grow=Math.min(1,S.t/.45),fade=k>.8?(1-k)/.2:1;let sd=S.seed;const rnd=()=>{sd=(sd*9301+49297)%233280;return sd/233280;};
      for(let i=0;i<26;i++){const a=rnd()*6.28,rr=Math.sqrt(rnd())*S.r*grow,ox=Math.cos(a)*rr+Math.sin(g.t*.8+i)*2,oy=Math.sin(a)*rr*.32-6-rnd()*10*grow+Math.cos(g.t*.6+i)*1.2;
        const r=(4+rnd()*5)*grow*(k>.8?.7+.3*fade:1);if(k>.8&&rnd()<(1-fade))continue;puffAt(S.x+ox,S.gy+oy,r,.62*fade,i%3?'#b8c2ca':'#9aa6b0');}}};
  const darkFx=()=>{
    for(const f of g.fx){const k=f.t/f.life;
      if(f.k==='dread'){ctx.save();ctx.globalAlpha=(1-k)*.8;ctx.strokeStyle='#8a3cff';ctx.lineWidth=1.5;ctx.beginPath();ctx.ellipse(f.x,f.gy-2,f.r*k,f.r*k*.3,0,0,7);ctx.stroke();
        ctx.globalCompositeOperation='lighter';for(let i=0;i<6;i++){const a=i*1.05+k*2,rr=f.r*k*.8;ctx.fillStyle='rgba(170,90,255,.8)';ctx.fillRect(f.x+Math.cos(a)*rr,f.gy-8-Math.sin(a)*rr*.3-k*10,1.5,1.5);}ctx.restore();continue;}
      if(f.k==='soul'){const e=1-Math.pow(1-k,2),x=f.x+(f.tx-f.x)*e,y=f.y+(f.ty-f.y)*e-Math.sin(Math.PI*k)*10;ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,x,y,3,'#a060ff',.5*(1-k*.5));glow(ctx,x,y,1.2,'#f0d8ff',.9);ctx.restore();continue;}}
    for(const e of g.enemies){if(e.dead)continue;const y=(e.gy!=null?e.gy:g.G)-12;
      if(e.hexT>0){ctx.save();ctx.globalCompositeOperation='lighter';for(let i=0;i<3;i++){const a=g.t*4+i*2.1;ctx.fillStyle='rgba(150,60,255,.75)';ctx.fillRect(e.x+Math.cos(a)*5,y-4+Math.sin(a*1.3)*6,1.2,1.2);}glow(ctx,e.x,y,6,'#6a20c0',.12);ctx.restore();}
      if(e.fearT>0){ctx.fillStyle='#c080ff';ctx.fillRect(Math.round(e.x)-.5,Math.round(y-18),1,3);ctx.fillRect(Math.round(e.x)-.5,Math.round(y-14),1,1);}}
    for(const h of g.alive())if(h.key==='cultist'&&!(h.riseT>0)){const d=h.face||1,ey=(h.gy||g.G)-14.6;ctx.save();ctx.globalCompositeOperation='lighter';for(const ox of[-.1,1.7])glow(ctx,g.heroX(h)+d*(1.2+ox),ey,1.3,'#ff2a20',.32+.12*Math.sin(g.t*3+ox));ctx.restore();}   // his eyes glow red in the dark
    for(const h of g.alive())if(h.defib){const x=Math.round(g.heroX(h)+(h.medkit?12:6)),y=Math.round((h.gy||g.G)-31);ctx.fillStyle='#202020';ctx.fillRect(x-1,y-1,5,5);ctx.fillStyle='#f2d23a';ctx.fillRect(x,y,3,3);ctx.fillStyle='#202020';ctx.fillRect(x+1,y,1,2);ctx.fillRect(x,y+1,1,1);ctx.fillRect(x+2,y+1,1,1);}   /* carrying a Defibrillator: a little yellow pad with a bolt */
    for(const h of g.alive())if(h.sandbag&&!h.sbThrow){const x=Math.round(g.heroX(h)-7),y=Math.round((h.gy||g.G)-31);ctx.fillStyle='#3a2c18';ctx.fillRect(x-1,y-1,6,5);ctx.fillStyle='#b89c68';ctx.fillRect(x,y,4,3);ctx.fillStyle='#8a7048';ctx.fillRect(x,y+1,4,.6);}   /* 0.12.104 carrying the Sandbag Wall: a little burlap bag */
    for(const h of g.alive())if(h.medkit){const x=Math.round(g.heroX(h)+6),y=Math.round((h.gy||g.G)-31);ctx.fillStyle='#202020';ctx.fillRect(x-1,y-1,5,5);ctx.fillStyle='#f2f2f2';ctx.fillRect(x,y,3,3);ctx.fillStyle='#e02020';ctx.fillRect(x+1,y,1,3);ctx.fillRect(x,y+1,3,1);}   /* carrying an ambulance Medkit */
    for(const h of g.alive()){if(h.kit&&h.kit.length){const y=(h.gy||g.G)-30;h.kit.forEach((it,i)=>{const x=g.heroX(h)-3+i*3;if(it==='med'){ctx.fillStyle='#f0f0f0';ctx.fillRect(x,y-1,2,2);ctx.fillStyle='#e02020';ctx.fillRect(x+.5,y-.5,1,1);}else{ctx.fillStyle='#ffd23f';ctx.fillRect(x,y-1.5,1.5,2.5);ctx.fillStyle='#404040';ctx.fillRect(x+.2,y-2,1,.6);}});}
      if(h.herbs>0){const y=(h.gy||g.G)-30;for(let i=0;i<h.herbs;i++){const x=g.heroX(h)-3+i*3;ctx.fillStyle='#2e7a2a';ctx.fillRect(x,y,2,1.5);ctx.fillStyle='#8fe36a';ctx.fillRect(x,y-.6,1.2,1);}}   // Scavenger: herbs carried
      if(h.herbT>0&&Math.random()<.4){ctx.fillStyle='rgba(140,230,110,.8)';ctx.fillRect(g.heroX(h)-5+Math.random()*10,(h.gy||g.G)-6-Math.random()*16,1,1);}}
    for(const f of g.fx)if(f.k==='herbget'){const k=f.t/f.life;ctx.save();ctx.globalAlpha=1-k;ctx.fillStyle={med:'#f2f2f2',bat:'#7fe0ff',defib:'#f2d23a'}[f.kit]||'#8fe36a';ctx.fillRect(f.x-1,f.y-k*6,3,2);ctx.fillStyle='#2e7a2a';ctx.fillRect(f.x,f.y-k*6+1,1,2);ctx.restore();}
    for(const h of g.alive()){const A=h.search?[h.search.t,h.search.T||1.5,h.search.trap||h.search.disarm?'#9ad0ff':'#e8ecf2','#8a92a0']:h.setting?[h.setting.t,h.setting.T,'#ffc070','#a06030']:h.planting?[h.planting.t,h.planting.T,'#ffc070','#a06030']:null;if(!A)continue;   /* 0.12.55: one progress bar for every timed action: searching (silver), defusing / alarms (blue), planting (amber) */
      const k=Math.min(1,A[0]/A[1]),x=Math.round(g.heroX(h)+8),y0=Math.round((h.gy||g.G)-14),H=12;ctx.fillStyle='#000b';ctx.fillRect(x-1,y0-H-1,4,H+2);const f=Math.round(H*k);const gr=ctx.createLinearGradient(x,0,x+2,0);gr.addColorStop(0,A[2]);gr.addColorStop(1,A[3]);ctx.fillStyle=gr;ctx.fillRect(x,y0-f,2,f);}   // searching: a silver bar rising beside him
    for(const h of g.alive())if(h.shellT>0){ctx.save();ctx.globalAlpha=.55;ctx.fillStyle='#3e7a3a';ctx.beginPath();ctx.ellipse(g.heroX(h),(h.gy||g.G)-9,10,10,0,Math.PI,0);ctx.fill();ctx.strokeStyle='#9be07a';ctx.lineWidth=1;ctx.stroke();ctx.restore();}   // Shell Up
    for(const e of g.enemies)if(!e.dead&&e.webT>0){e.webT-=1/60;const y=(e.gy!=null?e.gy:g.G)-10;ctx.save();ctx.strokeStyle='rgba(235,240,255,.7)';ctx.lineWidth=.6;for(let i=0;i<4;i++){const a=i*.8;ctx.beginPath();ctx.moveTo(e.x-6*Math.cos(a),y-6*Math.sin(a));ctx.lineTo(e.x+6*Math.cos(a),y+6*Math.sin(a));ctx.stroke();}ctx.restore();}   // webbed
    for(const h of g.alive())if(h.pactT>0){const gy=h.gy||g.G,p=.5+.5*Math.sin(g.t*8);ctx.save();ctx.globalAlpha=Math.min(1,h.pactT)*(.45+.3*p);ctx.strokeStyle='#d0202a';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(g.heroX(h),gy,9,2.4,0,0,7);ctx.stroke();ctx.restore();}};
  if(g.nailFields)for(const F of g.nailFields){const al=Math.min(1,F.t/.6);ctx.save();ctx.globalAlpha=al;let r=F.seed;const n=Math.round((F.x1-F.x0)/3);for(let i=0;i<n;i++){r=(r*9301+49297)%233280;const q=r/233280;const x=F.x0+(F.x1-F.x0)*((i+q)/n),y=F.gy-1+(q-.5)*4;ctx.fillStyle='#9aa0aa';ctx.fillRect(Math.round(x),Math.round(y),2,1);ctx.fillStyle='#e8ecf2';ctx.fillRect(Math.round(x),Math.round(y),1,1);}ctx.restore();}   /* 0.12.211 nails on the ground */
  for(const h of g.alive())if(h.wallT>0){const fw=h.face||1,x=g.heroX(h)+fw*9,gy=h.gy||g.G,p=.6+.4*Math.sin(g.t*6);ctx.save();ctx.globalAlpha=.22*p;ctx.fillStyle='#c0303a';ctx.beginPath();ctx.ellipse(x,gy-16,4,17,0,0,7);ctx.fill();ctx.globalAlpha=.55*p;ctx.strokeStyle='#ff6a6a';ctx.lineWidth=.8;ctx.beginPath();ctx.ellipse(x,gy-16,4,17,0,fw>0?-1.4:1.7,fw>0?1.4:4.6);ctx.stroke();   /* 0.12.214 Shield_Wall: a crimson wall of force in front of the shield */
      if(h.wallDrag>0){for(let i=0;i<3;i++){ctx.globalAlpha=.7;ctx.fillStyle=Math.random()<.5?'#ffd27a':'#fff2c0';ctx.fillRect(x-fw*(2+Math.random()*4),gy-1-Math.random()*2,1,1);}ctx.globalAlpha=.35;ctx.fillStyle='#8a7a6a';ctx.beginPath();ctx.ellipse(g.heroX(h)-fw*4,gy-1,5+Math.random()*2,1.5,0,0,7);ctx.fill();}   // shield scraping the ground + dust at his feet while he drags forward
      ctx.restore();}
  for(const P of g.pools||[]){const cx=(P.x0+P.x1)/2,w=(P.x1-P.x0)/2;ctx.save();ctx.globalAlpha=P.fire>0?.9:Math.min(.85,(P.t||1)/2);ctx.fillStyle='#120e10';ctx.beginPath();ctx.ellipse(cx,P.gy,w,P.dz*.7,0,0,7);ctx.fill();ctx.fillStyle='rgba(120,90,160,.35)';ctx.beginPath();ctx.ellipse(cx-w*.3,P.gy-.6,w*.35,P.dz*.25,0,0,7);ctx.fill();   /* 0.12.216 oil pool: black and glossy, with a purple sheen */
      if(P.fire>0){const n=Math.round(w*.9);for(let i=0;i<n;i++){const q=((i*37+P.seed*13)%n)/n,x=P.x0+(P.x1-P.x0)*((i+.5)/n),hgt=4+((Math.sin(g.t*11+i*1.7)+1)*3);ctx.globalAlpha=.85;ctx.fillStyle=q<.3?'#fff2a0':q<.7?'#ffb030':'#ff5a1a';ctx.fillRect(Math.round(x),Math.round(P.gy-hgt-(q*2)),1,Math.round(hgt));}ctx.globalAlpha=.25;ctx.fillStyle='#ff7a20';ctx.beginPath();ctx.ellipse(cx,P.gy-4,w+3,6,0,0,7);ctx.fill();}
      ctx.restore();}
  for(const B of g.barrels||[]){const x=Math.round(B.x+(B.wob>0?Math.sin(g.t*60)*.7:0)),y=Math.round(B.gy);ctx.save();ctx.fillStyle='rgba(0,0,0,.35)';ctx.beginPath();ctx.ellipse(x,y,5,1.5,0,0,7);ctx.fill();   /* 0.12.216 a rusty red oil drum with a hazard band, dented as it takes hits */
      ctx.fillStyle='#1a0c0a';ctx.fillRect(x-5,y-14,10,14);ctx.fillStyle='#8a2a1e';ctx.fillRect(x-4,y-13,8,12);ctx.fillStyle='#b8402a';ctx.fillRect(x-4,y-13,2,12);ctx.fillStyle='#5a1a12';ctx.fillRect(x+2,y-13,2,12);
      ctx.fillStyle='#e8c030';ctx.fillRect(x-4,y-9,8,2);ctx.fillStyle='#1a0c0a';for(let i=0;i<4;i++)ctx.fillRect(x-4+i*2+(i%2),y-9,1,2);ctx.fillStyle='#3a1410';ctx.fillRect(x-5,y-14,10,1);ctx.fillRect(x-5,y-5,10,1);ctx.fillStyle='#c8c0b0';ctx.fillRect(x+1,y-14,2,1);
      if(B.dmg>0&&!B.gone){const fr=Math.min(1,B.dmg/B.hp);ctx.fillStyle='#120e10';const sx=x+(B.side||1)*5;for(let i=0;i<1+Math.round(fr*3);i++){const q=(g.t*(2+fr*6)+i*.37)%1;ctx.fillRect(Math.round(sx+(B.side||1)*q*(3+fr*6)),Math.round(y-10+q*q*9),1,1+(fr>.6?1:0));}}   /* oil streaming out, a gush when it's about to go */
      if(B.dmg>0){ctx.fillStyle='#120e10';ctx.fillRect(x-1,y-11,1,1);if(B.dmg>12)ctx.fillRect(x+1,y-6,1,1);if(B.dmg>20){ctx.fillStyle='#ff9a40';ctx.fillRect(x-2,y-12,1,1);}}ctx.restore();}
  if(g.radio&&g.radio.x>-12){const R=g.radio,x=Math.round(R.x),y=Math.round(R.gy),live=R.state==='idle'||R.state==='playing';ctx.save();   /* 0.12.217 the hidden radio: a small dented boombox, antenna up; it glows while it talks, then sparks and goes dark */
      ctx.globalAlpha=R.state==='dead'?.7:.95;ctx.fillStyle='#1a1614';ctx.fillRect(x-5,y-6,10,6);ctx.fillStyle=R.state==='dead'?'#3a3430':'#4a4038';ctx.fillRect(x-4,y-5,8,4);ctx.fillStyle='#22201c';ctx.fillRect(x-3,y-4,2,2);ctx.fillRect(x+1,y-4,2,2);
      ctx.fillStyle='#8a8070';ctx.fillRect(x-4,y-9,1,3);ctx.fillRect(x-5,y-11,1,2);
      if(R.state==='playing'){const p=.5+.5*Math.sin(g.t*20);ctx.fillStyle=`rgba(120,255,140,${.6+.4*p})`;ctx.fillRect(x-1,y-5,2,1);ctx.globalAlpha=.25*p;ctx.fillStyle='#9affb0';ctx.beginPath();ctx.arc(x,y-3,7,0,7);ctx.fill();}
      else if(R.state==='idle'&&Math.floor(g.t*1.3)%5===0){ctx.fillStyle='#7aff9a';ctx.fillRect(x-1,y-5,1,1);}   // a faint blink now and then: the clue
      else if(R.state==='dying'&&Math.random()<.5){ctx.fillStyle=Math.random()<.5?'#ffe08a':'#fff';ctx.fillRect(x-4+Math.random()*8,y-8+Math.random()*6,1,1);}
      ctx.restore();}
  const iaiWaves=()=>{for(const W of (g.waves||[])){const x=W.x,y=W.gy-14,d=W.dir,fade=Math.min(1,W.left/20+.25);ctx.save();   /* 0.12.236 Cheez: the Iaijutsu wave, a cyan crescent with a trail */
      for(let k=0;k<3;k++){const tx=x-d*k*7;ctx.globalAlpha=fade*(.18-.05*k);ctx.fillStyle='#3af0ff';ctx.beginPath();ctx.ellipse(tx,y,5,15-k*2,0,d>0?-Math.PI/2:Math.PI/2,d>0?Math.PI/2:Math.PI*1.5);ctx.fill();}
      ctx.globalAlpha=fade*.9;ctx.strokeStyle='#3af0ff';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(x,y,5,14,0,d>0?-Math.PI/2:Math.PI/2,d>0?Math.PI/2:Math.PI*1.5);ctx.stroke();
      ctx.strokeStyle='#e8ffff';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(x+d,y,4,12,0,d>0?-Math.PI/2:Math.PI/2,d>0?Math.PI/2:Math.PI*1.5);ctx.stroke();ctx.restore();}};
  const banners=()=>{for(const B of (g.banners||[])){const x=Math.round(B.x),y=Math.round(B.gy),fade=Math.min(1,B.t/.6,(B.T-B.t)/.3+.2);ctx.save();ctx.globalAlpha=fade;   /* 0.12.234 Cheez: Host_With_The_Most neon DICE BOYS banner: a still pole, the cloth waves */
      ctx.globalAlpha=fade*.1;ctx.fillStyle='#8cff46';ctx.beginPath();ctx.ellipse(x,y-1,B.r,6,0,0,Math.PI*2);ctx.fill();ctx.globalAlpha=fade;
      ctx.fillStyle='#2a2a36';ctx.fillRect(x,y-44,2,44);ctx.fillStyle='#3af0ff';ctx.fillRect(x,y-45,2,1);ctx.fillRect(x-1,y-46,4,1);
      const W=26,Hh=12;for(let i=0;i<W;i++){const o=Math.round(Math.sin(g.t*5-i*.35)*1.5*(i/W));ctx.fillStyle=i%2?'#0c2410':'#102c14';ctx.fillRect(x+2+i,y-43+o,1,Hh);ctx.fillStyle='#8cff46';ctx.fillRect(x+2+i,y-43+o,1,1);ctx.fillRect(x+2+i,y-44+Hh+o,1,1);}
      ctx.fillStyle='#3af0ff';ctx.font='bold 5px monospace';ctx.textBaseline='middle';const txt=['DICE','BOYS'];txt.forEach((t,j)=>{for(let c=0;c<t.length;c++){const cx=x+5+c*5,o=Math.round(Math.sin(g.t*5-(cx-x)*.35)*1.5*((cx-x)/W));ctx.fillText(t[c],cx,y-40+j*6+o);}});
      ctx.restore();}};
  const druidFx=()=>{for(const f of g.fx){const k=f.t/f.life;
      if(f.k==='smash'){const R=f.r*Math.min(1,k/.35),a=1-k;ctx.save();   /* 0.12.236 Warhound jetpack landing: a dust-and-rock ground smash */
        ctx.globalAlpha=a*.55;ctx.strokeStyle='#d9c7a0';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(f.x,f.gy,R,R*.22,0,0,Math.PI*2);ctx.stroke();
        ctx.globalAlpha=a*.25;ctx.fillStyle='#8a7a5c';ctx.beginPath();ctx.ellipse(f.x,f.gy,R*.85,R*.18,0,0,Math.PI*2);ctx.fill();ctx.restore();
        for(let i=0;i<14;i++){const ang=i/14*Math.PI*2+f.x,d=R*(.35+.6*((i*37%10)/10)),px=f.x+Math.cos(ang)*d,py=f.gy+Math.sin(ang)*d*.22-Math.sin(Math.min(1,k*1.4)*Math.PI)*(4+i%4*2);puffAt(px,py-2,(1.6+2.4*k)*(1+(i%3)*.3),.5*(1-k),i%2?'#b9a27a':'#9c8a68');}
        ctx.globalAlpha=Math.max(0,1-k*1.6);ctx.fillStyle='#5a4a36';for(let i=0;i<10;i++){const dir=i%2?1:-1,px=f.x+dir*R*k*(.4+(i%5)*.15),py=f.gy-6-Math.sin(k*Math.PI)*(8+i%4*3);ctx.fillRect(Math.round(px),Math.round(py),1+(i%2),1+(i%2));}ctx.globalAlpha=1;continue;}
      if(f.k==='iaicut'){const a=1-k;ctx.save();ctx.globalAlpha=a;ctx.fillStyle='#3af0ff';const x0=Math.min(f.x0,f.x1),w=Math.abs(f.x1-f.x0);ctx.fillRect(x0,f.gy,w,1);ctx.globalAlpha=a*.4;ctx.fillRect(x0,f.gy-1,w,3);ctx.globalAlpha=a*.8;ctx.fillStyle='#fff';ctx.fillRect(x0+w*k,f.gy,Math.max(2,w*.2*(1-k)),1);ctx.restore();continue;}   /* 0.12.234 Iaijutsu: a thin cyan cut line through the lane */
      if(f.k==='chopwave'){const d=f.dir,front=Math.min(1,k/.55)*f.len,gy=f.gy;ctx.save();   /* 0.12.222 Ground_Chop: a tall wave of torn earth racing ahead: jagged rock spikes erupt at the front and crumble behind it, dust and chunks fly */
        const N=Math.ceil(f.len/3);for(let i=0;i<N;i++){const px=i*3;if(px>front)break;const age=(front-px)/f.len,life=Math.max(0,1-age*2.2-(k>.7?(k-.7)/.3:0));if(life<=0)continue;
          const hgt=(11+((i*7+f.seed)%5)*3.6)*life*(px>front-6?1.3:1),x=f.x0+d*px;ctx.globalAlpha=Math.min(1,life*1.4);
          ctx.fillStyle='#1a0e08';ctx.beginPath();ctx.moveTo(x-2.8,gy);ctx.lineTo(x+d*.8,gy-hgt);ctx.lineTo(x+2.8,gy);ctx.fill();ctx.fillStyle='#c8925a';ctx.beginPath();ctx.moveTo(x-1.6,gy);ctx.lineTo(x+d*.8,gy-hgt+1.5);ctx.lineTo(x+.6,gy);ctx.fill();ctx.fillStyle='#ffe0b0';ctx.fillRect(Math.round(x+d*.4),Math.round(gy-hgt+1),1,1);}
        const fx=f.x0+d*front;if(k<.6){glow(ctx,fx,gy-10,14,'#ffb060',.35*(1-k/.6));ctx.globalAlpha=.55*(1-k/.6);ctx.fillStyle='#c8a878';ctx.beginPath();ctx.ellipse(fx,gy-3,7,5,0,0,7);ctx.fill();ctx.globalAlpha=.35;ctx.strokeStyle='#ffe0a0';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(fx,gy-8,3,10,0,0,7);ctx.stroke();
          for(let j=0;j<5;j++){const r=((j*53+f.seed*7)%97)/97,q=(k*3+r)%1;ctx.globalAlpha=1-q;ctx.fillStyle=j%2?'#6a4a30':'#b08860';ctx.fillRect(Math.round(fx-d*q*6+(r-.5)*8),Math.round(gy-4-q*16*(.6+r)),2,2);}}
        ctx.restore();continue;}
      if(f.k==='toolbox'){const u=Math.min(1,k),x=f.x0+(f.x1-f.x0)*u,y=(f.gy0+(f.gy1-f.gy0)*u)-16-Math.sin(Math.PI*u)*22;ctx.save();ctx.translate(x,y);ctx.rotate(u*9*(f.x1>=f.x0?1:-1));   /* 0.12.207 Edward's Toolbox_Toss: a red toolbox tumbling end over end */
        ctx.fillStyle='#1a0c0c';ctx.fillRect(-4.5,-3,9,6);ctx.fillStyle='#c0302a';ctx.fillRect(-4,-2.5,8,5);ctx.fillStyle='#e85a4a';ctx.fillRect(-4,-2.5,8,1);ctx.fillStyle='#9aa0a8';ctx.fillRect(-1.5,-4,3,1.2);ctx.fillRect(-.5,-.5,1,1);ctx.restore();continue;}
      if(f.k==='fswipe'){const d=f.dir,e=1-Math.pow(1-Math.min(1,k/.5),3),al=k<.55?1:Math.max(0,1-(k-.55)/.45),cx=f.x,cy=f.gy-13,R=f.r;   /* 0.12.201 Fireman cleave: a big vicious crescent with gore streaks */
        ctx.save();ctx.globalAlpha=al;const a0=-1.25,a1=a0+2.5*e;const A0=d>0?a0:Math.PI-a0,A1=d>0?a1:Math.PI-a1;
        for(const [w,col,rr] of [[6,'rgba(90,10,10,.55)',R],[3.6,'rgba(220,60,30,.8)',R-1],[1.4,'rgba(255,220,180,.95)',R-1.5],[1,'rgba(160,20,20,.8)',R*.72]]){ctx.strokeStyle=col;ctx.lineWidth=w;ctx.lineCap='round';ctx.beginPath();ctx.ellipse(cx,cy,rr,rr*.62,0,Math.min(A0,A1),Math.max(A0,A1));ctx.stroke();}
        if(k>.25){ctx.fillStyle='rgba(170,10,20,'+(.9*al)+')';for(let i=0;i<7;i++){const q=(i*37%11)/11,aa=a0+2.5*q,ex=cx+d*Math.cos(aa)*R*(1+.25*k),ey=cy+Math.sin(aa)*R*.62+k*6;ctx.fillRect(ex,ey,1.3,1.3);}}
        ctx.restore();continue;}
      if(f.k==='claw'){const d=f.dir,e=1-Math.pow(1-Math.min(1,k/.55),3);const span=Math.max(6,Math.abs(f.tx-f.x));const cx=f.x+d*(span*e),cy=f.gy-11-2*Math.sin(Math.PI*e);
        const s=(.55+.55*e)*(k>.7?1-(k-.7)/.3*.3:1),al=k<.7?1:Math.max(0,1-(k-.7)/.3);ctx.save();ctx.globalAlpha=al;ctx.globalCompositeOperation='lighter';
        glow(ctx,cx,cy,9*s,'#4dff7a',.28);
        ctx.lineCap='round';
        for(const [w,col] of [[2.4*s,'rgba(60,220,110,.55)'],[1.1*s,'rgba(200,255,200,.95)']]){ctx.strokeStyle=col;ctx.lineWidth=w;
          ctx.beginPath();ctx.ellipse(cx-d*2*s,cy,2.6*s,3.2*s,0,0,7);ctx.stroke();   // palm
          for(let i=0;i<4;i++){const oy=(i-1.5)*2.3*s;ctx.beginPath();ctx.moveTo(cx,cy+oy*.7);ctx.quadraticCurveTo(cx+d*4.5*s,cy+oy-1.2*s,cx+d*6.5*s,cy+oy+1.6*s);ctx.stroke();}}   // four hooked talons
        if(k>.45){const q=(k-.45)/.55;ctx.strokeStyle=`rgba(170,255,170,${.9*(1-q)})`;ctx.lineWidth=.9;for(let i=0;i<3;i++){const ox=f.tx+(i-1)*2.2;ctx.beginPath();ctx.moveTo(ox-d*2,f.gy-17+i);ctx.lineTo(ox+d*3,f.gy-6+i);ctx.stroke();}}   // three claw rakes on the target
        ctx.restore();continue;}
      if(f.k==='mend'){ctx.save();ctx.globalCompositeOperation='lighter';const y=f.gy-14-k*10;glow(ctx,f.x,y,8*(1-k)+3,'#5dff6a',.4*(1-k));ctx.fillStyle=`rgba(150,255,140,${1-k})`;ctx.fillRect(f.x-1,y-4,2,8);ctx.fillRect(f.x-4,y-1,8,2);ctx.fillStyle=`rgba(235,255,230,${1-k})`;ctx.fillRect(f.x-.5,y-.5,1,1);
        for(let i=0;i<5;i++){const a=i*1.26+f.t*3;ctx.fillStyle=`rgba(120,230,110,${.8*(1-k)})`;ctx.fillRect(f.x+Math.cos(a)*(6+k*6),f.gy-6-k*16-i*2,1,1);}ctx.restore();}
      if(f.k==='thorn'&&f.t>=0){const T=THORNS[f.v%4];const up=Math.min(1,f.t/.15),dn=k>.75?(1-k)/.25:1;const sc=.17*up;ctx.save();ctx.globalAlpha=dn;drawUnit(ctx,T,0,f.x,f.gy+1+(1-dn)*6,sc,null,0,0,false);ctx.restore();}}
    for(const h of g.alive())if(h.hotT>0){const el=8-h.hotT;const fr=el<1.2?Math.min(6,Math.floor(el/1.2*7)):4+Math.floor(g.t*5)%3;ctx.save();ctx.globalCompositeOperation='lighter';
      drawUnit(ctx,VINE,fr,g.heroX(h),(h.gy||g.G)+2,.11,h.hotT<.6?h.hotT/.6:.9,0,0,false);ctx.restore();}
    for(const T of g.cyclones||[]){const A=T.A,fr=T.t<A.dur?Math.floor(T.t*10)%10:Math.min(15,10+Math.floor((T.t-A.dur)/.35*6));ctx.save();ctx.globalCompositeOperation='lighter';
      drawUnit(ctx,TORN,fr,T.x,T.gy+2,.36,1,0,0,false);ctx.restore();}};
  const poultices=()=>{for(const h of g.alive())if(h.poulticeT>0){ctx.save();ctx.globalCompositeOperation='lighter';for(let i=0;i<4;i++){const ph=((g.t*.8+i*.25)%1);ctx.fillStyle=`rgba(150,235,130,${.8*(1-ph)})`;ctx.fillRect(g.heroX(h)-5+i*3,(h.gy||g.G)-8-ph*16,1.5,1.5);}ctx.restore();}};
  /* 0.12.62 Warhound flamethrower: campfire flames (Kyle's fire art, logs cut off) pouring out in a widening cone, with a hot glow; burning enemies carry small flames */
  const blueFire=(x,gy,s,fr,a,down)=>{const IM=XIMG.camp;if(!IM||!IM.complete)return;if(!XIMG._blueCamp){try{const c=document.createElement('canvas');c.width=IM.width;c.height=IM.height;const cx=c.getContext('2d');cx.drawImage(IM,0,0);const D=cx.getImageData(0,0,c.width,c.height),p=D.data;
      for(let i=0;i<p.length;i+=4){const r=p[i],gg=p[i+1],b=p[i+2];p[i]=b*.6;p[i+1]=gg*.85;p[i+2]=Math.min(255,r*1.1+30);}cx.putImageData(D,0,0);XIMG._blueCamp=c;}catch(e){XIMG._blueCamp=IM;}}   /* 0.12.67: Kyle's campfire flames, recoloured blue for the jetpack */
    ctx.save();ctx.globalAlpha=a;if(down){ctx.translate(x,gy);ctx.scale(1,-1);ctx.translate(-x,-gy);}ctx.drawImage(XIMG._blueCamp,fr*34+3,0,28,27,x-14*s,gy-27*s,28*s,27*s);ctx.restore();};   // down: the flame points down (jet exhaust)
  const fireBit=(x,gy,s,fr,a)=>{const IM=XIMG.camp;if(!IM||!IM.complete)return;ctx.save();ctx.globalAlpha=a;ctx.drawImage(IM,fr*34+3,0,28,27,x-14*s,gy-27*s,28*s,27*s);ctx.restore();};
  /* 0.12.77 (Kyle's flamethrower sheet, crawl_flame.png): 15 frames, 290x200 each, nozzle at (22,156): 5 ignite, 5 full burst, 5 dying off.
     Scaled so the burst reaches the flame's length, anchored on the nozzle (the Warhound's) or in front of the Fireman_Zombie, mirrored when facing left */
  const flames=()=>{const IM=XIMG.flame;for(const f of g.fx){if(f.k!=='flame')continue;const k=Math.min(.999,f.t/f.life),src=f.src;
      let x0,y0;if(src&&src.alive&&src.key==='robot'){x0=g.heroX(src)+f.dir*13;y0=(src.gy||G)-13.5;}else{x0=src&&!src.dead&&src.x!=null?src.x+f.dir*12:f.x;y0=f.gy-12;}f.x=x0;
      const fi=k<.2?Math.floor(k/.2*5):k<.72?5+Math.floor((k-.2)/.52*10)%5:10+Math.min(4,Math.floor((k-.72)/.28*5));
      if(IM&&IM.complete&&IM.naturalWidth){const s=f.len/205;ctx.save();ctx.translate(x0,y0);const dn=Math.max(0,(f.gy-y0));const ang=Math.min(.45,.216*dn/13.5);ctx.rotate(f.dir*ang);ctx.scale(f.dir*s,s*.62);ctx.drawImage(IM,fi*290,0,290,200,-22,-156,290,200);ctx.restore();}}   // 0.12.78: from the barrel, angled so the bottom of the burst just touches the ground of his lane
    for(const e of g.enemies)if(e.fb&&!e.dead){const fr=4+Math.floor(g.t*10+e.phase*3)%4;fireBit(e.x+Math.sin(g.t*7+e.phase)*2,(e.gy!=null?e.gy:G)-14,.32,fr,.85);fireBit(e.x-3,(e.gy!=null?e.gy:G)-4,.22,(fr+2)%4+4,.7);}};
  /* 0.12.66 JP: the doobie (a little white joint at his mouth burning down over the 2s, glowing ember), smoke puffs drifting off him,
     a green haze while he's HIGH, a dust trail while he rushes to family, and his shield glinting during Trash_Talk */
  const jpFx=()=>{for(const h of g.heroes){if(h.key!=='jp'||!h.alive)continue;const gy=h.gy||G,dir=(h.face||1)>0?1:-1,mx=h.x+dir*2.2,my=gy-16.4;
      if(h.smoking){const k=Math.min(1,h.smoking.t/2),L=3.4*(1-k*.6);ctx.fillStyle='#f4efe4';ctx.fillRect(Math.min(mx,mx+dir*L),my,Math.abs(dir*L),.9);
        const fl=.6+.4*Math.sin(g.t*23);ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,mx+dir*L,my+.4,2.2,'#ff6a20',.5*fl);ctx.restore();ctx.fillStyle=fl>.7?'#ffd060':'#ff4a10';ctx.fillRect(mx+dir*L-.5,my,1,1);
        for(let i=0;i<5;i++){const p=((g.t*.7+i*.2)%1);ctx.globalAlpha=(1-p)*.55;ctx.fillStyle='#c8c8c0';const r=.8+p*2.6;ctx.beginPath();ctx.arc(mx+dir*(L+1)+Math.sin(g.t*2+i)*2+p*4*dir,my-1-p*14,r,0,7);ctx.fill();}ctx.globalAlpha=1;}
      if(h.highT>0){const p=.5+.5*Math.sin(g.t*1.7);ctx.globalAlpha=.18+.1*p;ctx.fillStyle='#9ad06a';for(let i=0;i<3;i++){const q=((g.t*.25+i/3)%1);ctx.beginPath();ctx.arc(h.x-3+i*3+Math.sin(g.t+i)*2,gy-22-q*10,1.4+q*2,0,7);ctx.fill();}ctx.globalAlpha=1;}
      if(h.rush){ctx.fillStyle='rgba(180,150,110,.5)';for(let i=0;i<4;i++)ctx.fillRect(h.x-dir*(4+i*3)+Math.sin(g.t*30+i)*1,gy-1-(i%2),2,1.5);}
      if(h.trashT>0){ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,h.x+dir*3,gy-14,6,'#ffb040',.25+.15*Math.sin(g.t*8));ctx.restore();}}};
  const logs=()=>{for(const L of g.logs||[]){const x=Math.round(L.x),y=L.gy,a=(L.x-L.x0)/5;ctx.save();ctx.translate(x,y-4);   /* 0.12.58 Log_Roll: a rolling log with dust behind it */
      ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(-7,3,14,2);ctx.fillStyle='#6b4423';ctx.fillRect(-7,-3,14,7);ctx.fillStyle='#8a5a30';ctx.fillRect(-7,-3,14,2);
      ctx.fillStyle='#c8a070';ctx.beginPath();ctx.ellipse(7,0.5,2,3.5,0,0,7);ctx.fill();ctx.strokeStyle='#7a4a20';ctx.lineWidth=.6;ctx.beginPath();ctx.ellipse(7,.5,1,2,0,0,7);ctx.stroke();
      ctx.fillStyle='#4a2c14';for(let i=0;i<3;i++){const px=((i*5-a*3)%14+14)%14-7;ctx.fillRect(px,-3,1,7);}ctx.restore();
      ctx.fillStyle='rgba(170,140,100,.5)';for(let i=0;i<4;i++){const ph=(g.t*3+i*.25)%1;ctx.fillRect(x-9-ph*10,y-2-ph*4,1.5,1.5);}}};
  const quakes=()=>{for(const f of g.fx)if(f.k==='quake'){if(f.chop){const k0=Math.min(1,f.t/(f.life*.7)),n=7;ctx.save();   /* 0.12.58 Ground_Chop: rock spikes burst up along the ground, running outward from the axe */
      for(let i=0;i<n;i++){const p=i/(n-1);if(p>k0)break;const life=1-Math.min(1,(k0-p)*2.2+f.t/f.life*.5);if(life<=0)continue;const sx=f.x-f.chop*f.w/2+f.chop*p*f.w,hh=(3+4*(1-p*.4))*life;ctx.fillStyle='#5a4228';ctx.beginPath();ctx.moveTo(sx-2.5,f.gy);ctx.lineTo(sx-.5,f.gy-hh);ctx.lineTo(sx+.6,f.gy-hh*.7);ctx.lineTo(sx+2.5,f.gy);ctx.fill();ctx.fillStyle='#b89060';ctx.fillRect(sx-.5,f.gy-hh,1,1.2);
        ctx.fillStyle=`rgba(190,160,110,${.6*life})`;ctx.fillRect(sx-3+((i*7)%5),f.gy-hh-2-(1-life)*4,1.5,1.5);ctx.fillRect(sx+1,f.gy-hh-4-(1-life)*6,1,1);}ctx.restore();}const k=f.t/f.life;ctx.save();ctx.globalAlpha=1-k;ctx.fillStyle='#8a6a40';
      for(let i=0;i<8;i++){const x=f.x-f.w/2+(i+.5)*f.w/8;ctx.fillRect(x-1,f.gy-1-Math.sin((k+i*.13)*Math.PI)*4,2,2);}ctx.strokeStyle='#c8a060';ctx.beginPath();ctx.moveTo(f.x-f.w/2,f.gy);ctx.lineTo(f.x+f.w/2,f.gy);ctx.stroke();ctx.restore();}};
  const booms=()=>{for(const f of g.fx){if(f.k==='strike'&&ATLAS.strike){const S=ATLAS.strike,k=f.t/f.life,fr=Math.min(S.n-1,Math.floor(k*S.n));ctx.save();ctx.globalCompositeOperation='lighter';ctx.filter='hue-rotate(180deg) saturate(1.6)';drawUnit(ctx,S,fr,f.x,f.gy+1,.6,k>.8?(1-k)/.2:1,0,0,false);ctx.restore();glow(ctx,f.x,f.gy-4,14,'#fff08a',.5*(1-k));continue;}   /* 0.12.178 Thunderclap: the pack's lightning strike, tinted yellow */
    if(f.k==='frag'&&ATLAS.frag){const F=ATLAS.frag,k=f.t/f.life,fr=Math.min(F.n-1,4+Math.floor(k*(F.n-4)));drawUnit(ctx,F,fr,f.x,f.gy+2,.52,k>.8?(1-k)/.2:1,0,0,false);continue;}   /* 0.12.175 frag blast: the pack's explosion */
    if(f.k!=='boom')continue;const k=f.t/f.life,fr=Math.min(BOOM.n-1,Math.floor(k*BOOM.n));drawUnit(ctx,BOOM,fr,f.x,f.gy+2,f.small?.17:.32,k>.85?(1-k)/.15:1,0,0,false);}};
  /* 0.12.107 Shadow_Clone: a see-through copy of Chibi with a faint purple glow, moving and swinging on its own */
  const drawClone=(c)=>{const h=c.owner;if(!h)return;const fade=Math.min(1,(c.life-c.t)/.4,c.t/.25);
    ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,c.x,c.gy-12,7,'#b066ff',.13*fade);glow(ctx,c.x,c.gy-12,3.5,'#d9a6ff',.08*fade);ctx.restore();
    const ghost=Object.assign({},h,{x:c.x,gy:c.gy,face:c.face,ghost:1,moving:c.moving,walkT:c.walkT,animM:c.animM,animT:c.animM>0?.35-c.animM:0,swingAnim:h.swingAnim||'attack1',leapH:0,bleedT:0,shield:0,shieldT:0,hotT:0,cozyT:0,stealthT:0,cloneT:0,smoking:null,dash:null,whirl:null,perch:null,sbThrow:null,climb:null,sandbag:0,medkit:0,defib:0,herbs:0,kit:[],hitFlash:0,downed:0,riseT:0,shoutT:0,rageT:0,courage:0});
    GHOST_A=.5*fade;try{drawHero(ghost);}finally{GHOST_A=1;}};
  const drawHero=(h)=>{const G0=h.gy||g.G;ctx.save();shrinkAt(ctx,h.x,G0,HS);drawHero0(h);ctx.restore();};
  const drawHero0=(h)=>{const G=h.gy||g.G;if(!h.alive){return;}
    if(h.bleedT>0){const p=.5+.5*Math.sin(g.t*10);ctx.save();ctx.globalCompositeOperation='lighter';
      for(let r=0;r<3;r++){const rr=((g.t*1.4+r/3)%1);ctx.strokeStyle=`rgba(220,20,40,${.55*(1-rr)})`;ctx.beginPath();ctx.ellipse(h.x,G-26,8+rr*14,(8+rr*14)*1.25,0,0,7);ctx.stroke();}
      glow(ctx,h.x,G-26,10+2*p,'#c0102a',.18);ctx.restore();
      for(let i=0;i<5;i++){const u2=((g.t*1.6+i*.21)%1);const dx=Math.round(h.x-7+((i*37)%15));const dy=Math.round(G-44+u2*42);ctx.fillStyle=u2<.15?'#ff3a4a':'#c0102a';ctx.fillRect(dx,dy,2,2);if(u2>.92){ctx.fillStyle='#7a0a16';ctx.fillRect(dx-1,G-1,3,1);}}}
    if(h.rageT>0){const p=.5+.5*Math.sin(g.t*9);ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,h.x,G-24,15+3*p,'#a0541c',.32);glow(ctx,h.x,G-24,8,'#ff8a30',.12+.08*p);   /* 0.12.58 Timber_Rage: a pulsing brown-orange glow and wood chips flying off him */
      for(let i=0;i<5;i++){const u2=((g.t*1.3+i*.2)%1);ctx.fillStyle=u2<.3?'#e0a060':'#8a5a2a';ctx.fillRect(Math.round(h.x-8+((i*29)%17)),Math.round(G-10-u2*40),1.5,1);}ctx.restore();}
    let fr=11;if(h.animT>0)fr=6+Math.min(2,Math.floor((.32-h.animT)/.107));else if(h.hitFlash>0)fr=9;else if(g.scroll)fr=Math.floor(h.walkT*9)%6;
    const ph=h.key.length*1.7;const wob=h.wanderX||0;const ly=Math.round(2+Math.sin(g.t*.7+ph)*2.5);
    const lx=(h.animT>0&&h.lunge?h.lunge*Math.sin(Math.PI*(1-h.animT/.32))*.9:0)+(h.dodgeX||0)+wob;if(h.dodging&&fr===11)fr=Math.floor(g.t*12)%6;
    ctx.save();ctx.translate(0,ly);
    if(SP['h_'+h.key+'_a']){   // partner pair: two fighters, each with its own animation
      const fa=h.animT>0?6+Math.min(2,Math.floor((.32-h.animT)/.107)):h.hitFlash>0?9:g.scroll?Math.floor(h.walkT*9)%6:11;
      const fb=h.animT2>0?6+Math.min(2,Math.floor((.32-h.animT2)/.107)):h.hitFlash>0?9:g.scroll?Math.floor(h.walkT*9+3)%6:11;
      const lb=h.animT2>0&&h.lunge2?h.lunge2*Math.sin(Math.PI*(1-h.animT2/.32))*.9:0;
      if(!h.style.companion){shadow(ctx,h.x-9+lx,G,8);spr(ctx,'h_'+h.key+'_a',fa,h.x-9+lx-32,G-60,false,null,h.hitFlash);}
      shadow(ctx,h.x+9+lb,G,8);spr(ctx,'h_'+h.key+'_b',fb,h.x+9+lb-32,G-60,false,null,h.hitFlash);
      if(h.style.companion){const cx=h.x+(h.compX||-12),cy=h.compY||0;const pf=h.pounce?7:(g.scroll||Math.abs(h.compV||0)>4?Math.floor(g.t*10)%6:fa);
        shadow(ctx,cx,G+4,7);spr(ctx,'h_'+h.key+'_a',h.animT>0?fa:pf,cx-32,G-60+4-cy,(h.compV||0)<-4&&!h.animT,null,0);}
    }else if(UNITS[h.skin||h.key]&&UNITS[h.skin||h.key].idle){shadow(ctx,h.x+lx,G,9);const U=UNITS[h.skin||h.key],C=h.base.char;let A=U.idle,f=Math.floor(g.t*(h.key==='druid'?5:6))%A.n;
      const mov=h.moving||g.scroll;
      let riseRot=0,rum=null,runLean=0,runBob=0;
      // 0.12.22 getting back up: his last death frame, then the death frames played backwards (falling ones rotate back upright), then idle
      if(h.riseT>0&&U.death){const D=U.death,k=1-h.riseT/(h.riseT0||1.1);
        if(k>.86){A=U.idle;f=0;}
        else{A=D;const q=Math.max(0,(k-.18)/.68);f=Math.max(0,D.n-1-Math.floor(q*D.n));if(D.fall)riseRot=((h.face||1)>0?1.45:-1.45)*Math.pow(1-Math.min(1,q*1.15),1.4);}}
      else if(h.summonT>0&&U.summon){A=U.summon;f=Math.min(A.n-1,Math.floor((1-h.summonT/(h.summonT0||.8))*A.n));}   // Void_Cultist: arms raised, both hands glowing
      else if((h.building||h.repairing)&&U.kneel){A=U.kneel;f=Math.min(A.n-1,2+Math.floor(g.t*6)%Math.max(1,A.n-2));}   // 0.12.75 Engineer: kneeling, working
      else if(h.jet&&U.jet){A=U.jet;f=Math.floor(g.t*10)%A.n;}   // 0.12.67 Warhound: Tactical_Retreat (legs tucked, jets lit)
      else if(h.nano&&U.use){A=U.use;f=Math.floor(g.t*6)%A.n;}
      else if(h.useT>0&&h.key==='shoshi'&&U.use){A=U.use;f=Math.floor(g.t*8)%A.n;}   // 0.12.110 Shoshi on his phone   // Nano-Tech Repair Bots: kneeling, bots swirling
      else if(h.lz&&U.ranged){const C2=h.base.char.ranged.lazer;A=U.ranged;f=h.lz.t<C2.charge?(h.lz.t<C2.charge/2?0:1):2+Math.floor(g.t*10)%2;}   // Targeted Lazer: lens charges, then burns
      else if(h.gat&&U.ranged){A=U.ranged;f=Math.floor(g.t*24)%A.n;}   // Moss_Mech's gatling: barrels spinning, muzzle flashing
      else if(h.launchT>0&&U.missile){A=U.missile;f=Math.min(A.n-1,1+Math.floor(g.t*8)%3);}
      else if(h.wallT>0&&U.defend){A=U.defend;f=h.wallDrag>0?A.n-1-(Math.floor(g.t*8)%2):Math.min(A.n-1,2+Math.floor(g.t*4)%Math.max(1,A.n-2));}   /* 0.12.180 Crimson_Knight: Shield_Wall */
      else if(h.charge&&U.runatk){A=U.runatk;f=Math.floor(g.t*14)%A.n;}   /* Crimson_Charge */
      else if(h.kleap&&U.jump){A=U.jump;f=Math.min(A.n-1,Math.floor(h.kleap.t/.6*A.n));}   /* Leap_Strike */
      else if(h.key==='soldier'&&h.cast&&U.reload){A=U.reload;f=Math.min(A.n-1,Math.floor(h.cast.t/h.cast.T*A.n));}   /* 0.12.200 Ammo_Drop: his Recharge animation while he sets the crate down */
      else if(h.nstrip&&U.shot2){A=U.shot2;f=Math.floor(g.t*16)%A.n;}   /* 0.12.211 Edward's Nail_Strip */
      else if(h.supp&&U.shot2){A=U.shot2;f=Math.floor(g.t*16)%A.n;}   /* 0.12.199 Soldier: Suppressing_Fire (sighted-in stance, muzzle flashing) */
      else if(h.pshot&&U.shot2){A=U.shot2;f=Math.min(A.n-1,Math.floor(h.pshot.t/h.pshot.T*A.n));}   /* 0.12.178 Chibi_Archer: Piercing_Shot */
      else if(h.tumble&&U.jump){A=U.jump;f=Math.min(A.n-1,Math.floor(h.tumble.t/h.tumble.T*A.n));}   /* Tumble */
      else if(h.cast&&h.cast.anim&&U[h.cast.anim]){A=U[h.cast.anim];f=Math.min(A.n-1,Math.floor(h.cast.t/h.cast.T*A.n));}   /* Chibi_Sorcerer casting */
      else if(h.iaiA&&U.iai){const I=h.iaiA,H=.25;if(I.t<H){A=U.iai;f=Math.min(A.n-1,Math.floor(I.t/H*A.n));}else{A=U.draw||U.melee;f=Math.min(A.n-1,3+Math.floor((I.t-H)/.2*2));}}   /* 0.12.234 Cheez: Iaijutsu sheathe-hold then the draw */
      else if(h.sipT>0&&U.sake){A=U.sake;f=Math.floor(g.t*6)%A.n;}   /* Cheez: Sake_Break swig */
      else if(h.throwT>0&&U.throw){A=U.throw;f=Math.min(A.n-1,Math.floor((1-h.throwT/(h.throwT0||.45))*A.n));}
      else if(h.dash&&U.runatk){A=U.runatk;f=Math.min(A.n-1,3+Math.floor(h.dash.t/h.dash.T*2));}
      else if(h.animM>0){A=(h.swingAnim&&U[h.swingAnim])||U.melee;const D=h.swingAnim==='attack2'?.36:.45;f=Math.min(A.n-1,Math.floor((1-h.animM/D)*A.n));}
      else if(h.aimHold>0&&U.ranged){A=U.ranged;f=0;}   /* 0.12.163 holding the aim before the shot */
      else if(h.animR>0&&h.firedMoving&&!U.walkfire&&h.key==='edward'&&mov){A=(h.running&&U.run)||U.walk;f=Math.floor(g.t*(h.running?12:8))%A.n;}   /* 0.12.223 (Kyle): Edward fires on the move (no accuracy loss), so he keeps his walk/run legs going instead of sliding in the firing pose */
      else if(h.animR>0){A=(h.firedMoving&&U.walkfire)||U.ranged;f=Math.min(A.n-1,Math.floor((1-h.animR/(h.animRT||.5))*A.n));}
      else if((h.casting>0||h.animC>0)&&h.key==='druid'){A=U.ranged;f=1;}   // staff raised, tip glowing
      else if(h.volley>0&&U.ranged){A=U.ranged;f=Math.min(2,Math.floor((1-h.volley/(h.volleyT0||.6))*3));}   // draws and looses high
      else if(h.blowing>0&&U.blowgun){A=U.blowgun;f=Math.min(A.n-1,Math.floor((1-h.blowing/(h.blowT0||.7))*A.n));}
      else if(h.whirl&&U.spin){A=U.spin;f=Math.floor(g.t*16)%A.n;}
      else if(h.leap&&U.leap){A=U.leap;f=Math.min(A.n-1,Math.floor(h.leap.t/.6*A.n));}
      else if(h.rolling&&U.roll){A=U.roll;f=Math.min(A.n-1,Math.floor(h.rolling.t/.6*A.n));}
      else if(h.chopping>0&&U.chop){A=U.chop;f=Math.min(A.n-1,Math.floor((1-h.chopping/(h.chopT0||.5))*A.n));}
      else if(h.rageAnim>0&&U.rage){h.rageAnim-=1/60;A=U.rage;f=Math.min(A.n-1,Math.floor((1-h.rageAnim/.7)*A.n));}
      else if(h.camping>0&&U.kneel){A=U.kneel;f=Math.min(A.n-1,Math.floor((1-h.camping/(h.campT0||1.8))/.78*A.n));}   // kneel, flick the lighter
      else if(h.cast){A=U.ranged;f=0;}
      else if(h.tossing&&U[h.tossing.kind]){A=U[h.tossing.kind];f=Math.min(A.n-1,Math.floor(h.tossing.t/h.tossing.T*A.n));}   // 0.12.58 Proximity_Bomb toss / throw
      else if(h.setting){A=U.reload;f=Math.min(A.n-1,Math.floor(h.setting.t/h.setting.T*A.n));}   // kneels to set the Trip Bomb   // holding the aim during Aimed Shot's cast
      else if((h.search||h.planting)&&U.idle&&!(h.setting&&U.reload)){A=U.idle;f=Math.floor(g.t*3)%A.n;rum=h.search||{o:{x:h.planting.x},t:0};}   /* 0.12.37: rummaging (built from his idle frames, bent over and digging) */
      else if(h.hitFlash>0){A=U.hurt;f=Math.min(A.n-1,Math.floor((1-h.hitFlash/.12)*A.n));}
      else if(C&&C.ranged&&U.reload&&h.ammo<=0&&!mov){A=U.reload;f=Math.min(A.n-1,Math.floor((h.reloadT||0)/C.ranged.reload*A.n));}
      else if(mov){A=(h.running&&U.run)||U.walk;f=Math.floor(g.t*(h.running?12:h.key==='lumberjack'?9:8))%A.n;
        if(h.running&&!U.run&&A.n>1){f=Math.floor(g.t*15)%A.n;runLean=((h.face||1)>0?1:-1)*.06;runBob=-Math.abs(Math.sin(g.t*15*Math.PI*2/A.n))*.7;}}   /* 0.12.38: no run row (druid): her walk played fast, leaning into it with a bounce */
      const bob=(mov&&A.n===1?-Math.abs(Math.sin(g.t*11))*1.6:0)+runBob;if(runLean&&!riseRot)riseRot=runLean;   // one-frame walk (companion art has no walk row): a little hop
      if(h.whirl){ctx.save();const sp=g.t*16;   // 0.12.26: a wider slashing wave whips round him while he spins, so the reach reads
        ctx.globalCompositeOperation='lighter';
        for(let i=0;i<3;i++){const a0=sp+i*2.09;ctx.lineCap='round';
          ctx.strokeStyle='rgba(200,220,255,.30)';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(h.x+lx,G-11,26-i*2,7-i*.5,0,a0,a0+1.3);ctx.stroke();
          ctx.strokeStyle='rgba(255,255,255,.75)';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(h.x+lx,G-11,27-i*2,7.5-i*.5,0,a0+.2,a0+1.15);ctx.stroke();}
        ctx.strokeStyle='rgba(232,240,255,.45)';ctx.lineWidth=1.2;for(let i=0;i<2;i++){ctx.beginPath();ctx.ellipse(h.x+lx,G-10,16-i*3,5-i,0,sp*1.1+i*2,sp*1.1+i*2+2.2);ctx.stroke();}ctx.restore();}   // inner spin trail
      /* 0.12.107: the Shadow_Clone is drawn on its own now (drawClone) */
      if(rum){   /* rummage: dips down and digs (squash + lean toward the wreck), pops up, repeats; bits fly out where he digs */
        const ox=rum.o?rum.o.x+((OBST[rum.o.k]||{}).w||0)*.0:h.x+10;const dir=(rum.o&&rum.o.x<h.x-2)?-1:1;const ph=(g.t*2.3+(h.key.length*.37))%1;
        const dip=ph<.55?Math.sin(ph/.55*Math.PI):0;const jig=Math.sin(g.t*23)*.02*dip;const fx=h.x+lx;
        ctx.save();ctx.translate(fx,G);ctx.rotate(dir*(.1+.2*dip)+jig);ctx.scale(1+.03*dip,1-.13*dip);ctx.translate(-fx,-G);
        drawUnit(ctx,A,f,fx,G,A.pre?ART_SCALE/A.pre/HS:A.art?ART_SCALE/HS:(A.sc||1),null,h.hitFlash,0,(dir>0)!==!!A.faceR);ctx.restore();
        const seed=Math.floor(g.t*2.3+(h.key.length*.37));for(let i=0;i<4;i++){const q=((ph*1.6)+i*.17)%1;if(q>.8)continue;const r=Math.sin(seed*12.9+i*78.2)*43758.5%1;const rr=Math.abs(r);
          const bx=fx+dir*(9+q*10*(.6+rr)),by=G-4-Math.sin(q*Math.PI)*(8+6*rr);ctx.fillStyle=rum.disarm?(i%2?'#9ad0ff':'#e8e8e8'):(i%2?'#8a7a64':'#b8b8b8');ctx.globalAlpha=1-q;ctx.fillRect(Math.round(bx),Math.round(by),1.5,1.5);}ctx.globalAlpha=1;}
      else drawUnit(ctx,A,f,h.x+lx,G+bob-(h.leapH||0)*1.2-(A.fall&&riseRot?2*Math.abs(riseRot)/1.45:0),A.pre?ART_SCALE/A.pre/HS:A.art?ART_SCALE/HS:(A.sc||1),h.stealthT>0?.4+.08*Math.sin(g.t*5):null,h.hitFlash,riseRot,((h.face||1)>0)!==!!A.faceR);}   /* 0.12.128: Shoshi's sheet faces right, the others face left */   /* 0.12.67: stealthed = see-through, a faint shimmer */
    else{shadow(ctx,h.x+lx,G,9);spr(ctx,'h_'+h.key,fr,h.x+lx-32,G-60,h.face<0,null,h.hitFlash);}
    ctx.restore();
    if(h.gritT>0){const p=.5+.5*Math.sin(g.t*9),fa=Math.min(1,h.gritT/.5);ctx.save();ctx.globalCompositeOperation='lighter';ctx.strokeStyle=`rgba(230,175,90,${(.35+.3*p)*fa})`;ctx.lineWidth=1.5;ctx.beginPath();ctx.ellipse(Math.round(h.x+lx),G-24,13+p,26+p,0,0,7);ctx.stroke();
      ctx.fillStyle=`rgba(255,215,140,${.8*fa})`;for(let i=0;i<4;i++){const an=g.t*3+i*1.57;ctx.fillRect(Math.round(h.x+lx+Math.cos(an)*13),Math.round(G-24+Math.sin(an)*24),1.5,1.5);}ctx.restore();}   // Grit_Teeth: a steady amber brace around him
    if(h.shield>0){ctx.strokeStyle=h.staticT>0?'rgba(255,230,90,.75)':'rgba(154,230,255,.7)';ctx.beginPath();ctx.ellipse(Math.round(h.x+lx),G-24,15,27,0,0,7);ctx.stroke();
      if(h.staticT>0){ctx.save();ctx.globalCompositeOperation='lighter';ctx.strokeStyle='rgba(255,240,140,.9)';ctx.lineWidth=.6;for(let i=0;i<3;i++){const a=g.t*7+i*2.1+Math.sin(g.t*31+i)*.6,x0=h.x+lx+Math.cos(a)*15,y0=G-24+Math.sin(a)*27;ctx.beginPath();ctx.moveTo(x0,y0);ctx.lineTo(x0+Math.sin(g.t*40+i)*3,y0+2.5);ctx.lineTo(x0+1.5,y0+5);ctx.stroke();}ctx.restore();}}   /* 0.12.195 Static_Shield: yellow, crackling */
    if(h.ocN>0){ctx.save();ctx.globalCompositeOperation='lighter';const hx2=h.x+lx+(h.face||1)*4,hy2=G-16;glow(ctx,hx2,hy2,5+Math.sin(g.t*20),'#ffe04a',.55);ctx.fillStyle='#fffbe0';for(let i=0;i<h.ocN;i++){const a=g.t*9+i*2.1;ctx.fillRect(Math.round(hx2+Math.cos(a)*4),Math.round(hy2+Math.sin(a)*4),1,1);}ctx.restore();}   /* Overcharge: crackling hands, one orbiting spark per charged shot */
    const bx=h.x+(h.dodgeX||0)+(h.wanderX||0),G0=G;{const G=G0-(h.leapH||0)*1.2*HS;if(!h.ghost)plate(ctx,h,bx,G-(hbOf(h).h+17),22,true);   /* 0.12.75: the plate rides up with a hero on the lookout or a jetpack */
    {const cb=castBar(h);if(cb&&!PLATE_OFF){const w=18,x=Math.round(bx-w/2),y=Math.round(G-(hbOf(h).h+17))+6;const k=Math.max(0,Math.min(1,cb[0]));   /* 0.12.71: cast / channel / reload bar under the plate */
      ctx.fillStyle='#120a14';ctx.fillRect(x-1,y-1,w+2,3);ctx.fillStyle='#2a2430';ctx.fillRect(x,y,w,1);ctx.fillStyle=cb[1];ctx.fillRect(x,y,Math.max(1,Math.round(w*k)),1);
      if(cb[2]){ctx.fillStyle='#ffffff';ctx.globalAlpha=.55+.45*Math.sin(g.t*12);ctx.fillRect(x+Math.round(w*k)-1,y,1,1);ctx.globalAlpha=1;}}}}};
  // enemies
  // depth lanes: each enemy stands a few px nearer/farther; small creatures take the front lanes; back lanes draw first
  for(const e of g.enemies)if(e.lane==null){const a=SP['e_'+e.type];e.lane=e.boss||e.fly?0:UNITS[e.type]?Math.floor(Math.random()*6):(a&&FH(a)<64?5+Math.floor(Math.random()*4):Math.floor(Math.random()*5));}
  const es=g.enemies.filter(e=>!e.dead).sort((a,b)=>a.lane-b.lane||b.x-a.x);
  const drawEnemy=(e)=>{if(e.inside!=null)return;const G0=(e.gy!=null&&!e.fly&&!e.boss)?e.gy:g.G;ctx.save();if(e.emergeT>0){const k=1-e.emergeT/.5;ctx.filter=`brightness(${(.12+.88*k).toFixed(2)})`;ctx.globalAlpha=.45+.55*k;}shrinkAt(ctx,e.x,G0,HS);drawEnemy0(e);ctx.restore();};   /* 0.12.130: out of a dark doorway: starts as a shadow, brightens to normal */
  const drawEnemy0=(e)=>{const G=(e.gy!=null&&!e.fly&&!e.boss)?e.gy:g.G;let fr=e.animT>0?6+Math.min(2,Math.floor((.3-e.animT)/.1)):e.hitFlash>0&&!e.boss?9:Math.floor(e.walkT*8)%6;
    if(e.boss&&(e.type==='harvest'||e.type==='wraith')&&ATLAS[e.type]){const H=ATLAS[e.type],A=e.act,W=e.type==='wraith';let nm,fr;   /* 0.12.127 the Harvest Knight's own animations */
      if(A){nm=A.name;const N=H[nm].n;fr=Math.min(N-1,Math.floor(A.t/A.T*N));}else if(e.hitFlash>0){nm='hurt';fr=0;}else{const mov=e.x>(e._px==null?e.x:e._px)+.01||e.x<(e._px==null?e.x:e._px)-.01;nm=mov?(W?'drift':'walk'):(e.phase&&!W?'enraged':'idle');fr=Math.floor(g.t*(mov?9:7))%H[nm].n;}
      e._px=e.x;const a=H[nm];shadow(ctx,e.x,G,W?22:30);drawUnit(ctx,Object.assign({},a,{img:e.type}),fr,e.x,G-(W?6+Math.sin(g.t*2)*3:0),.95,null,e.hitFlash,0,true);return;}   /* the wraith floats */
    if(e.type==='bat'&&ATLAS.bat){const B=ATLAS.bat;const a=e.swoop?B.swoop:e.hitFlash>0?B.hurt:B.fly;const f=a===B.fly?Math.floor(g.t*12+e.phase)%a.n:0;shadow(ctx,e.x,e.gy||g.G,6);drawUnit(ctx,a,f,e.x,e.y,1,null,e.hitFlash,0,(e.face||-1)>0);if(e.hp<e.max)plate(ctx,e,e.x,e.y-16,12,false,'#e8303a');return;}   /* 0.12.206 Giant_Bat */
    if(e.boss){const bf=e.animT>0?2:Math.floor(g.t*2)%2;const y=e.fly?e.y-90:G-124;shadow(ctx,e.x,G,26);spr(ctx,'b_'+e.type,bf,e.x-64,y,false,null,e.hitFlash);return;}
    if(UNITS[e.skin||e.type]){const U=UNITS[e.skin||e.type];const [A,uf]=unitFrame(e,U);const gy=e.gy!=null?G:G+e.lane;const sc=(e.E.scale||1)*(e.elite?1.1:1)*(e.nem?(1.12+.1*e.nem.rank)*(e.nem.size||1):1);shadow(ctx,e.x,gy,8);if(e.nem){glow(ctx,e.x,gy-10,10+e.nem.rank*2,e.nem.col||'#ff2a1a',.16+.04*Math.sin(g.t*4));}   /* 0.12.136 Nemesis: bigger with a red glow */
      const dsc=A.pre?sc/A.pre:sc;drawUnit(ctx,A,uf,e.x,gy,dsc,null,e.hitFlash,0,(e.face>0)!==!!A.faceR);const y=gy-U.walk.ay*(U.walk.pre?sc/U.walk.pre:sc);   /* pre-shrunk art (zombies) is drawn 1:1 */
      if(e.slow>0){ctx.fillStyle='rgba(154,230,255,.8)';for(let i=0;i<3;i++)ctx.fillRect(Math.round(e.x-6+i*5),Math.round(y+8+((g.t*20+i*7)%20)),1,1);}
      if(e.burnT>0){ctx.fillStyle=Math.random()<.5?'#ffb040':'#ff5a1a';ctx.fillRect(Math.round(e.x-3+Math.random()*6),Math.round(y+10+Math.random()*12),1,2);}
      if(e.nem||e.hp<e.max||e.bleedT>0||e.burnT>0||e.slow>0||e.stun>0)plate(ctx,e,e.x,y-2,e.nem?24:e.elite?20:14,false,e.nem?'#ff4a3a':e.elite?'#ffb020':'#e8303a');
      if(e.nem){ctx.save();ctx.font='bold 7px monospace';ctx.textAlign='center';const nm=e.nem.name+' '+'★'.repeat(e.nem.rank);ctx.fillStyle='#000';ctx.fillText(nm,e.x+.8,y-7.2);ctx.fillStyle=e.nem.col||'#ff6a4a';ctx.fillText(nm,e.x,y-8);ctx.restore();}
      if(e.distractT>0){ctx.fillStyle='#e8fff0';ctx.font='bold 6px monospace';ctx.textAlign='center';ctx.fillText('?',Math.round(e.x),Math.round(y-12-Math.abs(Math.sin(g.t*6))*1.5));}   // 0.12.68: off to check the noise
      if(e.rootT>0&&!e.boss){const fx0=Math.round(e.x),fy0=Math.round(gy);ctx.strokeStyle='#4a7a2a';ctx.lineWidth=1;for(let i=0;i<4;i++){const sx=fx0-5+i*3.3;ctx.beginPath();ctx.moveTo(sx,fy0+1);ctx.quadraticCurveTo(sx+(i%2?3:-3),fy0-4-i%2*2,sx+(i%2?-1:1),fy0-7);ctx.stroke();}ctx.fillStyle='#8a6a40';ctx.fillRect(fx0-1,fy0-6,2,6);ctx.fillStyle='#e8e0c8';ctx.fillRect(fx0-1,fy0-7,2,1);}   /* 0.12.195 Snare_Arrow: the arrow pinned at his feet, vines tangled round his legs */
      if(e.markT>0){const my=y-9,p=.5+.5*Math.sin(g.t*10);ctx.strokeStyle=`rgba(255,70,60,${.6+.4*p})`;ctx.lineWidth=1;ctx.strokeRect(Math.round(e.x)-3.5,Math.round(my)-3.5,7,7);ctx.fillStyle='#ff4a3a';ctx.fillRect(Math.round(e.x)-.5,Math.round(my)-.5,1,1);}   // Pinning_Shot mark
      return;}
    const n='e_'+e.type,a=SP[n];const big=FH(a)===64;
    const y=e.fly?e.y-FH(a)/2:G-(big?60:44)+e.lane;if(!e.fly)shadow(ctx,e.x,G+e.lane,big?8:7);
    if(e.elite){ctx.save();ctx.translate(e.x,y+FH(a));ctx.scale(1.22,1.22);spr(ctx,n,fr,-FW(a)/2,-FH(a),false,null,e.hitFlash);ctx.restore();}
    else spr(ctx,n,fr,e.x-FW(a)/2,y,false,null,e.hitFlash);
    if(e.slow>0){ctx.fillStyle='rgba(154,230,255,.8)';for(let i=0;i<3;i++)ctx.fillRect(Math.round(e.x-6+i*5),Math.round(y+8+((g.t*20+i*7)%20)),1,1);}
    if(e.burnT>0){ctx.fillStyle=Math.random()<.5?'#ffb040':'#ff5a1a';ctx.fillRect(Math.round(e.x-3+Math.random()*6),Math.round(y+10+Math.random()*12),1,2);}
    if(e.hp<e.max||e.bleedT>0||e.burnT>0||e.slow>0||e.stun>0)plate(ctx,e,e.x,y-2,e.elite?20:14,false,e.elite?'#ffb020':'#e8303a');};
  // draw heroes and enemies back-to-front by lane so units in the far lane sit behind the near ones
  /* 0.12.119 (Kyle) lootable storefronts, drawn over their building's own shop front. Lootable: a gold glint at the door and an alarm
     bell box over it. Looted: the door kicked in, glass and stock spilled on the sidewalk. Ringing: NOT the car's flashing lights but a
     rotating red beacon on the bell throwing a sweeping beam, the window strobing white in double flashes, and the bell shaking. */
  /* 0.12.121 (Kyle) lootable storefronts: a full shop front laid over its building's ground floor (same height as before): a lit sign
     naming the shop, two big display windows with stock on the shelves, a centre door, an alarm bell. Units walk through it; only the two
     pillars out front (their own obstacles, drawn in front of lane-0 units) block. Looted: dark, glass smashed, door kicked in, stock spilled.
     Ringing: a rotating red beacon on the bell sweeping the street, the windows strobing white in double flashes, the bell shaking. */
  const SIGNF={D:'110101101101110',I:'111010010010111',L:'100100100100111',Q:'010101101111011',T:'111010010010010',U:'101101101101111',A:'010101111101101',B:'110101110101110',C:'011100100100011',E:'111100110100111',G:'011100101101011',H:'101101111101101',K:'101101110101101',M:'101111111101101',N:'110101101101101',O:'010101101101010',P:'110101110100100',R:'110101110101101',W:'101101101111101',Y:'101101010010010',' ':'000000000000000'};
  const SHOPS={grocery:{t:'GROCERY',c:'#ffb84a',goods:['#a83c32','#c8a046','#46708c','#7a7a86','#5a9a46']},pharmacy:{t:'PHARMACY',c:'#5ae08a',goods:['#e0e0e0','#c89a46','#5a8cb0','#e0e0e0']},
    pawn:{t:'PAWN',c:'#7fb8ff',goods:['#c8c8d0','#b08a40','#8a5a3a','#5a6a7a']},hardware:{t:'HARDWARE',c:'#ff8a3a',goods:['#c86a2a','#8a8a96','#c8c040','#5a6a7a']},deli:{t:'DELI',c:'#ff7a9a',goods:['#c86a6a','#e8d0a0','#a0c060','#c8a046']},liquor:{t:'LIQUOR',c:'#b88aff',goods:['#5a8a5a','#a87a40','#c8c8d0','#7a4a8a']},bank:{t:'BANK',c:'#ffd23f',goods:['#ffd23f','#c8b060']}};
  const hsh=n=>{const v=Math.sin(n*12.9898)*43758.5453;return v-Math.floor(v);};
  const drawFront=o=>{const L=(BGA.city&&BGA.city.layers.find(l=>l.shops));if(!L)return;const s=L.w/L.r[2];const fy=L.y+L.front*s,gy=L.y+L.ground*s,x=Math.round(o.x*2)/2;
    const S=SHOPS[o.shop]||SHOPS.grocery,hw=Math.max(14,(o.bw||36)/2-1),top=fy-7,lt=!o.looted,ring=o.alarmT>0,pu=.5+.5*Math.sin(g.t*3.2+o.x*.05);ctx.save();
    // wall + cornice + sign board
    ctx.fillStyle='#1a2332';ctx.fillRect(x-hw,top,hw*2,gy-top);ctx.fillStyle='#34445c';ctx.fillRect(x-hw,top,hw*2,.8);ctx.fillRect(x-hw,top+6.2,hw*2,1);
    ctx.fillStyle='#0b1018';ctx.fillRect(x-hw+2,top+1.2,hw*2-4,4.6);
    const tx=S.t,sc=.8,tw=tx.length*4*sc-sc;let sx=x-tw/2;ctx.fillStyle=lt?S.c:'#3a4656';
    for(const ch of tx){const gl=SIGNF[ch]||SIGNF[' '];for(let k=0;k<15;k++)if(gl[k]==='1'&&!(o.looted&&hsh(o.x+k+ch.charCodeAt(0))<.3))ctx.fillRect(sx+(k%3)*sc,top+1.6+Math.floor(k/3)*sc,sc,sc);sx+=4*sc;}
    if(lt)glow(ctx,x,top+3.5,Math.min(hw,tw/2+4),S.c,.12+.08*pu);
    // two big display windows either side of the door
    const wy0=top+8,wy1=gy-2.5;
    for(const sd of [-1,1]){const x0=sd<0?x-hw+2.5:x+4.5,x1=sd<0?x-4.5:x+hw-2.5,ww=x1-x0;
      ctx.fillStyle='#3e4e66';ctx.fillRect(x0-.6,wy0-.6,ww+1.2,wy1-wy0+1.2);
      if(lt){const gr=ctx.createLinearGradient(0,wy0,0,wy1);gr.addColorStop(0,'#3a2c1c');gr.addColorStop(1,'#7a5a30');ctx.fillStyle=gr;}else ctx.fillStyle='#06090e';ctx.fillRect(x0,wy0,ww,wy1-wy0);
      for(let sh=wy0+3.5;sh<wy1;sh+=3.5){ctx.fillStyle=lt?'#2a2016':'#141a22';ctx.fillRect(x0,sh,ww,.5);   // shelves and stock
        for(let gx=x0+.5;gx<x1-.5;gx+=1.2){const h=hsh(o.x*7+gx*3+sh);if(h<(lt?.75:.25)){ctx.fillStyle=S.goods[Math.floor(h*97)%S.goods.length];ctx.globalAlpha=lt?1:.5;ctx.fillRect(gx,sh-1.4,.8,1.4);ctx.globalAlpha=1;}}}
      if(lt){ctx.globalAlpha=.22;ctx.fillStyle='#e8f4ff';ctx.beginPath();ctx.moveTo(x0+ww*.15,wy0);ctx.lineTo(x0+ww*.35,wy0);ctx.lineTo(x0+ww*.1,wy1);ctx.lineTo(x0-.01,wy1);ctx.fill();ctx.fillRect(x0+ww*.55,wy0,.6,wy1-wy0);ctx.globalAlpha=1;}
      else{ctx.fillStyle='#7aa8d0';for(let k=0;k<6;k++){const h=hsh(o.x+k*5+sd);ctx.fillRect(x0+h*ww,k%2?wy0:wy1-.8,.6,.8);}}
      ctx.fillStyle='#3e4e66';ctx.fillRect(x0+ww/2-.3,wy0,.6,wy1-wy0);}
    // door
    ctx.fillStyle='#3e4e66';ctx.fillRect(x-4,wy0-1,8,gy-wy0+1);
    if(lt){ctx.fillStyle='#ffcf7a';ctx.fillRect(x-3,wy0,6,gy-wy0);ctx.fillStyle='#ffe8b8';ctx.fillRect(x-1.5,wy0+1,3,gy-wy0-2);ctx.fillStyle='#3e4e66';ctx.fillRect(x-.25,wy0,.5,gy-wy0);
      ctx.globalCompositeOperation='lighter';ctx.globalAlpha=.5;const lg=ctx.createRadialGradient(x,gy,1,x,gy,24);lg.addColorStop(0,'rgba(255,200,110,.7)');lg.addColorStop(1,'rgba(255,200,110,0)');ctx.fillStyle=lg;ctx.fillRect(x-26,gy-12,52,20);ctx.globalCompositeOperation='source-over';ctx.globalAlpha=1;}
    else{ctx.fillStyle='#04070b';ctx.fillRect(x-3,wy0,6,gy-wy0);ctx.fillStyle='#2a3a4c';ctx.beginPath();ctx.moveTo(x-3,wy0);ctx.lineTo(x-7,wy0+2);ctx.lineTo(x-7,gy+1);ctx.lineTo(x-3,gy);ctx.fill();
      for(let i=0;i<12;i++){ctx.fillStyle=S.goods[i%S.goods.length];ctx.fillRect(x-hw+2+hsh(o.x+i)*(hw*2-4),gy+.5+hsh(o.x*3+i)*2,i%3?.6:1,.6);}}
    // 0.12.122 rooftop: a parapet slab across the top, a ladder up the right side, maybe a crate up there
    if(o.roof){const R=o.roof,ry=R.y;ctx.fillStyle='#2c3a50';ctx.fillRect(x-hw-1,ry-1.5,hw*2+2,2.2);ctx.fillStyle='#5e7090';ctx.fillRect(x-hw-1,ry-1.5,hw*2+2,.6);
      // 0.12.127 (Kyle): the roof door: a dark recessed doorway in the middle of the wall above the roof, where zombies step out
      ctx.fillStyle='#3e4e66';ctx.fillRect(x-4,ry-15,8,14);ctx.fillStyle='#26324a';ctx.fillRect(x-3.4,ry-14.4,6.8,13.4);ctx.fillStyle='#020304';ctx.fillRect(x-2.6,ry-13.6,5.2,12.6);
      ctx.fillStyle='#5e7090';ctx.fillRect(x-4.4,ry-15.6,8.8,.8);if(R.doorT>0){ctx.globalAlpha=Math.min(1,R.doorT*2);ctx.fillStyle='#ff4030';ctx.fillRect(x-1.2,ry-10,.6,.6);ctx.fillRect(x+.6,ry-10,.6,.6);ctx.globalAlpha=1;}
      const lx=x+hw+1.5,ly=LANES[0]+1;ctx.fillStyle='#6a5a48';ctx.fillRect(lx-1.6,ry-3,.6,ly-ry+3);ctx.fillRect(lx+1,ry-3,.6,ly-ry+3);for(let y=ry-1;y<ly;y+=2.4)ctx.fillRect(lx-1.6,y,3.2,.5);
      if(R.crate||R.crateDone){const D=OBST.city_crate;drawUnit(ctx,{fw:D.fw,fh:D.fh,n:1,ax:D.fw/2,ay:D.fh-1,x:D.x,y:D.y,img:'cityob'},R.crateDone?1:0,x-hw*.55,ry-1,.45,null,0,0,false);
        if(R.crate&&(g.t*.9+o.x*.02)%2<.2){const f=((g.t*.9+o.x*.02)%2)/.2;ctx.globalAlpha=Math.sin(f*3.14);ctx.fillStyle='#fff6c0';const sx=x-hw*.55+2,sy=ry-9;ctx.fillRect(sx-1.5,sy,3,.5);ctx.fillRect(sx-.25,sy-1.25,.5,3);ctx.globalAlpha=1;}}}
    // loot bag over the door while it's still lootable
    if(lt){const iy=top-6+Math.sin(g.t*3+o.x)*1.2;ctx.fillStyle='#1a1208';ctx.beginPath();ctx.arc(x,iy+1.6,3.2,0,7);ctx.fill();ctx.fillStyle=S.c;ctx.beginPath();ctx.arc(x,iy+1.6,2.5,0,7);ctx.fill();ctx.fillRect(x-1,iy-2.2,2,1.6);
      ctx.fillStyle='#1a1208';ctx.fillRect(x-1.5,iy-.8,3,.6);ctx.fillStyle='#fff6d0';ctx.fillRect(x-1.4,iy+.6,.8,.8);glow(ctx,x,iy+1.6,6,S.c,.18*(.6+.4*pu));}
    // alarm bell on the sign's corner
    const bx=x+hw-3,by=top+1,sh=ring?Math.sin(g.t*70)*.35:0;
    ctx.fillStyle='#1c1c22';ctx.fillRect(bx-2+sh,by-1,4,2.5);ctx.fillStyle=ring?'#ff3a2e':'#8a2420';ctx.beginPath();ctx.arc(bx+sh,by-1,1.6,Math.PI,0);ctx.fill();
    if(ring){const a=g.t*5.5;ctx.globalCompositeOperation='lighter';const dx=Math.cos(a),vis=Math.max(0,Math.sin(a)*.5+.5),len=70;ctx.globalAlpha=.32*vis+.06;
      const gr=ctx.createLinearGradient(bx,by,bx+dx*len,by+18);gr.addColorStop(0,'rgba(255,40,30,.9)');gr.addColorStop(1,'rgba(255,40,30,0)');ctx.fillStyle=gr;ctx.beginPath();ctx.moveTo(bx,by-1);ctx.lineTo(bx+dx*len,by+6);ctx.lineTo(bx+dx*len,by+26);ctx.closePath();ctx.fill();
      ctx.globalAlpha=.55+.45*vis;glow(ctx,bx,by-1,4.5,'#ff2a1a',.5);glow(ctx,bx,by-1,1.4,'#ffd0c0',.9);
      const ph=(g.t*1.3+o.x*.01)%1;if(ph<.05||(ph>.1&&ph<.15)){ctx.globalAlpha=.5;ctx.fillStyle='#e8f4ff';ctx.fillRect(x-hw+2.5,wy0,hw*2-5,wy1-wy0);ctx.globalAlpha=.25;glow(ctx,x,wy0+6,hw+6,'#d8ecff',.25);}
      ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';}
    ctx.restore();};
  // the storefront's two pillars: stone columns from the sidewalk up to the cornice, in front of lane-0 units
  const drawPillar=o=>{const L=(BGA.city&&BGA.city.layers.find(l=>l.shops));if(!L)return;const s=L.w/L.r[2];const top=L.y+L.front*s-7,gy=LANES[0]+1,x=Math.round(o.x*2)/2;ctx.save();
    /* 0.12.122 (Kyle): a waist-high wall along the front edge of the roof, drawn in front of whoever is up there (low enough that the crate shows over it) */
    if(o.sd>0&&o.F&&o.F.roof){const F=o.F,R=F.roof,fx=Math.round(F.x*2)/2,hw=Math.max(14,(F.bw||36)/2-1),ry=R.y;ctx.fillStyle='#2c3a50';ctx.fillRect(fx-hw-1,ry-6.5,hw*2+2,7.2);
      ctx.fillStyle='#5e7090';ctx.fillRect(fx-hw-1.4,ry-7,hw*2+2.8,1);ctx.fillStyle='#202a3a';for(let yy=ry-4.5;yy<ry;yy+=2.2)ctx.fillRect(fx-hw-1,yy,hw*2+2,.4);
      for(let k=fx-hw;k<fx+hw;k+=4)ctx.fillRect(k+((Math.round(k)%8)?2:0),ry-6,.4,6);ctx.fillStyle='#3a4a62';ctx.fillRect(fx-hw-1,ry-6,.6,6.6);}
    shadow(ctx,x,gy,3);ctx.fillStyle='#2a3444';ctx.fillRect(x-2.6,top-1,5.2,2.2);ctx.fillRect(x-2.6,gy-2.2,5.2,2.2);
    ctx.fillStyle='#4a5a72';ctx.fillRect(x-1.7,top+1,3.4,gy-top-3);ctx.fillStyle='#7a8ca6';ctx.fillRect(x-1.7,top+1,.8,gy-top-3);ctx.fillStyle='#26303f';ctx.fillRect(x+1,top+1,.7,gy-top-3);
    ctx.fillStyle='#5e7090';ctx.fillRect(x-2.6,top-1,5.2,.6);ctx.fillStyle='#1e2632';for(let y=top+5;y<gy-4;y+=5)ctx.fillRect(x-1.7,y,3.4,.4);ctx.restore();};
  const drawOb=o=>{const D=OBST[o.k];if(D.front)return drawFront(o);if(D.pillar)return drawPillar(o);const gy=LANES[Math.max(...o.lanes)];ctx.save();if(!D.flat)shadow(ctx,o.x,gy,Math.max(5,D.fw*.22));drawUnit(ctx,{fw:D.fw,fh:D.fh,n:1,ax:D.fw/2,ay:D.fh-(D.flat?6:1),x:D.x,y:D.y,img:D.img||'obst'},D.open&&o.looted?1:0,o.x,gy+1,.5,null,0,0,!!o.flip);if(o.k==='city_lootbox'&&!o.looted&&(g.t*.7+o.x*.01)%2<.18){const f=((g.t*.7+o.x*.01)%2)/.18;ctx.globalAlpha=Math.sin(f*3.14);ctx.fillStyle='#fff6c0';const sx=o.x-3+(o.x%5),sy=gy-8;ctx.fillRect(sx-1.5,sy,3,.5);ctx.fillRect(sx-.25,sy-1.25,.5,3);ctx.globalAlpha=1;}
    if(o.alarmT>0&&D.lights){const on=Math.floor(o.alarmT*6)%2===0,fl=o.flip?-1:1;ctx.globalCompositeOperation='lighter';   /* 0.12.74 (Kyle): the car's own head- and taillights flash, throwing light rays */
      const P=([lx,ly])=>[o.x+(lx-D.fw/2)*.5*fl,gy+1+(ly-(D.fh-1))*.5];
      if(D.lights.head){const [x,y]=P(D.lights.head),d=-fl;if(on){glow(ctx,x,y,2.6,'#fff4c0',.85);glow(ctx,x,y,1,'#ffffff',1);
          const gr=ctx.createLinearGradient(x,y,x+d*46,y);gr.addColorStop(0,'rgba(255,240,180,.45)');gr.addColorStop(1,'rgba(255,240,180,0)');ctx.fillStyle=gr;ctx.beginPath();ctx.moveTo(x,y-.8);ctx.lineTo(x+d*46,y-9);ctx.lineTo(x+d*46,y+5);ctx.lineTo(x,y+.8);ctx.fill();
          for(let i=-2;i<=2;i++){ctx.strokeStyle='rgba(255,250,220,.35)';ctx.lineWidth=.4;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+d*(14+Math.abs(i)*2),y+i*3);ctx.stroke();}}}
      if(D.lights.tail){const [x,y]=P(D.lights.tail),d=fl;const k=on?1:.25;glow(ctx,x,y,3*k+.6,'#ff2a1a',.7*k);glow(ctx,x,y,.9,'#ffb0a0',k);
        if(on)for(let i=-2;i<=2;i++){ctx.strokeStyle='rgba(255,60,40,.4)';ctx.lineWidth=.45;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+d*(10+Math.abs(i)*2),y+i*2.6);ctx.stroke();}}
      ctx.globalCompositeOperation='source-over';}/* car alarm: flashing lights */ctx.restore();};
  /* 0.12.75 Engineer's buildings, drawn from shapes: the watchtower (steel legs, X braces, chain-link panels, plank floors with low walls,
     a ladder up the whole thing and a sign per tier), the concrete barrier, the tesla coil and the car turret */
  /* 0.12.265 (Kyle): a metal guard railing on every tower floor, drawn IN FRONT of whoever is standing up there (like the shop pillars) */
  const drawTowerRail=b=>{const x=Math.round(b.x),gy=b.gy,W=9.5,TH=30;ctx.save();if(b.hitT>0)ctx.globalAlpha=.75;
    for(let i=0;i<b.tier;i++){const fy=gy-TH*(i+1),L=x-W-3,Rr=x+W+3;
      ctx.fillStyle='#5c6470';for(let px=L;px<=Rr;px+=3.2)ctx.fillRect(Math.round(px*2)/2,fy-8,.8,8);   // balusters
      ctx.fillStyle='#7d8794';ctx.fillRect(L-.5,fy-8.5,Rr-L+1.5,1.4);ctx.fillStyle='#b8c2ce';ctx.fillRect(L-.5,fy-8.5,Rr-L+1.5,.5);   // top rail with a shine
      ctx.fillStyle='#6a7380';ctx.fillRect(L,fy-4.4,Rr-L+.8,.9);   // mid rail
      ctx.fillStyle='#4a515c';ctx.fillRect(L-1,fy-9,1.6,9);ctx.fillRect(Rr-.6,fy-9,1.6,9);}   // corner posts
    ctx.restore();};
  const drawBld=b=>{const x=Math.round(b.x),gy=b.gy;ctx.save();if(b.hitT>0){ctx.globalAlpha=.75;}
    if(b.k==='tower'){const W=9.5,TH=30;const top=gy-TH*b.tier;   /* 0.12.76: about 45% as wide as before */
      shadow(ctx,x,gy,11);
      for(let i=0;i<b.tier;i++){const y0=gy-TH*i,y1=y0-TH;
        ctx.strokeStyle='rgba(170,180,190,.35)';ctx.lineWidth=.4;   // chain-link: diamond lattice on the lower part of each tier
        ctx.save();ctx.beginPath();ctx.rect(x-W,y0-14,2*W,14);ctx.clip();for(let k=-W-12;k<=W+12;k+=2.5){ctx.beginPath();ctx.moveTo(x+k,y0-1);ctx.lineTo(x+k+12,y0-13);ctx.stroke();ctx.beginPath();ctx.moveTo(x+k,y0-1);ctx.lineTo(x+k-12,y0-13);ctx.stroke();}ctx.restore();
        ctx.fillStyle='#4a5058';ctx.fillRect(x-W-1,y0-14,2*W+2,1);
        ctx.strokeStyle='#6a7280';ctx.lineWidth=1.1;ctx.beginPath();ctx.moveTo(x-W+2,y0);ctx.lineTo(x+W-2,y1+2);ctx.moveTo(x+W-2,y0);ctx.lineTo(x-W+2,y1+2);ctx.stroke();   // X brace
        ctx.fillStyle='#6a4a2a';ctx.fillRect(x-W-3,y1,2*W+6,2.5);ctx.fillStyle='#8a6438';ctx.fillRect(x-W-3,y1,2*W+6,1);   // plank floor
        ctx.save();ctx.translate(x-4.2,y0-23);ctx.scale(.7,.7);ctx.translate(-(x-6),-(y0-24));const sx=x-6,sy=y0-24;ctx.fillStyle='#1a1410';ctx.fillRect(sx-1,sy-1,14,10);   // the tier's sign (smaller now)
        if(i===0){ctx.fillStyle='#f2f2ea';ctx.fillRect(sx,sy,12,8);ctx.fillStyle='#d0202a';ctx.fillRect(sx+5,sy+1,2,6);ctx.fillRect(sx+3,sy+3,6,2);}
        else if(i===1){ctx.fillStyle='#4a5a2a';ctx.fillRect(sx,sy,12,8);ctx.fillStyle='#d8b040';for(let q=0;q<3;q++){ctx.fillRect(sx+2+q*3,sy+2,2,5);ctx.fillStyle='#b08020';ctx.fillRect(sx+2+q*3,sy+2,2,1);ctx.fillStyle='#d8b040';}}
        else{ctx.fillStyle='#2a3a5a';ctx.fillRect(sx,sy,12,8);ctx.fillStyle='#9ad0ff';ctx.beginPath();ctx.arc(sx+4,sy+4,2,0,7);ctx.arc(sx+8,sy+4,2,0,7);ctx.fill();ctx.fillStyle='#1a1410';ctx.fillRect(sx+5.5,sy+3,1,2);}ctx.restore();}
      ctx.fillStyle='#5a626e';ctx.fillRect(x-W,top,2.2,gy-top);ctx.fillRect(x+W-2.2,top,2.2,gy-top);ctx.fillStyle='#8a94a2';ctx.fillRect(x-W,top,.8,gy-top);ctx.fillRect(x+W-2.2,top,.8,gy-top);   // steel legs
      ctx.fillStyle='#7a5a34';ctx.fillRect(x+W+3,top-2,1,gy-top+2);ctx.fillRect(x+W+7,top-2,1,gy-top+2);for(let y=gy-2;y>top;y-=3)ctx.fillRect(x+W+3,y,5,.8);   // ladder all the way up
      if(b.tier>=3){ctx.fillStyle='#3a3f48';ctx.fillRect(x-W-3,top-14,2,9);ctx.fillRect(x+W+1,top-14,2,9);ctx.fillStyle='#6a4a2a';ctx.fillRect(x-W-4,top-15,2*W+8,2);}   // lookout roof
      if(b.hp<b.max){const w=20;ctx.fillStyle='#000a';ctx.fillRect(x-w/2-1,top-20,w+2,3);ctx.fillStyle='#ffd23f';ctx.fillRect(x-w/2,top-19,w*Math.max(0,b.hp/b.max),1);}}
    else if(b.k==='sandbag'){shadow(ctx,x,gy,12);   /* 0.12.104 Sandbag Wall: a low, wide pile of burlap bags, staggered like bricks (shorter and wider than a HESCO cell) */
      const rows=[[-9,-3,3,9],[-6,0,6],[-3,3]];const bw=6.4,bh=3.6;
      rows.forEach((r,ri)=>{const yy=gy-bh*(ri+1)+ri*.6;for(const dx of r){const cx=x+dx;ctx.fillStyle=ri%2?'#b89c68':'#a88c5a';ctx.beginPath();ctx.ellipse(cx,yy+bh/2,bw/2,bh/2,0,0,Math.PI*2);ctx.fill();
        ctx.fillStyle='rgba(255,240,200,.25)';ctx.fillRect(cx-bw/2+1,yy+.5,bw-3,.7);ctx.fillStyle='rgba(60,40,20,.45)';ctx.fillRect(cx+bw/2-1.2,yy+1,.6,bh-1.5);   /* lit top edge, tied-off end */
        if(b.A&&b.A.barb){ctx.strokeStyle='rgba(70,70,74,.9)';ctx.lineWidth=.4;}}});
      if(b.A&&b.A.barb){const T=gy-bh*3+1;ctx.strokeStyle='#5b5f63';ctx.lineWidth=.45;ctx.beginPath();for(let k=0;k<=12;k++){const px=x-10+k*1.7,py=T-1.2+Math.sin(k*1.9)*1.1;k?ctx.lineTo(px,py):ctx.moveTo(px,py);}ctx.stroke();ctx.fillStyle='#8a8f94';for(let k=0;k<12;k+=2)ctx.fillRect(x-10+k*1.7,T-1.6+Math.sin(k*1.9)*1.1,.8,.8);}   /* barbed wire along the top (tier III) */
      if(b.hp<b.max*.5){ctx.fillStyle='#c8b080';for(let k=0;k<5;k++)ctx.fillRect(x-6+k*3,gy-.8,1.4,.8);}   /* split bags, sand spilling */
      if(b.hp<b.max){ctx.fillStyle='#000a';ctx.fillRect(x-8,gy-17,16,3);ctx.fillStyle='#ffd23f';ctx.fillRect(x-7,gy-16,14*Math.max(0,b.hp/b.max),1);}}
    else if(b.k==='barrier'){const w=7,h=17,L=x-w,R=x+w,T=gy-h;shadow(ctx,x,gy,10);   /* 0.12.76 (Kyle): one HESCO_Barrier cell, like his photos */
      ctx.fillStyle='#a8946c';ctx.fillRect(L,T,2*w,h);ctx.fillStyle='#c2ad84';ctx.fillRect(L+1,T+1,w-1,h-2);ctx.fillStyle='#8e7a56';ctx.fillRect(x+3,T+1,w-3,h-2);   // geotextile, lit from the left
      for(let yy=T+2;yy<gy;yy+=2.6){ctx.fillStyle='rgba(120,100,70,.35)';ctx.fillRect(L,yy,2*w,.5);}   // fabric bulging between the wires
      ctx.strokeStyle='rgba(70,72,74,.85)';ctx.lineWidth=.35;for(let xx=L+1.6;xx<R;xx+=2.4){ctx.beginPath();ctx.moveTo(xx,T);ctx.lineTo(xx,gy);ctx.stroke();}for(let yy=T+1.3;yy<gy;yy+=2.4){ctx.beginPath();ctx.moveTo(L,yy);ctx.lineTo(R,yy);ctx.stroke();}   // welded wire mesh
      ctx.fillStyle='#3e4246';for(const cx of[L,x,R-1])ctx.fillRect(cx,T-1,1,h+1);ctx.fillStyle='#7a8086';for(let yy=T;yy<gy;yy+=1.6)for(const cx of[L,x,R-1])ctx.fillRect(cx,yy,1,.6);   // coil-joint rods
      ctx.fillStyle='#5a4228';ctx.beginPath();ctx.moveTo(L-.5,T+.5);ctx.quadraticCurveTo(x-3,T-4,x,T-2.6);ctx.quadraticCurveTo(x+4,T-4.5,R+.5,T+.5);ctx.closePath();ctx.fill();ctx.fillStyle='#7a5c38';ctx.fillRect(x-4,T-2.6,3,1);   // dirt heaped over the top
      ctx.fillStyle='#c8b48a';ctx.fillRect(L,T,2*w,1);   // the fabric lip folded over the rim
      {ctx.fillStyle='#6b4a2a';ctx.fillRect(L-3.2,T-1,.8,h+1);ctx.fillRect(L-1.2,T-1,.8,h+1);ctx.fillStyle='#8a6438';for(let yy=T+1;yy<gy-.5;yy+=2.6)ctx.fillRect(L-3.2,yy,2.8,.7);}   // 0.12.104 (Kyle): a little wooden ladder up the left side
      if(b.hp<b.max*.6){ctx.strokeStyle='#4a3a22';ctx.lineWidth=.5;ctx.beginPath();ctx.moveTo(x-3,T+4);ctx.lineTo(x-1,T+8);ctx.lineTo(x-3,T+11);ctx.stroke();ctx.fillStyle='#6a5030';ctx.fillRect(x-2,gy-1,4,1);}   // torn, dirt spilling
      if(b.hp<b.max){ctx.fillStyle='#000a';ctx.fillRect(x-8,T-8,16,3);ctx.fillStyle='#ffd23f';ctx.fillRect(x-7,T-7,14*Math.max(0,b.hp/b.max),1);}}
    else if(b.k==='tesla'){shadow(ctx,x,gy,6);ctx.fillStyle='#3a3f48';ctx.fillRect(x-4,gy-4,8,4);ctx.fillStyle='#22262c';ctx.fillRect(x-1,gy-16,2,12);
      for(let y=gy-15;y<gy-5;y+=2){ctx.fillStyle='#c87a3a';ctx.fillRect(x-2.5,y,5,1);}ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,x,gy-19,3+Math.sin(g.t*12),'#6ad0ff',.5);glow(ctx,x,gy-19,1.4,'#e8fbff',1);
      if(Math.random()<.5){ctx.strokeStyle='rgba(160,230,255,.8)';ctx.lineWidth=.5;zig(x,gy-19,x+(Math.random()-.5)*12,gy-19+(Math.random()-.5)*10,3,1.5);}ctx.restore();
      ctx.fillStyle='#000a';ctx.fillRect(x-6,gy-25,12,2.5);ctx.fillStyle='#6ad0ff';ctx.fillRect(x-5,gy-24.5,10*Math.max(0,b.hp/b.max),1);}
    else if(b.k==='turret'){const d=b.face||-1,ty=gy-22;ctx.fillStyle='#2a2e34';ctx.fillRect(x-3,ty,6,4);ctx.fillStyle='#4a525c';ctx.fillRect(x-2,ty-3,5,3);ctx.fillStyle='#1a1c20';ctx.fillRect(d>0?x+2:x-9,ty-2,7,1.5);
      ctx.fillStyle='#e8c020';ctx.fillRect(x-3,ty+3,6,.8);if(b.hp<b.max){ctx.fillStyle='#000a';ctx.fillRect(x-6,ty-7,12,2.5);ctx.fillStyle='#ffd23f';ctx.fillRect(x-5,ty-6.5,10*Math.max(0,b.hp/b.max),1);}}
    ctx.restore();};
  const engFx=()=>{for(const S of g.satchels||[]){const y=S.gy-(S.hgt||0)*.5-2;ctx.fillStyle='#3a2a18';ctx.fillRect(S.x-3,y-3,6,4);ctx.fillStyle='#6a4a28';ctx.fillRect(S.x-3,y-3,6,1);ctx.fillStyle='#2a1c10';ctx.fillRect(S.x-1,y-5,2,2);   /* 0.12.75 satchel: canvas pouch, strap, blinking red light */
      if(Math.floor(g.t*3)%2){ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,S.x+2,y-2,1.6,'#ff2a1a',.9);ctx.restore();}}
    for(const f of g.fx){const k=f.t/f.life;if(f.k==='spark'){ctx.fillStyle=k<.4?'#fff6c0':'#ffb040';for(let i=0;i<3;i++)ctx.fillRect(f.x+Math.cos(i*2.1+f.x)*k*6,f.gy-4-Math.sin(i*2.1+f.x)*k*5+k*k*6,1,1);}
      else if(f.k==='tracer'){ctx.save();ctx.globalCompositeOperation='lighter';ctx.strokeStyle=`rgba(255,220,140,${1-k})`;ctx.lineWidth=.6;ctx.beginPath();ctx.moveTo(f.x0,f.y0);ctx.lineTo(f.x1,f.y1);ctx.stroke();glow(ctx,f.x0,f.y0,1.6,'#ffd080',.8*(1-k));ctx.restore();}}
    for(const h of g.alive())if(h.kitHits>0){ctx.fillStyle='rgba(200,208,220,.55)';ctx.fillRect(Math.round(g.heroX(h))-3,(h.gy||G)-14,6,1);}};
  const drawTent=T=>{const U=UNITS.tentacle;if(!U)return;const A=U[T.anim]||U.idle;let fr;const n=A.n;
    if(T.anim==='idle')fr=Math.floor(g.t*9+T.x)%n;else if(T.anim==='emerge')fr=Math.min(n-1,Math.floor(T.aT/.5*n));else if(T.anim==='attack')fr=Math.min(n-1,Math.floor(T.aT/.6*n));else if(T.anim==='hit')fr=Math.min(n-1,Math.floor(T.aT/.25*n));else fr=Math.min(n-1,Math.floor(T.aT/.8*n));
    ctx.save();shrinkAt(ctx,T.x,T.gy,HS);shadow(ctx,T.x,T.gy,9);drawUnit(ctx,A,fr,T.x,T.gy+1,T.big||1,null,T.hitT>0?(T.hitT-=1/60):0,0,T.face>0);ctx.restore();   // 0.12.70: Call_of_Cthulhu makes them 25% bigger
    if(T.hp<T.max&&T.anim!=='death'){const w=12,y=T.gy-36;ctx.fillStyle='#000a';ctx.fillRect(Math.round(T.x-w/2)-1,y-1,w+2,3);ctx.fillStyle='#9a50e8';ctx.fillRect(Math.round(T.x-w/2),y,Math.max(0,w*T.hp/T.max),1);}};
  const items=[...(g.blds||[]).map(b=>[b.gy-.3,-1,b.x,()=>drawBld(b)]),...(g.blds||[]).filter(b=>b.k==='tower'&&b.hp>0&&b.tier>=1).map(b=>[Math.max(b.gy,...[b.occ,b.occ2].filter(Boolean).map(o=>o.gy||G))+.05,1,b.x,()=>drawTowerRail(b)]),...(g.tentacles||[]).map(T=>[T.gy+.1,0,T.x,()=>drawTent(T)]),...(g.obst||[]).map(o=>[OBST[o.k].flat?-999:LANES[Math.max(...o.lanes)]+.2,-1,o.x,()=>drawOb(o)]),...hs.filter(h=>h.alive).map(h=>[h.gy||G,0,h.x,()=>drawHero(h)]),...(g.clones||[]).map(c=>[c.gy,0,c.x,()=>drawClone(c)]),...es.map(e=>[e.boss?G-.5:(e.gy!=null&&!e.fly?e.gy:G+e.lane-5),1,-e.x,()=>drawEnemy(e)])]
    .sort((a,b)=>a[0]-b[0]||a[1]-b[1]||a[2]-b[2]);
  // campfire (drawn behind the units) with sparks drifting up while it burns
  if(g.camp){const F=g.camp;let fr=0;if(F.state==='start')fr=1+Math.min(2,Math.floor(F.t/.3));else if(F.state==='burn')fr=4+Math.floor(g.t*8)%4;else if(F.state==='dying')fr=8+Math.min(2,Math.floor((F.dT||0)/.4));else fr=11;
    const A=Object.assign({},CAMPF,{x:fr*34,n:1});const fade=F.state==='dead'&&F.deadT>4?(5-F.deadT):1;drawUnit(ctx,A,0,F.x,F.gy+1,.5,fade,0,0,false);
    if(F.state==='burn'){ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,F.x,F.gy-6,14,'#ff9a30',.12+.04*Math.sin(g.t*9));
      for(let i=0;i<7;i++){const ph=((g.t*.7+i*.143)%1);const sx=F.x+Math.sin(i*2.3+g.t*2)*3+Math.sin(ph*9+i)*2,sy=F.gy-10-ph*28;ctx.fillStyle=ph<.6?'rgba(255,200,90,.95)':'rgba(255,120,40,'+(1-ph)*1.6+')';ctx.fillRect(sx,sy,ph<.3?1:.6,ph<.3?1:.6);}
      ctx.restore();}
    if(F.state==='dying'||F.state==='dead'){ctx.fillStyle='rgba(150,150,160,.25)';for(let i=0;i<3;i++){const ph=((g.t*.4+i*.33)%1);ctx.beginPath();ctx.arc(F.x+Math.sin(ph*6+i)*2,F.gy-6-ph*20,1.5+ph*3,0,7);ctx.fill();}}}
  traps();rainDraw();
  /* 0.12.51 enemy scrap mines: a rusted Trip Bomb cousin, dark red casing, spikes, a blinking red light and a taut wire. Unspotted ones are faint. */
  for(const M of g.mines||[]){if(!M.armed)continue;const x=Math.round(M.x),y=M.gy;ctx.save();
    if(M.shotgun&&!M.owner){const city=g.st.biome&&g.st.biome.id==='city';   /* 0.12.158 tripwire shotgun: a bush (trash bags downtown), a barrel peeking out pointing left, a wire across the lane */
      ctx.globalAlpha=M.spotted?1:.55;ctx.strokeStyle='rgba(210,210,200,.6)';ctx.lineWidth=.4;ctx.beginPath();ctx.moveTo(x-10,y-5);ctx.lineTo(x-10,y+1.5);ctx.moveTo(x-10,y-4.5);ctx.lineTo(x-2,y-3.2);ctx.stroke();ctx.fillStyle='#3a2a24';ctx.fillRect(x-10.5,y-5.5,1,1);
      ctx.globalAlpha=1;ctx.fillStyle='#2a2a2e';ctx.fillRect(x-6,y-4,5,1);ctx.fillStyle='#55555c';ctx.fillRect(x-6,y-4,5,.4);ctx.fillStyle='#000';ctx.fillRect(x-6.4,y-4,.5,1);   /* twin barrels */
      if(city){ctx.fillStyle='#1c1f26';ctx.beginPath();ctx.ellipse(x+1.5,y-2.6,4.2,3,0,0,7);ctx.fill();ctx.fillStyle='#262a33';ctx.beginPath();ctx.ellipse(x+4.5,y-2,3.2,2.4,0,0,7);ctx.fill();ctx.fillStyle='#3a404c';ctx.fillRect(x+.5,y-5,1.4,.6);}
      else{for(const [bx,by,r,c] of [[x+1,y-3,3.6,'#1e3a1a'],[x+3.6,y-2.4,3,'#244a20'],[x-.6,y-1.6,2.6,'#2c5a26'],[x+2.4,y-4.6,2.4,'#30642a']]){ctx.fillStyle=c;ctx.beginPath();ctx.arc(bx,by,r,0,7);ctx.fill();}}
      if(M.spotted){const b=Math.round(Math.sin(g.t*5)*1);ptext(ctx,'!',x-4,y-12+b,'#ff5a3a',1);}ctx.restore();continue;}
    ctx.globalAlpha=M.spotted?1:.38;
    ctx.strokeStyle='rgba(200,200,190,.55)';ctx.lineWidth=.5;ctx.beginPath();ctx.moveTo(x-7,y-1.5);ctx.lineTo(x+7,y-1.5);ctx.stroke();ctx.fillStyle='#3a2a24';ctx.fillRect(x-7.5,y-2.5,1,2);ctx.fillRect(x+6.5,y-2.5,1,2);   /* wire + stakes */
    ctx.fillStyle='#1c1412';ctx.fillRect(x-3,y-3,6,3);ctx.fillStyle='#6a2a1e';ctx.fillRect(x-2.5,y-2.5,5,2);ctx.fillStyle='#8a4a2a';ctx.fillRect(x-2,y-2.5,2,1);   /* rusted casing */
    if(M.cluster){ctx.fillStyle='#4a3a30';for(const sx of [-2.5,-.5,1.5]){ctx.beginPath();ctx.arc(x+sx+.5,y-3.6,.9,0,7);ctx.fill();}ctx.fillStyle='#c8a030';ctx.fillRect(x-2.5,y-1.2,5,.5);}   /* 0.12.157 cluster mine: little bomblets packed on top and a faded yellow band */
    else{ctx.fillStyle='#9a9a90';for(const sx of [-2.5,-.5,1.5])ctx.fillRect(x+sx,y-4,1,1);}   /* nail spikes */
    if(Math.floor(g.t*3)%2===0){const lc=M.owner?'#5aff6a':'#ff3a2a';ctx.fillStyle=lc;ctx.fillRect(x-.5,y-3.5,1,1);glow(ctx,x,y-3,1.6,lc,M.spotted?.3:.12);}   /* ours blink green */
    ctx.globalAlpha=1;if(M.spotted&&!M.owner){const b=Math.round(Math.sin(g.t*5)*1);ptext(ctx,'!',x,y-12+b,'#ff5a3a',1);}ctx.restore();}
  for(const K of g.crates||[]){const x=Math.round(K.x),y=Math.round(K.gy),k=K.t/K.A.dur,bl=k>.8&&Math.floor(g.t*6)%2;if(bl)continue;   /* 0.12.200 Ammo_Drop crate: olive box, yellow stencil band, a faint gold ring for its reach */
    ctx.save();ctx.globalAlpha=.25;ctx.strokeStyle='#ffd27a';ctx.lineWidth=.6;ctx.beginPath();ctx.ellipse(x,y,K.A.r,K.A.r*.25,0,0,7);ctx.stroke();ctx.restore();shadow(ctx,x,y,5);
    ctx.fillStyle='#1c2016';ctx.fillRect(x-5,y-5,10,5);ctx.fillStyle='#4a5a32';ctx.fillRect(x-4.5,y-4.5,9,4);ctx.fillStyle='#5f7240';ctx.fillRect(x-4.5,y-4.5,9,1);ctx.fillStyle='#d8b030';ctx.fillRect(x-4.5,y-3,9,1);ctx.fillStyle='#1c2016';ctx.fillRect(x-.5,y-4.5,1,4);
    for(const o of g.alive())if(!K.taken.has(o)&&o.plan&&o.plan.intent==='crate'){ctx.fillStyle='#ffd27a';ctx.fillRect(x-.5,y-9-Math.abs(Math.sin(g.t*5))*1.5,1,2);break;}}
  for(const b of g.bomblets||[]){let x,y;if(b.fuse<0){const u=Math.min(1,b.t/b.T);x=b.x0+(b.x1-b.x0)*u;y=b.gy0+(b.gy1-b.gy0)*u-Math.sin(u*Math.PI)*(b.H||14)-2;}else{x=b.x1;y=b.gy1-1.5;}   /* bomblets: arc, land, blink, pop */
    if(b.frag&&ATLAS.frag){const F=ATLAS.frag;shadow(ctx,b.fuse<0?b.x0+(b.x1-b.x0)*Math.min(1,b.t/b.T):b.x1,b.fuse<0?b.gy0+(b.gy1-b.gy0)*Math.min(1,b.t/b.T):b.gy1,1.4);drawUnit(ctx,F,b.fuse<0?0:2+Math.floor(g.t*10)%2,x,y+1.5,.42,null,0,b.fuse<0?b.t*14:0,false);continue;}   /* 0.12.175 the Soldier's frag: the pack's grenade, spinning in the air, then ticking on the ground */
    shadow(ctx,b.fuse<0?b.x0+(b.x1-b.x0)*Math.min(1,b.t/b.T):b.x1,b.fuse<0?b.gy0+(b.gy1-b.gy0)*Math.min(1,b.t/b.T):b.gy1,1.6);ctx.fillStyle='#2a201a';ctx.beginPath();ctx.arc(x,y,1.4,0,7);ctx.fill();ctx.fillStyle='#6a4a30';ctx.fillRect(x-.5+Math.cos(b.spin)*.6,y-.9,.8,.6);
    const blink=b.fuse<0?Math.floor(g.t*8)%2===0:Math.floor(g.t*24)%2===0;if(blink){ctx.fillStyle='#ff3a2a';ctx.fillRect(x-.4,y-1.6,.8,.8);glow(ctx,x,y-1.2,2,'#ff3a2a',.35);}}
  for(const h of g.alive())if(h.mine>0){const x=Math.round(g.heroX(h)-8),y=Math.round((h.gy||g.G)-31);ctx.fillStyle='#1c1412';ctx.fillRect(x-1,y,5,3);ctx.fillStyle='#6a2a1e';ctx.fillRect(x,y+1,3,1);ctx.fillStyle='#ff3a2a';ctx.fillRect(x+1,y,1,1);}   /* carrying a defused mine */
  for(const it of items)it[3]();
  engFx();voidFx();slamDraw();pinnedDraw();bottleDraw();nadeDraw();laser();waves();banners();iaiWaves();druidFx();robotFx();darkFx();quakes();logs();flames();jpFx();poultices();booms();
  // projectiles
  for(const p of g.proj){const x=Math.round(p.x),y=p.aimed?Math.round(p.y):Math.round(G+(p.y-G)*HS);const c=PCOL[p.kind]||'#ff3a3a';ctx.save();shrinkAt(ctx,x,y,HS);
    /* 0.12.94 (Kyle): projectiles turn to match the way they're flying (arrows from the tower point down at the target) */
    {const fx=p.x,fy=p.aimed?p.y:G+(p.y-G)*HS;if(p._sx!=null){const dx=fx-p._sx,dy=fy-p._sy;if(dx*dx+dy*dy>.01)p._ang=Math.atan2(dy,dx);}p._sx=fx;p._sy=fy;
      if(p._ang!=null&&p.kind!=='buck'){const d=(p.kind==='arrow'||p.kind==='quarrel')?(p.enemy?-1:1):(p.dir||1);let r=d<0?p._ang-Math.PI:p._ang;while(r>Math.PI)r-=2*Math.PI;while(r<-Math.PI)r+=2*Math.PI;if(Math.abs(r)>.02){ctx.translate(x,y);ctx.rotate(r);ctx.translate(-x,-y);}}}
    if(p.kind==='void'){const d=(p.dir||1);ctx.save();ctx.globalCompositeOperation='lighter';for(let i=1;i<=5;i++){ctx.fillStyle=`rgba(150,60,255,${.4-.07*i})`;ctx.fillRect(x-d*i*2.8-1,y-1+Math.sin(g.t*25+i)*.8,2,2);}glow(ctx,x,y,6,'#7a30e0',.35);ctx.restore();ctx.fillStyle='#12061e';ctx.beginPath();ctx.arc(x,y,2.4,0,7);ctx.fill();ctx.strokeStyle='#c090ff';ctx.lineWidth=.8;ctx.stroke();}   // void bolt: a black core in a violet halo
    else if(p.kind==='buck'){const d=(p.dir||1);ctx.save();ctx.globalCompositeOperation='lighter';   /* one buckshot pellet: a hot slug with a short streak */
      ctx.strokeStyle='rgba(255,200,120,.55)';ctx.lineWidth=.8;ctx.beginPath();ctx.moveTo(x-d*6,y);ctx.lineTo(x,y);ctx.stroke();ctx.fillStyle='#fff0c0';ctx.fillRect(x-.75,y-.75,1.5,1.5);ctx.restore();}
    else if(p.kind==='gat'){const d=(p.dir||1);ctx.save();ctx.globalCompositeOperation='lighter';ctx.strokeStyle='rgba(255,210,120,.85)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x-d*8,y);ctx.lineTo(x,y);ctx.stroke();ctx.fillStyle='#fff4c8';ctx.fillRect(x-1,y-.5,2,1);ctx.restore();}   // gatling tracer
    else if(p.kind==='leaf'){const d=(p.dir||1);ctx.save();ctx.globalCompositeOperation='lighter';   // 0.12.15 nature bolt: a glowing seed with leaves spinning round it and a fading green trail
      for(let i=1;i<=5;i++){ctx.fillStyle=`rgba(90,255,120,${.38-.065*i})`;const s=1.6-.22*i;ctx.fillRect(x-d*i*2.6-s/2,y-s/2+Math.sin(g.t*20+i)*.5,s,s);}
      glow(ctx,x,y,6,'#5dff6a',.32);glow(ctx,x,y,2.6,'#c8ffb0',.55);ctx.restore();
      ctx.fillStyle='#e8ffd8';ctx.fillRect(x-.75,y-.75,1.5,1.5);
      for(let i=0;i<3;i++){const an=g.t*14*d+i*2.09,lx=x+Math.cos(an)*2.6,ly=y+Math.sin(an)*1.6;ctx.fillStyle=i%2?'#3cc84a':'#7ee081';ctx.fillRect(lx-.6,ly-.4,1.2,.8);}}
    else if(p.kind==='dart'){const d=(p.dir||1),X=k=>d>0?x+k:x-k-1;   /* 0.12.68: a nicer tiny dart: steel needle, dark shaft, red and cream tuft, a drop of green poison */
      ctx.fillStyle='rgba(200,255,190,.18)';ctx.fillRect(d>0?x-11:x+2,y,9,1);ctx.fillStyle='#d8dde8';ctx.fillRect(X(1),y,2,1);ctx.fillStyle='#5fe04a';ctx.fillRect(X(0),y,1,1);ctx.fillStyle='#2a1e14';ctx.fillRect(d>0?x-4:x+1,y,4,1);
      ctx.fillStyle='#c8302a';ctx.fillRect(X(-5),y-1,1,3);ctx.fillStyle='#f0e6d0';ctx.fillRect(X(-6),y-1,1,1);ctx.fillRect(X(-6),y+1,1,1);ctx.fillStyle='#e04838';ctx.fillRect(X(-6),y,1,1);}   // poison dart: shaft, green-tipped point, little fletch
    else if(p.kind==='kunai'){const d=(p.dir||1);ctx.fillStyle='#2e3040';ctx.fillRect(x-d*6-(d<0?1:0),y,6,1);ctx.fillStyle='#5c3424';for(let i=1;i<5;i+=2)ctx.fillRect(x-d*(1+i),y,1,1);ctx.fillStyle='#a8aec4';ctx.fillRect(d>0?x:x-4,y-1,4,3);ctx.fillStyle='#e0e6f2';ctx.fillRect(d>0?x+3:x-4,y,2,1);ctx.fillStyle='#b0965a';ctx.fillRect(x-d*7,y-1,1,3);}   // spinning-free kunai, pixel drawn
    else if(p.kind==='yarrow'&&UNITS.archer&&UNITS.archer.arrow){const B=UNITS.archer.arrow,d=(p.dir||1);ctx.save();ctx.globalCompositeOperation='lighter';if(p.pin){for(let i=0;i<5;i++){ctx.strokeStyle=`rgba(255,${200-i*25},${120-i*20},${.5-i*.09})`;ctx.lineWidth=3-i*.45;ctx.beginPath();ctx.moveTo(x-d*(10+i*9),y+i*.15);ctx.lineTo(x-d*(4+i*9),y);ctx.stroke();}glow(ctx,x,y,4,'#ffb050',.3);}   /* 0.12.68 Pinning_Shot: a hot motion trail */
      else{ctx.strokeStyle='rgba(255,240,200,.35)';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(x-d*26,y);ctx.lineTo(x-d*4,y);ctx.stroke();}ctx.restore();   // faint streak behind it
      drawUnit(ctx,B,0,x,y,ART_SCALE/B.pre/HS*(p.pin?2.4:1.7),null,0,0,d<0);}   // his own arrow, cut from his Ranged frames
    else if(p.kind==='bullet'&&UNITS.flannel&&UNITS.flannel.bullet){const B=UNITS.flannel.bullet;drawUnit(ctx,B,0,x,y+B.ay*ART_SCALE/HS,ART_SCALE/HS,null,0,0,(p.dir||1)<0);}   // sprite bullet from the character's own sheet
    else if(p.kind==='zap'){const d=(p.dir||1);ctx.save();ctx.globalCompositeOperation='lighter';ctx.strokeStyle='rgba(255,230,90,.75)';ctx.lineWidth=.9;ctx.beginPath();ctx.moveTo(x-d*9,y+Math.sin(g.t*40)*1.2);ctx.lineTo(x-d*6,y-1.2);ctx.lineTo(x-d*3,y+1.2);ctx.lineTo(x,y);ctx.stroke();glow(ctx,x,y,4,'#ffe04a',.5);ctx.fillStyle='#fffbe0';ctx.fillRect(x-1,y-1,2,2);ctx.restore();}   /* 0.12.178 the Sorcerer's spark */
    else if(p.kind==='arrow'||p.kind==='quarrel'){const d=p.enemy?-1:1;ctx.fillStyle='#8a6a4a';ctx.fillRect(d>0?x-8:x-1,y,9,1);
      ctx.fillStyle='#d8d0c0';ctx.fillRect(x-d*9,y-1,2,1);ctx.fillRect(x-d*9,y+1,2,1);ctx.fillStyle='#c8ccd6';ctx.fillRect(x+(d>0?1:-3),y-1,2,3);ctx.fillRect(x+(d>0?3:-4),y,1,1);}
    else if(p.kind==='brick'){ctx.save();ctx.translate(x,y);ctx.rotate(p.rot||0);   /* 0.12.68: a real-looking brick (long and flat), tumbling */
      ctx.fillStyle='#4a1a10';ctx.fillRect(-4.5,-2,9,4);ctx.fillStyle='#a8442a';ctx.fillRect(-4,-1.5,8,3);ctx.fillStyle='#c9663e';ctx.fillRect(-4,-1.5,8,1);ctx.fillStyle='#8a3220';ctx.fillRect(-4,.5,8,1);
      ctx.fillStyle='#d8c8b0';ctx.globalAlpha=.55;ctx.fillRect(-4,-1.5,1,3);ctx.fillRect(3,-1.5,1,1);ctx.globalAlpha=1;ctx.fillStyle='#5a2214';ctx.fillRect(-2,-.5,1,1);ctx.fillRect(1,-.5,1,1);ctx.restore();}
    else if(p.kind==='beam'){ctx.fillStyle='#ff2a3a';ctx.fillRect(x,y,8,1);}
    else if(p.kind==='batswarm'){ctx.fillStyle='#1a0a14';ctx.fillRect(x-3,y,7,2);ctx.fillRect(x-1,y-1,3,1);ctx.fillStyle='#ff2a2a';ctx.fillRect(x,y,1,1);}
    else drawProj(ctx,p,x,y,c,g.t);ctx.restore();}
  // fx
  for(const f of g.fx){const k=f.t/.6;ctx.save();if(f.x!=null&&!f.raw)shrinkAt(ctx,f.x,G,HS);
    if(f.k==='gibs'){const tt=f.t,a=tt>1.8?Math.max(0,1-(tt-1.8)/.8):1;ctx.save();ctx.globalAlpha=a;   /* 0.12.40 zombie gibs: chunks fly, bounce once, settle, fade */
      for(const q of f.P){const T=Math.min(tt,2.2);let hh=q.h+q.vh*T-140*T*T,x=q.x+q.vx*Math.min(T,(q.vh+Math.sqrt(q.vh*q.vh+560*q.h))/280);if(hh<0)hh=0;
        ctx.fillStyle=q.c;const s=q.s;ctx.fillRect(Math.round(x*2)/2-s/2,Math.round((f.gy-hh)*2)/2-s/2,s,s*(hh>0?1:.6));}ctx.restore();}
    if(f.k==='blood'){const L=f.life,tt=f.t;let sd=f.seed;const rnd=()=>{sd=(sd*9301+49297)%233280;return sd/233280;};
      for(let i=0;i<f.n;i++){const a=(rnd()-.5)*1.6-(.35);const sp=(f.big?34:24)*(.4+rnd());const vx=Math.cos(a)*sp*f.dir,vy=Math.sin(a)*sp-10*rnd();
        const gy=f.gy+(rnd()*4-2);let x=f.x+vx*tt,y=f.y+vy*tt+60*tt*tt;
        if(y>=gy){const tl=(-vy+Math.sqrt(Math.max(0,vy*vy+240*(gy-f.y))))/120;x=f.x+vx*tl;y=gy;   // landed: a spot on the ground
          ctx.globalAlpha=Math.max(0,1-tt/L);ctx.fillStyle=i%3?'#5a0a12':'#7a1018';ctx.fillRect(Math.round(x),Math.round(y),i%4?1:2,1);}
        else{ctx.globalAlpha=1;ctx.fillStyle=tt<.08?'#ff5050':i%2?'#c0141e':'#8a0c16';const s2=i%3===0?2:1;ctx.fillRect(Math.round(x),Math.round(y),s2,s2);}}
      if(tt<.1){ctx.globalAlpha=1-tt*10;ctx.fillStyle='#ff3a3a';ctx.fillRect(Math.round(f.x)-1,Math.round(f.y)-1,f.big?3:2,f.big?3:2);}   // impact burst
      ctx.globalAlpha=1;}
    if((f.k==='harvestdie'||f.k==='wraithdie')&&ATLAS[f.k.slice(0,-3)]){const D=ATLAS[f.k.slice(0,-3)].die;const fr=Math.min(D.n-1,Math.floor(f.t/1.6*D.n));ctx.save();shrinkAt(ctx,f.x,f.gy,HS);ctx.globalAlpha=f.t>1.8?Math.max(0,1-(f.t-1.8)/.4):1;drawUnit(ctx,Object.assign({},D,{img:f.k.slice(0,-3)}),fr,f.x,f.gy,.95,null,0,0,true);ctx.restore();continue;}
    if(f.k==='pellets'){const k2=f.t/f.life;glow(ctx,f.x,f.gy-3.5,6*(1-k2),'#ffd080',.8*(1-k2));   /* 0.12.158 shotgun pellets: 7 streaks along their real paths */
      ctx.strokeStyle=`rgba(255,220,150,${(1-k2).toFixed(2)})`;ctx.lineWidth=.6;for(const o of f.offs||[]){const d0=k2*f.R,a=o/f.R;ctx.beginPath();ctx.moveTo(f.x-d0,f.gy-3.5+a*d0);ctx.lineTo(f.x-d0-7,f.gy-3.5+a*(d0+7));ctx.stroke();}continue;}
    if(f.k==='poof'){ctx.fillStyle=`rgba(180,170,190,${1-k})`;for(let i=0;i<(f.big?10:6);i++){const a=i*1.1;const r=4+k*(f.big?22:12);ctx.fillRect(Math.round(f.x+Math.cos(a)*r),Math.round(f.y+Math.sin(a)*r*.6),2,2);}}
    if(f.k==='ring'){ctx.strokeStyle=f.c;ctx.globalAlpha=1-k;ctx.beginPath();ctx.ellipse(Math.round(f.x),Math.round(f.y),f.r*(.3+k),f.r*(.3+k)*.45,0,0,7);ctx.stroke();ctx.globalAlpha=1;}
    if(f.k==='slash'){const al=Math.max(0,1-k*1.6);for(let i=0;i<14;i++){const a2=-1.2+i*.18;const r=13+k*3;ctx.fillStyle=`rgba(240,232,214,${al*(i<3||i>11?.5:1)})`;ctx.fillRect(Math.round(f.x-6+Math.cos(a2)*r),Math.round(f.y+Math.sin(a2)*r*.9),2,i>3&&i<10?2:1);}}
    if(f.k==='spark'){ctx.fillStyle=f.c;for(let i=0;i<4;i++){const a=i*1.57+.7;ctx.fillRect(Math.round(f.x+Math.cos(a)*k*8),Math.round(f.y+Math.sin(a)*k*8),1,1);}}
    if(f.k==='beam'){ctx.fillStyle=f.c;ctx.globalAlpha=1-k;ctx.fillRect(Math.round(f.x)-2,0,5,Math.round(f.y));ctx.fillStyle='#fff';ctx.fillRect(Math.round(f.x),0,1,Math.round(f.y));ctx.globalAlpha=1;}
    if(f.k==='drain'){ctx.fillStyle=f.c;for(let i=0;i<8;i++){const u=(i/8+k)%1;ctx.fillRect(Math.round(f.x+(f.tx-f.x)*u),Math.round(f.y+(G-30-f.y)*u-Math.sin(u*3.14)*10),2,2);}}
    if(f.k==='frost'){ctx.fillStyle=`rgba(200,240,255,${1-k})`;for(let i=0;i<40;i++)ctx.fillRect((i*37+Math.round(k*30))%W,(i*53+Math.round(k*80))%G,1,1);}
    if(f.k==='tentacle'){ctx.fillStyle='#4a2a52';const h=Math.sin(k*3.14)*60;ctx.fillRect(Math.round(f.x)-3,Math.round(G-h),6,Math.round(h));ctx.fillStyle='#c050a0';ctx.fillRect(Math.round(f.x)-1,Math.round(G-h),2,2);}
    if(f.k==='zap'){ctx.strokeStyle=`rgba(190,240,255,${1-k})`;ctx.beginPath();ctx.moveTo(f.x,f.y);for(let i=1;i<=5;i++){const u2=i/5;ctx.lineTo(f.x+(f.tx-f.x)*u2+(i<5?(Math.random()-.5)*6:0),f.y+(f.ty-f.y)*u2+(i<5?(Math.random()-.5)*6:0));}ctx.stroke();}
    if(f.k==='nstrace'){const y2=f.y2!=null?f.y2:f.y,dx=f.x2-f.x1,ex=f.x2+Math.sign(dx||1)*8,ey=y2+(y2-f.y)*8/Math.max(4,Math.abs(dx));ctx.globalAlpha=Math.max(0,.9*(1-k));ctx.lineCap='round';ctx.strokeStyle=f.c;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(f.x1,f.y);ctx.lineTo(ex,ey);ctx.stroke();ctx.strokeStyle='#fff';ctx.lineWidth=.8;ctx.beginPath();ctx.moveTo(f.x1,f.y);ctx.lineTo(ex,ey);ctx.stroke();glow(ctx,f.x1,f.y,3,'#ffe08a',.6*(1-k));ctx.globalAlpha=1;}   /* 0.12.155 No_Scope tracer: hip to target, angled across lanes */   /* 0.12.93 No_Scope tracer */
    if(f.k==='beamline'){ctx.fillStyle=f.c;ctx.globalAlpha=.8*(1-k);ctx.fillRect(Math.round(f.x),Math.round(f.y)-2,W,5);ctx.fillStyle='#fff';ctx.fillRect(Math.round(f.x),Math.round(f.y),W,1);ctx.globalAlpha=1;}
    if(f.k==='beamall'){ctx.fillStyle=`rgba(255,40,60,${.8*(1-k)})`;ctx.fillRect(0,G-34,f.x,6);ctx.fillStyle=`rgba(255,220,220,${1-k})`;ctx.fillRect(0,G-32,f.x,2);}
    if(f.k==='drainall'){ctx.strokeStyle=`rgba(255,40,60,${1-k})`;for(const h of g.alive()){ctx.beginPath();ctx.moveTo(h.x,G-30);ctx.lineTo(f.x-30,f.y);ctx.stroke();}}ctx.restore();}
  if(CC.brain&&!g.demo){ctx.save();ctx.font='5px monospace';ctx.textAlign='center';
    const tag=(u,x,y,lines,c)=>{lines=lines.filter(Boolean);const w=Math.max(...lines.map(l=>ctx.measureText(l).width))+4;ctx.fillStyle='rgba(0,0,0,.65)';ctx.fillRect(Math.round(x-w/2),Math.round(y-6*lines.length-1),Math.round(w),6*lines.length+2);
      ctx.fillStyle=c;lines.forEach((l,i)=>ctx.fillText(l,Math.round(x),Math.round(y-6*(lines.length-1-i))));};
    const nm=t=>!t?'nobody':t.key?(heroDef(t.key)||{name:t.key}).name.split(' ').slice(-1)[0]:(t.type||'foe');
    for(const h of g.alive()){const P=h.plan;if(!P)continue;tag(h,g.heroX(h),(h.gy||G)-Math.max(60,hbOf(h).h*UNIT_SCALE+14),[`${(heroDef(h.key)||{name:h.key}).name} · ${personaTitle(h)}`,`${P.intent.toUpperCase()} → ${nm(P.tgt)}`,P.why,...(h.dangerT>g.t?[h.dangerWhy]:[]),...(h.abWhyT>g.t?[h.abWhy]:[]),h.pauseT>0?'(thinking...)':h.burst>0?'BURST!':''],'#b6ff00');}
    for(const e of g.enemies){if(e.dead||!e.plan)continue;tag(e,e.x,(e.gy||G)-(e.type==='werewolf'?40:52),[`${e.retreatT>0?'BACK OFF':'HUNT'} → ${nm(e.plan.tgt)}`,e.plan.why,e.pauseT>0?'(shambling...)':''],'#ff9a9a');}
    ctx.restore();}
  // 0.12.13 callouts: short shouts above the speaker's head, in that hero's colour
  if(g.calls&&g.calls.length){ctx.save();const cfs=ctx.canvas.clientWidth&&ctx.canvas.clientWidth<700?4:3.4;ctx.font='bold '+cfs+'px monospace';   /* 0.12.201 (Kyle): chatter 15% smaller on desktop, unchanged on phones */ctx.textAlign='center';ctx.textBaseline='bottom';const seen=new Set();
    for(let i=g.calls.length-1;i>=0;i--){const c=g.calls[i];if(seen.has(c.u))continue;seen.add(c.u);const u=c.u;if(!u.alive)continue;
      const x=Math.max(30,Math.min(g.W-30,g.heroX(u))),y=(u.gy||G)-Math.max(56,hbOf(u).h*UNIT_SCALE+10)-(CC.brain?32:0)-Math.min(3,c.t*8);
      const k=c.t<.12?c.t/.12:c.t>c.life-.35?Math.max(0,(c.life-c.t)/.35):1;ctx.globalAlpha=k;const w=ctx.measureText(c.s).width+4;
      ctx.fillStyle='rgba(8,6,14,.78)';ctx.fillRect(Math.round(x-w/2),Math.round(y-cfs-1.5),Math.round(w),cfs+2);ctx.fillStyle=c.c;ctx.fillRect(Math.round(x-w/2),Math.round(y),Math.round(w),1);
      ctx.beginPath();ctx.moveTo(x-2,y+1);ctx.lineTo(x+2,y+1);ctx.lineTo(x,y+3);ctx.fill();ctx.fillText(c.s,Math.round(x),Math.round(y));}
    ctx.restore();ctx.globalAlpha=1;}
  {const small=ctx.canvas.clientWidth&&ctx.canvas.clientWidth<700,wm=small?.65:.5;   /* 0.12.201 (Kyle): pop-up words half size (a bit bigger on phones so they stay readable); numbers unchanged */
  for(const t of g.texts){const a=1-t.t/.9;ctx.globalAlpha=Math.max(0,a);const sc=t.sc||(t.big?2:1),word=/[A-Za-z]{2}/.test(t.s);ptext(ctx,t.s,t.x,Math.round(G+(t.y-G)*HS),t.c,word?Math.max(.5,Math.round(sc*wm*RES)/RES):sc);ctx.globalAlpha=1;}}
  ctx.restore();
  // boss bar / stage progress
  if(!g.demo){const p=g.boss&&!g.boss.dead?null:Math.min(1,g.dist/g.st.len);
    if(p!=null){ctx.fillStyle='#120a14';ctx.fillRect(6,4,W-12,4);ctx.fillStyle='#a6ff2e';ctx.fillRect(7,5,Math.round((W-14)*p),2);if(g.st.boss){ctx.fillStyle='#ff3a3a';ctx.fillRect(W-10,3,4,6);}}
    else{ctx.fillStyle='#120a14';ctx.fillRect(40,4,W-80,6);ctx.fillStyle='#c8102e';ctx.fillRect(41,5,Math.round((W-82)*Math.max(0,g.boss.hp/g.boss.max)),4);}}
}
// ---------------------------------------------------------------- portraits
// 0.12.13 one floating tooltip for the whole game: follows what you hover, always fits on screen.
//   Any element with data-tiph (html) gets a rich tip; any plain title="" is taken over so it looks the same.
/* 0.12.213 (Kyle: cleaner ability tooltips) one layout for every ability: a small cost/cooldown line, then one short line per sentence */
function fmtAbil(txt){txt=String(txt||'');let meta=[],body=txt;const P=txt.split(' · ');
  if(P.length>1){P.shift();const m=[];while(P.length){const p=P[0];const dot=p.search(/\.\s/);const head=dot>=0?p.slice(0,dot):p;
      if(/energy|^\d|life|passive|basic attack|\(passive\)|^Passive/i.test(head)&&head.length<48){m.push(head.replace(/^\(|\)$/g,''));if(dot>=0){P[0]=p.slice(dot+2);break;}P.shift();}else break;}
    meta=m;body=P.join(' · ');}
  const S=body.split(/(?<=[.!?])\s+(?=[A-Z(])/).filter(Boolean);
  return (meta.length?`<div class="tt-m">${meta.map(esc).join(' · ')}</div>`:'')+S.map(s=>`<div class="tt-l">${esc(s)}</div>`).join('');}
function howTip(k,insp){const D=heroDef(k)||{name:k},C=CHAR[k]||{};const p=personaOf({key:k,insp});
  return `<div class="tt-h">${esc(D.name)}</div><div class="tt-r">${esc(C.role||'')} · ${esc(personaTitle({key:k,insp}))}</div><div class="tt-b">${esc(BEHAVIOR[k]||D.blurb||'')}</div>`+
    `<div class="tt-s">${SLIDERS.map(([sk,l,r])=>{const v=p[sk]??5,s=Math.abs(v-5)/5;   // 0.12.24: the harder it leans, the brighter and bolder that side's word
      const mix=(a,b)=>Math.round(a+(b-a)*s),col=`rgb(${mix(150,190)},${mix(160,255)},${mix(150,40)})`,st=s>0?`style="opacity:${(.6+.4*s).toFixed(2)};color:${col};font-weight:${s>=.6?800:s>=.3?700:500}${s>=.8?';text-shadow:0 0 6px rgba(166,255,46,.55)':''}"`:'';
      return `<span class="l" ${v<5?st:''}>${esc(l)}</span><i><b style="left:${v*10}%;background:${s>0?col:'#ffd23f'}"></b></i><span class="r" ${v>5?st:''}>${esc(r)}</span>`;}).join('')}</div>`+
    `<div style="margin-top:5px;font-size:9px;opacity:.75">Key: <span style="color:rgb(158,179,128);opacity:.7">slight lean</span> · <span style="color:rgb(174,217,84);font-weight:700">strong</span> · <span style="color:rgb(190,255,40);font-weight:800;text-shadow:0 0 6px rgba(166,255,46,.55)">extreme</span></div>`+
    (insp&&INSP[insp]?`<div style="margin-top:5px;font-size:10px;opacity:.8">✨ ${esc(insp)}: ${esc(inspText(insp))}</div>`:'');}
let FTIP=null;function installTips(){if(FTIP)return;FTIP=document.createElement('div');FTIP.id='cc-ftip';document.body.appendChild(FTIP);let cur=null;
  const place=el=>{const r=el.getBoundingClientRect(),W=innerWidth,H=innerHeight;const tw=FTIP.offsetWidth,th=FTIP.offsetHeight;
    let x=r.left+r.width/2-tw/2;x=Math.max(8,Math.min(W-tw-8,x));let y=r.top-th-8;if(y<8)y=r.bottom+8;if(y+th>H-8)y=Math.max(8,H-th-8);FTIP.style.left=x+'px';FTIP.style.top=y+'px';};
  const show=el=>{if(el.title){el.dataset.tipt=el.title;el.removeAttribute('title');}const h=el.dataset.tiph;FTIP.innerHTML=h!=null?h:esc(el.dataset.tipt||'').replace(/\n/g,'<br>');
    if(!FTIP.innerHTML){hide();return;}FTIP.style.display='block';cur=el;const rr=el.closest('.rot-side');if(rr){if(FTIP.parentNode!==rr)rr.appendChild(FTIP);FTIP.classList.add('inrot');FTIP.style.left='';FTIP.style.top='';}else{if(FTIP.parentNode!==document.body)document.body.appendChild(FTIP);FTIP.classList.remove('inrot');place(el);}};
  const hide=()=>{FTIP.style.display='none';cur=null;};
  document.addEventListener('mouseover',e=>{if(Date.now()-lastT<800)return;const el=e.target.closest&&e.target.closest('[data-tiph],[title],[data-tipt]');if(el===cur)return;if(!el){hide();return;}show(el);},true);
  document.addEventListener('focusin',e=>{if(Date.now()-lastT<800||(e.target.matches&&e.target.matches(':focus-visible')===false))return;const el=e.target.closest&&e.target.closest('[data-tiph],[title],[data-tipt]');if(el)show(el);});
  document.addEventListener('scroll',()=>{if(cur&&cur.isConnected){if(!FTIP.classList.contains('inrot'))place(cur);}else hide();},true);document.addEventListener('mousedown',()=>{if(Date.now()-lastT>800)hide();},true);
  // 0.12.81 phones: tap (or long-press) anything with a tip to view it; tap again or tap elsewhere to close. No text selection.
  let lastT=0;const TSEL='[data-tiph],[title],[data-tipt]';document.addEventListener('pointerdown',e=>{if(e.pointerType==='touch')lastT=Date.now();},true);
  document.addEventListener('pointerup',e=>{if(e.pointerType!=='touch')return;lastT=Date.now();const el=e.target.closest&&e.target.closest(TSEL);
    if(e.target.closest&&e.target.closest('#cc-ftip')){hide();return;}if(!el){hide();return;}if(el.closest('button,a,input,select,label')){hide();return;}if(cur===el){hide();return;}show(el);},true);   // buttons act on tap; long-press them to read the tip
  document.addEventListener('contextmenu',e=>{const el=e.target.closest&&e.target.closest(TSEL);if(el&&el.closest('#cc')){e.preventDefault();show(el);}},true);
  }
function portrait(key,size){const U=UNITS[key];if(U&&U.idle&&!SP['h_'+key]){const c=document.createElement('canvas');const A=U.idle;c.width=A.fw;c.height=A.fh;c.className='cc-por';
    const go=()=>{const x=c.getContext('2d');x.imageSmoothingEnabled=false;const k=A.pk||(A.art?3.4:A.pre?3.4*A.pre:1),w=30*k,hh=46*k,z=A.art?1:2,sx=A.x+A.ax-w/2,sy=A.y+A.ay-hh;c.width=w*z;c.height=hh*z;x.imageSmoothingEnabled=!!A.art;if(key==='jp')x.scale(z,z);else{x.translate(c.width,0);x.scale(-z,z);}   /* 0.12.143 (Kyle): JP faces the other way in character select */x.drawImage(A.img?XIMG[A.img]:UIMG,sx,sy,w,hh,0,0,w,hh);};
    const IM0=A.img?XIMG[A.img]:UIMG;if(IM0.complete)go();else IM0.addEventListener('load',go,{once:true});if(size)c.style.width=size+'px';
    if(A.n>1){let f=0;const tick=()=>{if(!c.isConnected&&f>2)return;f++;const x=c.getContext('2d'),k=A.pk||(A.art?3.4:A.pre?3.4*A.pre:1),w=30*k,hh=46*k,z=A.art?1:2,fi=f%A.n,sx=A.x+fi*A.fw+A.ax-w/2,sy=A.y+A.ay-hh;
      if(IM0.complete){x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,c.width,c.height);x.imageSmoothingEnabled=!!A.art;if(key==='jp')x.scale(z,z);else{x.translate(c.width,0);x.scale(-z,z);}x.drawImage(IM0,sx,sy,w,hh,0,0,w,hh);}
      setTimeout(tick,key==='edward'?(fi>=5&&fi<12?150:220):260);};setTimeout(tick,300+Math.random()*400);}   /* 0.12.217 (Kyle): every hero card breathes with its idle; Edward's idle is his own (he tinkers with the nail gun and pushes his glasses up) */
    return c;}
  const c=document.createElement('canvas');const a=SP['h_'+key];c.width=a[2];c.height=a[3];c.className='cc-por';
  const go=()=>{const x=c.getContext('2d');x.imageSmoothingEnabled=false;x.clearRect(0,0,c.width,c.height);x.drawImage(IMG,a[0],a[1],a[2],a[3],0,0,a[2],a[3]);};
  if(IMG.complete)go();else IMG.addEventListener('load',go,{once:true});if(size)c.style.width=size+'px';return c;}

// ---------------------------------------------------------------- styles
const CSS=`
#cc{position:fixed;inset:0;z-index:9000;background:#07040a;color:#e9e3f2;display:flex;flex-direction:column;font-size:14px;-webkit-tap-highlight-color:transparent;user-select:none}
#cc[hidden]{display:none}
#cc .px{font-family:var(--px,'Press Start 2P',monospace);letter-spacing:.5px}
#cc button{font:inherit;color:inherit;cursor:pointer}
.cc-top{display:flex;align-items:center;gap:6px;padding:6px 8px;background:#120a18;border-bottom:2px solid #2a1838;flex:0 0 auto}
.cc-top .t{font-family:var(--px,monospace);font-size:11px;color:#a6ff2e;margin-right:auto;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cc-ib{background:#1e1228;border:2px solid #3a2450;border-radius:6px;min-width:34px;height:32px;padding:0 8px;font-size:13px}
.cc-vol{width:80px;accent-color:#a6ff2e;vertical-align:middle;margin:0 4px}
.cc-ib[aria-pressed=true]{border-color:#a6ff2e;color:#a6ff2e}
.cc-main{position:relative;flex:1;display:flex;flex-direction:column;min-height:0;align-items:center}
.cc-info{display:flex;gap:10px;align-items:center;width:100%;padding:4px 10px;font-size:12px;flex-wrap:wrap;box-sizing:border-box}
.cc-info b{color:#ffd23f;font-weight:600}.cc-xp{flex:1;min-width:90px;height:6px;background:#1e1228;border:1px solid #3a2450;border-radius:3px;overflow:hidden}.cc-xp i{display:block;height:100%;background:#a6ff2e}
@keyframes ccTentPulse{0%,100%{box-shadow:0 0 0 #a6ff2e00}50%{box-shadow:0 0 10px #a6ff2e88}}
.cc-help{background:#140c1c;border:1px solid #a6ff2e66;border-radius:10px;padding:8px 12px;margin:6px 0 10px;font-size:12px;line-height:1.45;color:#e8dff5}
.cc-help b{color:#a6ff2e}
canvas.cc-fire{display:block;width:100%;image-rendering:pixelated;image-rendering:crisp-edges;border-radius:10px;border:1px solid #3a2a1a;box-shadow:0 0 30px rgba(255,120,40,.18);margin:6px 0 10px}
#cc-cv{image-rendering:pixelated;image-rendering:crisp-edges;background:#000;display:block;flex:0 0 auto}
.cc-cvw{position:relative;overflow:hidden;flex:0 0 auto;max-width:100%}
.cc-cvw.cam #cc-cv{position:absolute;left:0;top:0}
.cc-boss{position:absolute;left:0;right:0;text-align:center;font-family:var(--px,monospace);font-size:10px;color:#ff6a6a;text-shadow:0 1px 0 #000;pointer-events:none}
.cc-hud{display:grid;gap:6px;width:100%;padding:6px 8px;box-sizing:border-box;flex:0 0 auto}
.cc-hc{display:flex;gap:6px;align-items:center;background:#120a18;border:2px solid #2a1838;border-radius:8px;padding:3px 6px;min-width:0}
.cc-hc .cc-por{width:30px;height:30px;object-fit:cover;object-position:center top}
.cc-hc .n{font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.cc-hc .bar{height:6px;background:#2a1018;border-radius:3px;overflow:hidden;margin-top:2px}.cc-hc .bar i{display:block;height:100%;background:#4fd46a}
.cc-hc.dead{opacity:.4}
.cc-panel{position:absolute;inset:0;overflow:auto;background:rgba(7,4,10,.96);padding:14px 12px 40px;box-sizing:border-box;-webkit-overflow-scrolling:touch}
.cc-panel[hidden]{display:none}
.cc-wrap{max-width:760px;margin:0 auto}
.cc-h{font-family:var(--px,monospace);color:#a6ff2e;font-size:16px;margin:6px 0 4px;line-height:1.5}
.cc-h2{font-family:var(--gothic,serif);font-size:24px;color:#ff8a1f;margin:4px 0 8px}
.cc-sub{color:#b8aecb;font-size:13px;margin:0 0 12px}
.cc-row{display:flex;gap:8px;flex-wrap:wrap}
.cc-card{background:#120a18;border:2px solid #2a1838;border-radius:10px;padding:10px;box-sizing:border-box}
.cc-btn{background:#2a1430;border:2px solid #6a2a8a;border-radius:8px;padding:10px 14px;font-weight:600}
.cc-btn.go{background:#1f3a12;border-color:#a6ff2e;color:#d8ffb0;font-family:var(--px,monospace);font-size:12px;padding:14px 18px}
.cc-btn.warn{border-color:#c8102e;background:#2a0a10}
.cc-btn:disabled{opacity:.4}
.cc-who{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}
.cc-who button{background:#120a18;border:2px solid #3a2450;border-radius:12px;padding:14px;text-align:left}
.cc-who .e{font-size:28px}.cc-who .nm{font-family:var(--px,monospace);font-size:12px;margin:6px 0}
.cc-pin{display:grid;grid-template-columns:repeat(3,74px);gap:10px;justify-content:center;margin:12px 0}
.cc-pin button{height:58px;font-size:22px;background:#1e1228;border:2px solid #3a2450;border-radius:10px}
.cc-dots{display:flex;gap:12px;justify-content:center;margin:10px 0}.cc-dots i{width:16px;height:16px;border-radius:50%;border:2px solid #a6ff2e}.cc-dots i.on{background:#a6ff2e}
.cc-dots.bad{animation:ccshake .3s}@keyframes ccshake{25%{transform:translateX(-6px)}75%{transform:translateX(6px)}}
.cc-heroes{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:8px;align-items:start}
.cc-hero{background:#120a18;border:2px solid #2a1838;border-radius:10px;padding:8px;text-align:left;position:relative}
[data-tiph],[data-tipt]{-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}
#cc-ftip.inrot{position:absolute!important;left:50%!important;top:50%!important;transform:translate(-50%,-50%);max-height:85%;overflow:auto;pointer-events:auto}
#cc .cc-radiosub{position:absolute;left:50%;bottom:6%;transform:translateX(-50%);max-width:80%;padding:5px 10px;background:rgba(8,10,8,.82);border:1px solid #6aff8a66;border-radius:6px;color:#b8ffc8;font:600 clamp(10px,1.3vw,14px)/1.3 system-ui,sans-serif;text-align:center;opacity:0;transition:opacity .3s;pointer-events:none;z-index:4;text-shadow:0 0 6px #3aff6a55}
#cc-ftip .tt-m{color:#ffd23f;font-size:10px;margin:1px 0 3px;opacity:.9}#cc-ftip .tt-l{margin:0 0 2px;padding-left:8px;text-indent:-8px}#cc-ftip .tt-l:before{content:'· ';color:#a6ff2e}
#cc-ftip{position:fixed;z-index:9999;display:none;pointer-events:none;max-width:min(340px,calc(100vw - 16px));background:#0d0712;border:1px solid #a6ff2e;border-radius:8px;padding:8px 10px;color:#e8dff5;font:11px/1.4 system-ui,sans-serif;box-shadow:0 8px 22px #000c;text-align:left;white-space:normal}#cc-ftip .tt-h{font-weight:700;color:#ffd23f;font-size:12px}#cc-ftip .tt-r{opacity:.7;font-size:10px;margin-bottom:5px}#cc-ftip .tt-b{margin-bottom:6px}#cc-ftip .tt-s{display:grid;grid-template-columns:1fr 64px 1fr;gap:2px 6px;align-items:center;font-size:9.5px}#cc-ftip .tt-s .l{text-align:right;opacity:.55}#cc-ftip .tt-s .r{opacity:.55}#cc-ftip .tt-s .on{opacity:1;color:#a6ff2e;font-weight:700}#cc-ftip .tt-s i{position:relative;height:5px;background:#2a1838;border-radius:3px}#cc-ftip .tt-s i b{position:absolute;top:-2px;width:5px;height:9px;margin-left:-2.5px;background:#ffd23f;border-radius:2px}.cc-ab .cc-tip{display:none!important}.cc-ab.pas{color:#9ad8ff;border-color:#2a4a60;background:#121c28}.cc-hw{display:flex;flex-direction:column;align-self:start}.cc-abl{display:flex;flex-direction:column;align-items:flex-start;gap:4px;margin-top:6px}.cc-ab{position:relative;font-size:10.5px;background:#1e1228;border:1px solid #3a2850;border-radius:6px;padding:2px 6px;color:#ffd23f;cursor:help}.cc-ab .cc-tip{display:none;position:absolute;left:0;bottom:calc(100% + 6px);z-index:20;width:220px;background:#0d0712;border:1px solid #a6ff2e;border-radius:8px;padding:7px 9px;color:#e8dff5;font-size:11px;line-height:1.4;box-shadow:0 6px 18px #000a;white-space:normal}.cc-ab:hover .cc-tip,.cc-ab:focus .cc-tip{display:block}.cc-hw .cc-hero{height:auto}.cc-insp{background:#0d0712;border:1px solid #2a1838;border-top:0;border-radius:0 0 10px 10px;padding:4px 8px 8px}.cc-insp select{width:100%;margin-top:3px;background:#120a18;color:#e8dff5;border:1px solid #3a2850;border-radius:6px;font-size:11px;padding:3px}.cc-insp select:disabled{opacity:.45}.cc-ibx{font-size:10.5px;color:#b8aecb;margin-top:4px;line-height:1.35}
.cc-hero[aria-pressed=true]{border-color:#a6ff2e;box-shadow:0 0 0 2px #a6ff2e44}
.cc-hero .cc-por{width:64px;height:64px;float:left;margin-right:6px}
.cc-hero .nm{font-weight:700;font-size:13px}.cc-hero .dk{font-size:11px;color:#b8aecb}.cc-hero .lv{font-family:var(--px,monospace);font-size:9px;color:#ffd23f;margin-top:4px}
.cc-hero .ord{position:absolute;top:6px;right:8px;font-family:var(--px,monospace);font-size:12px;color:#a6ff2e}
.cc-stat{clear:both;display:grid;grid-template-columns:28px 1fr;gap:2px 6px;font-size:10px;padding-top:6px;color:#b8aecb}.cc-stat i{display:block;height:5px;margin-top:3px;background:#3a2450;border-radius:3px}.cc-stat i b{display:block;height:100%;border-radius:3px;background:#ff8a1f}
.cc-load{display:grid;gap:8px}
.cc-lh{display:flex;gap:8px;align-items:flex-start}
.cc-chips{display:flex;flex-wrap:wrap;gap:4px;margin-top:4px}
.cc-chip{font-size:11px;padding:3px 6px;border-radius:6px;background:#1e1228;border:1px solid #3a2450}
.cc-chip.it{border-style:dashed}
.cc-chipw{display:inline-flex;gap:2px;align-items:center}.cc-mini{font-size:11px;padding:3px 7px;border-radius:6px;background:#2a1430;border:1px solid #6a2a8a}.cc-slotrow{margin-top:5px}.cc-chip b{font-weight:600}
.cc-offers{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px}
.cc-offer{background:#120a18;border:2px solid var(--rc);border-radius:12px;padding:10px;text-align:left;display:flex;flex-direction:column;gap:4px}
.cc-offer .rar{font-family:var(--px,monospace);font-size:9px;color:var(--rc)}
.cc-offer .kind{font-size:11px;color:#b8aecb;text-transform:uppercase;letter-spacing:.6px}
.cc-offer .cn{font-weight:700;font-size:14px}.cc-offer .tx{font-size:12px;color:#d8d0e6}
.cc-offer .who{display:flex;gap:6px;align-items:center;font-size:11px;color:#b8aecb}.cc-offer .who .cc-por{width:28px;height:28px;object-fit:cover;object-position:center top}
.cc-stars{color:#ffd23f;font-size:11px;letter-spacing:1px}
.cc-asc{color:#ffb020;font-family:var(--gothic,serif);font-size:16px}
.cc-lb{width:100%;border-collapse:collapse;font-size:12px}.cc-lb td,.cc-lb th{padding:5px 6px;border-bottom:1px solid #2a1838;text-align:left}.cc-lb th{color:#b8aecb;font-weight:500}
.cc-banner{position:absolute;left:0;right:0;top:38%;text-align:center;font-family:var(--px,monospace);font-size:18px;color:#ffd23f;text-shadow:0 2px 0 #000,0 0 12px #000;pointer-events:none;transition:opacity .4s}
.cc-hc .sp{display:none}
.cc-hud.tall{grid-template-columns:1fr!important}.cc-hud.tall .cc-hc .cc-por{width:44px;height:44px}.cc-hud.tall .n{font-size:13px}
.cc-hud.tall .sp{display:flex;flex-wrap:wrap;gap:4px;margin-top:5px}
.cc-sp{position:relative;font-size:11px;padding:3px 6px 5px;border-radius:6px;background:#1e1228;border:1px solid #3a2450;overflow:hidden}.cc-sp.it{border-style:dashed;color:#b8aecb}
.cc-sp i{position:absolute;left:0;bottom:0;height:2px;background:#a6ff2e;width:0}
#cc .cc-hud{display:none!important}
#cc .cc-uf{display:flex;flex-direction:column;gap:4px;position:absolute;left:1.6%;top:9%;z-index:3;pointer-events:auto}   /* 0.12.204 (Kyle): life bars top-left over the sky, for every screen */
#cc.land .cc-uf{top:calc(9% + 20px)}
#cc .uf{display:block;width:clamp(104px,19vw,170px);cursor:help;text-shadow:0 1px 0 #000,1px 0 0 #000,-1px 0 0 #000,0 -1px 0 #000}
#cc .uf .cc-por{display:none}
#cc .uf .ufn{font:700 clamp(9px,1.25vw,12px)/1.15 system-ui,sans-serif;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#cc .uf .ufn span.lv{color:#ffd23f;font-weight:600}
#cc .uf .ufs{font-weight:600;font-size:.9em;margin-left:4px}
#cc .uf .ufh{height:clamp(4px,.55vw,7px);background:rgba(30,10,20,.8);border:1px solid rgba(0,0,0,.7);border-radius:2px;margin-top:2px;overflow:hidden}
#cc .uf .ufe{height:2px;background:rgba(16,26,42,.8);margin-top:1px;overflow:hidden;border-radius:1px}
#cc .uf .ufh i,#cc .uf .ufe i{display:block;height:100%;width:100%}#cc .uf .ufe i{background:#3fb6ff}
#cc .uf.dead{opacity:.5;filter:grayscale(1)}
#cc.land .cc-info{position:absolute;top:0;left:0;z-index:2;background:rgba(7,4,10,.6);padding:3px 8px}
#cc.land .cc-hud{position:absolute;bottom:0;left:0;z-index:2;background:rgba(7,4,10,.55);grid-auto-flow:column;padding:3px 6px}
#cc.land .cc-hc{padding:1px 4px;border-width:1px}
#crawl-strip{position:relative;margin:10px 0 0;border:2px solid #2a1838;border-radius:10px;overflow:hidden;height:clamp(70px,11vw,118px);background:#07040a;cursor:pointer}
#crawl-strip canvas{width:100%;height:100%;display:block;image-rendering:pixelated;image-rendering:crisp-edges}
#crawl-strip .cs-play{position:absolute;left:10px;top:8px;font-family:var(--px,monospace);font-size:11px;color:#a6ff2e;background:rgba(7,4,10,.78);border:2px solid #a6ff2e;border-radius:8px;padding:7px 10px;cursor:pointer}
#crawl-strip .cs-top{position:absolute;right:10px;top:10px;font-size:11px;color:#e9e3f2;background:rgba(7,4,10,.7);padding:3px 7px;border-radius:6px;max-width:55%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
@media (max-width:520px){#crawl-strip .cs-play{font-size:9px;padding:5px 7px}#crawl-strip .cs-top{font-size:10px;top:auto;bottom:6px}}
`;

// ---------------------------------------------------------------- state
const CC={data:Save.load(),player:null,unlocked:{},slotIdx:-1,game:null,speed:1,paused:false,raf:0};
const PL=()=>{const p=CC.data.players[CC.player]=CC.data.players[CC.player]||{pin:null,slots:[null,null,null,null,null]};while(p.slots.length<5)p.slots.push(null);return p;};   /* 0.12.86 (Kyle): 5 save files, no PIN */
const SLOT=()=>PL().slots[CC.slotIdx];
function persist(){Save.write(CC.data);updateStripTop();}
function migrate(slot,player){migrateSlot(slot,player);}
function bestOf(player){const p=CC.data.players[player];let b={score:0,stage:0,prestige:0};if(!p)return b;
  for(const s of p.slots)if(s&&(s.best.prestige*100+s.best.stage>b.prestige*100+b.stage||(s.best.score>b.score&&s.best.stage>=b.stage)))b=Object.assign({},s.best);
  for(const s of p.slots)if(s)b.score=Math.max(b.score,s.best.score);return b;}

// ---------------------------------------------------------------- overlay shell
let root,cv,ctx,panel,hud,info,bossEl,banner;
const CAMP_SHOP=false;   /* 0.12.37 (Kyle): Merchant and Backpack hidden on the camp screen for now (flip to true to bring them back) */
function build(){
  if(root)return;if(!document.getElementById('cc-style')){const st=document.createElement('style');st.id='cc-style';st.textContent=CSS;document.head.appendChild(st);}
  root=document.createElement('div');root.id='cc';root.hidden=true;root.setAttribute('role','dialog');root.setAttribute('aria-label','Crypt Crawl');
  root.innerHTML=`<div class="cc-top"><span class="t">⚰️ CRYPT CRAWL <span style="color:#6a5a7a;font-size:8px">v0.12.284</span></span>
    <button class="cc-ib" data-a="restart" title="Restart this stage from its save point" hidden>↺</button><button class="cc-ib" data-a="pause" title="Pause">⏸</button><button class="cc-ib" data-a="speed" title="Game speed">1×</button>
    <button class="cc-ib" data-a="brain" title="Show what every unit is thinking">🧠</button><button class="cc-ib" data-a="mute" title="Sound effects">${muted?'🔇':'🔊'}</button><button class="cc-ib" data-a="music" title="Music on/off">${musicMuted?'🎵̸':'🎵'}</button><button class="cc-ib" data-a="track" title="Next track (now: ${TRACKS[trackI].name})">⏭</button><input class="cc-vol" data-vol type="range" min="0" max="100" value="${Math.round(musicVol*100)}" title="Music volume"><button class="cc-ib" data-a="zoom" title="Zoom (Auto: closer camera on phones)">🔍</button><button class="cc-ib" data-a="side" title="Turn sideways (phones held upright)">⟳</button><button class="cc-ib" data-a="fs" title="Full screen">⛶</button><button class="cc-ib" data-a="close" title="Close">✕</button></div>
    <div class="cc-main"><div class="cc-info"></div><div class="cc-cvw"><div class="cc-uf"></div><canvas id="cc-cv" width="${384*RES*GQ}" height="${216*RES*GQ}"></canvas></div><div class="cc-boss"></div><div class="cc-banner"></div><div class="cc-hud"></div><div class="cc-panel"></div></div>`;
  document.body.appendChild(root);
  cv=$('#cc-cv',root);ctx=cv.getContext('2d');cv.addEventListener('pointerdown',radioClick);panel=$('.cc-panel',root);hud=$('.cc-hud',root);info=$('.cc-info',root);bossEl=$('.cc-boss',root);banner=$('.cc-banner',root);
  root.addEventListener('click',e=>{const b=e.target.closest('[data-a]');if(!b)return;const a=b.dataset.a;
    if(a==='close')closeCrawl();
    if(a==='restart'&&CC.game){if(!confirmInline(b,'↺?'))return;CC.game=null;cancelAnimationFrame(CC.raf);persist();beginStage();}
    if(a==='pause'){CC.paused=!CC.paused;b.textContent=CC.paused?'▶':'⏸';}
    if(a==='speed'){CC.speed=CC.speed%3+1;b.textContent=CC.speed+'×';}
    if(a==='brain'){CC.brain=!CC.brain;b.classList.toggle('on',CC.brain);b.style.outline=CC.brain?'2px solid #b6ff00':'';}
    if(a==='music'){musicMuted=!musicMuted;b.textContent=musicMuted?'🎵̸':'🎵';b.style.opacity=musicMuted?.5:1;try{localStorage.setItem('podrundown-crawl-music-mute',musicMuted?'1':'0');}catch(_){}musicStart();}
    if(a==='track'){const T=musicNext();b.title=`Next track (now: ${T.name})`;flash('♫ '+T.name+' · '+T.info+' · '+T.by,2400);}
    if(a==='mute'){muted=!muted;b.textContent=muted?'🔇':'🔊';try{localStorage.setItem('podrundown-crawl-mute',muted?'1':'0');}catch(_){}}
    if(a==='fs'){if(window.PodSideways)PodSideways.goBig(root);setTimeout(layout,120);}
    if(a==='zoom'){const L=[0,1,1.5,2];CAMZ=L[(L.indexOf(CAMZ)+1)%L.length];try{localStorage.setItem('cc-zoom',String(CAMZ));}catch(e){}b.title='Zoom: '+(CAMZ?CAMZ+'×':'Auto');b.textContent=CAMZ?CAMZ+'×':'🔍';layout();}
    if(a==='side'){if(window.PodSideways){PodSideways.sidewaysPref(!root.classList.contains('rot-side'));PodSideways.fitSideways(root);}setTimeout(layout,60);}});
  {const vs=root.querySelector('[data-vol]');if(vs)vs.oninput=()=>{musicVol=vs.value/100;try{localStorage.setItem('podrundown-crawl-music-vol',musicVol);}catch(_){}if(BGM)BGM.volume=musicVol;if(musicVol>0&&!musicMuted)musicStart();else if(BGM)BGM.pause();};}
  document.addEventListener('keydown',e=>{if(root.hidden)return;if(e.key==='Escape'&&!document.fullscreenElement)closeCrawl();if(e.key===' '&&CC.game){e.preventDefault();CC.paused=!CC.paused;}});
  window.addEventListener('resize',()=>{if(window.PodSideways&&root&&!root.hidden)PodSideways.fitSideways(root);layout();});document.addEventListener('fullscreenchange',()=>setTimeout(layout,60));
}
/* 0.12.56 (Kyle): phones get a closer camera. The fight happens in the bottom fifth of the picture, so on a phone we
   blow the picture up and crop: sideways phones fill the width and lose some sky; upright phones zoom 2x and the camera follows the party.
   Desktop is unchanged (Auto = whole field). The 🔍 button cycles Auto / 1x / 1.5x / 2x. */
let CAMZ=(()=>{try{return +(localStorage.getItem('cc-zoom')||0)||0;}catch(e){return 0;}})(),CAM={sc:1,vw:0,vh:0,cw:0,ch:0,on:false,x:null};
const handset=()=>!!(window.PodSideways&&PodSideways.isPhone());
function layout(){if(!root||root.hidden)return;root.classList.toggle('phone',handset());const main=$('.cc-main',root);const W=main.clientWidth,H=main.clientHeight;const wrap=$('.cc-cvw',root);
  const land=W>H*1.25&&H<620;root.classList.toggle('land',land);
  hud.classList.toggle('tall',!land&&H>W*1.2);
  const reserved=land?0:(info.offsetHeight+hud.offsetHeight+4);const avH=Math.max(120,H-reserved);let w=Math.min(W,avH*16/9);
  const k=Math.floor(w/384);if(k>=2&&k*384>=w*.82)w=k*384;
  let z=CAMZ||(handset()?(land?'fill':2):1);
  let cw=w,ch=w*9/16,vw=w,vh=ch;
  if(z==='fill'){cw=W;ch=W*9/16;vw=W;vh=Math.min(ch,avH);}
  else if(z>1){cw=w*z;ch=cw*9/16;vw=Math.min(W,cw);vh=Math.min(avH,ch);}
  cw=Math.floor(cw);ch=Math.floor(ch);vw=Math.floor(vw);vh=Math.floor(vh);
  CAM.on=cw>vw+1||ch>vh+1;CAM.sc=cw/384;CAM.vw=vw;CAM.vh=vh;CAM.cw=cw;CAM.ch=ch;if(!CAM.on)CAM.x=null;
  wrap.classList.toggle('cam',CAM.on);wrap.style.width=vw+'px';wrap.style.height=vh+'px';
  cv.style.width=cw+'px';cv.style.height=ch+'px';panCam();
  bossEl.style.top=(wrap.offsetTop+vh*.06)+'px';banner.style.top=(wrap.offsetTop+vh*.38)+'px';}
/* keep the party (and a bit of what's ahead of them) in view; always keep the ground at the bottom */
function panCam(){if(!CAM.on){cv.style.left='0px';cv.style.top='0px';return;}const g=CC.game;const sc=CAM.sc;
  let fx=192;if(g&&g.heroes){const al=g.heroes.filter(h=>h.alive);if(al.length){const xs=al.map(h=>h.x);fx=(Math.min(...xs)+Math.max(...xs))/2+55;}}
  CAM.x=CAM.x==null?fx:CAM.x+(fx-CAM.x)*.08;
  const L=Math.max(CAM.vw-CAM.cw,Math.min(0,CAM.vw/2-CAM.x*sc)),T=CAM.vh-CAM.ch;
  cv.style.left=Math.round(L)+'px';cv.style.top=Math.round(T)+'px';}
function openCrawl(){build();root.hidden=false;musicStart();document.body.style.overflow='hidden';stopStrip();if(window.PodSideways)PodSideways.fitSideways(root);CC.data=Save.load();for(const p in CC.data.players)for(const s of CC.data.players[p].slots||[])if(s)migrateSlot(s,p);Save.write(CC.data);showWho();layout();}
function closeCrawl(){musicStop();if(CC.game&&!CC.game.over)quitToCamp(true);CC.game=null;cancelAnimationFrame(CC.raf);root.hidden=true;document.body.style.overflow='';try{if(document.fullscreenElement)document.exitFullscreen();}catch(e){}startStrip();}
function showPanel(html){installTips();const wy=window.scrollY,wx=window.scrollX,same=!panel.hidden&&panel._k===html.slice(0,80),pt=panel.scrollTop;panel._k=html.slice(0,80);panel.hidden=false;const rb=root.querySelector('[data-a=restart]');if(rb)rb.hidden=true;panel.innerHTML=`<div class="cc-wrap">${html}</div>`;panel.scrollTop=same?pt:0;window.scrollTo(wx,wy);requestAnimationFrame(()=>{if(Math.abs(window.scrollY-wy)>2)window.scrollTo(wx,wy);});   // 0.12.80: re-rendering a screen (feeding, buttons) no longer jumps the page scroll
  hud.innerHTML='';info.innerHTML='';bossEl.textContent='';drawIdle();return panel;}
function drawIdle(){const g=CC.idle||(CC.idle=demoGame(384));ctx.imageSmoothingEnabled=false;if(IMG.complete&&BGI.complete)drawGame(ctx,g,384,0);}
// ---------------------------------------------------------------- screens
function showWho(){
  const rows=Object.keys(OWNERS).map(p=>{const b=bestOf(p);return {p,b};}).sort((a,b)=>(b.b.prestige*100+b.b.stage)-(a.b.prestige*100+a.b.stage)||b.b.score-a.b.score);
  const P=showPanel(`<div class="cc-h">⚰️ CRYPT CRAWL</div><p class="cc-sub">Your deck heroes march through the crypt on their own. You pick the team, the upgrades and when to push on. For now it's one endless stretch of Blackwater Lake. Fall and you keep everything, so you can always grind your way past a tough stage.</p>
  <div class="cc-who">${Object.keys(OWNERS).map(p=>{const b=bestOf(p);const has=CC.data.players[p]&&CC.data.players[p].pin;
    return `<button data-p="${p}"><div class="e">${OWNERS[p]}</div><div class="nm px">${p}</div><div class="cc-sub" style="margin:0">${b.stage?`Best stage ${b.stage}${b.prestige?' ★'+b.prestige:''}`:''}</div></button>`;}).join('')}</div>
  <div class="cc-h" style="margin-top:18px;font-size:12px">🏆 LEADERBOARD</div>
  <table class="cc-lb"><tr><th>Player</th><th>Furthest</th><th>Best score</th></tr>${rows.map(r=>`<tr><td>${OWNERS[r.p]} ${r.p}</td><td>${r.b.stage?`Stage ${Math.min(r.b.stage,CFG.maxStage)}${r.b.prestige?' · Prestige '+r.b.prestige:''}`:'—'}</td><td>${r.b.score?fmt(r.b.score):'—'}</td></tr>`).join('')}</table>
  <details style="margin-top:14px"><summary class="cc-sub" style="cursor:pointer">How it works</summary><p class="cc-sub">Each player has 5 save files. Hero levels, gold and items stay with the save, and nothing is lost when the party falls. Lower-level heroes earn catch-up XP. Between stages you camp: spend level-ups, then press Begin. Beat stage ${CFG.maxStage} to Prestige and loop with tougher monsters.</p></details>`);
  P.querySelectorAll('[data-p]').forEach(b=>b.onclick=()=>{CC.player=b.dataset.p;CC.unlocked[CC.player]=1;showSlots();});   /* 0.12.86 (Kyle): no PIN for now */
}
function showPin(){
  const p=PL();const setting=!p.pin;let entry='',first=null;
  const draw=()=>{const P=showPanel(`<div class="cc-h">${OWNERS[CC.player]} ${CC.player.toUpperCase()}</div><p class="cc-sub">${setting?(first?'Type it again to confirm.':'Pick a 4-digit PIN. It keeps your saves yours.'):'Enter your PIN.'}</p>
    <div class="cc-dots">${[0,1,2,3].map(i=>`<i class="${i<entry.length?'on':''}"></i>`).join('')}</div>
    <div class="cc-pin">${[1,2,3,4,5,6,7,8,9,'⌫',0,'↩'].map(k=>`<button data-k="${k}">${k}</button>`).join('')}</div>
    <p class="cc-sub" style="text-align:center">PINs are saved on this device only. Forgot yours? Kyle can reset it from his saves screen.</p>`);
    P.querySelectorAll('[data-k]').forEach(b=>b.onclick=()=>key(b.dataset.k));};
  const bad=()=>{const d=$('.cc-dots',panel);d.classList.remove('bad');void d.offsetWidth;d.classList.add('bad');};
  const key=k=>{if(k==='↩')return showWho();if(k==='⌫'){entry=entry.slice(0,-1);return draw();}if(entry.length<4)entry+=k;draw();
    if(entry.length===4)setTimeout(()=>{if(setting){if(!first){first=entry;entry='';draw();}else if(first===entry){p.pin=Save.pinHash(CC.player,entry);persist();CC.unlocked[CC.player]=1;showSlots();}else{first=null;entry='';draw();bad();}}
      else if(Save.pinHash(CC.player,entry)===p.pin){CC.unlocked[CC.player]=1;showSlots();}else{entry='';draw();bad();}},120);};
  draw();
}
function showSlots(){
  const p=PL();
  const P=showPanel(`<div class="cc-h">${OWNERS[CC.player]} ${CC.player.toUpperCase()} · SAVES</div><p class="cc-sub">Five separate games. Try different hero combos in each.</p>
  <div class="cc-load">${p.slots.map((s,i)=>{if(!s)return `<div class="cc-card"><b>Save ${i+1}</b> · empty<div class="cc-row" style="margin-top:8px"><button class="cc-btn go" data-new="${i}">NEW SAVE</button></div></div>`;
    migrate(s,CC.player);if(!s.team&&s.run)s.team=s.run.team.slice();const top=Object.entries(s.heroes).sort((a,b)=>b[1].lvl-a[1].lvl).slice(0,4).map(([k,v])=>`${heroDef(k).icon} ${esc(heroDef(k).name)} <b>Lv ${v.lvl}</b>`).join(' · ');
    return `<div class="cc-card"><b>Save ${i+1}</b> · 💰 ${fmt(s.gold||0)} · best stage ${s.best.stage||0}${s.best.prestige?' ★'+s.best.prestige:''} · best score ${fmt(s.best.score)} · ${s.runs} runs
      ${s.run?`<div class="cc-sub" style="margin:0 0 6px">Run in progress: stage ${s.run.stage}${s.run.prestige?' ★'+s.run.prestige:''} with ${s.run.team.map(k=>esc(heroDef(k).name)).join(', ')}</div>`:''}
      <div class="cc-row">${s.run||(s.team&&s.team.length)?`<button class="cc-btn go" data-cont="${i}">CONTINUE</button>`:`<button class="cc-btn go" data-team="${i}">BEGIN</button>`}${s.run||(s.team&&s.team.length)||s.runs?`<button class="cc-btn warn" data-del="${i}">Delete</button>`:''}</div></div>`;}).join('')}</div>
  <div class="cc-row" style="margin-top:12px"><button class="cc-btn" data-back>← Players</button></div>`);
  P.querySelector('[data-back]').onclick=showWho;
  P.querySelectorAll('[data-reset]').forEach(b=>b.onclick=()=>{const who=b.dataset.reset;if(!confirmInline(b,`Reset ${who}'s PIN?`))return;CC.data.players[who].pin=null;delete CC.unlocked[who];persist();
    if(who==='Kyle'){CC.unlocked.Kyle=0;return showPin();}showSlots();});
  P.querySelectorAll('[data-new]').forEach(b=>b.onclick=()=>{p.slots[+b.dataset.new]=newSlot(CC.player);persist();CC.slotIdx=+b.dataset.new;showTeam();});
  P.querySelectorAll('[data-cont]').forEach(b=>b.onclick=()=>{const i=+b.dataset.cont,S=p.slots[i];CC.slotIdx=i;if(S.run)showCamp();else restartSameTeam(S,S.team);});   /* 0.12.171: Continue picks the run back up, or starts the next run with the save's team */
  P.querySelectorAll('[data-team]').forEach(b=>b.onclick=()=>{const i=+b.dataset.team,S=p.slots[i];CC.slotIdx=i;if(S.run)return;if(S.team&&S.team.length)restartSameTeam(S,S.team);else showTeam();});
  P.querySelectorAll('[data-del]').forEach(b=>b.onclick=()=>{if(!confirmInline(b,'Delete forever?'))return;p.slots[+b.dataset.del]=null;persist();showSlots();});
}
function confirmInline(b,msg){if(b.dataset.armed)return true;b.dataset.armed=1;const t=b.textContent;b.textContent=msg+' Tap again';setTimeout(()=>{if(b.isConnected){delete b.dataset.armed;b.textContent=t;}},2600);return false;}
/* 0.12.57 (Kyle): PWR and SPD used the old flat atk/aspd numbers, which are the same for every hero now that damage comes from dice.
   PWR is now his best basic attack's damage per second (dice, flat bonus, pellets, crit), SPD how many basic attacks he gets off per second.
   Both are scaled against the best in the roster so the bars spread out. */
function atkProfile(k){const C=CHAR[k]||{};let best={dps:0,rate:0};
  for(const [nm,A] of Object.entries(C)){if(!A||typeof A!=='object'||!Array.isArray(A.dice)||!(A.every>0))continue;
    const avg=(A.dice[0]*(A.dice[1]+1)/2+(A.flat||0))*(1+((A.pellets||1)-1)*.5);/* pellets spread wide: count about half of the extras as landing */const clip=A.clip||1,cyc=clip>1?((clip-1)*A.every+(A.reload||A.every))/clip:A.every;
    const dps=avg/cyc*(1+(C.crit||0)*((C.critMul||1.75)-1));const r=best.rate;if(dps>best.dps)best={dps,rate:r,nm,avg};best.rate=Math.max(best.rate,1/cyc);}
  return best;}
function statBars(k,lvl){const b=heroBase(k,lvl,3);const mx={hp:80};const HE=Object.keys(CHAR).filter(x=>x!=='dog');const P=atkProfile(k);
  const mxD=Math.max(...HE.map(x=>atkProfile(x).dps)),mxR=Math.max(...HE.map(x=>atkProfile(x).rate));
  return `<div class="cc-stat"><span title="${b.stamina} Stamina × 5 = ${b.hp} HP">HP ${b.hp}</span><i><b style="width:${Math.min(100,b.hp/mx.hp*100)}%"></b></i><span title="Basic attack damage per second: about ${P.dps.toFixed(1)} (${P.nm||'basic'}: ${(P.avg||0).toFixed(1)} a hit, crit ${Math.round(b.crit*100)}%, accuracy ${b.acc||0}). Abilities not counted.">PWR</span><i><b style="width:${Math.max(8,P.dps/mxD*100).toFixed(0)}%"></b></i><span title="About ${P.rate.toFixed(2)} basic attacks a second">SPD</span><i><b style="width:${Math.max(8,P.rate/mxR*100).toFixed(0)}%"></b></i></div>`;}
const ROLE={melee:'Melee',ranged:'Ranged',caster:'Caster',duo:'Duo',gunner:'Rifle + Melee',blade:'Sword'};
/* 0.12.170 (Kyle): a save keeps one team for good. The party is picked once, when the save is made; later runs restart with that same team. */
function restartSameTeam(s,team){for(const k of team){const H=s.heroes[k];if(H){H.lvl=1;H.xp=0;H.pts={};H.tal=[];H.offer=null;}}s.run=newRun(team,s);const M=s.lastModes||{};s.run.hardcore=!!M.hardcore;s.run.dnd=!!M.dnd;if(s.run.dnd)s.run.rolls=rollPersonas(team);s.runs++;persist();showCamp();}
function showTeam(){
  setRunModes(null);  const s=SLOT();migrate(s,CC.player);s.partySize=3;const pick=[];   /* 0.12.33: back to a 3-hero party */
  const mine=DATA.heroes.slice();   /* 0.12.92: every player uses the shared roster */
  const P=showPanel(`<div class="cc-h">PICK YOUR PARTY</div><p class="cc-sub">Up to 3 heroes from your decks. Fewer heroes = each one is stronger. Lower-level heroes earn catch-up XP.</p>
    <div class="cc-heroes">${mine.map(h=>{const st=STYLE[h.key];const H=s.heroes[h.key],L=H.lvl;const tip=[h.name,'',BEHAVIOR[h.key]||h.blurb||'','',...personaLines({key:h.key,insp:H.insp})].join('\n');
      const sp=h.spells[0];return `<div class="cc-hw"><button class="cc-hero" data-k="${h.key}" aria-pressed="false" data-tiph="${esc(howTip(h.key,H.insp))}"><span class="ord"></span><span class="por" data-por="${h.key}"></span><div class="nm">${h.icon} ${esc(h.name)}</div>${h.deck?`<div class="dk">Built from deck: <b>${esc(h.deck)}</b></div>`:''}<div class="dk">${(CHAR[h.key]&&CHAR[h.key].role)||ROLE[st.atk]}${st.tank?' · Tank':''}${st.companion?' · with companion':''}</div>
      <div class="lv">LV ${L}</div><div class="dk">🧠 Personality: <b>${esc(personaTitle({key:h.key,insp:H.insp}))}</b> <span style="opacity:.7">(hover the card for how it fights)</span></div>${statBars(h.key,L)}<div class="cc-abl">${abOrder((CHAR[h.key]||{}).abilities).map(a=>`<span class="cc-ab${a.passive?' pas':''}" tabindex="0" data-tiph="${esc('<div class=tt-h>'+(a.passive?'✦ ':'⚡ ')+esc(a.name.replace(/_/g,' '))+(a.passive?' <span style=opacity:.7>(passive)</span>':'')+'</div>'+fmtAbil(ABIL_DESC[a.id]||a.name))}">${a.passive?'✦':'⚡'} ${esc(a.name)}</span>`).join('')||'<span class="dk" style="opacity:.6">No abilities yet</span>'}</div>${sp?`<div class="dk" style="margin-top:2px">Starts with ${esc(sp.name||shortCard(sp.card))} (${SPELL[sp.arch].label})</div>`:''}</button>
      <div class="cc-insp" data-ik="${h.key}"><div class="cc-sub" style="margin:4px 0 2px;font-size:10px">✨ INSPIRATION DECK</div>
        <select data-ip><option value="">Pick a player…</option>${Object.keys(PLAYER_ICON).map(p=>`<option value="${p}"${H.insp&&INSP[H.insp]&&INSP[H.insp].o===p?' selected':''}>${PLAYER_ICON[p]} ${p}</option>`).join('')}</select>
        <select data-id ${H.insp?'':'disabled'}></select><div class="cc-ibx"></div></div></div>`;}).join('')}</div>
    <div class="cc-row" style="margin-top:12px"><label class="cc-sub" style="margin:0 8px 0 0;font-size:12px;cursor:pointer" data-tipt="Friendly fire: your heroes' shots can hit allies in the way, and your own explosions (Trip Bomb, its shockwave, missiles, planted mines) hurt your units too."><input type="checkbox" data-hc ${s.lastModes&&s.lastModes.hardcore?'checked':''}> ☠ Hardcore</label><label class="cc-sub" style="margin:0 10px 0 0;font-size:12px;cursor:pointer" data-tipt="Every hero's 20 personality sliders are rolled (2d6-2 each) when the run starts instead of using their fixed values. Deck nudges still apply on top."><input type="checkbox" data-dnd ${s.lastModes&&s.lastModes.dnd?'checked':''}> 🎲 D&amp;D mode</label><button class="cc-btn go" data-go disabled>START RUN</button><button class="cc-btn" data-back>← Saves</button></div>`);
  P.querySelectorAll('[data-por]').forEach(e=>e.replaceWith(portrait(e.dataset.por)));
  // Inspiration: player first, then that player's decks (each option shows its bonus). Saved per hero on this save slot.
  P.querySelectorAll('.cc-insp').forEach(box=>{const k=box.dataset.ik,H=s.heroes[k];const ip=box.querySelector('[data-ip]'),id=box.querySelector('[data-id]'),ib=box.querySelector('.cc-ibx');
    const fill=()=>{const p=ip.value;id.disabled=!p;id.innerHTML=p?`<option value="">Pick a deck…</option>`+Object.keys(INSP).filter(d=>INSP[d].o===p).map(d=>`<option value="${esc(d)}"${H.insp===d?' selected':''}>${esc(d)}: ${esc(inspText(d))}</option>`).join(''):'<option>Pick a player first</option>';show();};
    const show=()=>{const d=H.insp;ib.innerHTML=d&&INSP[d]?`<b>${esc(d)}</b>: ${esc(inspText(d))}<br><span style="opacity:.7">${esc(INSP[d].why)}</span><ul style="margin:4px 0 0;padding-left:14px">${inspHelp(d).map(t=>`<li style="margin-top:2px">${esc(t)}</li>`).join('')}</ul>${cdrTable(k,d)}`:'<span style="opacity:.6">No inspiration yet</span>';
      const b=box.parentNode.querySelector('.cc-hero');if(b){b.dataset.tiph=howTip(k,H.insp);const pt=b.querySelector('.dk b');if(pt)pt.textContent=personaTitle({key:k,insp:H.insp});const t=b.querySelector('.dk b');}};
    ip.onchange=()=>{if(!ip.value||(H.insp&&INSP[H.insp]&&INSP[H.insp].o!==ip.value)){H.insp=null;persist();}fill();};
    id.onchange=()=>{H.insp=id.value||null;persist();show();};fill();});
  const upd=()=>{P.querySelectorAll('.cc-hero').forEach(b=>{const i=pick.indexOf(b.dataset.k);b.setAttribute('aria-pressed',i>=0);b.querySelector('.ord').textContent=i>=0?i+1:'';});
    const g=P.querySelector('[data-go]');g.disabled=!pick.length;g.textContent=`START RUN (${pick.length}/${s.partySize||2})`;};
  P.querySelectorAll('.cc-hero').forEach(b=>b.onclick=()=>{const k=b.dataset.k,i=pick.indexOf(k);if(i>=0)pick.splice(i,1);else if(pick.length<(s.partySize||3))pick.push(k);upd();});
  P.querySelector('[data-back]').onclick=showSlots;
  P.querySelector('[data-go]').onclick=()=>{s.team=pick.slice();s.run=newRun(pick,s);s.lastModes={hardcore:!!P.querySelector('[data-hc]').checked,dnd:!!P.querySelector('[data-dnd]').checked};s.run.hardcore=s.lastModes.hardcore;s.run.dnd=s.lastModes.dnd;if(s.run.dnd)s.run.rolls=rollPersonas(pick);s.runs++;persist();showCamp();};upd();
}
function rankStars(r){return r>=CFG.maxRank?'<span class="cc-asc">✦ MAX ✦</span>':'<span class="cc-stars">'+'★'.repeat(Math.min(5,Math.ceil(r/2)))+'</span> <span class="cc-sub" style="font-size:11px">r'+r+'</span>';}
function chipFor(e,item,hk){const base=item?shortCard(e.card):sname(hk,e.card);const name=e.r>=CFG.maxRank?`✦ ${esc(maxTitle(e.card,e.arch))}`:esc(base);
  return `<span class="cc-chip ${item?'it':''}" title="${item?esc(e.card):'Inspired by '+esc(e.card)}"><b>${name}</b> · ${item?ITEM[e.arch].label:SPELL[e.arch].label} r${e.r}${(e.augs||[]).map(g=>' +'+AUG[g].name).join('')}${item?' · GS '+gearScore(e):''}${item&&e.proc?' · ✦ '+({onhit:'on hit',oncrit:'on crit',onkill:'on kill',whenhit:'when hit',near:'when close',allylow:'ally low',oncast:'on cast'}[PROCS[e.proc].t]||''):''}</span>`;}
/* camp panel: supplies, what the camp did on arrival, upgrades (pick 1 of the offers per camp), Triage builds */
function campPanel(s,run,btn){const gold=s.gold||0,parts=s.parts||0;const food=run.food||0;run.haggle=haggleOf(s,run);run.resource=resourcefulOf(s,run);
  const owned=Object.keys(run.upg||{}).filter(id=>run.upg[id]);
  const tent=`<span class="cc-tent" style="cursor:help;font-size:18px;margin-left:6px;display:inline-flex;align-items:center;gap:3px;padding:1px 6px;border:1px dashed #a6ff2e88;border-radius:10px;animation:ccTentPulse 2.2s ease-in-out infinite" data-tiph="${esc('<b>⛺ Every camp upgrade</b><br>'+Object.keys(CAMP_UPG).map(id=>{const U=CAMP_UPG[id],t=upgT(run,id);const mx=U.needs?(Object.keys(U.needs).every(k=>upgT(run,U.needs[k])>0)?U.tiers.length:U.tiers.length-1):U.tiers.length;return `${U.icon} ${U.name}: <b style="color:${t?'#a6ff2e':'#9a90a8'}">${t}/${mx}</b> <span style="opacity:.6">(${U.tiers.map(g=>Math.max(25,Math.round(g*(1-(run.haggle||0))*.75/25)*25)+'g').join(' / ')})</span>`;}).join('<br>')+(run.haggle?`<br><br>🤝 Haggler: upgrades ${Math.round(run.haggle*100)}% off`:'')+(run.resource?`<br>🧰 Resourceful: you can pay in spare parts`:''))}">⛺<span style="font-size:10px;color:#a6ff2e">ⓘ</span></span>`;
  const sup=`<div class="cc-card"><b>🏕️ Camp</b>${tent} <span class="cc-sub" style="font-size:12px">💰 <b style="color:#ffd23f">${fmt(gold)}</b> gold · ⚙️ <b>${parts}</b> spare parts · 🥫 <b>${Number.isInteger(food)?food:Math.floor(food)+'½'}</b> food · 💧 <b>${run.water||0}</b> water · <span title="Reroll dice (max 3): swap the camp upgrade offers or a hero's ⬆ Upgrade picks. Every stage you finish, won or lost, charges 25% of a die." style="cursor:help">${diceStr(run)}</span>${(s.lucky||0)?` · <span title="Lucky Dice: very rare loot. Spend one on a hero (button on their card) to gamble a basic attack's die size." style="cursor:help">${luckyStr(s)}</span>`:''}</span>${run.team.some(k=>missingOf(run,k)&&run.heroes[k]&&!run.heroes[k].dead)?` <button class="cc-btn" data-feedall style="padding:2px 8px;font-size:12px;vertical-align:middle" title="Feed and water everyone who needs it: most-needy and lowest HP first, never wastes supplies"><svg width="16" height="14" viewBox="0 0 16 14" style="vertical-align:-2px;image-rendering:pixelated"><rect x="1" y="5" width="7" height="8" fill="#b8642a"/><rect x="1" y="5" width="7" height="2" fill="#e8d0a0"/><rect x="2" y="8" width="5" height="3" fill="#e8302a"/><rect x="1" y="12" width="7" height="1" fill="#6a3a18"/><path d="M12 2 L14.5 7 A2.6 2.6 0 1 1 9.5 7 Z" fill="#4ab8ff"/><rect x="10.5" y="7" width="1" height="2" fill="#d8f4ff"/></svg> Feed all</button>`:''}
    ${(run.campLog||[]).length?`<div class="cc-sub" style="font-size:11px;margin:4px 0 0">${run.campLog.map(esc).join(' · ')}</div>`:''}
    ${owned.length?`<div class="cc-chips" style="margin-top:6px">${owned.map(id=>{const U=CAMP_UPG[id],t=run.upg[id];return `<span class="cc-chip" title="${esc(U.txt(t))}">${U.icon} ${esc(U.name)} ${['','I','II','III','IV'][t]}</span>`;}).join('')}</div>`:''}</div>`;
  const picked=run.picked||[];const offers=(run.offers||[]).filter(id=>picked.includes(id)||upgT(run,id)<CAMP_UPG[id].tiers.length);   /* 0.12.190 (Kyle): buy any or all of the 3 picks you can afford (each once per camp) */
  const up=`<div class="cc-card"><b>🔨 Camp upgrades</b> <span class="cc-sub" style="font-size:11px">${run.upgBought?`Buy any of the others you can still afford. New offers next camp.`:'Buy any or all of them you can afford, at the pick price.'} They last for this run.</span>${offers.length?(run.rerolls>=1?` <button class="cc-btn" data-reroll style="margin-left:6px;padding:2px 8px;font-size:11px" data-tipt="Spend 1 die: swap these 3 picks for 3 new ones. What you built stays built.">🎲 Reroll · ${diceStr(run)}</button>`:` <span class="cc-sub" style="font-size:11px;opacity:.7">${diceStr(run)}</span>`):''}
    <div class="cc-offers" style="margin-top:8px">${offers.map(id=>{const U=CAMP_UPG[id],t=upgT(run,id)+1,pr=upgPrice(run,id);return `<div class="cc-offer" style="--rc:${t>1?'#7fd0ff':'#a6ff2e'}"><span class="rar">${t>1?'TIER '+t:'NEW'}</span><span class="cn">${U.icon} ${esc(U.name)}${U.tiers.length>1?' '+['','I','II','III','IV'][t]:''}</span><span class="tx">${esc(U.txt(t))}</span>
      ${picked.includes(id)?`<button class="cc-btn" disabled>✓ Built</button>`:`<button class="cc-btn" data-upg="${id}" ${gold<pr?'disabled':''}>Build · ${fmt(pr)}g</button>${run.resource?`<button class="cc-btn" data-upgp="${id}" style="margin-top:4px" ${parts<upgParts(run,id)?'disabled':''}>Build · ⚙️ ${upgParts(run,id)} parts</button>`:''}`}</div>`;}).join('')||'<span class="cc-sub">Everything is fully built!</span>'}</div></div>`;
  const cl=conList(run);const con=`<div class="cc-card" style="border-color:#ffb020;box-shadow:0 0 0 1px #ffb02055,0 0 14px #ffb02033"><b>🏗️ Construction</b> <span class="cc-sub" style="font-size:11px">Build anything, as many as you like this camp, at <b>double</b> the pick price.</span>
    <button class="cc-btn" data-con style="margin-left:8px;background:#ffb020;color:#1a1000;font-weight:800">${run.conOpen?'▲ HIDE':'🏗️ OPEN CONSTRUCTION'}</button>
    ${run.conOpen?`<div class="cc-offers" style="margin-top:8px">${cl.map(id=>{const U=CAMP_UPG[id],t=upgT(run,id)+1,pr=conPrice(run,id);return `<div class="cc-offer" style="--rc:#ffb020"><span class="rar">${t>1?'TIER '+t:'NEW'}</span><span class="cn">${U.icon} ${esc(U.name)}${U.tiers.length>1?' '+['','I','II','III','IV'][t]:''}</span><span class="tx">${esc(U.txt(t))}</span>
      <button class="cc-btn" data-conb="${id}" ${gold<pr?'disabled':''}>Build · ${fmt(pr)}g</button>${run.resource?`<button class="cc-btn" data-conp="${id}" style="margin-top:4px" ${parts<conParts(run,id)?'disabled':''}>Build · ⚙️ ${conParts(run,id)} parts</button>`:''}</div>`;}).join('')||'<span class="cc-sub">Everything is fully built!</span>'}</div>`:''}</div>`;
  const tt=upgT(run,'triage');const tri=tt?`<div class="cc-card"><b>🩺 Triage Station ${['','I','II','III','IV'][tt]}</b> <span class="cc-sub" style="font-size:11px">${(run.triageN||0)}/${TRIAGE.max[tt-1]} built this camp · whoever you pick carries it into the next stage</span>
    ${[['med','Medkit','heals an ally under 50% for 35%'],['defib','Defibrillator','instantly revives a downed ally']].concat(run.team.includes('robot')?[['bat','Battery','+30 energy for the Warhound when he runs low']]:[]).map(([w,n,d])=>`<div class="cc-chips" style="align-items:center;margin-top:4px"><span class="cc-sub" style="font-size:11px;margin:0;min-width:180px"><b>${n}</b> · ⚙️ ${TRIAGE[w][tt-1]} · ${d}</span>${run.team.map(k=>btn(`data-tri="${w}|${k}" ${parts<TRIAGE[w][tt-1]||(run.triageN||0)>=TRIAGE.max[tt-1]?'disabled':''}`,'→ '+esc(heroDef(k).name.split(/[ _]/)[0]),'Build it for '+heroDef(k).name)).join(' ')}</div>`).join('')}</div>`:'';
  const tw=upgT(run,'tower');if(tw&&!run.scoutOffers)run.scoutOffers=scoutRoll(run);
  const tower=tw?`<div class="cc-card"><b>🗼 Watchtower ${['','I','II','III','IV'][tw]}</b> <span class="cc-sub" style="font-size:11px">Scouts report on the road ahead. ${tw>=4?'MAP TABLE: pick up to TWO roads for the next stage.':'Pick one for the next stage.'}</span>
    <div class="cc-offers" style="margin-top:8px">${(run.scoutOffers||[]).map(id=>{const S=SCOUT[id],on=[].concat(run.scoutPick||[]).includes(id);return `<div class="cc-offer" style="--rc:${on?'#a6ff2e':'#7fd0ff'}"><span class="cn">${S.icon} ${esc(S.name)}</span><span class="tx">${esc(S.txt(tw>=3?1.5:1))}</span><button class="cc-btn" data-scout="${id}" ${on&&tw<4?'disabled':''}>${on?(tw>=4?'Chosen ✓ (tap to drop)':'Chosen ✓'):'Take this road'}</button></div>`;}).join('')}</div></div>`:'';
  const rd=upgT(run,'radio');const radio=rd?(()=>{const F=radioForecast(run);return `<div class="cc-card"><b>📻 Radio Shack ${['','I','II'][rd]}</b> <span class="cc-sub" style="font-size:11px">Chatter about stage ${run.stage}: about <b>${F.foes}</b> undead in <b>${F.waves}</b> waves${F.wolves?' · 🐺 werewolves':''}${F.firemen?' · 🧑‍🚒 firemen':''}<br>🔋 Everyone starts the stage at full energy · first wave: ALERT (+10 accuracy)${rd>=2?' · ALERT on every wave · 📦 a supply drop halfway (food, water, 2 parts)':''}</span></div>`;})():'';   /* 0.12.105 */
  const stl=upgT(run,'still');const sF=[2,1.5,1,1][stl-1];const still=stl?`<div class="cc-card"><b>🫙 Moonshine Still ${['','I','II','III','IV'][stl]}</b> <span class="cc-sub" style="font-size:11px">A jar costs 🥫 ${sF} food + 💧 1 water, one for anyone you can afford · +20% damage, +10% attack speed, ${stl>=4?'15%':'10%'} less damage taken, ${stl>=4?'-15%':'-20%'} accuracy, steadier nerves until ${stl>=4?'the stage ends (going down no longer clears it)':stl===3?'they go down (50% chance it survives that) or the stage ends':'they go down or the stage ends'} (then pour another)</span>
    <div class="cc-chips" style="align-items:center;margin-top:4px">${run.team.filter(k=>k!=='robot').map(k=>(run.heroes[k].carry&&run.heroes[k].carry.courage)?`<span class="cc-chip" style="color:#ffd27a">🫙 ${esc(heroDef(k).name.split(/[ _]/)[0])} ✓ jar packed</span>`:btn(`data-brew="${k}" ${(run.food||0)<sF-1e-9||(run.water||0)<1?'disabled':''}`,'🫙 → '+esc(heroDef(k).name.split(/[ _]/)[0]),'Pour '+heroDef(k).name+' a jar: +20% damage, +10% attack speed, 10% less damage taken, -20% accuracy for the next stage')).join(' ')}</div></div>`:'';
  return radio+sup+con+up+tri+tower+still;}
/* 0.12.57 (Kyle): the camp screen opens on the party resting around a roaring fire at night (Diablo-style),
   idling with their normal animations, the fire flickering light over them. Everything else on the camp screen stays below it. */
const CAMPBG=new Image();CAMPBG.src='crawl_campbg.png';   /* 0.12.63 (Kyle): his cabin-at-night painting is the camp backdrop */
function campScene(host,run){const W=171,H=96;const c=document.createElement('canvas');c.className='cc-fire';c.width=W*RES;c.height=H*RES;host.appendChild(c);
  const x=c.getContext('2d');let g;try{const r2=newRun(run.team.slice(),null);r2.stage=run.stage;r2.prestige=run.prestige||0;g=new Game({run:r2,slot:null,demo:true,W});}catch(e){c.remove();return;}
  g.enemies=[];g.obst=[];g.mines=[];g.bomblets=[];g.crates=[];g.loot=[];g.minions=[];g.proj=[];g.fx=[];g.texts=[];
  const fx=90,fgy=CFG.H-H+80;g.camp={x:fx,gy:fgy,t:1,life:99,state:'burn',A:{}};g.bgImg=CAMPBG;   // the painting's fire pit
  const spots=[[fx-30,fgy+7,1],[fx+30,fgy+7,-1],[fx-14,fgy-6,1]];
  g.heroes.forEach((h,i)=>{const s=spots[i]||spots[0];h.x=s[0];h.gy=s[1];h.face=s[2];h.alive=true;h.moving=false;h.hp=h.max;h.en=h.enMax||100;h.wanderX=0;h.dodgeX=0;h.plan=null;});
  const stars=[...Array(34)].map(()=>[60+Math.random()*60,30+Math.random()*50,Math.random()]);   // embers drifting up from the fire
  let last=performance.now();
  const frame=now=>{if(!c.isConnected)return;requestAnimationFrame(frame);const dt=Math.min(.05,(now-last)/1000);if(dt<1/31)return;last=now;
    g.t+=dt;g.camp.t+=dt;for(const h of g.heroes){h.walkT=(h.walkT||0);h.animT=0;h.hitFlash=0;}
    if(!(IMG.complete&&CAMPBG.complete))return;PLATE_OFF=true;try{drawGame(x,g,W,CFG.H-H);}catch(e){PLATE_OFF=false;return;}PLATE_OFF=false;
    const RR=c.width/W;x.setTransform(RR,0,0,RR,0,0);
    x.globalCompositeOperation='source-over';x.fillStyle='rgba(4,2,14,.18)';x.fillRect(0,0,W,H);   // the painting is already night: only a light shade
    for(const s of stars){const life=(g.t*.35+s[2])%1;const ex=fx+(s[0]-90)*.35*life+Math.sin(g.t*3+s[2]*20)*2,ey=(fgy-(CFG.H-H))-6-life*55;x.globalAlpha=(1-life)*(.5+.5*Math.sin(g.t*14+s[2]*30));x.fillStyle=life<.3?'#fff2b0':'#ff9a40';x.fillRect(ex,ey,.8,.8);}x.globalAlpha=1;   // sparkling embers
    const fy=fgy-(CFG.H-H)-6,fl=1+.07*Math.sin(g.t*11)+.05*Math.sin(g.t*17.3);
    x.globalCompositeOperation='lighter';
    let gr=x.createRadialGradient(fx,fy,1,fx,fy,78*fl);gr.addColorStop(0,'rgba(255,160,60,.6)');gr.addColorStop(.35,'rgba(255,110,30,.22)');gr.addColorStop(1,'rgba(255,80,20,0)');x.fillStyle=gr;x.fillRect(0,0,W,H);
    gr=x.createRadialGradient(fx,fy+2,0,fx,fy+2,14*fl);gr.addColorStop(0,'rgba(255,230,150,.7)');gr.addColorStop(1,'rgba(255,140,40,0)');x.fillStyle=gr;x.fillRect(fx-20,fy-20,40,40);
    x.globalCompositeOperation='source-over';
    gr=x.createLinearGradient(0,0,W,0);gr.addColorStop(0,'rgba(4,2,10,.75)');gr.addColorStop(.25,'rgba(4,2,10,0)');gr.addColorStop(.75,'rgba(4,2,10,0)');gr.addColorStop(1,'rgba(4,2,10,.75)');x.fillStyle=gr;x.fillRect(0,0,W,H);   // vignette
  };requestAnimationFrame(frame);}
function showCamp(){
  const s=SLOT();const run=s.run;migrate(s,CC.player);run.bag=run.bag||[];if(ABILITIES_OFF){run.pending=0;run.bag=run.bag.filter(e=>e.kind==='item');}const st=CFG.stage(run.stage,run.prestige);
  setRunModes(run);{const lg=campArrive(s,run);if(lg.length)run.campLog=lg;else if(run.campAt!==run.stage)run.campLog=[];}const hungry=new Set(run.needFeed||[]);
  const btn=(attrs,label,title)=>`<button class="cc-mini" ${attrs} ${title?`title="${esc(title)}"`:''}>${label}</button>`;
  const P=showPanel(`<div class="cc-h">STAGE ${run.stage}${run.prestige?' · ★'+run.prestige:''}${run.hardcore?' <span style="color:#ff5a5a;font-size:12px">☠ HARDCORE</span>':''}${run.dnd?' <span style="color:#c8a0ff;font-size:12px">🎲 D&amp;D</span>':''}</div><div class="cc-h2">${esc(st.biome.name)}${st.boss?` — ${esc(CFG.bosses[st.boss].name)} awaits`:''}</div>
    <div class="cc-firehost"></div>
    ${(()=>{try{if(localStorage.getItem('cc-camphelp')==='off')return '';}catch(e){}return `<div class="cc-help" data-camphelp>🏕️ <b>Camp tips</b> · Hover the pulsing <b>⛺ ⓘ</b> next to the title to see every camp upgrade, its tiers and prices. Hover ability and deck chips under 📜 <b>Skills</b> for details. Feed and water everyone before you leave, or they start the next stage weaker. Anything with a dotted underline or ⓘ has more info on hover.
      <div style="margin-top:6px;display:flex;gap:8px"><button class="cc-btn" data-helpx="once" style="padding:2px 10px">Got it</button><button class="cc-btn" data-helpx="off" style="padding:2px 10px;opacity:.75">Don't show again</button></div></div>`;})()}
    <p class="cc-sub">Score ${fmt(run.score)} · save point.${run.ff?` <b style="color:#7dff9a">🌱 Fall Forward ${run.ff}/3: +${Math.round(FF.xp[run.ff]*100)}% XP, +${Math.round(FF.gold[run.ff]*100)}% gold piles, −${Math.round(FF.keep[run.ff]*100)}% score lost on a fall.</b>`:''} ${run.pending?`<b style="color:#a6ff2e">⬆ ${run.pending} upgrade${run.pending>1?'s':''} waiting</b>`:'No upgrades waiting.'}</p>
    <div class="cc-load">${run.team.map(k=>{const d=heroDef(k),hv=run.heroes[k],L=s.heroes[k],cap=slotCaps(L.lvl);
      const act=hv.spells.map((e,i)=>[e,i]).filter(([e])=>!SPELL[e.arch].passive),pas=hv.spells.map((e,i)=>[e,i]).filter(([e])=>SPELL[e.arch].passive);
      const row=(lbl,list,n,c,slotName)=>`<div class="cc-slotrow"><span class="cc-sub" style="font-size:11px;margin:0">${lbl} ${n}/${c}</span><div class="cc-chips">${list.map(([e,i])=>`<span class="cc-chipw">${chipFor(e,slotName==='item',k)}${btn(`data-un="${k}|${slotName}|${i}"`,'↓','Move to backpack')}</span>`).join('')}</div></div>`;
      return `<div class="cc-card cc-lh"><span data-por="${k}"></span><div style="flex:1;min-width:0"><b>${d.icon} ${esc(d.name)}</b> <span class="cc-sub" style="font-size:11px">LV ${L.lvl} · Gear ${heroGear(hv)} · ${hv.dead?'fallen (revives at 25%)':Math.round((hv.hpf==null?1:hv.hpf)*100)+'% HP'}</span>
        ${ABILITIES_OFF?'':`<div class="cc-chips"><span class="cc-chip" title="${esc(SIG[k].txt)}" style="border-color:#ffd23f"><b>⚡ ${esc(SIG[k].name)}</b> · signature</span></div>`+row('Abilities',act,act.length,cap.active,'spell')+row('Passives',pas,pas.length,cap.passive,'spell')}
        ${(()=>{const C=CHAR[k]||{};const ab=abOrder(C.abilities).map(A=>[A.passive?'✦':'⚔',A.name||A.id,ABIL_DESC[A.id]||'']);const dk=L.insp?deckSkills(L.insp):[];   /* 0.12.56 (Kyle): Skills tab: his own abilities plus what his deck gives him; hover any for the details */
          const chip=([ic,n,d],col)=>`<span class="cc-chip" style="cursor:help;border-color:${col}" data-tiph="${esc('<div class="tt-h">'+esc(n.replace(/_/g,' '))+'</div>'+fmtAbil(d))}">${ic} ${esc(n.replace(/_/g,' '))}</span>`;
          return `<details class="cc-skills" style="margin-top:4px"><summary class="cc-sub" style="font-size:11px;margin:0;cursor:pointer">📜 Skills</summary><div class="cc-chips" style="margin-top:4px">${ab.map(x=>chip(x,'#7fd0ff')).join('')}${dk.map(x=>chip(x,'#c8a0ff')).join('')||(L.insp?'':'<span class="cc-sub" style="font-size:11px;margin:0">No deck inspiration</span>')}</div>${L.insp?`<div class="cc-sub" style="font-size:10px;margin:3px 0 0;opacity:.75">✨ ${esc(L.insp)}${inspText(L.insp)?': '+esc(inspText(L.insp)):''}</div>`:''}</details>`;})()}
        ${k!=='robot'&&!run.heroes[k].dead?(()=>{const n=needsOf(run,k);const fc=upgT(run,'smoker')?.5:1;   /* 0.12.72 Hunger & Thirst tiers */
          const hc=['#7ee081','#ffd060','#ff9040','#ff4a3a'][n.h],tc=['#7fd0ff','#ffd060','#ff9040','#ff4a3a'][n.t];
          const hT=n.h?`Next stage: heals on them ${Math.round(HUNGER.heal[n.h]*100)}% weaker, ${Math.round(HUNGER.spd[n.h]*100)}% slower moving and attacking, -${HUNGER.acc[n.h]} accuracy, and they start with ${Math.round(HUNGER.hp[n.h]*100)}% less HP.`:'Well fed.';
          const tT=n.t?`Next stage: foggy head (Perception -${THIRST.perc[n.t]}, plans and focus -${THIRST.think[n.t]}, decisions ${Math.round((THIRST.slow[n.t]-1)*100)}% slower) and a slow life drain (${(THIRST.drain[n.t]*100).toFixed(2)}% of max HP a second).`:'Well watered.';
          return `<div class="cc-sub" style="font-size:11px;margin:4px 0 0">🍖 <b style="color:${hc};cursor:help" title="${esc(hT)}">${HUNGER.names[n.h]}</b> ${n.h?btn(`data-feed="${k}|food" ${run.food>=fc?'':'disabled'}`,'🥫 Eat','Use '+(fc<1?'half a ration (smoked)':'1 food')+': Hunger -'+(upgT(run,'kitchen')?2:1)):''} · 💧 <b style="color:${tc};cursor:help" title="${esc(tT)}">${THIRST.names[n.t]}</b> ${n.t?btn(`data-feed="${k}|water" ${run.water>=1?'':'disabled'}`,'💧 Drink','Use 1 water: Thirst -'+(upgT(run,'purifier')?2:1)):''}${n.h||n.t?'<span style="opacity:.75"> · it only gets worse if ignored</span>':''}</div>`;})()
          :(k==='robot'?`<div class="cc-sub" style="font-size:11px;margin:4px 0 0;opacity:.7">🔋 Runs on its own power: no food or water needed</div>`:'')}
        ${(()=>{const fr=talFree(L),P=L.pts||{};const old=Object.keys(LVPTS).filter(x=>P[x]).map(x=>`${LVPTS[x].icon}${P[x]}`).join(' ');   /* 0.12.106 TALENTS (Kyle's level-up revamp) */
          const got=talPicks(L).map(id=>{const c=talCard(id,k);return c?`<span class="cc-chip" title="${esc(c.txt)}" style="${id.startsWith('cap:')?'border-color:#ffd23f;color:#ffd23f':id.startsWith('mod:')?'border-color:#c792ff;color:#d8b8ff':''}">${c.icon} ${esc(c.name)}</span>`:'';}).join('');
          const O=fr?talOffer(k,L):null;const kindName={cap:'⭐ CAPSTONE (pick 1 of 2)',mod:'🔮 SKILL MOD (pick 1)',stat:'⬆ Upgrade (pick 1 of 3)'};
          const offer=O?`<div style="margin-top:6px"><b style="color:${O.kind==='cap'?'#ffd23f':O.kind==='mod'?'#d8b8ff':'#a6ff2e'}">Level ${O.L} ${kindName[O.kind]}</b>${fr>1?` <span style="opacity:.8">(${fr} points waiting)</span>`:''}${O.kind==='stat'?` <button class="cc-btn" data-talrr="${k}" ${run.rerolls>=1?'':'disabled'} style="margin-left:6px;padding:2px 8px;font-size:11px" title="Spend 1 reroll die for 3 new upgrade picks">🎲 Reroll · ${diceStr(run)}</button>`:''}
            <div class="cc-offers" style="margin-top:6px">${O.ids.map(id=>{const c=talCard(id,k);if(!c)return '';const col=O.kind==='cap'?'#ffd23f':O.kind==='mod'||id.startsWith('mod:')?'#c792ff':id.startsWith('ps:')?'#7fd0ff':'#a6ff2e';
              return `<div class="cc-offer" style="--rc:${col}"><span class="rar">${O.kind==='cap'?'CAPSTONE':O.kind==='mod'||id.startsWith('mod:')?'SIGNATURE':id.startsWith('ps:')?'PERSONALITY':'STAT'}</span><span class="cn">${c.icon} ${esc(c.name)}</span><span class="tx">${esc(c.txt)}</span><button class="cc-btn" data-tal="${k}|${id}">Take it</button></div>`;}).join('')}</div></div>`:'';
          return `<div class="cc-sub" style="font-size:11px;margin:4px 0 0">${got?`<div class="cc-chips" style="margin-top:2px">${got}</div>`:fr?'':'Talents: one per level gained: pick 1 of 3 upgrades (with a hero-only SIGNATURE card in the mix), and a hero capstone fork at levels 5 and 10.'}${old?` <span style="opacity:.8">· old stat points: ${old}</span>`:''}${offer}</div>`;})()}
        ${(()=>{const C=talChar(k,L)||{};const T=luckyTargets(C);if(!T.length)return '';const lu=L.lucky||{};   /* 0.12.281 basic attack dice + Lucky Die */
          const d=w=>{const D=C[w].dice;const tag=lu[w]?` <span style="color:#7dff9a" title="Changed by a Lucky Die (base d${(CHAR[k][w]||{}).dice?CHAR[k][w].dice[1]:'?'})">🍀</span>`:'';return `${w==='melee'?'⚔️':'🏹'} ${D[0]}d${D[1]}${C[w].flat?'+'+C[w].flat:''}${tag} <span style="opacity:.6">(${Math.round(luckyOdds(D[0])*100)}% up)</span>`;};
          const ll=L.luckyLast;const llT=ll?` <b style="color:${ll.up?'#7dff9a':ll.down?'#ff6a6a':'#ccc'}">${ll.up?'🍀 LUCKY!':ll.down?'💀 Unlucky:':'Stayed:'} ${ll.w} ${ll.n}d${ll.from} → ${ll.n}d${ll.to}</b>`:'';
          return `<div class="cc-sub" style="font-size:11px;margin:4px 0 0">Basic attack: ${T.map(d).join(' · ')}${llT}${(s.lucky||0)>0?` <button class="cc-btn" data-lucky="${k}" style="margin-left:6px;padding:2px 8px;font-size:11px;border-color:#7dff9a;color:#7dff9a" title="Spend 1 Lucky Die: melee or ranged (random) rerolls its die size. Count stays the same. Can go up or DOWN.">${LUCKY_ICON} Roll Lucky Die (${s.lucky})</button>`:''}</div>`;})()}
        ${hv.carry&&(hv.carry.courage||hv.carry.medkit||hv.carry.defib||(hv.carry.kit||[]).length)?`<div class="cc-sub" style="font-size:11px;margin:4px 0 0">🎒 Carrying into the stage: ${[hv.carry.courage?'Liquid Courage':'',hv.carry.medkit?'Medkit':'',hv.carry.defib?'Defibrillator':'',...(hv.carry.kit||[]).map(x=>x==='bat'?'Battery':'Medicine')].filter(Boolean).join(', ')}</div>`:''}</div></div>`;}).join('')}
      ${campPanel(s,run,btn)}
      <div class="cc-shopwrap" ${CAMP_SHOP?'':'hidden'}>${(()=>{const gold=s.gold||0;if(run.shopAt!==run.stage)return `<div class="cc-card"><b>🛒 Merchant</b> <span class="cc-sub" style="font-size:12px">💰 <b style="color:#ffd23f">${fmt(gold)}</b> gold · the merchant sets up shop after each boss you beat.</span></div>`;if(!run.shop||run.shop.stage!==run.stage)stockShop(run);
        const owned=[...run.team.flatMap(k=>run.heroes[k].items.map((e,i)=>({e,where:'hero',k,i}))),...run.bag.map((e,i)=>({e,where:'bag',i})).filter(o=>o.e.kind==='item')];
        return `<div class="cc-card"><b>🛒 Merchant</b> <span class="cc-sub" style="font-size:12px">here after your boss win · 💰 <b style="color:#ffd23f">${fmt(gold)}</b> gold (kept by this save)</span>
        <div class="cc-offers" style="margin-top:8px">${run.shop.items.map((it,i)=>{const R=CFG.rarity.find(r=>r.id===it.rar)||CFG.rarity[0];const pr=itemPrice(it.rar,run.stage);const pc=procFor(it.card);
          return `<div class="cc-offer" style="--rc:${R.col}"><span class="rar">${R.name.toUpperCase()}</span><span class="kind">${ITEM[it.arch].label} · for ${esc(heroDef(it.hero).name)} (fits anyone)</span><span class="cn">${esc(shortCard(it.card))} <span class="cc-sub" style="font-size:11px">GS ${gearScore({r:R.pts,tier:it.tier})}</span></span>
            <span class="tx">${esc(ITEM[it.arch].txt(R.pts))}${pc?'. '+esc(PROCS[pc].txt(procChance(R.pts))):''}</span>${it.sold?'<span class="cc-sub" style="margin:0">Sold</span>':`<button class="cc-btn" data-buy="${i}" ${gold<pr?'disabled':''}>Buy · ${fmt(pr)}g</button>`}</div>`;}).join('')||'<span class="cc-sub">Nothing left to sell from your decks.</span>'}</div>
        <div class="cc-row" style="margin-top:8px"><button class="cc-btn" data-restock ${gold<15*run.stage?'disabled':''}>Restock · ${15*run.stage}g</button></div>
        ${owned.length?`<div class="cc-sub" style="margin:10px 0 4px;font-size:12px">Hone an item (+1 rank):</div><div class="cc-chips">${owned.map((o,j)=>{const pr=honePrice(o.e.r,run.stage);return o.e.r>=CFG.maxRank?'':`<button class="cc-mini" data-hone="${j}" ${gold<pr?'disabled':''}>${esc(shortCard(o.e.card))} r${o.e.r}→${o.e.r+1} · ${fmt(pr)}g</button>`;}).join('')}</div>`:''}</div>`;})()}
      <div class="cc-card"><b>🎒 Backpack</b> <span class="cc-sub" style="font-size:11px">${run.bag.length}/${BAG_SIZE} · skills only fit the hero they came from; items fit anyone · more slots unlock at hero level 5, 8 and 12</span>
        <div class="cc-load" style="margin-top:6px">${run.bag.length?run.bag.map((e,bi)=>{const isItem=e.kind==='item';const who=isItem?run.team:[e.owner];
          return `<div class="cc-chips" style="align-items:center">${chipFor(e,isItem,e.owner)}<span class="cc-sub" style="font-size:11px;margin:0">${isItem?'':'('+esc(heroDef(e.owner).name)+')'}</span>
            ${who.filter(k=>run.team.includes(k)).map(k=>btn(`data-eq="${bi}|${k}"`,'↑ '+esc(heroDef(k).name.split(' ').slice(-1)[0]),'Equip on '+heroDef(k).name)).join('')}${isItem?btn(`data-dis="${bi}"`,'Sell +'+(12*(e.r||1))+'g','Sell'):btn(`data-dis="${bi}"`,'✕','Discard')}</div>`;}).join(''):'<span class="cc-sub" style="font-size:12px;margin:0">Empty. New picks that don\'t fit a slot land here.</span>'}</div></div></div></div>
    <div class="cc-row" style="margin-top:14px">${run.pending?`<button class="cc-btn go" data-pick>CHOOSE UPGRADES (${run.pending})</button>`:`<button class="cc-btn go" data-begin>BEGIN STAGE ${run.stage} ▶</button>`}
      <button class="cc-btn" data-quit>Save & exit</button></div><p class="cc-sub" id="cc-campmsg" style="margin-top:8px"></p>`);
  P.querySelectorAll('[data-por]').forEach(e=>e.replaceWith(portrait(e.dataset.por,56)));{const fh=P.querySelector('.cc-firehost');if(fh)campScene(fh,run);}P.querySelectorAll('[data-helpx]').forEach(x=>x.onclick=()=>{if(x.dataset.helpx==='off'){try{localStorage.setItem('cc-camphelp','off');}catch(e){}}const el=P.querySelector('[data-camphelp]');if(el)el.remove();});
  const msg=t=>{const m=P.querySelector('#cc-campmsg');if(m)m.textContent=t;};
  P.querySelectorAll('[data-un]').forEach(b=>b.onclick=()=>{const [k,sl,i]=b.dataset.un.split('|');if(unequip(run,k,sl,+i)){persist();showCamp();}else msg(run.bag.length>=BAG_SIZE?'Backpack is full.':'Each hero keeps at least one skill equipped.');});
  P.querySelectorAll('[data-eq]').forEach(b=>b.onclick=()=>{const [bi,k]=b.dataset.eq.split('|');if(equip(run,s,+bi,k)){persist();showCamp();}else msg('No free slot of that kind on '+heroDef(k).name+'. Move something to the backpack first.');});
  P.querySelectorAll('[data-dis]').forEach(b=>b.onclick=()=>{if(!confirmInline(b,'Sure?'))return;const e=run.bag[+b.dataset.dis];if(e&&e.kind==='item')s.gold=(s.gold||0)+12*(e.r||1);discard(run,'bag',null,+b.dataset.dis);persist();showCamp();});
  P.querySelectorAll('[data-buy]').forEach(b=>b.onclick=()=>{const it=run.shop.items[+b.dataset.buy];const pr=itemPrice(it.rar,run.stage);if((s.gold||0)<pr)return;
    const w=giveItem(run,s,it);if(!w){msg('No room on any hero or in the backpack.');return;}s.gold-=pr;it.sold=1;sfx('level');persist();showCamp();});
  const rs=P.querySelector('[data-restock]');if(rs)rs.onclick=()=>{const c=15*run.stage;if((s.gold||0)<c)return;s.gold-=c;stockShop(run);persist();showCamp();};
  const owned2=[...run.team.flatMap(k=>run.heroes[k].items),...run.bag.filter(e=>e.kind==='item')];
  P.querySelectorAll('[data-hone]').forEach(b=>b.onclick=()=>{const e=owned2[+b.dataset.hone];const pr=honePrice(e.r,run.stage);if((s.gold||0)<pr)return;s.gold-=pr;e.r=Math.min(CFG.maxRank,e.r+1);sfx('level');persist();showCamp();});
  const pk=P.querySelector('[data-pick]');if(pk)pk.onclick=showPick;
  const bg=P.querySelector('[data-begin]');if(bg)bg.onclick=()=>{const left=run.team.filter(k=>missingOf(run,k)&&!run.heroes[k].dead);
    if(left.length&&!bg.dataset.sure){bg.dataset.sure=1;bg.textContent='Leave hungry/thirsty? '+left.map(k=>{const n=needsOf(run,k);return heroDef(k).name+(n.h?' '+HUNGER.names[n.h]:'')+(n.t?' '+THIRST.names[n.t]:'');}).join(', ')+' ▶';return;}campDepart(run);persist();beginStage();};
  {const fa=P.querySelector('[data-feedall]');if(fa)fa.onclick=()=>{if(feedAll(run)){sfx('level');persist();showCamp();}else{fa.textContent='Not enough supplies';}};}
  P.querySelectorAll('[data-feed]').forEach(b=>b.onclick=()=>{const [k,w]=b.dataset.feed.split('|');if(feedUnit(run,k,w)){sfx('level');persist();showCamp();}});
  P.querySelectorAll('[data-lucky]').forEach(b=>b.onclick=()=>{if(!((s.lucky||0)>0))return;const k=b.dataset.lucky,H=s.heroes[k];if(!H)return;const r=luckyRoll(k,H);if(!r)return;s.lucky--;persist();
    H.luckyLast=r;persist();sfx(r.up?'level':'die');showCamp();});   /* 0.12.281 Lucky Die */
  P.querySelectorAll('[data-talrr]').forEach(b=>b.onclick=()=>{if(!(run.rerolls>=1))return;const k=b.dataset.talrr,H=s.heroes[k];if(!H||!H.offer)return;const prev=H.offer.ids.slice();let nw=talRoll(k,H);for(let i=0;i<6&&nw.ids.every(x=>prev.includes(x));i++)nw=talRoll(k,H);H.offer=nw;run.rerolls--;sfx('level');persist();showCamp();});   /* 0.12.280 dice on stat picks */
  P.querySelectorAll('[data-tal]').forEach(b=>b.onclick=()=>{const [k,...r]=b.dataset.tal.split('|');const id=r.join('|');const H=s.heroes[k];if(talTake(k,H,id)){sfx('level');persist();showCamp();}});
  P.querySelectorAll('[data-upgp]').forEach(b=>b.onclick=()=>{const id=b.dataset.upgp,pp=upgParts(run,id);run.picked=run.picked||[];if(run.picked.includes(id)||(s.parts||0)<pp)return;s.parts-=pp;run.upg=run.upg||{};run.upg[id]=(run.upg[id]||0)+1;run.upgBought=1;run.picked.push(id);sfx('level');persist();showCamp();});
  {const rb=P.querySelector('[data-reroll]');if(rb)rb.onclick=()=>{if(!(run.rerolls>=1))return;const prev=run.offers||[];let nw=campOffers(run);for(let i=0;i<6&&nw.length&&nw.every(id=>prev.includes(id));i++)nw=campOffers(run);run.offers=nw;run.rerolls--;sfx('level');persist();showCamp();};}   /* 0.12.188 camp reroll */
  P.querySelectorAll('[data-upg]').forEach(b=>b.onclick=()=>{const id=b.dataset.upg,pr=upgPrice(run,id);run.picked=run.picked||[];if(run.picked.includes(id)||(s.gold||0)<pr)return;s.gold-=pr;run.upg=run.upg||{};run.upg[id]=(run.upg[id]||0)+1;run.upgBought=1;run.picked.push(id);sfx('level');persist();showCamp();});
  {const cb=P.querySelector('[data-con]');if(cb)cb.onclick=()=>{run.conOpen=!run.conOpen;persist();showCamp();};}
  P.querySelectorAll('[data-conb]').forEach(b=>b.onclick=()=>{const id=b.dataset.conb,pr=conPrice(run,id);if((s.gold||0)<pr)return;s.gold-=pr;run.upg=run.upg||{};run.upg[id]=(run.upg[id]||0)+1;sfx('level');persist();showCamp();});
  P.querySelectorAll('[data-conp]').forEach(b=>b.onclick=()=>{const id=b.dataset.conp,pp=conParts(run,id);if((s.parts||0)<pp)return;s.parts-=pp;run.upg=run.upg||{};run.upg[id]=(run.upg[id]||0)+1;sfx('level');persist();showCamp();});
  P.querySelectorAll('[data-scout]').forEach(b=>b.onclick=()=>{const id=b.dataset.scout;if(upgT(run,'tower')>=4){let a=[].concat(run.scoutPick||[]);a=a.includes(id)?a.filter(x=>x!==id):a.concat(id).slice(-2);run.scoutPick=a.length?a:null;}else run.scoutPick=id;persist();showCamp();});   /* 0.12.105 Map Table: two roads */
  P.querySelectorAll('[data-brew]').forEach(b=>b.onclick=()=>{const k=b.dataset.brew;const r=brewCourage(run,k);if(r==='ok'){sfx('level');persist();showCamp();const m=document.querySelector('#cc-campmsg');if(m)m.textContent='🫙 Poured '+heroDef(k).name+' a jar of Liquid Courage (−'+[2,1.5,1,1][upgT(run,'still')-1]+' food, −1 water).';}else msg({max:'No more brewing this camp.',food:'Not enough food.',water:'Not enough water.',has:heroDef(k).name+' already has a jar.'}[r]||'Can\'t brew that.');});
  P.querySelectorAll('[data-tri]').forEach(b=>b.onclick=()=>{const [w,k]=b.dataset.tri.split('|');const r=triageBuild(s,run,w,k);if(r==='ok'){sfx('level');persist();showCamp();}else msg({max:'No more builds at this camp.',parts:'Not enough spare parts.',has:heroDef(k).name+' already carries one of those.'}[r]||'Can\'t build that.');});

  P.querySelector('[data-quit]').onclick=showSlots;
}
/* 0.12.239 (Kyle): every stage you finish, won or lost, charges the reroll 50% (two results = a full reroll), up to 1 banked unless you already had more */
const DICE_MAX=3;   /* 0.12.280 (Kyle): bank up to 3 reroll dice; every stage you finish, won or lost, charges 25% of a die */
function rerollRefill(run){const r=run.rerolls||0;if(r<DICE_MAX)run.rerolls=Math.min(DICE_MAX,Math.round((r+.25)*4)/4);}
const LUCKY_ICON='<span style="display:inline-block;filter:hue-rotate(95deg) saturate(2.2) drop-shadow(0 0 3px #7dff9a)">🎲</span>';   /* 0.12.281 Lucky Die: a green glowing die */
function luckyStr(s){const n=s.lucky||0;return n?`${LUCKY_ICON.repeat(Math.min(n,5))} Lucky Di${n>1?'ce':'e'} (${n})`:'';}
function diceStr(run){const r=run.rerolls||0,n=Math.floor(r),p=Math.round((r%1)*100);return `${n?'🎲'.repeat(n):'<span style="opacity:.45">🎲</span>'} (${n})${p?` <span style="opacity:.75">+${p}% charged</span>`:''}`;}
function showPick(){
  const s=SLOT(),run=s.run;if(ABILITIES_OFF)run.pending=0;if(!run.pending)return showCamp();
  const luckN=run.heroes&&Object.values(run.heroes).some(h=>h.spells.some(x=>x.arch==='insight'&&(x.augs||[]).length))?4:3;
  const isB=(run.blessed||0)>0;const os=CC.offersCache||(CC.offersCache=offers(run,Math.random,luckN,isB?{luck:60,min:'U',blessed:1}:null));
  const P=showPanel(`<div class="cc-h">${isB?'⭐ BLESSED PICK':'LEVEL UP!'}</div><p class="cc-sub">${isB?'Every option is Uncommon or better, with a 40% shot at Rare each. ':''}${run.pending} pick${run.pending>1?'s':''} left. Tap one.</p>
    <div class="cc-offers">${os.map((o,i)=>{const d=describe(o,run,s);const hd=heroDef(o.hero);
      const kind=o.kind==='new'?(o.slot==='spell'?'New spell':'New item'):o.kind==='aug'?'Augment':'Upgrade';
      const base=o.slot==='spell'?sname(o.hero,o.card):shortCard(o.card);const nm=d.r1>=CFG.maxRank?`✦ ${esc(maxTitle(o.card,o.arch))}`:esc(base);
      return `<button class="cc-offer" style="--rc:${o.rar.col}" data-i="${i}"><span class="rar">${o.rar.name.toUpperCase()}</span><span class="kind">${kind} · ${o.slot==='spell'?SPELL[o.arch].label:ITEM[o.arch].label}${o.kind==='aug'?' · '+AUG[o.aug].name:''}</span>
        <span class="cn">${nm}</span>${d.r1>=CFG.maxRank?`<span class="cc-sub" style="margin:0;font-size:11px">${esc(base)} at max rank</span>`:''}${o.slot==='spell'?`<span class="cc-sub" style="margin:0;font-size:10px">inspired by ${esc(shortCard(o.card))}</span>`:''}
        <span class="who"><span data-por="${o.hero}"></span>${esc(hd.name)}</span>
        <span>${o.kind==='new'?'':`r${d.r0} → `}${rankStars(d.r1)}${d.where?` <span class="cc-sub" style="font-size:10px">· ${d.where}</span>`:''}</span><span class="tx">${esc(d.txt)}${o.kind==='aug'?` <b>${AUG[o.aug].name}:</b> ${AUG[o.aug].txt}.`:''}</span></button>`;}).join('')}</div>
    <div class="cc-row" style="margin-top:12px"><button class="cc-btn" data-skip>Skip (+${fmt(2*run.stage)} score)</button></div>`);
  P.querySelectorAll('[data-por]').forEach(e=>e.replaceWith(portrait(e.dataset.por)));
  P.querySelectorAll('[data-i]').forEach(b=>b.onclick=()=>{const o=os[+b.dataset.i];const r=applyOffer(run,o,s);if(r==='full')return showReplace(o);if(o.blessed)run.blessed=Math.max(0,(run.blessed||0)-1);sfx('level');CC.offersCache=null;persist();run.pending?showPick():showCamp();});
  
  P.querySelector('[data-skip]').onclick=()=>{run.pending--;if(isB)run.blessed=Math.max(0,(run.blessed||0)-1);run.score+=2*run.stage;CC.offersCache=null;persist();run.pending?showPick():showCamp();};
}
function showReplace(o){
  const s=SLOT(),run=s.run;const hv=run.heroes[o.hero];const t=o.slot==='item'?'item':SPELL[o.arch].passive?'passive':'active';
  const eq=(t==='item'?hv.items.map((e,i)=>['item',i,e]):hv.spells.map((e,i)=>['spell',i,e]).filter(([,,e])=>!!SPELL[e.arch].passive===(t==='passive')));
  const P=showPanel(`<div class="cc-h">NO ROOM</div><p class="cc-sub">${esc(heroDef(o.hero).name)}'s ${t==='item'?'item':t==='passive'?'passive':'ability'} slots and the backpack are full. Drop one to take <b>${esc(o.slot==='spell'?sname(o.hero,o.card):shortCard(o.card))}</b>:</p>
    <div class="cc-load">${eq.map(([sl,i,e])=>`<button class="cc-card" style="text-align:left" data-d="${sl}|${i}">Equipped: ${chipFor(e,sl==='item',o.hero)}</button>`).join('')}
      ${run.bag.map((e,i)=>`<button class="cc-card" style="text-align:left" data-d="bag|${i}">🎒 ${chipFor(e,e.kind==='item',e.owner)}</button>`).join('')}</div>
    <div class="cc-row" style="margin-top:12px"><button class="cc-btn" data-cancel>← Back to picks</button></div>`);
  P.querySelectorAll('[data-d]').forEach(b=>b.onclick=()=>{const [w,i]=b.dataset.d.split('|');discard(run,w,o.hero,+i);applyOffer(run,o,s);if(o.blessed)run.blessed=Math.max(0,(run.blessed||0)-1);sfx('level');CC.offersCache=null;persist();run.pending?showPick():showCamp();});
  P.querySelector('[data-cancel]').onclick=showPick;
}
function endRun(s,victory){const r=s.run;if(!r)return;const tot=r.score;
  if(r.prestige*100+r.stage>s.best.prestige*100+s.best.stage){s.best.stage=r.stage;s.best.prestige=r.prestige;}s.best.score=Math.max(s.best.score,tot);s.run=null;persist();}
// ---------------------------------------------------------------- playing
function ufTip(h){const C=CHAR[h.key]||{};const ab=abOrder(C.abilities||[]);   /* 0.12.81: phone unit-frame tip: abilities (actives first, passives last) */
  return `<div class="tt-h">${esc(h.def.name)} · LV ${h.lvl}</div>`+ab.map(A=>`<div class="tt-b"><b>${A.passive?'✦':'⚔'} ${esc((A.name||A.id).replace(/_/g,' '))}</b>${A.passive?' <span style="opacity:.6">(passive)</span>':''}${fmtAbil(ABIL_DESC[A.id]||'')}</div>`).join('')+`<div class="tt-b" style="opacity:.7;margin-top:4px">Tap again to close.</div>`;}
/* 0.12.99 (Kyle): when a deck gives cooldown reduction, show THIS hero's ability cooldowns before -> after so players can choose */
function cdrTable(k,d){const I=INSP[d];const r=I&&I.mod&&I.mod.cdr;if(!r)return '';const C=CHAR[k]||{};const rows=[];
  for(const A of abOrder(C.abilities||[])){if(A.passive&&!A.icd)continue;const nm=(A.name||A.id).replace(/_/g,' ');
    if(A.book){for(const [bk,B] of Object.entries(A))if(B&&typeof B==='object'&&B.cd)rows.push([nm+' · '+bk,B.cd]);continue;}
    if(A.cd)rows.push([nm,A.cd]);else if(A.icd)rows.push([nm+' (internal)',A.icd]);}
  const sg=SIG[k];if(sg&&sg.fn&&String(sg.fn).indexOf('false')<0&&sg.cd)rows.push([sg.name,sg.cd]);
  if(!rows.length)return '';const f=v=>(Math.round(v*10)/10)+'s';
  return `<div style="margin-top:6px;font-size:11px"><b>⏱ ${esc(heroDef(k).name)} with −${r}% cooldowns</b><table style="border-collapse:collapse;margin-top:3px">${rows.map(([n,v])=>`<tr><td style="padding:1px 10px 1px 0">${esc(n)}</td><td style="opacity:.6">${f(v)}</td><td style="padding:0 6px">→</td><td style="color:#a6ff2e"><b>${f(v*(1-Math.min(.5,r/100)))}</b></td></tr>`).join('')}</table></div>`;}
function beginStage(){
  const s=SLOT(),run=s.run;panel.hidden=true;CC.paused=false;
  /* 0.12.73 (Kyle) Retry: snapshot everything at the start of the stage (heroes, HP, items, herbs, kit, buffs, gold, parts, supplies, run state) */
  if(run.retries==null)run.retries=1;try{const r2=Object.assign({},run);delete r2.snap;run.snap=JSON.stringify({run:r2,gold:s.gold||0,parts:s.parts||0,heroes:s.heroes,best:s.best});}catch(e){run.snap=null;}
  CC.game=new Game({run,slot:s});window.__CCG=CC.game;CC.lv0=Object.fromEntries(run.team.map(k=>[k,s.heroes[k].lvl]));
  hud.style.gridTemplateColumns=`repeat(${run.team.length},minmax(0,1fr))`;
  hud.innerHTML=CC.game.heroes.map(h=>`<div class="cc-hc" data-h="${h.key}"><span data-por="${h.key}"></span><div style="flex:1;min-width:0"><div class="n">${esc(h.def.name)} <span style="color:#ffd23f">${h.lvl}</span></div><div class="bar"><i></i></div>
    <div class="sp"><span class="cc-sp" data-sig style="border-color:#ffd23f"><b>⚡ ${esc(SIG[h.key].name)}</b><i></i></span>${h.spells.map((s,i)=>`<span class="cc-sp" data-s="${i}"><b>${s.r>=CFG.maxRank?'✦ ':''}${esc(sname(h.key,s.card))}</b> r${s.r}<i></i></span>`).join('')}${h.items.map(it=>`<span class="cc-sp it"><b>${esc(shortCard(it.card))}</b> ${ITEM[it.arch].label} r${it.r}</span>`).join('')}</div></div></div>`).join('');
  hud.querySelectorAll('[data-por]').forEach(e=>e.replaceWith(portrait(e.dataset.por)));
  /* 0.12.81 (Kyle) phones: small WoW-style unit frames in the top-left of the sky instead of the panels under the stage; tap one to see its abilities */
  const uf=$('.cc-uf',root);uf.innerHTML=CC.game.heroes.map(h=>{const col=(typeof CALL_COLOR!=='undefined'&&CALL_COLOR[h.key])||'#9ad0ff';return `<div class="uf" data-h="${h.key}" data-tiph="${esc(ufTip(h))}"><div class="ufb"><div class="ufn" style="color:${col}">${esc(h.def.name)} <span class="lv">${h.lvl}</span><span class="ufs"></span></div><div class="ufh"><i style="background:linear-gradient(${col},${col}aa)"></i></div><div class="ufe"><i></i></div></div></div>`;}).join('');
  uf.querySelectorAll('[data-por]').forEach(e=>e.replaceWith(portrait(e.dataset.por)));
  const st=CC.game.st;flash(`STAGE ${run.stage}`,1400);if(st.boss)setTimeout(()=>{},0);
  root.querySelector('[data-a=restart]').hidden=false;layout();CC.last=performance.now();cancelAnimationFrame(CC.raf);CC.raf=requestAnimationFrame(loop);
}
/* 0.12.217 the radio's messages: a roast of the crew or something fun. Each one plays once per browser before they repeat */
const RADIO_LINES=['Hear this if you\'re gay!','Bryan\'s a bitch!','This is an emergency broadcast. JP is high again. Repeat: JP is high again.','Cheez has never once read a card before playing it.','Eddie, put the nail gun down and come to game night.',
  'Meo, we know you stole the last slice.','Shamp, your deck is not a combo deck. It is a pile.','Wolf, the zombies called. They want their haircut back.','Bryan, nobody believes you drew that naturally.','Dice Boys rule!',
  'This frequency is sponsored by Dice Boys. Roll high, die hard.','JP, your Kar98 called. It wants a sober owner.','Cheez is legally a snack, and that is all we will say.','Eddie, you can stop targeting Kyle now. He knows.','Attention survivors: Shamp still owes everybody five bucks.',
  'Meo has been spotted hiding behind the cars again. Classic Meo.','Wolf, howling at the moon does not count as cardio.','If you can hear this, Bryan lost again.','Stay hydrated. Stay strapped. Dice Boys forever.','Good news, everybody: the zombies are slow. Bad news: so is Cheez.',
  'Breaking news: local man JP smokes entire forest, calls it a break.','Kenzie is the only responsible adult left. Protect her at all costs.','Leon, if you\'re listening: you\'re the best one in the pod.','Kyle built this whole game just to win one argument.','Shoshi, turn it off and on again. The apocalypse, I mean.'];
function playRadio(R){if(!R||R.state!=='idle')return;R.state='playing';const g=CC.game;
  let seen=[];try{seen=JSON.parse(localStorage.getItem('podrundown-crawl-radio')||'[]');}catch(_){}let pool=RADIO_LINES.filter(l=>!seen.includes(l));if(!pool.length){seen=[];pool=RADIO_LINES.slice();}
  const line=pool[Math.floor(Math.random()*pool.length)];seen.push(line);try{localStorage.setItem('podrundown-crawl-radio',JSON.stringify(seen));}catch(_){}
  const sub=root.querySelector('.cc-radiosub')||(()=>{const d=document.createElement('div');d.className='cc-radiosub';root.querySelector('.cc-cvw').appendChild(d);return d;})();
  const v0=BGM?BGM.volume:0;const duck=to=>{if(!BGM)return;const from=BGM.volume,t0=performance.now();const st=()=>{const k=Math.min(1,(performance.now()-t0)/500);BGM.volume=from+(to-from)*k;if(k<1)requestAnimationFrame(st);};st();};
  let noise=null;const startStatic=()=>{if(muted)return;try{AC=AC||new (window.AudioContext||window.webkitAudioContext)();const n=AC.sampleRate*1,b=AC.createBuffer(1,n,AC.sampleRate),c=b.getChannelData(0);for(let i=0;i<n;i++)c[i]=(Math.random()*2-1)*(Math.random()<.02?1:.35);
      const s=AC.createBufferSource(),f=AC.createBiquadFilter(),gn=AC.createGain();s.buffer=b;s.loop=true;f.type='bandpass';f.frequency.value=1800;f.Q.value=.8;gn.gain.value=.05;s.connect(f);f.connect(gn);gn.connect(AC.destination);s.start();noise={s,gn};}catch(_){}};
  const end=()=>{if(noise){try{noise.gn.gain.value=0;noise.s.stop();}catch(_){}}sub.style.opacity=0;setTimeout(()=>duck(musicVol),500);R.state='dying';R.dieT=1.2;sfx('hit');};
  sub.textContent='📻 "'+line+'"';sub.style.opacity=1;duck(Math.min(v0,musicVol*.2));startStatic();
  setTimeout(()=>{let done=false;const fin=()=>{if(done)return;done=true;setTimeout(end,250);};
    try{if(!muted&&window.speechSynthesis){const u=new SpeechSynthesisUtterance(line);u.rate=.95;u.pitch=.75;u.volume=1;u.onend=fin;u.onerror=fin;speechSynthesis.cancel();speechSynthesis.speak(u);setTimeout(fin,Math.max(3500,line.length*95));}else setTimeout(fin,Math.max(2800,line.length*70));}catch(_){setTimeout(fin,3000);}},500);}
function radioClick(e){const g=CC.game;if(!g||!g.radio||g.radio.state!=='idle')return;const r=cv.getBoundingClientRect();const wx=(e.clientX-r.left)/r.width*g.W,wy=(e.clientY-r.top)/r.height*CFG.H;
  const R=g.radio;if(Math.abs(wx-R.x)<10&&Math.abs(wy-(R.gy-4))<12){e.preventDefault();playRadio(R);}}
function flash(t,ms){banner.textContent=t;banner.style.opacity=1;clearTimeout(CC.bt);CC.bt=setTimeout(()=>banner.style.opacity=0,ms||1200);}
function loop(now){
  const g=CC.game;if(!g||root.hidden)return;let dt=Math.min(.05,(now-CC.last)/1000);CC.last=now;
  if(!CC.paused){for(let i=0;i<CC.speed;i++)g.step(dt);}
  for(const e of g.events){if(e.type==='levelup'){sfx('level');flash('LEVEL UP!',900);}if(e.type==='boss'){sfx('boss');flash(e.name.toUpperCase(),1800);}
    if(e.type==='herolevel')sfx('level');if(e.type==='enrage')flash('ENRAGED!',1400);if(e.type==='itemdrop'){sfx('level');flash('ITEM FOUND!',900);}if(e.type==='luckydrop'){sfx('level');flash('🍀 LUCKY DIE!',1200);}if(e.type==='herodown')sfx('die');if(e.type==='gun')sfx(e.rifle?'rifle':e.nail?'nail':e.big?'biggun':'gun');if(e.type==='boom')sfx('boom');if(e.type==='dash')sfx('dash');if(e.type==='bow')sfx('bow');if(e.type==='heal')sfx('heal');if(e.type==='camp')sfx('camp');if(e.type==='whoosh')sfx('whoosh');if(e.type==='slash')sfx('plasma');if(e.type==='thorns')sfx('thorns');if(e.type==='bell')sfx('bell',e);if(e.type==='alarm')sfx('alarm',e);if(e.type==='clunk')sfx('clunk');if(e.type==='glass')sfx('glass',e);if(e.type==='nemesis'){sfx('boss');flash(e.back?e.name.toUpperCase()+' RETURNS! (RANK '+'I'.repeat(e.rank)+')':(e.rank>1?e.name.toUpperCase()+' GROWS STRONGER':e.name.toUpperCase()+' RISES')+(e.trait?' · '+({rav:'RAVENOUS',blood:'BLOODTHIRSTY',bulwark:'BULWARK',howl:'HOWLER',cleave:'CLEAVER'}[e.trait]||''):''),1800);}if(e.type==='nemdown'){sfx('clear');flash(e.name.toUpperCase()+' IS DEAD',1600);}if(e.type==='lazer')sfx('lazer',e);if(e.type==='flame')sfx('flame');if(e.type==='shotgun')sfx('shotgun');if(e.type==='shriek')sfx('shriek');if(e.type==='wind')sfx('wind');if(e.type==='shout')sfx('shout');}
  g.events.length=0;
  ctx.imageSmoothingEnabled=false;drawGame(ctx,g,384,0);panCam();
  const run=g.run;info.innerHTML=`<span class="px" style="font-size:10px;color:#a6ff2e">STAGE ${run.stage}${run.prestige?' ★'+run.prestige:''}</span><span>${esc(g.st.biome.name)}</span><span>Score <b>${fmt(run.score+g.stageScore)}</b></span>${run.ff?`<span title="Fall Forward: +${Math.round(FF.xp[run.ff]*100)}% XP, +${Math.round(FF.gold[run.ff]*100)}% gold piles, −${Math.round(FF.keep[run.ff]*100)}% score lost on a fall" style="color:#7dff9a">🌱${run.ff}</span>`:''}<span>💰 <b>${fmt((SLOT().gold||0)+g.stageGold)}</b></span>
    <span class="cc-xp" title="Next upgrade"><i style="width:${Math.min(100,(run.xp||0)/(8+6*(run.lv||0))*100)}%"></i></span>${run.pending?`<b style="color:#a6ff2e">⬆${run.pending}</b>`:''}`;
  bossEl.textContent=g.boss&&!g.boss.dead?g.boss.B.name.toUpperCase():'';
  const doSt=(CC.ufT=(CC.ufT||0)+1)%8===0;
  for(const h of g.heroes){const f=root.querySelector(`.cc-uf [data-h="${h.key}"]`);if(!f)continue;f.classList.toggle('dead',!h.alive);
    if(doSt){const S=[];if(!h.alive)S.push(['DOWN','#ff4a4a']);else{if(h.bleedT>0)S.push(['🩸','#ff5a5a']);if(h.stun>0)S.push(['💫','#ffe07a']);if(h.slowT>0&&h.slow>0)S.push(['🐌','#9ad0ff']);if(h.shield>0)S.push(['🛡'+Math.round(h.shield),'#cfe8ff']);if(h.highT>0)S.push(['🌿','#8fe36a']);if(h.gritT>0||h.wallT>0)S.push(['🪨','#d8c8a8']);if(h.stealthT>0)S.push(['👻','#c8c8ff']);if(h.hunger>0)S.push(['🍖','#ffb070']);if((h.moods||[]).some(m=>m.name==='roasted'))S.push(['🔥','#ffa040']);if(h.buffT>0)S.push(['⬆','#a6ff2e']);if(h.courage)S.push(['🫙','#ffd27a']);if(h.sakeB)S.push(['🍶','#b8ff7a']);if(h.bnIn)S.push(['🎲','#8cff46']);if(h.upT>0)S.push(['✨','#fff']);}
      const s=f.querySelector('.ufs');const html=S.map(([t,c])=>`<span style="color:${c}">${t}</span>`).join(' ');if(s.dataset.v!==html){s.dataset.v=html;s.innerHTML=html;}}
    f.querySelector('.ufh i').style.width=Math.max(0,h.hp/h.max*100)+'%';f.querySelector('.ufe i').style.width=h.enMax?Math.max(0,Math.min(100,(h.en||0)/h.enMax*100))+'%':'0%';}
  for(const h of g.heroes){const el=hud.querySelector(`[data-h="${h.key}"]`);if(!el)continue;el.classList.toggle('dead',!h.alive);el.querySelector('.bar i').style.width=Math.max(0,h.hp/h.max*100)+'%';
    el.querySelector('.n span').textContent=SLOT().heroes[h.key].lvl;
    if(hud.classList.contains('tall')){const sc=el.querySelector('[data-sig] i');if(sc)sc.style.width=Math.max(0,Math.min(100,(1-(h.sigT||0)/(SIG[h.key].cd*(1-h.cdr)))*100))+'%';}
    if(hud.classList.contains('tall'))h.spells.forEach((s,i)=>{const S=SPELL[s.arch];const c=el.querySelector(`[data-s="${i}"] i`);if(c)c.style.width=S.passive?'100%':Math.max(0,Math.min(100,(1-s.cdT/(S.cd*(1-h.cdr)))*100))+'%';});}
  if(g.over){return finishStage(g);}
  CC.raf=requestAnimationFrame(loop);
}
/* 0.12.38 (Kyle): a stats brief after each stage: who did what, plus a few awards */
function statsBrief(g){const S=g.stats||{};const keys=Object.keys(S).filter(k=>k!=='?');if(!keys.length)return '';const secs=Math.max(1,g.t||1);
  const nm=k=>k==='flannel_pal'?'Traveling_Companion':(heroDef(k)?heroDef(k).name:((CHAR[k]||{}).name||k));
  const best=(f,min)=>{let b=null,bv=min||0;for(const k of keys){const v=f(S[k]);if(v>bv){bv=v;b=k;}}return b?[b,bv]:null;};
  const aw=[['💥 Most damage',best(s=>s.dmg),v=>fmt(Math.round(v))],['💚 Top healer',best(s=>s.heal,1),v=>fmt(Math.round(v))+' healed'],['💀 Most kills',best(s=>s.kills),v=>v+' kills'],
    ['🎯 Biggest hit',best(s=>s.biggest),v=>Math.round(v)],['🧠 Headshots',best(s=>s.heads),v=>v],['🛟 Revives',best(s=>s.revives),v=>v],['🔍 Searches',best(s=>s.searches),v=>v],['🤏 Sticky fingers',best(s=>s.steals||0),v=>v+' stolen from allies'],['🧨 Defused',best(s=>s.defused||0),v=>v+' mines'],['💥 Wrong wire',best(s=>s.fumbled||0),v=>v+' mines set off'],['💢 Friendly fire',best(s=>s.ff||0),v=>v+' hits on allies'],['🩸 Took the most',best(s=>s.taken),v=>fmt(Math.round(v))+' dmg']]
    .filter(a=>a[1]).map(([t,[k,v],f])=>`<span class="cc-chip" style="margin:2px">${t}: <b>${esc(nm(k))}</b> (${f(v)})</span>`).join('');
  const rows=keys.sort((a,b)=>S[b].dmg-S[a].dmg).map(k=>{const s=S[k];return `<tr><td style="text-align:left">${esc(nm(k))}</td><td>${fmt(Math.round(s.dmg))}</td><td>${(s.dmg/secs).toFixed(1)}</td><td>${fmt(Math.round(s.heal))}</td><td>${s.kills}</td><td>${s.crits}</td><td>${s.heads}</td><td>${fmt(Math.round(s.taken))}</td><td>${s.downs}</td><td>${s.revives}</td><td>${s.searches}</td></tr>`;}).join('');
  return `<div class="cc-card" style="margin-top:8px"><b>📊 Stage stats</b> <span class="cc-sub" style="font-size:11px">${Math.round(secs)}s of fighting</span>
    <div style="margin:6px 0">${aw}</div>
    <div style="overflow-x:auto"><table class="cc-stats" style="border-collapse:collapse;font-size:11px;width:100%;text-align:right"><tr style="opacity:.7"><th style="text-align:left">Unit</th><th>Damage</th><th>DPS</th><th>Healed</th><th>Kills</th><th>Crits</th><th>Heads</th><th>Taken</th><th>Downed</th><th>Revives</th><th>Searches</th></tr>${rows}</table></div></div>`;}
function finishStage(g){
  const s=SLOT(),run=s.run;const first=!g._fin;g._fin=1;   /* 0.12.73: 'give up' after a retry offer comes back through here: don't count the stage twice */
  if(first){g.saveBack();run.score+=Math.round(g.stageScore);s.gold=(s.gold||0)+g.stageGold;
  s.parts=(s.parts||0)+(g.stageParts||0);s.lucky=(s.lucky||0)+(g.stageLucky||0);run.food=(run.food||0)+(g.stageFood||0);run.water=(run.water||0)+(g.stageWater||0);}   /* camp supplies */
  run.lastHaul={food:g.stageFood||0,water:g.stageWater||0,parts:g.stageParts||0};
  const found=[];if(g.over==='clear')for(const it of g.stageItems){const where=giveItem(run,s,it);if(where)found.push(shortCard(it.card)+(where==='bag'?' (backpack)':''));else{const v=Math.round(itemPrice(it.rar,run.stage)/3);s.gold+=v;found.push(shortCard(it.card)+' (sold, no room: +'+v+'g)');}}
  const lvls=run.team.filter(k=>s.heroes[k].lvl>CC.lv0[k]).map(k=>`${esc(heroDef(k).name)} → LV ${s.heroes[k].lvl}`);
  if(g.over==='clear'){
    sfx('clear');
    for(const k of run.team){const h=run.heroes[k];if(h.dead){h.dead=false;h.hpf=.25;}else h.hpf=Math.min(1,(h.hpf||0)+.3);}
    run.needFeed=run.team.filter(k=>k!=='robot');   /* 0.12.58: everyone needs food AND water at camp, except the Warhound */
    if(run.ff)run.campLog2=(run.campLog2?run.campLog2+' ':'')+'🌱 Fall Forward cleared: you got back up and beat it.';run.ff=0;   /* 0.12.237 a clear wipes the stacks */
    if(run.retryUsed){run.retryUsed=0;run.retries=1;run.campLog2='↻ Stage beaten on the retry: you get your retry back.';}   /* 0.12.73 */
    const cleared=run.stage;run.score+=Math.round(5*cleared*(1+run.prestige));   /* 0.12.94: clear bonus 5 x stage (was 250 x stage) */
    if(cleared>=CFG.maxStage){persist();CC.game=null;return showVictory(lvls);}
    if(cleared===CFG.strangerStage&&run.team.length<3&&!run.strangerDone){run.strangerDone=1;const free=s.forsook?[]:DATA.heroes.filter(h=>!run.team.includes(h.key));
      if(CFG.stage(cleared,run.prestige).boss)run.shopAt=cleared+1;run.stage++;persist();CC.game=null;return showStranger(free);}
    if(CFG.stage(cleared,run.prestige).boss)run.shopAt=cleared+1;
    run.stage++;rerollRefill(run);   /* 0.12.239 (Kyle): a win refills the reroll 50% */
    if(run.prestige*100+run.stage-1>s.best.prestige*100+s.best.stage){s.best.stage=run.stage-1;s.best.prestige=run.prestige;}
    persist();CC.game=null;
    const rb=run.campLog2;run.campLog2=null;const P=showPanel(`<div class="cc-h">STAGE ${cleared} CLEAR!</div>${rb?`<p class="cc-sub" style="color:#a6ff2e">${rb}</p>`:''}<p class="cc-sub">+${fmt(Math.round(g.stageScore)+Math.round(5*cleared*(1+run.prestige)))} score · ${g.kills} kills · 💰 +${fmt(g.stageGold)} gold${g.stageParts?' · ⚙ +'+g.stageParts+' spare parts':''}${g.stageFood?' · 🥫 +'+g.stageFood+' food':''}${g.stageWater?' · 💧 +'+g.stageWater+' water':''}${found.length?'<br>Found: '+found.map(esc).join(', '):''}${lvls.length?'<br>'+lvls.join(', '):''}</p>${statsBrief(g)}<div class="cc-row"><button class="cc-btn go" data-c>TO CAMP ▶</button></div>`);
    P.querySelector('[data-c]').onclick=showCamp;return;}
  // defeat
  /* 0.12.85 (Kyle): nobody loses a run any more. A wipe keeps EVERYTHING (gold, parts, food, water, items and XP picked up on the way),
     the party limps back to camp at half health, and you can spend it all to grind out the stage you're stuck on. */
  if(true){sfx('die');
    for(const it of g.stageItems||[]){const where=giveItem(run,s,it);if(where)found.push(shortCard(it.card)+(where==='bag'?' (backpack)':''));else{const v=Math.round(itemPrice(it.rar,run.stage)/3);s.gold+=v;found.push(shortCard(it.card)+' (sold, no room: +'+v+'g)');}}
    for(const k of run.team){const h=run.heroes[k];if(h){h.dead=false;h.hpf=Math.max(.5,h.hpf||0);}}
    run.needFeed=run.team.filter(k=>k!=='robot');run.snap=null;run.retries=1;run.retryUsed=0;run.falls=(run.falls||0)+1;
    /* 0.12.237 (Kyle) Fall Forward: the fall costs 10% of your total score + 50% of what this attempt earned (already added in), less 10/20/30% for the stacks you carried in; then +1 stack (max 3) */
    const att=Math.round(g.stageScore||0),keep=FF.keep[Math.min(3,run.ff||0)],lost=Math.min(run.score,Math.round((.1*run.score+.5*att)*(1-keep)));run.score-=lost;const ff0=run.ff||0;run.ff=Math.min(3,ff0+1);
    const ffLine=`<br><b style="color:#7dff9a">🌱 Fall Forward (Lessons Learned) ${'●'.repeat(run.ff)}${'○'.repeat(3-run.ff)}</b> (${run.ff}/3): until you clear a stage everyone gets <b>+${Math.round(FF.xp[run.ff]*100)}% XP</b>, <b>+${Math.round(FF.gold[run.ff]*100)}% gold piles</b>, and the next fall costs <b>${Math.round(FF.keep[run.ff]*100)}% less score</b>.<br>📉 Score lost: −${fmt(lost)} (10% of your total + half of this attempt's ${fmt(att)}${keep?`, cut ${Math.round(keep*100)}% by your stacks`:''}).`;
    rerollRefill(run);   /* 0.12.239 (Kyle): a loss refills the reroll 50% too */
    persist();CC.game=null;
    const P=showPanel(`<div class="cc-h" style="color:#ff9a3c">THE PARTY FELL BACK</div><div class="cc-h2">Stage ${run.stage}${run.prestige?' · ★'+run.prestige:''}</div>
      <p class="cc-sub">Everything you picked up comes with you: 💰 +${fmt(g.stageGold)} gold${g.stageParts?` · 🔩 +${g.stageParts} parts`:''}${g.stageLucky?` · ${LUCKY_ICON} +${g.stageLucky} Lucky Di${g.stageLucky>1?'ce':'e'}`:''}${(g.stageFood||g.stageWater)?` · 🍖 +${g.stageFood||0} food · 💧 +${g.stageWater||0} water`:''}${found.length?'<br>Items: '+found.map(esc).join(', '):''}${ffLine}${lvls.length?'<br>Level ups: '+lvls.join(', '):''}</p>
      <p class="cc-sub">Everyone gets back up at half health. Rest at camp, spend what you found, and take another run at stage ${run.stage}.</p>
      <div class="cc-row" style="margin-top:12px">${run.pending?`<button class="cc-btn go" data-pk>⬆ CHOOSE UPGRADES (${run.pending})</button>`:''}<button class="cc-btn${run.pending?'':' go'}" data-c>⛺ BACK TO CAMP</button></div>`);
    P.querySelector('[data-c]').onclick=showCamp;{const pk=P.querySelector('[data-pk]');if(pk)pk.onclick=showPick;}return;}
  if((run.retries==null?1:run.retries)>0&&run.snap){sfx('die');CC.game=null;   /* 0.12.73: one retry per run (doesn't stack); beating the stage gives it back */
    const P=showPanel(`<div class="cc-h" style="color:#ff5a5a">YOUR PARTY HAS FALLEN</div><div class="cc-h2">Stage ${run.stage}${run.prestige?' · ★'+run.prestige:''}</div>
      <p class="cc-sub">You have <b style="color:#a6ff2e">1 retry</b> left this run. Retrying puts everything back exactly as it was when this stage started: every hero's HP, items, herbs and kit, your gold, parts and supplies. Beat the stage this time and you get the retry back. Fall again and the run is over.</p>
      <div class="cc-row" style="margin-top:12px"><button class="cc-btn go" data-retry>↻ RETRY STAGE ${run.stage}</button><button class="cc-btn warn" data-giveup>Give up the run</button></div>`);
    P.querySelector('[data-retry]').onclick=()=>{const S=JSON.parse(run.snap);s.run=S.run;s.run.snap=run.snap;s.run.retries=0;s.run.retryUsed=1;s.gold=S.gold;s.parts=S.parts;s.heroes=S.heroes;if(S.best)s.best=S.best;persist();beginStage();};
    P.querySelector('[data-giveup]').onclick=e=>{if(!confirmInline(e.currentTarget,'Really end the run?'))return;run.retries=0;run.snap=null;finishStage(g);};
    return;}
  sfx('die');const reached=run.stage,score=run.score,team=run.team.slice();endRun(s,0);CC.game=null;
  const P=showPanel(`<div class="cc-h" style="color:#ff5a5a">YOUR PARTY HAS FALLEN</div><div class="cc-h2">Stage ${reached}${run.prestige?' · ★'+run.prestige:''}</div>
    <p class="cc-sub">Score ${fmt(score)} · best ${fmt(s.best.score)}. Spells and items are gone; hero levels stay.${lvls.length?'<br>Level ups this stage: '+lvls.join(', '):''}</p>
    <div class="cc-load">${team.map(k=>`<div class="cc-card cc-lh"><span data-por="${k}"></span><div><b>${esc(heroDef(k).name)}</b><div class="cc-sub" style="margin:0">LV ${s.heroes[k].lvl} · ${fmt(s.heroes[k].xp)}/${fmt(needHeroXp(s.heroes[k].lvl))} XP</div></div></div>`).join('')}</div>
    <div class="cc-row" style="margin-top:12px"><button class="cc-btn go" data-again>SAME TEAM AGAIN</button><button class="cc-btn" data-saves>Saves</button></div>`);
  P.querySelectorAll('[data-por]').forEach(e=>e.replaceWith(portrait(e.dataset.por,48)));
  P.querySelector('[data-again]').onclick=()=>{s.team=team.slice();restartSameTeam(s,team);};
  P.querySelector('[data-saves]').onclick=showSlots;
}
function showStranger(free){
  const s=SLOT(),run=s.run;const bless=(forsake)=>{if(forsake){s.forsook=1;}run.blessed=(run.blessed||0)+1;run.pending=(run.pending||0)+1;sfx('level');persist();showCamp();};
  const P=showPanel(`<div class="cc-h">A MYSTERY STRANGER</div><div class="cc-h2">Freed from the castle cells</div>
    ${free.length?`<p class="cc-sub">Someone was chained up in the dungeon. Choose who it turns out to be: they join this run now and this save can bring 3 heroes from then on. Or leave them be for a ⭐ Blessed Upgrade (every option Uncommon or better, with much better odds of Rare), but then <b>this save stays a 2-hero party for good</b>; later runs that clear stage 6 get the blessing again instead.</p>
    <div class="cc-heroes">${free.map(h=>`<button class="cc-hero" data-k="${h.key}"><span data-por="${h.key}"></span><div class="nm">${h.icon} ${esc(h.name)}</div><div class="dk">Inspired by deck: <b>${esc(h.deck)}</b></div><div class="lv">LV ${s.heroes[h.key].lvl}</div></button>`).join('')}</div>
    <div class="cc-row" style="margin-top:12px"><button class="cc-btn warn" data-bless="forsake">Leave them be: ⭐ Blessed Upgrade (2 heroes for good)</button></div>`
    :`<p class="cc-sub">${s.forsook?'You swore off the stranger in this save. The empty cell still holds a gift':'The cell holds only a lingering spirit, with no hero of yours to answer the call yet'}. It leaves you a gift instead: a ⭐ Blessed Upgrade (every option Uncommon or better, with much better odds of Rare).</p>
    <div class="cc-row"><button class="cc-btn go" data-bless>⭐ ACCEPT THE BLESSING</button></div>`}`);
  P.querySelectorAll('[data-por]').forEach(e=>e.replaceWith(portrait(e.dataset.por)));
  P.querySelector('[data-bless]').onclick=e=>{const b=e.currentTarget;if(b.dataset.bless==='forsake'&&!confirmInline(b,'2 heroes for good?'))return;bless(b.dataset.bless==='forsake');};
  P.querySelectorAll('[data-k]').forEach(b=>b.onclick=()=>{const k=b.dataset.k,d=heroDef(k);s.strangerSaved=1;s.partySize=3;run.strangerJoined=1;run.team.push(k);
    run.heroes[k]={hpf:1,dead:false,spells:ABILITIES_OFF?[]:[{card:d.spells[0].card,arch:d.spells[0].arch,r:Math.max(1,Math.min(4,run.stage-3)),augs:[]}],items:[]};if(!ABILITIES_OFF)run.pending=(run.pending||0)+2;sfx('level');persist();showCamp();});
}
function showVictory(lvls){
  const s=SLOT(),run=s.run;const np=run.prestige+1;
  if(run.prestige*100+CFG.maxStage>s.best.prestige*100+s.best.stage){s.best.stage=CFG.maxStage;s.best.prestige=run.prestige;}s.best.score=Math.max(s.best.score,run.score);persist();
  const P=showPanel(`<div class="cc-h">THE CRYPT IS CONQUERED</div><div class="cc-h2">Stage ${CFG.maxStage} cleared${run.prestige?' at ★'+run.prestige:''}</div>
    <p class="cc-sub">Score ${fmt(run.score)}.${lvls.length?' '+lvls.join(', ')+'.':''} More stages are coming. Until then you can <b>Prestige</b>: descend again from stage 1 with your build, monsters much tougher, more score, and rarer loot${np>=2?' (Legendary now possible)':''}.</p>
    <div class="cc-row"><button class="cc-btn go" data-pr>PRESTIGE ★${np}</button><button class="cc-btn" data-ret>Retire this run</button></div>`);
  P.querySelector('[data-pr]').onclick=()=>{run.prestige=np;run.stage=1;run.rerolls=Math.min(DICE_MAX,(run.rerolls||0)+1);persist();showCamp();};
  P.querySelector('[data-ret]').onclick=()=>{endRun(s,1);showSlots();};
}
function quitToCamp(silent){const g=CC.game;if(!g)return;persist();CC.game=null;if(!silent)showCamp();}   // hero XP already banked; the run restarts this stage
// ---------------------------------------------------------------- header strip (attract mode)
function demoGame(W){const keys=DATA.heroes.map(h=>h.key).sort(()=>Math.random()-.5).slice(0,3);
  const run=newRun(keys,null);run.stage=1+Math.floor(Math.random()*8);run.prestige=0;
  for(const k of keys){const d=heroDef(k);run.heroes[k].spells=d.spells.slice(0,2).map(s=>({card:s.card,arch:s.arch,r:4,augs:[]}));}
  const g=new Game({run,slot:null,demo:true,W});for(const h of g.heroes){h.base=heroBase(h.key,8,3);}g.recalc();for(const h of g.heroes)h.hp=h.max;return g;}
let strip,scv,sctx,sg,sraf=0,svis=true,slast=0;
function updateStripTop(){if(!strip)return;const rows=Object.keys(OWNERS).map(p=>({p,b:bestOf(p)})).filter(r=>r.b.stage).sort((a,b)=>(b.b.prestige*100+b.b.stage)-(a.b.prestige*100+a.b.stage)||b.b.score-a.b.score);
  $('.cs-top',strip).textContent=rows.length?`🏆 ${OWNERS[rows[0].p]} ${rows[0].p} · stage ${Math.min(rows[0].b.stage,CFG.maxStage)}${rows[0].b.prestige?' ★'+rows[0].b.prestige:''} · ${fmt(rows[0].b.score)}`:'🏆 No runs yet. Be first.';}
function stripLoop(now){if(!strip||!svis||(root&&!root.hidden)){sraf=0;return;}
  sraf=requestAnimationFrame(stripLoop);if(now-slast<33)return;const dt=Math.min(.05,(now-slast)/1000);slast=now;
  const H=106,W=Math.max(200,Math.round(H*strip.clientWidth/Math.max(1,strip.clientHeight)));
  if(scv.width!==W*RES||!sg||sg.W!==W){scv.width=W*RES;scv.height=H*RES;sg=demoGame(W);}
  sg.step(dt);if(sg.over||!sg.alive().length)sg=demoGame(W);sg.events.length=0;
  if(IMG.complete&&BGI.complete){sctx.imageSmoothingEnabled=false;drawGame(sctx,sg,W,CFG.H-H);}}
function startStrip(){if(strip&&!sraf&&svis)sraf=requestAnimationFrame(stripLoop);}
function stopStrip(){cancelAnimationFrame(sraf);sraf=0;}
function mountStrip(){
  const nav=document.querySelector('.pagetabs');if(!nav||document.getElementById('crawl-strip'))return;
  strip=document.createElement('div');strip.id='crawl-strip';strip.innerHTML=`<canvas aria-hidden="true"></canvas><button class="cs-play" type="button">▶ PLAY CRYPT CRAWL</button><span class="cs-top"></span>`;
  nav.parentNode.insertBefore(strip,nav);scv=strip.querySelector('canvas');sctx=scv.getContext('2d');
  if(!document.getElementById('cc-style')){const st=document.createElement('style');st.id='cc-style';st.textContent=CSS;document.head.appendChild(st);}
  strip.addEventListener('click',openCrawl);updateStripTop();
  try{new IntersectionObserver(es=>{svis=es[0].isIntersecting;if(svis)startStrip();else stopStrip();}).observe(strip);}catch(e){}
  document.addEventListener('visibilitychange',()=>{if(document.hidden)stopStrip();else startStrip();});
  if(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches){svis=false;const go=()=>{const H=106,W=Math.round(H*strip.clientWidth/strip.clientHeight);scv.width=W*RES;scv.height=H*RES;sg=demoGame(W);sctx.imageSmoothingEnabled=false;drawGame(sctx,sg,W,CFG.H-H);};IMG.complete&&BGI.complete?go():BGI.addEventListener('load',go,{once:true});}
  else startStrip();
}
window.CryptCrawl={open:openCrawl,_cc:CC,
  resetPin(who){const d=Save.load();if(d.players[who]){d.players[who].pin=null;Save.write(d);CC.data=d;return who+"'s PIN cleared on this device";}return 'no such player';}};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mountStrip);else mountStrip();