import json, importlib, random, sys, math
sys.path.insert(0, '/home/claude/pod2'); sys.path.insert(0, '/home/claude/pod2/decks')
from formulas import STATS, feeds, body
import re
from math import comb
from plan_tags import tags as plan_tags, RULES as PLAN_RULES, CT as CT_, PLAN_STAT, groups as syn_groups
PT = json.load(open('/home/claude/pod2/pt.json'))

DECKS = ['grim', 'thing', 'mathas', 'marina', 'mech', 'kotis', 'joel', 'turtle', 'kykar', 'weather', 'blood', 'dragons', 'korvold', 'felothar', 'thranduil', 'vile', 'depala', 'mothman', 'casino', 'scare', 'modular', 'family', 'spider', 'zurgo', 'eddie_vivi', 'eddie_bruce', 'eddie_cloud', 'eddie_kasla', 'eddie_splinter', 'eddie_miles', 'eddie_narset', 'robots2']
BASICS = {'Plains', 'Island', 'Swamp', 'Mountain', 'Forest', 'Snow-Covered Plains', 'Snow-Covered Island', 'Snow-Covered Swamp', 'Snow-Covered Mountain', 'Snow-Covered Forest'}
STAT_NAME = {'mana': 'Mana', 'cards': 'Cards', 'consistency': 'Consistency', 'threats': 'Threats',
             'finish': 'Finish', 'reach': 'Reach', 'interaction': 'Interaction', 'survival': 'Survival',
             'politics': 'Politics'}
GROUPS = {'engine': ['mana', 'cards', 'consistency'], 'offense': ['threats', 'finish', 'reach'],
          'defense': ['interaction', 'survival', 'politics']}

def load_info():
    order = [n for v in json.load(open('/home/claude/pod2/fetch_order.json')).values() for n in v]
    rows = open('/home/claude/pod2/card_info.txt').read().strip().split(';')
    assert len(rows) == len(order), (len(rows), len(order))
    info = {}
    for n, r in zip(order, rows):
        salt, mv, typ, rar = r.split(',')
        info[n] = dict(salt=float(salt), mv=float(mv), type=typ, rarity=rar)
    for b in BASICS:
        info[b] = dict(salt=0, mv=0, type='Land', rarity='c')
    return info

def sim_lands(lands, landramp, n=4000, seed=7):
    """Goldfish: share of games with 5+ lands by T6 and 7+ by T8 (on the play)."""
    rng = random.Random(seed)
    deck = ['L'] * lands + ['R'] * landramp + ['X'] * (99 - lands - landramp)
    h6 = h8 = 0
    for _ in range(n):
        rng.shuffle(deck)
        hand = deck[:7]; lib = deck[7:]; bf = 0; ok6 = ok8 = False
        for t in range(1, 9):
            if t > 1:
                hand.append(lib.pop(0))
            if 'L' in hand:
                hand.remove('L'); bf += 1
            if bf >= 2 and 'R' in hand:
                hand.remove('R'); bf += 1
            if t == 6: ok6 = bf >= 5
            if t == 8: ok8 = bf >= 7
        h6 += ok6; h8 += ok6 and ok8
    return h6 / n, h8 / n


# ---- 0.10.1 Feeds the Plan: what each deck's commander / core engine wants
TOKEN = re.compile(r'token|Food|Treasure|Clue|Mutagen|Saproling|Spawn|Scion|Pest|Thrull|Soldier|Citizen|Insect|Ooze|Squirrel|Zombie|Spirit|Rhino|Goblin', re.I)
def _cheap_nc(c):
    return c['type'] not in ('Creature', 'Land') and c['mv'] <= 3
FEEDS = {
    'thing': ('threats', 'cheap noncreature spell for The Thing', _cheap_nc),
    'kykar': ('threats', 'cheap noncreature spell for Kykar/Talrand', _cheap_nc),
    'turtle': ('threats', 'token for Leonardo', lambda c: any(e.get('kind') == 'wide' for e in c['entries']) or bool(TOKEN.search(c['note']))),
    'joel': ('reach', 'token or body for the drain engines', lambda c: any(e.get('kind') == 'wide' for e in c['entries']) or bool(TOKEN.search(c['note']))),
    'mech': ('threats', 'artifact for Tezzeret, crew and animators', lambda c: c['type'] == 'Artifact' or bool(re.search(r'artifact|robot|construct|vehicle|golem|myr|servo|thopter', c['note'], re.I))),
    'marina': ('cards', 'enchantment for the enchantress engines', lambda c: c['type'] == 'Enchantment'),
    'kotis': ('threats', 'aura/equipment for Kotis', lambda c: bool(re.search(r'aura|equipment|equip|mutate', c['note'], re.I))),
    'mathas': ('finish', 'pays your own life down for a swap', lambda c: c['name'] in {
        'Damnable Pact', 'Necrologia', 'Peer into the Abyss', 'Stargaze', 'Cut of the Profits', 'Phyrexian Lens',
        'Starving Revenant', 'Erebos, Bleak-Hearted', "K'rrik, Son of Yawgmoth", 'Read the Bones', "Night's Whisper", 'Phyrexian Arena'}),
    'grim': ('threats', 'fuels the Throne / reanimation', lambda c: c['name'] in {
        'Venomous Changeling', 'Buried Alive', 'Deadbridge Chant', 'Incarnation Technique', 'World Shaper', 'Emry, Lurker of the Loch',
        'Maskwood Nexus', 'Mirror Entity', 'Taurean Mauler'}),
}
ENGINES = {'Leonardo, the Balance', 'Joel, Resolute Survivor', 'Ellie, Vengeful Hunter', 'Dr. Eggman', 'The Thing', "Kykar, Wind's Fury",
           'Kotis, the Fangkeeper', 'Marina Vendrell', 'Mathas, Fiend Seeker', 'Kenrith, the Returned King',
           'Throne of the Grim Captain // The Grim Captain', 'Zada, Hedron Grinder', 'Feather, the Redeemed'}

def _p_at_least(K, k, n, N=99):
    """chance to see at least k of K good cards in n cards (fractional K interpolated)"""
    def p(Ki):
        Ki = max(0, min(N, Ki))
        return 1 - sum(comb(Ki, i) * comb(N - Ki, n - i) / comb(N, n) for i in range(k))
    lo = int(K); f = K - lo
    return p(lo) * (1 - f) + p(lo + 1) * f

def score_deck(key, info):
    mod = importlib.import_module(key)
    M, TAGS = mod.META, mod.TAGS
    raw = json.load(open('/home/claude/pod2/raw_lists.json'))[M['file']]
    cards = []
    missing = []
    for c in raw:
        n = c['name']
        if n in BASICS:
            for _ in range(c['q']):
                cards.append(dict(name=n, note='basic land', entries=[]))
            continue
        if n not in TAGS:
            missing.append(n); continue
        note, entries = TAGS[n]
        cards.append(dict(name=n, note=note, entries=[dict(e) for e in entries]))
    extra = [n for n in TAGS if n not in {c['name'] for c in raw}]
    # card facts
    for c in cards:
        i = info.get(c['name'], dict(salt=0, mv=0, type='?', rarity='?'))
        c.update(mv=i['mv'], type=i['type'], salt=i['salt'], rarity=i['rarity'])
        c['commander'] = c['name'] in M['cmdr']
        c['secret'] = c['name'] in M.get('secret', [])
        bounce = any('bounce land' in e['label'] for e in c['entries'])
        c['is_land'] = c['type'] == 'Land' or bounce
    # 0.10.9 Commander engines: a cheat on the commander (or secret commander) is the deck's planned strategy,
    # always on hand, so it counts as Consistency, not Mana. A repeating one (eng) also makes every card it can
    # put into play (Plan Tag C) count extra in Hit-Rate: +0.5 x its odds.
    free_drop = 0.0
    for c in cards:
        if not (c['commander'] or c['secret']):
            continue
        for e in c['entries']:
            if e.get('kind') == 'cheat':
                e['stat'] = 'consistency'; e['label'] = 'Commander engine: ' + e['label']
                if e.get('eng'):
                    free_drop = max(free_drop, 0.5 * e.get('odds', 1.0))
    # 0.10.7 Plan Tag: C = works with the commander, T = fits the deck's main plan
    for c in cards:
        c['plan'] = plan_tags(key, c['name'], c['is_land']) if not c['commander'] else set()
        if not c['plan']:
            continue
        tot = {}
        for e in c['entries']:
            tot[e['stat']] = tot.get(e['stat'], 0) + e['pts']
        st = max(tot, key=tot.get) if tot and max(tot.values()) > 0 else 'threats'
        route = PLAN_STAT.get(key, {})
        for tg in ('C', 'T'):
            if tg in c['plan'] and route.get(tg):
                st = route[tg]; break
        eng = bool(re.search(r'Whenever|At the beginning|\{T\}:', CT_.get(c['name'], ''), re.I)) and c['type'] != 'Instant' and c['type'] != 'Sorcery'
        what = ' + '.join({'C': 'commander', 'T': 'deck plan'}[x] for x in sorted(c['plan']))
        val = (0.25 if eng else 0.15) + (0.05 if len(c['plan']) == 2 else 0)
        c['entries'].append(dict(stat=st, pts=val, label=f'Plan Tag ({what})', kind='feeds'))
    # 0.10.12 Commander copy engine: Plan Tag C creatures enter twice, so their Tall threat counts x mult
    mult = max([e.get('mult', 1) for c in cards if c['commander'] or c['secret'] for e in c['entries'] if e.get('kind') == 'copyengine'] or [1])
    if mult > 1:
        for c in cards:
            if 'C' in c.get('plan', ()) and c['type'] == 'Creature':
                for e in c['entries']:
                    if e.get('kind') == 'tall':
                        e['pts'] = round(e['pts'] * mult, 3); e['label'] += f' (copied x{mult:g})'
    # 0.10.8 Synergy groups: +0.005 per other card in the group, max 0.15 a group, max 2 groups a card
    from collections import Counter
    gsize = Counter(g for c in cards for g in set(syn_groups(key, c['name'], c['is_land'])))
    for c in cards:
        if c['commander'] or c['is_land']:
            continue
        gs = sorted(set(syn_groups(key, c['name'], c['is_land'])), key=lambda g: -gsize[g])[:2]
        for g, st in gs:
            v = round(min(0.15, 0.005 * (gsize[(g, st)] - 1)), 3)
            if v > 0:
                c['entries'].append(dict(stat=st, pts=v, label=f'Synergy: {g} ({gsize[(g, st)]} cards)', kind='synergy'))
    # wipes: first full, later ones x0.6 (0.10.1)
    wipes = sorted([e for c in cards for e in c['entries'] if e.get('wipe')], key=lambda e: -e['pts'])
    for e in wipes[1:]:
        e['pts'] = round(e['pts'] * 0.6, 3); e['label'] += ' (later wipe x0.6)'
    # 0.10.11 Quick Air: small evasive creatures (not big enough to be a Tall threat) still pressure the table,
    # and cheap ones come out in bunches. +0.10, +0.05 per power (up to 3), +0.10 per mana under 3.
    quick_air = 0; qa_mv = []
    for c in cards:
        if c['type'] != 'Creature' or c['is_land']: continue
        if not any(e.get('kind') == 'evasive' for e in c['entries']): continue
        if any(e.get('kind') == 'tall' for e in c['entries']): continue
        pw = min(PT.get(c['name'], [0, 0])[0], 3)
        v = round(0.10 + 0.05 * pw + 0.10 * max(0, 3 - c['mv']), 3)
        c['entries'].append(dict(stat='threats', pts=v, label=f"Quick Air ({PT.get(c['name'], [0, 0])[0]} power, MV {c['mv']:g})", kind='quickair'))
        quick_air += 1; qa_mv.append(max(1, c['mv']))
    # 0.12.89 Commander engines (Kyle): a commander's own repeatable ability (activated, or every turn / every attack with no
    #   other card needed) is always on hand from the command zone, so those entries count x2. Listed per deck in META['cmd_engine'].
    for c in cards:
        if not (c['commander'] or c['secret']): continue
        ks = M.get('cmd_engine', {}).get(c['name'], [])
        for e in c['entries']:
            if e.get('kind') in ks and not e['label'].startswith('Commander engine'):
                e['pts'] = round(e['pts'] * 2, 3); e['label'] = 'Commander engine (x2): ' + e['label']
    # 0.12.89 New mechanic tags, read straight from card text so every deck gets them the same way
    # 0.12.91 (Kyle): in a token deck convoke spells often cost only 1-2 real mana. Bodies = creatures + 2 per token maker.
    bodies = sum(1 for c in cards if c['type'] == 'Creature') + 2 * sum(1 for c in cards if re.search(r'create (a|an|one|two|three|four|five|six|X|that many|\d+) .{0,60}creature tokens?', CT_.get(c['name'], ''), re.I))
    def ck_of(mv):
        if bodies >= 60: return max(1, mv - 2)    # token engine: you pay about 2 at most
        if bodies >= 40: return max(1, mv - 3)    # wide board: you pay about 3
        if bodies >= 25: return min(mv - 1, 2)
        return min(mv - 1, 1)
    for c in cards:
        if c['is_land']: continue
        tx = CT_.get(c['name'], ''); tl = tx.split('\n')[1] if '\n' in tx else ''
        # Convoke: the board pays part of the cost (1-3 mana, by how many creatures and token makers the deck has)
        if re.search(r'\bConvoke\b', tx) and c['mv'] > 1:
            k = ck_of(c['mv'])
            c['entries'].append(dict(stat='mana', pts=round(0.06 * k, 3), label=f'Convoke: the board pays about {k:g} of its {c["mv"]:g} mana (mana left for other spells)', kind='convoke'))   # its tags already use the real cost it's cast for
        # Ninjutsu / Sneak: comes in attacking and unblocked at instant speed, and returns the attacker (re-use its ETB, dodge a kill)
        if re.search(r'\b(Commander )?[Nn]injutsu \{|\bSneak \{', tx) and 'Creature' in tl:
            pw = PT.get(c['name'], [0, 0])[0]
            if not any(e.get('kind') == 'evasive' and e.get('ev') == 'unblock' for e in c['entries']):
                c['entries'].append(dict(stat='reach', pts=round((0.05 + 0.10 * pw * 1.25) * 0.6, 3), label=f'Ninjutsu: enters attacking and unblocked ({pw} power, needs an unblocked attacker)', kind='ninjutsu'))
                c['entries'].append(dict(stat='finish', pts=round(min(0.3, 0.05 + 0.025 * pw) * 0.6, 3), label=f'Finish (Unblockable): ninjutsu {pw} power in unblocked', kind='finish', ftype='Unblockable'))
            c['entries'].append(dict(stat='survival', pts=0.1, label='Ninjutsu: returns the attacker to hand (dodges removal, re-use its ETB)', kind='survive', part='Protect'))
        # Job select: the Equipment makes a 1/1 Hero and attaches to it
        if re.search(r'\bJob select\b', tx):
            from formulas import wide as _wide
            for e in _wide(1, c['mv'], label=f"Threat: Wide (1) Job select: makes a 1/1 Hero token to carry it (MV:{c['mv']:g})"): c['entries'].append(e)
        # Ward: a tax on every spell aimed at it (light hexproof)
        m = re.search(r'\b[Ww]ard (\{(\d+)\}|—)', tx)
        if m and not any(e.get('kind') == 'ward' for e in c['entries']):
            n = int(m.group(2)) if m.group(2) else 3
            c['entries'].append(dict(stat='survival', pts=round(min(0.3, 0.08 + 0.05 * n), 3), label=f'Ward {n}: every removal spell costs {n} more', kind='ward'))
    # 0.10.14 Vehicles dodge creature wipes cast at sorcery speed: +0.15 Survival each
    for c in cards:
        if not c['is_land'] and re.search(r'Vehicle', CT_.get(c['name'], '').split('\n')[1] if '\n' in CT_.get(c['name'], '') else ''):
            c['entries'].append(dict(stat='survival', pts=0.15, label='Vehicle: dodges creature wipes', kind='survive', part='Endure'))
    # 0.10.16 Free / cheap equips: a deck with cards that skip or cut equip costs gets the equip-cost penalty back
    FREE_EQ = re.compile(r'rather than pay the equip cost|[Ee]quip abilities you activate.{0,60}cost \{\d\} less|[Ee]quip costs?.{0,40}less|attach (it|target Equipment|any number of target Equipment|an Equipment)', re.S)
    free_eq = [c['name'] for c in cards if not c['is_land'] and FREE_EQ.search(CT_.get(c['name'], ''))]
    if free_eq:
        for c in cards:
            for e in c['entries']:
                if e.get('pump') and e.get('eqpen'):
                    e['pts'] = round(e['pts'] + e['eqpen'], 3); e['label'] += ' (equip cost covered)'
    # 0.10.1 Body floor: creatures scoring under 0.5 count their body
    for c in cards:
        if c['type'] == 'Creature' and not c['is_land'] and sum(e['pts'] for e in c['entries']) < 0.5 and c['name'] in PT:
            c['entries'] += body(*PT[c['name']])
    # 0.10.4 Wide saturation: Wide points past 10 count half (scaled across every token maker)
    wide = [e for c in cards for e in c['entries'] if e.get('kind') == 'wide']
    W = sum(e['pts'] for e in wide)
    if W > 10:
        f = (10 + 0.5 * (W - 10)) / W
        for e in wide:
            e['pts'] = round(e['pts'] * f, 3)
        adj_note_wide = f'Wide saturation: {W:.1f} Wide points, past 10 count half (x{f:.2f})'
    else:
        adj_note_wide = None
    # 0.10.1 politics: Aim (single-target removal = you choose who) and counterspells as Deals
    aims = cnts = 0
    for c in cards:
        at = {e.get('atype') for e in c['entries'] if e.get('kind') == 'answer' and not e.get('wipe')}
        if 'Counter' in at and cnts < 5:
            cnts += 1; c['entries'].append(dict(stat='politics', pts=0.15, label='Politics (Deals): counterspell leverage', kind='politics', levers=['Deals']))
        elif 'Removal' in at and aims < 8:
            aims += 1; c['entries'].append(dict(stat='politics', pts=0.10, label='Politics (Direction): Aim', kind='politics', levers=['Direction']))
    # ---------------- 0.12.1 rules from Kyle's notes ----------------
    cmd_tx = ' '.join(CT_.get(c['name'], '') for c in cards if c['commander'] or c['secret'])
    def ctx(c): return re.sub(r'\([^()]*\)', '', CT_.get(c['name'], ''))
    # a) Suit Up stacking: only the first few suited-up pieces really matter
    su = sorted([e for c in cards for e in c['entries'] if e['label'].startswith('Finish (Suit Up)')], key=lambda e: -e['pts'])
    for i, e in enumerate(su):
        w = 1 if i < 4 else 0.5 if i < 8 else 0.25
        if w < 1:
            e['pts'] = round(e['pts'] * w, 3); e['label'] += f' (suit-up piece #{i+1}: x{w:g})'
    # b) Recursion stacking: the 7th+ recursion engine adds less
    rec = sorted([c for c in cards if any(e.get('part') == 'Recover' for e in c['entries'])],
                 key=lambda c: -sum(e['pts'] for e in c['entries'] if e.get('part') == 'Recover'))
    for i, c in enumerate(rec):
        w = 1 if i < 5 else 0.6 if i < 8 else 0.4
        if w < 1:
            for e in c['entries']:
                if e.get('part') == 'Recover':
                    e['pts'] = round(e['pts'] * w, 3); e['label'] += f' (recursion #{i+1}: x{w:g})'
    for c in cards:
        if c['is_land'] or c['commander']: continue
        tx = ctx(c); low = tx.lower()
        typ = CT_.get(c['name'], '\n').split('\n')[1] if '\n' in CT_.get(c['name'], '') else ''
        # c) Rebuild: a repeatable token maker refills the board after a wipe
        rep_tok = any(('create' in l.lower() and 'token' in l.lower()) and (l.startswith(('Whenever', 'At the beginning')) or '}:' in l or ', {T}:' in l or l.startswith('{'))
                      for l in tx.split('\n')) and 'Instant' not in typ and 'Sorcery' not in typ
        if rep_tok or any(e.get('kind') == 'wide' and e.get('eng') for e in c['entries']):
            c['entries'].append(dict(stat='survival', pts=0.15, label='Rebuild: keeps making bodies after a wipe', kind='survive', part='Recover'))
        # d) Commander that must connect (combat-damage trigger): evasion and double strike on it matter more
        if re.search(r'deals combat damage to a player', cmd_tx, re.I):
            if re.search(r'(equipped|enchanted|target) creature[^.]{0,60}(has|have|gains?)[^.]{0,40}double strike', low):
                c['entries'].append(dict(stat='cards', pts=0.4, label='Double strike: the commander hits twice, so its combat-damage trigger happens twice', kind='feeds'))
            elif re.search(r'(equipped|enchanted|target) creature[^.]{0,60}(has|have|gains?)[^.]{0,40}(flying|menace|shadow|trample|can\'t be blocked)|can\'t be blocked', low) and ('Aura' in typ or 'Equipment' in typ or 'Instant' in typ):
                c['entries'].append(dict(stat='reach', pts=0.25, label='Connects the commander: evasion for a commander that has to hit', kind='givesev'))
        # e) Mutate commander: a double strike creature under it gives the mutated pile double strike
        if 'Mutate' in cmd_tx and 'Creature' in typ and re.search(r'(^|\n)([A-Z][a-z]+, )*[Dd]ouble strike', tx):
            c['entries'].append(dict(stat='finish', pts=0.4, label='Mutate base: the commander mutates onto it and gains double strike', kind='finish'))
        # f) "Enters or attacks" commander without haste: haste givers get it an extra trigger the turn it lands
        if re.search(r'enters or attacks', cmd_tx, re.I) and not re.search(r'(^|\n)[^\n]*\bhaste\b', cmd_tx.split('\n----\n')[0] if False else '') and \
           re.search(r'(equipped|enchanted|target) creature[^.]{0,60}(has|have|gains?)[^.]{0,30}haste|creatures you control (have|gain) [^.]{0,20}haste', low):
            c['entries'].append(dict(stat='threats', pts=0.3, label='Haste for the commander: its attack trigger fires the turn it lands', kind='feeds'))
        # g) "Whenever you sacrifice" commander: a free, repeatable sacrifice outlet turns every token into a card
        if re.search(r'Whenever you sacrifice', cmd_tx, re.I) and re.search(r'(^|\n)Sacrifice (a|an|another) [^:\n]{0,40}:', tx):
            c['entries'].append(dict(stat='cards', pts=0.3, label='Free sacrifice outlet: every sacrifice draws with the commander', kind='feeds'))
    # per-card totals
    for c in cards:
        c['stats'] = {s: 0.0 for s in STATS}
        for e in c['entries']:
            c['stats'][e['stat']] += e['pts']
        c['total'] = round(sum(c['stats'].values()), 3)
    pts = {s: round(sum(c['stats'][s] for c in cards), 3) for s in STATS}
    adj = {s: [] for s in STATS}
    # ---- Mana base check
    lands = [c for c in cards if c['is_land']]
    nl = len(lands)
    ramp_cards = [c for c in cards if not c['is_land'] and any(e.get('kind') == 'ramp' for e in c['entries'])]
    if nl >= 36 or (nl >= 33 and len(ramp_cards) >= 12):
        adj['mana'].append((0.5, f'{nl} lands with {len(ramp_cards)} ramp cards: +0.5'))
    elif nl < 33:
        adj['mana'].append((-0.5, f'only {nl} lands: -0.5'))
    else:
        adj['mana'].append((0, f'{nl} lands with {len(ramp_cards)} ramp cards: no change'))
    unt = 0.0
    for c in lands:
        es = [e for e in c['entries'] if e.get('kind') == 'land']
        if c['name'] in BASICS: unt += 1
        elif es:
            en = es[0]['entry']; unt += 1 if en == 'U' else 0 if en == 'T' else en
    share = unt / max(1, nl)
    if share >= 0.75: adj['mana'].append((0.25, f'{share:.0%} of lands usually enter untapped: +0.25'))
    elif share < 0.5: adj['mana'].append((-0.25, f'only {share:.0%} of lands usually enter untapped: -0.25'))
    else: adj['mana'].append((0, f'{share:.0%} of lands usually enter untapped: no change'))
    fix = sum(1 for c in lands if any(e.get('fix') for e in c['entries']) or any('bounce land' in e['label'] for e in c['entries']))
    fix += sum(1 for c in cards if not c['is_land'] and any(e.get('kind') == 'fixing' for e in c['entries']))
    need = 5 * (M['colors'] - 1)
    short = max(0, need - fix)
    pen = -0.25 * (short // 3)
    adj['mana'].append((pen, f'color strain: {fix}/{need} fixing sources' + (f' -> {pen}' if pen else ' -> ok')))
    landramp = sum(1 for c in cards if not c['is_land'] and any(e.get('landramp') for e in c['entries']))
    h6, h8 = sim_lands(nl, landramp)
    ld = 0.75 if h8 >= 0.7 else 0.5 if h6 >= 0.7 else 0
    adj['mana'].append((ld, f'land drops: {h6:.0%} reach 5 lands by T6, {h8:.0%} also 7 by T8 -> +{ld}'))
    # ---- Threat variety
    kinds = set()
    for c in cards:
        for e in c['entries']:
            if e['stat'] == 'threats' and e['pts'] > 0.05 and e.get('kind') in ('tall', 'wide', 'board', 'ncthreat'):
                kinds.add({'tall': 'Tall', 'wide': 'Wide', 'board': 'Board Power', 'ncthreat': 'Noncreature'}.get(e['kind'], e['kind']))
                if c['commander']: kinds.add('Commander')
    tv = 1 if len(kinds) >= 4 else -1 if len(kinds) <= 1 else 0
    adj['threats'].append((tv, f"threat kinds: {', '.join(sorted(kinds))} -> {tv:+d}"))
    # Air density: how many small evasive creatures, divided by their average mana value (cheap ones come out in bunches)
    avg_qa = sum(qa_mv) / len(qa_mv) if qa_mv else 0
    qa = round(0.60 * quick_air / avg_qa, 2) if quick_air else 0
    adj['threats'].append((qa, f'Air density: {quick_air} small evasive creatures / average MV {avg_qa:.1f} x 0.60 -> +{qa}'))
    if adj_note_wide:
        adj['threats'].append((0, adj_note_wide))
    # ---- Interaction coverage
    cov = set()
    for c in cards:
        for e in c['entries']:
            if e.get('kind') == 'answer' and e['pts'] > 0:
                cov |= set(e.get('kinds', '')) & set('caepgs')
    cv = 1 if len(cov) >= 4 else -1 if cov <= {'c'} else 0
    names = {'c': 'creatures', 'a': 'artifacts', 'e': 'enchantments', 'p': 'planeswalkers', 'g': 'graveyards', 's': 'spells'}
    adj['interaction'].append((cv, f"answers: {', '.join(names[k] for k in 'caepgs' if k in cov)} -> {cv:+d}"))
    # ---- Politics levers + salt
    lev = {'Deals': 0, 'Deterrents': 0, 'Direction': 0}
    for c in cards:
        ls = set()
        for e in c['entries']:
            for l in e.get('levers', []) or []: ls.add(l)
        for l in ls: lev[l] += 1
    sp = 0.5 * sum(1 for v in lev.values() if v >= 3)
    adj['politics'].append((sp, f"levers: Deals {lev['Deals']}, Deterrents {lev['Deterrents']}, Direction {lev['Direction']} -> +{sp}"))
    salt = round(sum(c['salt'] for c in cards if not (c['is_land'] and c['salt'] < 0.15)), 1)
    sn = 1 if salt < 20 else 0 if salt <= 40 else -1 if salt <= 60 else -2
    adj['politics'].append((sn, f'deck salt {salt} -> {sn:+d}'))
    # ---- 0.10.4 Hit-Rate and Plan B (Consistency), answers and closers on time
    K = KB = 0.0
    for c in cards:
        if c['is_land'] or c['commander']:
            continue
        reuse = 0.25 if any(e.get('kind') == 'second' for e in c['entries']) else 0
        if c['plan']:
            K += (1.0 if len(c['plan']) == 2 else 0.5) + reuse
            if 'C' in c['plan']:
                K += free_drop
            if 'T' in c['plan']:
                KB += 1
        elif any(e.get('kind') == 'tutor' for e in c['entries']):
            K += 1
        elif any(e.get('kind') == 'select' and e['pts'] > 0.1 for e in c['entries']):
            K += 0.5
    K = round(K, 2)
    fd = f', +{free_drop:g} per card the commander can drop free' if free_drop else ''
    p1, p2, pb = _p_at_least(K, 2, 10), _p_at_least(K, 3, 10), _p_at_least(KB, 2, 10)
    adj['consistency'].append((round(3 * p1 + 1 * p2, 2), f'Hit-Rate: {K:g} plan-card weight (both tags 1, one tag 0.5{fd}) + finders, {p1:.0%} to see two and {p2:.0%} to see three in your first 10 cards -> +{3*p1+p2:.2f}'))
    adj['consistency'].append((round(1.5 * pb, 2), f'Plan B: {KB:g} cards on the deck plan (work without the commander), {pb:.0%} to see two in 10 cards -> +{1.5*pb:.2f}'))
    na = sum(1 for c in cards if any(e.get('kind') == 'answer' and e['pts'] > 0.1 for e in c['entries']))
    pa = _p_at_least(na, 1, 10)
    adj['interaction'].append((round(1.0 * pa, 2), f'Answer on time: {na} answers, {pa:.0%} to hold one by turn 4 -> +{pa:.2f}'))
    nf = sum(1 for c in cards if c['stats']['finish'] >= 0.3 if 'stats' in c) if False else \
         sum(1 for c in cards if sum(e['pts'] for e in c['entries'] if e['stat'] == 'finish') >= 0.3)
    pf = _p_at_least(nf, 1, 13)
    adj['finish'].append((round(0.75 * pf, 2), f'Closer on time: {nf} finishers, {pf:.0%} to see one by turn 7 -> +{0.75*pf:.2f}'))
    # 0.10.16 Suit-up stack: pump Equipment/Auras plus double strike sources multiply one creature's hit
    npump = sum(1 for c in cards if any(e.get('pump') for e in c['entries']))
    nds = sum(1 for c in cards if not c['is_land'] and 'double strike' in CT_.get(c['name'], '').lower())
    if npump >= 4 and nds:
        v = round(0.25 * min(6, nds) * min(1.0, npump / 8), 2)
        adj['finish'].append((v, f'Suit-up stack: {npump} pump Equipment/Auras and {nds} double strike sources -> +{v:g}'))
    final = {s: round(pts[s] + sum(a for a, _ in adj[s]), 3) for s in STATS}
    nonland = [c for c in cards if not c['is_land']]
    avg_mv = round(sum(c['mv'] for c in nonland) / max(1, len(nonland)), 2)
    return dict(key=key, meta=M, cards=cards, pts=pts, adj=adj, final=final, missing=missing, extra=extra,
                lands=nl, salt=salt, avg_mv=avg_mv, land_drop=round(h6, 2), land_drop8=round(h8, 2),
                untapped=round(share, 2), fixing=fix, need=need, levers=lev, coverage=sorted(cov), kinds=sorted(kinds))

def run():
    info = load_info()
    res = [score_deck(k, info) for k in DECKS]
    # divide numbers: second-highest deck = 10
    divs = {}
    for r in res:   # 0.10.1: Politics is rated on the square root of its points
        r['final']['politics_raw'] = r['final']['politics']
        r['final']['politics'] = round(math.sqrt(max(0, r['final']['politics'])), 3)
    for s in STATS:
        vals = sorted([r['final'][s] for r in res], reverse=True)
        divs[s] = round(vals[1] / 11, 4) if vals[1] > 0 else 1   # 0.10.19: second-best deck = 11, so the top one or two decks in every stat go blue (10+)
    divs['mana'] = 4.00   # 0.10.1: fixed Mana divide (user's call), so strong ramp decks can pass 10
    for r in res:
        r['rating'] = {}
        for s in STATS:
            v = r['final'][s] / divs[s]
            r["rating"][s] = min(15, max(1, int(math.floor(v + 0.5))))
        def g(ss):
            return sum(min(10, r['rating'][s]) + 0.5 * max(0, r['rating'][s] - 10) for s in ss)
        for gk, ss in GROUPS.items():
            r[gk] = g(ss)
        r['total'] = r['engine'] + r['offense'] + r['defense']
    return res, divs

if __name__ == '__main__':
    res, divs = run()
    for r in res:
        if r['missing'] or r['extra']:
            print(r['key'], 'MISSING', r['missing'], 'EXTRA', r['extra'])
    print('divides', divs)
    for r in sorted(res, key=lambda r: -r['total']):
        print(f"{r['meta']['deck'][:22]:22} tot {r['total']:5.1f} | " + ' '.join(f"{s[:4]} {r['final'][s]:5.1f}/{r['rating'][s]:2d}" for s in STATS))
