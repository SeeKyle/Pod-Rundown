"""0.12.128 (Kyle) THE HOLLOW WRAITH, stage 20 boss. Original pixel art drawn by code (same shaded-primitive toolkit as the
Harvest Knight). A towering hooded shade: a deep cowl with nothing inside but two cold cyan eyes, a ragged indigo robe that
frays into drifting shadow tendrils instead of legs, skeletal blue-grey hands, and a long scythe with an ice-blue glowing
blade. Cyan motes, rune-stitched hem, and a cold halo. 160x160 frames, facing right (the game flips it).
Rows: idle (float), drift, dash (fast fly), sweep (scythe), claw (grab + drain), cast (orbs), hurt, death (dissolve)."""
import math, random, json, importlib.util
import numpy as np
from PIL import Image
spec = importlib.util.spec_from_file_location('mh', '/home/claude/pod2/make_harvest.py'); mh = importlib.util.module_from_spec(spec); spec.loader.exec_module(mh)
mh.OUTL = (6, 6, 18)
Canvas, ramp, rot = mh.Canvas, mh.ramp, mh.rot
FW = FH = 160
GROUND = 154

ROBE = [(6, 7, 18), (12, 14, 34), (20, 22, 52), (30, 32, 74), (44, 46, 102), (64, 66, 136), (92, 96, 170)]
INNER = [(2, 2, 6), (6, 6, 14), (10, 10, 24)]
BONE = [(40, 48, 66), (70, 82, 104), (108, 122, 146), (150, 166, 188), (196, 210, 226)]
HAFT = [(14, 14, 22), (28, 28, 40), (44, 44, 60), (64, 64, 84)]
ICE = [(24, 46, 72), (44, 86, 124), (80, 142, 182), (130, 200, 230), (190, 238, 252), (236, 252, 255)]
CYAN, CYAN2, CYANW = (70, 230, 230), (40, 170, 190), (200, 255, 255)


def glow(C, x, y, r, col, st=1.0):
    for oy in range(-int(r) - 1, int(r) + 2):
        for ox in range(-int(r) - 1, int(r) + 2):
            yy, xx = int(y + oy), int(x + ox)
            if 0 <= yy < FH and 0 <= xx < FW:
                w = max(0, 1 - math.hypot(ox, oy) / r) ** 1.5 * st
                C.add[yy, xx] += (col[0] * w * .5, col[1] * w * .5, col[2] * w * .5)


def wraith(P, seed=1):
    C = Canvas(); R = random.Random(seed)
    bob, lean = P.get('bob', 0), P.get('lean', 0)
    core = (78 + P.get('dx', 0), 86 + bob)            # chest
    head = rot((core[0] + 4, core[1] - 30), core, lean); head = (head[0] + P.get('hx', 0), head[1] + P.get('hy', 0))
    sh_f = rot((core[0] + 12, core[1] - 16), core, lean)
    sh_b = rot((core[0] - 10, core[1] - 17), core, lean)
    ph = P.get('ph', 0); trail = P.get('trail', 0); gl = P.get('glow', 1.0)
    limb = lambda o, a, l: (o[0] + math.sin(a) * l, o[1] + math.cos(a) * l)

    # --- shadow tendrils (behind): long tapering strands streaming down and back from the hem, waving
    hem_y = core[1] + 42
    for i in range(8):
        sx = core[0] - 18 + i * 5.2
        pts = [(sx, hem_y - 6)]
        L_ = 22 + (i * 7 % 13) + trail * 30
        for k in range(1, 9):
            t = k / 8
            pts.append((sx - t * (8 + trail * 60) + math.sin(ph * 6.28 + i * 1.3 + t * 4) * (3 + t * 4), hem_y - 6 + t * L_ * (1 - trail * .55)))
        for k in range(8):
            r0 = 3.4 * (1 - k / 8) + .4; r1 = 3.4 * (1 - (k + 1) / 8) + .3
            C.capsule(pts[k], pts[k + 1], r0, r1, ROBE, bias=-.25 - k * .03)
        if i % 3 == 0:
            ex, ey = pts[-1]; glow(C, ex, ey, 3, CYAN2, .5 * gl)

    # --- back arm (sleeve + claw)
    def arm(sh, A, front, reach=1.0):
        el = limb(sh, A[0], 15 * reach); hand = limb(el, A[0] + A[1], 15 * reach)
        b = 0 if front else -.18
        C.capsule(sh, el, 6.5, 7.5, ROBE, bias=b - .02)                       # wide hanging sleeve
        C.capsule(el, limb(el, A[0] + A[1], 5), 7.5, 8.5, ROBE, bias=b - .08, tex=lambda x, y, t, k: (-.2 if (x + y) % 5 == 0 else 0))
        cuff = limb(el, A[0] + A[1], 5)
        C.capsule(cuff, hand, 2.0, 1.6, BONE, bias=b - .05)                   # skeletal forearm
        ca = A[0] + A[1]
        for f in range(4):                                                      # long claw fingers
            fa = ca + (f - 1.5) * .28
            k1 = limb(hand, fa, 5); k2 = limb(k1, fa + .5 * P.get('curl', .4), 4)
            C.line(hand, k1, ramp(BONE, .55 + b)); C.line(k1, k2, ramp(BONE, .7 + b))
            if front or P.get('clawglow'): glow(C, k2[0], k2[1], 2.2, CYAN, .45 * gl * (1.6 if P.get('clawglow') else 1))
        return el, hand
    if not P.get('claw_front'): el_b, hand_b = arm(sh_b, P.get('ab', (.25, -.3)), False, P.get('reach_b', 1.0))

    # --- robe body: a tall tattered bell from shoulders to hem, rune-stitched
    top_l, top_r = rot((core[0] - 15, core[1] - 20), core, lean), rot((core[0] + 15, core[1] - 20), core, lean)
    sway = P.get('sway', 0)
    pts = [top_l, top_r, (core[0] + 20 + sway * 3, core[1] + 14), (core[0] + 24 + sway * 6, hem_y)]
    for i in range(9):                                                          # ragged hem, longer at the back
        x = core[0] + 24 + sway * 6 - i * 6.2
        pts.append((x - trail * i * 2, hem_y + (6 if i % 2 else 0) + R.randint(0, 3) + i * .8 * (1 + trail)))
    pts.append((core[0] - 26 - trail * 14, core[1] + 6))
    C.poly(pts, ROBE, base=.42, grad=(-.15, -.18), edge=.2, tex=lambda x, y: (-.1 if (x * 3 + y) % 9 == 0 else 0) + (.06 if (x + y * 2) % 13 == 0 else 0))
    for k in range(5):                                                          # long vertical folds
        fx = core[0] - 14 + k * 7
        C.line((fx, core[1] - 8), (fx - 2 - trail * 6, hem_y - 2), ramp(ROBE, .2))
    for i in range(14):                                                         # glowing runes stitched along the hem
        rx = core[0] + 18 - i * 3.2 - trail * i; ry = hem_y - 4 + (i % 3)
        if i % 2 == 0: C.put(int(rx), int(ry), CYAN2); glow(C, rx, ry, 1.6, CYAN2, .35 * gl)

    # --- mantle: a ragged short cape over the shoulders
    m = [rot(p, core, lean) for p in [(core[0] - 19, core[1] - 22), (core[0] + 18, core[1] - 22), (core[0] + 22, core[1] - 8)]]
    for i in range(7):
        m.append((core[0] + 20 - i * 6.5 - trail * 5, core[1] - 4 + (5 if i % 2 else 0) + R.randint(0, 2)))
    m.append((core[0] - 22 - trail * 6, core[1] - 10))
    C.poly(m, ROBE, base=.55, grad=(-.2, -.1), edge=.24)

    # --- hood: a deep pointed cowl, its opening a void with two cold eyes
    hx, hy = head
    C.blob(hx - 2, hy + 1, 14, 16, ROBE, bias=.0, rot=lean)
    C.poly([(hx - 12, hy - 6), (hx - 6, hy - 18), (hx - 14, hy - 24), (hx - 2, hy - 15), (hx + 8, hy - 10)], ROBE, base=.5, edge=.2)   # peak flopping back
    C.blob(hx + 4, hy + 2, 8.5, 10.5, INNER, bias=-.3, rot=lean + .15)       # the void
    C.blob(hx + 7, hy + 1, 4.5, 8, INNER, bias=-.4)
    for k in range(10):                                                          # cowl rim catches the light
        a = -1.2 + k * .26
        C.put(int(hx + 4 + math.cos(a) * 9.5), int(hy + 2 + math.sin(a) * 11.5), ramp(ROBE, .78))
    for ex, ey in ((hx + 3, hy + 1), (hx + 9, hy)):
        C.put(int(ex), int(ey), CYANW); C.put(int(ex) + 1, int(ey), CYANW); C.put(int(ex), int(ey) + 1, CYAN); C.put(int(ex) + 1, int(ey) + 1, CYAN)
        glow(C, ex, ey, 6 * P.get('eyes', 1), CYAN, 1.5 * gl)
    if P.get('wisp'):                                                            # mist curling out of the hood
        for k in range(6): glow(C, hx + 10 + k * 2, hy + 6 - k * 3 + math.sin(ph * 6 + k), 2.2, CYAN2, .25)

    if P.get('claw_front'): arm(sh_b, P.get('ab', (.25, -.3)), True, P.get('reach_b', 1.0))   # the grabbing arm comes out in front of the robe
    # --- scythe (front hand): a dark haft with a long ice-blue crescent blade
    af = P.get('af', (-.25, -.6)); wa = P.get('wa', -1.35); HL = P.get('haft', 62)
    hand_pos = limb(limb(sh_f, af[0], 15), af[0] + af[1], 15)
    hx_, hy_ = hand_pos
    top = (hx_ + math.cos(wa) * HL * .72, hy_ + math.sin(wa) * HL * .72)
    butt = (hx_ - math.cos(wa) * HL * .28, hy_ - math.sin(wa) * HL * .28)
    C.capsule(butt, top, 1.9, 1.7, HAFT, bias=.05, tex=lambda x, y, t, k: (.25 if int(t * 30) % 9 == 0 else 0))
    for k in range(3): glow(C, butt[0] + (top[0] - butt[0]) * (.2 + k * .3), butt[1] + (top[1] - butt[1]) * (.2 + k * .3), 1.5, CYAN2, .3 * gl)   # glowing bands
    bd = P.get('bd', 1); spine = [top]; ang = wa + bd * 1.5; n_ = 20; Lb = 58
    for i in range(n_):
        t = (i + 1) / n_; ang += bd * .07 * (1 + t)
        spine.append((spine[-1][0] + math.cos(ang) * Lb / n_, spine[-1][1] + math.sin(ang) * Lb / n_))
    backs, fronts = [], []
    for i, (x, y) in enumerate(spine):
        t = i / n_; j = min(i, n_ - 1)
        dx, dy = spine[j + 1][0] - spine[j][0], spine[j + 1][1] - spine[j][1]; ll = math.hypot(dx, dy) or 1
        nx, ny = -dy / ll * bd, dx / ll * bd
        wb, wf = 2.2 * (1 - t) + .5, 8.5 * (1 - t ** 1.4) + .3
        backs.append((x - nx * wb, y - ny * wb)); fronts.append((x + nx * wf, y + ny * wf))
    C.poly(backs + fronts[::-1], ICE, base=.55, grad=(-.1, -.05), edge=.3, tex=lambda x, y: (.12 if (x * 5 + y * 3) % 11 == 0 else 0))
    for i in range(n_):
        C.line(fronts[i], fronts[i + 1], CYANW if i % 4 else CYAN)
        mx, my = fronts[i]; glow(C, mx, my, 3.2, CYAN, .55 * gl * P.get('edge', 1))
    C.blob(top[0], top[1], 2.8, 2.8, HAFT, bias=.2)
    el_f, hand_f = arm(sh_f, af, True)

    # --- effects
    for (sx, sy) in P.get('smear', []): C.add[int(sy) % FH, int(sx) % FW] += (90, 200, 220)
    for (ox, oy, r) in P.get('orbs', []):
        glow(C, ox, oy, r * 2.4, CYAN, .9); C.blob(ox, oy, r, r, ICE, bias=.35)
    for (a0, b0, a1, b1) in P.get('ribbons', []):
        for k in range(24):
            t = k / 23; x = a0 + (a1 - a0) * t; y = b0 + (b1 - b0) * t + math.sin(t * 9 + ph * 6) * 3
            glow(C, x, y, 1.6, CYAN, .7)
    for (x, y, l) in P.get('streak', []):
        for k in range(int(l)): C.add[int(y) % FH, int(x - k) % FW] += (30, 90, 110)
    glow(C, core[0], core[1] - 6, 26, (40, 120, 160), .12 * gl)                  # cold aura
    return C


def frame(P, seed=1): return wraith(P, seed).finish()


def anims():
    A = {}
    A['idle'] = [dict(bob=round(math.sin(i / 6 * 6.28) * 3), ph=i / 6, sway=math.sin(i / 6 * 6.28) * .5, af=(.45, -.5), ab=(.3, -.35), wa=-1.05, glow=.9 + .1 * math.cos(i), wisp=1) for i in range(6)]
    A['drift'] = [dict(bob=round(math.sin(i / 6 * 6.28) * 2), ph=i / 6, lean=.08, trail=.25, sway=-.6, af=(.5, -.45), ab=(.5, -.2), wa=-1.0, wisp=1) for i in range(6)]
    A['dash'] = [dict(bob=-2, ph=i / 6, lean=.32, trail=.85, sway=-1.2, af=(.6, -.2), ab=(1.0, -.1), wa=-2.85, hx=2, glow=1.2,
                      streak=[(60 + k * 8, 60 + k * 14 + i % 2 * 3, 24 + (k * 7 + i * 3) % 14) for k in range(5)]) for i in range(6)]
    sw = [(-.4, -1.9, 0), (-1.6, -3.0, 0), (-2.3, -3.6, 0), (-1.2, -2.2, 1), (.2, -.6, 1), (.8, .4, 1), (.9, .7, 0), (.3, -.6, 0)]
    S = []
    for i, (sa, wa, sm) in enumerate(sw):
        pts = [(84 + math.cos(-2.6 + k * .1) * 50, 70 + math.sin(-2.6 + k * .1) * 50) for k in range(30)] if sm else []
        S.append(dict(af=(sa, -.3), ab=(.2 + sa * .3, -.5), wa=wa, lean=[0, -.12, -.18, .05, .2, .25, .2, .08][i], ph=i / 8, trail=[.1, 0, 0, .3, .5, .5, .3, .1][i], smear=pts, glow=1.1, edge=1.4 if sm else 1))
    A['sweep'] = S
    cl = []
    for i in range(7):   # the back claw lunges out, grabs, drains (cyan ribbons flow back into the hood)
        reach = [1.0, 1.25, 1.6, 1.7, 1.7, 1.4, 1.0][i]
        rib = [(124, 82, 92, 58), (126, 88, 94, 60)] if 3 <= i <= 5 else []
        cl.append(dict(claw_front=1, ab=(1.55, -.1 if i < 2 else .15), reach_b=reach, lean=[0, .1, .22, .25, .25, .15, .05][i], ph=i / 7, trail=.3, clawglow=1, curl=[.4, .2, .1, .9, .9, .6, .4][i],
                       af=(.45, -.5), wa=-1.05, ribbons=rib, glow=1 + (.3 if rib else 0)))
    A['claw'] = cl
    cs = []
    for i in range(6):
        orbs = [(80 + math.cos(i * .9 + k * 2.1) * (14 + i * 2), 36 + math.sin(i * .9 + k * 2.1) * 6 - i, 2 + i * .45) for k in range(3)]
        cs.append(dict(af=(-2.4, -.2), ab=(-2.7, .2), haft=48, wa=-1.5, lean=-.08, bob=-2, ph=i / 6, eyes=1.3 + i * .1, glow=1.2 + i * .08, orbs=orbs, wisp=1))
    A['cast'] = cs
    A['hurt'] = [dict(lean=-.22, hx=-2, glow=.5, eyes=.6, af=(.5, -.4), ab=(.4, -.3), wa=-.95, trail=.2), dict(lean=-.1, glow=.75, af=(.45, -.5), ab=(.3, -.3), wa=-1.0)]
    return A


def death_frames():
    """the shade unravels: the robe frays apart into rising motes and drifting tendrils, the eyes go last, the scythe falls and shatters"""
    out = []; R = random.Random(5)
    for i in range(10):
        k = i / 9
        im = frame(dict(lean=-.1 + k * .2, bob=round(k * 6), trail=.3 + k * .5, glow=1 - k * .5, eyes=1.4 - k, af=(.3 + k, -.3), ab=(.5, -.3), wa=-1.2 + k * 1.6, ph=k), seed=60 + i)
        a = np.array(im); h, w = a.shape[:2]
        rng = np.random.default_rng(i)
        frac = min(1, k * 1.15)
        yy = np.mgrid[0:h, 0:w][0]
        kill = rng.random((h, w)) < (frac * (1.15 - yy / h * .5))                 # the bottom unravels first
        a[kill, 3] = 0
        out_im = Image.fromarray(a, 'RGBA')
        C = Canvas()
        for _ in range(int(40 * k) + 6):                                           # motes drifting up
            x = 50 + R.uniform(0, 60); y = 130 - R.uniform(0, 110) * k
            C.add[int(y) % FH, int(x) % FW] += (60, 200, 210)
        if i >= 6:                                                                 # ice shards on the ground
            for s_ in range(8): C.line((60 + s_ * 6, GROUND - 1), (62 + s_ * 6, GROUND - 3 - (s_ % 3)), ICE[3 - s_ % 2])
        out_im.alpha_composite(C.finish(outline=False))
        out.append(out_im)
    return out


def build():
    A = anims()
    rows = [(k, [frame(P, seed=11 + i) for i, P in enumerate(v)]) for k, v in A.items()]
    rows.append(('die', death_frames()))
    ncol = max(len(f) for _, f in rows)
    sheet = Image.new('RGBA', (ncol * FW, len(rows) * FH), (0, 0, 0, 0)); meta = {}
    for r, (k, fr) in enumerate(rows):
        for i, im in enumerate(fr): sheet.alpha_composite(im, (i * FW, r * FH))
        meta[k] = dict(fw=FW, fh=FH, n=len(fr), ax=80, ay=GROUND, x=0, y=r * FH, img='wraith', art=0)
    sheet.save('/home/claude/pod2/crawl_wraith.png', optimize=True)
    return meta


if __name__ == '__main__':
    m = build(); print(json.dumps({k: (v['n'], v['y']) for k, v in m.items()}))
