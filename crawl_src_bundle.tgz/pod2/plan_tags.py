"""Plan Tag (0.10.7). C = works alongside the commander(s). T = fits the deck's main game plan beyond the commander.
Worked out from each card's saved text and type line, plus a few hand calls (ADD / DROP)."""
import json, re
CT = json.load(open('/home/claude/pod2/card_text.json'))

def info(name):
    t = CT[name]
    faces = t.split('\n----\n')
    types = ' '.join(f.split('\n')[1] for f in faces if len(f.split('\n')) > 1)
    body = re.sub(r'\([^()]*\)', '', t)
    return types, body

def _mv(tx):
    m = re.match(r'[^\n{]*((\{[^}]+\})+)', tx.split('\n')[0])
    if not m: return 0
    return sum(int(x) if x.isdigit() else 0 if x == 'X' else 1 for x in re.findall(r'\{([^}]+)\}', m.group(1)))

R = lambda pat: (lambda ty, tx: re.search(pat, tx, re.I) is not None)
TY = lambda pat: (lambda ty, tx: re.search(pat, ty, re.I) is not None)
ANY = lambda *fs: (lambda ty, tx: any(f(ty, tx) for f in fs))
NONCREATURE = lambda ty, tx: 'Creature' not in ty.split('—')[0] and 'Land' not in ty
INST_SORC = TY(r'Instant|Sorcery')

RULES = {
 'grim': dict(
   C=('creature types for The Grim Captain\'s craft (Dinosaur, Merfolk, Pirate, Vampire, changeling) or a creature Kenrith can make huge / bring back',
      ANY(TY(r'Dinosaur|Merfolk|Pirate|Vampire'), R(r'Changeling|every creature type'))),
   T=('big-creature cheat: power 6+, putting creatures into play, cascade into the Throne, or graveyard fuel',
      ANY(R(r'put (a|up to|that|those)? ?creature card.{0,40}onto the battlefield|put a permanent card.{0,40}onto the battlefield|Cascade|mill|graveyard to the battlefield|costs \{X\} less'),
          lambda ty, tx: any(int(p) >= 6 for p in re.findall(r'\n(\d+)/\d+', tx))))),
 'thing': dict(
   C=('a noncreature spell that grows The Thing, or helps him connect (evasion, extra combat, counters)',
      ANY(NONCREATURE, R(r'can\'t be blocked|additional combat|\+1/\+1 counter'))),
   T=('noncreature-spell payoffs and big mana',
      ANY(R(r'Whenever you cast a noncreature spell|noncreature spells you cast|first noncreature spell|cast a noncreature spell this turn'), R(r'add four mana|adds one mana of any type that land produced|draw an additional card')))),
 'mathas': dict(
   C=('bounty counters, or removal that kills an opponent\'s bountied creature so you draw',
      ANY(R(r'bounty'), lambda ty, tx: bool(re.search(r'Destroy target (nonblack )?creature|Exile target creature|-5/-5|sacrifices a creature|destroy all creatures|Destroy target creature or|attacking creature on the bottom|sacrifices the rest|sacrifices thirteen', tx, re.I)))),
   T=('life as a resource: life swaps, paying or losing your own life for cards, drains, pillowfort',
      R(r'exchange life totals|Redistribute|pay \w+ life|pay X life|lose[s]? (X|\d+|half) life|loses X life|you lose|can\'t attack you|lose life equal|each opponent loses'))),
 'marina': dict(
   C=('a Room for Marina to lock and unlock, or an enchantment her ETB finds',
      TY(r'Enchantment')),
   T=('enchantress draw, Curses that steer the table, Spirit tokens',
      R(r'enchantment (spell|you control) .{0,20}(enters|cast)|enchantment spell|enchantments you control|Constellation|Eerie|Curse|enchanted player|Spirit')) ),
 'mech': dict(
   C=('a Construct, Robot or Vehicle Dr. Eggman can put into play for free',
      TY(r'Construct|Robot|Vehicle')),
   T=('artifact payoffs, animating artifacts, crewing',
      ANY(TY(r'Artifact'), R(r'artifact'))) ),
 'kotis': dict(
   C=('suits up Kotis or helps him connect: auras, equipment, evasion, combat-damage payoffs, casting opponents\' spells',
      ANY(TY(r'Aura|Equipment'), R(r'can\'t be blocked|deals combat damage to a player|spell (they|you) don\'t own|Mutate'))),
   T=('mutate creatures and card draw on hits',
      R(r'Mutate|combat damage to (a player|one of your opponents)|draw a card'))),
 'joel': dict(
   C=('makes creature tokens for Joel, or a creature for Ellie to sacrifice',
      ANY(R(r'create .{0,40}creature token|Saproling|Sacrifice (a|another) creature'))),
   T=('aristocrats: creatures dying drain, draw or come back',
      R(r'(creature|token) (you control )?(dies|leaves)|Whenever (another|a) (nontoken )?creature you control dies|each opponent loses 1 life|sacrifice'))),
 'turtle': dict(
   C=('makes tokens for Leonardo, or uses the counters he hands out',
      ANY(R(r'create|token'), R(r'with (a )?counters? on|\+1/\+1 counter'))),
   T=('go-wide anthems and team pumps',
      R(r'creatures you control (get|gain|have)|Other creatures you control|each creature you control|for each token'))),
 'weather': dict(
   C=('a snow card Isu can play off the top of the library (and that grows Isu when it enters)',
      TY(r'Snow')),
   T=('tap-down and freeze effects, 4+ power payoffs, and cards that scale with your snow count',
      ANY(R(r"tap (target|up to|one or two|X|all) .{0,40}creatures?|tap an untapped creature|becomes tapped|doesn't untap|stun counter|power 4 or greater|greatest power|snow (permanent|land)s?|amount of \{S\}"),
          lambda ty, tx: 'Creature' in ty and any(int(p) >= 4 for p in re.findall(r'\n(\d+)/\d+', tx))))),
 'blood': dict(
   C=('a Bat: Zoraline gains a life each time one attacks, and many are 3-drops she can bring back',
      TY(r'Bat')),
   T=('life gain and drain: gaining or losing life pays you, or makes opponents lose life',
      R(r'gain(ed)? (\d+ |that much |X )?life|you gain|lifelink|loses? (\d+|X|that much) life|each opponent loses|gain or lose life|gained or lost life|Extort|life total'))),
 'dragons': dict(
   C=('a nontoken Dragon Miirym copies when it enters',
      TY(r'Dragon')),
   T=('Dragon payoffs, Dragon finders and the big mana to cast them',
      R(r'Dragon|power 4 or greater|Treasure'))),
 'korvold': dict(
   C=('something to sacrifice (tokens, Treasures, Food, fodder) or a way to sacrifice, each one a card and a counter for Korvold',
      R(r'[Ss]acrifice|Treasure|Food|Clue|Spawn|Scion|\btokens?\b')),
   T=('aristocrats: creatures dying or being sacrificed drain, ping, make mana or draw',
      R(r'dies|died|creature dying|leave the battlefield|you sacrifice|player sacrifices'))),
 'robots': dict(
   C=('an artifact creature for Optimus to bolster, or a counter / +1/+1 payoff that grows the Robot army',
      ANY(lambda ty, tx: 'Artifact' in ty and 'Creature' in ty, R(r'\+1/\+1 counter|bolster|modified'))),
   T=('artifact engine: cost reducers, draw-on-artifact, copies, animating artifacts and artifact recursion',
      R(r'artifact (spell|card|you control|creature)|artifacts you control|for each artifact|Affinity for artifacts|Improvise|historic|noncreature artifact'))),
 'kykar': dict(
   C=('a noncreature spell for Kykar, or a spell that targets your creature for Zada and Feather',
      ANY(NONCREATURE, R(r'target creature( you control)? (gets|gains)'))),
   T=('spellslinger payoffs: tokens, pings and growth from instants and sorceries',
      R(r'Whenever you cast (an instant or sorcery|a noncreature) spell|instant and sorcery|Prowess'))),
 'felothar': dict(
   C=('a high-toughness creature or defender Felothar turns into an attacker (toughness 4+ over power), or a sac outlet for his draw',
      ANY(R(r'Defender'), lambda ty, tx: 'Creature' in ty and any(int(t) >= 4 and int(t) > int(p) for p, t in re.findall(r'\n(\d+)/(\d+)', tx)), R(r'toughness'))),
   T=('walls-and-toughness plan: toughness payoffs, wipes that spare 0-power walls, and creatures dying / coming back',
      R(r'toughness|power 2 or less|total power 4 or less|damage to itself equal to its power|dies|graveyard to the battlefield|defender'))),
 'thranduil': dict(
   C=('an Elf: legendary Elves draw with Thranduil, Elves in the graveyard lend him their abilities',
      TY(r'Elf')),
   T=('Elf tribal payoffs, Elf mana and big creature copies',
      R(r'Elf|Elves|copy of target creature|copies of'))),
 'vile': dict(
   C=('a 5+ mana value spell for Vial Smasher\'s burn (first spell each turn hits for its MV), or a card that rides on opponents casting spells for Ishai',
      ANY(lambda ty, tx: _mv(tx) >= 5, R(r'an opponent casts|each player draws|first spell each turn'))),
   T=('wheels and discard punishers: everyone dumping and drawing hands while you burn them',
      R(r'discards? (your|their|all|his) hand|draws? seven|discard a card|whenever (an opponent|a player) draws|discards a card|draws? (an additional|two|a) card|each player'))),
 'depala': dict(
   C=('a Dwarf Depala pumps, a Vehicle she crews (her tap digs for more), or a payoff for crewing',
      ANY(TY(r'Dwarf|Vehicle'), R(r'\bcrew|becomes tapped'))),
   T=('equipment and vehicle payoffs: suiting up, free equips, artifacts entering',
      ANY(TY(r'Equipment'), R(r'Equipment|equipped|artifact (entered|enters)|Vehicles? you control|Storied')))),
 'mothman': dict(
   C=('mills cards (each nonland card milled spreads Mothman counters) or uses the +1/+1 counters',
      ANY(R(r'\bmill|milled|surveil'), R(r'\+1/\+1 counter|proliferate|counters? on'))),
   T=('Zombie army: makes, pumps or brings back Zombies',
      ANY(TY(r'Zombie'), R(r'Zombie')))),
 'casino': dict(
   C=('rolls dice (rolls of 4+ make Mr. House Robots) or makes Treasure to pump his roll',
      ANY(R(r'\broll|d20|d6|d4|d10|d12|six-sided|die\b|dice'), R(r'Treasure'))),
   T=('Treasure engine and artifact payoffs',
      ANY(R(r'Treasure'), R(r'sacrifice an artifact|artifact creatures?|three or more artifacts|artifacts you control')))),
 'scare': dict(
   C=('a mutate creature or non-Human body for Illuna to mutate onto',
      ANY(R(r'Mutate'), lambda ty, tx: 'Creature' in ty and 'Human' not in ty)),
   T=('big threats that grow, plus draw off big creatures',
      ANY(R(r'power 4 or greater|power 3 or greater|\+1/\+1 counter|double its power|equal to the number of lands'), lambda ty, tx: 'Creature' in ty and _mv(tx) >= 5))),
 'modular': dict(
   C=('Equipment for Gilgamesh to drop in free, or a card that copies/boosts his trigger',
      ANY(TY(r'Equipment'), R(r'triggered ability|Equipment'))),
   T=('suit-up beatdown: equips, extra combats, haste and big mana',
      ANY(TY(r'Equipment'), R(r'additional combat|equipped|Equipment|haste|modified|\{C\}\{C\}')))),
 'family': dict(
   C=('a cheap creature worth an offspring copy (ETBs twice) or a base-power-1 body for Zinnia',
      lambda ty, tx: 'Creature' in ty and (_mv(tx) <= 4 or re.search(r'When .{0,30}enters', tx, re.I) is not None)),
   T=('fliers, tap-downs and creatures-entering payoffs',
      ANY(R(r'Flying|flying'), R(r'\btap target|tap up to|stun|doesn\'t untap|enters tapped'), R(r'another creature you control enters|creature token you control|token you control enters')))),
 'spider': dict(
   C=('a Spider (Cosmic Spider-Man gives every Spider all five keywords) or a Spider payoff',
      ANY(TY(r'Spider'), R(r'Spider'))),
   T=('counters and legendary Hero payoffs',
      ANY(R(r'\+1/\+1 counter|modified|legendary'), TY(r'Hero')))),
 'zurgo': dict(
   C=('a Warrior, or a copy/mobilize effect whose temporary tokens Zurgo keeps',
      ANY(TY(r'Warrior'), R(r'Warrior'), R(r'token that\'s a copy|tokens that are copies|copy of (it|that|another|target)|mobilize|myriad'))),
   T=('go-wide Warrior army: anthems, haste, extra attackers',
      ANY(R(r'creatures you control get|other (Warriors|Giants|creatures)|haste|attacking|Giant'), TY(r'Giant')))),
}
ADD = {'grim': {'T': {'Ardent Plea', 'Shardless Agent', 'Buried Alive', 'Greater Good', 'Altar of the Wretched // Wretched Bonemass',
                      "Lifestream's Blessing", 'Prime Speaker Zegana', "Angrath's Marauders", "Selvala's Stampede", 'The Coming of Galactus',
                      'Scavenged Brawler', 'Victimize', 'Symbiote Spider-Man', "Silver Surfer, Galactus's Herald"},
               'C': {'Maskwood Nexus', 'Mirror Entity'}},
       'thing': {'C': {'Doc Samson, Super Psychiatrist', 'Echo, Perceptive Prodigy', 'Gogo, Master of Mimicry'},
                 'T': {"King T'Challa // Black Panther, Hope Enduring", 'The Unagi of Kyoshi Island', 'Kynaios and Tiro of Meletis', 'Thundertrap Trainer', 'Rites of Flourishing'}},
       'mathas': {'T': {'Ghostly Prison', "Norn's Annex", 'Mystic Barrier', 'Champions of Minas Tirith', 'Axis of Mortality', 'Soul Conduit',
                        'Peer into the Abyss', 'Sower of Discord', 'Double Vision', 'Cursed Recording', 'Marshland Bloodcaster', 'Inside Information'}},
       'marina': {'C': {'Bello, Bard of the Brambles', 'Displacer Kitten'}},
       'kotis': {'C': {'Felix Five-Boots', 'Unnatural Growth', 'Quietus Spike', 'Colossification', 'Gonti, Night Minister', 'Villainous Wealth',
                       'Tasha, the Witch Queen', 'Ivy, Gleeful Spellthief', 'The Thirteenth Doctor', 'Snakeskin Veil', 'Baleful Eidolon', 'Forgotten Ancient'}},
       'turtle': {'T': {'Jetmir, Nexus of Revels', 'King Darien XLVIII', 'Beastmaster Ascension', 'Raphael, the Muscle', 'End-Raze Forerunners'},
                  'C': {'Skullclamp'}},
       'joel': {'T': {'South Wind Avatar', 'Grave Venerations', 'Cauldron of Essence', 'Bastion of Remembrance', 'Goblin Bombardment',
                      'Deathreap Ritual', 'Arnyn, Deathbloom Botanist', 'Grave Researcher // Reanimate', 'Essenceknit Scholar'},
                'C': {'Ellie, Brick Master', 'Jaheira, Friend of the Forest'}},
       'mech': {'T': {'Tezzeret, Master of the Bridge', 'Chief Engineer', 'Rise and Shine', 'One with the Machine', 'Masterful Replication'}},
       'weather': {'C': {'Branching Evolution'}, 'T': {'Radstorm', 'The Pride of Hull Clade'}},
       'blood': {'C': {'Banishing Light', 'Valley Questcaller', 'Etchings of the Chosen', 'Desecrated Tomb', 'Regal Bloodlord', 'Lunar Convocation', 'Valley Rotcaller'}},
       'dragons': {'C': {'Blur', 'Master Biomancer'}, 'T': {'Reflections of Littjara', 'Multiversal Incursion', "Soul's Majesty"}},
       'korvold': {'C': {'Reassembling Skeleton'}},
       'robots': {'T': {'Tameshi, Reality Architect', 'Extravagant Replication', 'Emry, Lurker of the Loch'}},
       'felothar': {'C': {"Captain America's Shield", 'Spike Weaver'}, 'T': {'Morbid Opportunist', 'Priest of Forgotten Gods', "Martyr's Bond", 'Covetous Elegy'}},
       'vile': {'C': {'Echo, Perceptive Prodigy'}},
       'kykar': {'C': {'Tenth District Legionnaire'}, 'T': {'God-Eternal Kefnet', 'Salvager of Secrets', 'Micromancer'}},
       }
DROP = {'mathas': {'T': {'Final Act'}}, 'joel': {'T': {'Pick Your Poison'}}}

def tags(key, name, is_land):
    if is_land or name not in CT: return set()
    ty, tx = info(name)
    out = set()
    for k in ('C', 'T'):
        if RULES[key][k][1](ty, tx): out.add(k)
        if name in ADD.get(key, {}).get(k, ()): out.add(k)
        if name in DROP.get(key, {}).get(k, ()): out.discard(k)
    return out

# Where the Plan Tag bonus goes, when the synergy clearly lands in one stat (often a deck's weak spot).
# None = the card's own best stat.
PLAN_STAT = {
 'thing':  {'C': 'threats'},   # noncreature spells grow The Thing into the deck's real threat
 'kykar':  {'C': 'mana'},      # every noncreature spell is a Spirit = a red mana for Kykar
 'kotis':  {'C': 'threats'},   # auras/equipment turn Kotis into the must-answer threat
 'joel':   {'C': 'cards', 'T': 'reach'},    # token deaths draw with Joel; the death-drain pile skips combat
 'mathas': {'C': 'cards'},     # a bountied creature dying draws you a card
}

# ---- 0.10.8 Synergy groups: things the deck stacks (creature types AND non-creature themes).
# Every card in a group gets a tiny bonus that grows with how many other cards share the group:
#   +0.005 per other card in the group, max +0.15 per group, max 2 groups per card.
NONCREATURE_SPELL = lambda ty, tx: 'Creature' not in ty.split('—')[0] and 'Land' not in ty
GROUPS = {   # (name, matcher, stat the bonus goes to)
 'grim': [
   ('craft types (Dinosaur/Merfolk/Pirate/Vampire/changeling)', ANY(TY(r'Dinosaur|Merfolk|Pirate|Vampire'), R(r'Changeling|every creature type')), 'threats'),
   ('huge creatures (power 6+)', lambda ty, tx: any(int(p) >= 6 for p in re.findall(r'\n(\d+)/\d+', tx)), 'threats'),
   ('graveyard (mill / reanimate / from your graveyard)', R(r'\bmill|(from|in|into) (a|your) graveyard|graveyard to the battlefield'), 'survival'),
 ],
 'thing': [
   ('noncreature spells', NONCREATURE_SPELL, 'threats'),
   ('+1/+1 counters', R(r'\+1/\+1 counter|double the number|counters on'), 'threats'),
   ('extra combats & evasion', R(r'additional combat|can\'t be blocked'), 'reach'),
   ('noncreature-spell payoffs', R(r'Whenever you cast (a|your first) noncreature spell|cast a noncreature spell this turn|Noncreature spells you cast'), 'cards'),
   ('copies triggers', R(r'Copy target (activated or )?triggered ability|triggers an additional time'), 'threats'),
   ('extra-draw package', R(r'second card each turn|draws an additional card'), 'cards'),
 ],
 'mathas': [
   ('paying / losing your own life', R(r'pay \w+ life|pay X life|pay life|you lose|loses? (X|half|\d+) life|lose life equal'), 'cards'),
   ('life swaps & life-total tricks', R(r'exchange life totals|Redistribute|loses half|life total'), 'finish'),
   ('bounty counters', R(r'bounty'), 'cards'),
   ('pillowfort & taxes', R(r'can\'t attack you|unless their controller pays|only the nearest opponent'), 'politics'),
 ],
 'marina': [
   ('Rooms', TY(r'Room'), 'cards'),
   ('Curses', TY(r'Curse'), 'politics'),
   ('enchantment payoffs', R(r'enchantment (you control )?(enters|spell)|Constellation|Eerie|enchantments you control'), 'cards'),
   ('Spirits', R(r'Spirit'), 'threats'),
 ],
 'mech': [
   ('Robots & Constructs', TY(r'Robot|Construct'), 'threats'),
   ('Vehicles & crew', ANY(TY(r'Vehicle'), R(r'\bcrew')), 'threats'),
   ('artifact payoffs', R(r'artifacts? you control|artifact spells|historic|affinity for artifacts|for each artifact'), 'mana'),
 ],
 'kotis': [
   ('auras & equipment', ANY(TY(r'Aura|Equipment'), R(r'Bestow')), 'threats'),
   ('mutate', R(r'Mutate'), 'threats'),
   ('combat-damage triggers', R(r'combat damage to (a player|one of your opponents)|deals damage to an opponent'), 'cards'),
   ('casting opponents\' cards', R(r'spell (they|you) don\'t own|their library.{0,80}(cast|play)|opponent\'s library'), 'cards'),
 ],
 'joel': [
   ('Fungus & Saprolings', R(r'Fungus|Saproling'), 'threats'),
   ('death triggers', R(r'(dies|die|died)\b|leaves the battlefield'), 'reach'),
   ('sacrifice outlets', R(r'Sacrifice (a|another|any number of|two) (other )?(non-Eldrazi )?(creature|Saproling)'), 'reach'),
 ],
 'turtle': [
   ('tokens', R(r'token'), 'threats'),
   ('+1/+1 counters', R(r'\+1/\+1 counter|counter on it|counters on'), 'threats'),
   ('Food', R(r'Food'), 'survival'),
   ('Ninjas & Turtles', TY(r'Ninja|Turtle'), 'threats'),
 ],
 'weather': [
   ('snow permanents', TY(r'Snow'), 'threats'),
   ('tap-down & freeze', R(r"doesn't untap|stun counter|[Tt]ap (X|up to|one or two|all|target) .{0,30}creature"), 'interaction'),
   ('4+ power payoffs', R(r'power 4 or greater|greatest power|power of target'), 'cards'),
   ('mana dorks & untappers', R(r'\{T\}: (Add|Untap)|Untap another target snow'), 'mana'),
 ],
 'blood': [
   ('Bats', TY(r'Bat'), 'threats'),
   ('life-gain drains', R(r'Whenever you gain life|if you gained life|you gained life this turn'), 'reach'),
   ('life changes matter', R(r'gain or lose life|gained or lost life|lost life this turn'), 'cards'),
 ],
 'dragons': [
   ('Dragons', TY(r'Dragon'), 'threats'),
   ('Dragon payoffs', R(r'Dragons? (spell|you control|card|creature)|Dragons you control|another nontoken Dragon'), 'finish'),
   ('Treasure & mana', R(r'Treasure|Add (one|two) mana|\{T\}: Add'), 'mana'),
 ],
 'korvold': [
   ('sacrifice outlets', R(r'Sacrifice (a|another|two other|this) ?(other )?(creature|permanent|nonland|land|artifact)|As an additional cost to cast this spell, sacrifice|Kicker—Sacrifice'), 'survival'),
   ('death payoffs', R(r'dies|died|creature dying'), 'reach'),
   ('tokens & Treasures', R(r'create|Treasure|Food|Clue|Spawn|Scion'), 'mana'),
 ],
 'robots': [
   ('Robots & artifact creatures', lambda ty, tx: 'Artifact' in ty and 'Creature' in ty, 'threats'),
   ('artifact payoffs', R(r'artifact (spell|you control|creatures you control|enters)|artifacts you control|for each (other )?artifact'), 'cards'),
   ('+1/+1 counters & modified', R(r'\+1/\+1 counter|modified|bolster'), 'threats'),
   ('Iron Man suits', R(r'Iron (Man|Lad|Spider)|War Machine'), 'threats'),
 ],
 'kykar': [
   ('instants & sorceries', TY(r'Instant|Sorcery'), 'threats'),
   ('spell payoffs (cast an instant or sorcery / noncreature)', R(r'Whenever you cast (an instant or sorcery|a noncreature|an instant)|Prowess|instant and sorcery'), 'reach'),
   ('targets your own creature (Zada / Feather)', R(r'[Tt]arget creature( you control)? (gets \+|gains)|Target creature you control|target artifact or creature|that targets'), 'finish'),
   ('flying tokens & fliers', R(r'Flying|flying'), 'reach'),
 ],
 'felothar': [
   ('defenders & walls', R(r'Defender'), 'threats'),
   ('toughness matters', R(r'toughness'), 'threats'),
   ('death & recursion', R(r'dies|graveyard to the battlefield|return .{0,40} from your graveyard'), 'threats'),   # 0.12.1: recursion brings walls back to attack; Survival already counts the recursion itself
   ('sacrifice outlets', R(r'Sacrifice (another|a) creature'), 'cards'),
 ],
 'thranduil': [
   ('Elves', TY(r'Elf'), 'threats'),
   ('Elf payoffs', R(r'Elf|Elves'), 'threats'),
   ('mana dorks', R(r'\{T\}: Add'), 'mana'),
   ('creature copies', R(r'copy|copies'), 'finish'),
 ],
 'vile': [
   ('wheels', R(r'discards? (your|their) hand|each player discards|draws? seven'), 'cards'),
   ('discard & draw punishers', R(r'discards? a card|draws a card|whenever an opponent draws|Whenever you discard|cycle or discard'), 'reach'),
   ('burn & drain', R(r'damage to (each|that|target) (opponent|player)|loses? (\d+|X|half) life|each opponent loses'), 'reach'),
   ('reanimation', R(r'graveyard to the battlefield|from a graveyard onto the battlefield|Madness'), 'survival'),
 ],
 'depala': [
   ('Dwarves', TY(r'Dwarf'), 'threats'),
   ('Vehicles & crew', ANY(TY(r'Vehicle'), R(r'\bcrew')), 'threats'),
   ('Equipment', ANY(TY(r'Equipment'), R(r'Equipment|equipped|equip')), 'threats'),
   ('Treasure & storied', R(r'Treasure|Storied|historic'), 'mana'),
 ],
 'mothman': [
   ('mill', R(r'\bmill|milled'), 'threats'),
   ('Zombies', ANY(TY(r'Zombie'), R(r'Zombie')), 'threats'),
   ('+1/+1 counters', R(r'\+1/\+1 counter|proliferate|counters'), 'threats'),
   ('graveyard returns', R(r'from (your|a|all) graveyards?.{0,40}(battlefield|hand|cast)|Reanimate|cast .{0,30}from your graveyard'), 'survival'),
 ],
 'casino': [
   ('dice', R(r'\broll|d20|six-sided|dice'), 'mana'),
   ('Treasure', R(r'Treasure'), 'mana'),
   ('Dragons', TY(r'Dragon'), 'threats'),
   ('token anthems', R(r'tokens? you control get|Creature tokens'), 'threats'),
 ],
 'scare': [
   ('mutate', R(r'Mutate|mutates'), 'threats'),
   ('power 4+ payoffs', R(r'power 4 or greater|power 3 or greater'), 'cards'),
   ('combat-damage draw', R(r'combat damage to a player.{0,60}draw|deal combat damage to a player, draw'), 'cards'),
   ('mana dorks', R(r'\{T\}: Add'), 'mana'),
 ],
 'modular': [
   ('Equipment', ANY(TY(r'Equipment'), R(r'Equipment|equipped')), 'threats'),
   ('extra combats', R(r'additional combat'), 'finish'),
   ('big colorless mana', R(r'\{C\}\{C\}|seven \{R\}|adds one mana of any type that land produced|Add \{R\} for each'), 'mana'),
 ],
 'family': [
   ('fliers', R(r'Flying|flying'), 'reach'),
   ('tap-downs', R(r'\btap target|tap up to|stun counter|doesn\'t untap|tap an untapped creature|tapped creature'), 'interaction'),
   ('creatures entering', R(r'another creature you control enters|creature you control enters|token you control enters|tokens? you control'), 'threats'),
 ],
 'spider': [
   ('Spiders', ANY(TY(r'Spider'), R(r'Spider')), 'threats'),
   ('+1/+1 counters', R(r'\+1/\+1 counter|modified'), 'threats'),
   ('web-slinging', R(r'Web-slinging|web-slinging'), 'mana'),
 ],
 'zurgo': [
   ('Warriors', ANY(TY(r'Warrior'), R(r'Warrior')), 'threats'),
   ('copies kept', R(r'token that\'s a copy|tokens that are copies|mobilize|myriad'), 'threats'),
   ('Giants', ANY(TY(r'Giant'), R(r'Giant')), 'threats'),
   ('haste & pumps', R(r'haste|creatures you control get'), 'threats'),
 ],
}

def groups(key, name, is_land):
    if is_land or name not in CT: return []
    ty, tx = info(name)
    return [(g, st) for g, f, st in GROUPS.get(key, []) if f(ty, tx)]

# ---- Eddie's decks (0.12.80)
RULES['eddie_vivi'] = dict(
  C=('a noncreature spell that grows Vivi and pings the table, or gear that protects / carries him',
     ANY(NONCREATURE, R(r'Equipped creature|Enchanted creature|target creature you control'))),
  T=('spellslinger payoffs: copies, cascade, cast-from-exile and spell-matters engines',
     R(r'Cascade|copy (that|the next|target) (spell|instant)|Whenever you cast a noncreature|instant or sorcery|you may cast|you may play')))
PLAN_STAT['eddie_vivi'] = {'C': 'threats'}
GROUPS['eddie_vivi'] = [
  ('instants & sorceries', TY(r'Instant|Sorcery'), 'threats'),
  ('auras & equipment on Vivi', TY(r'Aura|Equipment'), 'threats'),
  ('cascade & copies', R(r'Cascade|copy that spell|copy (it|that|the next)'), 'reach'),
  ('draw engines', R(r'draw (a|two|three) card'), 'cards'),
]
RULES['eddie_bruce'] = dict(
  C=('fuels Bruce: mana for his XX draw, lands and power 4+ for the Hulk, or proliferate/counters',
     ANY(R(r'Add \{|land|untap all lands|power 4 or greater|power 7 or greater|\+1/\+1 counter|proliferate'))),
  T=('landfall and earthbend: extra land drops, fetching lands, and payoffs when lands enter',
     R(r'Landfall|earthbend|additional land|basic land card|land cards')))
GROUPS['eddie_bruce'] = [
  ('landfall', R(r'Landfall|land you control enters|additional land'), 'mana'),
  ('earthbending & Lessons', ANY(R(r'[Ee]arthbend'), TY(r'Lesson')), 'threats'),
  ('+1/+1 counters & proliferate', R(r'\+1/\+1 counter|proliferate'), 'threats'),
  ('big attackers (power 4+)', R(r'power 4 or greater|power 7 or greater|greatest power'), 'threats'),
]
RULES['eddie_cloud'] = dict(
  C=('Equipment for Cloud to carry (each equipped attacker draws), or a way to get him to 7 power for Treasures',
     ANY(TY(r'Equipment'), R(r'Equipment|equipped|power 7 or greater'))),
  T=('equip-matters engine: cheaper equips, Equipment tutors and recursion, haste and double strike for the suited-up hitter',
     R(r'Equipment|equip|double strike|attacks alone|extra combat|additional combat')))
GROUPS['eddie_cloud'] = [
  ('Equipment', TY(r'Equipment'), 'threats'),
  ('equip payoffs', R(r'Equipment (you control|spells|enters)|equipped creature|Equipped creatures'), 'threats'),
  ('power 7 matters', R(r'power 7 or greater|power 4 or greater'), 'finish'),
  ('Treasure', R(r'Treasure'), 'mana'),
  ('Final Fantasy heroes', R(r'Limit Break|Materia|SOLDIER|Summon:|Ultimate Magic'), 'threats'),
]
RULES['eddie_kasla'] = dict(
  C=('a convoke spell (Kasla scries 2 and draws on each), or a creature/token maker to tap for convoke',
     ANY(R(r'Convoke|convoke'), lambda ty, tx: 'Creature' in ty, R(r'[Cc]reate (a|two|three|four|six|X|that many)'))),
  T=('go-wide plan: token makers, anthems, team pumps and token payoffs',
     R(r'creature token|creatures you control get|attacking creatures|populate|Whenever a creature (token )?you control enters')))
GROUPS['eddie_kasla'] = [
  ('convoke', R(r'Convoke|convoke'), 'cards'),
  ('token makers', R(r'[Cc]reate .{0,30}creature token'), 'threats'),
  ('fliers', R(r'Flying|flying'), 'reach'),
  ('team pumps', R(r'creatures you control get|Attacking creatures you control'), 'finish'),
]
RULES['eddie_splinter'] = dict(
  C=('a Ninja whose hit triggers Splinter doubles, or a way to make Ninjas connect (unblockable, evasion)',
     ANY(TY(r'Ninja'), R(r'Ninja|can\'t be blocked|Ninjutsu|ninjutsu'))),
  T=('combat-damage payoffs: things that trigger when a creature hits a player',
     R(r'deals combat damage to a player|creatures you control deal combat damage|Ninja you control deals')))
GROUPS['eddie_splinter'] = [
  ('Ninjas', ANY(TY(r'Ninja'), R(r'Ninjutsu')), 'threats'),
  ('hit triggers', R(r'deals combat damage to a player'), 'cards'),
  ('unblockable', R(r'can\'t be blocked|intimidate|fear'), 'reach'),
  ('life gain', R(r'lifelink|gain .{0,10}life'), 'survival'),
]
RULES['eddie_miles'] = dict(
  C=('puts or multiplies +1/+1 counters, which Miles flips on and Ultimate Spider-Man doubles',
     R(r'\+1/\+1 counter|proliferate|counter on|counters on')),
  T=('counters-matter payoffs and Spider-Man allies: fight spells, explore, modified creatures',
     R(r'Spider|fights|explore|modified|with a counter|with a \+1/\+1 counter')))
GROUPS['eddie_miles'] = [
  ('+1/+1 counters', R(r'\+1/\+1 counter'), 'threats'),
  ('proliferate & doublers', R(r'proliferate|that many plus one|Double the number'), 'threats'),
  ('Spider-Verse', R(r'Spider'), 'threats'),
  ('fight', R(r'fights|deal damage equal to'), 'interaction'),
]
RULES['eddie_narset'] = dict(
  C=('a noncreature spell Narset can flip off the top for free, or a way to keep her attacking safely',
     ANY(NONCREATURE, R(r'hexproof|flying|can\'t be blocked'))),
  T=('extra combats and combat payoffs: untapping, double strike, prowess-style spell triggers',
     R(r'additional combat|untap all|double strike|Whenever you cast a noncreature|Whenever you attack')))
GROUPS['eddie_narset'] = [
  ('extra combats', R(r'additional combat|untap all (other )?(attacking )?creatures'), 'finish'),
  ('noncreature spell payoffs', R(r'Whenever you cast a noncreature|noncreature spell'), 'threats'),
  ('Equipment & auras', TY(r'Equipment|Aura'), 'threats'),
  ('fliers', R(r'Flying|flying'), 'reach'),
]
# Primary Directive 2.0 (Leon's rebuild) uses the same plan as the original
RULES['robots2'] = RULES['robots']
GROUPS['robots2'] = GROUPS['robots']
ADD['robots2'] = {k: set(v) for k, v in ADD.get('robots', {}).items()}
# 0.12.262 (Kyle: a dozen go-overs): every noncreature artifact feeds this deck's engine (Improvise, affinity, Kappa Cannoneer, Iron Man, Memnarch's draw), so the rocks count as deck-plan cards too
ADD['robots2'].setdefault('T', set()).update({'Sol Ring', 'Talisman of Creativity', 'Talisman of Conviction', 'Gilded Lotus', 'Thran Dynamo', 'Insight Engine', 'Reaver Titan'})
if 'robots' in PLAN_STAT: PLAN_STAT['robots2'] = PLAN_STAT['robots']
ADD['eddie_vivi'] = {'C': {'Spark Double', "Irenicus's Vile Duplication", 'Ember Island Production'}}
ADD['eddie_cloud'] = {'C': {'Professor Hojo', 'Bastion Protector'}}
# ---- 0.12.312 Kenzie's decks
RULES['kenzie_trostani'] = dict(
  C=('lifegain and bodies: every creature that enters gains Trostani\'s player life equal to its toughness',
     R(r'gain \d+ life|you gain|lifelink|create .* creature token')),
  T=('Angel and lifegain payoffs: counters, anthems and big fliers that cash in the life',
     R(r'Angel|whenever you gain life|creatures you control get \+|\+1/\+1 counter on each')))
GROUPS['kenzie_trostani'] = [
  ('Angels', R(r'Angel'), 'threats'),
  ('lifegain', R(r'gain \d+ life|you gain life|lifelink'), 'survival'),
  ('anthems', R(r'creatures you control get \+|get \+1/\+1'), 'threats'),
  ('tokens', R(r'creature token|Populate'), 'threats'),
]
RULES['kenzie_thalia'] = dict(
  C=('creatures and permanents that come back: Thalia & the Gitrog draw when lands hit the yard and punish noncreature spells',
     R(r'graveyard|return target|sacrifice a land|land card')),
  T=('counters, removal and recursion that grind the table down',
     R(r'\+1/\+1 counter|destroy|exile target|return .* from your graveyard')))
GROUPS['kenzie_thalia'] = [
  ('+1/+1 counters', R(r'\+1/\+1 counter'), 'threats'),
  ('removal', R(r'Destroy target|Exile target|destroy all'), 'interaction'),
  ('recursion', R(r'from your graveyard'), 'survival'),
]
RULES['kenzie_bumble'] = dict(
  C=('helps opponents (Ms. Bumbleflower draws and grows when you give them gifts) or casts lots of spells',
     R(r'target opponent|each opponent|opponents? (draw|create|gains?)|an opponent')),
  T=('counter growth and card flow: +1/+1 counters, flying, draw engines',
     R(r'\+1/\+1 counter|draw a card|Flying')))
GROUPS['kenzie_bumble'] = [
  ('group hug', R(r'each opponent|target opponent|any number of target opponents'), 'politics'),
  ('+1/+1 counters', R(r'\+1/\+1 counter'), 'threats'),
  ('card draw', R(r'draws? (a|two|three) cards?'), 'cards'),
]
