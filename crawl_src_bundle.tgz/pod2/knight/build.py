"""0.12.180 (Kyle): the Crimson_Knight, from CraftPix's 'Free Knight Character Sprites Pixel Art' (Knight_3, the crimson one).
License: https://craftpix.net/file-licenses/  The sheet faces right (faceR)."""
import json, numpy as np
from PIL import Image
K='/tmp/cpx/knight/Knight_3/'
def frames(f):
    im=Image.open(K+f+'.png').convert('RGBA');n=im.width//128;return [im.crop((i*128,0,(i+1)*128,128)) for i in range(n)]
rows=[('idle','Idle'),('walk','Walk'),('run','Run'),('attack1','Attack 1'),('attack2','Attack 2'),('attack3','Attack 3'),('defend','Defend'),('runatk','Run+Attack'),('jump','Jump'),('hurt','Hurt'),('death','Dead')]
fr={k:frames(f) for k,f in rows};fr['melee']=fr['attack1']
a=np.array(fr['idle'][0])[:,:,3]>0;ys,xs=np.where(a);y1=int(ys.max());AX=int(round(np.where(a[y1-5:y1+1].any(0))[0].mean()));AY=y1+1;H=int(ys.max()-ys.min()+1)
PRE=round(.4598*H/66*.94,4)   # a touch bigger than the Soldier: he's in full plate
order=[k for k,_ in rows]+['melee']
out=Image.new('RGBA',(8*128,128*len(order)),(0,0,0,0));meta={}
for r,k in enumerate(order):
    for i,f in enumerate(fr[k]): out.alpha_composite(f,(i*128,r*128))
    meta[k]=dict(fw=128,fh=128,n=len(fr[k]),ax=AX,ay=AY,x=0,y=r*128,img='knight',pre=PRE,art=1,faceR=1,pk=1.45)
out.save('/home/claude/pod2/crawl_knight.png',optimize=True)
A=json.load(open('/home/claude/pod2/crawl_atlas.json'));A['units']['knight']=meta;json.dump(A,open('/home/claude/pod2/crawl_atlas.json','w'))
print(AX,AY,H,PRE,{k:v['n'] for k,v in meta.items()})
