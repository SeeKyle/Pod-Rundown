# Needs Repair 0.12.1: 4 weak links per deck (re-picked from Kyle's notes), 4 swaps each (2 super budget, 1 medium $5-20, 1 any cost).
# EDHREC-first, checked against both faces of every card in the deck; House on Haunted Hill keeps enchantments as enchantments; Ominous Weather leans toward its winter-storm theme.
REPAIR = {
 "grim": [
  {
   "card": "Venomous Changeling",
   "read": 2,
   "why": "A 1/3 that's only here as crafting fodder; any big creature card does that job better, and Grim's Finish is its weakest stat.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Inspired Charge",
     "why": "team +2/+1 for the swing",
     "usd": 0.12
    },
    {
     "tier": "Super budget",
     "card": "Rally of Wings",
     "why": "untap fliers and +2/+2",
     "usd": 0.29
    },
    {
     "tier": "Medium",
     "card": "Agatha of the Vile Cauldron",
     "why": "a finisher; on 27% of Kenrith decks on EDHREC (+25% synergy)",
     "usd": 11.5
    },
    {
     "tier": "Any cost",
     "card": "Overwhelming Stampede",
     "why": "team pump and trample",
     "usd": 1.64
    }
   ]
  },
  {
   "card": "Tishana, Voice of Thunder",
   "read": 3,
   "why": "A 7-drop that draws per creature; Grim already refills with Zegana and the Altar, and Finish is its weakest stat.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Garruk's Uprising",
     "why": "draws on every big creature and gives the team trample",
     "usd": 0.55
    },
    {
     "tier": "Super budget",
     "card": "Bastion of Remembrance",
     "why": "drains everyone each time a fatty dies",
     "usd": 0.27
    },
    {
     "tier": "Medium",
     "card": "Moonshaker Cavalry",
     "why": "team flying and +X/+X for the big swing",
     "usd": 9.68
    },
    {
     "tier": "Any cost",
     "card": "Craterhoof Behemoth",
     "why": "one swing ends the game",
     "usd": 25.14
    }
   ]
  },
  {
   "card": "Herald of Secret Streams",
   "read": 3,
   "why": "Only counter creatures get unblockable, and Grim's fatties mostly don't carry counters.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Return of the Wildspeaker",
     "why": "draw a pile or overrun with the fatties",
     "usd": 2.61
    },
    {
     "tier": "Super budget",
     "card": "Biomancer's Familiar",
     "why": "cheaper activations for Kenrith and counters on cheats",
     "usd": 1.95
    },
    {
     "tier": "Medium",
     "card": "Triumph of the Hordes",
     "why": "infect overrun: one swing kills",
     "usd": 11.28
    },
    {
     "tier": "Any cost",
     "card": "Akroma's Will",
     "why": "team flying, double strike and protection",
     "usd": 17.09
    }
   ]
  },
  {
   "card": "Wayward Swordtooth",
   "read": 3,
   "why": "Extra land drops are nice, but the 5/5 needs ten permanents to attack or block.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Zirda, the Dawnwaker",
     "why": "ramp; on 29% of Kenrith decks on EDHREC (+27% synergy)",
     "usd": 1.31
    },
    {
     "tier": "Super budget",
     "card": "Fellwar Stone",
     "why": "ramp; on 36% of Kenrith decks on EDHREC (+5% synergy)",
     "usd": 0.88
    },
    {
     "tier": "Medium",
     "card": "Training Grounds",
     "why": "ramp; on 37% of Kenrith decks on EDHREC (+33% synergy)",
     "usd": 7.21
    },
    {
     "tier": "Any cost",
     "card": "Chromatic Lantern",
     "why": "ramp; on 48% of Kenrith decks on EDHREC",
     "usd": 4.93
    }
   ]
  }
 ],
 "thing": [
  {
   "card": "Gogo, Master of Mimicry",
   "read": 2,
   "why": "XX to copy a trigger is a lot of mana in a deck that would rather cast another noncreature spell.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Chandra, Torch of Defiance",
     "why": "removal and ramp; on 28% of The Thing decks on EDHREC (+27% synergy)",
     "usd": 2.0
    },
    {
     "tier": "Super budget",
     "card": "Inspired Charge",
     "why": "team +2/+1 for the swing",
     "usd": 0.12
    },
    {
     "tier": "Medium",
     "card": "Shared Animosity",
     "why": "attackers pump each other",
     "usd": 4.6
    },
    {
     "tier": "Any cost",
     "card": "Doubling Season",
     "why": "makes bodies; on 51% of The Thing decks on EDHREC (+46% synergy)",
     "usd": 33.17
    }
   ]
  },
  {
   "card": "Search for Glory",
   "read": 3,
   "why": "Tutors a legendary or snow card, but the deck has few legendary targets worth 3 mana.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Nature's Lore",
     "why": "ramp; on 51% of The Thing decks on EDHREC (+19% synergy)",
     "usd": 2.43
    },
    {
     "tier": "Super budget",
     "card": "Faeburrow Elder",
     "why": "ramp; on 36% of The Thing decks on EDHREC (+15% synergy)",
     "usd": 0.56
    },
    {
     "tier": "Medium",
     "card": "Birds of Paradise",
     "why": "ramp; on 46% of The Thing decks on EDHREC (+12% synergy)",
     "usd": 8.35
    },
    {
     "tier": "Any cost",
     "card": "Bloom Tender",
     "why": "ramp; on 38% of The Thing decks on EDHREC (+18% synergy)",
     "usd": 13.03
    }
   ]
  },
  {
   "card": "Bring to Light",
   "read": 3,
   "why": "A converge tutor that needs all five colors to find a 5-drop; often it finds a 3-4 drop.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Harmonize",
     "why": "draw three",
     "usd": 0.16
    },
    {
     "tier": "Super budget",
     "card": "Fact or Fiction",
     "why": "instant card advantage",
     "usd": 0.29
    },
    {
     "tier": "Medium",
     "card": "Terrasymbiosis",
     "why": "card draw; on 32% of The Thing decks on EDHREC (+31% synergy)",
     "usd": 8.7
    },
    {
     "tier": "Any cost",
     "card": "Commodore Guff",
     "why": "card draw and ramp; on 27% of The Thing decks on EDHREC (+26% synergy)",
     "usd": 28.68
    }
   ]
  },
  {
   "card": "Defense of the Heart",
   "read": 3,
   "why": "Only works if an opponent has three creatures, and it fetches creatures in a noncreature deck.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Rally of Wings",
     "why": "untap fliers and +2/+2",
     "usd": 0.29
    },
    {
     "tier": "Super budget",
     "card": "Overwhelming Stampede",
     "why": "team pump and trample",
     "usd": 1.64
    },
    {
     "tier": "Medium",
     "card": "Coat of Arms",
     "why": "creatures grow per shared type",
     "usd": 11.62
    },
    {
     "tier": "Any cost",
     "card": "Return of the Wildspeaker",
     "why": "draw or overrun",
     "usd": 2.61
    }
   ]
  }
 ],
 "mathas": [
  {
   "card": "Knight of Dusk's Shadow",
   "read": 2,
   "why": "A 2/2 menace in a deck that wants to stay alive; Survival is 1, so this slot should protect you.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Orzhov Advokist",
     "why": "opponents get counters for not attacking you (a deal that protects your life total)",
     "usd": 0.31
    },
    {
     "tier": "Super budget",
     "card": "Windborn Muse",
     "why": "taxes every attack on you",
     "usd": 0.96
    },
    {
     "tier": "Medium",
     "card": "Kambal, Consul of Allocation",
     "why": "punishes their noncreature spells and keeps your life up",
     "usd": 10.49
    },
    {
     "tier": "Any cost",
     "card": "Teferi's Protection",
     "why": "saves your board and life for a whole turn",
     "usd": 48.02
    }
   ]
  },
  {
   "card": "Tallyman of Nurgle",
   "read": 3,
   "why": "A 2/3 lifelinker that draws sometimes; the deck already draws a ton (Cards 11) and needs defense.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Archangel of Tithes",
     "why": "taxes attacks on you",
     "usd": 2.08
    },
    {
     "tier": "Super budget",
     "card": "Athreos, Shroud-Veiled",
     "why": "indestructible; makes their dead creatures come back to you",
     "usd": 1.23
    },
    {
     "tier": "Medium",
     "card": "Sphere of Safety",
     "why": "taxes every attack on you for each enchantment you have",
     "usd": 4.02
    },
    {
     "tier": "Any cost",
     "card": "Sheoldred, the Apocalypse",
     "why": "drains them on every draw and heals you on yours",
     "usd": 102.0
    }
   ]
  },
  {
   "card": "Read the Bones",
   "read": 3,
   "why": "Fine draw, but Cards is already maxed and Survival/Threats are the weak spots.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Wall of Omens",
     "why": "a blocker that replaces itself",
     "usd": 0.32
    },
    {
     "tier": "Super budget",
     "card": "Breena, the Demagogue",
     "why": "a deal: they draw for attacking others, you get counters",
     "usd": 0.78
    },
    {
     "tier": "Medium",
     "card": "Flawless Maneuver",
     "why": "free team indestructible",
     "usd": 7.71
    },
    {
     "tier": "Any cost",
     "card": "The One Ring",
     "why": "a turn of protection, then a growing card engine",
     "usd": 107.55
    }
   ]
  },
  {
   "card": "Night's Whisper",
   "read": 3,
   "why": "Same as Read the Bones: the deck's draw is covered, its life total isn't.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Disrupt Decorum",
     "why": "goads every opposing creature: they fight each other instead of you",
     "usd": 1.0
    },
    {
     "tier": "Super budget",
     "card": "Tenuous Truce",
     "why": "a peace deal that draws both of you cards",
     "usd": 0.39
    },
    {
     "tier": "Medium",
     "card": "Wedding Ring",
     "why": "cards for you whenever they draw extra",
     "usd": 11.14
    },
    {
     "tier": "Any cost",
     "card": "Karazikar, the Eye Tyrant",
     "why": "goads anyone who attacks: they hit each other",
     "usd": 11.91
    }
   ]
  }
 ],
 "marina": [
  {
   "card": "Curse of Thirst",
   "read": 3,
   "why": "One of the weaker curses: a slow ping that needs several curses on one player.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Glassworks // Shattered Yard",
     "why": "removal and a finisher; on 57% of Marina Vendrell decks on EDHREC (+56% synergy)",
     "usd": 0.1
    },
    {
     "tier": "Super budget",
     "card": "Defiled Crypt // Cadaver Lab",
     "why": "makes bodies and recursion; on 48% of Marina Vendrell decks on EDHREC (+47% synergy)",
     "usd": 0.24
    },
    {
     "tier": "Medium",
     "card": "Walk-In Closet // Forgotten Cellar",
     "why": "a key piece for this commander; on 55% of Marina Vendrell decks on EDHREC (+54% synergy)",
     "usd": 5.5
    },
    {
     "tier": "Any cost",
     "card": "Grand Entryway // Elegant Rotunda",
     "why": "makes bodies; on 46% of Marina Vendrell decks on EDHREC (+45% synergy)",
     "usd": 0.17
    }
   ]
  },
  {
   "card": "Curse of Death's Hold",
   "read": 3,
   "why": "Hits only one player's small creatures; a sweeper enchantment covers the whole table.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Restricted Office // Lecture Hall",
     "why": "a board wipe and protection; on 78% of Marina Vendrell decks on EDHREC (+76% synergy)",
     "usd": 0.31
    },
    {
     "tier": "Super budget",
     "card": "Garruk's Uprising",
     "why": "draws on big creatures and gives trample",
     "usd": 0.55
    },
    {
     "tier": "Medium",
     "card": "Mystic Remora",
     "why": "cards off their noncreature spells",
     "usd": 12.71
    },
    {
     "tier": "Any cost",
     "card": "Curiosity",
     "why": "a card every hit",
     "usd": 1.23
    }
   ]
  },
  {
   "card": "Evil Twin",
   "read": 3,
   "why": "A non-enchantment clone in an enchantment deck; any enchantment here keeps the density up.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Derelict Attic // Widow's Walk",
     "why": "card draw; on 52% of Marina Vendrell decks on EDHREC (+51% synergy)",
     "usd": 0.15
    },
    {
     "tier": "Super budget",
     "card": "Mesa Enchantress",
     "why": "card draw; on 42% of Marina Vendrell decks on EDHREC (+39% synergy)",
     "usd": 0.84
    },
    {
     "tier": "Medium",
     "card": "Skullclamp",
     "why": "creatures die into two cards",
     "usd": 5.15
    },
    {
     "tier": "Any cost",
     "card": "Charred Foyer // Warped Space",
     "why": "card draw; on 63% of Marina Vendrell decks on EDHREC (+61% synergy)",
     "usd": 3.26
    }
   ]
  },
  {
   "card": "Polluted Cistern // Dim Oubliette",
   "read": 3,
   "why": "Self-mill drains are slow, and the reanimate door is narrow in this deck.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Painter's Studio // Defaced Gallery",
     "why": "card draw and a finisher; on 41% of Marina Vendrell decks on EDHREC (+40% synergy)",
     "usd": 0.19
    },
    {
     "tier": "Super budget",
     "card": "Surgical Suite // Hospital Room",
     "why": "recursion; on 53% of Marina Vendrell decks on EDHREC (+52% synergy)",
     "usd": 0.24
    },
    {
     "tier": "Medium",
     "card": "Black Market Connections",
     "why": "cards, Treasure or tokens every turn",
     "usd": 13.08
    },
    {
     "tier": "Any cost",
     "card": "Phyrexian Arena",
     "why": "an extra card every upkeep",
     "usd": 3.06
    }
   ]
  }
 ],
 "mech": [
  {
   "card": "Armored Transport",
   "read": 2,
   "why": "A 2/1 that ignores blockers' damage; small and doesn't push the robot plan.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Etherium Sculptor",
     "why": "ramp; on 38% of Dr. Eggman decks on EDHREC (+34% synergy)",
     "usd": 0.74
    },
    {
     "tier": "Super budget",
     "card": "Talisman of Dominance",
     "why": "ramp; on 52% of Dr. Eggman decks on EDHREC",
     "usd": 1.0
    },
    {
     "tier": "Medium",
     "card": "Waste Not",
     "why": "card draw and ramp; on 61% of Dr. Eggman decks on EDHREC (+48% synergy)",
     "usd": 8.6
    },
    {
     "tier": "Any cost",
     "card": "Thought Vessel",
     "why": "ramp; on 45% of Dr. Eggman decks on EDHREC (+24% synergy)",
     "usd": 3.49
    }
   ]
  },
  {
   "card": "Night Market Guard",
   "read": 2,
   "why": "A 3/1 blocker; the deck would rather ramp into Gearhulks and the Gatebreaker turn.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Talisman of Creativity",
     "why": "ramp; on 48% of Dr. Eggman decks on EDHREC",
     "usd": 0.59
    },
    {
     "tier": "Super budget",
     "card": "Fellwar Stone",
     "why": "a 2-mana rock that fixes",
     "usd": 0.88
    },
    {
     "tier": "Medium",
     "card": "Geth's Grimoire",
     "why": "card draw; on 56% of Dr. Eggman decks on EDHREC (+51% synergy)",
     "usd": 10.32
    },
    {
     "tier": "Any cost",
     "card": "Talisman of Indulgence",
     "why": "a 2-mana B/R rock",
     "usd": 0.65
    }
   ]
  },
  {
   "card": "Watchful Automaton",
   "read": 2,
   "why": "Paying 3 for scry 1 is slow; Cards is the deck's lowest stat.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Thought Monitor",
     "why": "card draw and ramp; on 62% of Dr. Eggman decks on EDHREC (+59% synergy)",
     "usd": 0.34
    },
    {
     "tier": "Super budget",
     "card": "Oildeep Gearhulk",
     "why": "card draw and protection; on 59% of Dr. Eggman decks on EDHREC (+57% synergy)",
     "usd": 0.98
    },
    {
     "tier": "Medium",
     "card": "Skullclamp",
     "why": "creatures die into two cards",
     "usd": 5.15
    },
    {
     "tier": "Any cost",
     "card": "Padeem, Consul of Innovation",
     "why": "card draw and protection; on 57% of Dr. Eggman decks on EDHREC (+53% synergy)",
     "usd": 2.0
    }
   ]
  },
  {
   "card": "Golem Artisan",
   "read": 3,
   "why": "Small pumps for 2 each; a real draw engine helps more.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Thopter Spy Network",
     "why": "card draw and makes bodies; on 47% of Dr. Eggman decks on EDHREC (+43% synergy)",
     "usd": 0.39
    },
    {
     "tier": "Super budget",
     "card": "Great Intelligence's Plan",
     "why": "card draw; on 41% of Dr. Eggman decks on EDHREC (+38% synergy)",
     "usd": 0.53
    },
    {
     "tier": "Medium",
     "card": "Kindred Discovery",
     "why": "draw on every creature of your type",
     "usd": 6.12
    },
    {
     "tier": "Any cost",
     "card": "Thoughtcast",
     "why": "card draw; on 35% of Dr. Eggman decks on EDHREC (+32% synergy)",
     "usd": 0.5
    }
   ]
  }
 ],
 "kotis": [
  {
   "card": "Feral Invocation",
   "read": 2,
   "why": "+2/+2 aura with no evasion or double strike; Kotis needs to connect, and this doesn't help him.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Swiftfoot Boots",
     "why": "protection; on 67% of Kotis decks on EDHREC (+43% synergy)",
     "usd": 1.8
    },
    {
     "tier": "Super budget",
     "card": "Guardian Augmenter",
     "why": "protection and a finisher; on 30% of Kotis decks on EDHREC (+28% synergy)",
     "usd": 1.09
    },
    {
     "tier": "Medium",
     "card": "Slip Out the Back",
     "why": "protection; on 37% of Kotis decks on EDHREC (+33% synergy)",
     "usd": 4.97
    },
    {
     "tier": "Any cost",
     "card": "Brotherhood Regalia",
     "why": "protection; on 34% of Kotis decks on EDHREC (+32% synergy)",
     "usd": 10.94
    }
   ]
  },
  {
   "card": "Baleful Eidolon",
   "read": 3,
   "why": "Bestowed deathtouch is mostly defensive; Kotis wants evasion or double strike.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Whispersilk Cloak",
     "why": "shroud and unblockable",
     "usd": 2.15
    },
    {
     "tier": "Super budget",
     "card": "Arachnogenesis",
     "why": "fog plus Spiders",
     "usd": 1.57
    },
    {
     "tier": "Medium",
     "card": "Winged Boots",
     "why": "protection; on 28% of Kotis decks on EDHREC (+25% synergy)",
     "usd": 6.3
    },
    {
     "tier": "Any cost",
     "card": "Shadowspear",
     "why": "protection; on 28% of Kotis decks on EDHREC (+26% synergy)",
     "usd": 31.42
    }
   ]
  },
  {
   "card": "The Thirteenth Doctor",
   "read": 3,
   "why": "Counters on free casts is a small bonus; a hit-trigger draw piece does more.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Night's Whisper",
     "why": "draw two for 2",
     "usd": 0.26
    },
    {
     "tier": "Super budget",
     "card": "Sign in Blood",
     "why": "draw two for 2",
     "usd": 0.27
    },
    {
     "tier": "Medium",
     "card": "Skullclamp",
     "why": "creatures die into two cards",
     "usd": 5.15
    },
    {
     "tier": "Any cost",
     "card": "Read the Bones",
     "why": "scry 2, draw 2",
     "usd": 0.32
    }
   ]
  },
  {
   "card": "Tower Winder",
   "read": 3,
   "why": "A 2/2 that finds Command Tower; a real ramp piece gets Kotis out faster.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Farseek",
     "why": "ramp; on 58% of Kotis decks on EDHREC (+13% synergy)",
     "usd": 0.54
    },
    {
     "tier": "Super budget",
     "card": "Rampant Growth",
     "why": "ramp; on 52% of Kotis decks on EDHREC (+16% synergy)",
     "usd": 0.33
    },
    {
     "tier": "Medium",
     "card": "Birds of Paradise",
     "why": "ramp; on 42% of Kotis decks on EDHREC (+12% synergy)",
     "usd": 8.35
    },
    {
     "tier": "Any cost",
     "card": "Ancient Cellarspawn",
     "why": "ramp; on 28% of Kotis decks on EDHREC (+26% synergy)",
     "usd": 6.71
    }
   ]
  }
 ],
 "joel": [
  {
   "card": "Thallid Soothsayer",
   "read": 3,
   "why": "2 mana a card per sacrifice; the deck has cheaper free sac outlets and draw.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Zulaport Cutthroat",
     "why": "a finisher; on 68% of Ellie decks on EDHREC (+59% synergy)",
     "usd": 1.45
    },
    {
     "tier": "Super budget",
     "card": "Ophiomancer",
     "why": "makes bodies; on 64% of Ellie decks on EDHREC (+61% synergy)",
     "usd": 1.35
    },
    {
     "tier": "Medium",
     "card": "Chatterfang, Squirrel General",
     "why": "makes bodies; on 60% of Ellie decks on EDHREC (+52% synergy)",
     "usd": 9.07
    },
    {
     "tier": "Any cost",
     "card": "Liliana, Dreadhorde General",
     "why": "card draw and makes bodies; on 35% of Ellie decks on EDHREC (+32% synergy)",
     "usd": 10.14
    }
   ]
  },
  {
   "card": "Sifter of Skulls",
   "read": 3,
   "why": "Scions on nontoken deaths only, and the deck sacrifices mostly tokens.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Morbid Opportunist",
     "why": "card draw; on 56% of Ellie decks on EDHREC (+49% synergy)",
     "usd": 0.3
    },
    {
     "tier": "Super budget",
     "card": "Deadly Dispute",
     "why": "card draw and ramp; on 44% of Ellie decks on EDHREC (+31% synergy)",
     "usd": 0.33
    },
    {
     "tier": "Medium",
     "card": "Beast Whisperer",
     "why": "every creature spell draws",
     "usd": 5.41
    },
    {
     "tier": "Any cost",
     "card": "Sephiroth, Fabled SOLDIER",
     "why": "card draw; on 31% of Ellie decks on EDHREC (+29% synergy)",
     "usd": 25.07
    }
   ]
  },
  {
   "card": "Psychotrope Thallid",
   "read": 3,
   "why": "Slow Saprolings on spore counters; the deck makes tokens faster elsewhere.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Mirkwood Bats",
     "why": "a finisher and makes bodies; on 62% of Ellie decks on EDHREC (+50% synergy)",
     "usd": 1.42
    },
    {
     "tier": "Super budget",
     "card": "Beledros Witherbloom",
     "why": "makes bodies; on 44% of Ellie decks on EDHREC (+41% synergy)",
     "usd": 1.47
    },
    {
     "tier": "Medium",
     "card": "Shared Animosity",
     "why": "attackers pump each other",
     "usd": 4.6
    },
    {
     "tier": "Any cost",
     "card": "Bitterblossom",
     "why": "makes bodies; on 34% of Ellie decks on EDHREC (+31% synergy)",
     "usd": 33.06
    }
   ]
  },
  {
   "card": "Abby, Merciless Soldier",
   "read": 3,
   "why": "Gives an opponent a 4/4 to get your Fungus Zombies; a drain payoff is safer.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Jadar, Ghoulcaller of Nephalia",
     "why": "makes bodies; on 41% of Ellie decks on EDHREC (+40% synergy)",
     "usd": 1.62
    },
    {
     "tier": "Super budget",
     "card": "Overwhelming Stampede",
     "why": "team pump and trample",
     "usd": 1.64
    },
    {
     "tier": "Medium",
     "card": "Coat of Arms",
     "why": "creatures grow per shared type",
     "usd": 11.62
    },
    {
     "tier": "Any cost",
     "card": "Doubling Season",
     "why": "makes bodies; on 33% of Ellie decks on EDHREC (+27% synergy)",
     "usd": 33.17
    }
   ]
  }
 ],
 "turtle": [
  {
   "card": "Donatello, the Brains",
   "read": 3,
   "why": "A Mutagen per token batch is small next to the deck's real payoffs.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Michelangelo, Weirdness to 11",
     "why": "makes bodies; on 63% of Michelangelo decks on EDHREC (+60% synergy)",
     "usd": 2.17
    },
    {
     "tier": "Super budget",
     "card": "Splinter, the Mentor",
     "why": "makes bodies; on 52% of Michelangelo decks on EDHREC (+50% synergy)",
     "usd": 2.05
    },
    {
     "tier": "Medium",
     "card": "Shared Animosity",
     "why": "attackers pump each other",
     "usd": 4.6
    },
    {
     "tier": "Any cost",
     "card": "Doubling Season",
     "why": "makes bodies; on 40% of Michelangelo decks on EDHREC (+33% synergy)",
     "usd": 33.17
    }
   ]
  },
  {
   "card": "Arcade Cabinet",
   "read": 3,
   "why": "Counters on four creatures once, then a sacrifice to double; slow for 3 mana.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "April O'Neil, Live on the Scene",
     "why": "card draw and makes bodies; on 51% of Michelangelo decks on EDHREC (+48% synergy)",
     "usd": 0.26
    },
    {
     "tier": "Super budget",
     "card": "Lita, Little Orphan Amphibian",
     "why": "makes bodies; on 50% of Michelangelo decks on EDHREC (+47% synergy)",
     "usd": 0.27
    },
    {
     "tier": "Medium",
     "card": "Coat of Arms",
     "why": "creatures grow per shared type",
     "usd": 11.62
    },
    {
     "tier": "Any cost",
     "card": "The Ooze",
     "why": "removal and makes bodies; on 50% of Michelangelo decks on EDHREC (+48% synergy)",
     "usd": 4.14
    }
   ]
  },
  {
   "card": "Roadkill Rodney",
   "read": 3,
   "why": "A deathtouch robot that needs to hit; Cards is a low stat here.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "High Score",
     "why": "card draw; on 77% of Michelangelo decks on EDHREC (+73% synergy)",
     "usd": 0.84
    },
    {
     "tier": "Super budget",
     "card": "Heroes in a Half Shell",
     "why": "card draw; on 73% of Michelangelo decks on EDHREC (+71% synergy)",
     "usd": 1.31
    },
    {
     "tier": "Medium",
     "card": "Beast Whisperer",
     "why": "every creature spell draws",
     "usd": 5.41
    },
    {
     "tier": "Any cost",
     "card": "Mikey & Leo, Chaos & Order",
     "why": "card draw; on 57% of Michelangelo decks on EDHREC (+54% synergy)",
     "usd": 1.29
    }
   ]
  },
  {
   "card": "Kibo, Uktabi Prince",
   "read": 3,
   "why": "Gives opponents bananas too; a pure draw piece helps the deck more.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Bebop, Skull & Crossbones",
     "why": "card draw; on 46% of Michelangelo decks on EDHREC (+44% synergy)",
     "usd": 0.24
    },
    {
     "tier": "Super budget",
     "card": "Night's Whisper",
     "why": "draw two for 2",
     "usd": 0.26
    },
    {
     "tier": "Medium",
     "card": "Rishkar's Expertise",
     "why": "draw equal to your biggest creature's power",
     "usd": 4.93
    },
    {
     "tier": "Any cost",
     "card": "Sign in Blood",
     "why": "draw two for 2",
     "usd": 0.27
    }
   ]
  }
 ],
 "kykar": [
  {
   "card": "Salvager of Secrets",
   "read": 2,
   "why": "6 mana to return one spell; card draw that triggers Kykar does more.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Ponder",
     "why": "card draw; on 51% of Kykar decks on EDHREC (+34% synergy)",
     "usd": 2.0
    },
    {
     "tier": "Super budget",
     "card": "Preordain",
     "why": "card draw; on 48% of Kykar decks on EDHREC (+34% synergy)",
     "usd": 0.88
    },
    {
     "tier": "Medium",
     "card": "Skullclamp",
     "why": "card draw; on 57% of Kykar decks on EDHREC (+46% synergy)",
     "usd": 5.15
    },
    {
     "tier": "Any cost",
     "card": "Jeska's Will",
     "why": "card draw and ramp; on 26% of Kykar decks on EDHREC (+14% synergy)",
     "usd": 41.1
    }
   ]
  },
  {
   "card": "Micromancer",
   "read": 3,
   "why": "Tutors a 1-mana spell, and the deck has few that are worth fetching.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Talisman of Creativity",
     "why": "ramp; on 55% of Kykar decks on EDHREC (+14% synergy)",
     "usd": 0.59
    },
    {
     "tier": "Super budget",
     "card": "Storm-Kiln Artist",
     "why": "ramp and makes bodies; on 44% of Kykar decks on EDHREC (+30% synergy)",
     "usd": 1.94
    },
    {
     "tier": "Medium",
     "card": "Harmonic Prodigy",
     "why": "a key piece for this commander; on 40% of Kykar decks on EDHREC (+36% synergy)",
     "usd": 6.64
    },
    {
     "tier": "Any cost",
     "card": "Izzet Signet",
     "why": "ramp; on 47% of Kykar decks on EDHREC (+18% synergy)",
     "usd": 0.29
    }
   ]
  },
  {
   "card": "Thassa's Oracle",
   "read": 2,
   "why": "The alt win needs a near-empty library, which this deck almost never has.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Jeskai Ascendancy",
     "why": "card draw and a finisher; on 47% of Kykar decks on EDHREC (+33% synergy)",
     "usd": 1.81
    },
    {
     "tier": "Super budget",
     "card": "Monastery Mentor",
     "why": "makes bodies; on 30% of Kykar decks on EDHREC (+18% synergy)",
     "usd": 1.36
    },
    {
     "tier": "Medium",
     "card": "Coat of Arms",
     "why": "creatures grow per shared type",
     "usd": 11.62
    },
    {
     "tier": "Any cost",
     "card": "Impact Tremors",
     "why": "a finisher; on 48% of Kykar decks on EDHREC (+36% synergy)",
     "usd": 2.88
    }
   ]
  },
  {
   "card": "Ral, Storm Conduit",
   "read": 3,
   "why": "A planeswalker that pings 1 per spell; a real finisher closes faster.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Inspired Charge",
     "why": "team +2/+1 for the swing",
     "usd": 0.12
    },
    {
     "tier": "Super budget",
     "card": "Rally of Wings",
     "why": "untap fliers and +2/+2",
     "usd": 0.29
    },
    {
     "tier": "Medium",
     "card": "Akroma's Will",
     "why": "team flying, double strike, protection",
     "usd": 17.09
    },
    {
     "tier": "Any cost",
     "card": "Goblin Bombardment",
     "why": "fling creatures at a player",
     "usd": 3.19
    }
   ]
  }
 ],
 "weather": [
  {
   "card": "Frozen Aether",
   "read": 3,
   "why": "Opponents' things enter tapped; great flavor, small effect. A stronger storm-themed card keeps the vibe.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Search for Glory",
     "why": "a tutor; on 88% of Isu the Abominable decks on EDHREC (+87% synergy)",
     "usd": 0.71
    },
    {
     "tier": "Super budget",
     "card": "Ohran Viper",
     "why": "card draw; on 77% of Isu the Abominable decks on EDHREC (+77% synergy)",
     "usd": 1.37
    },
    {
     "tier": "Medium",
     "card": "Beast Whisperer",
     "why": "every creature spell draws",
     "usd": 5.41
    },
    {
     "tier": "Any cost",
     "card": "Winter Orb",
     "why": "the deep freeze: nobody untaps more than one land (hits you too, so drop it when you're ahead)",
     "usd": 22.69
    }
   ]
  },
  {
   "card": "Adarkar Windform",
   "read": 3,
   "why": "A 3/3 flier that removes flying; a bigger icy flier fits the storm better.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Overwhelming Stampede",
     "why": "team pump and trample",
     "usd": 1.64
    },
    {
     "tier": "Super budget",
     "card": "Glittering Frost",
     "why": "ramp; on 72% of Isu the Abominable decks on EDHREC (+71% synergy)",
     "usd": 0.21
    },
    {
     "tier": "Medium",
     "card": "Triumph of the Hordes",
     "why": "infect overrun",
     "usd": 11.28
    },
    {
     "tier": "Any cost",
     "card": "Sword of Fire and Ice",
     "why": "protection, damage and a card every hit",
     "usd": 16.57
    }
   ]
  },
  {
   "card": "Urban Evolution",
   "read": 3,
   "why": "The least on-theme card in the storm: draw 3 and a land, at sorcery speed.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Arcum's Astrolabe",
     "why": "card draw and ramp; on 68% of Isu the Abominable decks on EDHREC (+68% synergy)",
     "usd": 0.26
    },
    {
     "tier": "Super budget",
     "card": "Pilfering Hawk",
     "why": "card draw; on 68% of Isu the Abominable decks on EDHREC (+67% synergy)",
     "usd": 0.21
    },
    {
     "tier": "Medium",
     "card": "Stormchaser's Talent",
     "why": "an Otter that levels up to return your spells and make more Otters",
     "usd": 6.35
    },
    {
     "tier": "Any cost",
     "card": "Rhystic Study",
     "why": "a card every time an opponent doesn't pay 1",
     "usd": 67.41
    }
   ]
  }
 ],
 "blood": [
  {
   "card": "Campaign of Vengeance",
   "read": 3,
   "why": "Drains per attacker, but Cards is the deck's lowest stat: draw that pulls more Bats helps more.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Moonstone Eulogist",
     "why": "card draw and makes bodies; on 50% of Zoraline decks on EDHREC (+49% synergy)",
     "usd": 0.33
    },
    {
     "tier": "Super budget",
     "card": "Sinister Monolith",
     "why": "card draw and a finisher; on 35% of Zoraline decks on EDHREC (+33% synergy)",
     "usd": 0.22
    },
    {
     "tier": "Medium",
     "card": "Black Market Connections",
     "why": "cards, Treasure or tokens every turn",
     "usd": 13.08
    },
    {
     "tier": "Any cost",
     "card": "Stirge",
     "why": "card draw; on 34% of Zoraline decks on EDHREC (+33% synergy)",
     "usd": 0.29
    }
   ]
  },
  {
   "card": "Desecrated Tomb",
   "read": 2,
   "why": "Only makes Bats when creatures leave your graveyard, which this deck rarely does.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Night's Whisper",
     "why": "draw two for 2",
     "usd": 0.26
    },
    {
     "tier": "Super budget",
     "card": "Read the Bones",
     "why": "scry 2, draw 2",
     "usd": 0.32
    },
    {
     "tier": "Medium",
     "card": "Batwing Brume",
     "why": "a key piece for this commander; on 39% of Zoraline decks on EDHREC (+35% synergy)",
     "usd": 7.73
    },
    {
     "tier": "Any cost",
     "card": "Phyrexian Arena",
     "why": "card draw; on 42% of Zoraline decks on EDHREC (+15% synergy)",
     "usd": 3.06
    }
   ]
  },
  {
   "card": "Gray Merchant of Asphodel",
   "read": 3,
   "why": "A good drain, but the deck is low on cards and mana; a Bat draw engine helps more.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Painful Truths",
     "why": "draw up to three",
     "usd": 0.27
    },
    {
     "tier": "Super budget",
     "card": "Mask of Memory",
     "why": "draws two every hit",
     "usd": 0.39
    },
    {
     "tier": "Medium",
     "card": "Toxic Deluge",
     "why": "a cheap wipe you control",
     "usd": 5.7
    },
    {
     "tier": "Any cost",
     "card": "Rogue's Gloves",
     "why": "a card every hit",
     "usd": 0.47
    }
   ]
  },
  {
   "card": "Moonrise Cleric",
   "read": 3,
   "why": "A 2/3 flier that gains 1; a Bat or Cleric that draws keeps the tribe flowing.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Mind Stone",
     "why": "a rock that cashes in for a card",
     "usd": 0.2
    },
    {
     "tier": "Super budget",
     "card": "Sanguine Evangelist",
     "why": "makes bodies; on 47% of Zoraline decks on EDHREC (+45% synergy)",
     "usd": 0.33
    },
    {
     "tier": "Medium",
     "card": "Farewell",
     "why": "pick what gets exiled; keep your side",
     "usd": 5.78
    },
    {
     "tier": "Any cost",
     "card": "The One Ring",
     "why": "a turn of protection and cards",
     "usd": 107.55
    }
   ]
  }
 ],
 "dragons": [
  {
   "card": "Goblin Anarchomancer",
   "read": 3,
   "why": "A cost reducer for red and green; with Cards at 3, the deck needs more draw to keep Dragons in hand.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Garruk's Uprising",
     "why": "card draw; on 72% of Miirym decks on EDHREC (+44% synergy)",
     "usd": 0.55
    },
    {
     "tier": "Super budget",
     "card": "Harmonize",
     "why": "draw three",
     "usd": 0.16
    },
    {
     "tier": "Medium",
     "card": "Beast Whisperer",
     "why": "every creature spell draws",
     "usd": 5.41
    },
    {
     "tier": "Any cost",
     "card": "Ancient Silver Dragon",
     "why": "card draw; on 38% of Miirym decks on EDHREC (+32% synergy)",
     "usd": 43.82
    }
   ]
  },
  {
   "card": "Karametra's Acolyte",
   "read": 3,
   "why": "Devotion mana is often only 2-3 here; draw keeps a full grip for when Miirym hits.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Fact or Fiction",
     "why": "instant card advantage",
     "usd": 0.29
    },
    {
     "tier": "Super budget",
     "card": "Mulldrifter",
     "why": "a flier that draws two",
     "usd": 0.38
    },
    {
     "tier": "Medium",
     "card": "Rishkar's Expertise",
     "why": "draw equal to your biggest creature's power",
     "usd": 4.93
    },
    {
     "tier": "Any cost",
     "card": "Thought Monitor",
     "why": "an artifact that draws two",
     "usd": 0.34
    }
   ]
  },
  {
   "card": "Blur",
   "read": 3,
   "why": "A flicker-draw trick; a real draw engine keeps you casting Dragons.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Tireless Tracker",
     "why": "Clues on every land drop",
     "usd": 0.21
    },
    {
     "tier": "Super budget",
     "card": "Mask of Memory",
     "why": "draws two every hit",
     "usd": 0.39
    },
    {
     "tier": "Medium",
     "card": "Kindred Discovery",
     "why": "draw on every creature of your type",
     "usd": 6.12
    },
    {
     "tier": "Any cost",
     "card": "Rogue's Gloves",
     "why": "a card every hit",
     "usd": 0.47
    }
   ]
  },
  {
   "card": "Master Biomancer",
   "read": 3,
   "why": "Counters are nice, but the deck's weak spot is running out of Dragons to cast.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Commander's Sphere",
     "why": "a rock that cashes in for a card",
     "usd": 0.78
    },
    {
     "tier": "Super budget",
     "card": "Mind Stone",
     "why": "a rock that cashes in for a card",
     "usd": 0.2
    },
    {
     "tier": "Medium",
     "card": "Mystic Remora",
     "why": "cards off their noncreature spells",
     "usd": 12.71
    },
    {
     "tier": "Any cost",
     "card": "Curiosity",
     "why": "a card every hit",
     "usd": 1.23
    }
   ]
  }
 ],
 "korvold": [
  {
   "card": "Rhythm of the Wild",
   "read": 3,
   "why": "Riot and uncounterable creatures don't do much for a deck that eats its own board.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Professional Face-Breaker",
     "why": "card draw and ramp; on 35% of Korvold decks on EDHREC (+27% synergy)",
     "usd": 1.0
    },
    {
     "tier": "Super budget",
     "card": "Sign in Blood",
     "why": "draw two for 2",
     "usd": 0.27
    },
    {
     "tier": "Medium",
     "card": "Black Market Connections",
     "why": "card draw and ramp; on 26% of Korvold decks on EDHREC (+18% synergy)",
     "usd": 13.08
    },
    {
     "tier": "Any cost",
     "card": "Read the Bones",
     "why": "scry 2, draw 2",
     "usd": 0.32
    }
   ]
  },
  {
   "card": "Dig Up",
   "read": 3,
   "why": "Basic to hand, or a 4-mana-plus-cleave tutor; a sacrifice-draw piece fits better.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Painful Truths",
     "why": "draw up to three",
     "usd": 0.27
    },
    {
     "tier": "Super budget",
     "card": "Harmonize",
     "why": "draw three",
     "usd": 0.16
    },
    {
     "tier": "Medium",
     "card": "Beast Whisperer",
     "why": "every creature spell draws",
     "usd": 5.41
    },
    {
     "tier": "Any cost",
     "card": "Tireless Tracker",
     "why": "Clues on every land drop",
     "usd": 0.21
    }
   ]
  },
  {
   "card": "Vindictive Vampire",
   "read": 3,
   "why": "Pings 1 per death; a bigger drain or a free sac outlet does more with Korvold.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Mirkwood Bats",
     "why": "a finisher and makes bodies; on 40% of Korvold decks on EDHREC (+29% synergy)",
     "usd": 1.42
    },
    {
     "tier": "Super budget",
     "card": "Overwhelming Stampede",
     "why": "team pump and trample",
     "usd": 1.64
    },
    {
     "tier": "Medium",
     "card": "Chatterfang, Squirrel General",
     "why": "makes bodies; on 50% of Korvold decks on EDHREC (+41% synergy)",
     "usd": 9.07
    },
    {
     "tier": "Any cost",
     "card": "Blood Artist",
     "why": "a finisher; on 29% of Korvold decks on EDHREC (+19% synergy)",
     "usd": 2.77
    }
   ]
  },
  {
   "card": "Gluttonous Troll",
   "read": 3,
   "why": "Food is fodder, but a 3/3 that needs Food sacrificed is slow next to free outlets.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Garruk's Uprising",
     "why": "draws on big creatures and gives trample",
     "usd": 0.55
    },
    {
     "tier": "Super budget",
     "card": "Mask of Memory",
     "why": "draws two every hit",
     "usd": 0.39
    },
    {
     "tier": "Medium",
     "card": "Rishkar's Expertise",
     "why": "draw equal to your biggest creature's power",
     "usd": 4.93
    },
    {
     "tier": "Any cost",
     "card": "Rogue's Gloves",
     "why": "a card every hit",
     "usd": 0.47
    }
   ]
  }
 ],
 "robots": [
  {
   "card": "Jhoira's Familiar",
   "read": 3,
   "why": "A 2/2 flier that saves 1 on historic spells; real ramp does more.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Enthusiastic Mechanaut",
     "why": "ramp; on 60% of Optimus Prime decks on EDHREC (+47% synergy)",
     "usd": 0.27
    },
    {
     "tier": "Super budget",
     "card": "Azorius Signet",
     "why": "ramp; on 37% of Optimus Prime decks on EDHREC (+8% synergy)",
     "usd": 0.32
    },
    {
     "tier": "Medium",
     "card": "Herald of Secret Streams",
     "why": "a key piece for this commander; on 42% of Optimus Prime decks on EDHREC (+38% synergy)",
     "usd": 9.6
    },
    {
     "tier": "Any cost",
     "card": "Arcane Signet",
     "why": "any commander color for 2",
     "usd": 0.34
    }
   ]
  },
  {
   "card": "Planetary Annihilation",
   "read": 3,
   "why": "Your land base is safe (the deck runs few lands), but 6 damage kills your mana dorks and Robots too.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Dispatch",
     "why": "removal; on 53% of Optimus Prime decks on EDHREC (+38% synergy)",
     "usd": 1.56
    },
    {
     "tier": "Super budget",
     "card": "Organic Extinction",
     "why": "a board wipe; on 42% of Optimus Prime decks on EDHREC (+32% synergy)",
     "usd": 0.3
    },
    {
     "tier": "Medium",
     "card": "Damning Verdict",
     "why": "a board wipe; on 30% of Optimus Prime decks on EDHREC (+27% synergy)",
     "usd": 10.61
    },
    {
     "tier": "Any cost",
     "card": "Alibou, Ancient Witness",
     "why": "removal; on 41% of Optimus Prime decks on EDHREC (+33% synergy)",
     "usd": 0.3
    }
   ]
  },
  {
   "card": "Saheeli's Artistry",
   "read": 3,
   "why": "Two copies for 6 at sorcery speed; the deck has cheaper copy effects already.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Prowl, Stoic Strategist",
     "why": "card draw; on 56% of Optimus Prime decks on EDHREC (+55% synergy)",
     "usd": 1.26
    },
    {
     "tier": "Super budget",
     "card": "Padeem, Consul of Innovation",
     "why": "card draw and protection; on 41% of Optimus Prime decks on EDHREC (+37% synergy)",
     "usd": 2.0
    },
    {
     "tier": "Medium",
     "card": "Kindred Discovery",
     "why": "draw on every creature of your type",
     "usd": 6.12
    },
    {
     "tier": "Any cost",
     "card": "Losheel, Clockwork Scholar",
     "why": "card draw; on 43% of Optimus Prime decks on EDHREC (+41% synergy)",
     "usd": 2.57
    }
   ]
  },
  {
   "card": "Emry, Lurker of the Loch",
   "read": 3,
   "why": "Recasts small artifacts from the graveyard; a draw engine helps the counter/copy plan more.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Thopter Spy Network",
     "why": "card draw and makes bodies; on 39% of Optimus Prime decks on EDHREC (+35% synergy)",
     "usd": 0.39
    },
    {
     "tier": "Super budget",
     "card": "Tezzeret's Gambit",
     "why": "card draw; on 38% of Optimus Prime decks on EDHREC (+26% synergy)",
     "usd": 0.27
    },
    {
     "tier": "Medium",
     "card": "Mystic Remora",
     "why": "cards off their noncreature spells",
     "usd": 12.71
    },
    {
     "tier": "Any cost",
     "card": "Goldbug, Humanity's Ally",
     "why": "card draw; on 31% of Optimus Prime decks on EDHREC (+30% synergy)",
     "usd": 1.33
    }
   ]
  }
 ],
 "felothar": [
  {
   "card": "Read the Bones",
   "read": 3,
   "why": "Fine draw, but Finish is Felothar's weakest stat (1); a wall payoff closes games.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Behind the Scenes",
     "why": "a finisher; on 83% of Felothar the Steadfast decks on EDHREC (+72% synergy)",
     "usd": 0.33
    },
    {
     "tier": "Super budget",
     "card": "Tower Defense",
     "why": "a finisher; on 79% of Felothar the Steadfast decks on EDHREC (+66% synergy)",
     "usd": 0.29
    },
    {
     "tier": "Medium",
     "card": "Akroma's Will",
     "why": "team flying, double strike, protection",
     "usd": 17.09
    },
    {
     "tier": "Any cost",
     "card": "Assault Formation",
     "why": "a finisher; on 75% of Felothar the Steadfast decks on EDHREC (+61% synergy)",
     "usd": 0.4
    }
   ]
  },
  {
   "card": "Clifftop Lookout",
   "read": 3,
   "why": "A 1/2 that ramps once; the deck needs ways to turn walls into damage.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Inspired Charge",
     "why": "team +2/+1 for the swing",
     "usd": 0.12
    },
    {
     "tier": "Super budget",
     "card": "Rally of Wings",
     "why": "untap fliers and +2/+2",
     "usd": 0.29
    },
    {
     "tier": "Medium",
     "card": "Triumph of the Hordes",
     "why": "infect overrun",
     "usd": 11.28
    },
    {
     "tier": "Any cost",
     "card": "Return of the Wildspeaker",
     "why": "draw or overrun",
     "usd": 2.61
    }
   ]
  },
  {
   "card": "Viridian Emissary",
   "read": 3,
   "why": "Dies into a basic; a better ramp piece doesn't need to die.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Wall of Roots",
     "why": "ramp; on 59% of Felothar the Steadfast decks on EDHREC (+50% synergy)",
     "usd": 0.33
    },
    {
     "tier": "Super budget",
     "card": "Arboreal Grazer",
     "why": "ramp; on 52% of Felothar the Steadfast decks on EDHREC (+44% synergy)",
     "usd": 0.28
    },
    {
     "tier": "Medium",
     "card": "Three Visits",
     "why": "an untapped dual at instant speed",
     "usd": 5.29
    },
    {
     "tier": "Any cost",
     "card": "Arbor Adherent",
     "why": "ramp; on 86% of Felothar the Steadfast decks on EDHREC (+70% synergy)",
     "usd": 3.25
    }
   ]
  },
  {
   "card": "Naga Vitalist",
   "read": 3,
   "why": "A 1/2 dork; a sturdier ramp wall fits the deck.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Arcane Signet",
     "why": "any commander color for 2",
     "usd": 0.34
    },
    {
     "tier": "Super budget",
     "card": "Fellwar Stone",
     "why": "a 2-mana rock that fixes",
     "usd": 0.88
    },
    {
     "tier": "Medium",
     "card": "Birds of Paradise",
     "why": "any color on turn one",
     "usd": 8.35
    },
    {
     "tier": "Any cost",
     "card": "Orzhov Signet",
     "why": "a 2-mana W/B rock",
     "usd": 0.37
    }
   ]
  }
 ],
 "thranduil": [
  {
   "card": "Doppelgang",
   "read": 2,
   "why": "X copies for X+X+X mana; at 8 mana you get two copies.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Elrond, Moon-Reader",
     "why": "card draw; on 58% of Thranduil decks on EDHREC (+51% synergy)",
     "usd": 1.31
    },
    {
     "tier": "Super budget",
     "card": "Sign in Blood",
     "why": "draw two for 2",
     "usd": 0.27
    },
    {
     "tier": "Medium",
     "card": "Selvala, Heart of the Wilds",
     "why": "card draw; on 43% of Thranduil decks on EDHREC (+38% synergy)",
     "usd": 5.71
    },
    {
     "tier": "Any cost",
     "card": "Leaf-Crowned Visionary",
     "why": "card draw; on 35% of Thranduil decks on EDHREC (+32% synergy)",
     "usd": 5.13
    }
   ]
  },
  {
   "card": "Through the Forest Gate",
   "read": 3,
   "why": "Lands and life, but the Elves already make plenty of mana; draw helps more.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Read the Bones",
     "why": "scry 2, draw 2",
     "usd": 0.32
    },
    {
     "tier": "Super budget",
     "card": "Painful Truths",
     "why": "draw up to three",
     "usd": 0.27
    },
    {
     "tier": "Medium",
     "card": "Staff of Domination",
     "why": "card draw; on 34% of Thranduil decks on EDHREC (+32% synergy)",
     "usd": 11.6
    },
    {
     "tier": "Any cost",
     "card": "Harmonize",
     "why": "draw three",
     "usd": 0.16
    }
   ]
  },
  {
   "card": "Urban Evolution",
   "read": 3,
   "why": "Draw 3 and a land for 5 at sorcery speed; a legendary Elf or an engine does more with Thranduil.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Fact or Fiction",
     "why": "instant card advantage",
     "usd": 0.29
    },
    {
     "tier": "Super budget",
     "card": "Mulldrifter",
     "why": "a flier that draws two",
     "usd": 0.38
    },
    {
     "tier": "Medium",
     "card": "Rishkar's Expertise",
     "why": "draw equal to your biggest creature's power",
     "usd": 4.93
    },
    {
     "tier": "Any cost",
     "card": "Thought Monitor",
     "why": "an artifact that draws two",
     "usd": 0.34
    }
   ]
  },
  {
   "card": "Spark Double",
   "read": 3,
   "why": "Spark Double's copy isn't legendary, so copying an Elf won't trigger Thranduil's draw.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Imperious Perfect",
     "why": "makes bodies; on 53% of Thranduil decks on EDHREC (+48% synergy)",
     "usd": 0.69
    },
    {
     "tier": "Super budget",
     "card": "Bastion of Remembrance",
     "why": "drains on every death",
     "usd": 0.27
    },
    {
     "tier": "Medium",
     "card": "Deathrite Shaman",
     "why": "removal and ramp; on 37% of Thranduil decks on EDHREC (+20% synergy)",
     "usd": 4.77
    },
    {
     "tier": "Any cost",
     "card": "Ezuri, Renegade Leader",
     "why": "a finisher; on 54% of Thranduil decks on EDHREC (+52% synergy)",
     "usd": 22.37
    }
   ]
  }
 ],
 "vile": [
  {
   "card": "Hearthborn Battler",
   "read": 2,
   "why": "2 damage on a second spell each turn; the deck wants bigger burn payoffs.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Black Waltz No. 3",
     "why": "a finisher; on 17% of Ishai decks on EDHREC (+17% synergy)",
     "usd": 0.31
    },
    {
     "tier": "Super budget",
     "card": "Bastion of Remembrance",
     "why": "drains on every death",
     "usd": 0.27
    },
    {
     "tier": "Medium",
     "card": "Inkshield",
     "why": "makes bodies; on 21% of Ishai decks on EDHREC (+19% synergy)",
     "usd": 5.09
    },
    {
     "tier": "Any cost",
     "card": "Y'shtola, Night's Blessed",
     "why": "card draw and a finisher; on 15% of Ishai decks on EDHREC (+14% synergy)",
     "usd": 4.96
    }
   ]
  },
  {
   "card": "World Map",
   "read": 2,
   "why": "Sac to find a land is slow; a real rock helps more.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Talisman of Conviction",
     "why": "ramp; on 28% of Ishai decks on EDHREC (+11% synergy)",
     "usd": 0.32
    },
    {
     "tier": "Super budget",
     "card": "Talisman of Creativity",
     "why": "ramp; on 31% of Ishai decks on EDHREC",
     "usd": 0.59
    },
    {
     "tier": "Medium",
     "card": "Lotho, Corrupt Shirriff",
     "why": "ramp and makes bodies; on 24% of Ishai decks on EDHREC",
     "usd": 8.02
    },
    {
     "tier": "Any cost",
     "card": "Smothering Tithe",
     "why": "card draw and ramp; on 31% of Ishai decks on EDHREC",
     "usd": 59.1
    }
   ]
  },
  {
   "card": "Burnished Hart",
   "read": 3,
   "why": "3 mana plus 3 more for two basics; a cheaper rock ramps sooner.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Talisman of Indulgence",
     "why": "ramp; on 27% of Ishai decks on EDHREC",
     "usd": 0.65
    },
    {
     "tier": "Super budget",
     "card": "Mind Stone",
     "why": "a rock that cashes in for a card",
     "usd": 0.2
    },
    {
     "tier": "Medium",
     "card": "Kindred Discovery",
     "why": "draw on every creature of your type",
     "usd": 6.12
    },
    {
     "tier": "Any cost",
     "card": "An Offer You Can't Refuse",
     "why": "a counterspell and ramp; on 29% of Ishai decks on EDHREC",
     "usd": 3.19
    }
   ]
  },
  {
   "card": "Unburial Rites",
   "read": 3,
   "why": "Reanimation is off-plan for wheels and burn.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Curiosity",
     "why": "card draw; on 21% of Ishai decks on EDHREC (+20% synergy)",
     "usd": 1.23
    },
    {
     "tier": "Super budget",
     "card": "Dig Through Time",
     "why": "card draw; on 16% of Ishai decks on EDHREC (+15% synergy)",
     "usd": 0.25
    },
    {
     "tier": "Medium",
     "card": "Talion, the Kindly Lord",
     "why": "card draw; on 16% of Ishai decks on EDHREC (+14% synergy)",
     "usd": 7.03
    },
    {
     "tier": "Any cost",
     "card": "Esper Sentinel",
     "why": "card draw; on 29% of Ishai decks on EDHREC",
     "usd": 53.56
    }
   ]
  }
 ],
 "depala": [
  {
   "card": "Dwarven Mauler",
   "read": 3,
   "why": "Cheaper equips on one Dwarf; Mana is the deck's weak spot (4).",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Hoard Hauler",
     "why": "ramp and makes bodies; on 57% of Depala decks on EDHREC (+56% synergy)",
     "usd": 0.4
    },
    {
     "tier": "Super budget",
     "card": "Glóin, Dwarf Emissary",
     "why": "ramp and makes bodies; on 58% of Depala decks on EDHREC (+53% synergy)",
     "usd": 2.4
    },
    {
     "tier": "Medium",
     "card": "Farewell",
     "why": "pick what gets exiled; keep your side",
     "usd": 5.78
    },
    {
     "tier": "Any cost",
     "card": "Aerial Surveyor",
     "why": "ramp; on 52% of Depala decks on EDHREC (+51% synergy)",
     "usd": 1.37
    }
   ]
  },
  {
   "card": "Toolcraft Exemplar",
   "read": 3,
   "why": "A 3/2 first striker with artifacts; Cards is a low stat (3).",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Sram, Senior Edificer",
     "why": "card draw; on 89% of Depala decks on EDHREC (+71% synergy)",
     "usd": 1.74
    },
    {
     "tier": "Super budget",
     "card": "Smuggler's Copter",
     "why": "card draw; on 68% of Depala decks on EDHREC (+67% synergy)",
     "usd": 1.38
    },
    {
     "tier": "Medium",
     "card": "Delayed Blast Fireball",
     "why": "one-sided wipe",
     "usd": 15.92
    },
    {
     "tier": "Any cost",
     "card": "Weatherlight",
     "why": "card draw; on 67% of Depala decks on EDHREC (+66% synergy)",
     "usd": 1.41
    }
   ]
  },
  {
   "card": "Thorin Oakenshield",
   "read": 3,
   "why": "Ward 1 with a story; draw helps more.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Mighty Servant of Leuk-o",
     "why": "card draw and protection; on 55% of Depala decks on EDHREC (+54% synergy)",
     "usd": 0.36
    },
    {
     "tier": "Super budget",
     "card": "Reckoner Bankbuster",
     "why": "card draw and ramp; on 44% of Depala decks on EDHREC (+43% synergy)",
     "usd": 0.79
    },
    {
     "tier": "Medium",
     "card": "Akroma's Will",
     "why": "team flying, double strike, protection",
     "usd": 17.09
    },
    {
     "tier": "Any cost",
     "card": "Hangar Scrounger",
     "why": "card draw; on 38% of Depala decks on EDHREC (+37% synergy)",
     "usd": 0.21
    }
   ]
  },
  {
   "card": "Air Response Unit",
   "read": 3,
   "why": "A 3/3 flying vehicle; ramp helps the deck more.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Foundry Inspector",
     "why": "ramp; on 48% of Depala decks on EDHREC (+39% synergy)",
     "usd": 0.39
    },
    {
     "tier": "Super budget",
     "card": "Boros Signet",
     "why": "ramp; on 53% of Depala decks on EDHREC (+6% synergy)",
     "usd": 0.69
    },
    {
     "tier": "Medium",
     "card": "Moonshaker Cavalry",
     "why": "team flying and +X/+X",
     "usd": 9.68
    },
    {
     "tier": "Any cost",
     "card": "Stoic Farmer",
     "why": "ramp; on 36% of Depala decks on EDHREC (+36% synergy)",
     "usd": 0.36
    }
   ]
  }
 ],
 "mothman": [
  {
   "card": "Krosan Restorer",
   "read": 3,
   "why": "Untaps lands, with threshold for three; a plain rock or dork is steadier.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Farseek",
     "why": "ramp; on 71% of The Wise Mothman decks on EDHREC (+25% synergy)",
     "usd": 0.54
    },
    {
     "tier": "Super budget",
     "card": "Rampant Growth",
     "why": "ramp; on 59% of The Wise Mothman decks on EDHREC (+23% synergy)",
     "usd": 0.33
    },
    {
     "tier": "Medium",
     "card": "Three Visits",
     "why": "an untapped dual at instant speed",
     "usd": 5.29
    },
    {
     "tier": "Any cost",
     "card": "Talisman of Curiosity",
     "why": "ramp; on 49% of The Wise Mothman decks on EDHREC (+34% synergy)",
     "usd": 0.45
    }
   ]
  },
  {
   "card": "Embalmer's Tools",
   "read": 3,
   "why": "Self-mill per Zombie is slow; Interaction is low (3), so an answer helps more.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Nuclear Fallout",
     "why": "a board wipe; on 81% of The Wise Mothman decks on EDHREC (+72% synergy)",
     "usd": 2.44
    },
    {
     "tier": "Super budget",
     "card": "Putrefy",
     "why": "removal; on 51% of The Wise Mothman decks on EDHREC (+29% synergy)",
     "usd": 0.3
    },
    {
     "tier": "Medium",
     "card": "Atomize",
     "why": "removal; on 68% of The Wise Mothman decks on EDHREC (+60% synergy)",
     "usd": 5.76
    },
    {
     "tier": "Any cost",
     "card": "Beast Within",
     "why": "instant answer to anything",
     "usd": 0.67
    }
   ]
  },
  {
   "card": "Llanowar Dead",
   "read": 3,
   "why": "A Zombie mana dork; fine, but a better rock ramps as well and survives wipes.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Talisman of Resilience",
     "why": "ramp; on 48% of The Wise Mothman decks on EDHREC (+34% synergy)",
     "usd": 0.46
    },
    {
     "tier": "Super budget",
     "card": "Talisman of Dominance",
     "why": "ramp; on 46% of The Wise Mothman decks on EDHREC (+32% synergy)",
     "usd": 1.0
    },
    {
     "tier": "Medium",
     "card": "Birds of Paradise",
     "why": "any color on turn one",
     "usd": 8.35
    },
    {
     "tier": "Any cost",
     "card": "The Water Crystal",
     "why": "ramp; on 41% of The Wise Mothman decks on EDHREC (+35% synergy)",
     "usd": 4.07
    }
   ]
  },
  {
   "card": "Vengeful Dead",
   "read": 3,
   "why": "Drains 1 per Zombie death, but the deck has few sac outlets to make Zombies die on purpose.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Syr Konrad, the Grim",
     "why": "a finisher; on 51% of The Wise Mothman decks on EDHREC (+35% synergy)",
     "usd": 1.55
    },
    {
     "tier": "Super budget",
     "card": "Bastion of Remembrance",
     "why": "drains on every death",
     "usd": 0.27
    },
    {
     "tier": "Medium",
     "card": "Bloodchief Ascension",
     "why": "a finisher; on 42% of The Wise Mothman decks on EDHREC (+37% synergy)",
     "usd": 21.54
    },
    {
     "tier": "Any cost",
     "card": "Triumph of the Hordes",
     "why": "infect overrun",
     "usd": 11.28
    }
   ]
  }
 ],
 "casino": [
  {
   "card": "Alibou, Ancient Witness",
   "read": 3,
   "why": "Haste and pings for artifact attackers; Cards is low (3).",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Chaos Channeler",
     "why": "card draw; on 58% of Mr. House decks on EDHREC (+55% synergy)",
     "usd": 0.13
    },
    {
     "tier": "Super budget",
     "card": "Deadly Dispute",
     "why": "card draw and ramp; on 54% of Mr. House decks on EDHREC (+31% synergy)",
     "usd": 0.33
    },
    {
     "tier": "Medium",
     "card": "Black Market Connections",
     "why": "cards, Treasure or tokens every turn",
     "usd": 13.08
    },
    {
     "tier": "Any cost",
     "card": "The Deck of Many Things",
     "why": "card draw and recursion; on 76% of Mr. House decks on EDHREC (+72% synergy)",
     "usd": 4.02
    }
   ]
  },
  {
   "card": "Read the Bones",
   "read": 3,
   "why": "Fine draw; a dice or Treasure draw engine fits Mr. House better.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Painful Truths",
     "why": "draw up to three",
     "usd": 0.27
    },
    {
     "tier": "Super budget",
     "card": "Mask of Memory",
     "why": "draws two every hit",
     "usd": 0.39
    },
    {
     "tier": "Medium",
     "card": "Comet, Stellar Pup",
     "why": "makes bodies and recursion; on 70% of Mr. House decks on EDHREC (+65% synergy)",
     "usd": 8.18
    },
    {
     "tier": "Any cost",
     "card": "Rogue's Gloves",
     "why": "a card every hit",
     "usd": 0.47
    }
   ]
  },
  {
   "card": "Inspiring Leader",
   "read": 3,
   "why": "A background that only pumps tokens your commander gives; small here.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Mirkwood Bats",
     "why": "a finisher and makes bodies; on 68% of Mr. House decks on EDHREC (+52% synergy)",
     "usd": 1.42
    },
    {
     "tier": "Super budget",
     "card": "Brazen Dwarf",
     "why": "a finisher; on 62% of Mr. House decks on EDHREC (+59% synergy)",
     "usd": 0.23
    },
    {
     "tier": "Medium",
     "card": "Clown Car",
     "why": "makes bodies; on 55% of Mr. House decks on EDHREC (+52% synergy)",
     "usd": 11.34
    },
    {
     "tier": "Any cost",
     "card": "Luck Bobblehead",
     "why": "ramp and a finisher; on 50% of Mr. House decks on EDHREC (+46% synergy)",
     "usd": 4.58
    }
   ]
  },
  {
   "card": "Lobelia Sackville-Baggins",
   "read": 3,
   "why": "Needs opposing creatures dying to make Treasure; a steady Treasure maker helps more.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Jan Jansen, Chaos Crafter",
     "why": "ramp and makes bodies; on 70% of Mr. House decks on EDHREC (+63% synergy)",
     "usd": 0.47
    },
    {
     "tier": "Super budget",
     "card": "Crime Novelist",
     "why": "ramp; on 41% of Mr. House decks on EDHREC (+37% synergy)",
     "usd": 2.15
    },
    {
     "tier": "Medium",
     "card": "Sword of Hours",
     "why": "a key piece for this commander; on 40% of Mr. House decks on EDHREC (+38% synergy)",
     "usd": 4.63
    },
    {
     "tier": "Any cost",
     "card": "Fellwar Stone",
     "why": "a 2-mana rock that fixes",
     "usd": 0.88
    }
   ]
  }
 ],
 "scare": [
  {
   "card": "Doppelgang",
   "read": 2,
   "why": "X copies for X+X+X mana; too slow for a mutate deck.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Parcelbeast",
     "why": "card draw; on 64% of Illuna decks on EDHREC (+62% synergy)",
     "usd": 0.18
    },
    {
     "tier": "Super budget",
     "card": "Pollywog Symbiote",
     "why": "card draw and ramp; on 59% of Illuna decks on EDHREC (+58% synergy)",
     "usd": 0.22
    },
    {
     "tier": "Medium",
     "card": "Faerie Mastermind",
     "why": "draws off their extra cards",
     "usd": 12.33
    },
    {
     "tier": "Any cost",
     "card": "Cloudpiercer",
     "why": "card draw; on 48% of Illuna decks on EDHREC (+47% synergy)",
     "usd": 0.13
    }
   ]
  },
  {
   "card": "Forgotten Ancient",
   "read": 3,
   "why": "Grows on spells and moves counters; not a good mutate base.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Trumpeting Gnarr",
     "why": "makes bodies; on 59% of Illuna decks on EDHREC (+58% synergy)",
     "usd": 0.22
    },
    {
     "tier": "Super budget",
     "card": "Mythos of Illuna",
     "why": "removal and makes bodies; on 30% of Illuna decks on EDHREC (+28% synergy)",
     "usd": 0.2
    },
    {
     "tier": "Medium",
     "card": "Vesuvan Duplimancy",
     "why": "makes bodies; on 31% of Illuna decks on EDHREC (+30% synergy)",
     "usd": 5.36
    },
    {
     "tier": "Any cost",
     "card": "Return of the Wildspeaker",
     "why": "draw or overrun",
     "usd": 2.61
    }
   ]
  },
  {
   "card": "Faerie Vandal",
   "read": 3,
   "why": "A flash flier that grows on a second draw; a draw engine helps more (Cards 5).",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Growth Spiral",
     "why": "card draw and ramp; on 48% of Illuna decks on EDHREC (+24% synergy)",
     "usd": 0.4
    },
    {
     "tier": "Super budget",
     "card": "Genesis Ultimatum",
     "why": "card draw; on 32% of Illuna decks on EDHREC (+25% synergy)",
     "usd": 0.58
    },
    {
     "tier": "Medium",
     "card": "Omniscience",
     "why": "a key piece for this commander; on 36% of Illuna decks on EDHREC (+34% synergy)",
     "usd": 5.75
    },
    {
     "tier": "Any cost",
     "card": "Brainstorm",
     "why": "card draw; on 45% of Illuna decks on EDHREC (+32% synergy)",
     "usd": 3.22
    }
   ]
  },
  {
   "card": "Medusa, Inhuman Queen",
   "read": 3,
   "why": "Grows on noncreature spells in a creature deck.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Season of Growth",
     "why": "card draw; on 25% of Illuna decks on EDHREC (+23% synergy)",
     "usd": 0.23
    },
    {
     "tier": "Super budget",
     "card": "Fact or Fiction",
     "why": "instant card advantage",
     "usd": 0.29
    },
    {
     "tier": "Medium",
     "card": "Delayed Blast Fireball",
     "why": "one-sided wipe",
     "usd": 15.92
    },
    {
     "tier": "Any cost",
     "card": "Mulldrifter",
     "why": "a flier that draws two",
     "usd": 0.38
    }
   ]
  }
 ],
 "modular": [
  {
   "card": "Team Pennant",
   "read": 3,
   "why": "+1/+1 vigilance trample; Cards is the deck's weakest stat (2).",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Commander's Sphere",
     "why": "a rock that cashes in for a card",
     "usd": 0.78
    },
    {
     "tier": "Super budget",
     "card": "Mind Stone",
     "why": "a rock that cashes in for a card",
     "usd": 0.2
    },
    {
     "tier": "Medium",
     "card": "Hammer of Nazahn",
     "why": "protection; on 68% of Gilgamesh decks on EDHREC (+62% synergy)",
     "usd": 12.76
    },
    {
     "tier": "Any cost",
     "card": "Buster Sword",
     "why": "card draw; on 54% of Gilgamesh decks on EDHREC (+50% synergy)",
     "usd": 42.55
    }
   ]
  },
  {
   "card": "Goldhound",
   "read": 3,
   "why": "A Treasure dog; draw helps more.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Samurai's Katana",
     "why": "makes bodies; on 68% of Gilgamesh decks on EDHREC (+66% synergy)",
     "usd": 0.24
    },
    {
     "tier": "Super budget",
     "card": "Godo, Bandit Warlord",
     "why": "a finisher and a tutor; on 67% of Gilgamesh decks on EDHREC (+64% synergy)",
     "usd": 1.19
    },
    {
     "tier": "Medium",
     "card": "Kaldra Compleat",
     "why": "protection; on 65% of Gilgamesh decks on EDHREC (+64% synergy)",
     "usd": 9.43
    },
    {
     "tier": "Any cost",
     "card": "The One Ring",
     "why": "a turn of protection and cards",
     "usd": 107.55
    }
   ]
  },
  {
   "card": "Seer's Sundial",
   "read": 3,
   "why": "Pays 2 per land drop to draw; a stronger draw engine helps more.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Firion, Wild Rose Warrior",
     "why": "ramp and makes bodies; on 63% of Gilgamesh decks on EDHREC (+62% synergy)",
     "usd": 0.55
    },
    {
     "tier": "Super budget",
     "card": "Lizard Blades",
     "why": "a finisher; on 55% of Gilgamesh decks on EDHREC (+49% synergy)",
     "usd": 2.45
    },
    {
     "tier": "Medium",
     "card": "Excalibur, Sword of Eden",
     "why": "a key piece for this commander; on 55% of Gilgamesh decks on EDHREC (+52% synergy)",
     "usd": 17.55
    },
    {
     "tier": "Any cost",
     "card": "The Reaver Cleaver",
     "why": "ramp and makes bodies; on 62% of Gilgamesh decks on EDHREC (+50% synergy)",
     "usd": 27.62
    }
   ]
  },
  {
   "card": "Stark Industries Executive",
   "read": 3,
   "why": "2 mana a turn for a Treasure on a 1/2.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Coldsteel Heart",
     "why": "a rock that fixes",
     "usd": 1.69
    },
    {
     "tier": "Super budget",
     "card": "Brass Squire",
     "why": "a key piece for this commander; on 50% of Gilgamesh decks on EDHREC (+46% synergy)",
     "usd": 1.19
    },
    {
     "tier": "Medium",
     "card": "Seething Song",
     "why": "ramp; on 49% of Gilgamesh decks on EDHREC (+17% synergy)",
     "usd": 10.99
    },
    {
     "tier": "Any cost",
     "card": "The Fire Crystal",
     "why": "ramp and makes bodies; on 46% of Gilgamesh decks on EDHREC (+22% synergy)",
     "usd": 9.12
    }
   ]
  }
 ],
 "family": [
  {
   "card": "Spirited Companion",
   "read": 3,
   "why": "A dog that draws once; fine, but there are stronger draw pieces.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Aether Channeler",
     "why": "card draw and makes bodies; on 54% of Zinnia decks on EDHREC (+49% synergy)",
     "usd": 0.34
    },
    {
     "tier": "Super budget",
     "card": "Mulldrifter",
     "why": "a flier that draws two",
     "usd": 0.38
    },
    {
     "tier": "Medium",
     "card": "Faerie Mastermind",
     "why": "draws off their extra cards",
     "usd": 12.33
    },
    {
     "tier": "Any cost",
     "card": "Jacked Rabbit",
     "why": "card draw and makes bodies; on 48% of Zinnia decks on EDHREC (+46% synergy)",
     "usd": 4.16
    }
   ]
  },
  {
   "card": "Loyal Warhound",
   "read": 3,
   "why": "Fetches a Plains only when behind on lands.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Azorius Signet",
     "why": "ramp; on 58% of Zinnia decks on EDHREC (+29% synergy)",
     "usd": 0.32
    },
    {
     "tier": "Super budget",
     "card": "Boros Signet",
     "why": "ramp; on 55% of Zinnia decks on EDHREC (+29% synergy)",
     "usd": 0.69
    },
    {
     "tier": "Medium",
     "card": "Panharmonicon",
     "why": "a key piece for this commander; on 44% of Zinnia decks on EDHREC (+36% synergy)",
     "usd": 6.24
    },
    {
     "tier": "Any cost",
     "card": "Izzet Signet",
     "why": "ramp; on 53% of Zinnia decks on EDHREC (+24% synergy)",
     "usd": 0.29
    }
   ]
  },
  {
   "card": "Illusory Ambusher",
   "read": 3,
   "why": "Draws when it takes damage; situational.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Thought Monitor",
     "why": "an artifact that draws two",
     "usd": 0.34
    },
    {
     "tier": "Super budget",
     "card": "Commander's Sphere",
     "why": "a rock that cashes in for a card",
     "usd": 0.78
    },
    {
     "tier": "Medium",
     "card": "Farewell",
     "why": "pick what gets exiled; keep your side",
     "usd": 5.78
    },
    {
     "tier": "Any cost",
     "card": "Welcoming Vampire",
     "why": "card draw; on 40% of Zinnia decks on EDHREC (+37% synergy)",
     "usd": 2.78
    }
   ]
  },
  {
   "card": "Plumecreed Mentor",
   "read": 3,
   "why": "A counter for fliers entering is small; a draw piece helps more (Cards is 5).",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Curiosity",
     "why": "a card every hit",
     "usd": 1.23
    },
    {
     "tier": "Super budget",
     "card": "Rapid Augmenter",
     "why": "a key piece for this commander; on 53% of Zinnia decks on EDHREC (+50% synergy)",
     "usd": 0.26
    },
    {
     "tier": "Medium",
     "card": "Mystic Remora",
     "why": "cards off every noncreature spell they cast",
     "usd": 12.71
    },
    {
     "tier": "Any cost",
     "card": "Rhystic Study",
     "why": "a card every time an opponent doesn't pay 1",
     "usd": 67.41
    }
   ]
  }
 ],
 "spider": [
  {
   "card": "Web of Life and Destiny",
   "read": 3,
   "why": "8 mana (convoke helps) to put a creature from the top five into play each combat.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Twitching Doll",
     "why": "ramp and makes bodies; on 43% of Cosmic Spider-Man decks on EDHREC (+42% synergy)",
     "usd": 2.39
    },
    {
     "tier": "Super budget",
     "card": "Spider-Bot",
     "why": "ramp; on 36% of Cosmic Spider-Man decks on EDHREC (+35% synergy)",
     "usd": 0.26
    },
    {
     "tier": "Medium",
     "card": "Three Visits",
     "why": "an untapped dual at instant speed",
     "usd": 5.29
    },
    {
     "tier": "Any cost",
     "card": "Talisman of Conviction",
     "why": "a 2-mana R/W rock",
     "usd": 0.32
    }
   ]
  },
  {
   "card": "Spider-Man Noir",
   "read": 3,
   "why": "Only grows on lone attackers; the deck attacks wide.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Spider-UK",
     "why": "card draw; on 44% of Cosmic Spider-Man decks on EDHREC (+43% synergy)",
     "usd": 0.26
    },
    {
     "tier": "Super budget",
     "card": "Tireless Tracker",
     "why": "Clues on every land drop",
     "usd": 0.21
    },
    {
     "tier": "Medium",
     "card": "Faerie Mastermind",
     "why": "draws off their extra cards",
     "usd": 12.33
    },
    {
     "tier": "Any cost",
     "card": "Sensational Spider-Man",
     "why": "card draw; on 42% of Cosmic Spider-Man decks on EDHREC (+40% synergy)",
     "usd": 3.32
    }
   ]
  },
  {
   "card": "Lathiel, the Bounteous Dawn",
   "read": 3,
   "why": "Counters from life gained; Cards is low (4).",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Garruk's Uprising",
     "why": "draws on big creatures and gives trample",
     "usd": 0.55
    },
    {
     "tier": "Super budget",
     "card": "Aunt May",
     "why": "a key piece for this commander; on 74% of Cosmic Spider-Man decks on EDHREC (+72% synergy)",
     "usd": 0.26
    },
    {
     "tier": "Medium",
     "card": "Gwenom, Remorseless",
     "why": "a key piece for this commander; on 66% of Cosmic Spider-Man decks on EDHREC (+64% synergy)",
     "usd": 4.68
    },
    {
     "tier": "Any cost",
     "card": "Phyrexian Arena",
     "why": "an extra card every upkeep",
     "usd": 3.06
    }
   ]
  },
  {
   "card": "The Clone Saga",
   "read": 3,
   "why": "A slow saga: surveil, copy, draw on hits.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Spider-Sense",
     "why": "a counterspell; on 62% of Cosmic Spider-Man decks on EDHREC (+60% synergy)",
     "usd": 1.29
    },
    {
     "tier": "Super budget",
     "card": "Spider-Man 2099",
     "why": "a finisher; on 58% of Cosmic Spider-Man decks on EDHREC (+56% synergy)",
     "usd": 0.39
    },
    {
     "tier": "Medium",
     "card": "Impostor Syndrome",
     "why": "makes bodies; on 55% of Cosmic Spider-Man decks on EDHREC (+53% synergy)",
     "usd": 6.24
    },
    {
     "tier": "Any cost",
     "card": "Rhystic Study",
     "why": "a card every time an opponent doesn't pay",
     "usd": 67.41
    }
   ]
  }
 ],
 "zurgo": [
  {
   "card": "Herald of Dromoka",
   "read": 3,
   "why": "Vigilance for Warriors; Survival is low (3).",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Reigning Victor",
     "why": "protection and makes bodies; on 48% of Zurgo decks on EDHREC (+47% synergy)",
     "usd": 0.16
    },
    {
     "tier": "Super budget",
     "card": "Duty Beyond Death",
     "why": "protection; on 40% of Zurgo decks on EDHREC (+36% synergy)",
     "usd": 0.31
    },
    {
     "tier": "Medium",
     "card": "Boros Charm",
     "why": "team indestructible",
     "usd": 4.65
    },
    {
     "tier": "Any cost",
     "card": "Gornog, the Red Reaper",
     "why": "protection; on 38% of Zurgo decks on EDHREC (+37% synergy)",
     "usd": 1.0
    }
   ]
  },
  {
   "card": "Cloud Key",
   "read": 3,
   "why": "Saves 1 per spell of a chosen type; a real rock helps more.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Talisman of Conviction",
     "why": "a 2-mana R/W rock",
     "usd": 0.32
    },
    {
     "tier": "Super budget",
     "card": "Talisman of Indulgence",
     "why": "a 2-mana B/R rock",
     "usd": 0.65
    },
    {
     "tier": "Medium",
     "card": "Voice of Victory",
     "why": "makes bodies; on 68% of Zurgo decks on EDHREC (+52% synergy)",
     "usd": 19.99
    },
    {
     "tier": "Any cost",
     "card": "Commander's Sphere",
     "why": "a rock that cashes in for a card",
     "usd": 0.78
    }
   ]
  },
  {
   "card": "Voldaren Thrillseeker",
   "read": 3,
   "why": "Backup 2 and a fling; a bigger copy payoff does more.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Bone-Cairn Butcher",
     "why": "makes bodies; on 85% of Zurgo decks on EDHREC (+75% synergy)",
     "usd": 0.35
    },
    {
     "tier": "Super budget",
     "card": "Dalkovan Packbeasts",
     "why": "makes bodies; on 67% of Zurgo decks on EDHREC (+62% synergy)",
     "usd": 0.37
    },
    {
     "tier": "Medium",
     "card": "Zurgo Stormrender",
     "why": "card draw and a finisher; on 59% of Zurgo decks on EDHREC (+51% synergy)",
     "usd": 4.65
    },
    {
     "tier": "Any cost",
     "card": "Will of the Mardu",
     "why": "makes bodies; on 52% of Zurgo decks on EDHREC (+43% synergy)",
     "usd": 5.49
    }
   ]
  },
  {
   "card": "Oreskos Explorer",
   "read": 3,
   "why": "Plains to hand only per player ahead on lands.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Coldsteel Heart",
     "why": "a rock that fixes",
     "usd": 1.69
    },
    {
     "tier": "Super budget",
     "card": "Avenger of the Fallen",
     "why": "makes bodies; on 64% of Zurgo decks on EDHREC (+60% synergy)",
     "usd": 0.59
    },
    {
     "tier": "Medium",
     "card": "Toxic Deluge",
     "why": "a cheap wipe you control",
     "usd": 5.7
    },
    {
     "tier": "Any cost",
     "card": "Smothering Tithe",
     "why": "Treasure every time an opponent draws",
     "usd": 59.1
    }
   ]
  }
 ]
}
