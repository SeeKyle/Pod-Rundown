/* Crypt Crawl — side-scrolling auto-battler for Pod Rundown.
   Engine (pure logic, runs headless in node for balance sims) + renderer + UI.
   Content lives in the CFG tables so stages, biomes, enemies, bosses, items and abilities can be added as rows. */
(function(){
'use strict';
const DATA=__CRAWLDATA__;      // heroes from the decks (built by battler_data.py)
const ATLAS=__CRAWLATLAS__;    // sprite + backdrop atlas (built by make_crawl_art.py)
const OWNERS={Kyle:'🎩',Cheez:'🧀',Leon:'🪼',Eddie:'♠'};   // 0.12.92 (Kyle): everyone plays; the hero roster is shared   // 0.12.1: only Kyle's tab while the game is rebuilt (Cheez and Leon come back later)

// ======================================================================= CONFIG TABLES
const CFG={
  W:384,H:216,GROUND:200,
  stagesPerBiome:10,
  strangerStage:10,                  // clearing this frees the mystery stranger (3rd party spot)
  maxStage:20,                      /* 0.12.117 (Kyle): 1-10 the lake, 11-20 downtown; beat 20 to Prestige */
  slots:{spell:3,item:2},
  maxRank:10,
  walkSpeed:26,
  rarity:[
    {id:'C',name:'Common',pts:1,w:62,col:'#c9c9c9'},
    {id:'U',name:'Uncommon',pts:2,w:27,col:'#4fd46a'},
    {id:'R',name:'Rare',pts:3,w:11,col:'#4aa8ff'},
    {id:'L',name:'Legendary',pts:5,w:2.5,col:'#ffb020',minPrestige:2}   // locked early on purpose
  ],
  biomes:[
    {id:'grave',name:'Blackwater Lake',pool:{zombie:1,fireman:.14,skarcher:.1},boss:'gravelord'},
    {id:'city',name:'Downtown',pool:{zombie:1,fireman:.2,skarcher:.1},boss:null},   /* 0.12.108 (Kyle): the city streets. 0.12.117: stages 11-20 */
  ],   /* 0.12.85 (Kyle): only the cabin-by-the-lake level for now; it just keeps going. Saved for later:
    {id:'manor',name:'Hollowmere Cemetery',pool:{zombie:1,fireman:.14},boss:'countess'},
    {id:'bog',name:'The Cathedral Corridor',pool:{zombie:1,fireman:.14},boss:'maw'}, */
  enemies:{ // hp/dmg at stage 1; spd px/s; atk = seconds between hits; cost = spawn budget
    // rebuilt roster: only the zombie so far. animAtk = attack animation length (s), hitAt = when in it the blow lands (s)
    // Kyle's zombie: 25 HP (0.12.3, was 15), 1d6 per hit, swings every 1.25s, 12px reach, very slow, 3 armor (=6% less damage), small-medium knockback resistance,
    // 25% on hit to Bleed (20 dmg over 5s), item 4% / small gold 17.5%. Three looks (skins), identical stats.
    zombie:  {undead:1,scale:.88,aimScale:.88,hp:25,dmgDie:6,spd:10.3,   /* 0.12.201 (Kyle): all base mobs a touch faster */   /* 0.12.136 (Kyle): 9.5 (was 8.8) */   /* 0.12.38 (Kyle): 12% smaller, about the size of our humanoids */atk:1.25,reach:12,armorPts:3,kbRes:.35,bleed:{chance:.25,dmg:20,dur:5},
              itemChance:.04,goldChance:.29,goldAmt:[3,7],stack:true,xp:2,pts:10,cost:1.2,animAtk:.6,hitAt:.38,skins:['zombie','zombie_f','zombie_b']},
    // 0.12.62 (Kyle) Fireman_Zombie: a zombie in turnout gear. A touch slower than a normal zombie, 1.25x the life, triple the armor,
    //   hits slightly harder, and can't be burned (fire and burn damage do nothing to him). Swings a heavy gloved arm.
    // 0.12.65 (Kyle): now 4x a zombie's health (100) and armor (12) at 2/5 its speed
    fireman: {undead:1,scale:.88,aimScale:.88,hp:100,dmgDie:7,spd:5.5,   /* 0.12.136 (Kyle): 5 (was 3.5) */atk:1.25,reach:15+5/3,armorPts:12,kbRes:1,ccHalf:1,cleave:1,   /* 0.12.238 (Kyle): reach +5 screen px (15 -> 16.7). 0.12.201 (Kyle): longer reach, immune to knockback, slows/stuns/dazes last half as long, swings cleave everything in reach in front */bleed:{chance:.25,dmg:20,dur:5},fireImmune:1,name:'Fireman_Zombie',
              itemChance:.05,goldChance:.35,goldAmt:[4,8],stack:true,xp:5,pts:30,cost:3.2,animAtk:.6,hitAt:.4,skins:['zombie_fire']},
    // 0.12.183 (Kyle) Skeleton_Archer (CraftPix free skeleton pack): hangs back near the right edge and shoots arrows (1d6) every 2.6s,
    //   with a 0.6s draw before each shot. Fragile, slow, can't bleed (no blood). From stage 3 on.
    skarcher:{undead:1,scale:.88,aimScale:.88,hp:18,dmgDie:6,spd:8.6,atk:2.6,ranged:1,stop:270,proj:'arrow',reach:12,armorPts:2,kbRes:.25,noBleed:1,name:'Skeleton_Archer',
              itemChance:.05,goldChance:.32,goldAmt:[3,7],stack:true,xp:4,pts:25,cost:2.5,animAtk:1.0,shotAt:.6,hitAt:.5,skins:['skarcher']},
    // 0.12.175 (Kyle) Screamer: a fast, lanky zombie woman (CraftPix freebie art). Fragile, hits light, runs. When she gets near the party she stops and
    //   SHRIEKS (1.4s): if she finishes it, 2-4 more zombies come running in (+1 every 5 stages, max 6). Kill or stun her mid-scream and nobody comes.
    //   Up to 2 shrieks, 14s apart. Stage 1: exactly one, in the last wave. Later stages: 1 (stage 2-4), 1-2 (5-9), 2 (10-14), 2-3 (15+), all in the back half of the waves.
    screamer:{undead:1,scale:.88,aimScale:.88,hp:27,dmgDie:4,spd:27,   /* 0.12.231 (Kyle): 27 HP (was 23) */   /* 0.12.201 (Kyle): +3 HP, speed between zombie and werewolf */atk:1.0,reach:12,armorPts:1,kbRes:.15,name:'Screamer',fps:11,
              itemChance:.04,goldChance:.31,goldAmt:[3,7],stack:true,xp:4,pts:25,cost:2,animAtk:.5,hitAt:.35,skins:['screamer'],scream:{r:115,T:1.4,cd:14,max:2,n:[2,4]}},
    // 0.12.206 (Kyle) Giant_Bat: a big flier (bigger than a real bat next to a person). It circles above a hero with a small up/down bob
    //   (no dodge chance: shots simply have to connect with it), then swoops down and strikes for 1d3 and climbs back up. From stage 2.
    bat:{undead:0,hp:12,dmgDie:3,spd:34,atk:2.4,fly:1,reach:10,armorPts:0,kbRes:.2,name:'Giant_Bat',noLoot:0,
              itemChance:.03,goldChance:.22,goldAmt:[3,7],xp:3,pts:14,cost:1.6,animAtk:.4,hitAt:.2},
    // Kyle's werewolf, the first fast enemy: zombie stats except 30 HP (0.12.3, was 40) and fast; hunts the back-line heroes first
    werewolf:{hp:38,dmgDie:7,spd:47,atk:1.2,reach:15,   /* 0.12.201 (Kyle): faster, a little more reach */armorPts:4,   /* 0.12.65: a bit sturdier and meaner (was 30 HP, 1d6, 3 armor) */kbRes:.35,bleed:{chance:.25,dmg:20,dur:5},
              itemChance:.04,goldChance:.32,goldAmt:[3,7],xp:3,pts:16,cost:2.2,animAtk:.7,hitAt:.45,backline:true,fps:12,scale:.77,
              leap:{dmg:10,gap:25,dur:.55,cd:8,bleed:[12,4]}},   /* 0.12.203 (Kyle): the leap is a line attack: it bounds 25% further, right through its target, and every hero it passes through takes 10 and bleeds */   // jumping attack: bounds over a 20px gap and lands for 10 damage
  },
  harvestLive:true,wraithLive:true,   /* 0.12.132 (Kyle): switched on */   /* 0.12.127 (Kyle): switched on to try him */
  bosses:{
    wraith:{undead:1,name:'The Hollow Wraith',hp:1300,dmg:16,spd:16,xp:220,pts:5200,art:'wraith'},   /* 0.12.130 (Kyle) stage 20 boss */
    harvest:{undead:1,name:'The Harvest Knight',hp:1100,dmg:15,spd:12,xp:140,pts:3200,art:'harvest'},   /* 0.12.127 (Kyle) stage 10 boss */
    gravelord:{undead:1,name:'The Gravelord',hp:950,dmg:20,spd:9, xp:60, pts:1500},
    countess: {undead:1,name:'The Crimson Countess',hp:1350,dmg:20,spd:14,xp:90,pts:2500,fly:1},
    maw:      {name:'The Maw Below',hp:2000,dmg:28,spd:0, xp:130,pts:4000},
  },
  stage(n,prestige){
    const bi=Math.min(this.biomes.length-1,Math.floor((n-1)/this.stagesPerBiome)), b=this.biomes[bi];
    const P=prestige||0;
    return {n,biome:b,bi,boss:(n===10&&this.harvestLive)?'harvest':(n===20&&this.wraithLive)?'wraith':null,   /* 0.12.84 (Kyle): no bosses for now (the table stays for later) */
      len:1.5*(820+42*(n-1)),   // 5 stages per biome; each about 25% shorter than before
      rate:1.5*(0.62+0.061*(n-1))*(1+0.3*P),   // spawn budget per second
      // 0.12.13 (Kyle): each stage ~10-20% harder on average (was ~25%): +8% enemy HP, +5% damage and +4% more enemies per stage
      //   = about 1.08*1.05*1.04 = +18% total threat per stage (plus the extra werewolves and strays).
      // 0.12.65 (Kyle): enemies get +3% health, armor and damage per stage (rounded down), nothing else
      hpMul:Math.pow(1.03,n-1)*Math.pow(2.2,P),
      dmgMul:Math.pow(1.03,n-1)*Math.pow(1.8,P),
      countMul:1+.04*(n-1),   /* 0.12.104 (Kyle): 4% more enemies per stage (was 5%) */   /* 0.12.87 (Kyle): 5% more enemies per stage, rounded down per wave */   // more enemies per stage stays (that is numbers, not stats)
      xpMul:1+0.10*(n-1)+P*2.4};   /* 0.12.104 (Kyle): XP per kill +10% per stage (was 19%) */
  },
};
// hero fighting styles (basic attack + body), keyed by deck
const STYLE={
  grim:{atk:'melee',reach:30,hp:1.15,dmg:1.15},
  vile:{atk:'duo',a:'orb',b:'melee',reach:28,hp:.95,dmg:.85},
  felothar:{atk:'melee',reach:26,hp:1.7,dmg:.7,tank:1},
  thing:{atk:'caster',proj:'shard',hp:1.05,dmg:1},
  kykar:{atk:'caster',proj:'zap',hp:.85,dmg:1},
  depala:{atk:'melee',reach:26,hp:1.25,dmg:1.1},
  kotis:{atk:'melee',reach:24,hp:.95,dmg:.65,double:1,aspd:1.15},
  dragons:{atk:'ranged',proj:'fire',range:150,hp:.9,dmg:1.05,splash:14},
  mathas:{atk:'ranged',proj:'quarrel',range:210,hp:.8,dmg:1.25,aspd:.85},
  turtle:{atk:'duo',a:'melee',b:'melee',reach:36,hp:1.25,dmg:.75,tank:1},
  marina:{atk:'caster',proj:'wisp',hp:.85,dmg:1},
  korvold:{atk:'melee',reach:28,hp:1.35,dmg:1.05,devour:1},
  thranduil:{atk:'ranged',proj:'arrow',range:230,hp:.85,dmg:1.05,aspd:1.1},
  jp:{atk:'gunner',proj:'bullet',reach:18,range:290,hp:1,dmg:1},
  knight:{atk:'blade',proj:'kunai',reach:20,range:0,hp:1,dmg:1},   // 0.12.180 Crimson_Knight: sword and shield, no ranged
  carcher:{atk:'gunner',proj:'arrow',reach:12,range:260,hp:1,dmg:1},   // 0.12.178 Chibi_Archer: bow
  csorc:{atk:'gunner',proj:'zap',reach:13,range:220,hp:1,dmg:1},   // 0.12.178 Chibi_Sorcerer: lightning bolts
  soldier:{atk:'gunner',proj:'bullet',reach:15,range:240,hp:1,dmg:1},   // 0.12.175 Soldier: assault rifle
  shoshi:{atk:'gunner',proj:'bullet',reach:1,range:230,hp:1,dmg:1},
  edward:{atk:'gunner',proj:'bullet',reach:14,range:210,hp:1,dmg:1},   // 0.12.207 Edward: nail gun
  cheez:{atk:'blade',proj:'kunai',reach:21,range:0,hp:1,dmg:1},   // 0.12.234 Cheez: beam katana, no ranged   // 0.12.110 Shoshi: machine pistol
  eng:{atk:'gunner',proj:'nade',reach:20,range:165,hp:1,dmg:1},   // 0.12.105 Engineer: wrench + Grenade_Launcher
  flannel:{atk:'gunner',proj:'bullet',reach:20,range:250,hp:1,dmg:1},
  lumberjack:{atk:'blade',proj:'yarrow',reach:22,range:200,hp:1,dmg:1},
  cultist:{atk:'gunner',proj:'void',reach:18,range:210,hp:1,dmg:1},   // 0.12.21 Void_Cultist: ritual dagger + void bolts
  robot:{atk:'gunner',proj:'gat',reach:22,range:160,hp:1,dmg:1},   // 0.12.17 Moss_Mech: arc blade + gatling arm   // 0.12.11 Lumber_Jack: axe + bow
  druid:{atk:'gunner',proj:'leaf',reach:18,range:220,hp:1,dmg:1},   // 0.12.9 Druid: nature caster and healer
  archer:{atk:'gunner',proj:'yarrow',reach:22,range:280,hp:1,dmg:1},   // 0.12.7 Yumi_Archer: longbow + bow strike
  chibi:{atk:'blade',proj:'kunai',reach:24,range:180,hp:1,dmg:1},   // 0.12.6 Chibi_Warrior: sword only
  flannel_pal:{atk:'gunner',proj:'bullet',reach:16,range:250,hp:1,dmg:1},
  dog:{atk:'blade',proj:'bullet',reach:14,range:0,hp:1,dmg:1},   /* 0.12.44 Guard Dog (camp Kennel) */   // Flannel_Man's companion (summoned, not picked)   // 0.12.3 Flannel_Man: rifle + crowbar, one body
  joel:{atk:'duo',a:'arrow',b:'melee',reach:28,range:210,hp:1.05,dmg:.9,companion:1},
  robots:{atk:'ranged',proj:'plasma',range:190,hp:1.35,dmg:1.0,tank:1},
  blood:{atk:'caster',proj:'blood',hp:.95,dmg:.9,leech:.25},
  mech:{atk:'ranged',proj:'shell',range:200,hp:1.05,dmg:1.1,splash:12},
  weather:{atk:'caster',proj:'frost',hp:1.1,dmg:.95,chill:1},
};
const ORDER={melee:0,blade:.5,duo:1,gunner:1.5,ranged:2,caster:3};
// walking pace per hero (px/s): heavy/armored/stone slow, light and quick ones faster
const MOVE={cheez:17,edward:16,knight:15,carcher:19,csorc:16,soldier:16,shoshi:17,eng:15,jp:16,dog:24,cultist:15,robot:14,lumberjack:18,druid:16,archer:17,chibi:20,flannel:15,flannel_pal:15,grim:24,vile:26,felothar:18,thing:20,kykar:26,depala:22,kotis:34,dragons:30,mathas:28,turtle:22,marina:26,korvold:26,thranduil:32,joel:28,robots:22,blood:30,mech:24,weather:24};
const MINION_SPEED=62;
// how each hero's Summon spell behaves when recast (easy to retune per hero)
const SUMMON_STYLE={grim:'empower',thing:'empower',korvold:'empower',felothar:'mend',depala:'mend',robots:'mend',mech:'mend',
  vile:'volatile',mathas:'volatile',joel:'volatile',kykar:'swarm',kotis:'swarm',dragons:'swarm',turtle:'swarm',thranduil:'swarm',blood:'swarm',marina:'linger',weather:'linger'};
const SUMMON_TXT={empower:'Recasting grows the one already out (+25% power, up to 3 stacks) instead of adding another.',mend:'Recasting fully repairs and refreshes the one already out.',
  volatile:'Recasting detonates the old one in a blast as the new one arrives.',swarm:'Calls two smaller ones each time.',linger:'Lasts 18s; recasting refreshes it.'};
const RANGED_SUMMONERS=new Set(['robots','mech','marina','kykar','thing','vile']);   // their summons shoot from mid-screen; everyone else's charge in
// ---- signature abilities: every hero comes with one, on its own cooldown (not a spell slot). fn(game, hero, atk)
const SIG={
  knight:{name:'Shield_Wall · Crimson_Charge · Leap_Strike · Shield_Bash · Blood_Oath',cd:16,txt:'Holds the front in full crimson plate with a sword-and-shield combo. Throws up a Shield_Wall that pulls zombies onto him, Crimson_Charges through a lane of them, Leap_Strikes onto anything mauling a friend, and Shield_Bashes to stun (and interrupt shrieks and archers). Blood_Oath: every kill heals him and he hits harder when he\'s hurt.',fn:()=>false},
  carcher:{name:'Piercing_Shot · Tumble · Snare_Arrow · Hunters_Mark · Light_Feet',cd:10,txt:'Shoots a bow from long range, puts a Piercing_Shot through a whole line of zombies, Tumbles back out of reach when one gets on her, pins fast or dangerous zombies with a Snare_Arrow, and puts a Hunters_Mark on the one the team should focus. Light_Feet: quick and hard to pin down.',fn:()=>false},
  csorc:{name:'Chain_Lightning · Thunderclap · Static_Shield · Overcharge · Arcane_Flow',cd:11,txt:'Throws sparks of lightning, arcs Chain_Lightning through a pack, calls down a Thunderclap on a crowd, wraps a friend in a Static_Shield, and Overcharges his sparks so they jump. Arcane_Flow: every kill gives him energy back.',fn:()=>false},
  cheez:{name:'Iaijutsu · Sake_Break · Error_Code_Fix · Dice-Boys_Banner · Perfect_Attendance',cd:9,txt:'A drunken techno-samurai with a beam katana. Cuts down whole lines of zombies with an Iaijutsu draw-slash, gets loose and fast on Sake_Break, fixes friends (or glitches the big ones) with Error_Code_Fix, plants a DICE BOYS banner as Dice-Boys_Banner, and never misses game night (Perfect_Attendance).',fn:()=>false},
  edward:{name:'Nail_Strip · Toolbox_Toss · Chutzpah · Power_of_Friendship · Loyal_to_a_Fault',cd:14,txt:'Fires a Nail_Gun from mid range and smacks anything that gets close with it. Dumps a Nail_Strip down a crowded lane (and leaves the nails on the ground), heaves his Toolbox_Toss at the biggest threat, powers up with the Power_of_Friendship when his people are hurting, and takes hits for anyone about to drop, getting energy back for every one (Loyal_to_a_Fault).',fn:()=>false},
  soldier:{name:'Frag_Grenade · Smoke_Grenade · Covering_Fire · Ammo_Drop · Battle_Hardened',cd:14,txt:'Holds the middle with a hip-fired Machine_Gun (15-round mag: taps, or lets rip on big targets) and a rifle-butt up close, lobs a Frag_Grenade into bunched-up zombies (4d6 blast and a 1.5s stun), pops Smoke_Grenades to cover hurt friends, lays down aimed Covering_Fire to slow a lane, drops an Ammo_Drop crate for the shooters, and is Battle_Hardened: below half HP he takes 15% less damage and reloads 25% faster.',fn:()=>false},
  shoshi:{name:'Ctrl_Z · Turn_It_Off_And_On_Again · Tech_Support · Dad_Mode · Always_Online',cd:12,txt:'Taps zombies with an Automatic_Pistol (20-round mag; unloads on big targets), undoes the damage an ally just took, reboots allies in trouble, keeps everyone\'s cooldowns moving with Tech_Support, goes dad mode for anyone about to drop, and is Always_Online: pings when someone goes down, kills car alarms from his phone, and calls targets for everyone near him.',fn:()=>false},
  grim:{name:'Royal Cleave',cd:6,txt:'Sweeps every ground enemy in reach for 220% damage and shoves them back.',fn:(g,h,a)=>g.sigArea(h,46,a*2.2,{kb:1.4,ground:1,fx:'slash'})},
  vile:{name:'Hexburst',cd:5,txt:'A hex orb bursts on the nearest enemy for 160% and 80% around it.',fn:(g,h,a)=>g.sigShot(h,'orb',a*1.6,{splash:26})},
  felothar:{name:'Shield Wall',cd:9,txt:'Shields the whole team for 10% of his max HP.',fn:(g,h,a)=>{for(const o of g.alive()){o.shield+=h.max*.1;o.shieldT=6;}g.fx.push({k:'ring',x:h.x,y:g.G-24,r:30,t:0,c:'#ffd23f'});return true;}},
  thing:{name:'Shard Storm',cd:6,txt:'Hurls 2 big crystal shards at random enemies for 160% each.',fn:(g,h,a)=>g.sigMulti(h,'shard',a*1.6,2)},
  kykar:{name:'Chain Lightning',cd:6,txt:'Lightning arcs through 3 enemies for 120% each.',fn:(g,h,a)=>g.sigChain(h,a*1.2,3)},
  depala:{name:'Rocket Hammer',cd:6,txt:'Smashes the front enemy for 260%, stunning and knocking it back.',fn:(g,h,a)=>g.sigFront(h,a*2.6,{stun:.6,kb:1.6})},
  kotis:{name:'Venom Flurry',cd:5,txt:'Four quick stabs for 60% each; the target is poisoned.',fn:(g,h,a)=>g.sigFront(h,a*.6,{hits:4,burn:a*.4})},
  dragons:{name:'Twin Breath',cd:7,txt:'Fire and frost wash over everything within 90px: 110% damage and a chill.',fn:(g,h,a)=>g.sigArea(h,90,a*1.1,{slow:.35,fx:'ring',c:'#ff8a1f'})},
  mathas:{name:'Bounty Mark',cd:7,txt:'Marks the toughest enemy (takes +20% for 6s) and shoots it for 200%.',fn:(g,h,a)=>g.sigMark(h,a*2)},
  turtle:{name:'Shell Spin',cd:6,txt:'Spins through every ground enemy in reach for 140%, shoving them back.',fn:(g,h,a)=>g.sigArea(h,40,a*1.4,{kb:1.2,ground:1,fx:'ring',c:'#c8b890'})},
  marina:{name:'Lantern Haunt',cd:9,txt:'Lets the lantern ghost out to fight for 9s (one at a time).',fn:(g,h,a)=>{g.addMinion(h,h.max*.3,a*.6,9,'spirit','sig',1);return true;}},
  korvold:{name:'Gorge',cd:6,txt:'Bites the front enemy for 260% and heals for 30% of it.',fn:(g,h,a)=>g.sigFront(h,a*2.6,{heal:.3})},
  thranduil:{name:'Volley',cd:6,txt:'Looses 3 heavy arrows at random enemies for 115% each.',fn:(g,h,a)=>g.sigMulti(h,'arrow',a*1.15,3)},
  cultist:{name:'Syphon_Life · Lethal_Strikes · Spawn_Tentacle · Call_of_Cthulhu · Ritual_Blade',cd:12,txt:'A hooded void cultist with a poisoned ritual dagger who pays for his magic in blood.',fn:()=>false},
  robot:{name:'Arc_Surge · Missile_Barrage · Smoke_Screen · Nano-Tech_Repair_Bots · Primary_Directive',cd:12,txt:'A hunched olive war-walker: a flamethrower up close, a Targeted Lazer at range, and a jetpack for getting out of trouble.',fn:()=>false},
  lumberjack:{name:'Whirl_Wind · Ground_Chop · Hatchet_Leap · Timber_Rage · Feller\'s_Rhythm',cd:14,txt:'An axeman with a hunting bow.',fn:()=>false},
  druid:{name:'Mend · Rejuvenating Bloom · Thorn Wave · Cyclone',cd:4,txt:'Mend (20 energy, 5s): instantly heals the most-hurt ally 10%. Rejuvenating Bloom (40 energy, 14s): heals an ally 4% of max HP every second for 8s. Thorn Wave (35 energy, 14s): a wave of thorns erupts along the ground down her lane; everything it bursts under takes 2d6 and bleeds. Cyclone (40 energy, 18s): a tornado wanders in front of her for 5s, pulling nearby enemies in and grinding down everything inside it.',fn:()=>false},
  archer:{name:'Arrow_Rain · One Nocked, Two in Hand · Blow_Gun',cd:14,txt:'Arrow_Rain (40 energy, 18s cooldown): looses a volley into the air and 16 arrows rain down on the thickest group of enemies (1d6 each, about 70px wide and 2 lanes up and down). Blow_Gun (25 energy, 9s cooldown): puffs a poison dart that always adds 1 poison stack to a living target (75% chance of a 2nd, 50% of a 3rd); each stack deals 3% of max HP every 1.5s for 7.5s, and any new stack resets the timer. Undead are immune. One Nocked, Two in Hand (30 energy, 14s cooldown): he nocks one arrow and holds two more ready, his next 3 arrows fly much faster (a third of the usual wait, quicker draw). Longbow shots (1d10) and a close-range bow strike (1d8).',fn:()=>false},
  chibi:{name:'Wave Dash · War Cry · Poultice',cd:10,txt:'Wave Dash (45 energy, 16s cooldown): rides a blue energy wave up to 400px forward, hitting everything it passes through (2 lanes up and down) for a normal sword hit (2d5 base, buffs and crits apply). War Cry (20 energy, 7s cooldown): every ally within 800px gets +25% damage and attack speed for 7s. Sword combo: Attack 1, Attack 2, and a running slash, plus a kunai throw (1d4) at enemies he can\'t reach yet.',fn:()=>false},
  eng:{name:'Build · Repair · Modify · Satchel_Charge · Field_Plating',cd:20,txt:'Builds a watchtower, a concrete barrier and a tesla coil, fixes them and the Warhound, bolts auto-turrets onto wrecks, and blows things up with a satchel he sets off himself.',fn:()=>false},
  jp:{name:'Toke_Break · Protect_the_Familia · No_Scope · Trash_Talk',cd:20,txt:'Smokes up to get HIGH (Wake_n_Bake), rushes in to shield family in trouble (and shield-bashes the closest zombie away), no-scopes zombies in a line with the Kar98 and talks trash to pull zombies onto himself.'},
  flannel:{name:'Aimed Shot · Proximity_Bomb · Traveling_Companion',cd:14,txt:'Call Traveling_Companion (25 energy, 24s cooldown, 0.8s whistle): calls his Traveling_Companion, a timid partner who circles around him, with a third of his stats, her own Brick Throw (never misses, 75% stun) and Bottle_Distraction (34 energy, 16s: she lobs a bottle behind the zombies, preferably behind a crowd; every zombie within 180px turns and walks to the noise for 2.5s). If she is already out, she heals 7% of her max HP instead. Proximity_Bomb (35 energy, 10s cooldown): planted, tossed underhand to roll, or thrown overhand; it blows up the first enemy to come near it, hurting everything around it (area damage, knockback, 50% bleed). Aimed Shot (40 energy, 14s cooldown, 2s cast with a laser sight): a carefully aimed rifle shot that always goes to the middle (head) box, with +5% crit chance and 2.5x crit damage. Pierces through one enemy.',fn:()=>false},   // runs from Game.gunner (CHAR abilities), shown here
  joel:{name:'Brick Toss',cd:7,txt:'The scout lobs a brick for 200% that stuns the target for 0.75s.',fn:(g,h,a)=>g.sigShot(h,'brick',a*2,{stun:.75})},
  robots:{name:'Overcharge',cd:7,txt:'A piercing plasma beam hits every enemy in a line for 160%.',fn:(g,h,a)=>g.sigArea(h,260,a*1.6,{fx:'beamline',c:'#3ff0ff'})},
  blood:{name:'Blood Rite',cd:7,txt:'Drains 3 enemies for 90% and heals the whole team for half of it.',fn:(g,h,a)=>g.sigDrain(h,a*.9,3)},
  mech:{name:'Mortar Barrage',cd:7,txt:'Two big shells crash down for 160% with splash.',fn:(g,h,a)=>g.sigMulti(h,'shell',a*1.6,2,{splash:20})},
  weather:{name:'Blizzard',cd:8,txt:'Chills every enemy (−50% speed, 2s) and deals 60%.',fn:(g,h,a)=>g.sigArea(h,999,a*.6,{slow:.5,fx:'frost'})},
};
// ---- damage pipeline: every hit goes through mitigate(). Today there is one type ('physical') and armor is a flat % reduction.
// To add types later: list them here, tag attacks with {type:'fire'} etc., and give enemies/heroes a resist map
// (e.g. CFG.enemies.zombie.resist={fire:-0.5, cold:0.3} = weak to fire, resists cold).
const DMG_TYPES={physical:{name:'Damage'}};
// Kyle's armor rule: points 1-20 = 2% less damage each, 21-40 = 1% each, 41+ = 0.5% each (capped at 90%)
function armorReduction(a){a=Math.max(0,a||0);return Math.min(.9,Math.min(a,20)*.02+Math.min(Math.max(a-20,0),20)*.01+Math.max(a-40,0)*.005);}
function mitigate(target,amt,type){
  type=type||'physical';
  const armor=target.armor!=null?target.armor:((target.E&&target.E.armor)||(target.B&&target.B.armor)||0);
  const res=(target.resist||(target.E&&target.E.resist)||(target.B&&target.B.resist)||{})[type]||0;
  const pts=target.E&&target.armorPts!=null?target.armorPts:((target.E&&target.E.armorPts)||(target.B&&target.B.armorPts)||target.armorPts||0);   /* enemies carry their own stage-scaled armor */
  return Math.max(1,amt*(1-Math.min(.75,armor))*(1-armorReduction(pts))*(1-res));
}

// ======================================================================= ABILITIES (spells) + AUGMENTS
// a = attack power of the owner, r = rank (1..10). Each describes itself for the pick cards.
const AUG={
  burn:{name:'Burn',txt:'sets targets ablaze'}, stun:{name:'Stun',txt:'stuns targets briefly'},
  slow:{name:'Wither',txt:'slows targets'}, shred:{name:'Shred',txt:'targets take +20% damage'},
  leech:{name:'Lifesteal',txt:'heals the team for part of the damage'}, knock:{name:'Knockback',txt:'shoves targets back'},
  chain:{name:'Chain',txt:'jumps to one more enemy'}, pierce:{name:'Pierce',txt:'passes through enemies'},
  echo:{name:'Echo',txt:'recasts at half power'}, extra:{name:'Multiply',txt:'+1 projectile / target / minion'},
  shield:{name:'Ward',txt:'also shields the caster'}, execute:{name:'Execute',txt:'+100% damage to enemies under 30%'},
  explode:{name:'Volatile',txt:'minions explode when they fall'}, taunt:{name:'Taunt',txt:'minions draw enemy attacks'},
  all:{name:'Mass',txt:'affects the whole team'}, thorns:{name:'Thorns',txt:'reflects 30% of blocked damage'},
};
const SPELL={
  bolt:{label:'Bolt',cd:2.6,augs:['pierce','burn','chain','extra','echo'],
    txt:(r,a,S)=>`Fires ${1+Math.floor(r/4)+(S.aug.extra?1:0)} bolt${r>=4||S.aug.extra?'s':''} for ${Math.round(a*(.7+.12*r))} damage each.`},
  nova:{label:'Nova',cd:7,augs:['stun','leech','knock','echo','burn'],
    txt:(r,a)=>`Blasts every enemy within ${46+3*r}px of the front line for ${Math.round(a*(1.2+.22*r))}.`},
  smite:{label:'Smite',cd:5.5,augs:['execute','chain','stun','shred'],
    txt:(r,a)=>`Strikes the toughest enemy for ${Math.round(a*(2.4+.45*r))}.`},
  drain:{label:'Drain',cd:4.5,augs:['extra','slow','leech','shred'],
    txt:(r,a,S)=>`Drains ${2+Math.floor(r/3)+(S.aug.extra?2:0)} enemies for ${Math.round(a*(.6+.12*r))}; heals the weakest ally for 40% of it.`},
  summon:{label:'Summon',cd:9,augs:['explode','taunt','extra','leech'],
    txt:(r,a,S,o,hk)=>{const cap=(r>=10?3:r>=5?2:1)+(S.aug.extra?1:0);const st=SUMMON_STYLE[hk]||'replace';return `Calls a minion (${Math.round(o.max*(.18+.03*r))} HP, ${Math.round(a*(.35+.06*r))} dmg). Up to ${cap} out. ${SUMMON_TXT[st]||'Recasting replaces the oldest.'}`;}},
  regen:{label:'Regen',cd:6,augs:['all','shield','echo'],
    txt:(r,a,S)=>`Heals ${S.aug.all?'every ally':'the weakest ally'} for ${Math.round(8+1.4*r)}% of their max HP.`},
  aegis:{label:'Aegis',cd:10,augs:['thorns','echo','leech'],
    txt:(r,a,S,o)=>`Shields the team for ${Math.round(o.max*(.05+.013*r))} for 6s.`},
  freeze:{label:'Freeze',cd:8,augs:['stun','shred','burn','echo'],
    txt:(r,a)=>`Chills every enemy (−45% speed, ${(1.6+.15*r).toFixed(1)}s) and deals ${Math.round(a*(.3+.08*r))}.`},
  counter:{label:'Counter',cd:7,augs:['stun','shield','echo'],
    txt:(r,a)=>`Wipes enemy projectiles and stuns ranged foes for ${(0.6+0.1*r).toFixed(1)}s; deals ${Math.round(a*(.4+.1*r))} to each.`},
  pump:{label:'Pump',passive:1,augs:[],txt:(r)=>`Passive: team damage +${4*r}%.`},
  haste:{label:'Haste',passive:1,augs:[],txt:(r)=>`Passive: team attack speed +${(3.5*r).toFixed(1)}%, cooldowns −${(1.5*r).toFixed(1)}%.`},
  insight:{label:'Insight',passive:1,augs:[],txt:(r)=>`Passive: +${6*r}% run XP, +${r} luck.`},
  devour:{label:'Devour',passive:1,augs:[],txt:(r)=>`Passive: kills heal the owner ${(.6+.25*r).toFixed(1)}% and grow team damage (resets each stage).`},
};
const MAXNAME=DATA.arch;   // titles for rank-10 abilities
const PROCS={ // items: ~half carry one of these, chosen from the card name
  ignite:{t:'onhit',txt:(c)=>`${c}% chance on hit: ignite the target.`},
  spark:{t:'onhit',txt:(c)=>`${c}% chance on hit: loose a bonus bolt.`},
  stunhit:{t:'onhit',txt:(c)=>`${c}% chance on hit: stun the target.`},
  critnova:{t:'oncrit',txt:(c)=>`${c}% chance on crit: small blast around the target.`},
  killheal:{t:'onkill',txt:(c)=>`${c}% chance on kill: heal the team 4%.`},
  killraise:{t:'onkill',txt:(c)=>`${c}% chance on kill: raise a skeleton ally for 8s.`},
  hitshield:{t:'whenhit',txt:(c)=>`${c}% chance when hit: gain a shield.`},
  hitthorns:{t:'whenhit',txt:(c)=>`When hit: reflect ${Math.round(c*1.5)}% of the damage.`},
  nearfrost:{t:'near',txt:(c)=>`When an enemy gets close: frost burst (6s cooldown, ${Math.round(c*2)}% stronger per rank).`},
  allylow:{t:'allylow',txt:(c)=>`When an ally drops under 35%: heal them ${Math.round(10+c/2)}% (20s cooldown).`},
  castrush:{t:'oncast',txt:(c)=>`${c}% chance on ability cast: +30% attack speed for 3s.`},
};
const ITEM={
  blade:{label:'Weapon',txt:(r)=>`+${5*r}% damage, +${r}% crit`},
  armor:{label:'Armor',txt:(r)=>`+${6*r}% max HP, −${(1.5*r).toFixed(1)}% damage taken`},
  relic:{label:'Relic',txt:(r)=>`−${(2.5*r).toFixed(1)}% cooldowns, +${(2.5*r).toFixed(1)}% attack speed`},
  charm:{label:'Charm',txt:(r)=>`+${(1.5*r).toFixed(1)}% crit, +${r} luck, +${3*r}% score`},
};
function strHash(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return h>>>0;}
function procFor(card){const h=strHash(card);if(h%100>=52)return null;const ks=Object.keys(PROCS);return ks[(h>>>8)%ks.length];}
const procChance=r=>Math.round(6+2.2*r);
function maxTitle(card,arch){const t=(MAXNAME[arch]||{titles:['Ascendant']}).titles;return t[strHash(card)%t.length];}
function shortCard(c){return c.split(' // ')[0];}
function sname(hk,card){const d=DATA.heroes.find(h=>h.key===hk);const s=d&&d.spells.find(x=>x.card===card);return s&&s.name?s.name:shortCard(card);}

// ======================================================================= HERO STATS
function heroDef(key){return DATA.heroes.find(h=>h.key===key);}
// Abilities (spells, passives, signatures, level-up picks) are switched off while Kyle rebuilds them from scratch.
const ABILITIES_OFF=true;
// Lanes: feet rows units can stand on (190 = the original ground). Units drift between them so they can pass each other.
const LANES=[188,194,200,206,212],LANE_SPD=26;
// 0.12.14 (Kyle) obstacles: rocks, stumps, bushes, a dead tree and a big log lying diagonally across two lanes. Not many, a bit random.
//   Units walk around them (lane change). Tall ones (blk > 0, in hitbox units like body heights) stop shots that fly low enough.
//   Never more than 2 lanes blocked near each other at once, so there's always a way around.
const OBST={"rock_moss":{"x":0,"y":33,"fw":44,"fh":36,"lanes":1,"blk":34,"foot":[[-7.98,7.98]],"prof":[10,12,13,20,23,24,25,27,29,31,33,34,34,34,33,33,31,26,20,13,12,12]},"rock_pile":{"x":46,"y":39,"fw":32,"fh":30,"lanes":1,"blk":26,"foot":[[-5.7,5.7]],"prof":[5,15,19,22,23,25,27,28,28,28,27,25,22,18,8,7]},"rock_crack":{"x":80,"y":35,"fw":32,"fh":34,"lanes":1,"blk":32,"foot":[[-5.7,5.7]],"prof":[13,17,21,24,26,28,30,31,32,32,32,31,29,26,23,18]},"rock_swirl":{"x":114,"y":37,"fw":30,"fh":32,"lanes":1,"blk":30,"foot":[[-5.32,5.32]],"prof":[12,16,19,22,25,27,29,30,30,30,30,28,25,23,17]},"rock_dirt":{"x":146,"y":37,"fw":30,"fh":32,"lanes":1,"blk":30,"foot":[[-5.38,4.88]],"prof":[12,16,20,23,25,27,29,30,30,30,30,28,25,23,17]},"rock_crumble":{"x":178,"y":41,"fw":30,"fh":28,"lanes":1,"blk":24,"foot":[[-5.32,5.32]],"prof":[12,15,19,22,24,26,26,26,24,23,24,23,21,18,7]},"log_big":{"x":210,"y":35,"fw":80,"fh":34,"lanes":2,"blk":14,"foot":[[-19.5,6.5],[-10.0,20.0]],"prof":[11,16,20,21,21,21,22,22,22,22,23,22,23,24,24,25,24,25,27,26,27,27,27,28,28,29,29,30,30,30,31,31,32,32,32,33,33,32,32,28]},"trunk":{"x":292,"y":29,"fw":29,"fh":40,"lanes":1,"blk":40,"foot":[[-5.528,2.5279999999999996]],"prof":[9,10,14,19,34,35,37,38,37,38,38,38,35,35,0]},"stump":{"x":323,"y":37,"fw":18,"fh":32,"lanes":1,"blk":30,"foot":[[-3.16,2.16]],"prof":[20,27,30,30,30,30,30,29,28]},"bush_a":{"x":343,"y":49,"fw":22,"fh":20,"lanes":1,"blk":0,"foot":[[-3.04,3.04]],"prof":[13,15,15,17,18,18,17,15,17,18,18]},"bush_b":{"x":367,"y":47,"fw":23,"fh":22,"lanes":1,"blk":0,"foot":[[-3.7199999999999998,3.12]],"prof":[11,16,20,20,20,20,20,18,19,19,17,0]},"deadtree":{"x":392,"y":0,"fw":43,"fh":69,"lanes":1,"blk":52,"foot":[[-9.12,-2.2800000000000002]],"prof":[10,11,11,12,16,23,24,45,48,51,64,65,62,67,67,64,60,62,65,66,67,0]},"city_crate":{"x":0,"y":22,"fw":30,"fh":32,"lanes":1,"blk":25,"foot":[[-5.4,5.4]],"prof":[25,27,27,27,27,27,27,27,27,27,27,27,27,27,26],"img":"cityob","open":1},"city_crate_tall":{"x":62,"y":16,"fw":26,"fh":38,"lanes":1,"blk":31,"foot":[[-4.68,4.68]],"prof":[31,33,33,33,33,33,33,33,33,33,33,33,32],"img":"cityob","open":1},"city_crate_stack":{"x":116,"y":0,"fw":40,"fh":54,"lanes":1,"blk":43,"foot":[[-7.2,7.2]],"prof":[0,43,45,45,45,45,45,45,45,45,45,45,45,45,44,25,25,25,25,24],"img":"cityob","open":1},"city_lootbox":{"x":198,"y":32,"fw":32,"fh":22,"lanes":1,"blk":15,"foot":[[-5.76,5.76]],"prof":[17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17],"img":"cityob","open":1},"city_moss_a":{"x":264,"y":39,"fw":44,"fh":15,"lanes":1,"blk":0,"foot":[[-7.92,7.92]],"prof":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],"img":"cityob","flat":1},"city_moss_b":{"x":310,"y":41,"fw":32,"fh":13,"lanes":1,"blk":0,"foot":[[-5.76,5.76]],"prof":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],"img":"cityob","flat":1},"city_moss_c":{"x":344,"y":37,"fw":58,"fh":17,"lanes":1,"blk":0,"foot":[[-10.44,10.44]],"prof":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],"img":"cityob","flat":1},"city_front":{"x":0,"y":0,"fw":2,"fh":2,"lanes":1,"blk":0,"foot":[[-7,7]],"prof":[0],"flat":1,"front":1},"city_pillar":{"x":0,"y":0,"fw":8,"fh":2,"lanes":1,"blk":0,"foot":[[-1.2,1.2]],"prof":[0],"pillar":1,"pass":1}};
const CARS={"car_hatch":{"x":0,"y":8,"fw":110,"fh":40,"lanes":2,"blk":32,"foot":[[-25.3,25.3],[-25.3,25.3]],"img":"cars","prof":[0,0,1,1,12,20,20,21,21,22,22,22,23,23,23,24,27,28,30,33,34,35,35,36,37,37,37,37,37,38,38,39,39,38,38,38,38,37,37,36,36,36,35,34,32,30,28,26,23,13,3,2,1,0,0],"lights":{"head":[16.1,20.3],"tail":[92.2,20.8]}},"car_van":{"x":112,"y":0,"fw":141,"fh":48,"lanes":2,"blk":38,"foot":[[-32.4,32.4],[-32.4,32.4]],"img":"cars","prof":[2,3,5,5,6,7,10,25,26,27,27,28,29,30,35,41,43,43,43,44,44,44,44,45,46,46,47,47,46,46,45,45,44,45,45,45,45,46,46,46,46,46,45,45,45,45,45,45,45,44,44,45,45,45,45,45,44,43,35,33,12,6,6,6,4,4,1,0,0,0,0],"lights":{"head":[23.7,25.7],"tail":[113.0,24.0]}},"car_sedan":{"x":255,"y":6,"fw":94,"fh":42,"lanes":2,"blk":34,"foot":[[-21.6,21.6],[-21.6,21.6]],"img":"cars","prof":[20,22,23,24,25,25,26,26,26,27,27,29,32,34,38,39,39,40,40,40,41,41,41,41,41,41,41,41,41,41,41,41,41,40,40,40,40,39,34,31,29,29,28,28,28,28,22],"lights":{"head":[5.7,23.3],"tail":[90.0,21.0]}},"car_coupe":{"x":351,"y":12,"fw":129,"fh":36,"lanes":2,"blk":29,"foot":[[-29.7,29.7],[-29.7,29.7]],"img":"cars","prof":[1,1,2,2,3,3,1,3,3,14,21,22,22,20,21,23,24,23,24,25,25,27,27,29,30,32,33,33,33,34,35,35,33,33,33,33,33,32,33,33,33,32,31,30,29,28,27,26,25,25,25,25,20,3,3,4,3,2,2,1,1,1,1,1,1],"lights":{"head":[28.1,20.1],"tail":[101.0,18.0]}},"car_muscle":{"x":482,"y":10,"fw":129,"fh":38,"lanes":2,"blk":30,"foot":[[-29.7,29.7],[-29.7,29.7]],"img":"cars","prof":[3,3,3,1,2,2,4,4,8,17,21,22,23,23,24,24,25,26,26,26,26,25,29,30,30,32,32,34,35,35,37,35,36,37,35,35,35,36,37,36,35,35,35,35,35,35,35,33,33,31,30,30,30,29,28,27,26,23,19,3,2,2,1,1,1],"lights":{"head":[25.0,20.8],"tail":[110.2,20.1]}},"car_ambulance":{"x":613,"y":0,"fw":141,"fh":48,"lanes":2,"blk":38,"foot":[[-32.4,32.4],[-32.4,32.4]],"img":"cars","prof":[2,3,5,5,6,7,10,25,26,27,27,28,29,30,35,41,43,45,45,45,45,45,45,45,46,46,47,47,46,46,45,45,44,45,45,45,45,46,46,46,46,46,45,45,45,45,45,45,45,44,44,45,45,45,45,45,44,43,35,33,12,6,6,6,4,4,1,0,0,0,0],"lights":{"head":[23.6,25.5],"tail":[110.1,24.8]}},"car_vw":{"x":833,"y":0,"fw":102,"fh":62,"lanes":2,"blk":49.0,"foot":[[-23.5,23.5],[-23.5,23.5]],"img":"cars","lights":{"head":[17.9,41.2],"tail":[86.4,30.8]},"prof":[0.0,0.0,1.4,1.4,1.4,16.8,28.0,35.0,35.0,40.6,39.2,39.2,40.6,42.0,42.0,42.0,42.0,42.0,42.0,42.0,51.8,53.2,53.2,60.2,57.4,57.4,53.2,57.4,57.4,57.4,49.0,50.4,50.4,50.4,40.6,40.6,40.6,40.6,40.6,40.6,40.6,40.6,37.8,37.8,35.0,11.2,11.2,1.4,4.2,0.0,0.0,0.0]}};/* 0.12.184 (Kyle): the overgrown VW bus scaled up 1.4x (it looked like a toy next to the other cars) */Object.assign(OBST,CARS);   // 0.12.29 broken-down cars (Kyle's art), real-car sized, smooth edges, 2 lanes, tall
const OBST_POOL=[['car_ambulance',.5],['car_muscle',1.4],['car_hatch',1.5],['car_van',1.2],['car_sedan',1.5],['car_coupe',1.4],['rock_moss',3],['rock_pile',3],['rock_crack',3],['rock_swirl',2],['rock_dirt',3],['rock_crumble',3],['log_big',2],['trunk',2],['stump',3],['bush_a',2],['bush_b',2],['deadtree',1],['city_crate',1.5],['city_crate_tall',1.1],['city_crate_stack',.8],['city_lootbox',.6],['city_moss_a',4.4],['city_moss_b',4.4],['city_moss_c',2.2]];   /* 0.12.119 (Kyle): downtown gets crates, loot boxes and moss patches instead of rocks and logs */
const SEARCHABLE=/^rock_|^log_|^stump|^trunk|^bush|^deadtree|^city_moss/;const CONTAINER=/^car_|^city_crate|^city_lootbox|^city_front/;const ALARMABLE=/^car_|^city_front/;const SEARCH_RE={herbalist:SEARCHABLE,scavenger:CONTAINER},SEARCH_T={herbalist:1.5,scavenger:2};   // 0.12.28 Herbalist searches these (foliage too)
const GROUND_FX=new Set(['corpse','stuck','thorn','poof','boom','quake','mend','spark','blood','splat','scorch','ring']);
// Units are drawn at half size (the world reads bigger); heights for aiming/hitboxes are in 'ruler units' = full-size sprite pixels
const UNIT_SCALE=.5;
// ---- Aiming (Kyle): a shot's height above the target's feet, in ruler units:
//   50% 20-35, 35% 36-40, 10% 41-50, 5% 51-70. Accuracy (0-100) shifts weight from the wild bands into the first band.
//   The same accuracy also decides how far side-to-side (in lanes) an area spell lands from the lane it was aimed at.
// Accuracy has steep diminishing returns: it takes a lot of it before shots almost always land in the right area.
//   tighten = 0.95 x (1 - e^(-accuracy/90)):  20 -> 19%,  50 -> 41%,  100 -> 64%,  150 -> 77%,  200 -> 85%,  300 -> 92%
function accTighten(acc){return .95*(1-Math.exp(-Math.max(0,acc||0)/90));}
function aimBands(acc){const m=accTighten(acc);const p4=5*(1-m),p3=10*(1-m),p2=35*(1-m*.85);return [[100-p2-p3-p4,20,35],[p2,36,40],[p3,41,50],[p4,51,70]];}
function rollAimHeight(acc,rng){let r=rng()*100;for(const [p,lo,hi] of aimBands(acc)){if(r<p)return lo+rng()*(hi-lo);r-=p;}return 30;}
// Shooting at fliers uses its own, tighter table aimed at the flier's body (ruler units above/below its centre, either side):
//   70% within 0-4, 20% 5-8, 10% 9-14. Accuracy trims the wide bands the same way.
function airBands(acc){const m=accTighten(acc);const p3=10*(1-m),p2=20*(1-m*.85);return [[100-p2-p3,0,4],[p2,5,8],[p3,9,14]];}
function rollAirAim(acc,rng,centre){let r=rng()*100;for(const [p,lo,hi] of airBands(acc)){if(r<p)return centre+(rng()<.5?-1:1)*(lo+rng()*(hi-lo));r-=p;}return centre;}
function rollLaneOffset(acc,rng){const m=accTighten(acc);const off2=10*(1-m),off1=30*(1-m),r=rng()*100;if(r<off2)return rng()<.5?-2:2;if(r<off2+off1)return rng()<.5?-1:1;return 0;}
// hitboxes, ruler units: w = width, h = height above the feet
const HITBOX={bat:{w:30,h:14},zombie:{w:16,h:46},werewolf:{w:30,h:36}};   // werewolf h is before his 0.77 draw scale (~28 tall walking)
// 0.11: heroes have bodies too. Every non-boss unit has a hitbox about its own size (ruler units). Per-hero overrides go in HERO_HB.
const HERO_HITBOX={w:20,h:46},HERO_HB={cheez:{w:18,h:46},edward:{w:18,h:46},knight:{w:22,h:46},carcher:{w:16,h:40},csorc:{w:16,h:40},soldier:{w:18,h:46},shoshi:{w:18,h:44},eng:{w:20,h:46},jp:{w:20,h:46},dog:{w:16,h:22},cultist:{w:14,h:36},robot:{w:23,h:52},lumberjack:{w:20,h:46},druid:{w:18,h:46},archer:{w:20,h:46},flannel:{w:20,h:46},flannel_pal:{w:18,h:42}};   // Flannel_Man: full-detail art drawn at normal humanoid size
function hbOf(u){return u&&u.key?(HERO_HB[u.key]||HERO_HITBOX):(u&&HITBOX[u.type])||{w:16,h:44};}
function depthHalf(hb){return Math.max(1.5,hb.w*.12);}   // how much lane depth (px, top view) a body fills either side of its feet
// ---- 0.11 Aiming reticle (Kyle): when a ranged unit picks a target, a 'shoot box' is laid over the target where it stands.
//   Height: the box is 3x the target's height. Its bottom starts near the target's FEET when close, its WAIST at medium range and
//   its CHEST when far (40-tall target: close 5-125, medium 20-140, far 30-150). Shots bunch toward the bottom of the box.
//   Width (top view, across the lanes): centred on the target, one target-width either side, bunched in the middle.
//   A shot that misses keeps flying and hits whatever hitbox it passes through (friend of the target or not). pierce = extra bodies it can go through.
const AIM_RANGE={close:40,far:170};   // px between shooter and target
const AIM_POINTS={feet:.125,waist:.5,chest:.75};   // fractions of the target's height
const AIM_SHAPE={bunch:4};   // higher = shots bunch harder toward the bottom of the box (tuning knob)
// ---- 0.12.2 Aim boxes (Kyle): every target has 3 stacked boxes, measured in ruler units above its feet (already at drawn size).
//   A shot first rolls WHICH box it goes to (by the box %), then a random height inside that box.
//   Accuracy: each 1 point slides 0.25% from TOP -> BOTTOM and 0.25% from BOTTOM -> MIDDLE (so 10 accuracy on a zombie:
//   top 40 -> 37.5, bottom 50 stays 50, middle 10 -> 12.5). Negative accuracy (shooting on the move) slides it back the other way.
//   Shapes that change (the werewolf rearing up to swipe) get a second set of boxes for that pose.
const AIM_BOXES={
  zombie:  {top:[49,85,40],mid:[28,49,10],bot:[0,28,50]},            // Kyle's numbers: [low, high, %]
  werewolf:{top:[24,44,40],mid:[13,24,40],bot:[0,13,20],             // walking: low and long
            tall:{top:[35,54,30],mid:[15,35,40],bot:[0,15,30]}},     // reared up mid-attack
};
const AIM_STEP=.25;
// ---- 0.12.8 Poison (Kyle): ONE shared stack per target for every poison effect. Each stack deals 3% of the target's max HP
//   every 1.5s; no max stacks. Adding any stack resets the timer for the whole stack to 7.5s. Undead are immune.
const POISON={pct:.03,tick:1.5,dur:7.5};
function isUndead(e){return !!((e.E&&e.E.undead)||(e.B&&e.B.undead)||(CFG.bosses[e.type]&&CFG.bosses[e.type].undead));}
// ---- 0.12.4 Headshots (Kyle): a shot that hits a body inside its MIDDLE box (the head box from the aim boxes, current pose) is a
//   headshot: extra damage that stacks with crits (both multiply). Melee can't headshot.
const HEADSHOT={mul:1.5};
function isHead(tg,h){const B=aimBoxesOf(tg);return h>=B.mid[0]&&h<=B.mid[1];}   // % moved per accuracy point
function aimPose(tg){const B=AIM_BOXES[tg&&tg.type];if(!B)return null;
  if(B.tall&&tg.anim===1&&tg.animT>0&&tg.E){const f=1-tg.animT/(tg.E.animAtk||.3);if(f>.12&&f<.62)return B.tall;}return B;}
function aimBoxesOf(tg){const B=aimPose(tg);if(B){const s=tg&&tg.E&&tg.E.aimScale;if(!s)return B;const S=a=>[a[0]*s,a[1]*s,a[2]];return {top:S(B.top),mid:S(B.mid),bot:S(B.bot)};}
  const h=hbOf(tg).h*((tg&&tg.E&&tg.E.scale)||1);   // anyone without their own boxes (heroes too) uses the zombie's shape scaled to their height
  return {top:[1.065*h,1.85*h,40],mid:[.61*h,1.065*h,10],bot:[0,.61*h,50]};}
function aimOdds(B,acc){let t=B.top[2],b=B.bot[2],m=B.mid[2];const k=AIM_STEP*(acc||0);
  if(k>=0){const a=Math.min(t,k);t-=a;b+=a;const c=Math.min(b,k);b-=c;m+=c;}
  else{const a=Math.min(m,-k);m-=a;b+=a;const c=Math.min(b,-k);b-=c;t+=c;}
  return {top:t,mid:m,bot:b};}
function reticleBox(tg,box,rng){const B=aimBoxesOf(tg);const [lo,hi]=B[box];return {h:lo+rng()*(hi-lo),off:0,lo,hi,box};}   // sure shots: no accuracy roll
function reticle(acc,tg,dist,rng){const hb=hbOf(tg);const m=accTighten(acc);
  const B=aimBoxesOf(tg),P=aimOdds(B,acc);let r=rng()*(P.top+P.mid+P.bot),box;
  box=r<P.top?'top':r<P.top+P.mid?'mid':'bot';const [lo,hi]=B[box];
  const h=lo+rng()*(hi-lo);
  const side=((rng()+rng()+rng())/1.5-1)*(1-.5*m);   // -1..1 target-widths, bunched in the middle
  return {h,off:side*2*depthHalf(hb),lo:B.bot[0],hi:B.top[1],box,odds:P};}
// ---- 0.11 Facing: every hero and regular enemy can turn around, but only does so when its target is really behind it.
//   Turning takes TURN_T seconds and a unit can't swing or shoot while it turns. (Bosses will be rebuilt separately.)
const TURN_T=.22;
function faceToward(u,tx,dt){if(u.face==null)u.face=u.key?1:-1;const want=tx>u.x+2?1:tx<u.x-2?-1:u.face;
  if(want!==u.face){u.turnT=(u.turnT||0)+dt;if(u.turnT>=TURN_T){u.face=want;u.turnT=0;return true;}return false;}u.turnT=0;return true;}
// ---- 0.11 Energy: every unit has an energy pool (like rogue energy). 100 max, refills 10 per second for now (a formula later).
//   Abilities will spend it with spendEnergy(unit, cost) once they come back.
const ENERGY={max:u=>u.enMaxB||100,regen:u=>u.enRegenB||4.6};   // 0.12.169 (Kyle): base regen 4.6/s (was 5)
function regenEnergy(u,dt){const M=ENERGY.max(u);if(u.en==null)u.en=M;u.enMax=M;u.enTick=(u.enTick||0)+dt;while(u.enTick>=.5){u.enTick-=.5;u.en=Math.min(M,u.en+ENERGY.regen(u)*.5);}}   // ticks every 0.5s
function spendEnergy(u,c){c*=u.enCostM||1;if((u.en||0)<c)return false;u.en-=c;unstealth(u);if(u.capF&&u.capF.length&&CURG)capHook('cast',CURG,u,c);return true;}
let CURG=null;   /* 0.12.249 the game being stepped, for capstone cast hooks */   // 0.12.67: using an ability breaks stealth
/* 0.12.67 Stealth (generic, for any future stealth source too): u.stealthT>0 = zombies can't pick you as a target and lose you if they had you.
   Attacking or using an ability breaks it (and a short lockout stops the same smoke cloud from re-hiding you instantly). */
function onMeE(g,h){const x=g.heroX(h);return g.enemies.filter(e=>!e.dead&&!e.fly&&Math.abs(e.x-x)<16).length;}
function unstealth(u){if(u&&u.stealthT>0){u.stealthT=0;u.stealthCd=1.2;}}
// Werewolves come in a set number per stage (Kyle: 1 on stage 1, 2 on stage 3), spread along the stage instead of from the random pool
const CLUSTERS={count:8,first:3,last:[7,9],cap:7};
const CLUSTERS1={count:8,first:3,last:[8,9],cap:7};   /* 0.12.134 (Kyle): one fewer zombie in every stage-1 wave */   /* 0.12.104 (Kyle): stage 1 only: bigger waves, the last one most of all (other stages keep 3 -> 7-9) */   // 0.12.84 (Kyle: good waves of regular zombies): 8 waves, 3 at the start to 7-9 at the end   // Kyle: first cluster 2, last cluster 6-7
const WOLVES_PER_STAGE=n=>n<2?0:Math.min(8,2+Math.floor((n-2)*.5));   // 0.12.84 (Kyle): no werewolves on stage 1; 2 on stage 2, one more every 2 stages, max 8   // 0.12.65 (Kyle: too weak / too few): 3 on stage 1, one more about every 2 stages   // 0.12.13 (Kyle): 2 on stage 1, then one more about every 2-3 stages (2,2,2,3,3,4,4,4,5...)
const STRAYS_PER_STAGE=n=>3+Math.floor((n-1)/3);   // 0.12.84: one more lonely zombie per stage   // 0.12.13 (Kyle): a lonely zombie here or there between cluster waves
const ENEMY_BODY=9;   // px between a melee enemy's centre and the front hero's centre before reach is added
const HERO_FLAT_HP=0,HP_PER_STAMINA=5,HERO_DICE=[2,4],HERO_BASE_CRIT=.1;   // basic attack = 2d4; every hero starts at 10% crit
// ---- 0.12.3 real characters: every number comes straight from the character sheet Kyle fills out
const CHAR={
  // 0.12.110 (Kyle) SHOSHI: Kyle's cousin, his go-to tech guy. Smart, funny, always helps when asked. Works at Life360, wife and a 4-year-old girl.
  //   Purple hoodie, jeans, glasses and a headset; a machine pistol in 3-round bursts. A support gunner who keeps everyone running.
  shoshi:{name:'Shoshi',role:'Automatic_Pistol + Tech Support',flatHp:0,stamina:9,hpPerStamina:5,armorPts:5,dodge:.07,kbRes:.25,
    melee:{dice:[1,1],every:99,reach:0,kb:0,hitAt:.1},   // 0.12.110 (Kyle): no melee at all; up close he just keeps shooting
    ranged:{dice:[1,4],flat:0,every:.08,range:230,clip:20,reload:3.25,pellets:1,anim:.12,burst:1,burstGap:.45,tapAcc:15,sprayAcc:-6},   /* 0.12.110 (Kyle): TAP = single aimed shots (+15 acc, ~2/s); UNLOAD = full auto (-6 acc) on a big target or one mauling a hurt ally */   // 0.12.110 (Kyle): auto-switch Glock, 20-round mag (0.12.111, was 33), ~12 rounds/s. Aimed taps normally; he UNLOADS on a big or dangerous target
    acc:16,walkPenalty:8,crit:.08,critMul:1.75,luck:18,xp:0,run:2,turn:.2,enMax:100,enRegen:4.6,
    abilities:[
      // Always_Online (passive, one big one: Life360 + his phone): he always knows where his people are and everything is connected.
      //   - When an ally goes down he gets a PING: +40% move speed for 4s to get there, and he helps anyone up 30% faster.
      //   - Car alarms within 150px get shut off from his phone in 1.5s (he stops to tap it, no running over).
      //   - Allies within 100px of him get +5 accuracy (he's calling targets on the headset).
      {id:'online',name:'Always_Online',passive:1,move:.4,dur:4,rev:.3,r:150,T:1.5,auraR:100,auraAcc:5},
      // Ctrl_Z: UNDO. IF an ally within 90px lost 25%+ of their max HP in the last 3s THEN he undoes it: they get all of it back. 30 energy, 20s.
      {id:'undo',name:'Ctrl_Z',en:34,cd:20,r:90,win:3,min:.25},
      // Turn_It_Off_And_On_Again: he "reboots" an ally within 70px: clears bleed, fear and slow, heals 8% and refreshes one of their cooldowns.
      //   IF an ally near me is bleeding/afraid/slowed, OR under 50% with an ability on cooldown THEN reboot them. 25 energy, 12s.
      {id:'reboot',name:'Turn_It_Off_And_On_Again',en:29,cd:12,r:70,heal:.08,under:.5},
      // Tech_Support (was Free_Trial): an INSTANT, no buff. Every cast cuts the remaining cooldowns of every ally within 100px (not his own) by 15% and gives each +5 energy.
      //   IF an ally near me has a cooldown running AND there's a fight near us THEN do it. 15 energy, 7s (0.12.116: 15% cut + 5 energy each).
      {id:'trial',name:'Tech_Support',en:17,cd:7,r:100,cut:.15,energy:5},   /* 0.12.116 (Kyle): 15% cut, 7s, 15 energy; little bonus: +5 energy to each ally (he pushed an update) */   /* 0.12.114 (Kyle): every cast cuts the remaining cooldowns of every ally near him (not his own) by 20%, plus 3s of +10% damage. 12 energy, 6s: he keeps it going */
      // Dad_Mode: IF an ally within 90px is under 40% with 2+ zombies on them THEN he plants himself next to them: 40% less damage for 5s,
      //   the ally gets a shield worth 20% of their max HP, and zombies on them get shoved back. 30 energy, 18s.
      {id:'dad',name:'Dad_Mode',en:34,cd:18,r:90,dur:5,dr:.4,shield:.2,under:.4,kb:30}]},
  // 0.12.180 (Kyle; Claude picked the crimson knight) Crimson_Knight (CraftPix free knight pack, Knight_3): full crimson plate, sword and kite shield. The team's wall.
  //   Shield_Wall: IF 3+ zombies are on him, or 2+ are mauling an ally under 45% within 40 THEN he plants his shield for 4s: 60% less damage, no knockback,
  //     and every zombie within 50 is taunted onto him. 40 energy, 16s.
  //   Crimson_Charge: IF 3+ zombies are lined up in one lane 25-90 ahead THEN he charges through the line (up to 95px): 2d6 to each and a big shove. 35 energy, 12s.
  //   Leap_Strike: IF a zombie is mauling an ally under 40% (or a Nemesis/boss is) 30-110 away THEN he leaps onto it: 3d6 and a 1s stun to it, 1d6 to anything beside it. 45 energy, 18s.
  //   Blood_Oath (passive): every kill heals him 3% of his max HP, and below half HP he hits 15% harder.
  knight:{name:'Crimson_Knight',role:'Sword & Shield Tank',combo:1,flatHp:0,stamina:12,hpPerStamina:5,armorPts:8,   /* 0.12.245 (Kyle): base armor 8 */dodge:.03,kbRes:.6,
    melee:{dice:[1,8],flat:1,every:1.15,reach:20,kb:20,hitAt:.2},
    acc:12,walkPenalty:4,crit:.08,critMul:1.75,luck:14,xp:0,run:2,turn:.2,enMax:100,enRegen:4.6,
    abilities:[
      {id:'oath',name:'Blood_Oath',passive:1,heal:.03,under:.5,dmg:.15,regen:.2,regR:125/3},   /* 0.12.238: +0.20 HP/s per zombie within 125px */
      {id:'wall',name:'Shield_Wall',en:46,cd:16,dur:4,dr:.6,r:50},
      {id:'charge',name:'Crimson_Charge',en:40,cd:12,min:25,max:90,dist:95,dice:[2,6],kb:40,spd:220},
      {id:'kleap',name:'Leap_Strike',en:52,cd:13,min:30,max:110,dice:[3,6],flat:4,   /* 0.12.202 (Kyle): +4 damage, 13s (was 18s), used more often */splash:[1,6],stun:1,T:.6},
      // 0.12.195 Shield_Bash: slams his shield into the zombie in front: 1d6 and a 1.5s stun (bosses 0.5s). It interrupts a Screamer's shriek and a Skeleton_Archer's draw. 23 energy, 8s.
      {id:'bash',name:'Shield_Bash',en:23,cd:8,reach:20,dice:[1,6],stun:1.5}]},
  // 0.12.178 (Kyle) Chibi_Archer (CraftPix chibi pack, the Archer): a little hooded archer. Long-range bow, light on her feet.
  //   Piercing_Shot: IF 3+ zombies are lined up ahead in one lane THEN a heavy arrow goes through all of them (up to 5): 2d6 each. 35 energy, 10s.
  //   Tumble: IF a zombie gets right on her THEN she hops back about 45px and looses an arrow mid-air. 25 energy, 12s.
  //   Light_Feet (passive): +12% dodge and she moves quicker than most.
  carcher:{name:'Chibi_Archer',role:'Bow + Tumble',flatHp:0,stamina:8,hpPerStamina:5,armorPts:3,dodge:.12,kbRes:.15,
    melee:{dice:[1,4],every:1.0,reach:12,kb:18,hitAt:.2},   // a quick kick with the bow
    ranged:{dice:[1,6],flat:2,every:1.15,range:260,clip:0,reload:0,pellets:1,anim:.9,releaseAt:.55},   // draw, hold, loose (her Shot_1 row)
    acc:20,walkPenalty:10,crit:.15,critMul:2,luck:20,xp:0,run:2,turn:.18,enMax:100,enRegen:4.6,
    abilities:[
      {id:'lightfeet',name:'Light_Feet',passive:1},
      {id:'pierce',name:'Piercing_Shot',en:40,cd:10,n:5,dice:[2,6],lineN:3},
      {id:'tumble',name:'Tumble',en:29,cd:12,dist:45,T:.6},
      // 0.12.195 Snare_Arrow: pins one zombie in place for 2.5s (1d4) and slows anything beside it 30% for 2s. 29 energy, 12s.
      {id:'snare',name:'Snare_Arrow',en:29,cd:12,root:2.5,r:14,slow:.3,slowT:2,dice:[1,4]},
      // 0.12.195 Hunter's_Mark: marks one zombie for 6s: everyone hits it 25% harder. 23 energy, 15s.
      {id:'hmark',name:'Hunters_Mark',en:23,cd:15,dur:6,amp:.25}]},
  // 0.12.178 (Kyle) Chibi_Sorcerer (CraftPix chibi pack, the Wizard): dark-haired, dark cloak, yellow lightning.
  //   Chain_Lightning: IF 2+ zombies are within 150 THEN a bolt hits the nearest and jumps to 3 more within 45 of each other: 2d6, 20% less each jump, and a 0.4s stun. 40 energy, 11s.
  //   Thunderclap: IF 3+ zombies are bunched 30-160 out THEN he charges up and calls lightning down on them: 3d6 in a 60-wide blast, 1s stun (bosses 0.4s). 45 energy, 16s.
  //   Arcane_Flow (passive): +3 energy every time he kills something.
  csorc:{name:'Chibi_Sorcerer',role:'Lightning + Staff',flatHp:0,stamina:8,hpPerStamina:5,armorPts:2,dodge:.06,kbRes:.15,
    melee:{dice:[1,4],every:1.2,reach:13,kb:16,hitAt:.2},   // staff bonk
    ranged:{dice:[1,8],flat:1,every:1.4,range:220,clip:0,reload:0,pellets:1,anim:.5,releaseAt:.3},   // a spark of lightning (his Attack_2 row)
    acc:18,walkPenalty:6,crit:.08,critMul:1.8,luck:18,xp:0,run:2,turn:.2,enMax:100,enRegen:4.6,
    abilities:[
      {id:'arcflow',name:'Arcane_Flow',passive:1,en:3},
      {id:'chain',name:'Chain_Lightning',en:46,cd:11,r:150,jump:45,n:4,dice:[2,6],fall:.2,stun:.4},
      {id:'thunder',name:'Thunderclap',en:52,cd:16,min:30,max:160,r:30,dice:[3,6],stun:1,T:.9},
      // 0.12.195 Static_Shield: wraps an ally (or himself) within 60 in crackling static for 6s: a shield worth 20% of their max HP, and anything that hits them gets zapped for 1d4. 40 energy, 14s.
      {id:'static',name:'Static_Shield',en:40,cd:14,r:60,shield:.2,dur:6,zap:[1,4]},
      // 0.12.195 Overcharge: his next 3 sparks hit 50% harder and each jumps to a second zombie within 40 for half. 29 energy, 12s.
      {id:'overcharge',name:'Overcharge',en:29,cd:12,n:3,mul:1.5,jump:40}]},
  // 0.12.175 (Kyle) the Soldier (CraftPix freebie art): helmet, balaclava, plate carrier and an assault rifle. Steady mid-range shooter with a rifle-butt up close.
  //   Frag_Grenade: he pulls a pin and lobs it 40-130 out onto a bunch of zombies; it lands, ticks for 0.5s and blows: 4d6 in a 30-wide blast
  //   (full in the middle, 60% at the edge) and everything caught is STUNNED for 1.5s. He won't throw it where an ally would be caught.
  //   Battle_Hardened (passive): below half HP he takes 15% less damage and reloads 25% faster.
  // 0.12.207 (Kyle) EDWARD (Eddie): a good friend who's stuck around forever. Works two jobs (construction, and the files at a casino), a dad,
  //   charismatic, funny, loyal to a fault, the one you can rely on, smart, likes a good time, big anime and movie guy. Short black fro, glasses, beard.
  //   Nail_Gun: 1d4 every 0.55s (0.12.226, was 1d6+1), 18 nails, 2.6s reload. Up close he smacks them with it (1d6+1).
  //   Toolbox_Toss: IF the biggest threat (a Nemesis/boss/fireman, or the zombie on the most-hurt friend) is 40-140 out THEN he heaves his toolbox: 2d8 and a 1.2s stun, 1d4 to anything beside it. 38 energy, 14s.
  //   Power_of_Friendship (0.12.244 more triggers: a friend down, a boss/Nemesis near, he's under 40% with 2+ on him, Chutzpah pulling 3+, all three in the banner, a friend just helped up): IF 2+ friends are under 60% (or one is under 35%, or 4+ zombies are on the team) THEN he powers up, anime style: 6s of +30% damage and attack speed for him, +10% damage for friends within 300px. 45 energy, 22s.
  //   Loyal_to_a_Fault (passive): a friend within 480px under 30% HP has 40% of every hit they take land on Edward instead, +3 energy for each. Loyal to a fault: he keeps doing it even when he's low.
  //   AI (sliders): IF a friend is under 35% and he's over 360px away (and he's above 25%) THEN he walks over to stand with them (Pack Hunter hurries; Ally Awareness picks the worst-off friend, else the nearest).
  //     Toolbox_Toss: Ally Awareness looks at the zombie on a hurt friend first, otherwise the big threat first; Squander throws at anything. Nail_Strip: 3+ in a lane (Blind Aggression 2, Preserve 4).
  //     Power_of_Friendship: 2+ friends under 60%, one under 35%, or 4+ zombies on the team (Preserve: a dire friend AND 2 hurt, or 6+ on the team).
    //   (0.12.210) one passive only: Loyal_to_a_Fault also gives energy back for every hit he takes for a friend; his two-jobs stamina is just his +20% base energy regen.
  // 0.12.234 (Kyle) CHEEZ (Shawn): drunken techno-samurai (Kamigawa: Neon Dynasty vibe). Casino tech (fixes the error-coded machines), part Japanese and part Indian
  //   and proud of both, anime/video-game nerd who hits game cons, witty teaser (never mean), anti-fascist, never misses game night and often hosts it. Yells "DICE BOYS!".
  //   Beam_Katana (basic melee): 1d8+1 every 0.9s, reach 18.
  //   Iaijutsu: IF 2+ zombies are lined up in his lane within 360px, or a Screamer/archer/Nemesis is in reach, THEN he sheathes, holds a beat (0.35s), and
  //     draw-slashes in a blinding dash through the line (up to 360px): 2d8 to each, the first one a guaranteed crit. 30 energy, 9s.
  //   Sake_Break: IF 3+ zombies are within 180px of him, or a boss/Nemesis is close, THEN a swig of neon sake: 10s Drunken_Style: +25% attack speed, +15% dodge, -10 accuracy,
  //     and now and then a hiccup stagger (0.3s). 40 energy, 10s. Preserve saves it for 4+ or a boss.
  //   Error_Code_Fix (his casino job): IF a friend within 450px is under 50% (Ally Awareness: 60%) or bleeding/slowed/stunned THEN REBOOT: heal 20% of their max HP and clear it;
  //     ELSE IF a Fireman/Nemesis is within 180px THEN OVERRIDE it: 2s stun and its armor halved for 6s. 35 energy, 20s.
  //   Dice-Boys_Banner: IF 2+ friends are within 300px of him and a fight is on (3+ zombies on screen) THEN he plants a waving neon DICE BOYS banner: for 8s friends within
  //     300px of it hit 10% harder and get +1 energy a second; if all three heroes are by it everyone shouts DICE BOYS! (+5% crit for the 8s). 40 energy, 25s.
  //   Perfect_Attendance (passive): never misses game night: once a stage, a hit that would drop him leaves him at 1 HP and untouchable for 2s.
  cheez:{name:'Cheez',role:'Beam Katana + Sake',flatHp:0,stamina:10,hpPerStamina:5,armorPts:6,dodge:.07,kbRes:.3,
    melee:{dice:[1,8],flat:1,every:.9,reach:21,kb:16,hitAt:.15},   /* 0.12.238 (Kyle): longer beam blade, reach 21 (was 18) */
    acc:14,walkPenalty:4,crit:.1,critMul:1.9,luck:15,xp:0,run:2,turn:.2,enMax:100,enRegen:5,
    abilities:[
      {id:'attend',name:'Perfect_Attendance',passive:1,hold:2},
      {id:'iai',name:'Iaijutsu',en:30,cd:9,range:140,dice:[2,8],hold:.25,spd:200},   /* 0.12.236: a wave, 600px/s for ~420px, one blink to it */
      {id:'sake',name:'Sake_Break',en:40,cd:10,dur:10,share:6,vul:.15,   /* 0.12.240 (Kyle): 10s on himself, 10s cd; a share lasts 6s (10s to a friend in the banner) */spd:.25,dodge:.15,acc:10,hic:.15},
      {id:'errfix',name:'Error_Code_Fix',en:35,cd:20,heal:.2,r:150,stun:2,arm:6},
      {id:'host',name:'Dice-Boys_Banner',en:40,cd:25,dur:8,r:100,dmg:.15,crit:.07,regen:.5}   /* 0.12.243 (Kyle): +15% dmg (was 10%), +0.5 energy/s (was 1), +7% crit (was 5%); all live while you stand in it */]},
  edward:{name:'Edward',role:'Nail_Gun + Toolbox',flatHp:0,stamina:10,hpPerStamina:5,armorPts:7,dodge:.05,kbRes:.35,
    melee:{dice:[1,6],flat:1,every:2.1,reach:14,kb:55,hitAt:.3},   /* 0.12.214 (Kyle): the nailer butt-strike is slow but sends them flying */
    ranged:{dice:[1,4],flat:0,every:.3,range:210,clip:18,   /* 0.12.244 (Kyle): a nail every 0.30s */   /* 0.12.226 (Kyle): 1d4 a nail; 0.12.227: every 0.45s, 3s reload */reload:3,pellets:1,anim:.3},
    acc:16,walkPenalty:0,crit:.09,critMul:1.8,luck:16,xp:0,run:2,turn:.2,enMax:100,enRegen:5.5,   /* 0.12.221 (Kyle): no accuracy lost on the move with the nail gun */
    abilities:[
      {id:'loyal',name:'Loyal_to_a_Fault',passive:1,under:.3,share:.4,r:160,en:3},
      {id:'toolbox',name:'Toolbox_Toss',en:38,cd:14,min:40,max:140,dice:[2,8],splash:[1,4],stun:1.2,throw:.6},
      {id:'nails',name:'Nail_Strip',en:35,cd:13,range:100,dice:[1,4],bleed:[6,3],T:.7,field:5,slow:.3},   /* 0.12.211 (Kyle) */
      {id:'chutz',name:'Chutzpah',en:34,cd:16,r:100,dur:3,dr:.3,per:.1,max:5},   /* 0.12.220 (Kyle) */
      {id:'friend',name:'Power_of_Friendship',en:45,cd:22,dur:6,dmg:.3,spd:.3,ally:.1,r:100}]},
  soldier:{name:'Soldier',role:'Machine_Gun + Frag_Grenade',flatHp:0,stamina:10,hpPerStamina:5,armorPts:8,dodge:.05,kbRes:.4,
    melee:{dice:[1,6],every:1.2,reach:15,kb:24,hitAt:.15},   // rifle-butt
    ranged:{dice:[1,2],flat:1,every:.15,range:240,clip:15,reload:7,pellets:1,anim:.15,burst:1,burstGap:.5,tapAcc:-3,sprayAcc:-15},   // 0.12.202 (Kyle) machine gun, hip-fired: 15-round mag, a round every 0.15s when he lets rip (big target or one on a hurt friend), otherwise slower taps; 1d2+1; 7s reload. Wild from the hip: much less accurate than Covering_Fire
    acc:17,walkPenalty:8,crit:.1,critMul:1.8,luck:16,xp:0,run:2,turn:.2,enMax:100,enRegen:4.6,
    abilities:[
      {id:'hardened',name:'Battle_Hardened',passive:1,under:.5,dr:.15,reload:.25},
      {id:'frag',name:'Frag_Grenade',en:40,cd:14,min:40,max:130,r:30,dice:[4,6],stun:1.5,fuse:.5,fly:.6},
      // 0.12.199 Smoke_Grenade: lobs a smoke canister (the pack's smoke cloud) 20-110 out: a 60-wide cloud for 6s. Zombies inside miss half their swings
      //   and move 25% slower; heroes inside are harder to hit. 40 energy, 16s.
      {id:'smokegren',name:'Smoke_Grenade',en:40,cd:16,min:0,max:100,r:30,dur:6.75,   /* 0.12.201 (Kyle): +0.75s */miss:.5,slow:.25,throw:.65,sprite:1,stealth:.3,rev:.25},   /* 0.12.199 (Kyle): up to 300 screen px; allies inside are unseen and revive 25% faster */
      // 0.12.199 Suppressing_Fire: plants and hoses one lane with his rifle (the pack's Shot_2 stance) for 1.6s: 10 rounds of 1d4, every zombie hit slowed 40% for 2s. 35 energy, 12s.
      {id:'suppress',name:'Covering_Fire',en:40,cd:12,T:1.8,n:9,dice:[1,4],flat:1,acc:18,slow:.4,slowT:2,range:220},   /* 0.12.202 (Kyle): now shouldered and aimed (+18 accuracy), 9 rounds of 1d4+1, and he picks off the zombies closest to his friends in that lane first */
      // 0.12.200 Ammo_Drop: drops an ammo crate (his Recharge animation) for 8s. Allies within 30 reload 50% faster and their shots hit 15% harder;
      //   each ally who steps right onto it gets one free full magazine, once per crate. 35 energy, 20s.
      {id:'ammodrop',name:'Ammo_Drop',en:40,cd:20,dur:8,r:30,reload:.5,dmg:.15}]},
  // 0.12.66 (Kyle) JP: big orange hoodie, dark jeans, Kar98 + a real sword and a homemade wooden shield. A good guy who loves picking on people,
  //   games all day and smokes a lot of weed (not a drinker). Plays sword-fight with his kids. Mixes jokey and sensible.
  jp:{name:'JP',role:'Kar98 + Sword & Board',flatHp:0,stamina:9,hpPerStamina:5,armorPts:7,dodge:.05,kbRes:.35,
    melee:{dice:[1,8],every:1.1,reach:18,kb:18,hitAt:.15},                    // sword: medium speed, low-medium damage
    ranged:{dice:[1,20],flat:0,every:2.25,range:290,   /* 0.12.201 (Kyle): 1d20, no flats */clip:1,reload:2.25,pellets:1,quietReload:1,aimT:.25},   // 0.12.163 (Kyle): Kar98 1d8+4 with a 0.25s aim wind-up before the shot (was 4d4-2, no wind-up); 2.25s; he doesn't call out reloads
    acc:20,walkPenalty:12,crit:.12,critMul:2,luck:18,xp:0,run:2,turn:.22,enMax:100,enRegen:4.6,
    blockCh:.2,   // 0.12.79 Sword & Board (built into his melee kit): 20% to BLOCK a hit outright with the homemade shield. Any unit with a shield gets blockCh.
    abilities:[
      // Toke_Break: 2s, he can keep walking but does nothing else, then he's HIGH for 30s and patched up 6%. No energy, 22s.
      //   IF I'm not high (or nearly down) AND nothing is within 45px THEN spark one up.
      {id:'toke',name:'Toke_Break',en:0,cd:22,dur:2,high:30,heal:.06},
      // Protect_the_Familia: IF an ally is under 55% with a zombie on them (or under 35%) within ~660px THEN rush to them, immune while rushing;
      //   on arrival we both get a shield worth 50% of my max HP for 5s. 0.12.93 (Kyle): Shield_Bash is baked in: he shoves the ally 75px toward
      //   the friend furthest left AND bashes the closest zombie 75px the other way for 2d4 (1s stun). 50 energy, 20s.
      {id:'familia',name:'Protect_the_Familia',en:57,cd:20,range:220,spd:120,shield:.5,shieldT:5,push:25,under:.55,bashDice:[2,4],bashPush:25,bashStun:1},
      // 0.12.93 No_Scope (replaces Shield_Bash): the gamer in him. A hip-fired Kar98 flick that punches through up to 3 zombies in a line
      //   for 3d6 each (+15% crit). IF 2+ zombies are lined up in front of me within 290px (or a big one) THEN no-scope it. 35 energy, 15s.
      {id:'noscope',name:'No_Scope',en:40,cd:15,dice:[3,6],pierce:3,range:290,crit:.15},   // 0.12.94: toned down (was 4d6, 30 energy, 10s)
      // Trash_Talk: he picks on the zombies (and his friends). Every zombie within 70px comes for HIM for 4s while he hides behind the shield
      //   (30% less damage); his friends laugh it off: +5% crit for 6s. IF 2+ zombies are on an ally near me THEN talk trash. 25 energy, 18s.
      {id:'trash',name:'Trash_Talk',en:34,cd:12,r:70,dur:4,dr:.3,crit:.05,critT:6},   // 0.12.79: 12s, and more reasons to use it
      // Wake_n_Bake (passive): HIGH = +10% dodge, 10% less damage taken, +1 energy/s, +10% sword speed. Sober (not high for 10s+) =
      //   -6 accuracy, -10% move and attack speed, and he gets grumpy.
      {id:'baked',name:'Wake_n_Bake',passive:1,dodge:.2,dr:.2,en:1,   /* 0.12.151 (Kyle): +1 energy a second (was 2) */mspd:.2,slide:4,soberAfter:10,acc:-6,slow:.1}]},   // 0.12.79: high bonuses doubled + slides 4 toward slasher
  flannel:{name:'Flannel_Man',role:'Rifle + Melee',flatHp:0,stamina:8,hpPerStamina:5,armorPts:5,dodge:.05,kbRes:.40,
    melee:{dice:[1,12],every:1.5,reach:20,kb:23,hitAt:.15},                 // crowbar: d12, swing every 1.5s, 20px reach, knockback 23/100
    ranged:{dice:[1,8],flat:0,every:1.75,range:250,clip:1,reload:1.75,pellets:1},   /* bolt-action rifle: d8, 1.75s between shots (0.12.38: -0.25s), reloads after every shot */
    acc:18,walkPenalty:12,crit:.12,critMul:2,luck:21,xp:0,run:2,turn:.22,enMax:100,enRegen:4.6,
    // abilities (Kyle). Aimed Shot: skips the accuracy roll and lands in the MIDDLE box, +5% crit chance, crits hit 2.5x.
    //   Damage = the rifle's dice + every flat damage bonus, so it grows with future flat-damage items/effects.
    //   Cost: 40 energy (8s of base regen) and 14s cooldown: a big hit you see a few times a stage, leaving room for more abilities.
    abilities:[{id:'aimed',name:'Aimed Shot',en:52,cd:14,cast:2,pierce:1,box:'mid',critAdd:.05,critMul:2.5},
      // Trip Bomb: 1s to crouch and set a nail bomb on a stake with a tripwire, a little ahead in his lane. It arms after 0.6s and
      //   blows the first time a ground enemy walks into the wire: CROSS-shaped area damage (36px each way along the lane, 2 lanes
      //   up and down across it; full in the middle, half at the ends), a hard shove away from the blast, and nails that make 50% of victims bleed. 30 energy, 20s cooldown, 1 out at a time.
      // Call Companion: 0.8s whistle. If she isn't out, she joins the fight; if she is, she's patched up for 7% of her max HP instead.
      // Set_Camp: he kneels, flicks a lighter and starts a campfire (1.8s). The fire doesn't block anything; every ally within 250 screen px
      //   (83 world px) gets COZY: +1% max HP and +2 energy every second. The fire has 5 life and can't be attacked, but each time Flannel_Man or
      //   his Traveling_Companion takes damage from an attack it loses 1; at 0 it breaks and dies out. 35 energy, 30s cooldown.
      // 0.12.63 (Kyle): the fire gives COZY to every ally within 400 screen px (133 world) and keeps refreshing it while they stay (see COZY).
      {id:'camp',name:'Set_Camp',en:46,cd:30,cast:1.8,life:5,radius:133},
      // Grit_Teeth (Kyle, 0.12.15): he sets his jaw and digs in: 60% less damage taken for 7s, and for that time his personality slides
      //   hard toward close fighting (Shooter->Slasher +6, Aggressive +3), so the behavior system walks him up into crowbar range. He
      //   shouts for the squishier allies to get behind him. IF hurt (under 60%) with something on him, OR 3+ enemies close, THEN use it. 30 energy, 22s cooldown.
      // 0.12.63 (Kyle) True_Grit (was Grit_Teeth): 15s CD, lasts 8s: 50% less damage taken, +25% move speed, and his Careful/Reckless and
      //   Sharpshooter/Brawler sliders go to 10 for the duration (all-in, up close). IF hurt with something on him, OR 3+ close, THEN use it.
      {id:'grit',name:'True_Grit',en:40,cd:15,dur:8,dr:.5,under:.6,move:.25},
      // 0.12.68 (Kyle) Elite_Survivors (passive, replaces Call Traveling_Companion): his partner starts every stage beside him; he has the
      //   Scavenger perk built in; and while they're within 150 screen px (50 world) of each other both get +10% dodge.
      {id:'elite',name:'Elite_Survivors',passive:1,r:50,dodge:.1},
      // 0.12.59 (Kyle) Proximity_Bomb: one bomb, same blast shape every way, three activations on one shared 10s cooldown:
      //   OVERHAND THROW: a big arc ~117-133px out (350-400 screen px); it blows the moment it lands: 4d4.
      //   CAREFUL ROLL: underhand ~25px out (75 screen px), then it rolls ~17-25px more (50-75 screen px). IF a zombie comes near while it rolls
      //     THEN it blows early for 3d4 AND the cooldown is cut in half; ELSE it stops, and a moment later ACTIVATES (red glow): then 6d4.
      //   SET IT UP: kneel ~3s and plant it further down the trail; a planted bomb is activated: 6d4.
      //   IF one of his bombs is left behind off screen (the party moved on) THEN the cooldown is cut in half.
      // 0.12.64 (Kyle's hard stats, screen px / 3 = world px): 40 energy, 10s.
      //   Trigger: 40px wide in its own lane (+-6.7), 20px wide one lane up and one down (+-3.3).
      //   Blast: 100px wide in its own lane (+-16.7), 40px wide one lane up/down (+-6.7).
      //   OVERHAND: 1s cast (can walk), lands exactly where he picks 300-450px (100-150) away, blows on impact: 2d4+6, lanes up/down 60px wide (+-10).
      //   UNDERHAND: 0.5s cast (can walk), lands 100px (33) ahead, rolls 50px (17), then 0.5s to truly activate (flashing).
      //     Tripped before that: 2d4+2 and 2s back on the cooldown. Activated: 2d4+6.
      //   PLACE: 3s kneeling (no moving), put 5px (1.7) in front, active at once: 6d4+2, blast +20px wide (+-20) and +10px in the side lanes (+-8.3).
      //   Left behind off screen: what's left of the cooldown is halved.
      {id:'trip',name:'Proximity_Bomb',en:46,cd:10,arm:0,trig:{w0:6.7,w1:3.3},blast:{w0:16.7,w1:6.7},
        hurl:{min:100,max:150,h:42,dur:.95,cast:1,dmg:[[2,4],6],w1:10},lob:{dist:33,h:7,dur:.55,roll:16.7,rollSpd:26,settle:.5,cast:.5,early:[[2,4],2],live:[[2,4],6],refund:2},
        place:{cast:3,off:1.7,dmg:[[6,4],2],w0:20,w1:8.3},kb:45,bleed:{chance:.5,dmg:12,dur:4},life:40}]},
};

// ---- 0.12.3 Inspiration Decks (Kyle): pick a player, then one of their decks. Each deck gives one small, unique bonus tied to
//   what that deck is best at. sl = slider moves (a move that would go below 0 or above 10 doesn't happen). Easy to retune here.
const INSP={   /* 0.12.82 (Kyle): every deck now gives exactly TWO things (a passive or perk, a stat, a starting stash, or a slider nudge), as unique as possible and
   tied to what the deck does best. A slider nudge only counts as one of the two when the other bonus is a particularly strong passive. */
 // Kyle
 'The Grim Throne':{o:'Kyle',why:'Kenrith\'s royal court: nobody haggles like royalty, and the throne always gets its due in the end',passive:'haggler',perk:'inevitable'},
 'Felothar':{o:'Kyle',why:'Walls of root and bark: the pod\'s top Survival, and the forest feeds whoever holds behind them',passive:'herbalist',mod:{armor:6}},
 'Modular Beatdown':{o:'Kyle',why:'Gilgamesh suits up from a pile of spare parts and hits the hardest in the pod',passive:'resourceful',mod:{meleeDmg:20}},
 'A Vile Smashing':{o:'Kyle',why:'Wheels: the most cards seen, and everyone else\'s hand ends up in yours',passive:'pickpocket',mod:{xp:12}},
 'Truly Fantastic':{o:'Kyle',why:'The Thing: a walking pile of orange rock that nothing shoves, and the team\'s deep mana pool',passive:'mountain',mod:{enMax:24}},
 'Dice Boys Casino':{o:'Kyle',why:'Mr. House runs the casino: the house always has money, and the dice always seem to land his way',passive:'bankroll',perk:'superlucky'},
 'Tame Depala':{o:'Kyle',why:'Dwarf mechanics in plated rigs: hard to shove and they hit like a hammer',mod:{kbRes:20,meleeDmg:10}},
 "Life Swappin' Bounty Poppin'":{o:'Kyle',why:'Mathas puts bounties on the biggest threat and always gets paid',passive:'bounty',sl:{size:2}},
 'The Last of Us':{o:'Kyle',why:'Survivors who live off what they scrounge from the wrecks and slip every grab',passive:'scavenger',mod:{dodge:4}},
 'House on Haunted Hill':{o:'Kyle',why:'The house always sees you coming, and things that touch it get scared off',passive:'haunt',mod:{acc:6}},
 'Mothman Cometh!':{o:'Kyle',why:'A dark omen that is never quite where you hit, and never far behind',passive:'omen',sl:{lane:2}},
 'Ominous Weather':{o:'Kyle',why:'Isu\'s winter storms push everything back, and every storm fills the barrels',passive:'raincatch',mod:{kb:40}},   // 0.12.104: Rain Catcher instead of Sapper (Sapper stays on Cosmic Spider)   // 0.12.101 review: knockback 30 -> 40 (Sapper is situational)
 'Build a Scare':{o:'Kyle',why:'Illuna mutates into something bigger, stitched together from whatever is lying around, and stitches up whoever falls apart',perk:'medicine',mod:{stamina:2}},
 "Thunder's Decree":{o:'Kyle',why:'Zurgo only knows one way: forward, and faster every swing',passive:'onslaught',sl:{aggr:2}},
 // Cheez
 'Kykar, Zada & Feather':{o:'Cheez',why:'Wind\'s Fury: a flurry of cheap spells, one after another, from a flock that never sits still',mod:{cdr:15,move:8}},   // 0.12.100 (Kyle): 15% cooldown reduction, lighter second bonus
 'Double Dragons':{o:'Cheez',why:'Dragon fire, and two dragons means double the luck: every hoard they stumble on is a big one',perk:'superlucky',mod:{rangedDmg:16}},
 'Turtle Power':{o:'Cheez',why:'Shells and teamwork: when it gets bad, they pull in and wait it out',passive:'shell',mod:{armor:4}},
 'Korvold Eats Everything':{o:'Cheez',why:'Korvold feeds on what he kills, and eats (and drinks) everything they were carrying',passive:'devour',perk:'looter'},   // 0.12.104: Lucky Looter instead of a 3-food starting stash
 'Armed Robbery':{o:'Cheez',why:'Kotis steals from everyone, and his crew gets in and out before anyone notices',passive:'pickpocket',sl:{self:2}},
 'Blood Suckers':{o:'Cheez',why:'Lifelinking bats: the night always comes, and every bite they miss only makes the next one surer',perk:'inevitable',mod:{lifesteal:5}},
 'Mechanized Mayhem':{o:'Cheez',why:'Dr. Eggman strips wrecks for parts to overclock his guns',passive:'scavenger',mod:{rangedSpd:15}},
 // Leon
 'Family Matters':{o:'Leon',why:'Zinnia\'s copies look out for each other and bandage each other up',passive:'bodyguard',perk:'medicine'},
 'Thranduil':{o:'Leon',why:'Elven eyes and forest lore: knows every herb in the woods and never misses a shot',passive:'herbalist',mod:{acc:8}},
 'Primary Directive 2.0':{o:'Leon',why:'Optimus\'s rebuild: the Autobots patch themselves up from salvage, and a stack of big mana rocks keeps them charged',passive:'resourceful',mod:{enRegen:1}},
 'Cosmic Spider':{o:'Leon',why:'Spider-Sense and web shooters: his sense tingles near traps',passive:'webs',perk:'sapper'},
 // Eddie
 'Vivi':{o:'Eddie',why:'The Black Mage: his commander makes a pile of mana every turn and every spell hits harder',mod:{enRegen:1,rangedDmg:12}},   // 0.12.101 review: energy regen 1.5 -> 1 (was the strongest stat pair)
 'Bruce Banner':{o:'Eddie',why:'Hulk smash: the longer he runs at you, the harder the first punch lands, and he soaks a lot getting there',passive:'onslaught',mod:{stamina:2}},   // 0.12.101 review: Onslaught instead of +10% XP (more fun, on theme)
 'Cloud':{o:'Eddie',why:'Omnislash: a suited-up SOLDIER whose every big hit is a Limit Break',mod:{critMul:.3,crit:3}},
 'Kasla, the Broken Halo':{o:'Eddie',why:'Convoke: the whole angel army chips in, so everything at camp costs less, and she flies in fast',passive:'haggler',mod:{move:10}},
 'Master Splinter':{o:'Eddie',why:'A sewer rat knows where every scrap of food is, and his shuriken fly fast',passive:'forager',mod:{rangedSpd:15}},   // 0.12.104: Forager instead of Dark Omen (Omen stays on Mothman); shuriken speed 10 -> 15% to make up for it   // 0.12.101 review: Dark Omen (a sure dodge every 12s) instead of +4% dodge
 'Miles Morales':{o:'Eddie',why:'Spider-Man in the making: web shooters to slow them down, and he grows with every fight',passive:'webs',mod:{xp:8}},   // 0.12.101 review: Web Shooter instead of +6 Luck
 'Narset, Enlightened Master':{o:'Eddie',why:'A monk who turns every attack into free spells: her abilities come back 20% faster, with a little more energy to spend',mod:{cdr:20,enMax:10}},   // 0.12.98 (Kyle): cooldown reduction
};
const PLAYER_ICON={Kyle:'🎩',Cheez:'🧀',Leon:'🪼',Eddie:'♠'};
// what each character is like in a fight (shown when you hover them on the party screen)
// one line per ability for the party-screen hover boxes
const ABIL_DESC={
  autopistol:'Automatic_Pistol (basic attack) · 1d4 a round · 20-round mag · 3.25s reload. TAP: aimed single shots (+15 accuracy, about 2 a second). UNLOAD: full auto, about 12 a second (-6 accuracy), on big targets, on anything mauling a hurt ally, and now and then for fun. No melee: up close he keeps shooting.',
  snare:'Snare_Arrow · 29 energy · 12s. Pins one zombie in place for 2.5s (1d4) and slows anything right beside it 30% for 2s. Goes for fast ones (Screamers, werewolves) and anything closing on a hurt ally.',
  hmark:'Hunters_Mark · 23 energy · 15s. Marks one zombie for 6s: everyone hits it 25% harder.',
  static:'Static_Shield · 40 energy · 14s. Wraps an ally (or himself) within 180px in static for 6s: a shield worth 20% of their max HP, and anything that hits them is zapped for 1d4.',
  overcharge:'Overcharge · 29 energy · 12s. His next 3 sparks hit 50% harder and each jumps to a second zombie close by for half.',
  bash:'Shield_Bash · 23 energy · 8s. Slams his shield into the zombie in front: 1d6 and a 1.5s stun (bosses 0.5s). Interrupts a Screamer\'s shriek or a Skeleton_Archer\'s draw.',
  oath:'Blood_Oath (passive) · every kill heals him 3% of his max HP, below half HP he hits 15% harder, and he regenerates 0.20 HP a second for every zombie within 125px of him.',
  wall:'Shield_Wall · 46 energy · 16s. When 3+ zombies are on him, or 2+ are mauling an ally under 45% near him, he plants his shield for 4s: 60% less damage, no knockback, and every zombie within 150px is taunted onto him.',
  charge:'Crimson_Charge · 40 energy · 12s. When 3+ zombies are lined up in one lane 75-270px ahead, he charges through the line (up to 285px): 2d6 to each and a big shove.',
  kleap:'Leap_Strike · 52 energy · 13s. Leaps 90-330px onto a zombie mauling a hurt ally, a Nemesis or boss, or into a pack of 3+: 3d6+4 and a 1s stun to it, 1d6 to anything beside it.',
  lightfeet:'Light_Feet (passive) · +12% dodge, and she moves quicker than most heroes.',
  pierce:'Piercing_Shot · 40 energy · 10s. When 3+ zombies are lined up ahead of her in one lane, she looses a heavy arrow that goes through all of them (up to 5): 2d6 each.',
  tumble:'Tumble · 29 energy · 12s. When a zombie gets right on her, she hops back about 135px and looses an arrow while she\'s in the air.',
  arcflow:'Arcane_Flow (passive) · +3 energy every time he kills something.',
  chain:'Chain_Lightning · 46 energy · 11s. When 2+ zombies are within 450px, a bolt hits the nearest and jumps to 3 more (each within 135px of the last): 2d6, 20% less each jump, and a 0.4s stun.',
  thunder:'Thunderclap · 52 energy · 16s. When 3+ zombies are bunched 90-480px out, he charges for 0.9s and calls lightning down on them: 3d6 in a 180px-wide blast and a 1s stun (bosses 0.4s).',
  ammodrop:'Ammo_Drop · 40 energy · 20s. Drops an ammo crate for 8s: allies within 90px reload 50% faster and their shots hit 15% harder, and each ally who steps onto it gets one free full magazine (once per crate). Shooters nearby go grab it when they\'re low.',
  smokegren:'Smoke_Grenade · 40 energy · 16s. Lobs smoke up to 300px out, first choice onto a downed ally: a 180px cloud for 6.75s. Allies inside are unseen and revive 25% faster, getting up with +15% HP. Zombies inside miss half their swings and move 25% slower.',
  suppress:'Covering_Fire · 40 energy · 12s. Shoulders the gun and fires 9 aimed rounds (1d4+1, +18 accuracy) down one lane over 1.8s, picking off the zombies closest to his friends first. Every zombie hit is slowed 40% for 2s. Used when a lane fills up or something fast is coming.',
  frag:'Frag_Grenade · 40 energy · 14s. Lobs it 120-390px onto 3+ bunched zombies (or 2 with a big one). After a 0.5s tick: 4d6 in a 90px blast (60% at the edge) and a 1.5s stun. Never where an ally would be caught.',
  attend:'Perfect_Attendance (passive) · never misses game night: once a stage, a hit that would drop him leaves him at 1 HP and untouchable for 2s. Each stage cleared with nobody going down: +2% team damage next stage (max +6%).',
  iai:'Iaijutsu · 30 energy · 9s. Half damage, half movement. A quick draw-slash throws a cyan wave down his lane (fast, about 420px): 2d8 to everything it passes, the first a guaranteed crit. While it\'s out he can reactivate ONCE to blink to wherever the wave is. Used on 2+ lined up or a Screamer, archer or Nemesis; when he\'s hurt and mobbed he throws it backward and rides it out. He blinks to finish a priority target, save a friend in trouble at the wave, escape a mob, or take free ground.',
  sake:'Sake_Break · 40 energy · 10s. A swig of neon sake: 10s of Drunken_Style: +25% attack speed and +15% dodge, but he takes 15% more damage (sloppy drunk guard) and hiccups now and then. Used with 3+ zombies close or a big one near. SHARE: once per swig he can pass the bottle to a friend within 150px: they get half the effect for 6s, and his remaining cooldown is halved and 20 energy comes back. Share with a friend standing in his Dice-Boys_Banner and it\'s even better: they get the FULL effect for the full 10s, and 75% of his remaining cooldown is wiped and 30 energy comes back.',
  errfix:'Error_Code_Fix · 35 energy · 20s. Casino tech mode. REBOOT a friend under 50% (or bleeding, slowed, stunned) within 450px: heal 20% of their max HP and clear it. No one to fix: OVERRIDE a Fireman or Nemesis within 540px: 2s stun and half armor for 6s.',
  host:'Dice-Boys_Banner · 40 energy · 25s. "Game night at my place!" Plants a waving neon DICE BOYS banner for 8s. Anyone standing within 300px of it hits 15% harder and gets +0.5 energy a second. While all three heroes are in it at once, everyone yells DICE BOYS! and gets +7% crit for as long as all three stay in. Friends know it\'s a good spot: they head over when they can, and the third one really wants to get there when the other two already are.',
  loyal:'Loyal_to_a_Fault (passive) · a friend within 480px under 30% HP: 40% of every hit they take lands on Edward instead, and every hit he takes for them gives him +3 energy (works two jobs, never runs out of gas).',
  toolbox:'Toolbox_Toss · 38 energy · 14s. Heaves his toolbox 120-420px at the biggest threat (a Nemesis, boss or Fireman, whichever zombie has hurt his friends most, or the one on the most-hurt friend): 2d8 and a 1.2s stun, 1d4 to anything beside it.',
  nails:'Nail_Strip · 35 energy · 13s. Dumps a whole strip of nails down one lane: every zombie in it up to 300px out takes 1d4 and bleeds, and the nails stay on the ground for 5s, slowing anything walking over them by 30%. Used on a lane with 3+ zombies coming, or a fast one.',
  chutz:'Chutzpah · 34 energy · 16s. He struts out and dares them: every zombie within 300px comes for him for 3s. Meanwhile he takes 30% less damage, and every hit he soaks adds +10% to his next nail or Toolbox_Toss (max +50%). Used when zombies are on his friends, or a friend under 40% is getting mauled.',
  friend:'Power_of_Friendship · 45 energy · 22s. He powers up, anime style, when: 2+ friends are under 60%, one is under 35%, 4+ zombies are on the team, a friend is down, a boss or Nemesis is within 600px, he\'s under 40% with 2+ on him, Chutzpah is pulling 3+ onto him, all three Dice Boys are in the banner, or a friend was just helped up: 6s of +30% damage and attack speed, and friends within 300px hit 10% harder.',
  hardened:'Battle_Hardened (passive) · below half HP: 15% less damage taken, 25% faster reloads. Every 15s he stashes a spare mag (max 2); a reload with one takes 3.5s instead of 7s.',
  online:'Always_Online (passive) · when an ally goes down he gets a PING: +40% move speed for 4s and helps people up 30% faster. Car alarms within 450px are shut off from his phone in 1.5s. Allies within 300px get +5 accuracy from his headset calls.',
  undo:'Ctrl_Z · 34 energy · 20s. When an ally within 270px (or he himself) has lost 25%+ of their max HP in the last 3s, he undoes it: they get all of it back.',
  reboot:'Turn_It_Off_And_On_Again · 29 energy · 12s. Reboots an ally within 210px: clears bleed, fear and slow, heals 8% and refreshes one of their cooldowns. Used on anyone bleeding, scared or slowed, or under half health with an ability waiting.',
  trial:'Tech_Support · 17 energy · 7s. An instant: every cast cuts the remaining cooldowns of every ally within 300px (not his own) by 15% and gives each of them +5 energy. Cheap and quick, so he keeps doing it all fight.',
  dad:'Dad_Mode · 34 energy · 18s. When an ally within 270px is under 40% with 2+ zombies on them, he plants himself beside them: 40% less damage for 5s, a shield worth 20% of their max HP, and the zombies on them get shoved back.',
  build:'Build · 29 energy · three buildings, each with its own cooldown. He kneels to build (3s) and his other cooldowns pause. WATCHTOWER (7s): heals allies near it 1% a second; Modify adds tier 2 (+15% ranged attack speed nearby, and a floor a shooter can stand on: +6 accuracy, +30% range, +7.5% damage) and tier 3 (the top lookout: a second shooter climbs up for +12 accuracy, +50% range, +15% damage). Up there they can\'t be hit, but zombies nearby go for the tower legs. HESCO_BARRIER (16s): blocks its lanes; zombies have to break it; allies behind get +8 accuracy. TESLA_COIL (22s): zaps the nearest zombie for 1d4+2 every 1.5s, arcing to one more, for 25s. When one of his towers scrolls off behind the team, tower and Modify cooldowns reset.',
  repair:'Repair · free, no cooldown · slow: patches up his buildings (6 HP a second) and the Warhound (2% a second) while he stays beside them. His other cooldowns pause while he works.',
  modify:'Modify · 34 energy · 10s (a watchtower tier refunds 70%). Adds the next tier to his watchtower, or bolts an auto-turret onto a wrecked car: 3-round bursts, 1s reload, not very accurate.',
  satchel:'Satchel_Charge · 40 energy · 18s. Tosses a satchel of explosives that never goes off on its own; he sets it off when it\'s worth it. The biggest blast in the game: 6d4 at the centre, falling off outward, and a huge shove.',
  plating:'Field_Plating (passive) · stay next to an ally for 3s and he straps a plate kit on them: +25% armor and +15% knockback resistance until they take 3 hits.',
  syphon:'Syphon_Life · 100 energy · 9s. A swirling black and purple beam from his chest into an enemy up to 330px away for 3s: it drains 3 life a second (more with damage buffs) and heals him for 1.25x what it drains. This is how he pays for everything else.',
  lethal:'Lethal_Strikes · 10% of his life · 20s · 12s. A frenzy: +75% dagger speed, 25% less per hit, Ritual_Blade poison doubled (50% chance, 2 stacks), and he goes all-in up close.',
  tentacle:'Spawn_Tentacle · 8% of his life · 10s. Raises a tentacle anywhere within 400px, right in the middle of the biggest pack. It can\'t move, lashes 1d6+2 out to its reach, heals off what it hits, and withers 5% a second.',
  cthulhu:'Call_of_Cthulhu · 15% of his life · 30s. His tentacles burst back up 200px in front of him and a wave of terror rolls out: 2s of fear and 25% slower. For 10s every tentacle is 25% bigger and lashes 25% faster, and Spawn_Tentacle comes back twice as fast.',
  harvest:'Ritual_Harvest (passive) · built into his dagger: every dagger kill takes 1.5s off Spawn_Tentacle\'s cooldown.',
  blade:'Ritual_Blade (passive) · his poisoned ritual dagger: a hit that lands has a 25% chance to add a poison stack, every dagger swing refreshes the poison already on the target, and every dagger kill takes 1.5s off Spawn_Tentacle\'s cooldown.',
  clone:'Shadow_Clone · 40 energy · 18s. A see-through copy of him steps out for 5s and runs at a different zombie (one bothering an ally first). It swings for 40% damage and pulls the zombies it hits. While it\'s near him it soaks 35% of the blows aimed at him.',
  momentum:'Momentum · Passive. Every sword hit within 2s of the last one gives +6% attack speed, stacking up to +30%. Stop swinging for 2s and it resets.',
  pin:'Pinning_Shot · 34 energy · 12s. An arrow that nails the biggest threat to the ground for 2.5s and marks it for 6s: marked enemies take 25% more damage from everyone.',
  wind:'Wind_Reading · Passive. He reads the wind: shots at anything more than about 450px away get +15 accuracy and +0.5x crit damage.',
  resurge:'Verdant_Resurgence · Passive · 25s cooldown. When an ally would die, vines catch them: they stay up, can\'t be hurt for 2s and heal 30% of their max HP.',
  nano:'Nano-Tech_Repair_Bots · 40 energy · 20s. Under 55% he stops and repair bots restore 7% of his max life every second for 5s (he\'s a machine: no bandages, herbs or heal spells). He can\'t move or attack meanwhile and cuts it short if swarmed. Every hit he takes has a 15% chance to halve the remaining cooldown.',
  surge:'Arc_Surge · 45 energy · 20s · 15s. Overcharges the Targeted Lazer: 1d4+3 every 0.35s, a 25 px blast at the tip that sweeps 210 px instead of 150, and every lazer hit sets them on fire. He leans 3 toward Shooter while it lasts.',
  directive:'Primary_Directive · one skill, two choices, one shared cooldown. TACTICAL_RETREAT (free, 40s): when he drops under 30% he jetpacks in a big arc back to the rear; a blue shield caps every hit at 5 in the air and he fires about 3 missiles on the way. CARPET_BOMB (45 energy, 30s): jetpacks FORWARD about 360px over the horde and drops 9 missiles onto whatever is under him (same shield). Either one lands with a GROUND SMASH: 2d6 to everything within 135px, knocked hard away from him. Using either puts both on cooldown. He bombs on 4+ zombies (or a boss) ahead while over 45%, and saves it to bail out when he\'s low.',
  missiles:'Missile_Barrage · 55 energy · 15s. The pod on his back pops open and lobs 3 missiles high over the fight onto a group, spread wide; each one 2d4 in a small blast.',
  smoke:'Smoke_Screen · 40 energy · 16s. Lobs smoke between a hurt ally and the zombies on them: a 180px cloud for 6s. Zombies inside move 30% slower and miss half their attacks. Allies inside dodge 25% of hits and are STEALTHED (zombies lose track of them) until 5s after they step out or attack.',
  toke:'Toke_Break · no energy · 22s · 2s. He sparks up a big one and keeps walking but does nothing else while he smokes; then he\'s HIGH for 30s (see Wake_n_Bake) and feels 6% better.',
  familia:'Protect_the_Familia · 57 energy · 20s (starts after the dash). When a friend within 660px drops under 55% with a zombie near (or under 35%), he dashes in front of them, untouchable and setting off nothing. Both get a shield worth 50% of his max HP for 5s and the friend is shoved 75px back. A zombie right beside him is bashed: 2d4, a 1s stun, sent flying into its friends (1d4 each).',
  noscope:'No_Scope · 40 energy · 15s. The gamer in him: a hip-fired Kar98 flick that punches through up to 3 zombies in a line for 3d6 each, with +15% crit. Used when 2+ zombies line up in front of him, on one big one, or right after a Kar98 shot to finish off a lone zombie it would likely kill.',
  trash:'Trash_Talk · 34 energy · 12s. He roasts every zombie within 210px so they all come for him for 4s while he hides behind the shield (30% less damage); his friends laugh: +5% crit for 6s. He uses it when zombies are piling on a friend, or when 3+ are around him and he\'s above half health.',
  baked:'Wake_n_Bake · Passive. While HIGH: +20% dodge, 20% less damage taken, +1 energy a second, +20% sword speed, and he leans 4 toward Slasher. Sober for 10s+: -6 accuracy and 10% slower moving and attacking. Sword & Board (built in): 20% to BLOCK a hit outright with the shield.',
  aimed:'Aimed Shot · 52 energy · 14s · 2s cast with a laser sight. Never misses the head box, +5% crit, 2.5x crit damage, pierces. If the shot kills, what\'s left of its cooldown is halved.',
  trip:'Proximity_Bomb · 46 energy · 10s. Goes off when a zombie comes within 40px in its lane (20px a lane up or down). OVERHAND: thrown 300-450px, blows on impact for 2d4+6. UNDERHAND: rolls 150px ahead and arms in 0.5s for 2d4+6 (2d4+2 if tripped early). PLACE: 3s kneeling, right in front, 6d4+2 and a wider blast. A bomb left behind off screen halves the rest of the cooldown.',
  grit:'True_Grit · 40 energy · 15s. For 8s he takes 50% less damage, moves 25% faster, and goes all in: his Careful/Reckless and Sharpshooter/Brawler sliders both jump to 10, so he wades in with the crowbar.',
  camp:'Set_Camp · 46 energy · 30s. Kneels for 1.8s and lights a fire in front of him. Allies within 400px get COZY while they stay close: +0.5 life and +0.5 energy a second, +10% melee attack speed and +10% move speed. The fire takes 5 hits on Flannel_Man or his companion before it goes out.',
  elite:'Elite_Survivors (passive) · his Traveling_Companion starts every stage beside him; while they\'re within 150px both get +10% dodge. He has Scavenger built in (searches wrecks for medkits, batteries and scrap). She throws bricks (never miss, 75% stun) and a Bottle_Distraction (34 energy, 16s): every zombie within 72px of where it lands walks to the noise for 1.8s (she aims it just behind the tightest knot of zombies).',
  dash:'Wave Dash · 57 energy · 16s. Rides a blue energy wave about 300px forward; everything it passes through (about 1.5 lanes each way) takes a normal sword hit (2d5 base); War Cry, damage buffs and crits apply as usual.',
  shout:'War Cry · 29 energy · 7s. Every ally within 600px gets +25% damage and attack speed for 7s.',
  rain:'Arrow_Rain · 52 energy · 18s. 16 arrows rain down on the thickest group of enemies (1d6 each).',
  rapid:'One Nocked, Two in Hand · 46 energy · 10s. She rapid-fires 3 arrows within 1 second, each at the same or a different target (-5 accuracy). These can\'t crit, but any crit she lands at any time halves what\'s left of this cooldown.',
  blowgun:'Blow_Gun · 34 energy · 9s. A dart that hits for 1d4 on its own plus poison (1 stack guaranteed, 75% for a 2nd, 50% for a 3rd) on the living. Undead are immune to the poison, but hitting one halves what\'s left of the cooldown.',
  poultice:'Poultice · 29 energy · 15s. When he\'s under 60% health he slaps a herbal poultice on: heals himself 4% of max HP every second for 6s.',
  whirl:'Whirl_Wind · 52 energy · 14s. Spins with his axe for up to 5s at half speed, trailing a slashing wave: every second it hits everything within about 70px for 1d4 and makes it bleed (6 over 3s). He can break it off early to escape, but usually spins it out.',
  chop:'Ground_Chop · 34 energy · 9s. A huge overhead chop into the ground: a shockwave 120px ahead for 2d6 that shoves and stuns for 0.8s.',
  leap:'Hatchet_Leap · 46 energy · 16s. Double-jumps onto an enemy up to 180px away and slams down for 1d10 to everything around the landing, cracking the ground. Everything hit is stunned: 1.2s right under him, down to 0.4s at the edge.',
  rage:'Timber_Rage · 40 energy · 20s. Under half health: +30% damage, +20% attack speed and 25% less damage taken for 6s.',
  rhythm:'Feller\'s_Rhythm (passive) · every 3rd axe hit in a row (each within 3s of the last) is a felling blow: +50% damage and a 0.4s stagger. TIMBER!',
  mend:'Mend · 20 energy · 5s. Instantly heals the most-hurt ally for 10% of their max HP.',
  bloom:'Rejuvenating Bloom · 40 energy · 14s. Wraps an ally in a healing vine heart: 4% of max HP every second for 8s.',
  thorns:'Thorn Wave · 46 energy · 14s. A wave of earth thorns erupts along the ground 400px down her lane: 2d6 to everything it bursts under, plus bleed (12 over 4s) and a 50% chance of a poison stack (undead are immune).',
  cyclone:'Cyclone · 52 energy · 18s. A slow tornado forms well ahead of her (about 450px out) and wanders there for 5s, slowly pulling nearby enemies toward it and dealing small steady damage (1d3 every 0.5s) to everything inside.'};
const BEHAVIOR={
  knight:'A knight in crimson plate who took an oath and means to keep it. Stands at the front with sword and shield, plants the shield when the crowd gets thick and drags them all onto himself, charges through a line of them, and comes down out of the sky on anything that grabs a friend.',
  carcher:'A small hooded archer who would much rather be shooting from far away. Picks targets off at long range, lines up shots that go through a whole row, and hops back out of reach the moment something gets close.',
  csorc:'A quiet, dark-haired little sorcerer who throws lightning. Hangs back in the middle, sparks single zombies, chains bolts through a pack, and saves his Thunderclap for a real crowd. Gets a second wind from every kill.',
  cheez:'A drunken techno-samurai with a beam katana: the casino tech who fixes the broken machines, an anime and game-con nerd, a witty teaser who never means it, and the guy who never misses game night (and usually hosts it). Slices whole lines of zombies, gets loose on neon sake, reboots hurt friends, and plants the DICE BOYS banner.',
  edward:'A good friend who\'s stuck around forever and the one you can always rely on. Works two jobs (construction and the files at a casino), so he never runs out of gas. Charismatic, funny, loyal to a fault and sharp: nails zombies from mid range, heaves his toolbox at the big ones, dares the whole horde to come at him with pure Chutzpah, takes hits for anyone about to drop, keeps a file on whoever\'s hurting his friends, and when things look grim he powers up with the Power of Friendship.',
  soldier:'A soldier who kept his kit when everything fell apart. Calm, by the book, a little dry. Holds the middle of the line with his assault rifle, butt-strokes anything that gets too close, and saves his frag grenades for a real crowd. Calls his throws.',
  shoshi:'The crew\'s go-to tech guy. Smart, funny, and the first to help whenever anyone asks. Hangs back at mid range bursting zombies with his Automatic_Pistol (20-round mag: aimed taps, or he unloads on a big target), always keeps an eye on where everyone is, reboots whoever\'s in trouble, keeps everyone\'s cooldowns moving with Tech_Support, shuts car alarms off from his phone, and goes full dad mode when someone is about to go down.',
  cultist:'Theatrical, self-serving zealot. Hangs back behind the front line, flinging void bolts and stabbing with a ritual dagger anything that gets close. Pays for his magic in his own blood: tentacles up out of the middle of the pack, a frenzy of poisoned stabs, and the call of Cthulhu to send everything fleeing. Then he drinks the life back out of them with a swirling void beam. Holds grudges and loves to show off. Fairly steady (zealotry), but his chanting makes him loud, so zombies hear him coming; he rarely bothers with cover.',
  robot:'Heavy, patient war machine. Walks slowly, holds a line in front of the squishies and trusts its plating. Hoses anything close with its flamethrower and burns a creeping red lazer through anything further out (overcharged with Arc Surge when a crowd lines up). When they bunch it sends a missile barrage; when a friend is hurt and swarmed it smokes them out and hides them. When it is about to break it jets out of the fight. Listens to callouts. Unshakable: almost never panics. Also the loudest thing on the field: he clanks past wrecks and sets alarms off, and stray zombies home in on the noise. He stands in the open and trusts his plating.',
  lumberjack:'Big, stubborn brawler. Wades into the thick of it with his axe and goes for the biggest enemy, holding a grudge against whatever hit him. Shoots his hunting bow while he closes in, spins into crowds, leaps onto targets, chops the ground to stun, gets angry when he\'s hurt, and rolls out of trouble. Loud and rowdy, he draws zombies in and trips car alarms. He never hides behind anything.',
  druid:'Selfless healer. Hangs back near her friends and watches their health more than the enemies: patches up whoever is hurt worst, wraps allies in healing vines, and pokes at range with nature bolts. When enemies bunch up she drops thorns on them or sends a tornado down the lane. Light-footed and quiet. Her nerves are middling, so a boss or a fallen friend can rattle her for a moment. She tucks in behind rocks and logs when the horde gets thick.',
  archer:'Patient longbow marksman. Stays well back in his own lane, moves slowly and plants his feet for clean, accurate shots at the biggest threat. Backs up what his allies are fighting, sticks to his plan and doesn\'t waste energy. If something gets in close he cracks it with his bow. Steady and nearly silent: the best one to send searching a wreck. He shoots from behind cover whenever there\'s some nearby.',
  chibi:'Bold little front-liner. Charges in with his sword and fights up close, alternating a two-hit combo when he plants his feet and a running slash when he\'s on the move. Watches the enemies more than his friends, hops lanes to find a fight and picks his own targets. Stubborn about whoever hit him last, and loves to show off after a kill. Light on his feet and fairly steady. He never takes cover; he\'d rather be in their faces.',
  eng:'Practical fixer. Hangs a little behind the front, works with his hands: puts up a watchtower behind the team and builds it up, drops a concrete barrier in front of a crowd, plants a tesla coil, bolts turrets onto wrecks and keeps it all patched together. Halving the tower cooldown whenever one of his towers scrolls off behind the team keeps them coming. Bashes anything close with a heavy wrench and lobs grenades into the crowd with his Grenade_Launcher (from the lookout, they come down hard and bounce further). Patient, very techy, a bit quiet; holds his satchel until the moment is right.',
  jp:'Loud, lovable menace. A good guy who picks on everybody, games all day and smokes even more. Kar98 at range, sword and a homemade wooden shield up close, and the first one in when family is in trouble. Keep him high or he gets grumpy.',
  flannel:'Careful, team-first marksman. Hangs back at mid range with his bolt-action rifle and plants his feet before shooting: one shot, then a 2-second reload. Anything that gets into crowbar reach gets a d12 swing instead. Looks after hurt allies before himself and keeps an eye on where his friends are. Goes for the big targets and holds a grudge: whatever hurts him becomes his next target. Sticks to his plan and his own lane, and never shows off. A seasoned survivor: steady nerves, quiet, and always puts a car or a rock between himself and the horde when he can, leaning out to shoot.',
  joel:'Fast, restless pair. Always on the move: they hop lanes looking for better fights and change plans constantly. They lean into close fights, pile onto whatever their allies are hitting, and pick off the small ones. They burn energy as soon as they have it (lots of Power Attacks), shoot on the run (sloppy), forgive quickly and love to taunt after a kill.',
  mathas:'Patient sniper. Stays far back in its own lane, moves slowly and sticks to its plan. Watches the enemies, not its allies, and looks after itself first. Hunts the biggest enemy on screen on its own, plants its feet for clean shots and saves energy for a big burst. Never forgets who hit it. All business.',
};
const INSP_LABEL={acc:['Accuracy',''],crit:['Crit chance','%'],critMul:['Crit damage','x'],dodge:['Dodge','%'],armor:['Armor',' pts'],stamina:['Stamina',''],luck:['Luck',''],xp:['XP gain','%'],
  kbRes:['Knockback resistance','%'],enMax:['Max energy',''],enRegen:['Energy regen','/s'],lifesteal:['Life steal','%'],move:['Move speed','%'],meleeDmg:['Melee damage','%'],rangedDmg:['Ranged damage','%'],
  meleeSpd:['Melee speed','%'],rangedSpd:['Ranged speed','%'],kb:['Melee knockback',''],cdr:['Cooldown reduction','%']};
const INSP_HELP={cdr:'Every ability comes back that much faster (cooldown reduction tops out at 50%).',acc:'More shots land on the body and head instead of flying over (each point moves 0.25% of shots down a box).',
  crit:'Higher chance for any hit to be a critical hit.',critMul:'Critical hits deal more damage.',dodge:'Chance for an enemy hit to miss him completely.',
  armor:'Takes less damage from every hit (each point = 2% less, up to 20 points).',stamina:'More max health (each Stamina = 5 HP).',luck:'Better odds of rare items and gold.',
  xp:'Levels up faster.',kbRes:'Gets shoved around less by heavy hits.',enMax:'Can store more energy for abilities.',enRegen:'Energy refills faster, so abilities come back sooner.',
  lifesteal:'Heals for part of the damage he deals.',move:'Walks and runs faster.',meleeDmg:'Melee hits deal more damage.',rangedDmg:'Ranged hits deal more damage.',
  meleeSpd:'Swings his melee weapon more often.',rangedSpd:'Shoots and reloads faster.',kb:'Melee hits shove enemies back further.'};
function stashText(S){return Object.entries(S).map(([k,v])=>`+${v} ${{gold:'gold',parts:'spare parts',food:'food',water:'water'}[k]}`).join(', ');}
function inspHelp(name){const I=INSP[name];if(!I)return [];const out=[];if(I.perk&&PERKS[I.perk]){const P=PERKS[I.perk];out.push(P[0]+' '+P[1]+' (perk): '+P[2]);}
  if(I.passive&&INSP_PASSIVE[I.passive])out.unshift('✦ '+INSP_PASSIVE[I.passive][0]+': '+INSP_PASSIVE[I.passive][1]);
  for(const [k,v] of Object.entries(I.mod||{})){const [l,u]=INSP_LABEL[k]||[k,''];out.push(`${v>0?'+':''}${v}${u} ${l}: ${INSP_HELP[k]||''}`);}
  for(const [k,v] of Object.entries(I.sl||{})){const S=SLIDERS.find(s=>s[0]===k);if(!S)continue;const side=v>0?S[2]:S[1];
    if(false)0;out.push(`${side} +${Math.abs(v)}: slides his personality ${Math.abs(v)} step${Math.abs(v)>1?'s':''} toward "${side}" (the ${S[1]} ↔ ${S[2]} slider: ${S[3].toLowerCase()}). If that would go past 0 or 10, it doesn't move.`);}
  return out;}
// 0.12.27 (Kyle): more decks give one unique passive instead of a small stat; fewer give two things at once
const INSP_PASSIVE={
 herbalist:['Herbalist','he searches nearby foliage, rocks, stumps and fallen logs for healing herbs (1.5s each; the chance is good and goes up with his Luck and with how Perceptive he is) and carries up to 3. When he or an ally within about 50px is under 80% health, he uses one: it heals 20% of their max HP over 5s, but any damage stops it. He searches whatever is close by without going far out of his way, and goes to hurt allies with herbs.'],
 scavenger:['Scavenger','he searches broken-down cars (2s each; the chance goes up with his Luck and how Perceptive he is). He can turn up a Medkit (heals an ally under 60% for 25% at once), loose scrap worth gold, or, with a Warhound on the team, a Battery (+30 energy for the Warhound when he runs low). He carries 2 at most, in any mix. He searches wrecks close by without going far out of his way, and brings supplies to whoever needs them.'],
 resourceful:['Resourceful','he makes do with what he finds: the team can pay for camp upgrades in spare parts instead of gold (1 part per 4 gold of the price, so a 100g upgrade is 25 parts). Once per team.'],
 haggler:['Haggler','he talks every builder down: camp upgrades cost 20% less. Once per team: more Hagglers still means 20%.'],
 bankroll:['House Money','the house fronts you: the run starts with +50 gold for every hero carrying this deck. Spend it at camp.'],
 bounty:['Bounty Hunter','his first hit on the biggest enemy on the field puts a bounty on it: it is marked (takes 25% more damage from everyone for 8s), and when it dies the party gets +10 gold.'],
 haunt:['Haunted','anything that hits him has a 20% chance to be spooked and back away for 1.5s.'],
 omen:['Dark Omen','once every 12s, the first hit that would land on him passes straight through.'],
 onslaught:['Onslaught','after he has been moving for 1s, his next hit deals double damage.'],
 shell:['Shell Up','when he drops under 40% health he pulls into his shell: 70% less damage taken for 3s while he holds still (30s cooldown).'],
 devour:['Devour','every enemy he kills heals him 3% of his max HP and gives him 4 energy.'],
 pickpocket:['Pickpocket','every enemy he lands a hit on gets its pockets picked: when it dies it is much more likely to drop gold (+60%), food and water (x2), spare parts (x2.5) and items (+50%). A truly Selfish thief (8+) also sometimes helps himself to whatever a nearby ally is carrying...'],
 bodyguard:['Bodyguard','a scripted behavior: he sticks to whichever ally is most hurt and stands by their side, and while he is within reach of them he takes 30% of every hit meant for them.'],
 webs:['Web Shooter','his hits have a 15% chance to web the target: 60% slower for 2s.'],
 forager:['Forager','he knows what\'s edible: food drops from the enemies he kills come about twice as often (roughly one per 9 of his kills instead of one per 18).'],
 raincatch:['Rain Catcher','he never lets a storm go to waste: water drops from the enemies he kills come about twice as often (roughly one per 9 of his kills instead of one per 18).'],
 mountain:['The Mountain','nothing moves him: +50% knockback resistance (up to 95%), so heavy hits, boss slams and blasts barely shove him, and boss hits deal 10% less to him.'],
};
/* 0.12.56 (Kyle): perks are a second, smaller bonus a deck can carry; each one shows up on 2 decks for now */
const PERKS={
 sapper:['🧨','Sapper','spots enemy mines far more easily and defuses them with good odds (about 82% before traits, versus about 30% for anyone else; a failure sets it off). Slow and Steady, Techy, Steady nerves, Optimal and Luck all help. Plants bombs and mines faster (-0.8s), and his own Trip Bomb (Flannel_Man) hits 25% harder. A defused mine is kept as a one-time item 75% of the time (40% for non-Sappers) and planted in front of zombies coming down his lane; otherwise it comes apart into spare parts.'],
 medicine:['🌿','Medicine Man','every heal he gives lands 30% stronger: healing spells, medkits, herbs, healing over time and his abilities\' heals. Allies he helps up come back with 35% HP instead of 25%.'],
 inevitable:['⏳','Inevitable','every time something he tries fails (a shot that hits nothing, an attack that\'s dodged, an empty search, a fumbled defuse) he gains +2 Luck and +1% crit chance, stacking up to 10 times. The next critical hit he lands cashes it all in and the stacks start over. Resets each stage.'],
 looter:['🎒','Lucky Looter','nothing goes to waste: food AND water drops from the enemies he kills both come about 50% more often (roughly one of each per 12 of his kills instead of one per 18).'],
 superlucky:['🍀','Super Lucky','everything his Luck does, it does twice as well: his Luck counts double for finds when searching, rare drops, defusing and planting, and anything else Luck touches (Inevitable stacks included).'],
};
function deckSkills(name){const I=INSP[name];if(!I)return [];const out=[];if(I.passive&&INSP_PASSIVE[I.passive])out.push(['✦',INSP_PASSIVE[I.passive][0],'Deck passive: '+INSP_PASSIVE[I.passive][1]]);if(I.perk&&PERKS[I.perk])out.push([PERKS[I.perk][0],PERKS[I.perk][1],'Deck perk: '+PERKS[I.perk][2]]);return out;}
const insP=u=>(u&&u.insp&&INSP[u.insp]&&INSP[u.insp].passive)||(u&&u.key==='flannel'&&(((u.base&&u.base.char)||CHAR.flannel).abilities||[]).some(a=>a.id==='elite')?'scavenger':undefined);   /* 0.12.68: Elite_Survivors = Scavenger built in (a deck perk still wins) */
function inspText(name){const I=INSP[name];if(!I)return '';const out=[];if(I.passive&&INSP_PASSIVE[I.passive])out.push('✦ '+INSP_PASSIVE[I.passive][0]);
  for(const [k,v] of Object.entries(I.mod||{})){const [l,u]=INSP_LABEL[k]||[k,''];out.push(`${v>0?'+':''}${v}${u} ${l}`);}
  for(const [k,v] of Object.entries(I.sl||{})){const S=SLIDERS.find(s=>s[0]===k);if(S)out.push(`${v>0?S[2]:S[1]} +${Math.abs(v)}`);}
  if(I.stash)out.push('🎒 Starts with '+stashText(I.stash));
  if(I.perk&&PERKS[I.perk])out.push(PERKS[I.perk][0]+' '+PERKS[I.perk][1]);
  return out.join(', ');}
// ---- 0.12.5 Flannel_Man's companion: about 1/3 of every stat of his that applies (health, armor, dodge, knockback resistance,
//   damage, accuracy, crit chance, knockback). Speed, timing, range and energy stay the same so she keeps up and can use her brick.
// 0.12.6 Chibi_Warrior: a quick, sturdy sword fighter (Claude's starting numbers until Kyle fills his sheet). He swings a
//   2-hit combo (Attack 1, Attack 2) standing still and a running slash when he's on the move. No gun, no abilities yet.
CHAR.chibi={name:'Chibi_Warrior',role:'Sword + Kunai',combo:1,flatHp:0,stamina:10,hpPerStamina:5,armorPts:8,dodge:.06,kbRes:.30,
  melee:{dice:[2,5],every:1.2,reach:24,kb:15,hitAt:.18},   /* 0.12.58 (Kyle): too strong: 2d6/1.1s -> 2d5/1.2s (about -20% damage) */
  // Kunai throw (built from his Attack 1 wind-up + Run+Attack throwing arm): a light 1d4 poke at range while he closes in
  ranged:{dice:[1,4],flat:0,every:2.6,range:180,clip:0,reload:0,pellets:1,anim:.5,releaseAt:.32},
  acc:10,walkPenalty:4,crit:.10,critMul:1.75,luck:15,xp:0,run:2,turn:.18,enMax:100,enRegen:4.6,
  abilities:[
    // Wave Dash: he rides a blue energy wave (1.5x his height) about 300 screen px forward (100 world px) in 0.5s.
    //   (Kyle's distances are screen pixels: the normal 1152px-wide game shows 3 screen px per world px.)
    //   Everything the wave passes through (2 lanes up and down) takes 1.4x a sword roll (+flat bonuses) and a shove.
    //   Bigger reach and area, so it costs more: 45 energy, 16s cooldown.
    {id:'dash',name:'Wave Dash',en:57,cd:16,dist:100,dur:.5,dmgMul:1,depth:12,kb:25,minHits:2},
    // War Cry: every ally within 600 screen px (200 world px) gets +25% damage and +25% attack speed for 7s. 20 energy, 7s cooldown (Kyle).
    // Poultice (Kyle): he slaps a herbal poultice on his wounds: heals himself 4% of max HP every second for 6s (24% total). 20 energy, 15s.
    {id:'poultice',name:'Poultice',en:29,cd:15,pct:.04,tick:1,dur:6,under:.6},
    // 0.12.20 Shadow_Clone (decoy, new): a see-through copy of him steps out for 5s. It mirrors every sword hit he lands (+40% on the
    //   same target), and 35% of the blows aimed at him hit the clone instead. IF 2+ enemies close OR hurt with something on him. 30 energy, 18s.
    {id:'clone',name:'Shadow_Clone',en:40,cd:18,dur:5,mirror:.4,decoy:.35},
    // 0.12.20 Momentum (passive, new): each sword hit within 2s of the last stacks +6% attack speed, up to 5 stacks (+30%); a 2s gap drops it.
    {id:'momentum',name:'Momentum',passive:1,per:.06,max:5,window:2},
    {id:'shout',name:'War Cry',en:29,cd:7,range:200,dur:7,dmg:.25,spd:.25}]};
// 0.12.7 Yumi_Archer: a patient longbow marksman (Claude's starting numbers; no abilities yet). His arrow leaves from the
//   arrow's tip in his draw pose, at the moment of release in his Ranged animation (0.55s into a 0.8s draw). No reloading.
CHAR.archer={name:'Yumi_Archer',role:'Bow + Melee',flatHp:0,stamina:9,hpPerStamina:5,armorPts:6,dodge:.04,kbRes:.25,
  melee:{dice:[1,8],every:1.6,reach:22,kb:18,hitAt:.2},
  ranged:{dice:[1,10],flat:0,every:1.7,range:280,clip:0,reload:0,pellets:1,anim:.8,releaseAt:.55},
  acc:22,walkPenalty:15,crit:.12,critMul:2,luck:18,xp:0,run:2,turn:.25,enMax:100,enRegen:4.6,
  // One Nocked, Two in Hand (Kyle's name, with the archery spelling 'nocked'): his next 3 arrows come much faster (time between shots x0.3, quicker draw). 30 energy, 14s cooldown.
  abilities:[{id:'rapid',name:'One Nocked, Two in Hand',en:46,cd:10,shots:3,accPen:5,over:1},   // 0.12.63 (Kyle): 3 shots in 1s, 40 energy, 10s, can't crit; any crit she lands halves its remaining cooldown   // 0.12.23: 3 basic shots in 1.5s
    // Blow_Gun: he puts a bamboo blowgun to his lips (0.7s) and puffs a poison dart (1d3). It always applies 1 poison stack to a
    //   non-undead target, with a 75% chance for a 2nd and a 50% chance for a 3rd. 25 energy, 9s cooldown. Picks living targets.
    // Arrow_Rain: 0.6s to loose a volley high into the air, then 16 arrows rain down over 1.4s on the thickest group of enemies in
    //   range (about 70px wide, 2 lanes up and down). Each arrow hits what it lands on for 1d6 (+flat) and sticks in the ground.
    //   40 energy, 18s cooldown.
    {id:'rain',name:'Arrow_Rain',en:52,cd:18,cast:.6,count:16,over:1.4,fall:.35,spread:36,lanes:12,dice:[1,6],range:280,hitR:5},
    {id:'blowgun',name:'Blow_Gun',en:34,cd:9,anim:.7,releaseAt:.42,dice:[1,3],extra:[.75,.5],range:220,base:[1,4]},   // 0.12.63 (Kyle): +1d4 hit damage on top of the poison; hitting a poison-immune target halves its remaining cooldown
    // 0.12.20 Pinning_Shot (root + mark, new): an arrow that nails the target to the ground for 2.5s and MARKS it for 6s: marked enemies
    //   take 25% more damage from everyone. IF the biggest (or fastest) enemy in range isn't marked yet. 25 energy, 12s.
    {id:'pin',name:'Pinning_Shot',en:34,cd:12,root:2.5,mark:6,amp:.25,range:280,anim:.5,releaseAt:.3,dice:[1,8]},
    // 0.12.20 Wind_Reading (passive, new): shots at anything more than 150px (450 screen px) away get +15 accuracy and +0.5x crit damage.
    {id:'wind',name:'Wind_Reading',passive:1,far:150,acc:15,critMul:.5}]};
// 0.12.9 Druid (Claude's starting numbers): a staff-wielding nature caster. Small nature bolts at range, a staff poke up close,
//   and four abilities: two heals (one instant, one over time) and two nature attacks (thorns, a tornado).
CHAR.druid={name:'Druid',role:'Staff + Nature Bolts',flatHp:0,stamina:7,hpPerStamina:5,armorPts:3,dodge:.05,kbRes:.2,
  melee:{dice:[1,4],every:1.5,reach:26,kb:10,hitAt:.2,claw:1},   // 0.12.15 (Kyle): she swipes her hand and a glowing green spirit claw lunges off it into the target
  ranged:{dice:[1,6],flat:0,every:1.8,range:220,clip:0,reload:0,pellets:1,anim:.5,releaseAt:.3},   /* 0.12.58: released as the staff swing reaches its full thrust (frame 3), from the staff head */
  acc:16,walkPenalty:8,crit:.08,critMul:1.75,luck:20,xp:0,run:2,turn:.22,enMax:100,enRegen:4.6,
  abilities:[
    // Mend: small instant heal, low cooldown. 12% of the target's max HP on the most-hurt ally (under 85%). 12 energy, 4s cooldown.
    {id:'mend',name:'Mend',en:20,cd:5,heal:.10,under:.85},   /* 0.12.38 (Kyle): 12% -> 10%, 4s -> 5s */
    // Rejuvenating Bloom: heal over time on any ally (most hurt, under 90%, not already blooming): 5% of their max HP every 1s
    //   for 8s (40% total) inside a glowing vine heart. 30 energy, 12s cooldown.
    {id:'bloom',name:'Rejuvenating Bloom',en:40,cd:14,pct:.04,tick:1,dur:8,under:.9},   /* 0.12.38 (Kyle): 5%/s -> 4%/s, 12s -> 14s */
    // Thorn Wave (Kyle): a wave of earth thorns erupts along the ground down her lane, one after another for 200px over 1.2s.
    //   Every enemy a thorn bursts under takes 2d6 (+flat) and bleeds (12 over 4s). 35 energy, 14s cooldown.
    {id:'thorns',name:'Thorn Wave',en:46,cd:14,dice:[2,6],dist:133,dur:.8,poisonCh:.5,step:12,depth:6,bleed:{dmg:12,dur:4},cast:.5},
    // Cyclone (Kyle): a tornado that lasts 5s, wandering around sporadically in front of her. It slowly pulls nearby enemies
    //   (within 40px) toward it and deals small, steady damage to everything inside it (1d3 +flat every 0.5s). 40 energy, 18s cooldown.
    // 0.12.20 Verdant_Resurgence (passive, new): once per stage, when an ally would die, vines catch them instead: they stay up at 1 HP,
    //   can't be hurt for 2s and heal 30% of max HP over those 2s.
    {id:'resurge',name:'Verdant_Resurgence',passive:1,heal:.3,dur:2,icd:25},   // 0.12.24 (Kyle): no longer once per stage, 25s internal cooldown
    {id:'cyclone',name:'Cyclone',en:52,cd:18,ahead:150,near:100,dist:215,dur:5,dice:[1,3],every:.5,pullR:40,pull:16,inR:12,depth:6,spd:20,wander:28,cast:.5}]};
// 0.12.11 Lumber_Jack (Claude's starting numbers): a burly axeman with a hunting bow. Sturdy, hits hard up close.
CHAR.lumberjack={name:'Lumber_Jack',role:'Axe + Bow',combo:0,flatHp:0,stamina:11,hpPerStamina:5,armorPts:7,dodge:.03,kbRes:.45,
  melee:{dice:[1,12],every:1.2,reach:22,kb:28,hitAt:.2},   /* 0.12.58 (Kyle): a little weak: 1d10/1.3s -> 1d12/1.2s (about +25%) */
  ranged:{dice:[1,6],flat:0,every:2.2,range:200,clip:0,reload:0,pellets:1,anim:.7,releaseAt:.45},
  acc:14,walkPenalty:10,crit:.10,critMul:1.9,luck:16,xp:0,run:2,turn:.25,enMax:100,enRegen:4.6,
  abilities:[
    // Whirl_Wind: spins with his axe for 2.4s, drifting forward; every 0.4s it hits everything around him (1d6 +flat, ~18px, 1 lane each way). 40 energy, 14s.
    // 0.12.26 (Kyle): up to 5s, 1d4 every second to everything in a wider 24px circle, each hit refreshes a bleed (6 over 3s), he moves at half speed while
    //   spinning, and he can break off early (IF he's badly hurt and wants out, OR nothing has been in reach for 1.5s) but usually spins it out.
    {id:'whirl',name:'Whirl_Wind',en:52,cd:14,dur:5,every:1,r:24,depth:7,dice:[1,4],bleed:{dmg:6,dur:3},want:'close',range:30},
    // Ground_Chop: a huge overhead chop into the ground: a shockwave 40px ahead (2d6 +flat), shoves and stuns 0.8s. 25 energy, 9s.
    {id:'chop',name:'Ground_Chop',en:34,cd:9,cast:.5,dist:40,depth:6,dice:[2,6],stun:.8,kb:35,want:'close',range:40},
    // Hatchet_Leap: double-jumps onto an enemy up to 60px away and slams down (1d10 +flat to everything within 16px). 35 energy, 16s.
    // 0.12.69 (Kyle): the slam stuns: 1.2s right under him, down to 0.4s at the edge of the blast; a much bigger landing (cracked earth, dust, pebbles, a burst).
    {id:'leap',name:'Hatchet_Leap',en:46,cd:16,dur:.6,range:60,min:24,r:16,dice:[1,10],want:'close',stun0:1.2,stun1:.4},
    // Timber_Rage: when he's under half health he gets angry: +30% damage, +20% attack speed, 25% less damage taken for 6s. 30 energy, 20s.
    {id:'rage',name:'Timber_Rage',en:40,cd:20,dur:6,dmg:.3,spd:.2,dr:.25,under:.5,want:'close'},
    // 0.12.58 (Kyle: it never seemed to do anything) Log_Roll reworked: he kicks a log down his lane. It rolls 120px forward at 110px/s,
    //   hitting each zombie it passes once for 1d8 +flat, knocking them back and tripping them for 0.6s. 25 energy, 11s.
    //   IF 2+ enemies are in my lane ahead within 90px (or 1 big one) THEN roll it.
    // 0.12.69 (Kyle: replace Log_Roll with a passive of my choosing) Feller's_Rhythm (passive): every 3rd axe hit in a row (each within 3s of the
    //   last) is a FELLING blow: +50% damage and a 0.4s stagger (bosses don't stagger). "TIMBER!" pops over the target.
    {id:'rhythm',name:"Feller's_Rhythm",passive:1,n:3,window:3,bonus:.5,stun:.4}]};
// 0.12.19: renamed Warhound with Kyle's pick of the new sprite (hunched olive war-walker, brass trim, elbowed blade arm).
// 0.12.17 Moss_Mech (Kyle): an original moss-grown green war mech with a blue electric arc blade on its near arm and a gatling on
//   the far arm, plus a missile pod on its back. Heavy and slow, lots of armor. Basic ranged: a short 3-round burst from the gatling.
CHAR.robot={name:'Warhound',role:'Targeted Lazer + Flamethrower',combo:0,flatHp:0,stamina:12,hpPerStamina:5,armorPts:12,dodge:.02,kbRes:.6,
  /* 0.12.67 (Kyle): the arc blade is gone: up close he hoses them with the flamethrower (his "melee"); a wide cone about 210 screen px long,
     everything it touches burns for 2s, 1d4 every 0.25s (numbers only on crits) */
  melee:{dice:[1,4],every:1.5,reach:46,kb:0,hitAt:0,flame:{len:56,w0:8,w1:19,burn:3,burnDice:[1,4],hit:2,tick:.35,dur:.75}},   // 0.12.93 (Kyle: way too much DPS): ticks .25->.35s, burn 2->1.5s, every 1.3->1.5s   // 0.12.77: Kyle's burst sprite; a bit shorter, much wider
  /* Targeted Lazer (ranged basic): 0.5s charge-up, then a 2s beam. The tip starts ~10 screen px in front of a target 200-500 screen px away and
     (0.12.77) now: starts 50 px in front of the target and sweeps 150 px forward in 1s; 2d4 every 0.25s to everything within 20 px of the tip, with a little ground fire riding along.
     2s reload that only starts once the beam is done. (All in screen px; world = /3.) */
  ranged:{dice:[2,4],flat:0,every:0,range:167,clip:0,reload:0,pellets:1,anim:.45,
    lazer:{charge:.5,fire:1,min:30,max:167,lead:50/3,travel:50,tick:.35,r:20/3,dice:[1,4],flat:1,reload:5,travelS:70,rS:25/3,diceS:[1,4],flatS:3}},   // 0.12.93 (Kyle: way too much DPS): 1d4 every .35s (was 2d4 every .25s), 3.25s between shots, Arc_Surge 2d4   // 0.12.77 (Kyle): starts 50px in front of the target, sweeps 150px in 1s; 2.75s between shots
  acc:10,walkPenalty:8,crit:.08,critMul:1.8,luck:10,xp:0,run:1/* 0.12.38 (Kyle): the Warhound only walks */,turn:.3,enMax:100,enRegen:4.6,
  abilities:[
    // Arc_Surge (0.12.67, now activated): IF the lazer is up (or 3+ enemies are in lazer range) THEN 30 energy, 15s CD, 8s:
    //   Shooter/Slasher -3 (toward shooter); lazer 3d4 per 0.25s, 25 px radius, sweeps 210 px, and lazer hits Burn.
    {id:'surge',name:'Arc_Surge',en:45,cd:20,dur:15,slide:-3,burn:2},
    // Missile_Barrage: IF 3+ enemies are bunched (or a boss is up) 40-260px out THEN 3 missiles arc onto them, 2d4 each. 45 energy, 15s.
    {id:'missiles',name:'Missile_Barrage',en:55,cd:15,n:3,gap:.18,fly:.95,range:260,min:40,r:9,dice:[2,4],spread:24},
    // Smoke_Screen: IF an ally under 50% has enemies on them (or I'm swarmed by 3+) THEN smoke the spot for 6s. Allies (not me) inside are
    //   stealthed until they basic-attack or use an ability; it lasts 5s after they leave the smoke, re-entering refreshes it.
    {id:'smoke',name:'Smoke_Screen',en:40,cd:16,dur:6,r:30,slow:.3,miss:.5,dodge:.25,under:.5,throw:.55,stealth:5},
    // Nano-Tech_Repair_Bots (0.12.67): IF I'm under 55% AND nothing is on top of me (or I'm under 30%) THEN 35 energy, 20s CD: I stop ("use")
    //   and the bots restore 5% max life per second for 5s. I can't move or attack, but I cancel early if I get swarmed (2+ on me).
    //   Built in: 10% chance whenever I'm hit to halve the remaining cooldown.
    {id:'nano',name:'Nano-Tech_Repair_Bots',en:40,cd:20,dur:5,per:.07,under:.55,halveCh:.15},   /* 0.12.245 (Kyle): 7%/s, 15% halve chance */
    // Tactical_Retreat (passive, 0.12.67): when I drop under 30% I blast off on a blue-flame jetpack in an arc back to 100 px from the left edge
    //   and land slowly. While flying: every hit is capped at 5 damage (blue shield) and I fire ~3 single missiles at random enemies. 40s ICD.
    // 0.12.245 (Kyle) PRIMARY_DIRECTIVE: one skill, two choices that share one cooldown: Tactical_Retreat (free, under 30%: back) or Carpet_Bomb (45 energy: forward). Using either one puts both on cooldown (retreat 40s, bomb 30s).
    {id:'directive',name:'Primary_Directive',en:0,cd:30,
     retreat:{id:'retreat',name:'Tactical_Retreat',en:0,cd:40,under:.3,icd:40,T:2.6,H:38,shots:3,cap:5,x1:100/3},
    // 0.12.236 (Kyle) Carpet_Bomb (active, the other jetpack mode): IF 4+ zombies (or a boss) are 40-390px ahead of me AND I'm over 45% THEN I jetpack FORWARD
    //   ~360px and let loose 9 missiles (triple the retreat's 3) onto whatever is under my flight path. Same blue shield in the air. 45 energy, 30s.
    // Both modes (0.12.236): when I land, a GROUND SMASH: 2d6 to everything within 135px and a big knockback away from me on either side.
     carpet:{id:'carpet',name:'Carpet_Bomb',en:45,cd:30,T:2.4,H:42,shots:9,cap:5,dist:120}}]};
const JET_SMASH={r:45,dice:[2,6],kb:4};   /* 0.12.236 jetpack landing smash: 135 screen px, 2d6, major knockback */
// 0.12.75 Engineer (Kyle): hard hat, red shirt + overalls, a heavy wrench and a sawn-off shotgun. Builds things.
CHAR.eng={name:'Engineer',role:'Wrench + Grenade_Launcher',combo:0,flatHp:0,stamina:9,hpPerStamina:5,armorPts:7,dodge:.04,kbRes:.35,
  melee:{dice:[2,8],every:1.9,reach:20,kb:34,hitAt:.3,stunCh:.25,stun:.8},   // heavy, slow wrench: hits hard, 25% to stun 0.8s
  ranged:{dice:[3,6],flat:0,every:1.15,range:165,clip:1,reload:4,pellets:1,anim:.35,gl:{r:25,splash:1,fuse:.45,maxT:3,kb:22}},   /* 0.12.161 (Kyle): one grenade, then a 4s reload. 3d4 to everything within a 75 screen px blast radius (25 world) */   /* 0.12.105 (Kyle) Grenade_Launcher (was a sawn-off): 3 grenades, ~1.15s apart, 4.5s reload. 2d6 to whatever it hits, 55% to everything within ~42 screen px. Misses land, roll and blow 0.45s after they stop */
  acc:14,walkPenalty:10,crit:.08,critMul:1.8,luck:14,xp:0,run:1.8,turn:.22,enMax:100,enRegen:4.6,
  abilities:[
    // Build (a WC3-style spellbook: each building has its own cooldown). While he builds or repairs, his other cooldowns pause.
    //   Watchtower: tier 1 takes 5s; Modify adds tier 2 (5s) and tier 3 (7s). One shared health bar, +15% max HP per tier.
    //     T1 sign MEDICAL CROSS: allies within ~150 screen px regen 1% max HP a second.  T2 sign AMMO: allies nearby +15% ranged attack speed.
    //     T3 LOOKOUT: one ranged ally can climb up: +12 accuracy, +30% range, can't be hit until the tower falls. Empty, it gives allies nearby +5 accuracy.
    //   HESCO_Barrier (0.12.76, was the concrete barrier): ONE wire-mesh, fabric-lined cell filled with dirt; blocks zombies in its lane and the ones next to it
    //   (they hit it instead); allies standing behind it +8 accuracy.
    //   Tesla coil (my design): zaps the nearest zombie within ~135 screen px for 1d8 every 1.5s and arcs to one more; lasts 25s.
    {id:'build',name:'Build',en:29,cd:0,book:1,
      tower:{cd:7,T:[3,2.5,3.5],hp:60,   /* 0.12.95 (Kyle: tower too lame): 7s cooldown, builds in 3s, tiers 2/3 take half the time (2.5s / 3.5s) */per:.15,r:50,regen:.01,aspd:.15,acc:5,perchAcc:12,perchRange:.5,perchDmg:.15,midAcc:6,midRange:.3,midDmg:.075},   /* 0.12.264 (Kyle): tier 2 floor +30% range */   /* 0.12.236 (Kyle): the tier-2 floor holds a shooter too (smaller bonus: +6 acc, +15% range, +7.5% dmg); the top lookout +12 acc, +30% range, +15% dmg */
      barrier:{cd:16,T:3,hp:80,depth:9,acc:8,behind:40},
      tesla:{cd:22,T:3,hp:30,life:25,r:45,every:1.5,dice:[1,4],flat:2}},   // 0.12.79: 1d4+2
    // Repair: no cooldown, slow: fixes buildings (6 HP/s) and the Warhound (2% a second) while he stays next to them. Pauses his other cooldowns.
    {id:'repair',name:'Repair',en:0,cd:0,bld:6,mech:.02},
    // Modify: adds the next watchtower tier, or bolts an auto-turret onto a broken-down car (3-round bursts 0.25s apart, 1s reload, low accuracy).
    {id:'modify',name:'Modify',en:34,cd:10,towerBack:.7,   /* 0.12.119 (Kyle): 10s cooldown, but a tower tier gives 70% of it back (3s); still takes its build time */turret:{T:4,hp:40,range:120,burst:3,gap:.25,reload:1,hit:.45,dice:[1,4]}},
    // Satchel_Charge: tosses a satchel that never goes off by itself; he sets it off when it's worth it (3+ zombies on it, or something big).
    //   The biggest blast in the game: 6d4 at the centre, falling off to 30% at ~100 screen px, with a HEAVY shove.
    {id:'satchel',name:'Satchel_Charge',en:40,cd:18,min:30,max:100,r:33,dice:[6,4],kb:95,fly:.8},
    // Field_Plating (passive, the armor kit): staying within ~60 screen px of an ally for 3s straps a plate kit on them: +25% armor and
    //   +15% knockback resistance until they take 3 hits. One kit per ally at a time.
    {id:'plating',name:'Field_Plating',passive:1,r:20,T:3,armor:.25,kb:.15,hits:3}]};
// 0.12.21 Void_Cultist (Kyle): an original hooded cultist (crimson robe, navy hood, bone mask with one burning eye, curved ritual
//   dagger). Void bolts at range, dagger up close. Abilities: a summoned tentacle that can't move but lashes far, a self-bleeding
//   team buff, a curse that jumps on death, a fear chant, and a passive that feeds on nearby deaths.
CHAR.cultist={name:'Void_Cultist',role:'Dagger + Void Bolts',combo:0,flatHp:0,stamina:8,hpPerStamina:5,armorPts:3,dodge:.06,kbRes:.15,
  melee:{dice:[1,6],every:1.4,reach:18,kb:8,hitAt:.2},
  ranged:{dice:[1,4],flat:0,every:.95,range:210,clip:0,reload:0,pellets:1,anim:.34,releaseAt:.18},   // 0.12.22 (Kyle): weak void bolts, fired about twice as fast as other ranged heroes
  acc:14,walkPenalty:8,crit:.1,critMul:1.8,luck:18,xp:0,run:1.8,turn:.22,enMax:100,enRegen:4.6,
  /* 0.12.70 (Kyle) Void_Cultist rework: no energy at all. His abilities cost LIFE (Syphon_Life is free and is how he gets it back). */
  abilities:[
    // Syphon_Life (free): IF an enemy is within ~330 screen px (110 world) AND (I'm hurt OR nothing is on me) THEN channel a swirling black-and-purple
    //   beam into it for 3s: 3 damage a second (scaled by his damage), and he heals for everything it drains. Breaks if it dies or gets away. 9s CD.
    {id:'syphon',name:'Syphon_Life',en:100,cd:9,dur:3,range:110,dps:3,heal:1.25},   /* 0.12.154 (Kyle): 100 energy (his only energy skill), heals 1.25x what it drains */
    // Lethal_Strikes (10% of max life): IF a zombie is in dagger range and I can afford it THEN for 12s: +75% melee attack speed, -25% melee damage,
    //   Poisoned_Blade doubled (50%, 2 stacks), and Shooter/Slasher goes to 10 (all slasher). 20s CD.
    {id:'lethal',name:'Lethal_Strikes',en:0,hpCost:.1,cd:20,dur:12,spd:.75,dmg:.25,want:'close'},
    // Spawn_Tentacle (8% of max life, keeps the old tentacle): placed anywhere within 400 screen px (133 world), in the middle of the biggest pack.
    {id:'tentacle',name:'Spawn_Tentacle',en:0,hpCost:.08,cd:10,cast:.8,life:999,decay:.05,hp:15,steal:.2,reach:35,depth:10,every:1.4,dice:[1,6],flat:2,kb:20,range:133},   // 0.12.101 (Kyle): 10s (0.12.96 was 9s), 1d6+2; wither unchanged
    // Call_of_Cthulhu (15% of max life): 10s: Spawn_Tentacle's CD runs twice as fast, every tentacle is 25% bigger (reach too) and attacks 25% faster.
    //   On cast his tentacles burrow and re-emerge 200 screen px (67 world) in front of him, and a fear pulse goes out from him and from every tentacle:
    //   2s of fear and -25% move speed. IF 2+ tentacles are up OR 4+ zombies are coming, AND I can afford it THEN call. 30s CD.
    {id:'cthulhu',name:'Call_of_Cthulhu',en:0,hpCost:.15,cd:30,dur:10,size:.25,spd:.25,fear:2,slow:.25,r:45,move:67,cast:.9},
    // 0.12.152 (Kyle) Ritual_Blade (passive): Poisoned_Blade and Ritual_Harvest in one. A dagger hit that lands has a 25% chance to add
    //   1 poison stack; EVERY dagger swing refreshes the poison on its target; a dagger hit that KILLS takes 1.5s off Spawn_Tentacle's cooldown.
    {id:'blade',name:'Ritual_Blade',passive:1,ch:.25,n:1,cut:1.5}]};
const PAL_FRAC=1/3;
// which cooldown timer each ability uses, so the planner can see what is ready
/* 0.12.98 RULE for every ability now and later (Kyle): set its cooldown as  A.cd*(1-(h.cdr||0))  (internal cooldowns too: this.t+A.icd*(1-(h.cdr||0))).
   h.cdr is the hero's cooldown reduction (capped at 50%), e.g. from Narset's inspiration. Tested 0.12.98: all 9 heroes' abilities come back 20% faster. */
/* 0.12.237 (Kyle) FALL FORWARD: lose a stage and you pick up a stack (max 3); clear any stage and they all go away.
   While you carry them, for every hero: 1/2/3 stacks = +10/15/20% XP, +20/30/40% gold pile sizes, and you lose 10/20/30% less score the next time you fall.
   Falling costs 10% of your total score plus another 50% of whatever that failed attempt earned. (Lessons Learned, the little XP bump a loss
   gives for how far you got, is part of it now.) */
const XP_MUL=.8;   /* 0.12.250 (Kyle): every way of earning XP (kills, support, Nemeses, Lessons Learned, run levels) is 20% lower */
const FF={xp:[0,.1,.15,.2],gold:[0,.2,.3,.4],keep:[0,.1,.2,.3]};
const ffT=(run,k)=>run&&run.ff?FF[k][Math.min(3,run.ff)]:0;
const CD_KEY={directive:'pdT',undo:'unT',reboot:'rbT',trial:'frT',dad:'ddT',syphon:'syT',lethal:'leT',cthulhu:'ctT',nano:'nbT',tentacle:'tnT',pact:'paT',hex:'hxT',dread:'drT',clone:'clT',pin:'piT',surge:'suT',gatling:'gaT',missiles:'msT',smoke:'smT',grit:'grT',poultice:'poT',aimed:'abT',trip:'tbT',pal:'palT',camp:'caT',dash:'daT',shout:'shT',rapid:'raT',blowgun:'bgT',rain:'arT',mend:'mdT',bloom:'blT',thorns:'thT',cyclone:'cyT',
  whirl:'whT',chop:'cpT',leap:'lpT',rage:'rgT',roll:'rlT',brick:'brT',bottle:'boT'};
const CLOSE_AB=new Set(['lethal','dread','clone','surge','grit','dash','whirl','chop','leap','rage','trip']),FAR_AB=new Set(['syphon','cthulhu','tentacle','hex','pin','gatling','missiles','smoke','aimed','rain','rapid','blowgun','thorns','cyclone','brick']);
function abilityPlan(h){const C=h.base&&h.base.char;if(!C||!C.abilities||!C.abilities.length)return {};let close=0,far=0,farRange=0,ready=0;
  for(const a of C.abilities){const k=CD_KEY[a.id];const up=!(h[k]>0)&&(h.en||0)>=a.en;if(!up)continue;ready++;
    if(CLOSE_AB.has(a.id))close++;if(FAR_AB.has(a.id)){far++;farRange=Math.max(farRange,a.range||a.dist||(C.ranged&&C.ranged.range)||150);}}
  return {close,far,farRange,allDown:ready===0};}
CHAR.dog={name:'Guard_Dog',role:'Bite',flatHp:0,stamina:5,hpPerStamina:5,armorPts:2,dodge:.12,kbRes:.15,
  melee:{dice:[1,8],every:.7,reach:14,kb:6,hitAt:.12},ranged:null,   /* 0.12.58: bites harder and more often */
  acc:12,walkPenalty:0,crit:.10,critMul:1.75,luck:0,xp:0,run:2,turn:.15,enMax:100,enRegen:4.6,pet:1,abilities:[]};
CHAR.flannel_pal=(()=>{const C=CHAR.flannel,f=PAL_FRAC;return {name:'Traveling_Companion',flatHp:C.flatHp*f,stamina:C.stamina*f,hpPerStamina:C.hpPerStamina,armorPts:Math.round(C.armorPts*f),
  dodge:C.dodge*f,kbRes:C.kbRes*f,melee:{dice:C.melee.dice,dmgMul:f,every:C.melee.every,reach:16,kb:Math.round(C.melee.kb*f),hitAt:.12},
  ranged:{dice:[1,4],dmgMul:1,flat:0,every:.5,range:C.ranged.range,clip:7,reload:5,pellets:1},   /* 0.12.38 (Kyle): pistol 1d4, a shot every 0.5s, 7 in the clip, 5s reload */
  acc:Math.round(C.acc*f)-3,   /* a touch less accurate to make up for the faster fire */walkPenalty:Math.round(C.walkPenalty*f),crit:C.crit*f,critMul:C.critMul,luck:0,xp:0,run:C.run,turn:C.turn,enMax:100,enRegen:4.6,pet:1,
  // Brick Throw: never misses and always deals damage (1.5x her pistol roll + flat bonuses), 75% chance to stun for 1.2s. 20 energy, 9s cooldown.
  abilities:[{id:'brick',name:'Brick Throw',en:29,cd:9,range:170,dmgMul:1.5,stunCh:.75,stunT:1.2},
    // 0.12.68 (Kyle) Bottle_Distraction: lobs a glass bottle in a big arc 450-500 screen px (150-167 world); it shatters and every zombie within
    //   ~180 screen px (60 world) turns and goes to check the noise for 2.5s (no attacks). IF a pack of 3+ is coming THEN throw it BEHIND them.
    {id:'bottle',name:'Bottle_Distraction',en:34,cd:16,min:150,max:167,r:24,dur:1.8,   /* 0.12.229 (Kyle): shorter (1.8s, was 2.5s); 0.12.230: half the pull radius (24 world, 72px; was 48) */fly:1.1,min3:3}]};})();
function heroBase(key,lvl,teamSize){
  const C=CHAR[key];if(C){const L=Math.max(1,lvl||1);const lv=1+.06*(L-1);
    return {hp:C.flatHp+C.stamina*C.hpPerStamina,atk:10*lv*(1+.3*(3-teamSize)),stamina:C.stamina,flatHp:C.flatHp,dice:(C.ranged||C.melee).dice,aspd:1,crit:C.crit,critMul:C.critMul,
      acc:C.acc,dodge:C.dodge,armorPts:C.armorPts,kbRes:C.kbRes,pow:1,reach:1,luck:C.luck,xpm:1+C.xp/100,char:C,lvMul:lv*(1+.3*(3-teamSize))};}
  const d=heroDef(key),s=d.stats,st=STYLE[key];
  // Kyle's rules: Max Health = Flat Health + Stamina bonus; Stamina = deck lands / 3 (rounded up); 5 HP per Stamina. Base damage = d6.
  const stamina=Math.ceil((d.lands||36)/3);
  const hp=HERO_FLAT_HP+stamina*HP_PER_STAMINA;
  // ability power (spells, signatures, summons) keeps its old formula; only the basic attack is a d6 for now
  let atk=(7+.7*s.threats+.4*s.clock)*st.dmg;const L=Math.max(1,lvl||1);atk*=1+.06*(L-1);atk*=1+.3*(3-teamSize);
  return {hp,atk,stamina,flatHp:HERO_FLAT_HP,critMul:1.75,dice:HERO_DICE,aspd:(0.8+0.025*s.mana)*(st.aspd||1)*(st.atk==='caster'?.8:1)*(st.atk==='ranged'||st.atk==='caster'?.74:1),crit:HERO_BASE_CRIT,acc:0,dodge:.008*s.control,
    pow:1+.04*s.answers,reach:1+.02*s.reach,luck:Math.round((s.consistency+s.cards)/4)*5,xpm:1+.03*s.cards};
}
function needHeroXp(L){return 100+75*(L-1);}   /* 0.12.145 (Kyle): level 1 needs 100 XP, each level after takes 75 more */
function needRunXp(k){return 8+6*k;}

// ======================================================================= GAME (headless-capable)
// ================= 0.12.2 UNIT BEHAVIOR AI (Kyle's sliders) =================
// Every unit has 13 personality sliders (0 = left trait, 10 = right trait). Each "think", a unit builds every option it has
// (which foe to fight, which lane to stand in, how far to push or hang back, how fast to move, when to spend energy, whether to
// show off) and scores each one with a long list of if/then rules. The sliders set how much each rule counts, so two units
// looking at the same screen make different choices. Buffs/debuffs can slide the scales for a while: addMood(u,{k:+/-n},secs).
const SLIDERS=[
 ['aggr','Calculated Play','Blind Aggression','Safe plays and retreats vs. charging into danger'],
 ['aware','Enemy Awareness','Ally Awareness','Decides by where the enemies are vs. by where allies are'],
 ['pace','Slow and Steady','Fast and Furious','Walks and stops to think, steady hands for fiddly jobs like defusing vs. always running, thinking on the move'],
 ['lane','Stay In Your Lane','Switch It Up','Works the lane it is in vs. hunts for a better lane'],
 ['self','Selfless','Selfish','Protects allies and goes back for the downed vs. looks after itself and rarely risks a revive'],
 ['range','Shooter','Slasher','Prefers fighting from far vs. up close'],
 ['plan','On Track','New Plan','Relentless: sticks with what it started (a search, a revive, a chase) even under fire vs. rethinks often and drops things when hit'],
 ['energy','Squander','Preserve','Spends energy and uses supplies (medkits, herbs, batteries) early vs. saves both for a big burst or a real emergency'],
 ['size','Small Targets','Large Targets','Picks off the small ones vs. goes for the big ones'],
 ['exec','Suboptimal','Optimal','Sloppy (fires on the move) vs. efficient (plants its feet, finishes the weak)'],
 ['grudge','Forgiving','Vengeful','Forgets who hit it vs. hunts whoever hit it last'],
 ['pack','Pack Hunter','Lone Wolf','Piles onto what allies are fighting and stays close to them vs. picks its own fight and spreads out'],
 ['flair','Stoic','Showoff','All business vs. taunts and celebrates'],
 ['talk','Quiet','Chatty','Almost never calls anything out vs. calls out everything it sees'],
 ['tech','Primitive','Techy','Trusts muscle, nature and old ways vs. drawn to machines: shuts off car alarms, picks through wrecks, works the gadgets'],
 ['perc','Tunnel Vision','Perceptive','Locks onto the obvious target vs. keeps looking around for what isn\'t obvious (flankers, danger, things worth searching)'],
 ['listen','Ignores Callouts','Follows Callouts','Does its own thing vs. does what allies shout for'],
 ['nerve','Steady','Panicky','Keeps doing its job when things go wrong vs. panics (bolts, freezes or sprays wild shots) when a boss shows up, an alarm goes off, an ally drops or it gets swarmed'],
 ['noise','Light-Footed','Loud','Moves and searches quietly vs. clanks and crashes about: sets off car alarms more and draws lonely zombies in'],
 ['cover','Out in the Open','Takes Cover','Stands wherever the fight is vs. puts rocks, logs and wrecks between itself and the horde, and leans out to shoot'],
];
const PERSONA={
 knight:{aggr:7,aware:8,pace:4,lane:6,self:1,range:10,plan:6,energy:5,size:7,exec:7,grudge:6,pack:1,flair:5,talk:4,listen:7,perc:6,tech:2,nerve:0,noise:6,cover:3},   // 0.12.180 Crimson_Knight: selfless, fearless, sticks with the pack
 carcher:{aggr:3,aware:8,pace:6,lane:5,self:6,range:1,plan:6,energy:6,size:4,exec:8,grudge:3,pack:5,flair:6,talk:5,listen:6,perc:9,tech:3,nerve:4,noise:3,cover:7},   // 0.12.178 Chibi_Archer: keeps her distance, sharp-eyed
 csorc:{aggr:5,aware:7,pace:5,lane:5,self:4,range:1,plan:7,energy:7,size:6,exec:7,grudge:4,pack:6,flair:8,talk:3,listen:6,perc:7,tech:6,nerve:5,noise:5,cover:5},   // 0.12.178 Chibi_Sorcerer: quiet, showy with his magic
 cheez:{aggr:6,aware:7,pace:7,lane:5,self:3,range:9,plan:6,energy:5,size:5,exec:7,grudge:3,pack:3,flair:9,talk:6,listen:6,perc:6,tech:8,nerve:3,noise:6,cover:4},   // Cheez: a slasher with flair, witty, steady, a team guy
 edward:{aggr:5,aware:9,pace:6,lane:5,self:1,range:6,plan:8,energy:6,size:6,exec:8,grudge:3,pack:2,flair:6,talk:5,listen:8,perc:7,tech:6,nerve:2,noise:4,cover:6},   // Edward: a kind, loyal team guy: selfless, steady, smart, easygoing (Kyle: not a loudmouth)
 soldier:{aggr:5,aware:8,pace:5,lane:5,self:4,range:2,plan:8,energy:6,size:6,exec:9,grudge:4,pack:2,flair:3,talk:4,listen:8,perc:7,tech:5,nerve:1,noise:5,cover:8},   // 0.12.175 Soldier: disciplined, steady nerve, sticks with the group
 shoshi:{aggr:4,aware:9,pace:5,lane:5,self:2,range:0,plan:6,energy:5,size:5,exec:8,grudge:2,pack:3,flair:6,talk:8,listen:8,perc:8,tech:10,nerve:3,noise:3,cover:6},   // Shoshi: watches everybody, very techy, steady, chatty and funny   // starting values (Kyle's test numbers: middling with a few extremes, and very different between the two heroes)
 cultist:{aggr:4,aware:4,pace:4,lane:4,self:9,range:2,plan:5,energy:3,size:7,exec:6,grudge:8,pack:4,flair:8,talk:7,listen:3,perc:6,tech:3,nerve:3,noise:7,cover:3},   // Void_Cultist: hangs back, selfish, theatrical
 robot:{aggr:6,aware:6,pace:2,lane:3,self:3,range:5,plan:2,energy:4,size:7,exec:6,grudge:4,pack:6,flair:2,talk:4,listen:7,perc:6,tech:10,nerve:1,noise:10,cover:2},   // Moss_Mech: slow, steady, team-minded
 lumberjack:{aggr:7,aware:4,pace:6,lane:5,self:6,range:7,plan:5,energy:4,size:8,exec:4,grudge:8,pack:4,flair:6,talk:7,listen:1,perc:2,tech:2,nerve:4,noise:8,cover:1},   // Lumber_Jack: big, angry, goes for the big ones
 druid:{aggr:2,aware:9,pace:4,lane:3,self:0,range:2,plan:4,energy:4,size:5,exec:6,grudge:2,pack:6,flair:3,talk:6,listen:8,perc:7,tech:0,nerve:5,noise:1,cover:6},   // Druid: selfless healer
 archer:{aggr:2,aware:5,pace:3,lane:3,self:5,range:0,plan:2,energy:7,size:7,exec:9,grudge:4,pack:7,flair:2,talk:2,listen:7,perc:8,tech:1,nerve:2,noise:1,cover:7},   // Yumi_Archer: patient marksman
 chibi:{aggr:8,aware:3,pace:7,lane:6,self:6,range:9,plan:6,energy:3,size:6,exec:5,grudge:7,pack:3,flair:7,talk:9,listen:2,perc:3,tech:2,nerve:3,noise:2,cover:2},   // Chibi_Warrior: bold front-liner
 dog:{aggr:7,aware:9,pace:7,lane:6,self:1,range:10,plan:3,energy:5,size:3,exec:5,grudge:9,pack:1,flair:3,talk:6,listen:9,perc:9,tech:0,nerve:3,noise:4,cover:0},   // Guard Dog: loyal, alert, bites what comes near his people
 flannel_pal:{aggr:1,aware:9,pace:4,lane:2,self:5,range:1,plan:3,energy:6,size:2,exec:6,grudge:3,pack:2,flair:0,talk:3,listen:10,perc:7,tech:4,nerve:9,noise:2,cover:9},   // the companion (timid): hangs back, keeps her distance, picks off small ones next to him
 eng:{aggr:4,aware:6,pace:4,lane:4,self:4,range:4,plan:7,energy:5,size:6,exec:8,grudge:3,pack:6,flair:3,talk:4,listen:7,perc:7,tech:10,nerve:6,noise:5,cover:6},   // 0.12.75 Engineer: Shooter/Slasher 4 (6 toward shooter), very techy
 jp:{aggr:6,aware:5,pace:6,lane:5,self:2,range:4,plan:4,energy:5,size:5,exec:5,grudge:3,pack:2,flair:8,talk:10,listen:4,perc:5,tech:5,nerve:6,noise:7,cover:5},   // JP: loud, social, picks on everyone, steps in for family
 flannel:{aggr:3,aware:7,pace:5,lane:4,self:1,range:4,plan:3,energy:4,size:8,exec:7,grudge:8,pack:6,flair:1,talk:5,listen:6,perc:6,tech:6,nerve:2,noise:3,cover:8},   // Flannel_Man (Kyle's sheet)
 joel:   {aggr:6,aware:7,pace:8,lane:7,self:3,range:7,plan:7,energy:2,size:3,exec:4,grudge:3,pack:2,flair:8,talk:8,listen:3,perc:5,tech:5},   // The Spore Runners
 mathas: {aggr:3,aware:2,pace:3,lane:2,self:8,range:1,plan:2,energy:9,size:10,exec:9,grudge:9,pack:9,flair:1,talk:1,listen:1,perc:4,tech:6},  // Bounty Fiend
 zombie: {aggr:10,aware:1,pace:1,lane:3,self:9,range:10,plan:2,energy:5,size:5,exec:1,grudge:6,pack:6,flair:2},
 werewolf:{aggr:7,aware:2,pace:10,lane:9,self:9,range:10,plan:6,energy:3,size:1,exec:6,grudge:8,pack:8,flair:7,nerve:1,noise:6,cover:0},
 _default:{aggr:5,aware:5,pace:5,lane:5,self:5,range:5,plan:5,energy:5,size:5,exec:5,grudge:5,pack:5,flair:5},
};
const TRAIT_WORDS={aggr:['Careful','Reckless'],aware:['Hunter','Guardian'],pace:['Patient','Frantic'],lane:['Steadfast','Roaming'],self:['Loyal','Greedy'],
 range:['Sharpshooter','Brawler'],plan:['Stubborn','Fickle'],energy:['Spendthrift','Hoarder'],size:['Swarm-Breaker','Giant-Slayer'],exec:['Sloppy','Precise'],
 grudge:['Forgiving','Vengeful'],pack:['Pack','Lone'],flair:['Stoic','Showoff'],talk:['Silent','Loudmouth'],listen:['Headstrong','Team Player'],perc:['Tunnel-Visioned','Watchful'],nerve:['Steady','Jumpy'],noise:['Quiet','Clanky'],cover:['Exposed','Hunkered'],tech:['Old-Ways','Gearhead']};
/* 0.12.52 D&D mode (Kyle): each hero's sliders are rolled (2d6-2 each, so 0-10 with most near the middle) at the start of a run instead of fixed */
let DND_ROLLS=null;function setRunModes(run){DND_ROLLS=run&&run.dnd&&run.rolls?run.rolls:null;}
function rollPersonas(team){const out={};const keys=SLIDERS.map(s=>s[0]);for(const k of team){const r={};for(const s of keys)r[s]=Math.floor(Math.random()*6)+Math.floor(Math.random()*6);out[k]=r;}return out;}
function personaOf(u){if(!u.persona){const key=u.key||u.type;const b=(u.key&&DND_ROLLS&&DND_ROLLS[key])||PERSONA[key]||PERSONA._default;u.persona={talk:5,listen:5,perc:5,tech:5,nerve:5,noise:5,cover:5,...b};
  if(u.insp)for(const [k,d] of Object.entries((INSP[u.insp]||{}).sl||{})){const v=u.persona[k]+d;if(v>=0&&v<=10)u.persona[k]=v;}   // Kyle: a slide past 0 or 10 doesn't move at all
  if(!u.key){for(const k in u.persona)u.persona[k]=Math.max(0,Math.min(10,u.persona[k]+Math.round((Math.random()-.5)*2)));}   // monsters vary a little
  u.moods=[];}return u.persona;}
function addMood(u,shift,secs,name){personaOf(u);u.moods.push({shift,t:secs,name});}
function trait(u,k){if(k==='range'&&u&&u.key==='robot'&&u.lzReload>0)return 1;   /* 0.12.135 (Kyle): Warhound goes full Slasher while his lazer recharges, then back to normal */
  const p=personaOf(u);let v=p[k];for(const m of u.moods)v+=(m.shift[k]||0);return Math.max(0,Math.min(10,v))/10;}   // 0..1
function personaTitle(u){const p=personaOf(u);const ex=Object.keys(p).filter(k=>k in TRAIT_WORDS).map(k=>[k,Math.abs(p[k]-5),p[k]]).sort((a,b)=>b[1]-a[1]);
  const w=ex.slice(0,2).map(([k,,v])=>TRAIT_WORDS[k][v>=5?1:0]);return w.join(' ');}
function personaLines(u){const p=personaOf(u);return SLIDERS.map(([k,l,r])=>`${l} ${'▮'.repeat(p[k])}${'▯'.repeat(10-p[k])} ${r}`);}
const SHOW_LINES={hero:['HA!','Too easy!','Next!','Boom!','Did you see that?'],zombie:['Brainsss','Grrah!','*moans*'],werewolf:['AWOOO!','*snarl*','Grrr!']};
/* 0.12.38 (Kyle): every rock, log, car and ambulance can be looted ONCE in total; nobody picks one another unit is already searching */
/* 0.12.58 (Kyle): anyone can search anything. Debris (rocks, logs, stumps, bushes) hides herbs; cars hide spare parts, supplies and gear.
   The deck perk for it (Herbalist for debris, Scavenger for cars) makes it quick and likely to pay off; without it, it's slow and usually comes up empty.
   Returns 'perk' (my specialty), 'weak' (I can try), or null (nothing in it for me). */
function searchFit(h,o){if(!o||o.k==='car_ambulance')return null;const sp=insP(h),car=CONTAINER.test(o.k);if(o.k==='city_lootbox'||o.k==='city_front')return o.looted?null:'perk';   /* 0.12.119: a loot box is worth anyone's time */
  if(car){if(sp==='scavenger')return (h.kit||[]).length<2?'perk':'weak';return 'weak';}
  if(!SEARCHABLE.test(o.k))return null;if(sp==='herbalist')return (h.herbs||0)<3?'perk':null;return (h.herbs||0)<1?'weak':null;}
/* 0.12.58 (Kyle): the Warhound talks like a machine: clipped, capitals, no feelings, still readable.
   'I'll kill the alarm!' -> 'THIS UNIT WILL KILL THE ALARM.'  'They got them!' -> 'ALERT: THEY GOT THEM.' */
/* 0.12.139 (Kyle): JP doesn't hold back irl, so about a third of his lines get some salt on them */
/* 0.12.141 (Kyle): a little salt for the others: the traveling companion swears a fair bit, everyone else now and then (JP stays the worst) */
function saltify(s,rate){const r=Math.random();if(r>rate)return s;const P=['Shit, ','Damn, ','Hell, ','Christ, ','Ah, crap. '],S=[' Damn it!',' Holy shit.',' Hell yeah!',' Shit.',' Son of a bitch.'];
  if(r<rate/2)return P[Math.floor(Math.random()*P.length)]+s.charAt(0).toLowerCase()+s.slice(1);return s.replace(/[.!?]*$/,'')+'!'+S[Math.floor(Math.random()*S.length)];}
function jpify(s){const r=Math.random();if(r>.45)return s;   /* 0.12.139 (Kyle): hardcore, no kids playing this */
  /* 0.12.233 (Kyle): JP saves his meanness for the zombies. A line aimed at the team (you / we / guys / a name) gets a friendly cuss or, rarely, a light jab;
     anything else gets the full zombie-directed insult. */
  const P=['Shit! ','Fuck! ','Fuckin\' hell, ','Goddamn, ','Holy shit, ','Oh fuck me. ','Jesus fuckin\' Christ, ','Ah shit, ','Bullshit! '];
  const Z=[' Eat shit, zombie!',' Stay dead, fucker!',' Rot in hell!',' Get fucked, deadass!',' Piece of shit corpse.',' Fuck off back to the grave!',' Dumbass zombies.',' Motherfuckin\' biters.',' Ugly-ass corpse!'];
  const A=[' Fuck yeah!',' Holy shit.',' Let\'s fuckin\' go!',' Shit\'s crazy.',' I got you.',' Love you guys.',' Goddamn right.'],J=[' Keep up, slowpoke.',' Try not to die, nerd.',' You owe me one.'];
  const ally=/\b(you|your|you're|guys|team|we|us|our|buddy|bro)\b/i.test(s)||(typeof NICK!=='undefined'&&Object.values(NICK).some(n=>s.includes(n)));
  if(r<.22)return P[Math.floor(Math.random()*P.length)]+s.charAt(0).toLowerCase()+s.slice(1);
  const pool=ally?(Math.random()<.15?J:A):Z;return s.replace(/[.!?]*$/,'')+'!'+pool[Math.floor(Math.random()*pool.length)];}
function robotize(s){if(/^[A-Z0-9 :.,'\-?]+$/.test(s))return s;let t=' '+s+' ';
  const R=[[/\bI'm\b/gi,'THIS UNIT IS'],[/\bI'll\b/gi,'THIS UNIT WILL'],[/\bI've\b/gi,'THIS UNIT HAS'],[/\bI\b/g,'THIS UNIT'],[/\bme\b/gi,'THIS UNIT'],[/\bmy\b/gi,'THIS UNIT\'S'],
    [/\byou're\b/gi,'YOU ARE'],[/\bcan't\b/gi,'CANNOT'],[/\bdon't\b/gi,'DO NOT'],[/\bwon't\b/gi,'WILL NOT'],[/\bit's\b/gi,'IT IS'],[/\bthat's\b/gi,'THAT IS'],[/\blet's\b/gi,'PROCEED:'],
    [/\bgo go go\b/gi,'ADVANCE'],[/\bhelp\b/gi,'ASSISTANCE'],[/\bnope\b/gi,'NEGATIVE'],[/\byes\b/gi,'AFFIRMATIVE'],[/\bno\b(?=[!.?, ])/gi,'NEGATIVE'],[/\bok(ay)?\b/gi,'ACKNOWLEDGED'],[/\bthanks?( you)?\b/gi,'GRATITUDE LOGGED'],
    [/\b(ugh|oof|ow|ouch|argh|aah+|aaah+)\b/gi,'DAMAGE'],[/\bwhoa\b/gi,'ANOMALY'],[/\bhaha+\b/gi,'HA. HA.']];
  for(const [r,w] of R)t=t.replace(r,w);
  t=t.trim().replace(/\*[^*]*\*/g,'').replace(/[!]+/g,'.').replace(/\?+/g,'?').replace(/\.\.\.+/g,'.').replace(/\s+/g,' ').toUpperCase().trim();if(!/[.?]$/.test(t))t+='.';
  const pre=Math.random();return (pre<.18?'ALERT: ':pre<.3?'*BEEP* ':pre<.38?'QUERY: ':'')+t;}
/* 0.12.63 (Kyle): ability lists always show the actives first and the passive last, on every character card */
/* 0.12.63: temporary move-speed buffs (True_Grit +25%, Cozy +10%) */
/* 0.12.63 (Kyle) COZY: lasts 10s; +0.25 life and +0.25 energy every 0.5s; +10% melee attack speed and +10% move speed.
   Set_Camp keeps refreshing it for anyone in range; the Hearth camp upgrade gives it to everyone at the start of a stage. */
const COZY={dur:10,hp:.5,en:.5,melee:.1,move:.1};
function giveCozy(o){o.cozyT=Math.max(o.cozyT||0,COZY.dur);}
/* 0.12.64 (Kyle): proximity zone shared by Proximity_Bomb and the enemy rust mines: half-width w0 in its own lane, w1 one lane up or down */
var DEFUSE_D=12;   /* 0.12.156: where a defuser stands, world px left of the mine (tested for a safe sweet spot) */
function inSmoke(g,x,gy){return (g.clouds||[]).some(S=>S.A&&S.A.rev&&Math.abs(S.x-x)<S.r&&Math.abs((S.gy)-(gy!=null?gy:g.G))<14);}   /* 0.12.199 inside the Soldier's smoke */
const SG_SENSE=42;   /* 0.12.203: shotgun trap sensor reach, world px (125 screen px) */
function bombTrig(g,x,gy,Z,who){Z=Z||{w0:6.7,w1:3.3};for(const e of (who||g.enemies)){if(e.dead||e.fly||e.rush)continue;   /* 0.12.201: JP mid-Familia-dash triggers nothing */const ex=e.key?g.heroX(e):e.x,dz=Math.abs(((e.gy!=null?e.gy:g.G))-gy),dx=Math.abs(ex-x)-(e.boss?e.w*.5:0);
    if((dz<=3.5&&dx<=Z.w0)||(dz>3.5&&dz<=11.5&&dx<=Z.w1))return e;}return null;}
function dynMv(h){let m=1-(h.hunger>0?HUNGER.spd[h.hunger]:0);if(h.key==='jp'&&!(h.highT>0)&&(h.soberT||0)>10)m-=.1;if(h.gritT>0)m+=h.gritMv||0;if(h.cozyT>0)m+=.1;return m;}
function abOrder(L){L=L||[];return [...L.filter(a=>!a.passive),...L.filter(a=>a.passive)];}
function fleshy(u){return !(u&&u.key==='robot');}
function g_free(o,h){return !o.looted&&!(o.searchBy&&o.searchBy!==h&&o.searchBy.alive&&o.searchBy.search&&o.searchBy.search.o===o);}
const Brain={
  // one shared picture of the battlefield per tick: every unit can see every other unit
  snapshot(g){const H=g.alive(),E=g.enemies.filter(e=>!e.dead&&e.x<g.W+10);const onTarget=new Map();
    for(const h of H)if(h.plan&&h.plan.tgt)onTarget.set(h.plan.tgt,(onTarget.get(h.plan.tgt)||0)+1);
    const heat=new Map();for(const e of E)if(e.target)heat.set(e.target,(heat.get(e.target)||0)+1);
    const maxE=Math.max(1,...E.map(e=>e.max||1)),maxH=Math.max(1,...H.map(h=>h.max||1));
    g.bb={H,E,onTarget,heat,maxE,maxH,t:g.t};},
  // the decision loop: how often a unit rethinks comes from On Track/New Plan, Slow/Fast and its current mood
  due(g,u,dt){u.thinkT=(u.thinkT==null?Math.random()*.4:u.thinkT)-dt;if(u.thinkT>0)return false;
    u.thinkT=(.12+4.2*Math.pow(1-trait(u,'plan'),1.5)+1.2*(1-trait(u,'pace'))+Math.random()*.25)*(u.thirst>0?THIRST.slow[u.thirst]:1);return true;},   // 0.12.72: thirst slows decisions   // New Plan 10 rethinks ~8x a second; On Track 0 holds a plan 4-5s
  tick(u,dt){if(u.moods)u.moods=u.moods.filter(m=>(m.t-=dt)>0);if(u.grudgeT>0)u.grudgeT-=dt;if(u.pauseT>0)u.pauseT-=dt;if(u.panicT>0)u.panicT-=dt;if(u.sprayT>0)u.sprayT-=dt;},
  // score every foe a unit could fight
  pickTarget(g,u,foes,friends,isHero){if(!foes.length)return null;const bb=g.bb;const A=trait(u,'aware'),ef=1-A;
    const big=trait(u,'size'),venge=trait(u,'grudge'),lone=trait(u,'pack'),selfish=trait(u,'self'),opt=trait(u,'exec'),stay=1-trait(u,'lane'),commit=1-trait(u,'plan'),
          aggr=trait(u,'aggr'),slash=trait(u,'range');
    const ux=isHero?g.heroX(u):u.x,maxSize=isHero?bb.maxE:bb.maxH;const weakAlly=friends.reduce((b,f)=>!b||f.hp/f.max<b.hp/b.max?f:b,null);
    let best=null,bs=-1e9,why='';
    for(const c of foes){const cx=c.owner?c.x:(c.key?g.heroX(c):c.x);const d=Math.abs(cx-ux);let sc=0,w=[];
      if(!isHero&&c.key){const nz=trait(c,'noise');sc+=1.6*(nz-.5)*Math.max(0,1-d/160);if(nz>.7)w.push('heard them');}   /* 0.12.44 Light-Footed <-> Loud: enemies home in on loud heroes */
      // IF it is close THEN it's easier (enemy-focused units care most; slashers care even more)
      const near=Math.max(0,1-d/220);sc+=near*(.4+3.2*slash)*(.2+1.6*ef);
      // IF it is in my lane THEN good, unless I like switching lanes
      if(c.laneI!=null&&u.laneI!=null&&c.laneI===u.laneI){sc+=3*stay*stay;w.push('in my lane');}
      // IF I prefer big THEN size counts up, ELSE small ones count up
      const sz=(c.max||10)/maxSize;sc+=(big*sz+(1-big)*(1-sz))*3.5*Math.abs(big-.5)*2;
      // 0.12.137 (Kyle) IF it's a Nemesis THEN take it seriously: a big pull to it (more per rank, more if it downed someone I know, more for grudge-holders)
      if(isHero&&c.nem){sc+=3+1.6*c.nem.rank+3*venge;if((c.nem.kills||[]).includes(u.key))sc+=3;w.push(c.nem.name.split(' ')[0]+'!');}
      // IF it hit me recently AND I hold grudges THEN go get it
      if(u.lastHitBy===c&&u.grudgeT>0){sc+=7*Math.pow(venge,2);if(venge>.5)w.push('grudge');}
      // IF allies are already on it THEN pack hunters join, lone wolves look elsewhere
      const n=bb.onTarget.get(c)||(c.key?0:0);const allies=isHero?(bb.onTarget.get(c)||0):(bb.heat.get(c)||0);
      sc+=allies*(2.2*Math.pow(1-lone,1.5)-2*Math.pow(lone,1.5))*(.4+.6*A);if(allies&&lone<.4)w.push('with the pack');
      // IF it is hurting my weakest friend THEN selfless units step in
      if(weakAlly&&c.target===weakAlly&&weakAlly.hp/weakAlly.max<.7){sc+=6*Math.pow(1-selfish,1.5)*(.3+.7*A)*(1-weakAlly.hp/weakAlly.max);if(selfish<.5)w.push('protecting');}
      // IF it is nearly dead THEN optimal units finish it
      if(c.hp!=null&&c.max)sc+=Math.pow(opt,1.5)*(1-c.hp/c.max)*3;
      // IF it is my current target THEN stubborn units keep at it
      if(u.plan&&u.plan.tgt===c)sc+=4*Math.pow(commit,1.5);
      // 0.12.28 Tunnel Vision <-> Perceptive: IF tunnel-visioned THEN the obvious pick (current target, the nearest) counts much more;
      //   IF perceptive THEN threats sneaking onto allies behind the line, or tucked behind bigger enemies, count more
      {const pc=trait(u,'perc');if(u.plan&&u.plan.tgt===c)sc+=2.5*(1-pc);sc+=near*1.6*(1-pc);
       if(isHero&&c.target&&c.target!==u&&c.target.key){const mx=bb.H.reduce((s,o)=>s+g.heroX(o),0)/Math.max(1,bb.H.length);if(g.heroX(c.target)<=mx){sc+=2.4*pc;if(pc>.6)w.push('spotted it sneaking up');}}
       if(isHero&&!c.boss&&bb.E.some(o=>o!==c&&(o.max||0)>(c.max||0)*1.5&&Math.abs(o.x-c.x)<14))sc+=1.2*pc;}
      // IF an ally called this one out AND I chose to listen THEN it jumps up my list
      if(isHero){const O=Comms.ord(u,g,['focus','help','flank','boss','reload','tapped','burst','lane','reviving']);if(O){const ot=O.tgt||(O.type==='boss'?g.boss:null);
        if(ot===c){sc+=3+5*O.w;w.unshift('called: '+O.type);}
        else if((O.type==='help'||O.type==='reload'||O.type==='tapped'||O.type==='reviving')&&O.from&&c.target===O.from){sc+=2+4*O.w;w.unshift('covering '+Comms.name(O.from));}}}
      // IF it is a big threat to me and I'm careful THEN I'd rather not walk into it... unless I'm reckless
      if(!isHero&&u.E&&u.E.backline&&!g.isMeleeHero(c)){sc+=2.5;w.push('going for the back line');}   // IF I'm a back-line hunter THEN the squishy ones first
      if(isHero&&c.dmg)sc+=(aggr-.5)*.4*Math.min(2,c.dmg/10);
      sc+=(Math.random()-.5)*(.05+4*Math.pow(1-opt,1.5));   // sloppy units are all over the place; optimal ones are near-perfectly consistent
      if(sc>bs){bs=sc;best=c;why=w[0]||(big>.6?'big target':big<.4?'small target':'closest');}}
    return {tgt:best,why};},
  // which lane to stand in
  pickLane(g,u,tgt,isHero){const bb=g.bb;const cur=u.laneI;
    /* 0.12.37 (Kyle): IF I'm a companion AND my partner is up AND I'm not badly hurt THEN circle him: lanes swing above, level with and below his */
    {const O=Brain.orbitOf(g,u);if(O)return Math.max(0,Math.min(LANES.length-1,u.owner.laneI+O.dl));}const roam=trait(u,'lane'),A=trait(u,'aware'),lone=trait(u,'pack'),aggr=trait(u,'aggr'),commit=1-trait(u,'plan');
    const melee=isHero?g.isMeleeHero(u):true;let best=cur,bs=-1e9;
    const reach=roam<.1?0:roam<.45?1:roam<.8?2:4;   // Stay In Your Lane 0 never leaves it; Switch It Up 10 can cross the whole field
    for(let l=Math.max(0,cur-reach);l<=Math.min(LANES.length-1,cur+reach);l++){let sc=0;
      if(l===cur)sc+=3*(1-roam)+.6*commit-1.2*roam*roam;   // IF I stay put by nature THEN my lane wins ties
      if(isHero){const O=Comms.ord(u,g,['lane','flank','help']);const ol=O?(O.type==='lane'?O.lane:O.type==='flank'?(O.tgt&&O.tgt.laneI):(O.from&&O.from.laneI)):null;if(ol!=null&&l===ol)sc+=2+4*O.w;}   // IF called to a lane THEN go there
      sc-=Math.abs(l-cur)*(.8-.75*roam);
      {const ux=isHero?g.heroX(u):u.x;if(g.laneBlocked(l,isHero?ux-8:ux-50,isHero?ux+50:ux+8))sc-=6;}   // IF an obstacle sits in this lane just ahead THEN don't pick it
      if(tgt&&tgt.laneI!=null){if(l===tgt.laneI)sc+=melee?2.4:.8;}   // melee has to share a lane with what it hits
      const foesHere=bb.E.filter(e=>e.laneI===l).length,friendsHere=(isHero?bb.H:bb.E).filter(o=>o!==u&&o.laneI===l).length;
      sc+=foesHere*(isHero?(aggr-.5):0)*1.6;   // IF careful THEN avoid crowded enemy lanes; IF reckless THEN wade in
      sc+=friendsHere*(A*(1-lone)*1.4-lone*1.3);   // ally-minded pack units bunch up, lone wolves spread out
      if(sc>bs){bs=sc;best=l;}}
    return best;},
  // how far ahead of / behind its formation spot a hero stands, and how fast it moves
  /* companion orbit: an ellipse around the partner, side to side in x while the lane swings up and down; Ally Awareness keeps it tighter, Fast and Furious circles quicker */
  /* 0.12.43 Steady <-> Panicky: IF something scary happens (boss, car alarm, an ally goes down near me, I get swarmed, my HP drops low)
     THEN panicky units may lose it for a moment: bolt away, freeze up, or spray wild shots. Steady ones just keep working. */
  panic(g,u,why){if(!u||!u.alive||g.demo||(u.panicCd||0)>g.t||u.riseT>0)return;const nv=trait(u,'nerve');if(Math.random()>Math.pow(nv,1.4)*.85)return;u.panicCd=g.t+7+6*(1-nv);
    const C=u.base&&u.base.char;const shooter=C&&C.ranged&&trait(u,'range')<.5;const r=Math.random();
    if(shooter&&r<.35){u.sprayT=2.5+2*nv;}else if(r<.6+.2*(1-trait(u,'aggr'))){u.panicT=2+1.5*nv;addMood(u,{aggr:-6,pace:5},u.panicT,'panic');}else{u.pauseT=Math.max(u.pauseT||0,.6+.8*nv);}
    u.thinkT=0;Comms.bubble(g,u,Comms.pick(why==='boss'?['What is THAT?!','Oh no. Oh no no no.','We are so dead!']:why==='alarm'?['Turn it off turn it off!','They\'re coming!','Not the alarm!']:why==='down'?['No no no, get up!','They got them!','Who\'s next?!']:['AAAH!','Too many!','Nope nope nope!','Get them off me!']));},
  orbitOf(g,u){
    if(u.dog){const H=g.heroes.filter(h=>h.alive);if(!H.length)return null;
      if(!u.wardT||g.t>u.wardT||!u.owner||!u.owner.alive){u.owner=H.reduce((b,h)=>{const s=(g.bb.heat.get(h)||0)*2+(1-h.hp/h.max)*3;const sb=(g.bb.heat.get(b)||0)*2+(1-b.hp/b.max)*3;return s>sb?h:b;},H[0]);u.wardT=g.t+1.2;}
      const w=u.owner,wx=g.heroX(w),dx0=g.heroX(u);   /* 0.12.58 (Kyle): more aggressive: he goes after anything within 48px of his person OR within 85px of himself near the party, nearest first */
      const th=g.enemies.filter(e=>!e.dead&&!e.fly&&e.x<g.W-4&&(Math.abs(e.x-wx)<48||(Math.abs(e.x-dx0)<85&&H.some(h=>Math.abs(e.x-g.heroX(h))<110)))).sort((p,q)=>Math.abs(p.x-wx)*.5+Math.abs(p.x-dx0)-(Math.abs(q.x-wx)*.5+Math.abs(q.x-dx0)))[0];
      if(th){const tl=LANES.reduce((b,y,i)=>Math.abs(y-(th.gy!=null?th.gy:g.G))<Math.abs(LANES[b]-(th.gy!=null?th.gy:g.G))?i:b,0);return {dx:th.x-wx-8,dl:tl-w.laneI,ph:0,attack:1};}   /* IF something is on my person THEN go bite it */
      if(u.orbPh==null)u.orbPh=Math.random()*6.28;const ph=g.t*.9+u.orbPh;return {dx:Math.sin(ph)*16,dl:Math.round(Math.cos(ph)*1.2),ph};}   /* ELSE pace around them */
    if(!u.pet||!u.owner||!u.owner.alive)return null;if(u.hp/u.max<.3&&(g.bb.heat.get(u)||0))return null;
    if(u.orbPh==null)u.orbPh=Math.random()*6.28;const A=trait(u,'aware'),pace=trait(u,'pace');const ph=g.t*(.45+.5*pace)+u.orbPh;
    const R=16+18*(1-A);return {dx:Math.sin(ph)*R,dl:Math.round(Math.cos(ph)*1.2),ph};},
  pickPosition(g,h,tgt){const bb=g.bb;const aggr=trait(h,'aggr'),slash=trait(h,'range'),pace=trait(h,'pace'),A=trait(h,'aware'),selfish=trait(h,'self');
    {const O=Brain.orbitOf(g,h);if(O)return {xoff:g.heroX(h.owner)+O.dx-g.home(h),intent:O.attack?'charge':'orbit',runMul:O.attack?2:.6+1.2*pace};}
    if(h.panicT>0){h.search=null;h.order=null;return {xoff:-95,intent:'retreat',runMul:2};}   /* panicking: running for it (drops any search, ignores orders) */
    let xoff=(aggr-.5)*70+(slash-.5)*150,intent='hold';   // Shooter (0) hangs well back, Slasher (10) stands well forward; no class rules
    const hp=h.hp/h.max,danger=bb.heat.get(h)||0;const near=bb.E.filter(e=>Math.abs(e.x-g.heroX(h))<45).length;
    // 0.12.11 (Kyle): plans account for ability cooldowns and distances. IF a close-range ability is ready (and affordable) THEN
    //   step toward the fight; IF only ranged ones are ready THEN keep to their range; IF the big ones are all on cooldown AND hurt
    //   THEN hang back until they come back.
    // 0.12.22 revive: IF an ally is downed THEN most units go help them up. Selfless and pack-minded units are keenest; IF enemies are
    //   standing over the body THEN only the bold (Blind Aggression) still go in. The decision sticks for ~2s so they don't dither.
    {const D=g.heroes.filter(o=>!o.alive&&o.downed&&o!==h).sort((p,q)=>Math.abs(p.x-g.heroX(h))-Math.abs(q.x-g.heroX(h)))[0];
     if(D&&!h.pet){if(!h.revDecide||h.revDecide.D!==D||g.t>h.revDecide.until){const danger=bb.E.filter(e=>Math.abs(e.x-D.x)<40).length,swarm=bb.E.filter(e=>Math.abs(e.x-D.x)<22).length;const lone=trait(h,'pack');
         let w=.62+.3*(1-selfish)+.18*(1-lone)+.12*A-.12*(hp<.35?1:0);if(danger)w*=(.35+.85*aggr)*(1.25-.6*trait(h,'nerve'));   /* 0.12.58 (Kyle): more careful: IF the body is swarmed THEN each zombie right on it cuts the odds hard; 3+ and only the reckless try */if(swarm)w*=Math.pow(.5+.25*aggr,swarm)*(h.defib?1.5:1);   /* Steady units still go in under fire, Panicky ones balk */w=Math.max(.05,Math.min(.97,w));if(inSmoke(g,D.x,D.gy))w=Math.max(w,.92);   /* 0.12.199 (Kyle): a downed ally in the Soldier's smoke: everyone is keen to go get them */
         h.revDecide={D,until:g.t+1.6+Math.random()*.8,go:Math.random()<(h.defib?Math.min(.97,w+.45):w)};}   /* IF I carry a Defibrillator THEN I go for the downed ally far more readily (it is instant) */
       if(h.revDecide.go){const runMul=.45+1.4*pace;return {xoff:0,intent:'revive',runMul,reviveD:D,reviveLane:D.laneI};}}}
    // 0.12.30 car alarm: IF an alarm is blaring nearby THEN units go shut it off. Techy units (and Perceptive ones) are much keener;
    //   IF zombies are already around the car THEN only the bold go. Primitive units mostly leave it to someone else.
    {const car=(g.obst||[]).filter(o=>o.alarmT>0&&o.x>30&&Math.abs(o.x-g.heroX(h))<140).sort((p,q)=>Math.abs(p.x-g.heroX(h))-Math.abs(q.x-g.heroX(h)))[0];
     if(car&&!h.pet){if(!h.alDecide||h.alDecide.o!==car||g.t>h.alDecide.until){const tech=trait(h,'tech'),danger=bb.E.filter(e=>Math.abs(e.x-car.x)<40).length;
         let w=(.4+.55*tech+.12*trait(h,'perc'))*(1.15-.35*trait(h,'nerve'));if(danger)w*=.55+.6*aggr;   /* an alarm is treated as a big threat: most units go, Techy ones nearly always */h.alDecide={o:car,until:g.t+1.2+Math.random()*.8,go:Math.random()<Math.min(.95,w)};
         if(h.alDecide.go&&Math.random()<.5)Comms.bubble(g,h,Comms.pick(['I\'ll kill the alarm!','On the alarm!','Leave the car to me!']));}
       if(h.alDecide.go){const runMul=.45+1.4*pace;return {xoff:0,intent:'disarm',runMul,goTo:{ob:car},reviveLane:g.searchSpot(car,h).lane};}}}
    // 0.12.33 Medkit: IF I carry one AND an ally is under 50% THEN take it to them (selfless units most of all)
    /* 0.12.200 (Kyle): IF an ammo crate is within 50 AND I shoot with a magazine AND I haven't had my free mag from it AND I'm under 60% of a mag (any amount if Squander)
       AND nothing's right on top of the crate THEN run over and grab it. Pack Hunters go a bit farther for it; Panicky won't if zombies are within 30 of it. */
    if(g.crates&&g.crates.length&&h.base.char&&h.base.char.ranged&&h.base.char.ranged.clip>0){const C4=h.base.char.ranged,hx4=g.heroX(h);const K=g.crates.find(K=>!K.taken.has(h)&&Math.abs(K.x-hx4)<(trait(h,'pack')<.4?65:50));
      if(K&&((h.ammo||0)<C4.clip*.6||trait(h,'energy')<.35||h.reloadT>0)){const zn=bb.E.filter(e=>Math.abs(e.x-K.x)<(trait(h,'nerve')>.6?30:14)).length;if(!zn)return {xoff:0,intent:'crate',runMul:1.2+pace,goTo:{crate:K},reviveLane:K.laneI};}}
    if(h.medkit){const H=g.alive().filter(o=>o!==h&&!o.pet&&fleshy(o)&&o.hp/o.max<.62-.3*trait(h,'energy')).sort((p,q)=>p.hp/p.max-q.hp/q.max)[0];if(H&&Math.random()<.6+.35*(1-selfish)){const runMul=.45+1.4*pace;return {xoff:0,intent:'herb',runMul,goTo:H,reviveLane:H.laneI};}}
    // ambulance: IF I have no Medkit AND an unsearched ambulance is close (closer for Tunnel Vision) AND it's safe enough THEN search it
    if(!h.medkit&&!h.search&&!h.pet){const look=35+45*trait(h,'perc');const o=(g.obst||[]).find(o=>o.k==='car_ambulance'&&g_free(o,h)&&o.x>30&&Math.abs(o.x-g.heroX(h))<look);
      if(o){if(!h.amDecide||h.amDecide.o!==o||g.t>h.amDecide.until){const danger=bb.E.filter(e=>Math.abs(e.x-o.x)<60).length;h.amDecide={o,until:g.t+1.5+Math.random(),go:Math.random()<(danger?.2+.5*aggr:.6+.3*trait(h,'perc'))};}
        if(h.amDecide.go){const runMul=.45+1.4*pace;return {xoff:0,intent:'search',runMul,goTo:{ob:o},reviveLane:g.searchSpot(o,h).lane};}}}
    /* 0.12.51 Sapper: IF a spotted mine is near AND nothing is around it THEN go defuse it (Techy units are keener) */
    if(!h.pet){const M=(g.mines||[]).find(M=>!M.owner&&M.armed&&M.spotted&&M.x>30&&Math.abs(M.x-g.heroX(h))<95&&!bb.E.some(e=>Math.abs(e.x-M.x)<35)&&!g.heroes.some(o=>o!==h&&o.alive&&o.defuse&&o.defuse.M===M));
      /* IF a spotted mine is near AND it's calm AND nobody else is on it THEN: a Sapper usually goes for it; anyone else only if their own odds look decent (bolder ones gamble more) */
      if(M){if(!h.dfDecide||h.dfDecide.M!==M||g.t>h.dfDecide.until){const od=defuseOdds(h);h.dfDecide={M,until:g.t+2,go:Math.random()<(hasPerk(h,'sapper')?.85+.12*trait(h,'tech'):Math.max(0,od-.22)*1.3*(.45+.55*aggr))};}
        if(h.dfDecide.go){if(!h.defuse||h.defuse.M!==M)h.defuse={M,need:(2.4-1.5*trait(h,'tech'))*(hasPerk(h,'sapper')?1:1.3)*(1+.3*(.5-trait(h,'pace')))};return {xoff:0,intent:'defuse',runMul:.45+1.4*pace,goTo:{mine:M},reviveLane:M.l};}}}
    /* 0.12.45 thievery: IF I'm a Pickpocket AND truly Selfish (8+) AND nothing is in my face AND an ally nearby carries something good THEN I may sidle over and lift it.
       More Selfish = more likely; Light-Footed thieves try it more (they don't get caught as much); a Perceptive one spots what's worth taking. */
    if(insP(h)==='pickpocket'&&selfish>=.75&&!h.pet&&!(bb.heat.get(h)||0)&&(h.thiefCd||0)<=g.t){const goods=o=>(o.defib&&!h.defib)||(o.medkit&&!h.medkit)||((o.kit||[]).length&&(h.kit||[]).length<2)||(o.herbs>0&&(h.herbs||0)<3);
      const V=g.heroes.filter(o=>o!==h&&o.alive&&goods(o)&&Math.abs(g.heroX(o)-g.heroX(h))<70&&!bb.E.some(e=>Math.abs(e.x-g.heroX(o))<35)).sort((p,q)=>Math.abs(g.heroX(p)-g.heroX(h))-Math.abs(g.heroX(q)-g.heroX(h)))[0];
      if(V){if(!h.thDecide||h.thDecide.V!==V||g.t>h.thDecide.until)h.thDecide={V,until:g.t+3+Math.random()*2,go:Math.random()<(selfish-.75)*2.4*(.45+.55*(1-trait(h,'noise')))*(.6+.4*trait(h,'perc'))};
        if(h.thDecide.go)return {xoff:0,intent:'sneak',runMul:.5,goTo:V,reviveLane:V.laneI};}}
    /* 0.12.243 (Kyle) just helped up: for 2s I scramble AWAY from the zombies (toward the rear, or toward the side with fewer of them) */
    if(h.upT>0){const hx=g.heroX(h),near=bb.E.filter(e=>Math.abs(e.x-hx)<90);const fr=near.filter(e=>e.x>=hx).length,bk=near.length-fr;const dir=fr>=bk?-1:1;
      h.thinkT=Math.min(h.thinkT||0,.25);h.abWhy='BACK UP: getting clear';h.abWhyT=g.t+1;return {xoff:0,intent:'flee',runMul:1.6,goTo:{spot:1,x:Math.max(8,Math.min(g.W-8,hx+dir*45))},reviveLane:h.laneI};}
    /* 0.12.243 (Kyle) Dice-Boys_Banner: everyone knows it's a good spot. IF a banner is up (2s+ left) and I'm outside it THEN maybe head over:
         the third hero when the other two are already in it: very likely (85%, more with Team Player), unless I'm under 25% with zombies between;
         anyone else: if nothing is on me and it's within 600px, 45% + Team Player. Once in, I stay in it rather than drift back to my spot. Decided once a banner. */
    if(!h.pet&&g.banners&&g.banners.length&&!(h.perch)){const B=g.banners.filter(B=>B.t>2).sort((a,b)=>Math.abs(a.x-g.heroX(h))-Math.abs(b.x-g.heroX(h)))[0];
      if(B){const hx=g.heroX(h),inside=Math.abs(hx-B.x)<B.r*.85,team=g.alive().filter(o=>!o.pet),others=team.filter(o=>o!==h&&Math.abs(g.heroX(o)-B.x)<B.r).length,third=team.length>=3&&others===team.length-1;
        const onMe=bb.E.filter(e=>Math.abs(e.x-hx)<14).length;
        if(!inside){if(!h.bnDecide||h.bnDecide.B!==B||(third&&!h.bnDecide.third))h.bnDecide={B,third,go:third?Math.random()<.85+.15*trait(h,'pack')&&!(hp<.25&&bb.E.some(e=>(e.x-hx)*(B.x-hx)>0&&Math.abs(e.x-hx)<Math.abs(B.x-hx))):onMe===0&&Math.abs(B.x-hx)<200&&Math.random()<.45+.4*trait(h,'pack')};
          if(h.bnDecide.go){h.abWhy=third?'BANNER: the last Dice Boy, getting in!':'BANNER: good spot';h.abWhyT=g.t+2;return {xoff:0,intent:'banner',runMul:third?1.6:1,goTo:B,reviveLane:h.laneI};}}
        else{const hm=g.home(h);if(Math.abs(hm-B.x)>B.r*.8&&onMe===0)return {xoff:0,intent:'banner',runMul:.6,goTo:B,reviveLane:h.laneI};}}}
    // 0.12.27 Bodyguard (Family Matters, a deck-scripted behavior): IF an ally is hurt (under 90%) THEN stand beside the most hurt one
    /* 0.12.211 Edward (Loyal_to_a_Fault): IF a friend is under 35% and he's more than 120 world px from them (out of his reach to take their hits) AND he isn't under 25% himself
       THEN he goes to stand with them (Pack Hunter goes quicker; Ally Awareness picks the worst-off friend, otherwise the nearest hurt one) */
    if(h.key==='edward'&&!(hp<.25)){const al=g.alive().filter(o=>o!==h&&!o.pet&&o.hp/o.max<(h.cap&&h.cap.ed_bond?.6:.35));   /* Unbreakable_Bond: he guards anyone under 60% */const aw=trait(h,'aware');const H=al.sort((p,q)=>aw>.6?p.hp/p.max-q.hp/q.max:Math.abs(g.heroX(p)-g.heroX(h))-Math.abs(g.heroX(q)-g.heroX(h)))[0];
      if(H&&Math.abs(g.heroX(H)-g.heroX(h))>120){h.abWhy='LOYAL: getting to '+Comms.name(H);h.abWhyT=g.t+2;return {xoff:0,intent:'guard',runMul:.6+1.2*(1-trait(h,'pack')),goTo:H,reviveLane:H.laneI};}}
    if(insP(h)==='bodyguard'){const H=g.alive().filter(o=>o!==h&&!o.pet&&o.hp/o.max<.9).sort((p,q)=>p.hp/p.max-q.hp/q.max)[0];if(H&&!(hp<.25)){const runMul=.45+1.4*pace;return {xoff:0,intent:'guard',runMul,goTo:H,reviveLane:H.laneI};}}
    // 0.12.28 Herbalist: IF I have room for herbs AND there's unsearched debris close by AND it isn't swarmed THEN go search it
    {const sp=insP(h);if(sp==='scavenger'&&(h.kit||[]).includes('med')){const H=g.alive().filter(o=>o!==h&&!o.pet&&fleshy(o)&&o.hp/o.max<.72-.3*trait(h,'energy')).sort((p,q)=>p.hp/p.max-q.hp/q.max)[0];
      if(H&&Math.random()<.55+.35*(1-selfish)){const runMul=.45+1.4*pace;return {xoff:0,intent:'herb',runMul,goTo:H,reviveLane:H.laneI};}}}
    if(!h.search&&!h.pet){const look=30+45*trait(h,'perc')+(insP(h)==='scavenger'?20:0);const o=(g.obst||[]).filter(o=>searchFit(h,o)&&g_free(o,h)&&o.x>30&&o.x<g.W-10&&Math.abs(o.x-g.heroX(h))<look).sort((p,q)=>(searchFit(h,p)==='perk'?0:60)+Math.abs(p.x-g.heroX(h))-((searchFit(h,q)==='perk'?0:60)+Math.abs(q.x-g.heroX(h))))[0];
      if(o){const fit=searchFit(h,o),danger=bb.E.filter(e=>Math.abs(e.x-o.x)<(fit==='perk'?35:60)).length;
        if(!h.srDecide||h.srDecide.o!==o||g.t>h.srDecide.until)h.srDecide={o,until:g.t+1.5+Math.random()*(fit==='perk'?1:3),go:Math.random()<(fit==='perk'?(danger?(.15+.5*aggr):.8+.15*trait(h,'perc')):(danger?0:(.12+.3*trait(h,'perc')+.1*trait(h,'tech'))*(1-.5*trait(h,'aggr'))))*((bb.heat.get(h)||0)?.25:1)*   /* IF something is on me right now THEN I usually fight first; a long shot without the perk is only worth it when it's quiet */(/^car_/.test(o.k)&&bb.E.some(e=>Math.abs(e.x-o.x)<80)?(.45+.55*aggr)*(1.3-.6*trait(h,'noise')):1)};   /* IF it's a car AND enemies are around THEN Calculated units hold off (an alarm would bring more) */
        if(h.srDecide.go){const runMul=.45+1.4*pace;return {xoff:0,intent:'search',runMul,goTo:{ob:o},reviveLane:g.searchSpot(o,h).lane};}}}
    if(h.search&&!h.search.trap&&h.search.o&&h.search.o.lanes)return {xoff:0,intent:'search',runMul:1,goTo:{ob:h.search.o},reviveLane:g.searchSpot(h.search.o,h).lane};
    // 0.12.27 Scavenger: IF I'm carrying an herb AND an ally is under 80% (and not already healing) THEN selfless, ally-aware units go to them
    if(insP(h)==='herbalist'&&h.herbs>0){const H=g.alive().filter(o=>o!==h&&!o.pet&&fleshy(o)&&o.hp/o.max<.9-.3*trait(h,'energy')&&!(o.herbT>0)).sort((p,q)=>p.hp/p.max-q.hp/q.max)[0];
      if(H){if(!h.herbDecide||h.herbDecide.H!==H||g.t>h.herbDecide.until){const danger=bb.E.filter(e=>Math.abs(e.x-g.heroX(H))<35).length;let w=.5+.35*(1-selfish)+.2*A;if(danger)w*=.4+.8*aggr;h.herbDecide={H,until:g.t+1.5+Math.random(),go:Math.random()<Math.min(.95,w)};}
        if(h.herbDecide.go){const runMul=.45+1.4*pace;return {xoff:0,intent:'herb',runMul,goTo:H,reviveLane:H.laneI};}}}
    const AP=abilityPlan(h);
    if(AP.close&&tgt){xoff+=10+14*aggr;intent=intent==='hold'?'engage':intent;}
    if(AP.farRange&&tgt&&!AP.close){const d=Math.abs(tgt.x-g.heroX(h));if(d<AP.farRange*.4)xoff-=14;}
    if(AP.allDown&&hp<.6){xoff-=10+12*(1-aggr);}
    // callouts: IF I took an order THEN it pushes where I stand (personality still wins in an emergency below)
    const O=Comms.ord(h,g,['fallback','push','help','reload','tapped','camp','flank','trap','tank','smoke','reviving']);
    if(O){const fx=O.from?g.heroX(O.from):g.heroX(h);
      if(O.type==='fallback'||O.type==='trap'||O.type==='tank'){xoff-=O.type==='fallback'?55:25;intent='regroup';}
      else if(O.type==='push'){xoff+=55;intent='charge';}
      else if((O.type==='camp'||O.type==='smoke')&&O.x!=null){xoff=O.x-g.home(h);intent='gather';}
      else if(O.type==='flank'&&O.ally===h){xoff-=35;intent='kite';}
      else{xoff+=Math.max(-40,Math.min(50,fx-g.home(h)-xoff))*.7+10;intent='cover';}}
    // IF hurt AND careful THEN back off (the more careful, the earlier)
    const bail=.03+.72*Math.pow(1-aggr,1.3);if(hp<bail&&(danger||near)){xoff-=30+60*(1-aggr);intent='retreat';}   // Calculated 0 runs at 75% HP; Blind Aggression 10 basically never runs
    // IF a ranged unit has foes in its face THEN shooters step back to keep their distance
    else if(near&&slash<.5){xoff-=60*(1-slash*2);intent='kite';}   // shooter-minded units keep their distance (by slider, not by class)
    else if(aggr>.7&&tgt){intent='charge';}
    // IF an ally is getting mobbed AND I'm selfless and ally-minded THEN move up to help
    const mobbed=bb.H.filter(o=>o!==h&&(bb.heat.get(o)||0)>=2&&o.hp/o.max<.6)[0];if(mobbed&&selfish<.5&&A>.4&&intent!=='retreat'){xoff+=14+40*(1-selfish*2);intent='cover';}
    const runMul=.45+1.4*pace;
    if(near>=3)Brain.panic(g,h,'swarm');   /* Steady <-> Panicky: getting swarmed */
    /* 0.12.43 Pack Hunter <-> Lone Wolf also sets spacing: IF I'm a pack hunter THEN I drift in next to the nearest ally; IF a lone wolf THEN I keep room around me */
    {const pk=trait(h,'pack'),me=g.home(h)+xoff;const mates=bb.H.filter(o=>o!==h&&!o.pet);if(mates.length&&intent!=='retreat'){const m=mates.reduce((b,o)=>Math.abs(g.heroX(o)-me)<Math.abs(g.heroX(b)-me)?o:b,mates[0]);const dx=g.heroX(m)-me,d=Math.abs(dx);
      if(pk<.4&&d>20)xoff+=Math.sign(dx)*(d-20)*.6*(1-pk/.4);else if(pk>.6&&d<22)xoff-=(Math.sign(dx)||1)*(22-d)*.8*((pk-.6)/.4);}}
    /* 0.12.43 Out in the Open <-> Takes Cover: IF the fight is on AND I'm cover-minded (more so when hurt) THEN I put the nearest rock / log / wreck between me and the horde, leaning out to shoot */
    {const cv=trait(h,'cover');if(cv>.55&&intent!=='retreat'&&intent!=='charge'&&(slash>.6?hp<.6:(bb.E.length>=3||hp<.6||h.ammo<=0))){const front=bb.E.reduce((m,e)=>Math.min(m,e.x),1e9);const me=g.home(h)+xoff;
      if(!h.cvDecide||g.t>h.cvDecide.until){const obs=(g.obst||[]).filter(o=>o.blk>0&&o.x<front-10&&Math.abs(o.x-me)<75&&o.x>g.heroX(h)-60).sort((p,q)=>Math.abs(p.x-me)-Math.abs(q.x-me));
        h.cvDecide={o:obs[0]||null,until:g.t+1.5+Math.random(),go:Math.random()<(cv-.55)/.45*(hp<.6?1:.7)};}
      const o=h.cvDecide.o;if(h.cvDecide.go&&o&&(g.obst||[]).includes(o)){const l=o.lanes[o.lanes.length-1],[a]=g.obSpan(o,l);return {xoff:a-5-g.home(h),intent:'hunker',runMul,reviveLane:l};}}}
    return {xoff:Math.max(-115,Math.min(95,xoff)),intent,runMul};},
  // energy: squanderers spend at every chance; preservers wait to unload several big hits in a row
  energyCall(u){const pres=trait(u,'energy');const en=u.en||0;if(u.burst>0)return true;
    if(u.order&&u.order.type==='burst'&&u.order.until>(u._gt||0)&&en>=20)return true;   // IF told to unload on a clump THEN spend now
    // 0 = spends the moment it can afford anything; 10 = sits on it until FULL, then dumps 4 in a row
    if(pres<.5){return en>=10+40*pres&&Math.random()<Math.pow(1-pres*2,.5);}
    const need=70+30*((pres-.5)*2);if(en>=need-0.01){u.burst=2+Math.round(2*(pres-.5)*2);return true;}return false;},
  // Danger zones (marked boss attacks). Replaces the old Reflex stat with if/then rules on the sliders:
  //   notice it?  Enemy Awareness and Optimal units watch the ground; Blind Aggression and units locked on a target miss it more.
  //   react?      Calculated units step out; Blind Aggression may stand and keep swinging; Selfish units always look after themselves;
  //               a Showoff may wait to the last moment on purpose; New Plan units drop what they are doing faster than On Track ones.
  //   how fast?   Fast and Furious moves sooner and quicker; Slow and Steady takes a beat. Low HP makes everyone jumpier.
  //   how far?    Optimal steps fully clear with a margin; Suboptimal often comes up short.
  dangerCall(g,u,z,ux){const ag=trait(u,'aggr'),aw=trait(u,'aware'),pc=trait(u,'pace'),se=trait(u,'self'),pl=trait(u,'plan'),ex=trait(u,'exec'),fl=trait(u,'flair'),r=()=>g.rng();
    const low=u.max?1-Math.max(0,u.hp)/u.max:0;let why;
    let notice=.45+.45*(1-aw)+.35*(ex-.5)-.45*(ag-.3)+.25*low+.4*(trait(u,'perc')-.5);if(u.atkTgt||u.target)notice-=.1*(1-pl);
    if(r()>Math.min(.97,Math.max(.15,notice)))return {react:0,why:'did not see it'};
    let stay=.8*Math.pow(ag,1.5)*(1-low)-.35*se-.3*(1-ag);if(fl>.6&&low<.5)stay+=.1;
    if(r()<Math.max(0,stay))return {react:0,why:'ignores it, keeps fighting'};
    let delay=.15+.45*(1-pc)+.25*(1-pl)-.2*low+r()*.3;let showoff=0;
    if(fl>.7&&low<.4&&r()<fl-.5){delay+=.35;showoff=1;}
    delay=Math.max(.08,Math.min(z.T-.05,delay));
    const mul=ex>.6?1+.3*ex+r()*.15:.6+.5*ex+r()*.5;
    const spd=60+60*pc+30*low;
    why=showoff?'waits till the last second':mul<1?'steps out (short)':'steps clear';
    return {react:1,delay,mul,spd,why};},
  showoff(g,u,what){const fl=trait(u,'flair');if(fl<.05||Math.random()>Math.pow(fl,1.3))return;const L=SHOW_LINES[u.key?'hero':u.type]||SHOW_LINES.hero;
    const x=u.key?g.heroX(u):u.x;g.text(x,(u.key?g.G:u.y)-62,L[Math.floor(Math.random()*L.length)],'#ffd23f',false,.5);u.pauseT=.1+1.1*fl*fl;}   // showing off costs a moment
};
// ---- 0.12.13 Callouts: heroes shout short, colour-coded callouts to each other, and the callouts can change what allies do.
//   Two sliders run it (both part of the if/then behavior system like every other slider):
//     Quiet (0) <-> Chatty (10)            how often a unit calls things out. 0 almost never speaks; 10 calls out everything it sees.
//     Ignores Callouts (0) <-> Follows Callouts (10)   how often a unit does what it's asked. 0 nearly always ignores; 10 nearly always obeys.
//   Each callout is IF (something on the field) THEN (a unit may shout it) AND (each ally rolls whether to listen) THEN (that ally's
//   targeting / position / lane / energy / danger rules get pushed toward what was asked for a few seconds).
/* 0.12.204 (Kyle) guard dog breeds: a random one each time the kennel sends a dog. Small temperament nudges true to the breed */
const DOG_BREEDS=[
  {skin:'dog',name:'German_Shepherd',mood:{listen:1,aware:1}},                                   // trained, watches the team
  {skin:'dog_heeler',name:'Blue_Heeler',mood:{pace:2,perc:2,aggr:1,listen:-1},dodge:.03},        // quick, nippy, herds, a bit stubborn
  {skin:'dog_lab',name:'Black_Lab',mood:{aggr:-1,listen:2,pack:-2},bite:-.05},                    // eager to please, sticks close
  {skin:'dog_golden',name:'Golden_Retriever',mood:{aggr:-2,listen:2,aware:2,nerve:-1},bite:-.05}, // gentle, protective of its people
  {skin:'dog_husky',name:'Husky',mood:{listen:-3,pace:2,talk:3},dodge:.02},                       // fast, loud, does its own thing
  {skin:'dog_rott',name:'Rottweiler',mood:{aggr:3,nerve:-2,pace:-1},bite:.1}];                     // fearless, hits hard, a bit slower
const CALL_COLOR={cheez:'#3af0ff',edward:'#f0b429',knight:'#c0303a',carcher:'#e05a5a',csorc:'#ffd84a',soldier:'#9fb06a',shoshi:'#b38cff',eng:'#ffcc33',jp:'#ff9a3c',dog:'#d8a060',cultist:'#b05cff',robot:'#4de0d0',flannel:'#f2c94c',flannel_pal:'#ff6b6b',chibi:'#5ab4ff',archer:'#ff9f43',druid:'#7ee081',lumberjack:'#c79bff'};
const NICK={cheez:'Cheez',edward:'Edward',knight:'Knight',carcher:'Archer',csorc:'Sorcerer',soldier:'Soldier',shoshi:'Shoshi',eng:'Engineer',dog:'Dog',cultist:'Cultist',robot:'Hound',flannel:'Flannel',flannel_pal:'Companion',chibi:'Chibi',archer:'Yumi',druid:'Druid',lumberjack:'Jack'};
const FOE_NICK={zombie:['the zombie','that zombie','the shambler','the rotter','the dead one'],werewolf:['the wolf','the werewolf','the dog','the furball','the beast']};
const LANE_NAME=['top','upper','middle','lower','bottom'];
const CALLS={
  help:{dur:5,lines:['Help!','I need help here!','Get it off me!','A little help?!','They\'re on me!','Somebody, please!','I\'m getting swarmed!','Can\'t hold them!','Back me up!','Over here, quick!','I\'m in trouble!','HELP ME!','Cover me!','I can\'t shake {foe}!','{foe} is on me!'],
    ack:['Coming!','On my way!','Hang on!','I\'ve got you!','Moving to you!','Hold on, {ally}!','Right there!','I see you!']},
  heal:{dur:6,lines:['I need healing!','Heal me!','Patch me up!','I\'m bleeding out!','Medic!','Druid, a little help?','Need a heal!','I\'m hurt bad!','Could use some green magic!','Healer!','I\'m not gonna last!','Fix me up!'],
    poison:['I\'m poisoned!','Something in my veins...','I feel sick!','Poison! Cleanse me!'],ack:['Healing!','I\'ve got you!','Hold still!','Mending!','Hang in there!','Here, breathe!']},
  focus:{dur:6,lines:['Focus {foe}!','Everyone on {foe}!','Hit {foe}!','Take out {foe}!','{foe} first!','Burn {foe} down!','Go for {foe}!','Kill {foe}!','Target {foe}!','{foe}! Now!','All in on {foe}!','Drop {foe}!'],
    weak:['{foe} is almost dead!','Finish {foe}!','{foe} is hurt, finish it!','One more hit on {foe}!','{foe} is weak!','Clean up {foe}!'],
    ack:['On it!','Got it!','Switching!','Target acquired.','Yep!','Copy!','Locked on!']},
  flank:{dur:4,lines:['Behind you, {ally}!','{ally}, watch out!','{ally}, on your left!','Something\'s on {ally}!','{ally}, look out!','Watch your back, {ally}!','{ally}! Close one!','It\'s on {ally}!','Protect {ally}!','{foe} is on {ally}!'],
    ack:['I see it!','Got it!','Thanks!','Moving!','On it!']},
  fallback:{dur:5,lines:['Fall back!','Pull back!','Regroup!','Back up, back up!','Retreat!','Too many! Back!','Get back here!','Fall back and breathe!','Back off!','Reset! Reset!','Give ground!','Back to me!'],
    ack:['Falling back!','Backing up!','Right behind you!','Moving!','Regrouping!'],no:['No way!','Not yet!','I can take them!','Retreat? Never!','Keep running then.']},
  push:{dur:5,lines:['Push!','Push forward!','Go go go!','They\'re breaking!','Charge!','Press them!','Move up!','Don\'t let up!','Keep pushing!','Now\'s our chance!','At them!','Forward!'],
    ack:['Pushing!','Let\'s go!','Right with you!','Charging!','Hah! Yes!'],no:['Careful...','You go first.','Not so fast.','I\'ll hang back.','Too risky.']},
  burst:{dur:4,lines:['They\'re bunched up!','Hit them all!','Big group, light them up!','Now! Use everything!','They\'re clumped, blow it!','All together, now!','Pile of them here!','Perfect spot, unload!','Group\'s tight, go big!'],
    ack:['Unloading!','Here it comes!','Saying goodbye!','Firing everything!'],no:['Saving it.','Not yet.','Wait for it...']},
  boss:{dur:7,lines:['Big one!','Here it comes!','Boss incoming!','That\'s a big one!','Oh no. Oh no.','Everybody, on the big one!','Look at the size of it!','Bring it down!','Here\'s the boss!','Whoa, what is THAT?'],
    ack:['Ready!','Let\'s do it!','Bring it!','I\'m ready.']},
  down:{dur:8,lines:['{ally} is down!','We lost {ally}!','{ally}! No!','Man down!','{ally} fell!','They got {ally}!','{ally}, get up!','Avenge {ally}!'],
    angry:['You\'ll pay for that!','For {ally}!','Now I\'m mad.','No mercy!'],scared:['We\'re losing...','Stay close!','This is bad...','Careful, everyone!']},
  reload:{dur:3,lines:['Reloading!','Cover me, reloading!','Changing mags!','Out! Reloading!','Give me a sec!','Reload!','Hold them, reloading!'],ack:['Covering!','Got you!','I\'ll hold them!']},
  camp:{dur:7,lines:['Campfire\'s up!','Gather round the fire!','Warm up, everyone!','Fire\'s lit, come heal!','Come sit by the fire!','Rest up here!'],ack:['Coming!','Ooh, warm!','Be right there!','Don\'t mind if I do!']},
  lane:{dur:5,lines:['Coming up {lane}!','{lane} lane, watch it!','They\'re sneaking {lane}!','{lane} is open!','Somebody cover {lane}!','Eyes {lane}!','Movement {lane}!'],ack:['I\'ll take {lane}!','Got {lane}!','Moving {lane}!']},
  danger:{dur:2,lines:['Move!','Get out of there!','Look out!','Dodge!','Watch the ground!','{ally}, move!','Out of the way!','It\'s gonna hit!','Clear out!','MOVE, {ally}!'],ack:['Whoa!','Thanks!','Moving!','Close one!']},
  tapped:{dur:4,lines:['I\'m tapped out!','No energy!','Out of tricks!','I\'ve got nothing left!','Running on empty!','Cooling down!'],ack:['I\'ll cover you!','Got you!','Take a breath!']},
  kill:{dur:0,lines:['Got one!','Down!','Gotcha!','Next!','That\'s one!','Dropped it!','Stay down!','Easy!','And stay dead!','Another one!','Clean!','Scratch one!']},
  smoke:{dur:5,lines:['Smoke out!','Popping smoke!','Get in the smoke!','Smoke screen, use it!','Hide in the cloud!','Covering you!'],ack:['Thanks!','Into the smoke!','Got it!']},
  missiles:{dur:0,lines:['Missiles away!','Incoming!','Barrage out!','Fire in the hole!','Rockets!','Duck!']},
  gatling:{dur:0,lines:['Spinning up!','Eat lead!','Brrrrt!','Covering fire!','Hose them down!','Lead incoming!']},
  clone:{dur:0,lines:['Shadow clone!','Which one\'s real?','Double trouble!','Two of me!']},
  tentacle:{dur:0,lines:['From the deep!','Rise!','It hungers!','Feed, my pet!','The deep answers!','Tear them apart!']},
  pact:{dur:0,lines:['Blood for power!','Take my blood!','Drink deep, friends!','A small price!','Pain is strength!']},
  dread:{dur:0,lines:['Despair!','Tremble!','Flee, little things!','Your doom whispers!','Kneel!']},
  reviving:{dur:5,lines:['Getting {ally} up!','Hang on, {ally}!','Cover me, I\'m reviving!','Up you get, {ally}!','On my way, {ally}!','Hold them off!'],ack:['Covering!','Got you!','Go, go!']},
  tank:{dur:6,lines:['Get behind me!','I\'ll hold them!','Come on then!','Stay back, I got this!','Let \'em come!','I can take it!','Behind me, now!','Tanking!'],ack:['Behind you!','Got it!','Careful!','Okay!']},
  trap:{dur:4,lines:['Trap\'s down!','Lure them in!','Watch the wire!','Bait them over here!','Mind the bomb!'],ack:['Pulling back!','Luring!','Got it!']},
};
const REFUSE=['Busy!','In a sec!','Nope.','Can\'t right now!','Do it yourself!','I\'ve got my own problems!','Hmm... no.','Later!','Not now!','I\'m on something!','Ugh, fine... no.','Maybe not.'];
// IF this ally cares about this kind of callout THEN how much (0..1); multiplied with Follows Callouts to get the chance it obeys
function callRelevance(type,o,ctx){const ag=trait(o,'aggr'),se=trait(o,'self'),aw=trait(o,'aware'),lone=trait(o,'pack'),en=trait(o,'energy');
  switch(type){
    case 'heal':return isHealer(o)?1:0;
    case 'help':return .4+.6*(1-se);
    case 'focus':return .45+.55*(1-lone);
    case 'flank':return o===ctx.ally?1:(.3+.7*aw);
    case 'fallback':return Math.max(.05,1.1-ag);
    case 'push':return Math.max(.05,.15+ag);
    case 'burst':return hasAbilities(o)?(.25+.75*(1-en)):0;
    case 'boss':return .5+.5*(1-lone);
    case 'reload':case 'tapped':return .3+.7*(1-se);
    case 'camp':return o.hp/o.max<.9?1:.3;
    case 'lane':return .2+.8*trait(o,'lane');
    case 'danger':return o===ctx.ally?1:0;
    case 'trap':return .4+.6*(1-ag);
    case 'smoke':return o===ctx.ally?1:o.hp/o.max<.6?.8:.15;
    case 'reviving':return .4+.6*(1-se);
    case 'tank':return .2+.8*(1-trait(o,'range'));
    default:return 0;}}
function isHealer(u){return ((CHAR[u.key]||{}).abilities||[]).some(a=>a.id==='mend'||a.id==='bloom');}
function hasAbilities(u){return ((CHAR[u.key]||{}).abilities||[]).length>0;}
const Comms={
  name(u){return NICK[u.key]||((CHAR[u.key]||{}).name)||u.key;},
  foe(e){if(!e)return 'that one';if(e.boss)return 'the boss';const L=FOE_NICK[e.type];return L?L[Math.floor(Math.random()*L.length)]:'that one';},
  fill(s,ctx){return s.replace('{foe}',this.foe(ctx.tgt)).replace('{ally}',ctx.ally?this.name(ctx.ally):'you').replace('{lane}',ctx.lane!=null?LANE_NAME[Math.min(4,ctx.lane)]||'that lane':'that lane');},
  pick(a){return a[Math.floor(Math.random()*a.length)];},
  bubble(g,u,s,keep){if(!keep&&Math.random()<.22)return;if(u&&u.key&&Math.random()<.25)return;   /* 0.12.225 (Kyle): 25% less chatter overall */if(u&&u.key&&CHAR[u.key]&&Math.random()<.05+.35*trait(u,'talk'))return;   /* 0.12.201 (Kyle): Chatty 10 talks 40% less than before, scaling down to 5% less at 0 */if(u&&u.key==='dog')s=Comms.pick(['Woof!','Grrr!','Bark bark!','Arf!','*growls*','*snarls*']);   /* 0.12.38 (Kyle): about 22% less chatter on screen */if(u&&u.key==='robot')s=robotize(s);if(u&&u.key==='jp')s=jpify(s);else if(u&&u.key==='flannel_pal')s=saltify(s,.25);else if(u&&u.key&&u.key!=='robot'&&u.key!=='dog')s=saltify(s,.08);s=s.charAt(0).toUpperCase()+s.slice(1);(g.calls=g.calls||[]).push({u,s,c:CALL_COLOR[u.key]||'#e8e8e8',t:0,life:1.6+Math.min(1.4,s.length*.045)});
    if(g.calls.length>8)g.calls.shift();},
  // IF a unit decides to speak (Quiet<->Chatty, a personal cooldown, and the team not having just said the same thing) THEN shout it
  say(g,u,type,ctx,force){if(!u||!u.alive||g.demo)return false;const C=CALLS[type];if(!C)return false;ctx=ctx||{};
    const talk=trait(u,'talk');g.callGap=g.callGap||0;g.callType=g.callType||{};
    if(!force){if((u.callT||0)>g.t)return false;if(g.t<g.callGap)return false;if((g.callType[type]||-99)>g.t-3.5)return false;
      // 0 = nearly never (2% for something urgent), 10 = practically every time it sees something
      const urgent=type==='help'||type==='heal'||type==='danger'||type==='down';let p=Math.pow(talk,1.6)*.95+(urgent?.03:.004);if(/flank|lane|danger|boss/.test(type))p*=.4+1.2*trait(u,'perc');p*=.78;if(Math.random()>p){if(urgent||/boss|flank/.test(type))this.roast(g,u,type);return false;}}
    u.callT=g.t+.8+9*(1-talk);g.callGap=g.t+.45;g.callType[type]=g.t;
    const pool=ctx.variant&&C[ctx.variant]?C[ctx.variant]:C.lines;this.bubble(g,u,this.fill(this.pick(pool),ctx),true);
    if(C.dur)this.broadcast(g,u,type,ctx,C);return true;},
  // every ally hears it: IF it's relevant to them AND they roll under Follows Callouts THEN they take the order
  broadcast(g,u,type,ctx,C){for(const o of g.alive()){if(o===u||!o.key)continue;if(o.robbedBy===u&&o.moods&&o.moods.some(m=>m.name==='robbed'))continue;   /* still sore about the theft: ignores the thief's calls */const rel=callRelevance(type,o,ctx);if(rel<=0)continue;
      const L=trait(o,'listen');const p=(.02+.96*Math.pow(L,1.15))*rel;
      if(Math.random()<p){o.order={type,from:u,tgt:ctx.tgt||null,ally:ctx.ally||null,lane:ctx.lane,x:ctx.x,until:g.t+C.dur*(.5+L),w:L};
        o.thinkT=Math.min(o.thinkT==null?0:o.thinkT,.08+.25*(1-trait(o,'pace')));   // drop what they're doing and rethink right away
        if(C.ack&&Math.random()<.15+.6*trait(o,'talk'))setTimeoutSafe(g,.35+Math.random()*.5,()=>{if(o.alive)this.bubble(g,o,this.fill(this.pick(C.ack),{tgt:ctx.tgt,ally:u,lane:ctx.lane}));});}
      else if(Math.random()<.05+.35*trait(o,'talk')*(1-L)){const pool=C.no||REFUSE;setTimeoutSafe(g,.4+Math.random()*.5,()=>{if(o.alive)this.bubble(g,o,this.pick(pool));});}}},
  /* 0.12.202 (Kyle) JP's hidden passive (not on his sheet, no cooldown shown): IF a teammate sees something important and keeps quiet about it
     AND JP is up THEN sometimes he roasts them for it. They answer back: agree (more likely the more they follow callouts) and for 30s
     they're +1 Chatty and +1 Perception (they call things out more and notice more); or they brush him off and nothing changes. */
  roast(g,u,type){if(!u||u.key==='jp'||!CHAR[u.key]||g.demo)return;const jp=g.alive().find(o=>o.key==='jp');if(!jp||(g.roastT||0)>g.t||Math.random()>.35)return;
    if((u.moods||[]).some(m=>m.name==='roasted'))return;g.roastT=g.t+20;const nm=this.name(u);
    const what={help:'they needed help',heal:'somebody needed healing',danger:'that was coming',down:'someone went DOWN',boss:'the BOSS',flank:'the flank'}[type.replace(/[^a-z]/g,'')]||'that';
    setTimeoutSafe(g,.5,()=>{if(!jp.alive||!u.alive)return;this.bubble(g,jp,this.pick([nm+'! You saw '+what+' and said NOTHING?','Yo '+nm+', use your mouth words!','Bro. '+nm+'. Speak up next time.',nm+' out here playing the quiet game.','Did '+nm+' forget how to talk? Unreal.']),true);
      setTimeoutSafe(g,1.1,()=>{if(!u.alive)return;const agree=Math.random()<.35+.45*trait(u,'listen');
        if(agree){addMood(u,{talk:1,perc:1},30,'roasted');this.bubble(g,u,this.pick(['...Yeah, fair. My bad.','Okay okay, I\'ll call it out.','You\'re right. Eyes up.','Ugh. Fine. Noted.']),true);}
        else this.bubble(g,u,this.pick(['Mind your business, JP.','You didn\'t see it either!','Says the guy who\'s always high.','Nah, I had it handled.']),true);});});},
  ord(u,g,types){const o=u.order;if(!o||g.t>o.until)return null;if(o.from&&!o.from.alive&&o.type!=='down')return null;return types.includes(o.type)?o:null;},
  // the scan: each hero looks at the field on its own clock (Chatty units look more often) and checks the IF side of every callout
  step(g,dt){if(!g.calls)g.calls=[];for(const c of g.calls)c.t+=dt;g.calls=g.calls.filter(c=>c.t<c.life&&c.u.alive!==false);
    const al=g.alive().filter(h=>h.key&&h.alive);if(!al.length)return;const bb=g.bb;if(!bb)return;
    const E=g.enemies.filter(e=>!e.dead&&e.x<g.W);const mean=al.reduce((s,h)=>s+g.heroX(h),0)/al.length;
    if(g.boss&&!g.boss.dead&&!g.bossCalled){g.bossCalled=1;const sp=al.slice().sort((a,b)=>trait(b,'talk')-trait(a,'talk'))[0];this.say(g,sp,'boss',{tgt:g.boss},trait(sp,'talk')>.15);}
    for(const h of al){h.commT=(h.commT==null?Math.random()*.6:h.commT)-dt;if(h.commT>0)continue;h.commT=.35+.9*(1-trait(h,'talk'))+Math.random()*.3;
      const hp=h.hp/h.max,hx=g.heroX(h),heat=bb.heat.get(h)||0;
      // IF I'm hurt AND a healer is with us THEN ask for healing (poisoned units say so)
      if(hp<.5&&al.some(o=>o!==h&&isHealer(o))&&this.say(g,h,'heal',{ally:h,variant:(h.poison&&h.poison.n)?'poison':null}))continue;
      // IF I'm getting hit AND hurt THEN shout for help
      if(hp<.45&&heat>=1){const t=h.lastHitBy&&!h.lastHitBy.dead?h.lastHitBy:E.filter(e=>e.target===h)[0];if(this.say(g,h,'help',{tgt:t,ally:h}))continue;}
      // IF something has reached a back-liner (someone standing behind the team's middle) THEN warn them
      const back=al.filter(o=>o!==h&&g.heroX(o)<mean-4);for(const v of back){const e=E.find(e=>!e.fly&&Math.abs(e.x-g.heroX(v))<26&&(e.target===v||Math.abs((e.gy||g.G)-(v.gy||g.G))<8));
        if(e&&this.say(g,h,'flank',{tgt:e,ally:v}))break;}
      // IF two or more of us are hurt OR we're badly outnumbered THEN call a fall back
      const hurt=al.filter(o=>o.hp/o.max<.45).length;if((hurt>=2||E.length>=al.length*3+2)&&this.say(g,h,'fallback',{}))continue;
      // IF the enemies are few or nearly dead AND we're healthy THEN call a push
      if(E.length&&al.every(o=>o.hp/o.max>.6)&&(E.length<=2||E.every(e=>e.hp/e.max<.4))&&!(g.boss&&!g.boss.dead)&&this.say(g,h,'push',{}))continue;
      // IF 3+ enemies are bunched within ~17 world px THEN call for everyone to unload
      const clump=E.find(e=>E.filter(o=>Math.abs(o.x-e.x)<17).length>=3);if(clump&&this.say(g,h,'burst',{tgt:clump}))continue;
      // IF my target is big OR nearly dead THEN call a focus
      const T=h.plan&&h.plan.tgt;if(T&&!T.dead){const big=T.boss||(T.max||0)>=bb.maxE*.7,weak=T.hp/T.max<.3;if((big||weak)&&this.say(g,h,'focus',{tgt:T,variant:weak?'weak':null}))continue;}
      // IF a lane has enemies in it but none of us THEN call the lane
      const ln=E.find(e=>e.laneI!=null&&!al.some(o=>o.laneI===e.laneI)&&e.x<g.W*.8);if(ln&&this.say(g,h,'lane',{lane:ln.laneI,tgt:ln}))continue;
      // IF I'm out of energy AND every ability is on cooldown AND enemies are close THEN tell them I've got nothing
      if(hasAbilities(h)&&(h.en||0)<12&&abilityPlan(h).allDown&&E.some(e=>Math.abs(e.x-hx)<60)&&this.say(g,h,'tapped',{ally:h}))continue;}},
  // hooks the rest of the game calls
  onReload(g,h){this.say(g,h,'reload',{ally:h,tgt:h.plan&&h.plan.tgt});},
  onCamp(g,h,x){this.say(g,h,'camp',{ally:h,x},true&&trait(h,'talk')>.1);},
  onTrap(g,h,x){this.say(g,h,'trap',{ally:h,x});},
  onKill(g,h){if(h&&h.key==='cheez'&&Math.random()<.22){this.bubble(g,h,this.pick(['Punch nazis, slice zombies.','You\'re not invited to game night.','Critical hit! Roll for damage.','That machine\'s out of order.','Dice Boys never miss a session.','Get rekt, mouth-breather.','Cancel your sub, buddy.','That\'s a fatality.','Somebody tell the casino I\'m on break.','Rolled a nat 20 on that one.']));return;}if(h&&h.key)this.say(g,h,'kill',{});},   /* 0.12.235 Cheez quips */
  // IF an ally falls THEN someone shouts it; everyone who hears gets angrier (Vengeful) or more careful (Forgiving)
  onDown(g,h){const al=g.alive().filter(o=>o.key&&o!==h);if(!al.length)return;const sp=al.slice().sort((a,b)=>trait(b,'talk')-trait(a,'talk'))[0];
    this.say(g,sp,'down',{ally:h},true);
    for(const o of al){const L=trait(o,'listen'),v=trait(o,'grudge');if(Math.random()<.2+.8*L){if(v>=.5)addMood(o,{aggr:4,grudge:2},10,'avenge');else addMood(o,{aggr:-4,self:-2},10,'shaken');
      if(Math.random()<.3*trait(o,'talk'))setTimeoutSafe(g,.7+Math.random()*.6,()=>{if(o.alive)this.bubble(g,o,this.fill(this.pick(v>=.5?CALLS.down.angry:CALLS.down.scared),{ally:h}));});}}},
  // IF a danger zone is about to hit someone who didn't notice THEN an ally may yell at them, and IF they listen THEN they dodge late
  onDanger(g,z,missed){const al=g.alive().filter(o=>o.key);for(const v of missed){const sp=al.filter(o=>o!==v).sort((a,b)=>trait(b,'talk')-trait(a,'talk'))[0];if(!sp)continue;
      if(this.say(g,sp,'danger',{ally:v})&&v.order&&v.order.type==='danger'){const hx=g.heroX(v);const need=hx<z.cx?-(z.hw+8-(z.cx-hx)):(z.hw+8-(hx-z.cx));
        v.dodge={at:g.t+.25,dx:(v.dodgeX||0)+need,until:g.t+z.T+.5,spd:110};v.dangerWhy='⚠ '+this.name(sp)+' warned me';}}},
};
class Game{
  constructor(opt){
    this.W=opt.W||CFG.W;this.H=CFG.H;this.G=CFG.GROUND;
    this.rng=opt.rng||Math.random;this.demo=!!opt.demo;this.run=opt.run;this.slot=opt.slot;if(!this.demo)setRunModes(this.run);this.hardcore=!this.demo&&!!(this.run&&this.run.hardcore);
    this.st=CFG.stage(this.run.stage,this.run.prestige);
    this.nemQ=[];   /* 0.12.238 (Kyle): promoted zombies never just show up; they only come from the promotion system (a zombie that downs a hero) */   /* 0.12.136: one returning Nemesis per stage, 40% of the way in */
    this.dist=0;this.t=0;this.events=[];this.enemies=[];this.proj=[];this.fx=[];this.minions=[];this.texts=[];
    this.budget=2;this.bossSpawned=false;this.over=null;this.kills=0;this.shake=0;this.devourStacks=0;
    this.banners=[];this.waves=[];this.stageXp=0;this.stageScore=0;this.loot=[];this.stageGold=0;this.stageItems=[];this.stageFood=0;this.stageWater=0;this.stageParts=0;this.stats={};
    this.heroes=this.run.team.map((k,i)=>this.makeHero(k));
    this.heroes.sort((a,b)=>(STYLE[a.key].tank?-1:0)-(STYLE[b.key].tank?-1:0)||ORDER[a.style.atk]-ORDER[b.style.atk]);
    this.recalc();
    this.heroes.forEach((h,i)=>{h.x=this.home(h);const saved=this.run.heroes[h.key];h.hp=saved.dead?h.max*.25:Math.max(1,h.max*(saved.hpf==null?1:saved.hpf));});
    for(const h of this.heroes)if(h.thirst>0){const T=h.thirst;addMood(h,{perc:-THIRST.perc[T],plan:-THIRST.think[T],exec:-THIRST.think[T]},1e9,'thirst');}   /* 0.12.72 thirst: foggy head */
    this.mods=this.demo?scoutMods(null):scoutMods(this.run);
    {const kt=upgT(this.run,'kennel');if(kt&&!this.demo)this.spawnDog(kt);}
    for(const h of this.heroes)if((h.base.char&&h.base.char.abilities||[]).some(a=>a.id==='elite'))this.callPal(h,{heal:0});   /* 0.12.68 Elite_Survivors: she starts the stage beside him */
    {for(const h of this.heroes){const sv=this.run.heroes[h.key];const cr=sv.carry;   /* Triage builds ride along into the stage */
      if(cr&&!this.demo){if(cr.courage){h.courage=1;addMood(h,{nerve:-3,aggr:2},99999,'courage');}if(cr.medkit){h.medkit=1;h.medkitCamp=1;}if(cr.defib)h.defib=1;if(cr.kit&&cr.kit.length)h.kit=(h.kit||[]).concat(cr.kit).slice(0,2);sv.carry=null;}}}
    if(!this.demo&&upgT(this.run,'radio')>=1)for(const h of this.heroes)if(!h.pet&&h.enMax)h.en=h.enMax;   /* 0.12.246 Radio Shack I: they head out ready, full energy */
    if(this.heroes.some(h=>h.courage)){this.recalc();for(const h of this.heroes)if(h.courage){this.text(this.heroX(h),(h.gy||this.G)-60,'🫙 LIQUID COURAGE','#ffd27a',true);Comms.bubble(this,h,Comms.pick(['*hic* Let\'s GO!','Liquid courage, baby!','I feel INVINCIBLE. *hic*']),true);}}   /* 0.12.246: make the jar visible */
    this.spawnTimer=0;
  }
  makeHero(key){
    const sv=this.run.heroes[key];const lvl=(this.slot&&this.slot.heroes[key]||{lvl:1}).lvl;
    const insp=(this.slot&&this.slot.heroes[key]||{}).insp||null;
    const TH=this.slot&&this.slot.heroes[key];const bse=heroBase(key,lvl,this.run.team.length);if(TH&&bse.char)bse.char=talChar(key,TH);   /* 0.12.106 skill-mod talents */
    return {key,insp,def:heroDef(key),style:STYLE[key],lvl,base:bse,spells:ABILITIES_OFF?[]:sv.spells.map(s=>Object.assign({cdT:Math.random()*1.5},s)),
      items:sv.items.slice(),alive:true,x:0,atkT:Math.random()*.5,anim:0,animT:0,walkT:Math.random(),shield:0,shieldT:0,buffT:0,lowT:0,nearT:0,hitFlash:0,alt:0};
  }
  isMeleeHero(h){return h.style.atk==='melee'||h.style.atk==='duo'||h.style.atk==='blade';}
  // where each hero stands: melee 4/10 of the screen, ranged/casters 2/10 (several of a kind spread out a little)
  // 0.12.11 (Kyle): no hard-coded spots for melee vs ranged. Everyone shares one neutral rally point; WHERE each unit actually
  //   stands comes from its personality and abilities (Brain.pickPosition: Shooter<->Slasher, Calculated<->Aggressive, what's ready).
  home(h){if(h.pet&&h.owner)return this.home(h.owner)-(h.dog?6:14);const al=(this.alive().length?this.alive():this.heroes).filter(o=>!o.pet);const j=Math.max(0,al.indexOf(h));
    return Math.round(this.homeX||this.W*.33)-j*8+(j%2?6:0);}
  slotX(i){return this.home(this.heroes[i]);}
  // team-wide passives + per-hero items
  recalc(){
    const T={dmg:1,aspd:1,cdr:0,xp:1,luck:0,dodge:0,devour:0};
    for(const h of this.heroes)for(const s of h.spells){const r=s.r;
      if(s.arch==='pump')T.dmg+=.04*r; if(s.arch==='haste'){T.aspd+=.035*r;T.cdr+=.015*r;}
      if(s.arch==='insight'){T.xp+=.06*r;T.luck+=r;} if(s.arch==='devour')T.devour+=r;}
    this.team=T;
    for(const h of this.heroes){const b=h.base;let hpM=1,atkM=1,crit=b.crit,dr=0,cdr=T.cdr,aspd=T.aspd,luck=b.luck+T.luck,score=0;
      for(const it of h.items){const r=it.r*(1+.04*((it.tier||1)-1));
        if(it.arch==='blade'){atkM+=.05*r;crit+=.01*r;} if(it.arch==='armor'){hpM+=.06*r;dr+=.015*r;}
        if(it.arch==='relic'){cdr+=.025*r;aspd+=.025*r;} if(it.arch==='charm'){crit+=.015*r;luck+=5*r;score+=.03*r;}}
      const pct=h.max?h.hp/h.max:1;
      h.max=b.hp*hpM;h.atk=b.atk*atkM*T.dmg*(1+((this.run&&this.run.attendB&&this.run.team.includes('cheez'))?this.run.attendB:0));h.aspd=b.aspd*aspd;h.crit=Math.min(.6,crit);h.acc=b.acc||0;h.dr=Math.min(.45,dr);h.armor=h.dr;h.cdr=Math.min(.5,cdr);
      h.dodge=Math.min(.4,b.dodge+T.dodge);h.luck=luck;h.scoreM=1+score;h.pow=b.pow;h.reach=b.reach;
      h.critMul=b.critMul||1.75;h.armorPts=b.armorPts||0;h.kbRes=b.kbRes||0;h.enMaxB=100;h.enRegenB=5;h.xpBonus=0;h.lifesteal=0;h.mvMul=1;h.meleeDmg=1;h.rangedDmg=1;h.meleeSpd=1;h.rangedSpd=1;h.kbAdd=0;h.flatRanged=0;h.flatMelee=0;
      const I=INSP[h.insp];if(I){const m=I.mod||{};
        if(m.acc)h.acc+=m.acc;if(m.crit)h.crit+=m.crit/100;if(m.critMul)h.critMul+=m.critMul;if(m.dodge)h.dodge+=m.dodge/100;if(m.armor)h.armorPts+=m.armor;
        if(m.stamina){const add=m.stamina*((b.char&&b.char.hpPerStamina)||HP_PER_STAMINA);h.max+=add;}if(m.luck)h.luck+=m.luck;if(m.xp)h.xpBonus+=m.xp/100;
        if(m.kbRes)h.kbRes+=m.kbRes/100;if(m.enMax)h.enMaxB+=m.enMax;if(m.enRegen)h.enRegenB+=m.enRegen;if(m.lifesteal)h.lifesteal+=m.lifesteal/100;if(m.move)h.mvMul+=m.move/100;
        if(m.meleeDmg)h.meleeDmg+=m.meleeDmg/100;if(m.rangedDmg)h.rangedDmg+=m.rangedDmg/100;if(m.meleeSpd)h.meleeSpd+=m.meleeSpd/100;if(m.rangedSpd)h.rangedSpd+=m.rangedSpd/100;if(m.kb)h.kbAdd+=m.kb;if(m.cdr)h.cdr=Math.min(.5,(h.cdr||0)+m.cdr/100);}
      {const H=this.slot&&this.slot.heroes&&this.slot.heroes[h.key];const P=(H&&H.pts)||{};   /* level-up stat points (chosen at camp) */
        {const tl=talPicks(H);const m={};let hpP=0,dmP=0;h.healBonus=0;h.revBonus=0;h.cap={};
          for(const id of tl){const [t,a,b]=id.split(':');if(t==='st'){const S=TAL_STAT[a];if(!S)continue;if(S.hpPct)hpP+=S.hpPct;if(S.dmgPct)dmP+=S.dmgPct;if(S.heal)h.healBonus+=S.heal/100;if(S.rev)h.revBonus+=S.rev/100;for(const [x,v] of Object.entries(S.mod||{}))m[x]=(m[x]||0)+v;}
            else if(t==='cap'){h.cap[b]=1;const Cp=HCAP[h.key]&&HCAP[h.key][a]&&HCAP[h.key][a][b];if(Cp&&Cp.stat){if(Cp.stat.hpPct)hpP+=Cp.stat.hpPct;if(Cp.stat.dmgPct)dmP+=Cp.stat.dmgPct;for(const [x,v] of Object.entries(Cp.stat.mod||{}))m[x]=(m[x]||0)+v;}}}
          h.capF=Object.keys(h.cap).filter(x=>CAPFX[x]);
          if(h.cap.glass){dmP+=15;hpP-=10;}if(h.cap.bulwark){hpP+=20;m.armor=(m.armor||0)+2;}if(h.cap.over)m.cdr=(m.cdr||0)+20;if(h.cap.jugg){m.armor=(m.armor||0)+3;m.kbRes=(m.kbRes||0)+40;}
          h.enCostM=h.cap.over?.8:1;h.talDR=h.cap.jugg?.1:0;h.adrOn=0;h.pingOn=0;h.olAcc=0;if(h.key==='shoshi')h.revBonus=(h.revBonus||0)+.3;
          if(hpP)h.max*=1+hpP/100;if(dmP)h.atk*=1+dmP/100;
          if(m.acc)h.acc+=m.acc;if(m.crit)h.crit+=m.crit/100;if(m.dodge)h.dodge+=m.dodge/100;if(m.armor)h.armorPts+=m.armor;if(m.luck)h.luck+=m.luck;
          if(m.kbRes)h.kbRes+=m.kbRes/100;if(m.enMax)h.enMaxB+=m.enMax;if(m.enRegen)h.enRegenB+=m.enRegen;if(m.move)h.mvMul+=m.move/100;
          if(m.meleeSpd)h.meleeSpd+=m.meleeSpd/100;if(m.rangedSpd)h.rangedSpd+=m.rangedSpd/100;if(m.kb)h.kbAdd+=m.kb;if(m.cdr)h.cdr=Math.min(.5,(h.cdr||0)+m.cdr/100);}   /* 0.12.106 talents */
        if(P.hp)h.max*=1+.04*P.hp;if(P.dmg)h.atk*=1+.03*P.dmg;if(P.acc)h.acc+=2*P.acc;if(P.crit)h.crit+=.01*P.crit;if(P.luck)h.luck+=3*P.luck;if(P.armor)h.armorPts+=P.armor;
        if(h.courage){h.courageAcc=this.run&&upgT(this.run,'still')>=4?.85:.8;h.atk*=1.2;h.acc*=h.courageAcc;   /* 0.12.256 (Kyle): Still IV's better brew: -15% accuracy */h.meleeSpd*=1.1;h.rangedSpd*=1.1;}   /* 0.12.252 (Kyle): +20% dmg, +10% atk speed, -20% accuracy (and 10% less damage taken) */{const sv=this.run&&this.run.heroes&&this.run.heroes[h.key];const hu=(sv&&sv.hunger)||0,th=(sv&&sv.thirst)||0;h.hunger=hu;h.thirst=th;if(hu)h.acc-=HUNGER.acc[hu];}   /* 0.12.72 hunger: shaky aim */   /* Liquid Courage */const gt=upgT(this.run,'gen');if(gt)h.enRegenB+=[0,.25,.5,.75,1][gt];const bt=upgT(this.run,'bench');if(bt){h.flatRanged=(h.flatRanged||0)+bt;h.flatMelee=(h.flatMelee||0)+bt;}const sh=upgT(this.run,'shrine');if(sh)h.luck+=[5,10][sh-1];}
      if(insP(h)==='mountain')h.kbRes=Math.min(.95,(h.kbRes||0)+.5);h.luck+=2*(h.inevN||0);if(hasPerk(h,'superlucky'))h.luck*=2;   /* 0.12.56: The Mountain, Inevitable, Super Lucky */
      if(h.hp!=null)h.hp=Math.min(h.max,pct*h.max);}
  }
  alive(){return this.heroes.filter(h=>h.alive).concat((this.pets||[]).filter(p=>p.alive));}
  aliveHeroes(){return this.heroes.filter(h=>h.alive);}
  front(){const a=this.alive();return a.length?a.reduce((m,h)=>h.x>m.x?h:m,a[0]):null;}
  ev(type,o){this.events.push(Object.assign({type},o||{}));}
  // ---------------------------------------------------------------- spawning
  /* 0.12.136 (Kyle) NEMESIS (Shadow of Mordor style): IF an enemy downs a hero THEN it's promoted: it gets a name, heals to full,
     grows bigger and tougher, glows red and wears a name tag. Each further hero it downs ranks it up (max III).
     IF it's still alive when the stage ends THEN it remembers you: it comes back in a later stage, one rank higher.
     Killing one pays out bonus gold and XP. */
  nemesis(e,h){const run=this.run;run.nemeses=run.nemeses||[];const N=e.nem;
    if(!N){const F=['Rotgut','Gnasher','Mulch','Grimjaw','Stitches','Bonesaw','Sludge','Gristle','Moldy Mike','Chompers','Big Sheila','Toejam','Wormtooth','Hollowgut','Larry'],
        T=['the Hungry','Ankle-Biter','the Unkillable','Hero-Eater','the Persistent','of the Gutter','the Smelly','Kneecapper','the Patient','Two-Bites'];
      const used=new Set(run.nemeses.map(n=>n.name));let name;for(let i=0;i<20;i++){name=F[Math.floor(this.rng()*F.length)]+' '+T[Math.floor(this.rng()*T.length)];if(!used.has(name))break;}
      e.nem={id:'n'+Date.now()+Math.floor(this.rng()*1e4),name,rank:0,kills:[]};run.nemeses.push({id:e.nem.id,name,rank:0,type:e.type,kills:[],stage:this.st.n});}
    this.nemRank(e,h);this.ev('nemesis',{name:e.nem.name,rank:e.nem.rank,trait:(e.nem.traits||[]).slice(-1)[0]});}
  /* Nemesis traits (Kyle: skills they pick up): one when it first rises, a second at rank III.
     Ravenous: heals 40% of the damage it deals.  Bloodthirsty: every hit makes them bleed.  Bulwark: +8 armor and 70% knockback resistance.
     Howler: every 12s it howls and 2 zombies come running.  Cleaver: each swing also hits another hero standing next to the target (50%). */
  nemOnHit(e,V,d){if(e.nemHas('rav')){e.hp=Math.min(e.max,e.hp+d*.4);}
    if(e.nemHas('cleave')){const o=this.alive().find(o=>o!==V&&!o.pet&&Math.abs(this.heroX(o)-this.heroX(V))<10&&Math.abs((o.gy||this.G)-(V.gy||this.G))<8);if(o)this.hurtHero(o,d*.5,e);}}
  nemTrait(e){const N=e.nem,pool=['rav','blood','bulwark','howl','cleave'].filter(t=>!(N.traits||[]).includes(t));const t=pool[Math.floor(this.rng()*pool.length)];(N.traits=N.traits||[]).push(t);
    if(t==='bulwark'){e.armorPts=(e.armorPts||0)+8;e.nemKb=.7;}return t;}
  nemRank(e,h){const N=e.nem;if(N.rank>=3){e.hp=e.max;return;}N.rank++;if(h)N.kills.push(h.key);
    e.nemHas=t=>(N.traits||[]).includes(t);if(N.rank===1&&!(N.traits||[]).length)this.nemTrait(e);else if(N.rank===3&&(N.traits||[]).length<2)this.nemTrait(e);
    const r=()=>this.rng();   /* 0.12.136 (Kyle): no two promotions alike: every rank-up rolls its own boosts */
    let hpM=N.rank===1?1.5+r()*.7:1.2+r()*.35;const dmM=1.1+r()*.3,arm=1+Math.floor(r()*3);   /* 0.12.238 (Kyle): less armor on promotions: x1.75 base (was x3), +1-3 a rank (was +1-6) */
    if(!e.nemBase){e.nemBase=1;hpM=5;e.armorPts=Math.round((e.armorPts||0)*1.75);e.E=Object.create(e.E);if(e.E.reach!=null)e.E.reach*=1.2;e.E.spd*=1.2;}   /* 0.12.201 (Kyle): on promotion 5x HP (fully healed), triple armor, +20% reach, +20% speed */
    e.max=Math.round(e.max*hpM);e.hp=e.max;e.dmg*=dmM;e.dmgMul*=dmM;e.armorPts=(e.armorPts||0)+arm;
    if(N.col==null){N.col=['#ff2a1a','#ff8a1a','#b04aff','#4aff7a','#ffd23f','#4ad8ff'][Math.floor(r()*6)];N.size=.95+r()*.25;}
    const R=(this.run.nemeses||[]).find(n=>n.id===N.id);if(R){R.rank=N.rank;R.kills=N.kills.slice();R.stage=this.st.n;R.traits=(N.traits||[]).slice();R.col=N.col;R.size=N.size;}
    this.text(e.x,(e.gy||this.G)-48,N.name.toUpperCase()+(N.rank>1?' · RANK '+'I'.repeat(N.rank):' RISES'),'#ff4a3a');this.shake=Math.max(this.shake||0,.3);
    for(const o of this.alive())if(Math.random()<.5)Comms.bubble(this,o,Comms.pick(N.rank>1?['It\'s getting stronger!','Not HIM again!',N.name.split(' ')[0]+' is back for more!']:['That one\'s got a name now...','We\'ve made an enemy.','Watch out for that one!']));}
  spawnNemesis(n){const e=this.spawnEnemy(n.type||'zombie',{x:this.W+12});e.nem={id:n.id,name:n.name,rank:0,kills:(n.kills||[]).slice(),traits:[]};const r=Math.min(3,(n.rank||1)+1);e.nem.col=n.col;e.nem.size=n.size;for(const t of (n.traits||[])){e.nem.traits.push(t);if(t==='bulwark'){e.armorPts=(e.armorPts||0)+8;e.nemKb=.7;}}
    for(let i=0;i<r;i++)this.nemRank(e,null);this.ev('nemesis',{name:n.name,rank:e.nem.rank,back:1});return e;}
  spawnEnemy(type,opt){
    const E=CFG.enemies[type];const st=this.st;const elite=false;   /* 0.12.87 (Kyle): no elite zombies for now (was 7% +1% a stage) */
    const hp=Math.max(1,Math.round(E.hp*st.hpMul*ENEMY_HP))*(elite?2.6:1);   /* 0.12.103: zombies trimmed with hero damage so fights take as long as before */
    const e={type,E,x:this.W+10+this.rng()*20,y:E.fly?this.G-70+this.rng()*36:this.G,hp,max:hp,dmg:(E.dmg||E.dmgDie/2+.5)*st.dmgMul*(elite?1.5:1),dmgMul:st.dmgMul*(elite?1.5:1),skin:E.skins?E.skins[Math.floor(this.rng()*E.skins.length)]:type,atkT:this.rng()*.5,
      walkT:this.rng(),anim:0,animT:0,slow:0,slowT:0,stun:0,burn:0,burnT:0,shred:0,elite,armorPts:Math.floor((E.armorPts||0)*Math.pow(1.03,(st.n||1)-1)),fly:!!E.fly,ranged:!!E.ranged,hitFlash:0,phase:this.rng()*6,target:null};
    if(opt)Object.assign(e,opt);e.elite=false;   /* 0.12.142 (Kyle): no elites at all (the leftover elite:'roll' made every wave zombie secretly elite); only promoted Nemeses are different */
    this.enemies.push(e);return e;
  }
  spawnBoss(){
    const B=CFG.bosses[this.st.boss];const hp=B.hp*this.st.hpMul;
    const b={type:this.st.boss,B,boss:true,x:this.W+70,y:B.fly?this.G-40:this.G,hp,max:hp,dmg:B.dmg*this.st.dmgMul,atkT:0,t1:2,t2:5,t3:8,anim:0,animT:0,walkT:0,
      slow:0,slowT:0,stun:0,burn:0,burnT:0,shred:0,hitFlash:0,fly:!!B.fly,phase:0,w:22};
    if(!b.E)b.E={spd:B.spd||10,hp:B.hp,kbRes:.9,boss:1,name:B.name};   /* 0.12.215 fix (stage 10 freeze): bosses had no E, so any code reading e.E.something on a boss threw and froze the game */
    this.enemies.push(b);this.boss=b;this.bossSpawned=true;this.ev('boss',{name:B.name});this.shake=.6;for(const h of this.alive())Brain.panic(this,h,'boss');
  }
  pickType(){const n=this.st.n||1;const pool=Object.assign({},this.st.biome.pool);if(pool.skarcher!=null)pool.skarcher=n<3?0:Math.min(.14,.05+.01*(n-3));   /* 0.12.183 (Kyle): Skeleton_Archers from stage 3 (5% of a wave, +1% a stage, max 14%) */if(pool.fireman!=null)pool.fireman=n<3?0:Math.min(.2,.08+.015*(n-3));pool.bat=n<2?0:Math.min(.12,.05+.01*(n-2));   /* 0.12.206 (Kyle): Giant_Bats from stage 2 (5% of a wave, +1% a stage, max 12%) */   /* 0.12.84 (Kyle): Fireman_Zombie from stage 3 (8% of a wave, +1.5% a stage, max 20%) */
    let tot=0;for(const k in pool)tot+=pool[k];let r=this.rng()*tot;for(const k in pool){r-=pool[k];if(r<=0&&pool[k]>0)return k;}return 'zombie';}
  // ---------------------------------------------------------------- damage
  /* 0.12.38 stage stats per unit (shown after a stage clears) */
  st8(h,own){if(!own&&h&&h.owner&&h.owner.key&&!h.dog)h=h.owner;   /* 0.12.68: companions/summons' numbers count for their owner; the Guard Dog keeps his own line */
    const k=(h&&h.key)||'?';this.stats=this.stats||{};return this.stats[k]||(this.stats[k]={dmg:0,heal:0,kills:0,downs:0,revives:0,searches:0,crits:0,heads:0,taken:0,biggest:0});}
  /* 0.12.56 Inevitable: IF something I try fails THEN +2 Luck and +1% crit (up to 10 stacks) until my next crit */
  failAct(h){if(!h||!h.key||this.demo||!hasPerk(h,'inevitable')||(h.inevN||0)>=10)return;h.inevN=(h.inevN||0)+1;h.luck+=2*(hasPerk(h,'superlucky')?2:1);}
  hitEnemy(e,amt,src,opt){
    if(src&&src.perch&&src.perch.roofP&&src.perch.st==='fight')amt*=1.15;else if(src&&src.perch&&src.perchDmg&&src.climbT>=1)amt*=1+src.perchDmg;
    if(src&&src.bnIn)amt*=1+src.bnIn.dmg;   /* 0.12.243 standing in the Dice-Boys_Banner */   /* 0.12.236 tower floors: top +15%, tier 2 +7.5% */   /* 0.12.124 (Kyle): shooting down from a storefront roof: +15% damage from the height */
    if(e.dead||amt<=0)return 0;opt=opt||{};{let o=src,n=0;while(o&&o.owner&&!o.base&&n++<4)o=o.owner;const M=o&&o.base&&HERO_DMG[o.key];if(M)amt*=M;}   /* 0.12.103 (Kyle): every hero's damage tuned so a stage-1 hero averages about 300; healers and utility lower */if(opt.fire&&e.E&&e.E.fireImmune){amt*=.25;if(!opt.quiet&&this.rng()<.3)this.text(e.x,e.y-40,'resist','#9ab');}   /* 0.12.236 (Kyle): damage-type immunity now ignores 75% of the damage (debuff immunities stay 100%) */if(src&&src.key){e.lastHitBy=src;e.grudgeT=1+14*trait(e,'grudge');}
    if(!opt.sure&&e.E&&e.E.dodge&&this.rng()<e.E.dodge){this.text(e.x,e.y-30,'miss','#9aa');this.failAct(src);return 0;}
    let crit=false;if(src&&!opt.nocrit&&this.rng()<src.crit+(opt.critAdd||0)+.01*(src.inevN||0)+(src.laughT>0?.05:0)){amt*=(opt.critMul||src.critMul||1.75);crit=true;if(src.raT>0&&src.key==='archer')src.raT*=.5;   /* One Nocked passive: any crit halves its remaining cooldown */if(src.inevN){src.luck-=2*src.inevN*(hasPerk(src,'superlucky')?2:1);src.inevN=0;}
      const HR=!opt.fromTent&&src.base&&src.base.char&&(src.base.char.abilities||[]).find(a=>a.id==='herald');if(HR){src.critRegenT=HR.critT;for(const T of this.tentacles||[])T.heraldT=HR.critT;}}   // Herald: his crits (not his tentacles') feed him and every tentacle he has out   // Herald: crits feed energy
    if(src&&src.capF&&src.capF.length)amt=capHook('hit',this,src,e,amt,crit,opt);   /* 0.12.249 capstones */
    if(opt.head){amt*=HEADSHOT.mul;this.text(e.x,e.y-(e.fly?24:54),'HEADSHOT!','#ff6040',false);   /* 0.12.36 (Kyle): half the old size */}
    {const ip=insP(src);   // inspiration passives that trigger on his hits
     if(ip==='onslaught'&&(src.moveT||0)>1){amt*=2;src.moveT=0;}
     if(ip==='bounty'&&!e.bounty&&!e.dead){const big=this.enemies.filter(o=>!o.dead).reduce((b,o)=>!b||o.max>b.max?o:b,null);if(big===e){e.bounty=src;e.markT=8;e.markAmp=.25;}}
     if(ip==='pickpocket'&&!e.picked&&!e.boss){e.picked=1;if(this.rng()<.35)this.text(e.x,e.y-34,'$','#ffd23f');}   /* 0.12.45 (Kyle): picked pockets mean better drops when it dies */
     if(ip==='webs'&&!e.boss&&this.rng()<.15){e.slow=Math.max(e.slow||0,.6);e.slowT=Math.max(e.slowT||0,2);e.webT=2;}}
    if(opt.fire&&this.pools&&this.pools.length){for(const P of this.pools)if(!(P.fire>0)&&e.x>=P.x0&&e.x<=P.x1&&Math.abs((e.gy!=null?e.gy:this.G)-P.gy)<P.dz)this.lightPool(P);}
    amt=mitigate(e,amt,opt.type); if(e.shred>0)amt*=1.2;if(e.markT>0)amt*=1+(e.markAmp||.25);   // Pinning_Shot mark
    if(opt.execute&&e.hp<e.max*.3)amt*=2;if(src&&src.cap&&src.cap.exec&&e.hp<e.max*.25)amt*=1.6;   /* Executioner talent */
    amt=Math.max(1,amt);e.hp-=amt;e.hitFlash=.12;this.lastHit=this.t;
    if(src&&src.key&&!this.demo){const S=this.st8(src);S.dmg+=amt;if(crit)S.crits++;if(opt.head)S.heads++;if(amt>S.biggest)S.biggest=amt;}   /* stage stats */
    this.splatter(e,amt,1,crit);
    if(opt.kb>0){const ratio=Math.min(1,amt/Math.max(1,e.max));let kb=ratio<.08?ratio*12:ratio<.25?2+ratio*14:5+ratio*12;   // chip ~0, medium small, big decent
      if(crit)kb*=1.6;if(e.boss)kb*=.12;kb*=opt.kb;if(e.fly)kb*=.7;if(e.nemKb)kb*=1-e.nemKb;else if(e.E&&e.E.kbRes)kb*=1-e.E.kbRes;e.kbv=Math.max(e.kbv||0,Math.min(18,kb)*7);e.kbDir=src&&src.x!=null&&!e.boss?(e.x>=src.x?1:-1):1;}
    if(!opt.quiet||crit)this.text(e.x+(this.rng()*8-4),e.y-(e.boss?100:e.fly?16:44),Math.round(amt),crit?'#ffd23f':opt.fire?'#ffb060':'#ffffff',crit);   /* burn ticks only show a number when they crit */
    if(src&&src.lifesteal>0&&src.alive){const b0=src.hp;src.hp=Math.min(src.max,src.hp+amt*src.lifesteal);if(src.key)this.st8(src).heal+=src.hp-b0;}
    if(!ABILITIES_OFF&&src&&src.style&&src.style.leech)this.healHero(this.weakest(),amt*src.style.leech*.5,true);
    if(src&&src.items&&src.items.length)this.procs(src,crit?'oncrit':'onhit',e);
    if(e.hp<=0){if(opt.blast)e._blast={x:opt.bx!=null?opt.bx:(src?src.x:e.x-20)};this.kill(e,src);}
    return amt;
  }
  kill(e,src){
    if(src&&src.capF&&src.capF.length)capHook('kill',this,src,e);
    if(e.bounty&&!this.demo){this.stageGold+=10;this.text(e.x,e.y-40,'+10','#ffd23f');}
    if(insP(src)==='devour'&&src.alive){this.healHero(src,src.max*.03,true);src.en=Math.min(src.enMax||100,(src.en||0)+4);}
    if(src&&src.key==='knight'&&src.alive){const BO=(src.base.char.abilities||[]).find(a=>a.id==='oath');if(BO)this.healHero(src,src.max*BO.heal,true,src);}   /* 0.12.180 Blood_Oath */
    if(src&&src.key==='csorc'&&src.alive){const AF=(src.base.char.abilities||[]).find(a=>a.id==='arcflow');if(AF)src.en=Math.min(src.enMax||100,(src.en||0)+AF.en);}   /* 0.12.178 Arcane_Flow */
    e.dead=true;this.kills++;if(src&&src.key&&!this.demo)this.st8(src).kills++;this.onKillDark(e);if(src&&src.key&&!this.demo)Brain.showoff(this,src,'kill');if(src&&src.key)Comms.onKill(this,src);
    const xp=(e.boss?e.B.xp*.95:e.E.xp*.8)*this.st.xpMul;   /* 0.12.149 (Kyle): kill XP back up a bit (.7 -> .8, bosses .85 -> .95) */   /* 0.12.142: same XP per kill as before the elite fix (was 2.5 x .33) */   // regular enemies give about half the XP they used to (stages are twice as long)
    /* 0.12.94 (Kyle): scores are much lower: a zombie is worth 1 (werewolf 1.6, fireman 3), +10% a stage; about 50 for a good stage 1 */
    const pts=(e.boss?e.B.pts:e.E.pts*3)/10*(1+.1*(this.st.n-1))*(1+this.run.prestige)*(src?src.scoreM:1);
    this.stageScore+=pts;this.gainXp(xp);
    this.fx.push({k:'poof',x:e.x,y:e.y-(e.fly?0:20),t:0,big:!!e.boss||e.elite});
    if(!e.boss&&e._blast&&/^zombie/.test(e.type)){   /* 0.12.40 (Kyle): blown up by an explosion -> it bursts into gibs instead of falling over */
      const dir=e.x>=e._blast.x?1:-1;const G0=e.gy!=null?e.gy:this.G;const P=[];for(let i=0;i<16;i++){const a=-Math.PI/2+(this.rng()-.5)*2.2;const sp=40+this.rng()*70;
        P.push({x:e.x+(this.rng()-.5)*4,h:4+this.rng()*10,vx:Math.cos(a)*sp*.6+dir*(20+this.rng()*35),vh:-Math.sin(a)*sp*.9,s:i<4?2.2:i<10?1.5:1,c:i%5===0?'#d8d0c0':i%3===0?'#5a7060':['#7a1010','#a01818','#4a0c0c'][i%3],rot:this.rng()*6});}
      this.fx.push({k:'gibs',x:e.x,gy:G0,t:0,life:2.6,raw:1,P,dir});this.fx.push({k:'blood',raw:1,x:e.x,y:G0-12,gy:G0,dir,n:22,big:true,seed:this.rng()*1000,t:0,life:.9});this.shake=Math.max(this.shake||0,.15);}
    else if(!e.boss)this.fx.push({k:'corpse',gy:e.gy,type:e.type,skin:e.skin,x:e.x,y:e.y,fly:e.fly,elite:e.elite,lane:e.lane||0,t:0,life:1.3});
    if(this.team.devour){this.devourStacks=Math.min(60,this.devourStacks+1);for(const h of this.alive())if(h.spells.some(s=>s.arch==='devour'))this.healHero(h,h.max*(.006+.0025*this.spellRank(h,'devour')),true);}
    if(src&&src.items)this.procs(src,'onkill',e);
    if(!this.demo){const st=this.st;const r=this.rng();
      const PK=e.picked?{g:1.6,s:2,p:2.5,i:1.5}:{g:1,s:1,p:1,i:1};const gChance=e.boss?1:e.elite?1:Math.min(.95,(e.E.goldChance!=null?e.E.goldChance:.12)*((this.mods&&this.mods.gold)||1)*PK.g);if(r<gChance){const piles=e.boss?5:e.elite?2:1;   /* 0.12.38 (Kyle): every gold pile is small, 2-6 gold (bosses drop 5 piles, elites 2) */
        const al0=this.aliveHeroes(),lk=al0.length?al0.reduce((s2,o)=>s2+(o.luck||0),0)/al0.length:0;for(let i=0;i<piles;i++){let amt=5+Math.floor(this.rng()*4);if(this.rng()<lk/100)amt+=1+Math.floor(this.rng()*2);this.loot.push({kind:'gold',x:e.x+(this.rng()*14-7),gy:e.gy,amt,t:0,big:false,lucky:amt>8});}   /* 0.12.202 (Kyle): 5-8 gold a pile; the team's average Luck is the % chance a pile has +1-2 extra */   /* 0.12.186 (Kyle): 3-7 gold a pile */   /* 0.12.93 (Kyle): smaller piles since there are more enemies now: 1-5 gold (avg 4.0 -> 2.8) */}
      {const m=e.boss?6:e.nem?2:1;   /* 0.12.38 camp supplies off enemies (low odds): food or water 3%, spare parts 4% */
        /* 0.12.93 (Kyle): food and water each run their own "pity" roll PER HERO (summons, companions and pets don't roll). The first kill is a
           2% chance; every miss adds +0.3% (more with Supply boosts, Luck and a picked-up enemy) until it drops, then it resets to 2%.
           That's about one of each every ~18 kills per hero (0.12.94). Bosses and elites still drop extra. */
        const K=src&&!src.pet&&!src.minion&&this.run.team&&this.run.team.includes(src.key)?src:null;
        if(K){const P=this.run.pity=this.run.pity||{},q=P[K.key]=P[K.key]||{food:0,water:0};const boost=((this.mods&&this.mods.supply)||1)*PK.s*(1+(K.luck||0)/200)*(1+[0,.15,.3][upgT(this.run,'forage')||0]);const kp=insP(K);   /* 0.12.104 Forager / Rain Catcher / Lucky Looter */
          for(const kind of ['food','water']){const ch=Math.min(1,(.02+.0025*q[kind])*boost*m*   /* 0.12.140 (Kyle: too much food and water): 1.2% + 0.15% a miss (was 2% + 0.3%) */((kp==='forager'&&kind==='food')||(kp==='raincatch'&&kind==='water')?2.5:hasPerk(K,'looter')?1.8:1));if(this.rng()<ch){q[kind]=0;this.loot.push({kind,x:e.x+(this.rng()*10-5),gy:e.gy,amt:1,t:0});}else q[kind]++;}}
        else if(m>1&&this.rng()<.03*m)this.loot.push({kind:this.rng()<.5?'water':'food',x:e.x+(this.rng()*10-5),gy:e.gy,amt:1,t:0});
        if(this.rng()<.04*m*((this.mods&&this.mods.parts)||1)*PK.p)this.loot.push({kind:'parts',x:e.x+(this.rng()*10-5),gy:e.gy,amt:1+(this.rng()<.5?1:0),t:0});}
      const iChance=(e.boss?1:e.elite?.1+.01*st.n:(e.E.itemChance!=null?e.E.itemChance:.004+.0012*st.n))*PK.i;if(this.rng()<iChance){const it=rollItem(this.run,this.rng,e.boss?'U':null,e.boss?'boss':e.elite?'elite':'mob');if(it)this.loot.push({kind:'item',x:e.x+6,item:it,t:0});}}
    if(e.nem){const N=e.nem;this.run.nemeses=(this.run.nemeses||[]).filter(n=>n.id!==N.id);const gd=15*N.rank;this.stageGold+=gd;for(const o of this.aliveHeroes())this.supXp(o,10+this.st.n);   /* 0.12.148 (Kyle): a Nemesis gives each hero 10 + the stage number in XP */this.ev('nemdown',{name:N.name});this.text(e.x,(e.gy||this.G)-50,N.name.toUpperCase()+' IS DEAD · +'+gd+'g','#ffd23f');}
    if(e.boss&&(e.type==='harvest'||e.type==='wraith'))this.fx.push({k:e.type+'die',x:e.x,gy:this.G,t:0,life:2.2,raw:1});
    if(e.boss){this.ev('bossdown',{name:e.B.name});this.shake=1;for(const o of this.enemies)if(!o.dead){o.dead=true;this.fx.push({k:'poof',x:o.x,y:o.y-20,t:0});}}
  }
  spellRank(h,arch){const s=h.spells.find(s=>s.arch===arch);return s?s.r:0;}
  gainXp(xp){
    xp*=this.team.xp*(1+ffT(this.run,'xp'))*XP_MUL;   /* 0.12.237 Fall Forward: +10/15/20% XP while you carry stacks */this.stageXp+=xp;
    if(this.demo)return;
    this.run.xp=(this.run.xp||0)+xp;
    while(this.run.xp>=needRunXp(this.run.lv||0)){this.run.xp-=needRunXp(this.run.lv||0);this.run.lv=(this.run.lv||0)+1;this.run.pending=(this.run.pending||0)+1;this.ev('levelup');}
    // persistent hero XP with catch-up for heroes behind the team / the stage
    const al=this.aliveHeroes();if(!al.length||!this.slot)return;
    const lv=this.heroes.map(h=>this.slot.heroes[h.key].lvl);const ref=Math.max(Math.max(...lv),1+(this.st.n-1)*1.3+this.run.prestige*12);
    for(const h of al){const H=this.slot.heroes[h.key];const cu=Math.min(5,1+.4*Math.max(0,ref-H.lvl));H.xp+=xp*1.5*h.base.xpm*(1+(h.xpBonus||0)+[0,.1,.2,.3][upgT(this.run,'dummy')])*cu/al.length;
      while(H.xp>=needHeroXp(H.lvl)){H.xp-=needHeroXp(H.lvl);H.lvl++;this.ev('herolevel',{key:h.key,lvl:H.lvl});this.text(h.x,this.G-70,'LV '+H.lvl,'#7dff9a',true);}}
  }
  /* 0.12.146 (Kyle): a really tiny XP trickle for doing supporty things: 0.03 XP per HP healed on someone else (or repaired on a building),
     3 XP for helping someone up, 0.25 XP per ally Tech_Support reaches. Goes straight to that hero. */
  supXp(h,x){if(!h||!h.key||this.demo||!this.slot||!(x>0))return;x*=(1+ffT(this.run,'xp'))*XP_MUL;while(h&&h.owner&&!h.base)h=h.owner;const H=h&&this.slot.heroes[h.key];if(!H)return;H.xp+=x;
    while(H.xp>=needHeroXp(H.lvl)){H.xp-=needHeroXp(H.lvl);H.lvl++;this.ev('herolevel',{key:h.key,lvl:H.lvl});this.text(h.x,this.G-70,'LV '+H.lvl,'#7dff9a',true);}}
  healHero(h,amt,quiet,by){if(!h||!h.alive||amt<=0||h.dog)return;if(h.hunger>0)amt*=1-HUNGER.heal[h.hunger];   /* 0.12.72: a starving body heals badly */if(!fleshy(h)&&!this._mech)return;   /* 0.12.58: herbs, medkits and healing magic do nothing for the Warhound */{const M=by||this._healBy;if(M&&M.healBonus)amt*=1+M.healBonus;if(M&&hasPerk(M,'medicine'))amt*=1.3;}/* 0.12.56 Medicine Man: heals he gives +30% */const before=h.hp;h.hp=Math.min(h.max,h.hp+amt);{const B=by||this._healBy||h;if(B&&B.key&&!this.demo){this.st8(B).heal+=h.hp-before;if(B!==h)this.supXp(B,(h.hp-before)*.036);}}if(!quiet&&h.hp-before>=1)this.text(h.x,this.G-56,'+'+Math.round(h.hp-before),'#7dff9a');}
  weakest(){const a=this.alive().filter(fleshy);return a.length?a.reduce((m,h)=>h.hp/h.max<m.hp/m.max?h:m,a[0]):null;}
  // hit visual: a spray of blood thrown away from the blow, drops falling to the ground and leaving a fading spatter
  splatter(u,amt,dir,crit){if(this.demo&&this.rng()<.5)return;const boss=!!u.boss;const gy=u.gy!=null&&!u.fly?u.gy:this.G;
    const y=boss?gy-30:u.fly?u.y:gy-(u.type==='werewolf'?8:12);   // chest height on the half-size units
    this.fx.push({k:'blood',raw:1,x:u.x,y,gy:boss?gy:gy,dir,n:Math.min(18,6+Math.round(amt*1.2))+(crit?8:0),big:crit||boss,seed:this.rng()*1000,t:0,life:.9});}
  // Bleed: damage over time that ignores armor; reapplying refreshes it (doesn't stack)
  bleed(h,total,dur){if(h&&!fleshy(h))return;   /* 0.12.238 (Kyle): the Warhound can't bleed (or be poisoned) */const fresh=!(h.bleedT>0);h.bleedT=dur;h.bleedDps=total/dur;h.bleedTick=h.bleedTick||0;if(fresh)this.text(h.x,this.G-66,'BLEED','#ff3a4a');}
  hurtHero(h,amt,from){
    if(!h||!h.alive)return;
    /* 0.12.65 (Kyle) Guard Dog: no HP, he can take 5 hits (6 with a Tier III Kennel) before he goes down; one hit comes back every 15s (10s at Tier III).
       He can't be healed, but anyone can help him up (dogs never help others up: no hands). */
    if(h.dog){if(!this._noDodge&&this.rng()<h.dodge){this.text(h.x,this.G-30,'dodge','#9ae6ff');return false;}if(h.invulnT>0)return false;h.hits=(h.hits||0)-1;h.hitFlash=.12;h.hitRegT=0;h.hp=h.max*Math.max(0,h.hits)/h.hitsMax;
      if(h.hits<=0){h.alive=false;h.downed=0;h.gone=1;h.hp=0;h.plan=null;this.fx.push({k:'corpse',gy:h.gy,type:h.skin||'dog',skin:h.skin||'dog',x:h.x,y:h.gy,t:0,life:1.6,hero:1});this.fx.push({k:'poof',x:h.x,y:this.G-14,t:0});Comms.bubble(this,h,'*yelp*',true);if(this.slot)this.st8(h).downs++;
        this.pets=(this.pets||[]).filter(p=>p!==h);(this.dogQ=this.dogQ||[]).push(this.t+40);for(const o of this.alive())if(!o.pet&&this.rng()<.35){Comms.bubble(this,o,Comms.pick(['NO! Not the dog!','Good boy... rest easy.','They got the dog!','The kennel will send another.']));break;}}return true;}   /* 0.12.204 (Kyle): a dog that goes down is gone (no helping it up); the kennel sends a fresh one 40s later */if(from&&from.E){h.lastHitBy=from;h.grudgeT=1+19*trait(h,'grudge');}   // Forgiving forgets in a second; Vengeful holds it 20s
    if(!this._noDodge&&this.rng()<h.dodge+this.eliteDodge(h)){this.text(h.x,this.G-52,'dodge','#9ae6ff');return false;}   /* 0.12.232: enemy traps can't be dodged */
    if(from&&from.E&&!h.pet&&h.key!=='edward'&&!this._loyal){const ED=this.heroes.find(o=>o.key==='edward'&&o.alive&&o!==h);if(ED){const LY=(ED.base.char.abilities||[]).find(a=>a.id==='loyal');
      if(LY&&h.hp/h.max<LY.under&&Math.abs(this.heroX(ED)-this.heroX(h))<LY.r){const part=amt*LY.share;amt-=part;this._loyal=1;this.hurtHero(ED,part,from);this._loyal=0;if(ED.cap&&ED.cap.ed_bond)this.healHero(h,h.max*.04,true,ED);ED.en=Math.min(ED.enMax||100,(ED.en||0)+(LY.en||0));if(this.rng()<.08)Comms.bubble(this,ED,Comms.pick(['I got you!','Lean on me!','Not on my watch!','That one\'s on me!']),true);}}}   /* 0.12.207 Edward: Loyal_to_a_Fault */
    if(h.chutzT>0){amt*=1-(h.czDR||.3);h.chzStk=Math.min(5,(h.chzStk||0)+1);}   /* 0.12.220 Chutzpah: soaks 30% and every hit stores +10% for his next shot */
    if(from&&from.E&&!h.pet)from.dmgDone=(from.dmgDone||0)+amt;   /* for Edward's Paper_Trail */
    {const bc=h.base&&h.base.char&&h.base.char.blockCh;if(bc&&from&&!(h.smoking)&&this.rng()<bc){this.text(h.x,this.G-52,'BLOCK','#e8c890');this.ev('hit',{});h.blockT=.25;return false;}}   /* 0.12.79: shields block */
    if(from&&from.smokeT>0&&this.rng()<(from.smokeMiss||.5)){this.text(h.x,this.G-52,'miss','#c8d0d8');return false;}   // Smoke_Screen: blinded attackers miss half the time
    if(!this._bgRedirect&&from){const bg=this.alive().find(o=>o!==h&&insP(o)==='bodyguard'&&Math.abs(this.heroX(o)-this.heroX(h))<14&&Math.abs((o.gy||this.G)-(h.gy||this.G))<6);
      if(bg){this._bgRedirect=1;this.hurtHero(bg,amt*.3,from);this._bgRedirect=0;amt*=.7;}}   // Bodyguard takes 30% of the hit
    {const ip=insP(h);
     if(ip==='omen'&&(h.omenCd||0)<=this.t){h.omenCd=this.t+12;this.text(h.x,this.G-52,'miss','#b8a0ff');return false;}
     if(ip==='haunt'&&from&&from.E&&!from.boss&&this.rng()<.2){from.retreatT=Math.max(from.retreatT||0,1.5);from.fearT=1.5;}
     if(ip==='shell'&&h.hp/h.max<.4&&(h.shellCd||0)<=this.t){h.shellCd=this.t+30;h.shellT=3;}}
    if(h.cloneT>0&&from&&from.E&&(this.clones||[]).some(c=>c.owner===h&&Math.abs(c.x-h.x)<40)&&this.rng()<(h.cloneDecoy||.35)){this.fx.push({k:'spark',x:h.x-(h.face||1)*10,y:this.G-22,t:0,c:'#9ad8ff'});return false;}   // Shadow_Clone soaks it
    if(h.smokeT>0&&this.rng()<.25){this.text(h.x,this.G-52,'dodge','#c8d0d8');return false;}   // ...and heroes inside the smoke are harder to hit
    if(h.invulnT>0){this.text(h.x,this.G-52,'miss','#9ae6ff');return false;}
    amt=mitigate(h,amt,'physical');if(from&&from.boss&&insP(h)==='mountain')amt*=.9;if(h.rageT>0)amt*=.75;if(h.shellT>0)amt*=.3;if(amt>0&&h.herbT>0)h.herbT=0;   // a hit stops a herb heal
    if(h.gritT>0)amt*=1-(h.gritDR||0);
    if(h.perch&&h.perch.hp>0)return false;   /* 0.12.75: up on the lookout, nothing can reach them */
    if(h.kitHits>0){h.kitHits--;if(h.kitHits<=0){h.armorPts-=h.kitAdd||0;h.kbRes-=h.kitKb||0;h.kitAdd=0;h.kitKb=0;this.text(h.x,this.G-60,'plating gone','#b8c0cc');}}   /* Field_Plating */
    if(h.key==='robot'){if(h.jet)amt=Math.min(amt,(h.jet.A&&h.jet.A.cap)||5);if(from&&h.nbT>0&&this.rng()<.1){h.nbT/=2;this.text(h.x,this.G-60,'CD½','#7fe0ff');}}   /* 0.12.67 Tactical_Retreat shield; Nano-Tech's built-in CD halving */
    if(h.key==='jp'){if(h.highT>0)amt*=.8;if(h.trashT>0)amt*=.7;if(h.rush)return false;}   /* JP: high 10% less, Trash_Talk 30% less, immune while rushing to family */   // True_Grit (0.12.63: this was hidden inside the comment above, so Grit never actually reduced damage)
    if(h.talDR)amt*=1-h.talDR;   /* Juggernaut talent */
    if(h.courage)amt*=this.run&&upgT(this.run,'still')>=4?.85:.9;   /* 0.12.257 (Kyle): Still IV: 15% less damage taken */   /* Liquid Courage: can't feel a thing (until he goes down or the stage ends) */
    if(h.capF&&h.capF.length)amt=capHook('hurt',this,h,from,amt);
    if(h.sakeB&&h.sakeB.vul)amt*=1+h.sakeB.vul;   /* 0.12.242 Drunken_Style: sloppy guard, takes more damage */
    if(h.wallT>0)amt*=1-(h.wallDR||.6);   /* 0.12.180 Shield_Wall */
    if(h.key==='soldier'){const HB=(h.base.char.abilities||[]).find(a=>a.id==='hardened');if(HB&&h.hp<h.max*HB.under)amt*=1-HB.dr;}   /* 0.12.175 Battle_Hardened */
    if(this.heroes.some(o=>o.key==='shoshi'&&o.alive)){const L=h.dmgLog=h.dmgLog||[];L.push([this.t,amt]);while(L.length&&this.t-L[0][0]>4)L.shift();}   /* for Shoshi's Ctrl_Z */
    if(h.dadT>0)amt*=1-(h.dadDR||.4);   /* Shoshi's Dad_Mode */
    if(h.staticT>0&&from&&!from.dead&&!from.key&&from.x!=null){this.hitEnemy(from,this.rollDice(h.staticZap||[1,4])*(h.staticMul||1),h.staticBy&&h.staticBy.alive?h.staticBy:null,{sure:1,nocrit:1});this.fx.push({k:'bolt',pts:[[this.heroX(h),(h.gy||this.G)-14],[from.x,(from.gy!=null?from.gy:this.G)-14]],t:0,life:.15,raw:1,c:'y'});}   /* 0.12.195 Static_Shield zap */
    if(h.shield>0){const s=Math.min(h.shield,amt);h.shield-=s;amt-=s;if(h.thorns&&from&&!from.dead)this.hitEnemy(from,s*.3,null,{nocrit:1,sure:1});}
    if(amt<=0)return false;
    {const was=h.hp/h.max;h.hp-=amt;if(h.key&&was>=.35&&h.hp/h.max<.35)Brain.panic(this,h,'hurt');
     /* On Track <-> New Plan: IF I'm hit mid-search or mid-revive THEN rethinkers drop it, relentless units finish the job */
     if(h.key&&!this.demo){const pl=trait(h,'plan');if(h.search&&!h.search.disarm&&Math.random()<.08+.55*pl){h.search=null;h.srDecide={o:null,until:this.t+2,go:false};h.amDecide=null;h.plan=null;h.thinkT=0;}
       else if(h.plan&&h.plan.reviveD&&Math.random()<.05+.45*pl){h.revDecide={D:h.plan.reviveD,until:this.t+1.5,go:false};h.plan=null;h.thinkT=0;}}}
    /* 0.12.56: heavy hits shove heroes back a little (boss hits and anything over 15% of max HP); knockback resistance and The Mountain cut it */
    if(from&&from.E&&h.key&&(from.boss||amt>=h.max*.15)){const v=(from.boss?48:24)*(1-Math.min(.95,h.kbRes||0));if(v>1){h.kbv=Math.max(h.kbv||0,v);h.kbDir=(from.x>=this.heroX(h))?-1:1;}}
    if(h.key==='robot'&&h.alive&&h.hp>0&&h.hp/h.max<.3&&!h.jet&&!(h.pdT>0)&&(h.base.char.abilities||[]).some(a=>a.id==='directive'))this.startJet(h);
    h.hitFlash=.12;this.text(h.x+4,this.G-52,Math.round(amt),'#ff5a5a');if(h.key&&!this.demo)this.st8(h).taken+=amt;
    {const PL=h.base&&h.base.char&&(h.base.char.abilities||[]).find(a=>a.id==='plating');if(PL){h.plStacks=(h.plStacks||0)+1;   // Reactive_Plating
      if(h.plStacks>=PL.stacks&&!(h.plCd>this.t)){h.plStacks=0;h.plCd=this.t+PL.cd;h.shield=Math.max(h.shield||0,h.max*PL.shield);h.shieldT=PL.shieldT;this.shake=Math.max(this.shake||0,.3);
        this.fx.push({k:'ring',x:h.x,y:this.G-10,r:PL.r,t:0,c:'#7fd8ff'});this.fx.push({k:'quake',x:h.x,gy:h.gy||this.G,t:0,life:.5,raw:1});this.ev('boom',{});
        for(const e of this.enemies){if(e.dead||e.fly||e.boss)continue;if(Math.abs(e.x-h.x)<PL.r&&Math.abs((e.gy||this.G)-(h.gy||this.G))<12){const res=(e.E&&e.E.kbRes)||0;e.kbv=Math.max(e.kbv||0,PL.kb/100*40*8*(1-res));e.kbDir=e.x>=h.x?1:-1;}}}}}
    {const F=this.camp;if(F&&(F.state==='burn'||F.state==='start')&&(h===F.owner||h.owner===F.owner)){F.life--;if(F.life<=0){F.state='dying';F.dT=0;this.text(F.x,this.G-40,'THE FIRE DIES','#9aa');}}}
    this.splatter(h,amt,-1,false);
    this.procs(h,'whenhit',from,amt);
    if(h.hp/h.max<.35)for(const o of this.alive())this.procs(o,'allylow',null,0,h);
    if(h.hp<=0){if(from&&from.E&&!from.boss&&!from.dead&&!h.pet&&!h.dog)this.nemesis(from,h);this.heroDown(h);}
    return true;
  }
  heroDown(h){if(this.tryResurge(h))return;if(h.capF&&h.capF.length&&capHook('down',this,h))return;if(h.key==='cheez'&&(h.attendUsed||0)<(h.cap&&h.cap.cz_speed?2:1)&&(h.base.char.abilities||[]).some(a=>a.id==='attend')){h.attendUsed=(h.attendUsed||0)+1;h.hp=1;h.invulnT=2;if(h.cap&&h.cap.cz_speed){tbuff(h,{sp:.5,mv:.3},4);h.iaT=0;}this.text(this.heroX(h),(h.gy||this.G)-54,'PERFECT ATTENDANCE','#3af0ff',true);Comms.bubble(this,h,Comms.pick(['I have NEVER missed game night!','Not tonight. I\'m hosting!','Perfect attendance, baby!']),true);return;}   /* 0.12.234 Cheez: never misses game night */if(!h.pet)for(const o of this.alive())if(o.key==='shoshi'&&o!==h){o.pingT=4;this.text(this.heroX(o),(o.gy||this.G)-50,'PING!','#b38cff');}   /* Circle_Ping */if(h.cap&&h.cap.last&&!h.lsUsed&&!h.pet){h.lsUsed=1;h.hp=1;h.alive=true;h.invulnT=3;this.text(this.heroX(h),(h.gy||this.G)-50,'LAST STAND!','#ffd23f');this.fx.push({k:'ring',x:this.heroX(h),y:(h.gy||this.G)-10,r:18,t:0,c:'#ffd23f'});return;}   /* 0.12.106 Last Stand talent */h.building=null;h.repairing=null;h.syph=null;h.jet=null;h.lz=null;h.nano=null;h.stealthT=0;h.leap=null;h.leapH=0;h.whirl=null;h.dash=null;h.rolling=null;   /* no frozen mid-move poses */for(const o of this.alive())if(o!==h&&Math.abs(this.heroX(o)-this.heroX(h))<90)Brain.panic(this,o,'down');if(h.key&&!this.demo)this.st8(h).downs++;if(!h.pet&&h.cap&&h.cap.wind&&!h.swUsed){h.swUsed=1;h.windT=this.t+3;}   /* Second Wind talent */if(!h.pet){if(h.courage&&!(upgT(this.run,'still')>=4||upgT(this.run,'still')===3&&this.rng()<.5)){h.courage=0;h.atk/=1.2;h.acc/=h.courageAcc||.8;h.meleeSpd/=1.1;h.rangedSpd/=1.1;h.moods=(h.moods||[]).filter(m=>m.name!=='courage');}   /* 0.12.253 (Kyle): the jar wears off when you go down; 0.12.254: Still III 50% it stays, Still IV it always stays (stage end still clears it) */h.downed=1;h.revT=0;h.downT=this.t;h.search=null;h.plan=null;h.alDecide=null;h.srDecide=null;h.building=null;h.repairing=null;h.smoking=null;h.rush=null;h.cast=null;}   /* 0.12.102 fix: going down drops whatever job I was in the middle of (alarm, search, build...) *//* 0.12.22: downed, not dead: an ally can help them up */if(h.lastHitBy&&!h.lastHitBy.dead&&!this.demo)Brain.showoff(this,h.lastHitBy,'down');h.hp=0;h.alive=false;h.bleedT=0;this.ev('herodown',{key:h.key});Comms.onDown(this,h);this.fx.push({k:'poof',x:h.x,y:this.G-20,t:0,big:true});
    if(!h.pet){for(const p of this.pets||[])if(p.owner===h&&p.alive&&!p.dog){p.alive=false;this.fx.push({k:'poof',x:p.x,y:this.G-20,t:0});}}   // she leaves when he goes down
    if(!this.aliveHeroes().length){this.over='defeat';this.ev('defeat');
      /* 0.12.150 (Kyle): a small "learned something" bonus for a loss so a stuck team can grind through: each hero gets
         (4 + stage) x how far they got (0..1). Stage 7 at the halfway point = +5.5 XP each; a clear of that stage is worth ~60. */
      this.lossXp=0;   /* 0.12.251 (Kyle): Lessons Learned is no longer a lump of XP on a loss; it IS Fall Forward's XP bonus */}}
  procs(h,trig,e,amt,ally){
    if(ABILITIES_OFF)return;
    for(const it of h.items){if(!it.proc)continue;const P=PROCS[it.proc];if(P.t!==trig)continue;const ch=procChance(it.r)/100;const a=h.atk*h.pow;
      if(trig==='onhit'||trig==='oncrit'){if(this.rng()>ch||!e||e.dead)continue;
        if(it.proc==='ignite'){e.burn=Math.max(e.burn,a*.35);e.burnT=3;}
        if(it.proc==='spark')this.shoot(h,e,'bolt',a*.8,{});
        if(it.proc==='stunhit')e.stun=Math.max(e.stun,.6);
        if(it.proc==='critnova'){this.fx.push({k:'ring',x:e.x,y:e.y-16,r:22,t:0,c:'#ffb040'});for(const o of this.enemies)if(!o.dead&&Math.abs(o.x-e.x)<26)this.hitEnemy(o,a*.6,null,{nocrit:1});}}
      if(trig==='onkill'){if(this.rng()>ch)continue;
        if(it.proc==='killheal')for(const o of this.alive())this.healHero(o,o.max*.04);
        if(it.proc==='killraise')this.addMinion(h,h.max*.15,a*.4,8,'raise','item:'+it.card,1);}
      if(trig==='whenhit'){
        if(it.proc==='hitshield'&&this.rng()<ch){h.shield+=h.max*.08;h.shieldT=4;}
        if(it.proc==='hitthorns'&&e&&!e.dead)this.hitEnemy(e,amt*ch*1.5,null,{nocrit:1,sure:1});}
      if(trig==='allylow'&&ally&&ally.alive&&!(it.cd>0)){it.cd=20;this.healHero(ally,ally.max*(.1+ch/2));this.fx.push({k:'ring',x:ally.x,y:this.G-24,r:16,t:0,c:'#7dff9a'});}
      if(trig==='oncast'&&this.rng()<ch){h.buffT=3;}
      if(trig==='near'&&!(it.cd>0)){it.cd=6;this.fx.push({k:'ring',x:h.x+20,y:this.G-20,r:40,t:0,c:'#9ae6ff'});
        for(const o of this.enemies)if(!o.dead&&o.x-h.x<60){o.slow=Math.max(o.slow,.4+.02*it.r);o.slowT=2;this.hitEnemy(o,a*(.2+.05*it.r),null,{nocrit:1});}}
    }
  }
  // tag = which ability made it; cap = how many from that ability may be out (oldest gets replaced)
  addMinion(owner,hp,atk,life,kind,tag,cap){const f=this.front();const m={owner,hp,max:hp,atk,life,x:(f?f.x:120)+16+this.rng()*10,atkT:0,kind:kind||'spirit',taunt:false,explode:false,leech:false,
    ranged:RANGED_SUMMONERS.has(owner.key),tag:tag||kind,born:this.t};
    const same=this.minions.filter(o=>o.owner===owner&&o.tag===m.tag).sort((a,b)=>a.born-b.born);
    while(same.length>=(cap||1)){const o=same.shift();o.dead=true;this.fx.push({k:'poof',x:o.x,y:this.G-14,t:0});}
    this.minions=this.minions.filter(o=>!o.dead);this.minions.push(m);return m;}
  shoot(h,target,kind,dmg,opt){
    const mz=MUZZLE[h.key]||[10,30];const lift=h.perch?(h.leapH||0)*.6:0;const y0=this.G-mz[1]-lift;   /* 0.12.76: up on the lookout, shots leave from up there */const p={kind,x:h.x+(h.face<0?-mz[0]:mz[0]),y:y0,tx:target,dmg,src:h,spd:PSPD[kind]||160,pierce:opt.pierce||(h.style&&h.style.pierce)||0,opt,t:0,vy:kind==='brick'?-70:0,hit:new Set()};
    if(h&&h.ocN>0&&kind==='zap'){h.ocN--;p.dmg*=h.ocMul||1.5;p.oc=1;const J=h.ocJump||40;p.opt.onHit=(e,d)=>{this.hitEnemy(e,d,h,{});const n=this.enemies.filter(o=>!o.dead&&o!==e&&!o.fly&&Math.abs(o.x-e.x)<J&&Math.abs((o.gy!=null?o.gy:this.G)-(e.gy!=null?e.gy:this.G))<14).sort((a,b)=>Math.abs(a.x-e.x)-Math.abs(b.x-e.x))[0];
      if(n){this.hitEnemy(n,d*.5,h,{sure:1});this.fx.push({k:'bolt',pts:[[e.x,(e.gy!=null?e.gy:this.G)-12],[n.x,(n.gy!=null?n.gy:this.G)-12]],t:0,life:.25,raw:1,c:'y'});}};}   /* 0.12.195 Overcharge */
    this.proj.push(p);return p;
  }
  aim(p,h,tg){if(h&&h.sprayT>0){h._accBonus=(h._accBonus||0)-18;const r=this._aimInner(p,h,tg);h._accBonus+=18;return r;}return this._aimInner(p,h,tg);}
  _aimInner(p,h,tg){   // turn a shot into a free-flying projectile aimed with the reticle (0.11): either direction, heroes or enemies
    p.aimed=true;p.gy=h.gy!=null?h.gy:this.G;p.h=(h.fly?(this.G-h.y)/UNIT_SCALE:(h.key&&HERO_HB[h.key]?(MUZZLE[h.key]||[0,14])[1]/UNIT_SCALE:28))+(h.perch?(h.leapH||0)*.6/UNIT_SCALE:0);const air=tg.fly&&!tg.boss;const flyH=air?(this.G-tg.y)/UNIT_SCALE:0;
    const tx=tg.boss?tg.x-tg.w*.5:(tg.key?this.heroX(tg):tg.x);p.dir=tx>=p.x?1:-1;const dist=Math.abs(tx-p.x);
    if(air){let fh=flyH;if(tg.vx!=null){const T=dist/Math.max(60,p.spd||160),lx=tg.vx*T*.85,ly=(tg.vy||0)*T*.6;p.dist=Math.max(14,Math.abs(tx+lx-p.x));fh=(this.G-(tg.y+ly))/UNIT_SCALE;}   /* 0.12.206 (Kyle): shooters lead moving fliers a little, by how fast they're going */
      p.aimH=rollAirAim((h.acc||0)+(h._accBonus||0),this.rng,fh);p.tgy=p.gy;}
    else if(tg.boss){p.aimH=rollAimHeight((h.acc||0)+(h._accBonus||0),this.rng);p.tgy=tg.gy!=null?tg.gy:this.G;}
    else{const R=h._forceBox?reticleBox(tg,h._forceBox,this.rng):reticle((h.acc||0)+(h._accBonus||0),tg,dist,this.rng);p.aimH=R.h;p.tgy=(tg.gy!=null?tg.gy:this.G)+R.off;}
    p.arc=ARC[p.kind]||0;p.h0=p.h;p.x0=p.x;p.dist=air&&p.dist?p.dist:Math.max(14,dist);p.gy0=p.gy;p.tx=null;p.foes=h.key?'enemies':'heroes';}
  text(x,y,s,c,big,sc){if(this.demo&&typeof s==='number'&&this.rng()<.6)return;this.texts.push({x,y,s:String(s),c,t:0,big:!!big,sc});}
  // ---------------------------------------------------------------- spells
  cast(h,s){
    const S=SPELL[s.arch];if(S.passive)return;
    const r=Math.min(CFG.maxRank,s.r),a=h.atk*h.pow*(r>=10?1.25:1),aug={};for(const g of s.augs||[])aug[g]=1;
    const live=this.enemies.filter(e=>!e.dead&&e.x<this.W+4);
    const extra=aug.extra?1:0;let did=true;
    const onHit=(e,amt,kb)=>{const d=this.hitEnemy(e,amt,h,{execute:aug.execute,nocrit:false,kb:kb==null?1:kb});
      if(aug.burn){e.burn=Math.max(e.burn,a*.3);e.burnT=3;} if(aug.stun)e.stun=Math.max(e.stun,.6); if(aug.slow){e.slow=Math.max(e.slow,.3);e.slowT=2.5;}
      if(aug.shred)e.shred=5; if(aug.knock&&!e.boss)e.x+=18; if(aug.leech)this.healHero(this.weakest(),d*.12,true); return d;};
    const fx=(k,o)=>this.fx.push(Object.assign({k,t:0},o));
    switch(s.arch){
      case 'bolt':{if(!live.length){did=false;break;}const n=1+Math.floor(r/4)+extra;const tg=live.slice().sort((p,q)=>p.x-q.x);
        for(let i=0;i<n;i++)setTimeoutSafe(this,i*.22,()=>{if(!h.alive)return;const t=tg[i%tg.length];if(t.dead)return;this.shoot(h,t,'bolt',a*(.7+.12*r),{pierce:aug.pierce?3:0,onHit:(e,d)=>onHit(e,d,0),chain:aug.chain});});break;}
      case 'nova':{const f=this.front();if(!f||!live.length){did=false;break;}const R=(46+3*r)*h.reach;fx('ring',{x:f.x+R/2,y:this.G-22,r:R*.6,c:'#c050ff'});
        let any=false;for(const e of live)if(e.x-f.x<R){onHit(e,a*(1.2+.22*r));any=true;}this.shake=Math.max(this.shake,.2);if(!any)did=false;break;}
      case 'smite':{if(!live.length){did=false;break;}const tg=live.slice().sort((p,q)=>q.hp-p.hp);fx('beam',{x:tg[0].x,y:tg[0].y,c:'#fff4a0'});onHit(tg[0],a*(2.4+.45*r));
        if(aug.chain&&tg[1]){fx('beam',{x:tg[1].x,y:tg[1].y,c:'#fff4a0'});onHit(tg[1],a*(1.2+.22*r));}break;}
      case 'drain':{if(!live.length){did=false;break;}const n=2+Math.floor(r/3)+(aug.extra?2:0);let tot=0;const tg=live.slice().sort(()=>this.rng()-.5).slice(0,n);
        for(const e of tg){tot+=onHit(e,a*(.6+.12*r),0);fx('drain',{x:e.x,y:e.y-(e.fly?0:24),tx:h.x,c:'#ff3a5a'});}this.healHero(this.weakest(),tot*.4);break;}
      case 'summon':{const style=SUMMON_STYLE[h.key]||'replace';const tag='spell:'+s.card;const kind=h.key==='blood'?'bat':h.key==='joel'?'spore':h.key==='robots'||h.key==='mech'?'drone':h.key==='grim'||h.key==='korvold'?'raise':'spirit';
        const hp=h.max*(.18+.03*r),atk=a*(.35+.06*r);const mine=this.minions.filter(m=>m.owner===h&&m.tag===tag);const cap=(r>=10?3:r>=5?2:1)+extra;
        if((style==='empower'||style==='mend'||style==='linger')&&mine.length>=cap){
          const m=mine.sort((p,q)=>p.hp/p.max-q.hp/q.max)[0];
          if(style==='empower'&&(m.stacks||0)<3){m.stacks=(m.stacks||0)+1;m.max*=1.25;m.atk*=1.25;}
          m.hp=m.max;m.life=style==='linger'?18:10;this.fx.push({k:'ring',x:m.x,y:this.G-16,r:12,t:0,c:style==='empower'?'#ffd23f':'#7dff9a'});break;}
        if(style==='volatile')for(const o of mine.slice(0,Math.max(0,mine.length-cap+1))){o.dead=true;this.fx.push({k:'ring',x:o.x,y:this.G-16,r:26,t:0,c:'#ff8a1f'});
          for(const e of this.enemies)if(!e.dead&&Math.abs(e.x-o.x)<32)this.hitEnemy(e,o.atk*2.4,h,{nocrit:1,kb:.6});}
        this.minions=this.minions.filter(o=>!o.dead);
        const n=style==='swarm'?2:1,mult=style==='swarm'?.55:1;
        for(let i=0;i<n;i++){const m=this.addMinion(h,hp*mult,atk*mult,style==='linger'?18:10,kind,tag,style==='swarm'?cap*2:cap);
          m.taunt=!!aug.taunt||h.key==='felothar';m.explode=!!aug.explode;m.leech=!!aug.leech;m.small=style==='swarm';}break;}
      case 'regen':{const pct=.08+.014*r;if(aug.all){for(const o of this.alive())this.healHero(o,o.max*pct);}else{const w=this.weakest();if(!w||w.hp>=w.max){did=false;break;}this.healHero(w,w.max*pct);}
        if(aug.shield){h.shield+=h.max*.06;h.shieldT=5;}fx('ring',{x:h.x,y:this.G-24,r:14,c:'#7dff9a'});break;}
      case 'aegis':{for(const o of this.alive()){o.shield+=h.max*(.05+.013*r);o.shieldT=6;o.thorns=!!aug.thorns;}fx('ring',{x:h.x,y:this.G-24,r:26,c:'#9ae6ff'});break;}
      case 'freeze':{if(!live.length){did=false;break;}for(const e of live){e.slow=Math.max(e.slow,.45);e.slowT=1.6+.15*r;if(aug.stun)e.stun=Math.max(e.stun,.5);onHit(e,a*(.3+.08*r),0);}fx('frost',{});break;}
      case 'counter':{let any=false;for(const p of this.proj)if(p.enemy){p.dead=true;any=true;}for(const e of live)if(e.ranged||e.boss){e.stun=Math.max(e.stun,.6+.1*r);onHit(e,a*(.4+.1*r));any=true;}
        if(aug.shield){h.shield+=h.max*.06;h.shieldT=5;}if(!any)did=false;else fx('ring',{x:h.x+30,y:this.G-30,r:30,c:'#ffffff'});break;}
    }
    if(did){this.procs(h,'oncast');if(aug.echo&&!s._echo){const t=this;const s2=Object.assign({},s,{_echo:1,r:Math.max(1,Math.floor(r/2))});setTimeoutSafe(this,.9,()=>t.cast(h,s2));}}
    return did;
  }
  // ---------------------------------------------------------------- main step
  /* 0.12.58 (Kyle): IF what I'm working on (a search, an alarm, a mine, a plant) slides off the screen, or I'm being dragged off the edge with it,
     THEN drop it right away (bar and all) and think again. */
  /* 0.12.58 (Kyle): Hardcore: every area attack hurts allies caught in it too (the caster is spared). Hits each ally at most once per 'key'. */
  ffArea(src,x,gy,r,depth,dmg,key){if(!this.hardcore||!src||!src.key||!(dmg>0))return;for(const o of this.alive()){if(o===src||o.pet&&o.owner===src)continue;
      if(key){o._ffK=o._ffK||new Set();if(o._ffK.has(key))continue;}
      if(Math.abs(this.heroX(o)-x)<=r&&Math.abs((o.gy||this.G)-(gy==null?this.G:gy))<=depth){if(key)o._ffK.add(key);this.hurtHero(o,dmg,null);const S=this.st8(src);S.ff=(S.ff||0)+1;}}}
  /* 0.12.62 Warhound flamethrower: a cone that widens from 5 to 15 (gy) over 70px in front of him; every enemy in it starts (or restarts) burning */
  /* 0.12.75 Engineer: buildings */
  finishBuild(h,W){const BU=(h.base.char.abilities||[]).find(a=>a.id==='build'),MO=(h.base.char.abilities||[]).find(a=>a.id==='modify');const B=this.blds=this.blds||[];this.ev('thorns',{});
    if(W.k==='tower'){const A=BU.tower;B.push({bld:1,k:'tower',tier:1,x:W.x,gy:W.gy,hp:A.hp,max:A.hp,A,owner:h,t:0,occ:null});this.text(W.x,W.gy-40,'WATCHTOWER','#ffd23f');}
    else if(W.k==='tier'){const T=W.tgt;if(T&&T.hp>0&&T.tier<3){T.tier++;const nm=T.A.hp*Math.pow(1+T.A.per,T.tier-1);T.hp+=nm-T.max;T.max=nm;this.text(T.x,T.gy-50,'TIER '+T.tier,'#ffd23f');}}
    else if(W.k==='barrier'){const A=BU.barrier;B.push({bld:1,k:'barrier',x:W.x,gy:W.gy,hp:A.hp,max:A.hp,A,owner:h,t:0});}
    else if(W.k==='tesla'){const A=BU.tesla;B.push({bld:1,k:'tesla',x:W.x,gy:W.gy,hp:A.hp,max:A.hp,A,owner:h,t:0,zT:.5});}
    else if(W.k==='turret'){const A=MO.turret;const car=W.car;if(car){car.turret=1;B.push({bld:1,k:'turret',car,x:car.x,gy:LANES[Math.max(...car.lanes)],hp:A.hp,max:A.hp,A,owner:h,t:0,rl:0,shots:0,sT:0});}}}
  bldBlock(e,dt){for(const b of this.blds){if(b.hp<=0)continue;const ey=e.gy!=null?e.gy:this.G;
      if((b.k==='barrier'||b.k==='sandbag')&&Math.abs(ey-b.gy)<=b.A.depth&&e.x>b.x-2&&e.x<b.x+12){e.x=Math.max(e.x,b.x+10);e.bwT=(e.bwT||0)+dt;if(e.bwT>=(e.E&&e.E.atk||1.2)){e.bwT=0;e.anim=1;e.animT=.3;b.hp-=e.dmg;b.hitT=.15;if(b.A.barb){e.hp-=b.A.barb;e.hitFlash=.1;if(e.hp<=0)this.hitEnemy(e,1,null,{sure:1,nocrit:1});}}}
      else if(b.k==='tower'&&(b.occ||b.occ2)&&!e.E.ranged&&e.x>b.x-6&&e.x<b.x+55&&Math.abs(ey-b.gy)<=24&&!(e.target&&e.target.alive&&!e.target.perch&&Math.abs(this.heroX(e.target)-e.x)<14)){   /* 0.12.236 (Kyle): heroes up the tower make it a juicy target: nearby zombies (2 lanes either way) go for the legs */
        if(Math.abs(ey-b.gy)>1&&e.gy!=null)e.gy+=Math.sign(b.gy-ey)*Math.min(Math.abs(b.gy-ey),dt*14);if(e.x<b.x+9){e.x=Math.max(e.x,b.x+6);e.bwT=(e.bwT||0)+dt;if(e.bwT>=(e.E&&e.E.atk||1.2)){e.bwT=0;e.anim=1;e.animT=.3;b.hp-=e.dmg*1.25;b.hitT=.15;}}}
      else if(b.k!=='barrier'&&b.k!=='sandbag'&&b.k!=='turret'&&Math.abs(e.x-b.x)<9&&Math.abs(ey-b.gy)<5){e.bwT=(e.bwT||0)+dt*.5;if(e.bwT>=(e.E&&e.E.atk||1.2)){e.bwT=0;b.hp-=e.dmg;b.hitT=.15;}}}}
  satchelBoom(S){S.boom=1;const A=S.A,h=S.owner;this.fx.push({k:'boom',x:S.x,gy:S.gy,t:0,life:1.3,raw:1,big:1},{k:'crack',x:S.x,gy:S.gy,t:0,life:4,raw:1,r:A.r*.8},{k:'slam',x:S.x,gy:S.gy,t:0,life:.9,raw:1,r:A.r,seed:Math.random()*99});this.ev('boom',{});this.shake=Math.max(this.shake||0,1);
    const mul=h&&h.base?(h.atk/h.base.atk)*(h.rangedDmg||1)*(hasPerk(h,'sapper')?1.25:1):1;
    for(const e of this.enemies){if(e.dead)continue;const dx=Math.abs(e.x-S.x)-(e.boss?e.w*.4:0),dz=e.fly?0:Math.abs((e.gy!=null?e.gy:this.G)-S.gy);const d=Math.hypot(Math.max(0,dx),dz*1.6);if(d>A.r)continue;const f=1-.7*d/A.r;
      this.hitEnemy(e,(this.rollDice(A.dice)+((h&&h.flatRanged)||0))*mul*f,h&&h.alive?h:null,{sure:1});if(!e.dead&&!e.boss){const res=(e.E&&e.E.kbRes)||0;e.kbv=Math.max(e.kbv||0,A.kb/100*40*8*(1-res)*f);e.kbDir=e.x>=S.x?1:-1;e.stun=Math.max(e.stun||0,.5*f);}}
    if(this.hardcore)for(const o of this.alive()){const d=Math.abs(this.heroX(o)-S.x);if(d<A.r&&Math.abs((o.gy||this.G)-S.gy)<14)this.hurtHero(o,this.rollDice(A.dice)*(1-.7*d/A.r)*.8,null);}
    for(const o of this.obst||[])if(/^car_/.test(o.k)&&Math.abs(o.x-S.x)<A.r&&o.alarmed==null&&!this.demo){o.alarmed=this.rng()<.5;if(o.alarmed)this.carAlarm(o);}}
  stepEng(dt,scroll){
    if(this.satchels&&this.satchels.length){for(const S of this.satchels){S.t+=dt;S.x0-=scroll*dt;S.x1-=scroll*dt;const u=Math.min(1,S.t/S.T);S.x=S.x0+(S.x1-S.x0)*u;S.hgt=50*Math.sin(Math.PI*u)*(u<1?1:0);if(S.x<-10)S.boom=1;}
      this.satchels=this.satchels.filter(S=>!S.boom);}
    const B=this.blds;if(!B||!B.length){this.engAuras(dt);return;}
    for(const b of B){b.t+=dt;b.x-=scroll*dt;if(b.hitT>0)b.hitT-=dt;if(b.car)b.x=b.car.x;
      if(b.k==='tesla'){b.hp-=b.max/b.A.life*dt;b.zT-=dt;if(b.zT<=0&&b.hp>0){const T=this.enemies.filter(e=>!e.dead&&Math.abs(e.x-b.x)<b.A.r).sort((p,q)=>Math.abs(p.x-b.x)-Math.abs(q.x-b.x))[0];
          if(T){b.zT=b.A.every;const mul=b.owner&&b.owner.base?(b.owner.atk/b.owner.base.atk):1;this.hitEnemy(T,(this.rollDice(b.A.dice)+(b.A.flat||0))*mul,b.owner&&b.owner.alive?b.owner:null,{sure:1});
            const pts=[[b.x,b.gy-20],[T.x,(T.gy!=null?T.gy:this.G)-12]];const T2=this.enemies.find(e=>!e.dead&&e!==T&&Math.abs(e.x-T.x)<25);
            if(T2){this.hitEnemy(T2,(this.rollDice(b.A.dice)+(b.A.flat||0))*mul*.6,b.owner&&b.owner.alive?b.owner:null,{sure:1});pts.push([T2.x,(T2.gy!=null?T2.gy:this.G)-12]);}
            this.fx.push({k:'bolt',pts,t:0,life:.25,raw:1});this.ev('zap',{});}else b.zT=.3;}}
      if(b.k==='turret'&&b.hp>0){const A=b.A;if(b.rl>0)b.rl-=dt;else{b.sT-=dt;if(b.sT<=0){const T=this.enemies.filter(e=>!e.dead&&e.x>b.x-20&&Math.abs(e.x-b.x)<A.range).sort((p,q)=>Math.abs(p.x-b.x)-Math.abs(q.x-b.x))[0];
          if(T){b.sT=A.gap;b.shots++;b.face=T.x>=b.x?1:-1;const ty=(T.gy!=null?T.gy:this.G)-12;this.fx.push({k:'tracer',x0:b.x+b.face*4,y0:b.gy-26,x1:T.x+(Math.random()-.5)*6,y1:ty+(Math.random()-.5)*8,t:0,life:.08,raw:1});this.ev('gun',{});
            if(this.rng()<A.hit)this.hitEnemy(T,this.rollDice(A.dice),b.owner&&b.owner.alive?b.owner:null,{sure:1,nocrit:1});
            if(b.shots>=A.burst){b.shots=0;b.rl=A.reload;}}else b.sT=.2;}}}}
    for(const b of B){if(b.hp<=0&&!b.gone){b.gone=1;this.fx.push({k:'poof',x:b.x,y:b.gy-14,t:0,big:true});if(b.car)b.car.turret=0;this.unperchAll(b);}}
    for(const b of B){if(b.k==='tower'&&!b.gone&&b.x<=-14&&b.owner){b.gone=1;this.unperchAll(b);
        if(b.owner.twT>0||b.owner.moT>0){b.owner.twT=0;b.owner.moT=0;this.text(this.heroX(b.owner),this.G-62,'tower + Modify ready!','#ffd23f');}}}   /* 0.12.95 (Kyle): a tower left behind RESETS the tower and Modify cooldowns */
    this.blds=B.filter(b=>!b.gone&&b.x>-30);
    this.engAuras(dt);}
  engAuras(dt){const B=this.blds||[];
    /* 0.12.200 Ammo_Drop crates: buff allies near them; one free full mag per ally per crate when they step onto it */
    if(this.crates&&this.crates.length){for(const K of this.crates){K.t+=dt;K.x-=(this.scroll||0)*dt;for(const o of this.alive()){if(o.pet)continue;const dx=Math.abs(this.heroX(o)-K.x),dz=Math.abs((o.gy||this.G)-K.gy);
        if(dx<K.A.r&&dz<14)o.crateT=.3;const C3=o.base.char;if(dx<6&&dz<5&&!K.taken.has(o)&&C3&&C3.ranged&&C3.ranged.clip>0){K.taken.add(o);o.ammo=C3.ranged.clip;o.reloadT=0;this.text(this.heroX(o),(o.gy||this.G)-40,'FULL MAG','#ffd27a');this.ev('ok',{});}}}
      this.crates=this.crates.filter(K=>K.t<K.A.dur&&K.x>-10);}
    for(const o of this.alive()){if(o.crateT>0)o.crateT-=dt;if(o.ammoBuffT>0)o.ammoBuffT-=dt;o._bAcc=o._bAcc||0;let acc=0;
      for(const b of B){if(b.hp<=0)continue;const dx=this.heroX(o)-b.x,ad=Math.abs(dx),dz=Math.abs((o.gy||this.G)-b.gy);
        if(b.k==='tower'&&ad<b.A.r){if(b.tier>=1)this.healHero(o,o.max*b.A.regen*dt,true,b.owner);if(b.tier>=2)o.ammoBuffT=.3;if(b.tier>=3&&!b.occ&&!b.occ2)acc=Math.max(acc,b.A.acc);}
        if((b.k==='barrier'||b.k==='sandbag')&&b.A.acc&&dx<0&&dx>-b.A.behind&&dz<=b.A.depth)acc=Math.max(acc,b.A.acc);}
      if(acc!==o._bAcc){o.acc+=acc-o._bAcc;o._bAcc=acc;}}
    // lookout: IF the tower is tier 3 and empty THEN the nearest ranged ally (not the Engineer) climbs up
    /* 0.12.236 (Kyle): two floors. 'occ' = the top lookout (tier 3), 'occ2' = the tier-2 floor. Two shooters can station on one tower together. */
    for(const b of B){if(b.k!=='tower'||b.tier<2||b.hp<=0)continue;
      for(const sl of ['occ','occ2'])if(b[sl]&&(!b[sl].alive||b.x<12))this.unperch(b,sl);
      /* 0.12.174 (Kyle): every 2s someone is up, 20% chance per downed ally that they climb down to help. Nobody climbs up while an ally is down. */
      const downs=this.heroes.filter(o=>!o.pet&&!o.alive&&o.downed);
      for(const sl of ['occ','occ2']){const o=b[sl];if(!o||o.climbT<1)continue;o.dnT=(o.dnT||0)+dt;if(o.dnT>=2){o.dnT=0;
        if(downs.length&&this.rng()<Math.min(1,.2*downs.length)){const all=this.heroes.filter(x=>!x.pet&&x!==o).every(x=>!x.alive);this.unperch(b,sl);o.climbT=0;
          Comms.bubble(this,o,Comms.pick(all?['Hold on, I\'m coming down!','Nobody else is standing, I\'m coming!']:['Man down! Coming down!','Hang on, I\'m on my way!','Getting off this thing!']),true);}}}
      /* who climbs: a ranged hero (not the Warhound) near the tower. The top first (tier 3), then the tier-2 floor; a second shooter thinks about joining
         the first one (Shooters up to 120px away walk over for it, others only if they're right there, 70px). The Engineer goes last. */
      const slots=b.tier>=3?['occ','occ2']:['occ2'];
      for(const sl of slots){if(b[sl]||b.x<=20||downs.length)continue;
        const cand=this.alive().filter(o=>!o.pet&&!o.perch&&!(o.perchCd>this.t)&&!o.jet&&o.key!=='robot'&&o.base.char&&o.base.char.ranged&&!this.isMeleeHero(o)&&!(o.key==='eng'&&(o.building||o.repairing))&&Math.abs(this.heroX(o)-b.x)<(trait(o,'range')<.45?120:70)+(b.occ||b.occ2?20:0))
          .sort((p,q)=>(p.key==='eng')-(q.key==='eng')||Math.abs(this.heroX(p)-b.x)-Math.abs(this.heroX(q)-b.x));const o=cand[0];
        if(o){const top=sl==='occ';b[sl]=o;o.perch=b;o.perchSl=sl;o.climbT=0;o.perchAddAcc=top?b.A.perchAcc:b.A.midAcc;o.acc+=o.perchAddAcc;o.perchR=top?b.A.perchRange:b.A.midRange;o.perchDmg=top?b.A.perchDmg:b.A.midDmg;
          const mate=b[top?'occ2':'occ'];Comms.bubble(this,o,Comms.pick(mate?['Room for one more!','Scoot over, '+Comms.name(mate)+'.','Two guns up top!']:['Going up!','I have the high ground.','Nice view.']),true);}}
      /* 0.12.264 (Kyle: he sat up there and never shot): a shooter with nothing in range for 2.5s climbs down and rejoins the march (won't climb back for 6s) */
      for(const sl of ['occ','occ2']){const o=b[sl];if(!o||o.climbT<1)continue;const st=STYLE[o.key]||{};const Rr=(st.range||170)*(1+(o.perchR||0));
        if(this.enemies.some(e=>!e.dead&&Math.abs(e.x-this.heroX(o))<=Rr))o.upIdle=0;else if((o.upIdle=(o.upIdle||0)+dt)>2.5){o.upIdle=0;o.perchCd=this.t+6;this.unperch(b,sl);o.climbT=0;}}
      for(const sl of ['occ','occ2']){const o=b[sl];if(!o)continue;o.pauseT=Math.max(o.pauseT||0,.05);o.moving=false;   /* 0.12.76: they slide up the ladder (about 1s), then step over to the middle */
        const H=sl==='occ'?150:100,ox=b.x+(sl==='occ2'&&b.occ?-3:0);
        if(o.climbT<1){if(o.climbT===0)o.x=b.x+14;o.climbT=Math.min(1,o.climbT+dt/(H/150*1.1));o.x+=(b.x+14-o.x)*Math.min(1,dt*12);o.leapH=H*o.climbT;}else{o.x+=(ox-o.x)*Math.min(1,dt*8);o.leapH=H;}}}
    // Field_Plating: IF the Engineer has been next to an ally for 3s AND they have no kit THEN strap one on
    for(const h of this.heroes){if(h.key!=='eng'||!h.alive)continue;const PL=(h.base.char.abilities||[]).find(a=>a.id==='plating');if(!PL)continue;
      for(const o of this.alive()){if(o===h||o.dog||o.kitHits>0)continue;if(Math.abs(this.heroX(o)-this.heroX(h))<PL.r&&Math.abs((o.gy||this.G)-(h.gy||this.G))<8){o.kitT=(o.kitT||0)+dt;if(o.kitT>=PL.T){o.kitT=0;o.kitHits=PL.hits;o.kitAdd=o.armorPts*PL.armor;o.armorPts+=o.kitAdd;o.kitKb=PL.kb;o.kbRes=(o.kbRes||0)+PL.kb;this.text(o.x,this.G-60,'+PLATING','#c8d0dc');this.ev('zap',{});}}else o.kitT=0;}}}
  /* 0.12.236 Cheez's Iaijutsu wave: flies down his lane, 2d8 to each zombie it passes (first a crit), fades at the end of its run */
  stepWaves(dt){const IAd=[2,8];for(const W of this.waves){const step=W.spd*dt;W.x+=W.dir*step-(this.scroll||0)*dt;W.left-=step;W.t+=dt;const h=W.src;
      if(h){const mul=(h.atk/h.base.atk)*h.meleeDmg;for(const e of this.enemies){if(e.dead||e.fly||W.hit.has(e))continue;const ey=e.gy!=null?e.gy:this.G;if(Math.abs(ey-W.gy)>8)continue;if(Math.abs(e.x-W.x)>(e.boss?e.w*.5+4:6))continue;
        W.hit.add(e);const IA=(h.base.char.abilities||[]).find(a=>a.id==='iai');this.hitEnemy(e,(this.rollDice(W.dice||(IA&&IA.dice)||IAd)+(W.flat||0))*mul*(W.first?(h.critMul||1.8):1),h,{sure:1,nocrit:W.first?1:0,kb:.6,wave:1});if(W.first){W.first=0;this.text(e.x,ey-48,'IAI!','#3af0ff');}}}
      if(W.left<=0||W.x<-6||W.x>this.W+6)W.gone=1;}
    for(const W of this.waves)if(W.gone&&W.src&&W.src.wave===W){W.src.wave=null;W.src.blinkOK=0;}
    this.waves=this.waves.filter(W=>!W.gone);}
  /* 0.12.238 Sake buff (Cheez's own Drunken_Style, or a shared swig): +25% attack speed (melee and ranged), +15% dodge, -10 accuracy, times 'mul' */
  sakeBuff(o,mul,dur,SK){if(o.sakeB)this.sakeEnd(o);const B={T:dur,sp:SK.spd*mul,dg:SK.dodge*mul,vul:(SK.vul||0)*mul};o.sakeB=B;o.meleeSpd*=1+B.sp;o.rangedSpd=(o.rangedSpd||1)*(1+B.sp);o.dodge+=B.dg;}   /* 0.12.242 (Kyle): no accuracy penalty (he has no ranged); the downside is +15% damage taken */
  sakeEnd(o){const B=o.sakeB;if(!B)return;o.meleeSpd/=1+B.sp;o.rangedSpd/=1+B.sp;o.dodge-=B.dg;o.sakeB=null;}
  unperch(b,sl){const o=b[sl];if(!o)return;o.perch=null;o.leapH=0;o.acc-=o.perchAddAcc||0;o.perchAddAcc=0;o.perchR=0;o.perchDmg=0;o.perchSl=null;b[sl]=null;}
  unperchAll(b){this.unperch(b,'occ');this.unperch(b,'occ2');}
  /* 0.12.70 Void_Cultist: pay life for an ability (never below 25%) */
  payLife(h,c){if(h.hp-h.max*c<h.max*.25)return false;h.hp-=h.max*c;this.text(h.x+4,this.G-52,'-'+Math.round(h.max*c),'#c0102a');this.fx.push({k:'ring',x:h.x,y:(h.gy||this.G)-8,r:10,t:0,c:'#c0102a'});unstealth(h);return true;}
  /* 0.12.67 Warhound: one Missile_Barrage-strength missile at T (used by the barrage and by Tactical_Retreat) */
  fireMissile(h,T,MS){if(!T)return;const mul=(h.atk/h.base.atk)*h.rangedDmg*(h.cryDmg||1);this.ev('whoosh',{});
    (this.missiles=this.missiles||[]).push({x0:h.x+(h.face<0?-3:3),x:h.x,tx:T.x+(this.rng()*2-1)*MS.spread,gy:h.gy||this.G,tgy:Math.max(LANES[0],Math.min(LANES[LANES.length-1],(T.gy||this.G)+(this.rng()*2-1)*6)),t:0,T:MS.fly*(.9+this.rng()*.2),A:MS,src:h,mul,trail:0,h0:h.leapH||0});}
  /* Targeted Lazer: 0.5s charge (the tip tracks the target), then a 2s beam whose tip creeps forward; damage every 0.5s around the tip */
  robotLazer(h,dt,LZ){const L=h.lz;L.t+=dt;h.pauseT=Math.max(h.pauseT||0,.05);h.moving=false;h.face=L.dir;const S=h.surgeT>0;L.tx-=(this.scroll||0)*dt;
    if(L.t<LZ.charge){if(L.tg&&!L.tg.dead){L.tx=L.tg.x-L.dir*LZ.lead;L.gy=L.tg.gy!=null?L.tg.gy:this.G;}return;}
    if(!L.fired){L.fired=1;this.ev('lazer',{d:LZ.fire});}   /* 0.12.129 (Kyle): a proper bzzzz for the lazer */
    L.tx+=L.dir*(S?LZ.travelS:LZ.travel)/LZ.fire*dt;   /* 0.12.77: a smooth fast sweep */if(this.pools&&this.pools.length)this.igniteAt(L.tx,L.gy,6);   /* 0.12.216 the lazer lights oil */
    L.dt+=dt;if(L.dt>=LZ.tick||L.first==null){L.first=1;if(L.dt>=LZ.tick)L.dt-=LZ.tick;else L.dt=0;const r=S?LZ.rS:LZ.r,dice=S?LZ.diceS:LZ.dice,mul=(h.atk/h.base.atk)*h.rangedDmg*(h.cryDmg||1);L.puff=1;
      for(const e of this.enemies){if(e.dead)continue;const dx=Math.abs(e.x-L.tx)-(e.boss?e.w*.5:0),dz=e.fly?0:Math.abs((e.gy!=null?e.gy:this.G)-L.gy);if(dx>r||dz>Math.max(4,r*.75))continue;
        this.hitEnemy(e,(this.rollDice(dice)+(S?(LZ.flatS||0):(LZ.flat||0))+(h.flatRanged||0))*mul,h,{sure:1});   /* 0.12.245 (Kyle): basic lazer 1d4+1 */if(S&&!e.dead)e.fb={T:(h.base.char.abilities.find(a=>a.id==='surge')||{}).burn||2,tick:e.fb?e.fb.tick:.2,src:h,mul};}
      if(this.hardcore)for(const o of this.alive()){if(Math.abs(this.heroX(o)-L.tx)<=r&&Math.abs((o.gy||this.G)-L.gy)<=Math.max(4,r*.75)){this.hurtHero(o,this.rollDice(dice)*.8,null);const S8=this.st8(h);S8.ff=(S8.ff||0)+1;}}}
    if(L.t>=LZ.charge+LZ.fire||L.tx<-4||L.tx>this.W+6){h.lz=null;h.lzReload=LZ.reload;}}
  /* Tactical_Retreat: an arc on the jetpack back to ~100 screen px from the left edge, then a slow landing. Same flight time from anywhere. */
  startJet(h,mode){const PD=(h.base.char.abilities||[]).find(a=>a.id==='directive');if(!PD)return;const CB=mode==='carpet'&&PD.carpet;const TR=CB||PD.retreat;
    if(CB){h.jet={t:0,T:CB.T,x0:h.x,x1:Math.min(this.W-20,h.x+CB.dist),A:CB,shot:0,carpet:1};h.pdT=CB.cd*(1-(h.cdr||0));}else{h.jet={t:0,T:TR.T,x0:h.x,x1:TR.x1,A:TR,shot:0};h.pdT=TR.icd*(1-(h.cdr||0));}   /* one shared Primary_Directive cooldown */h.lz=null;h.nano=null;h.plan=null;
    this.ev('whoosh',{});this.shake=Math.max(this.shake||0,.2);Comms.bubble(this,h,CB?Comms.pick(['CARPET BOMB: INBOUND.','PAYLOAD: ARMED.','CLEARING THE ROAD.','DANGER CLOSE.']):Comms.pick(['TACTICAL RETREAT.','JETS: ENGAGED.','DISENGAGING.','REPOSITIONING.']),true);}
  robotJet(h,dt){const J=h.jet,A=J.A;J.t+=dt;h.pauseT=Math.max(h.pauseT||0,.05);h.moving=false;if(J.carpet)J.x1-=(this.scroll||0)*dt;else J.x1=A.x1;const u=Math.min(1,J.t/J.T);
    const ux=Math.min(1,u/.78),e=ux*ux*(3-2*ux);h.x=J.x0+(J.x1-J.x0)*e;h.face=J.x1<J.x0?-1:1;
    h.leapH=u<.3?A.H*Math.sin(u/.3*Math.PI/2):u<.55?A.H:A.H*Math.pow(1-(u-.55)/.45,1.5);
    const MS=(h.base.char.abilities||[]).find(a=>a.id==='missiles');while(MS&&J.shot<A.shots&&u>=(J.shot+.6)/(A.shots+.4)){J.shot++;let live=this.enemies.filter(e=>!e.dead&&e.x>0&&e.x<this.W);if(J.carpet){const lo=Math.min(J.x0,J.x1)-10,hi=Math.max(J.x0,J.x1)+40;const path=live.filter(e=>e.x>=lo&&e.x<=hi);if(path.length)live=path;}if(live.length)this.fireMissile(h,live[Math.floor(this.rng()*live.length)],{...MS,spread:4});}
    if(u>=1){h.jet=null;h.leapH=0;this.jetSmash(h);Comms.bubble(this,h,Comms.pick(['TOUCHDOWN.','REPAIRS ADVISED.','RE-ENGAGING.']));}}
  /* 0.12.236 (Kyle) jetpack landing: GROUND SMASH, 2d6 within 135px, big knockback away from him on either side */
  jetSmash(h){const S=h.cap&&h.cap.rb_omega?{r:70,dice:[4,6],kb:5,stun:1.5}:JET_SMASH,gy=h.gy||this.G,mul=(h.atk/h.base.atk)*(h.cryDmg||1);this.fx.push({k:'smash',x:h.x,gy,r:S.r,t:0,life:.7,raw:1});this.fx.push({k:'puff',x:h.x,y:gy-2,t:0,life:.5,s:2.2});
    this.shake=Math.max(this.shake||0,.35);this.ev('boom',{});
    for(const e of this.enemies){if(e.dead||e.fly)continue;const dx=Math.abs(e.x-h.x)-(e.boss?e.w*.5:0),dz=Math.abs((e.gy!=null?e.gy:this.G)-gy);if(dx>S.r||dz>S.r*.6)continue;this.hitEnemy(e,this.rollDice(S.dice)*mul,h,{sure:1,kb:S.kb});if(S.stun&&!e.dead&&!e.boss)e.stun=Math.max(e.stun||0,S.stun);}}
  flameSpray(h,tg,FL){const dir=tg.x>=h.x?1:-1;h.face=dir;this.ev('flame',{});if(this.pools&&this.pools.length)this.igniteAt(h.x+dir*(FL.len||40)/2,h.gy||this.G,(FL.len||40)/2);   /* 0.12.129 (Kyle): a flamethrower whoosh-roar */const gy=h.gy!=null?h.gy:this.G,x0=h.x+dir*12;const mul=(h.atk/h.base.atk)*h.rangedDmg*(h.cryDmg||1);
    this.fx.push({k:'flame',x:x0,gy,dir,len:FL.len,w0:FL.w0,w1:FL.w1,t:0,life:FL.dur,raw:1,src:h});this.ev('whoosh',{});
    const inCone=(x,y)=>{const d=(x-x0)*dir;if(d<-2||d>FL.len)return false;return Math.abs(y-gy)<=FL.w0+(FL.w1-FL.w0)*Math.max(0,d)/FL.len;};
    for(const e of this.enemies){if(e.dead||e.fly)continue;const ey=e.gy!=null?e.gy:this.G;if(!(inCone(e.x,ey)||(e.boss&&Math.abs(e.x-x0)<FL.len+e.w&&Math.sign(e.x-x0)===dir)))continue;
      this.hitEnemy(e,(FL.hit||3)*mul,h,{sure:1,fire:1,quiet:1});if(!e.dead){const tot=this.rollDice(FL.burnDice||[2,4]),T=FL.burn||3;e.fb={T,tick:0,src:h,mul,per:tot/(T/.25)};}}   /* 0.12.247 (Kyle): 2 flat on contact, then a burn of 1d4 spread over 3s */
    if(this.hardcore)for(const o of this.alive()){if(o===h||o.pet&&o.owner===h)continue;if(inCone(this.heroX(o),o.gy||this.G)){this.hurtHero(o,this.rollDice([2,4]),null);const S=this.st8(h);S.ff=(S.ff||0)+1;}}}
  dropLost(){const off=x=>x==null||x<14||x>this.W+8;
    for(const h of this.alive()){let lost=false;const S=h.search,D=h.defuse,P=h.plan;
      if(S&&S.o&&(off(S.o.x)||(!S.trap&&this.obst&&!this.obst.includes(S.o))))lost=true;   /* 0.12.156 fix: a defuse job points at a mine, not an obstacle; this used to throw every defuse out on its first frame */
      if(D&&D.M&&(off(D.M.x)||!(this.mines||[]).includes(D.M)))lost=true;
      if(P&&P.goTo&&((P.goTo.ob&&(off(P.goTo.ob.x)||!(this.obst||[]).includes(P.goTo.ob)))||(P.goTo.mine&&off(P.goTo.mine.x))))lost=true;
      if((S||D||h.planting||h.setting||h.tossing)&&this.heroX(h)<12)lost=true;
      if(lost){h.search=null;h.defuse=null;h.planting=null;h.setting=null;h.tossing=null;h.plan=null;h.thinkT=0;h.pauseT=0;if(S&&S.o&&S.o.searchBy===h)S.o.searchBy=null;}}}
  step(dt){CURG=this;
    if(this.over)return;this.t+=dt;
    const T=this;const al=this.alive();this.dropLost();for(const h of this.heroes)if(h.alive&&h.thirst>0&&!this.over){h.hp-=h.max*THIRST.drain[h.thirst]*dt;if(h.hp<1)h.hp=1;}   /* 0.12.72: dehydration drains a little life (never kills on its own) */for(const p of this.pets||[])if(p.dog&&!p.alive&&p.downed){p.x-=(this.scroll||0)*dt;if(p.x<-10)p.downed=0;}   /* a downed dog is left behind if nobody helps him up before he slides off screen */
    for(const p of this.pets||[])if(p.dog&&p.alive&&p.hits<p.hitsMax){p.hitRegT=(p.hitRegT||0)+dt;if(p.hitRegT>=p.hitRegEvery){p.hitRegT=0;p.hits++;p.hp=p.max*p.hits/p.hitsMax;}}   /* dog: one hit back every 15s (10s at Kennel III) */
    if(!this._hearth){this._hearth=1;if(!this.demo&&this.run&&upgT(this.run,'hearth'))for(const h of al)giveCozy(h);if(!this.demo&&this.run&&upgT(this.run,'jukebox'))for(const h of al)if(!h.pet)addMood(h,{nerve:-2},1e9,'jukebox');
      if(!this.demo&&this.slot)for(const h of al){const H=this.slot.heroes[h.key];for(const id of talPicks(H))if(id.startsWith('ps:')){const P=TAL_PERSONA[id.slice(3)];if(P)addMood(h,P.shift,1e9,'talent');}}   /* 0.12.106 personality talents */   /* 0.12.105 Old Jukebox */
      const sb=!this.demo&&this.run&&upgT(this.run,'sandbag');if(sb){const pool=al.filter(h=>!h.pet).sort(()=>this.rng()-.5);for(const h of pool.slice(0,sb>=3?2:1)){h.sandbag=sb;Comms.bubble(this,h,Comms.pick(['Got the sandbags.','I\'ll carry the bags.','Sandbags on my back!']));}}}   /* 0.12.104 Sandbag Wall: random carriers */   /* Hearth camp upgrade: everyone starts the stage Cozy */
    for(const t of this.timers||[])t.t-=dt;
    if(this.timers){for(const t of this.timers.filter(t=>t.t<=0))t.fn();this.timers=this.timers.filter(t=>t.t>0);}
    // 0.12.2 behavior AI: everyone reads the same snapshot of the battlefield, then each hero thinks on its own clock
    Brain.snapshot(this);for(const h of al)h._gt=this.t;Comms.step(this,dt);
    for(const h of al){Brain.tick(h,dt);if(Brain.due(this,h,dt)){const foes=this.enemies.filter(e=>!e.dead&&e.x<this.W+4);
      const pk=Brain.pickTarget(this,h,foes,al,true);const lane=Brain.pickLane(this,h,pk&&pk.tgt,true);const pos=Brain.pickPosition(this,h,pk&&pk.tgt);
      const gw=pos.goTo&&pos.goTo.ob?OBST[pos.goTo.ob.k]:null;h.plan={tgt:pk&&pk.tgt,why:pos.reviveD?'helping '+Comms.name(pos.reviveD)+' up':pos.intent==='disarm'?'shutting off the car alarm':pos.intent==='search'?'searching the '+(/^car_/.test(pos.goTo.ob.k)?'wreck':'debris'):pos.intent==='herb'?'bringing supplies to '+Comms.name(pos.goTo):pos.intent==='guard'?'guarding '+Comms.name(pos.goTo):pos.intent==='orbit'?(h.dog?'guarding ':'circling ')+Comms.name(h.owner):pos.intent==='hunker'?'taking cover':pos.intent==='crate'?'grabbing a mag from the ammo crate':pos.intent==='defuse'?'defusing a mine':pos.intent==='sneak'?'eyeing '+Comms.name(pos.goTo)+'\'s pockets':(pk?pk.why:''),lane:pos.reviveLane!=null?pos.reviveLane:lane,...pos};
      if(pos.intent==='hold'&&trait(h,'pace')<.45&&Math.random()<(1-trait(h,'pace'))*.5)h.pauseT=.4+1.6*(1-trait(h,'pace'));}}   // slow-and-steady units stop to think
    // formation
    // formation: everyone heads for their slot at their own pace; while marching, quicker heroes drift ahead and slow ones lag a little
    const avgMv=al.reduce((m,h)=>m+(MOVE[h.key]||26),0)/Math.max(1,al.length);
    al.forEach((h,i)=>{const mv=MOVE[h.key]||26;const drift=this.scroll?Math.max(-8,Math.min(10,(mv-avgMv)*.9)):0;let tx=this.exiting?this.W+60:(h.plan&&h.plan.goTo&&h.plan.goTo.crate?h.plan.goTo.crate.x:h.plan&&h.plan.reviveD&&!h.plan.reviveD.alive?h.plan.reviveD.x:h.plan&&h.plan.goTo&&h.plan.goTo.mine?h.plan.goTo.mine.x-DEFUSE_D:h.plan&&h.plan.goTo&&h.plan.goTo.ob?(()=>{const o=h.plan.goTo.ob;if(/search|disarm/.test(h.plan.intent))return this.searchSpot(o,h).x;const [a,b]=this.obSpan(o,o.lanes[0]);return h.x<(a+b)/2?a-6:b+6;})():h.plan&&h.plan.goTo&&h.plan.goTo.spot?h.plan.goTo.x:h.plan&&h.plan.goTo&&h.plan.goTo.isBanner?h.plan.goTo.x+((h.laneI||0)-1)*8:h.plan&&h.plan.goTo&&h.plan.goTo.alive?this.heroX(h.plan.goTo)+(h.plan.goTo.x<h.x?8:-8):this.home(h)+drift+(h.plan?(this._clear?Math.max(-6,h.plan.xoff):h.plan.xoff):0));tx=Math.max(8,Math.min(this.W-8,tx));   /* 0.12.58: with nothing near, nobody hangs far back (the march needs the party up front) */
      if(!this.exiting&&trait(h,'range')>.55&&!(h.plan&&(h.plan.intent==='retreat'||h.plan.reviveD||h.plan.goTo))){const foe=this.enemies.filter(e=>!e.dead&&!e.boss&&!e.fly&&e.gy!=null&&Math.abs(e.gy-(h.gy||190))<4&&e.x>h.x&&e.x-h.x<90).reduce((b,e)=>!b||e.x<b.x?e:b,null);if(foe)tx=Math.max(tx,Math.min(this.home(h)+28,foe.x-12));}   // push forward into the fight
      h._tx=tx;const x0=h.x;const C=h.base.char;const rm=C?((h.plan&&/retreat|charge|kite|cover|regroup|gather|revive|herb|guard|search|disarm|hunker|defuse/.test(h.plan.intent))||this.exiting?C.run:1):(h.plan?h.plan.runMul:1);h.running=C?rm>1:false;
      const d=tx-h.x,st=mv*(h.mvMul||1)*(h.upT>0?1.2:1)*(h.slowT>0?1-(h.slow||0):1)*dynMv(h)*(h.whirl?.5:1)*(this.exiting&&!C?2.6:1.6)*rm*(rm>1?.75:.85)*dt;/* 0.12.13 (Kyle): walking 15% slower, running 25% slower */const busy=(h.building&&h.walkTo==null)||h.repairing;   /* 0.12.162 (Kyle): the Engineer stands still while he builds, upgrades/modifies or repairs */
      if((!(h.pauseT>0)||this.exiting)&&!busy)h.x+=Math.abs(d)<=st?d:Math.sign(d)*st;h.moving=Math.abs(h.x-x0)>.02;h.moveT=h.moving?(h.moveT||0)+dt:0;});
    const f=this.front();if(!f)return;
    // blocking: walk unless something is close
    const near=this.enemies.filter(e=>!e.dead&&!e.fly).reduce((m,e)=>Math.min(m,e.x-(e.boss?e.w:0)-(e.ranged?40:0)),1e9);
    const blocked=(near<f.x+70||(this.boss&&!this.boss.dead))&&!(this.t-(this.lastHit||0)>3&&!(this.boss&&!this.boss.dead));
    /* 0.12.58 (Kyle): the screen only pushes forward once MORE than half of the standing party is past the middle of the screen.
       The party's resting spot is just past the middle, so walking up to it is what lets the screen move on. */
    {const H0=this.W*.33,H1=this.W*.58;this.homeX=this.homeX||H0;if(!this.exiting)this.homeX=H1;}
    const stand=al.filter(h=>!h.pet&&!h.perch),past=stand.filter(h=>h.x>this.W/2).length;   /* 0.12.75: whoever is up the lookout doesn't hold the march back */
    this._clear=!blocked;const anyDown=this.heroes.some(h=>!h.alive&&h.downed);   /* 0.12.58 (Kyle): the screen can't move on while anyone is down */
    const scroll=this.exiting?0:blocked||anyDown?0:past>stand.length/2?Math.max(18,Math.min(32,avgMv)):0;this.scroll=scroll;if(this.exiting){this.exitT+=dt;for(const h of al)h.walkT+=dt*(MOVE[h.key]||26)/26;}
    if(!this.bossSpawned)this.dist+=scroll*dt;
    // spawning
    const stageDone=this.dist>=this.st.len;
    const prog=Math.min(1,this.dist/this.st.len),ramp=.3+1.4*prog;   // light at the start, heavy near the end
    if(this.demo){if(!stageDone&&!this.exiting){this.budget+=this.st.rate*ramp*dt*(scroll?1.15:.25);   // title-screen demo keeps the old steady trickle
      const type=this.nextType||(this.nextType=this.pickType());const c=CFG.enemies[type].cost;
      if(this.budget>=c&&this.enemies.filter(e=>!e.dead).length<20){this.budget-=c;this.spawnEnemy(type);this.nextType=null;}}}
    else if(!stageDone&&!this.exiting){
      // 0.12.6 (Kyle): enemies come in CLUSTERS instead of a steady flow. 7 clusters per stage, spread along the stage with some
      //   randomness. Sizes grow from 2 at the start to 6-7 at the end (each a little random). A cluster walks in over ~1.5s, bunched.
      if(!this.clusters){const CL=this.st.n===1?CLUSTERS1:CLUSTERS;const N=CL.count;this.clusters=[];
        for(let i=0;i<N;i++){const t=i/(N-1);const size=i===0?CL.first:i===N-1?CL.last[0]+Math.floor(this.rng()*(CL.last[1]-CL.last[0]+1)):
            Math.max(2,Math.min(CL.cap,Math.round(CL.first+(CL.last[0]+.5-CL.first)*t+(this.rng()*2-1))));
          const at=this.st.len*Math.max(.02,Math.min(.9,.04+.84*t+(this.rng()*2-1)*.04));const sz=Math.max(1,Math.floor(size*(this.st.countMul||1)*((this.mods&&this.mods.foes)||1)));this.clusters.push({at,size:sz,left:sz,t:0});}
        {const n=this.st.n||1;let k=n===1?1:n<5?1:n<10?1+(this.rng()<.5?1:0):n<15?2:2+(this.rng()<.5?1:0);   /* 0.12.175 (Kyle): Screamers */
          if(this.demo)k=0;if(n===1&&N>0)this.clusters[N-1].scr=1;else for(let q=0;q<k;q++){const i=Math.floor(N/2)+Math.floor(this.rng()*Math.ceil(N/2));if(this.clusters[i])this.clusters[i].scr=(this.clusters[i].scr||0)+1;}}
        // strays: single zombies dropped in the quiet gaps between clusters (never right on top of one), some stages get none in a gap
        this.strays=[];const ats=this.clusters.map(q=>q.at);for(let i=0;i<STRAYS_PER_STAGE(this.st.n)*3&&this.strays.length<STRAYS_PER_STAGE(this.st.n);i++){
          const k=Math.floor(this.rng()*(ats.length-1));const a=ats[k],b=ats[k+1];if(b-a<this.st.len*.07)continue;const x=a+(b-a)*(.3+.4*this.rng());if(this.strays.some(s=>Math.abs(s-x)<this.st.len*.05))continue;this.strays.push(x);}
        this.strays.sort((p,q)=>p-q);}
      if(!this.demo&&this.nemQ&&this.nemQ.length&&this.dist>=this.st.len*.4)this.spawnNemesis(this.nemQ.shift());
      if(!this.demo&&!this.supplyDrop&&this.run&&upgT(this.run,'radio')>=2&&this.dist>=this.st.len*.5){this.supplyDrop=1;const gy=LANES[1]||this.G;for(const [k,dx] of [['food',0],['water',8],['parts',16]])this.loot.push({kind:k,x:this.W-14+dx,gy,amt:k==='parts'?2:1,t:0});this.text(this.W-40,gy-50,'📻 SUPPLY DROP','#a6ff2e',true);for(const h of this.alive())if(!h.pet&&Math.random()<.4)Comms.bubble(this,h,Comms.pick(['Radio says supplies incoming!','Care package!','Grab the drop!']));}   /* 0.12.246 Radio Shack II */
      while(this.strays&&this.strays.length&&this.dist>=this.strays[0]){this.strays.shift();if(this.enemies.filter(e=>!e.dead).length<24)this.spawnEnemy('zombie',{x:this.W+10+this.rng()*22,elite:'roll',stray:1});}
      const C0=this.clusters[0];
      if(C0&&this.dist>=C0.at){if(!C0.alerted){C0.alerted=1;const rt=!this.demo&&this.run?upgT(this.run,'radio'):0,first=!this.radioFirst;this.radioFirst=1;if(rt>=2||rt>=1&&first)for(const h of this.alive())if(!h.pet){if(!(h.alertT>0))h.acc+=10;h.alertT=5;}}   /* 0.12.105 Radio Shack II: early warning */C0.t-=dt;if(C0.t<=0&&this.enemies.filter(e=>!e.dead).length<28){C0.left--;C0.t=.12+this.rng()*.35;
          {const scr=C0.scr>0&&C0.left<=C0.scr;if(scr)C0.scr--;this.spawnEnemy(scr?'screamer':this.pickType(),{x:this.W+10+this.rng()*22+(scr?14+this.rng()*10:0),elite:'roll'});}   /* 0.12.231 (Kyle): Screamers come in at the back of a group (the last ones out, a little further behind) */if(C0.left<=0)this.clusters.shift();}}}
    if(!stageDone&&!this.demo){if(!this.wolfPlan){const k=WOLVES_PER_STAGE(this.st.n);this.wolfPlan=[];for(let i=0;i<k;i++)this.wolfPlan.push(this.st.len*(.12+.68*(i+.2+.4*this.rng())/k));}
      while(this.wolfPlan.length&&this.dist>=this.wolfPlan[0]){this.wolfPlan.shift();this.spawnEnemy('werewolf');}}
    else if(this.st.boss&&!this.bossSpawned&&!this.enemies.some(e=>!e.dead))this.spawnBoss();
    else if(!this.st.boss&&!this.enemies.some(e=>!e.dead)&&!this.demo&&!this.exiting){this.exiting=true;this.exitT=0;}
    if(this.demo&&stageDone){this.dist=0;}
    if(this.boss&&this.boss.dead&&!this.over&&!this.demo&&!this.exiting){this.exiting=true;this.exitT=0;}
    if(this.exiting&&!this.over){const al2=this.alive();if(!this.loot.length&&al2.every(h=>h.x>this.W+24)||this.exitT>12){this.over='clear';this.ev('clear');if(this.heroes.some(o=>o.key==='cheez')){const R0=this.run;const clean=!Object.values(this.stats||{}).some(v=>v.downs>0);R0.attendB=clean?Math.min(.06,(R0.attendB||0)+.02):0;}   /* 0.12.235 Perfect_Attendance: a clean stage = +2% team damage next stage, max +6% */return;}}
    // heroes
    this.stepObstacles(dt,scroll);this.stepMines(dt,scroll);this.stepRobot(dt,scroll);this.stepDark(dt,scroll);
    if(this.glides&&this.glides.length){for(const G of this.glides){G.u.x=Math.max(8,G.u.x+G.dir*G.v*dt);G.v=Math.max(0,G.v-G.v*8*dt-4*dt);}this.glides=this.glides.filter(G=>G.v>0&&!G.u.alive);}   /* 0.12.201 a downed friend shoved by Familia slides */
    for(const [i,h] of this.heroes.entries()){if(h.laneI==null){h.laneI=[2,1,3][i%3];h.gy=LANES[h.laneI];}}
    for(const h of al){
      {const hx=h.x;this._ignoreMine=h.defuse&&h.defuse.M;const want=this.freeLane(h.plan&&h.plan.lane!=null?h.plan.lane:h.laneI,h.laneI,hx-8,hx+(scroll?55:14));   // walk around obstacles
       if(want!==h.laneI&&Math.abs(h.gy-LANES[h.laneI])<1)h.laneI+=Math.sign(want-h.laneI);}
      if(!((h.building&&h.walkTo==null)||h.repairing)){const ty=LANES[h.laneI];h.gy+=Math.sign(ty-h.gy)*Math.min(Math.abs(ty-h.gy),LANE_SPD*1.4*dt);}
      if(h.leap){h.leap.age=(h.leap.age||0)+dt;if(h.leap.age>1.2){h.x=h.leap.x1;h.leap=null;h.leapH=0;}}
      if(h.rush){this.familiaStep(h,dt);continue;}   /* 0.12.201 Protect_the_Familia dash: nothing else happens until he gets there */   /* 0.12.50 (Kyle): a leap always lands, even if the fight around him ends mid-air */
      if(h.kbv>0&&h.building&&h.walkTo==null)h.kbv=0;if(h.kbv>0){h.x+=(h.kbDir||-1)*h.kbv*dt;h.kbv=Math.max(0,h.kbv-h.kbv*8*dt-4*dt);}   /* shoved by a heavy hit */
      regenEnergy(h,dt);if(h.critRegenT>0){h.critRegenT-=dt;h.en=Math.min(h.enMax||100,(h.en||0)+2*dt);h.hp=Math.min(h.max,h.hp+2*dt);}/* Herald: +1 energy and +1 HP every 0.5s */if(h.riseT>0){h.riseT-=dt;h.pauseT=Math.max(h.pauseT||0,.05);}h.walkT+=dt*(scroll?(MOVE[h.key]||26)/26:0);if(h.animT>0)h.animT-=dt;if(h.hitFlash>0)h.hitFlash-=dt;if(h.buffT>0)h.buffT-=dt;
      if(h.shellT>0){h.shellT-=dt;h.pauseT=Math.max(h.pauseT||0,.05);}
      if(h.shieldT>0){h.shieldT-=dt;if(h.shieldT<=0)h.shield=0;}if(h.staticT>0)h.staticT-=dt;
      if(h.capF&&h.capF.length)capHook('tick',this,h,dt);tbuffStep(h,dt);
      if(h.invulnT>0)h.invulnT-=dt;if(h.upT>0){h.upT-=dt;if(h.upT<=0){h.upT=0;h.invulnT=0;h.thinkT=0;}}if(h.throwT>0){h.throwAge=(h.throwAge||0)+dt;if(h.throwAge>2.5){h.throwT=0;h.throwAge=0;}}else h.throwAge=0;   /* 0.12.224 safety net: no throw pose can ever stick */
      if(h.hotT>0){h.hotT-=dt;h.hotTick=(h.hotTick||0)+dt;if(h.hotTick>=h.hotEvery){h.hotTick-=h.hotEvery;this.healHero(h,h.hotAmt,false,h.hotSrc);}}   // Rejuvenating Bloom
      if(h.slowT>0){h.slowT-=dt;if(h.slowT<=0)h.slow=0;}if(h.bleedT>0){h.bleedT-=dt;h.bleedTick+=dt;if(h.bleedTick>=1||h.bleedT<=0){const d=h.bleedDps*Math.min(1,h.bleedTick);h.bleedTick=0;h.hp-=d;this.text(h.x+6,this.G-58,Math.round(d),'#c0102a');if(h.hp<=0){this.heroDown(h);continue;}}}
      for(const it of h.items)if(it.cd>0)it.cd-=dt;
      if(this.enemies.some(e=>!e.dead&&e.x-h.x<36))this.procs(h,'near');
      if(h.roofBusy)continue;   /* 0.12.122: up a storefront roof for the crate: busy, no fighting */
      // signature ability
      const SG=ABILITIES_OFF?null:SIG[h.key];if(SG){h.sigT=(h.sigT==null?SG.cd*.5:h.sigT)-dt;if(h.sigT<=0){const ok=SG.fn(this,h,h.atk*h.pow);h.sigT=ok?SG.cd*(1-h.cdr):.6;if(ok){this.procs(h,'oncast');}}}
      // spells
      for(const s of h.spells){if(SPELL[s.arch].passive)continue;s.cdT-=dt;if(s.cdT<=0){const ok=this.cast(h,s);s.cdT=ok?SPELL[s.arch].cd*(1-h.cdr):.5;}}
      // basic attack
      const rate=dt*h.aspd*(h.buffT>0?1.3:1);const st=h.style;
      const findT=(kind)=>{const melee=kind==='melee';const ox=melee?f.x:h.x;const range=melee?st.reach*UNIT_SCALE+3:(st.range||170)*(h.perch?1+(h.perch.roofP?((CHAR.eng.abilities[0].tower.perchRange)||.3):(h.perchR||0)):1);
        const L=this.enemies.filter(e=>!e.dead&&e.inside==null&&(melee?(e.boss?e.x-e.w-h.x<=range&&e.x>h.x:Math.abs(e.x-h.x)<=range):(Math.abs(e.x-h.x)<=range))).sort((p,q)=>Math.abs(p.x-h.x)-Math.abs(q.x-h.x));
        const P=h.plan&&h.plan.tgt;if(P&&!P.dead&&L.includes(P)&&(!melee||P.boss||P.fly||P.gy==null||Math.abs(P.gy-h.gy)<2.5))return P;   // 0.12.2: the brain's pick, if it's in reach
        if(!melee)return L[0];
        // melee only reaches its own lane; if the nearest foe is in another lane, step one lane toward it
        const mine=L.find(e=>e.boss||e.fly||e.gy==null||Math.abs(e.gy-h.gy)<2.5);if(mine)return mine;
        if(!h.plan&&L[0]&&L[0].laneI!=null&&Math.abs(h.gy-LANES[h.laneI])<1)h.laneI+=Math.sign(L[0].laneI-h.laneI);
        return null;};
      if(st.atk==='gunner'||st.atk==='blade'){this.gunner(h,dt,f,findT);}
      else if(st.atk==='duo'){
        // partners fight independently: each has its own swing timer, target and animation
        if(h.animT2>0)h.animT2-=dt;
        h.atkT=Math.min(1,h.atkT+rate);h.atkT2=Math.min(1,(h.atkT2||0)+rate*.93);
        const ta=findT(st.a),tb=findT(st.b);
        const rd=faceToward(h,(ta||tb)?(ta||tb).x:h.x+10,dt);
        if(rd&&ta&&h.atkT>=1){h.atkT=0;h.animT=.32;this.basic(h,ta,st.a,.6*this.powerMul(h));}
        if(rd&&tb&&h.atkT2>=1){h.atkT2=0;h.animT2=.32;this.basic(h,tb,st.b,.6);}
        h.lunge=st.a==='melee'&&ta?f.x-h.x:0;h.lunge2=st.b==='melee'&&tb?f.x-h.x:0;
        if(st.companion)this.companion(h,dt,f);
      }else{
        h.atkT=Math.min(1.6,h.atkT+rate);const kind=st.atk==='melee'?'melee':'ranged';const tgt=findT(kind);
        const rd=faceToward(h,tgt?tgt.x:h.x+10,dt);
        h.lunge=kind==='melee'&&tgt?(h.face>0?f.x-h.x:Math.max(-10,tgt.x-h.x+8)):0;
        const plant=kind!=='melee'&&h.moving&&trait(h,'exec')>.5&&h.atkT<1.6;   // optimal shooters plant their feet before firing
        if(rd&&tgt&&h.atkT>=1&&!plant){h.atkT=0;h.anim=1;h.animT=.32;this.basic(h,tgt,undefined,this.powerMul(h));}
        if(h.atkT>1&&!h.moving)h.atkT=1;}
    }
    this.stepZones(dt);
    for(const l of this.loot){l.t+=dt;l.x-=scroll*dt;if(l.x<=f.x+14||this.over){l.got=1;if(l.kind==='gold'){const bb=upgT(this.run,'board');const a=Math.round(l.amt*(1+[0,.25,.5,.75][bb])*(1+ffT(this.run,'gold')));   /* 0.12.237 Fall Forward: +20/30/40% gold piles */this.stageGold+=a;this.text(l.x,this.G-30,'+'+a,'#ffd23f');}else if(l.kind==='food'||l.kind==='water'){if(l.kind==='food')this.stageFood=(this.stageFood||0)+1;else this.stageWater=(this.stageWater||0)+1;this.text(l.x,this.G-30,'+1 '+l.kind.toUpperCase(),l.kind==='food'?'#e8b060':'#7fd0ff');}else if(l.kind==='parts'){this.stageParts=(this.stageParts||0)+l.amt;this.text(l.x,this.G-30,'+'+l.amt+' PARTS','#c8d0d8');}else{this.stageItems.push(l.item);this.ev('itemdrop',{item:l.item});}}}
    this.loot=this.loot.filter(l=>!l.got);
    // minions
    for(const m of this.minions){m.life-=dt;m.atkT+=dt;if(m.animT>0)m.animT-=dt;if(m.hitFlash>0)m.hitFlash-=dt;const mi=this.minions.indexOf(m);
      // melee summons hang out ~3/4 across the screen and charge what's in front of them; ranged summons hold the middle and shoot
      const home=this.W*(m.ranged?.5:.7)+((mi%3)-1)*7;const src=m.owner.alive?{crit:m.owner.crit,scoreM:m.owner.scoreM,items:[]}:null;
      const foe=m.ranged?null:this.enemies.filter(e=>!e.dead&&!e.fly&&e.x>f.x+10).sort((p,q)=>Math.abs(p.x-home)-Math.abs(q.x-home))[0];
      const tx=foe&&Math.abs(foe.x-home)<this.W*.3?Math.max(f.x+10,foe.x-(foe.boss?foe.w:0)-14-mi*4):home;
      const md=tx-m.x,ms=MINION_SPEED*dt;m.x+=Math.abs(md)<=ms?md:Math.sign(md)*ms;m.moving=Math.abs(md)>1;
      if(m.ranged){const e=this.enemies.filter(e=>!e.dead&&e.x>m.x-20&&e.x-m.x<170).sort((p,q)=>p.x-q.x)[0];
        if(e&&m.atkT>=1.3){m.atkT=0;m.animT=.3;this.proj.push({kind:m.kind==='drone'?'plasma':'wisp',x:m.x+6,y:this.G-26,tx:e,dmg:m.atk*1.1,src,spd:PSPD[m.kind==='drone'?'plasma':'wisp'],pierce:0,opt:{},t:0,hit:new Set()});}}
      else{const e=this.enemies.filter(e=>!e.dead&&Math.abs(e.x-(e.boss?e.w:0)-m.x)<30)[0];
        if(e&&m.atkT>=1){m.atkT=0;m.animT=.3;this.fx.push({k:'slash',x:e.x-6,y:e.boss?e.y-50:e.fly?e.y:e.y-22,t:0});const d=this.hitEnemy(e,m.atk,src,{kb:.4});if(m.leech)this.healHero(this.weakest(),d*.2,true);}}
      if(m.hp<=0||m.life<=0){m.dead=true;this.fx.push({k:'poof',x:m.x,y:this.G-14,t:0});
        if(m.explode){this.fx.push({k:'ring',x:m.x,y:this.G-16,r:24,t:0,c:'#ff8a1f'});for(const e of this.enemies)if(!e.dead&&Math.abs(e.x-m.x)<30)this.hitEnemy(e,m.atk*2.2,null,{nocrit:1});}}}
    this.minions=this.minions.filter(m=>!m.dead);
    // enemies
    const alSeen=al.filter(o=>!(o.stealthT>0)&&!(o.perch&&o.perch.hp>0)),alE=alSeen.length?alSeen:al;   /* 0.12.67 stealth: zombies only see who isn't hidden */
    for(const e of this.enemies)if(e.fly&&!e.dead&&dt>0){e.vx=e._lx==null?0:(e.x-e._lx)/dt;e.vy=e._ly==null?0:(e.y-e._ly)/dt;e._lx=e.x;e._ly=e.y;}   /* 0.12.206: fliers' speed, for shooters to lead them */
    for(const e of this.enemies){if(e.dead)continue;const al=alE;if(e.target&&(e.target.stealthT>0||(e.target.perch&&e.target.perch.hp>0))&&alSeen.length&&!(e.tauntT>0)){e.target=null;e.plan=null;}
      if(!e.boss)regenEnergy(e,dt);e.walkT+=dt;if(e.hitFlash>0)e.hitFlash-=dt;if(e.animT>0)e.animT-=dt;if(e.shred>0)e.shred-=dt;

      if(e.fb){const F=e.fb;F.T-=dt;F.tick+=dt;while(F.tick>=.25&&!e.dead){F.tick-=.25;if(F.per!=null){F.acc=(F.acc||0)+F.per*F.mul;if(F.acc>=1){const d=Math.floor(F.acc);F.acc-=d;this.hitEnemy(e,d,F.src&&F.src.alive?F.src:null,{fire:1,quiet:1,sure:1});}}else this.hitEnemy(e,(this.rollDice([1,4])+(F.flat||0))*F.mul,F.src&&F.src.alive?F.src:null,{fire:1,quiet:1,sure:1});   /* 0.12.247: a spread-out burn piles up fractions so 2d4 really is 2d4 */}if(F.T<=0||e.dead)e.fb=null;}   /* 0.12.62 flamethrower burn: 1d4 every 0.25s for 2s */
      if(e.burnT>0){e.burnT-=dt;e.hp-=e.burn*dt*(e.E&&e.E.fireImmune?.25:1);   /* 0.12.236 Firemen take 25% from burns */if(e.hp<=0){this.kill(e,null);continue;}}
      if(e.poisonT>0){e.poisonT-=dt;e.poisonTick=(e.poisonTick||0)+dt;
        if(e.poisonTick>=POISON.tick){e.poisonTick-=POISON.tick;const d=e.max*POISON.pct*e.poison;e.hp-=d;this.text(e.x+4,e.y-38,Math.round(d),'#7dff6a');if(e.hp<=0){this.kill(e,null);continue;}}
        if(e.poisonT<=0){e.poison=0;e.poisonTick=0;}}
      if(e.bleedT>0&&e.E&&e.E.noBleed){e.bleedT=0;e.bleedDps=0;}   /* 0.12.183 Skeleton_Archer: no blood, no bleed */
      if(e.bleedT>0){e.bleedT-=dt;e.hp-=e.bleedDps*dt;if(e.hp<=0){this.kill(e,null);continue;}}   // nail bleed from Trip Bomb (ignores armor)
      if(e.E&&e.E.ccHalf){if(e.slowT>0)e.slowT-=dt;if(e.stun>0)e.stun-=dt;if(e.rootT>0)e.rootT-=dt;if(e.fearT>0)e.fearT-=dt;if(e.dazeT>0)e.dazeT-=dt;}   /* 0.12.201 (Kyle) Fireman: slows, stuns, roots, dazes run out twice as fast */
      if(e.E&&e.E.kbRes>=1)e.kbv=0;
      if(e.slowT>0){e.slowT-=dt;if(e.slowT<=0)e.slow=0;}
      if(e.kbv>0){e.x+=(e.kbDir||1)*e.kbv*dt;e.kbv=Math.max(0,e.kbv-e.kbv*8*dt-4*dt);}
      if(e.shoveT>0)this.shoveStep(e,dt);
      if(e.stun>0){e.stun-=dt;continue;}
      if(this.obst&&this.roofEnemy(e,dt,scroll))continue;   /* 0.12.122: storefront roof routes */
      if(this.blds&&!e.fly&&!e.boss)this.bldBlock(e,dt);   /* 0.12.75: barriers stop them; they hit buildings in their way */
      if(e.distractT>0){e.distractT-=dt;e.distractX-=scroll*dt;e.x-=scroll*dt;const dx=e.distractX-e.x;if(Math.abs(dx)>2)e.x+=Math.sign(dx)*Math.min(Math.abs(dx),e.E.spd*(1-(e.slow||0))*dt);e.face=dx>0?1:-1;e.walkT=(e.walkT||0)+dt;continue;}   /* 0.12.68 Bottle_Distraction: they go check the noise */
      const sp=(1-e.slow);
      if(e.E&&e.E.scream&&this.screamAI(e,dt,scroll,al))continue;
      if(e.type==='bat'){this.batAI(e,dt,scroll,al);continue;}
      if(e.boss){this.bossAI(e,dt,sp,f);continue;}
      const tank=this.minions.find(m=>m.taunt)||(this.minions.length&&this.rng()<.5?this.minions[0]:null);
      const blockX=f.x+18;
      if(e.fly){
        if(!e.target||(e.target.alive===false)||e.target.dead){e.target=this.minions.length&&this.rng()<.3?this.minions[Math.floor(this.rng()*this.minions.length)]:al[Math.floor(this.rng()*al.length)];}
        const tx=e.ranged?Math.max(e.E.stop*this.W/CFG.W,f.x+90):(e.target.owner?e.target.x:this.heroX(e.target))+16,ty=this.G-40+Math.sin(this.t*3+e.phase)*8-(e.ranged?20:0);
        e.x-=scroll*dt;if(e.x>tx)e.x-=Math.min(e.x-tx,e.E.spd*sp*dt);e.y+=(ty-e.y)*Math.min(1,dt*2);
        e.atkT+=dt;if(e.atkT>=e.E.atk&&Math.abs(e.x-tx)<6){e.atkT=0;e.anim=1;e.animT=.3;
          if(e.target.owner){if(!e.ranged)this.hurtMinion(e.target,e.dmg,e);}else if(e.ranged)this.enemyShot(e,e.target);else this.hurtHero(e.target,e.dmg,e);}
      }else if(e.ranged){
        const stop=Math.min(this.W-30,Math.max(e.E.stop*this.W/CFG.W,f.x+80));e.x-=scroll*dt;if(e.x>stop)e.x-=e.E.spd*sp*dt;e.x=Math.max(e.x,blockX);   /* 0.12.183: always stops on screen so it can shoot */
        e.atkT+=dt;if(e.atkT>=e.E.atk&&e.x<this.W-10){e.atkT=0;e.anim=1;e.animT=e.E.animAtk||.3;const t=al[Math.floor(this.rng()*al.length)];if(t)e.face=this.heroX(t)>e.x?1:-1;
          if(e.E.shotAt)setTimeoutSafe(this,e.E.shotAt,()=>{if(!e.dead&&!(e.stun>0)&&t&&t.alive){this.enemyShot(e,t);this.ev('bow',{});}});else this.enemyShot(e,t);}   /* 0.12.183: archers draw, then loose */
      }else{
        const mx=al.reduce((s,h)=>s+this.heroX(h),0)/Math.max(1,al.length);const back=al.filter(h=>this.heroX(h)<=mx);   // 'back line' = whoever is standing further back right now
        if(e.E.flank&&back.length&&!e.noFlank){
          // fast monsters try to slip past the front line and go for the ranged heroes
          if(!e.target||!e.target.alive||this.isMeleeHero(e.target))e.target=back[Math.floor(this.rng()*back.length)];
          const tx=this.heroX(e.target)+12;e.x-=scroll*dt;if(e.x>tx)e.x=Math.max(tx,e.x-e.E.spd*1.15*sp*dt);else if(e.x<tx-2)e.x+=e.E.spd*.5*sp*dt;
          if(Math.abs(e.x-tx)<4){e.atkT+=dt;if(e.atkT>=e.E.atk){e.atkT=0;e.anim=1;e.animT=e.E.animAtk||.3;this.hurtHero(e.target,e.dmg,e);if(e.E.leech)e.hp=Math.min(e.max,e.hp+e.dmg*e.E.leech);}}
        }else if(e.E.reach!=null&&!e.fly){
          // ---- lane walker (Kyle's rules): shambles at whoever is closest in its own lane; until it is 50px from the first hero it may
          // randomly drift into another lane; it sticks with the hero in front of it, but on rare occasions switches to someone closer
          if(e.laneI==null){e.laneI=Math.floor(this.rng()*LANES.length);e.gy=LANES[e.laneI];}
          const Rch=ENEMY_BODY+e.E.reach;const firstX=Math.max(...al.map(h=>this.heroX(h)));const far=e.x>firstX+50;
          const inLane=al.filter(h=>h.laneI===e.laneI);
          // 0.12.2 behavior AI: the monster thinks on its own clock (who to chase, which lane, when to pause or back off)
          Brain.tick(e,dt);if(Brain.due(this,e,dt)){const others=this.enemies.filter(o=>o!==e&&!o.dead);const pk=Brain.pickTarget(this,e,al,others,false);
            if(pk&&pk.tgt){e.target=pk.tgt;e.plan={tgt:pk.tgt,why:pk.why,lane:Brain.pickLane(this,e,pk.tgt,false)};}
            const aggr=trait(e,'aggr');if(aggr<.6&&e.hp/e.max<.18+.42*(1-aggr)&&!(e.retreatT>0))e.retreatT=1.5+2*(1-aggr);
            if(far&&trait(e,'pace')<.4&&Math.random()<.2*(1-trait(e,'pace')))e.pauseT=.4+.4*(1-trait(e,'pace'));}
          if(e.retreatT>0)e.retreatT-=dt;
          if(!e.plan&&e.E.backline){const mx2=al.reduce((s,h)=>s+this.heroX(h),0)/Math.max(1,al.length);const rear=al.filter(h=>this.heroX(h)<=mx2);const back=rear.length?rear.reduce((b,h)=>!b||this.heroX(h)<this.heroX(b)?h:b,null):al.reduce((b,h)=>!b||Math.abs(this.heroX(h)-e.x)<Math.abs(this.heroX(b)-e.x)?h:b,null);e.target=back;e.think=99;}
          const nearestIn=L=>L.reduce((b,h)=>!b||Math.abs(this.heroX(h)-e.x)<Math.abs(this.heroX(b)-e.x)?h:b,null);
          if(e.plan&&(!e.target||!e.target.alive)){e.target=nearestIn(inLane)||nearestIn(al);e.thinkT=0;}
          if(!e.plan&&!e.E.backline&&(!e.target||!e.target.alive))e.target=nearestIn(inLane)||nearestIn(al);
          if(e.tauntT>0){e.tauntT-=dt;if(e.tauntBy&&e.tauntBy.alive){e.target=e.tauntBy;e.plan=null;}}   /* Trash_Talk: they only want JP */
          else if(!e.plan&&!e.E.backline&&e.target.laneI!==e.laneI&&inLane.length&&Math.abs(e.gy-LANES[e.laneI])<1)e.target=nearestIn(inLane);
          e.think=(e.think==null?this.rng():e.think)-dt;
          if(!e.plan&&e.think<=0){e.think=1;   // once a second of walking: 10% chance to drift a lane (only while still 50px+ out)
            if(far&&this.rng()<.1){const alt=[e.laneI-1,e.laneI+1].filter(l=>l>=0&&l<LANES.length);e.laneI=alt[Math.floor(this.rng()*alt.length)];const t2=nearestIn(al.filter(h=>h.laneI===e.laneI));if(t2)e.target=t2;}   // random drift
            else if(this.rng()<.02){const c=nearestIn(al);if(c&&c!==e.target)e.target=c;}}   // rare: go after someone closer
          /* 0.12.58 (Kyle): every 1.5s a zombie has a 7% chance to wander into a neighbouring lane, wherever it is */
          e.lsw=(e.lsw==null?this.rng()*1.5:e.lsw)-dt;if(e.lsw<=0){e.lsw=1.5;if(!e.leapA&&!e.stun&&this.rng()<.07){const hl=al.map(h=>h.laneI),dist=l=>Math.min(...hl.map(x=>Math.abs(x-l))),alt=[e.laneI-1,e.laneI+1].filter(l=>l>=0&&l<LANES.length&&(dist(l)<=dist(e.laneI)||this.rng()<.15));if(alt.length){e.laneI=alt[Math.floor(this.rng()*alt.length)];e.laneHold=this.t+(dist(e.laneI)?1:2.5);}   /* 0.12.202 (Kyle): wandering lanes mostly toward where the heroes are, not away */const t2=nearestIn(al.filter(h=>h.laneI===e.laneI));if(t2&&Math.abs(this.heroX(t2)-e.x)<60)e.target=t2;}}
          const T=e.target;
          this._ignoreMine=null;const wantL0=e.plan&&e.plan.lane!=null?e.plan.lane:T.laneI;const wantL=this.freeLane(wantL0,e.laneI,e.x-45,e.x+6);const dodgeOb=wantL!==wantL0||!!this.laneBlocked(e.laneI,e.x-45,e.x+6);
          if(!al.some(h=>h.laneI===e.laneI)&&!e.plan){e.laneHold=0;}   /* 0.12.202 (Kyle): nobody in my lane? don't loiter there, head toward them */
          if(!(e.laneHold>this.t&&!dodgeOb)&&(dodgeOb||e.plan||e.E.backline||!far||!inLane.length||T.laneI!==e.laneI)){if(Math.abs(e.gy-LANES[e.laneI])<1&&wantL!==e.laneI)e.laneI+=Math.sign(wantL-e.laneI);}   // head for the chosen lane
          const ty=LANES[e.laneI];e.gy+=Math.sign(ty-e.gy)*Math.min(Math.abs(ty-e.gy),LANE_SPD*dt);e.y=e.gy;
          // queue politely behind a zombie already hitting this hero in this lane
          const front=this.enemies.filter(o=>o!==e&&!o.dead&&o.laneI===e.laneI&&o.x<e.x&&Math.abs(o.gy-e.gy)<3).reduce((b,o)=>!b||o.x>b.x?o:b,null);
          if(e.stackOff==null)e.stackOff=this.rng()*5;
          const stacks=e.E.stack!==false;   // every unit can stack now (a future 'block' ability can turn this off)
          const hx=this.heroX(T);const side=e.x>=hx?1:-1;const bodyT=u=>u&&u.key==='robot'?7:0;   /* 0.12.58: the Warhound is a big machine: zombies can reach him from further out */   // 0.11: which side of its hero it stands on (it can end up behind the heroes)
          let stopX=hx+side*(ENEMY_BODY+bodyT(T)+e.E.reach*.6+(stacks?e.stackOff:0)+(e.retreatT>0?42:0));if(!stacks&&front&&side>0&&front.x>=stopX-1)stopX=Math.max(stopX,front.x+11);
          const sameLane=Math.abs(e.gy-T.gy)<2;const ready=faceToward(e,hx,dt);let V=T;let inRange=ready&&sameLane&&Math.abs(e.x-hx)<=Rch+bodyT(T)+.5;
          /* 0.12.58 (Kyle): IF nobody in my lane is in reach BUT a hero one lane up or down is right next to me THEN swing at them instead */
          if(!inRange&&!e.leapA){const adj=al.filter(h=>Math.abs((h.gy||this.G)-e.gy)>=2&&Math.abs((h.gy||this.G)-e.gy)<=9.5&&Math.abs(this.heroX(h)-e.x)<=Rch+bodyT(h)-1).sort((p,q)=>Math.abs(this.heroX(p)-e.x)-Math.abs(this.heroX(q)-e.x))[0];if(adj&&faceToward(e,this.heroX(adj),dt)){V=adj;inRange=true;}}   // must face the hero and touch it
          // ---- leap attack: from about 20px outside its reach, in the target's lane, it bounds in and lands on the hero
          const LP=e.E.leap;e.leapCd=(e.leapCd||0)-dt;
          if(e.leapA){const A2=e.leapA;A2.t+=dt;const u=Math.min(1,A2.t/A2.dur);const px=e.x;e.x=A2.x0+(A2.x1-A2.x0)*u-scroll*dt;e.moving=true;
            const lo=Math.min(px,e.x)-ENEMY_BODY,hi=Math.max(px,e.x)+ENEMY_BODY;A2.hit=A2.hit||new Set();
            for(const o of this.alive()){if(A2.hit.has(o)||Math.abs((o.gy||this.G)-e.gy)>6)continue;const ox=this.heroX(o);if(ox<lo||ox>hi)continue;A2.hit.add(o);const took=this.hurtHero(o,LP.dmg*e.dmgMul,e);if(took&&o.alive&&LP.bleed)this.bleed(o,LP.bleed[0]*e.dmgMul,LP.bleed[1]);this.shake=Math.max(this.shake,.2);this.fx.push({k:'slash',x:ox,y:e.gy-20,t:0});}
            if(u>=1){e.leapA=null;e.face=-e.face||1;e.atkT=e.E.atk*.4;}
            continue;}
          if(LP&&e.leapCd<=0&&sameLane&&ready&&!e.stun){const gap=Math.abs(e.x-hx)-Rch;if(gap>LP.gap*.6&&gap<=LP.gap+4){e.leapA={t:0,dur:LP.dur,x0:e.x,x1:e.x-side*(gap+Rch)*1.25};e.leapCd=LP.cd;e.animT=0;continue;}}
          const x0=e.x;e.x-=scroll*dt;if(!(e.pauseT>0)){if(side>0&&e.x>stopX)e.x=Math.max(stopX,e.x-e.E.spd*sp*dt);else if(side<0&&e.x<stopX)e.x=Math.min(stopX,e.x+e.E.spd*sp*dt);
            else if(e.retreatT>0)e.x+=Math.sign(stopX-e.x)*Math.min(Math.abs(stopX-e.x),e.E.spd*.6*sp*dt);}   // backing off
          e.moving=Math.abs(e.x-x0)>.05||Math.abs(e.gy-LANES[e.laneI])>.5;
          if(!inRange)e.atkT=Math.min(e.E.atk,e.atkT+dt);
          else{e.atkT+=dt;if(e.atkT>=e.E.atk){e.atkT=0;e.anim=1;e.animT=e.E.animAtk||.3;
            const blow=()=>{if(e.dead||e.stun>0||!V.alive||Math.abs(e.gy-(V.gy||this.G))>(V===T?3:10)||Math.abs(e.x-this.heroX(V))>Rch+bodyT(V)+2)return;/* no swinging at thin air */const d=e.E.dmgDie?Math.max(1,Math.floor((1+Math.floor(this.rng()*e.E.dmgDie))*e.dmgMul)):e.dmg;const took=this.hurtHero(V,d,e);
              const B=e.E.bleed;if(B&&took&&V.alive&&this.rng()<(e.nemHas&&e.nemHas('blood')?1:B.chance))this.bleed(V,B.dmg*e.dmgMul,B.dur);
              if(took&&e.nem)this.nemOnHit(e,V,d);
              if(e.E.cleave){const dir=this.heroX(V)>=e.x?1:-1;this.fx.push({k:'fswipe',x:e.x,gy:e.gy!=null?e.gy:this.G,dir,r:Rch+6,t:0,life:.34,raw:1});this.shake=Math.max(this.shake||0,.08);
                for(const o of this.alive()){if(o===V||o.pet)continue;const dx=(this.heroX(o)-e.x)*dir;if(dx<-4||dx>Rch+bodyT(o)+2||Math.abs(e.gy-(o.gy||this.G))>10)continue;
                  const d2=Math.max(1,Math.floor((1+Math.floor(this.rng()*e.E.dmgDie))*e.dmgMul));const t2=this.hurtHero(o,d2,e);if(B&&t2&&o.alive&&this.rng()<B.chance)this.bleed(o,B.dmg*e.dmgMul,B.dur);}}};   /* 0.12.201 (Kyle) Fireman cleave: the swing hits every hero in reach in front of him */
            if(e.E.hitAt)setTimeoutSafe(this,e.E.hitAt,blow);else blow();}}
        }else{
        const wall=this.minions.filter(m=>m.x<e.x+4&&m.x>f.x+10).reduce((b,m)=>!b||m.x>b.x?m:b,null);const bx=wall&&wall.x+12>blockX?wall.x+12:blockX;
        // reach: can hit from (body width + reach) away; it keeps shuffling in a little closer so small knockbacks don't push it out of range
        const R=e.E.reach!=null?ENEMY_BODY+e.E.reach:null;const useR=R!=null&&!(wall&&wall.x+12>blockX);
        const bx2=useR?f.x+ENEMY_BODY+e.E.reach*.6:bx;const inRange=useR?e.x<=f.x+R+.5:e.x<=bx+2;
        e.x-=scroll*dt;if(e.x>bx2)e.x=Math.max(bx2,e.x-e.E.spd*sp*dt);
        if(useR&&!inRange)e.atkT=Math.min(e.E.atk,e.atkT+dt);   // keeps its swing ready while stepping back in
        if(inRange){e.atkT+=dt;if(e.atkT>=e.E.atk){e.atkT=0;e.anim=1;e.animT=e.E.animAtk||.3;
          const heroClose=e.x-f.x<30;
          const blow=()=>{if(e.dead||e.stun>0)return;const F=this.front();if(wall&&!wall.dead&&(!heroClose||bx>blockX))this.hurtMinion(wall,e.dmg,e);else if(tank&&tank.taunt&&!tank.dead)this.hurtMinion(tank,e.dmg,e);else if(F){const d=e.E.dmgDie?Math.max(1,Math.floor((1+Math.floor(this.rng()*e.E.dmgDie))*e.dmgMul)):e.dmg;const took=this.hurtHero(F,d,e);if(e.E.leech)e.hp=Math.min(e.max,e.hp+d*e.E.leech);
            const B=e.E.bleed;if(B&&took&&F.alive&&this.rng()<B.chance)this.bleed(F,B.dmg*e.dmgMul,B.dur);}};
          if(e.E.hitAt)setTimeoutSafe(this,e.E.hitAt,blow);else blow();}}
        }
      }
    }
    this.enemies=this.enemies.filter(e=>!e.dead||e.boss);
    /* 0.12.87 (Kyle): removed for now: enemies grew fiercer when a stage dragged past 3 minutes */   // stage dragging on: monsters grow fierce
    // ---- Campfire: grows, burns (cozy aura), breaks after 5 hits on Flannel_Man / his companion, then dies out
    if(this.camp){const F=this.camp;F.t+=dt;F.x-=scroll*dt;
      if(F.state==='start'&&F.t>=.9){F.state='burn';}
      if(F.state==='burn'){for(const o of this.alive())if(Math.abs(this.heroX(o)-F.x)<=F.A.radius)giveCozy(o);}
      if(F.state==='dying'){F.dT=(F.dT||0)+dt;if(F.dT>=1.2)F.state='dead';}
      if(F.state==='dead'){F.deadT=(F.deadT||0)+dt;if(F.deadT>5)this.camp=null;}
      if(this.camp&&F.x<-30)this.camp=null;}
    // ---- Thorn Waves: thorns burst one after another along the lane; each hits what's on top of it (damage + bleed)
    if(this.thornWaves&&this.thornWaves.length){for(const W of this.thornWaves){W.t+=dt;W.x0-=scroll*dt;const A=W.A,N=Math.floor(A.dist/A.step);
        while(W.n<N&&W.t>=A.dur*W.n/N){const x=W.x0+W.n*A.step;W.n++;this.fx.push({k:'thorn',x:x+(this.rng()*4-2),gy:W.gy+(this.rng()*2-1),v:Math.floor(this.rng()*4),t:0,life:1,raw:1});
          this.ffArea(W.src,x,W.gy,A.step*.75,A.depth,(this.rollDice(A.dice)+W.flat)*W.mul,W);
          for(const e of this.enemies){if(e.dead||e.fly||W.hit.has(e))continue;if(Math.abs(e.x-x)<=A.step*.75+(e.boss?e.w:0)&&(e.boss||Math.abs((e.gy!=null?e.gy:this.G)-W.gy)<=A.depth)){W.hit.add(e);
            this.hitEnemy(e,(this.rollDice(A.dice)+W.flat)*W.mul,W.src&&W.src.alive?W.src:null,{});if(!e.dead){e.bleedT=A.bleed.dur;e.bleedDps=A.bleed.dmg/A.bleed.dur;if(A.poisonCh&&this.rng()<A.poisonCh)this.addPoison(e,1);}}}}
        if(W.n>=N)W.done=1;}
      this.thornWaves=this.thornWaves.filter(W=>!W.done);}
    // ---- Cyclones: wander sporadically, pull nearby enemies in, and grind down whatever is inside them
    if(this.cyclones&&this.cyclones.length){for(const T of this.cyclones){T.t+=dt;const A=T.A;T.x-=scroll*dt;
        T.wT=(T.wT||0)-dt;if(T.wT<=0){const o=T.src&&T.src.alive?T.src.x:T.x0;T.tx=Math.max(o+(A.near||30),Math.min(Math.min(this.W-14,o+A.dist),T.x+(this.rng()*2-1)*(A.wander||70)));
          T.tgy=Math.max(LANES[0],Math.min(LANES[LANES.length-1],T.gy+(this.rng()*2-1)*7));T.wT=.4+this.rng()*.6;}   // a new random heading every 0.4-1s
        const dx=T.tx-T.x;T.x+=Math.sign(dx)*Math.min(Math.abs(dx),A.spd*dt*(.6+this.rng()*.8));T.gy+=Math.sign(T.tgy-T.gy)*Math.min(Math.abs(T.tgy-T.gy),10*dt);
        T.tick=(T.tick||0)+dt;const ticking=T.tick>=A.every;if(ticking)T.tick-=A.every;
        if(T.t<A.dur)for(const e of this.enemies){if(e.dead||e.fly)continue;const ex=e.x-T.x,ez=(e.gy!=null?e.gy:this.G)-T.gy,d=Math.abs(ex);
          if(!e.boss&&d<=A.pullR&&Math.abs(ez)<=A.depth*2){const k=1-d/A.pullR;e.x-=Math.sign(ex)*A.pull*k*dt*(1-((e.E&&e.E.kbRes)||0));if(e.gy!=null)e.gy-=Math.sign(ez)*Math.min(Math.abs(ez),6*k*dt);}   // slight pull toward the funnel
          if(ticking&&d<=A.inR+(e.boss?e.w:0)&&(e.boss||Math.abs(ez)<=A.depth))this.hitEnemy(e,(this.rollDice(A.dice)+(T.src.flatRanged||0))*T.mul,T.src&&T.src.alive?T.src:null,{nocrit:1});}
        if(ticking&&T.t<A.dur)this.ffArea(T.src,T.x,T.gy,A.inR,A.depth,(this.rollDice(A.dice)+(T.src.flatRanged||0))*T.mul);
        if(T.t>=A.dur+.35)T.done=1;}
      this.cyclones=this.cyclones.filter(T=>!T.done);}
    // ---- Arrow_Rain arrows in the air: drop, then hit whatever they land on and stick in the ground
    if(this.rain&&this.rain.length){for(const R of this.rain){R.t+=dt;R.x-=scroll*dt;if(R.t>=R.T&&!R.landed){R.landed=1;
        for(const e of this.enemies){if(e.dead||e.fly)continue;if(Math.abs(e.x-R.x)<=R.A.hitR+(e.boss?e.w:0)&&(e.boss||Math.abs((e.gy!=null?e.gy:this.G)-R.gy)<=4))this.hitEnemy(e,R.dmg,R.src&&R.src.alive?R.src:null,{});}
        this.ffArea(R.src,R.x,R.gy,R.A.hitR,4,R.dmg);this.fx.push({k:'stuck',x:R.x,gy:R.gy,t:0,life:2,raw:1});}}
      this.rain=this.rain.filter(R=>!R.landed);}
    // ---- traps (Trip Bomb): arm, wait for a ground enemy to walk into the wire, then blow
    /* 0.12.58 Log_Roll: the log rolls down its lane, hitting each zombie once (knockback + trip); in Hardcore it bowls allies over too */
    if(this.logs&&this.logs.length){for(const L of this.logs){L.t+=dt;L.x+=(L.A.spd-scroll)*dt;
        for(const e of this.enemies){if(e.dead||e.fly||L.hit.has(e))continue;if(Math.abs(e.x-L.x)<=6+(e.boss?e.w:0)&&(e.boss||Math.abs((e.gy!=null?e.gy:this.G)-L.gy)<=L.A.depth)){L.hit.add(e);const d=this.hitEnemy(e,(this.rollDice(L.A.dice)+L.flat)*L.mul,L.h,{kb:.8});
          if(d&&!e.dead){e.stun=Math.max(e.stun||0,L.A.trip*(e.boss?.3:1));const res=e.boss?.9:((e.E&&e.E.kbRes)||0);e.kbv=Math.max(e.kbv||0,L.A.kb/100*40*8*(1-res));e.kbDir=1;}}}
        if(this.hardcore)for(const o of this.alive()){if(o===L.h||L.hit.has(o)||o.pet)continue;if(Math.abs(this.heroX(o)-L.x)<=5&&Math.abs((o.gy||this.G)-L.gy)<=L.A.depth){L.hit.add(o);this.hurtHero(o,this.rollDice(L.A.dice)*.5,null);this.st8(L.h).ff=(this.st8(L.h).ff||0)+1;}}
        L.done=L.x-L.x0>=L.A.dist+L.t*scroll||L.x>this.W+20;}
      this.logs=this.logs.filter(L=>!L.done);}
    if(this.traps&&this.traps.length){for(const T of this.traps){T.t+=dt;T.x-=scroll*dt;const A=T.A;
        if(T.fly){const F=T.fly;F.t+=dt;F.x0-=scroll*dt;F.x1-=scroll*dt;const k=Math.min(1,F.t/F.T);T.x=F.x0+(F.x1-F.x0)*k;T.air=Math.sin(Math.PI*k)*F.h;T.spin=(T.spin||0)+dt*14;
          if(k>=1){T.fly=null;T.air=0;if(T.impact){this.tripBoom(T);continue;}T.t=0;this.fx.push({k:'ring',x:T.x,y:T.gy-1,t:0,r:5,c:'#b0a080'});}continue;}   /* overhand: blows on impact; underhand: lands and rolls */
        const near=()=>bombTrig(this,T.x,T.gy,A.trig);
        if(T.rollLeft>0){const Lb=A.lob,v=Lb.rollSpd*Math.max(.3,T.rollLeft/T.roll0);const s=Math.min(T.rollLeft,v*dt);T.x+=s;T.rollLeft-=s;T.spin=(T.spin||0)+s*.6;
          if(T.rollLeft<=.05){T.rollLeft=0;T.settleT=0;}}
        if(T.how==='toss'&&!T.live){if(near()){T.early=1;if(T.owner&&T.owner.tbT>0)T.owner.tbT=Math.max(0,T.owner.tbT-A.lob.refund);this.tripBoom(T);continue;}   /* tripped before it truly activated: 2d4+2, 2s back on the cooldown */
          if(!(T.rollLeft>0)){T.settleT=(T.settleT||0)+dt;if(T.settleT>=A.lob.settle){T.live=1;T.dice=A.lob.live[0];T.flat=A.lob.live[1];this.fx.push({k:'ring',x:T.x,y:T.gy-3,t:0,r:6,c:'#ff4030'});}}continue;}   /* truly activated: 2d4+6 */if(T.x<-6&&!T.done){T.done=1;if(T.owner&&T.owner.tbT>0)T.owner.tbT*=.5;continue;}   /* 0.12.59 (Kyle): left behind off screen: cooldown halved */
        if(T.t>A.life){T.done=1;continue;}
        if(near())this.tripBoom(T);}
      this.traps=this.traps.filter(T=>!T.done);}
    // projectiles
    for(const p of this.proj){p.t+=dt;
      if(p.aimed){
        p.x+=(p.dir||1)*p.spd*dt;const u=Math.min(1.6,Math.abs(p.x-p.x0)/p.dist);const h0=p.h0==null?28:p.h0;
        p.gy=p.gy0+(p.tgy-p.gy0)*u;p.h=h0+(p.aimH-h0)*u+(p.arc||0)*4*u*(1-u);p.y=p.gy-p.h*UNIT_SCALE;   /* lobbed things (kunai, darts) rise then drop onto the target. 0.12.38: this p.y update had been swallowed by a // comment, so shots were DRAWN at their launch height while they actually flew to their aim point */
        if(p.h<=0||p.x>this.W+20||p.x<-20||p.t>4){p.dead=true;if(p.h<=0)this.fx.push({k:'spark',x:p.x,y:p.gy,t:0,c:'#8a6a4a'});continue;}
        {const ob=(this.obst||[]).find(o=>this.obHitsShot(o,p));   /* 0.12.38: each obstacle stops shots by its own traced shape */
         if(ob){p.dead=true;this.fx.push({k:'spark',x:p.x,y:p.gy-p.h*UNIT_SCALE,t:0,c:'#b0a090'});
           if(/^car_/.test(ob.k)&&ob.alarmed==null&&!this.demo){ob.alarmed=this.rng()<.25;if(ob.alarmed)this.carAlarm(ob);}   /* a shot into a wreck: 25% to set its alarm off (once per car) */
           continue;}}
        {const B=(this.barrels||[]).find(B=>!B.gone&&Math.abs(p.x-B.x)<4&&Math.abs(p.gy-B.gy)<4&&p.h>=0&&p.h<14);if(B){p.dead=true;this.fx.push({k:'spark',x:p.x,y:p.gy-p.h*UNIT_SCALE,t:0,c:'#ffb070'});this.hitBarrel(B,p.dmg||4,p.dir||1);continue;}}   /* 0.12.216 a shot into an oil barrel */
        if(p.foes==='heroes'){   // an enemy's aimed shot: any hero body it passes through takes it
          for(const o of this.alive()){if(p.hit.has(o))continue;const hb=hbOf(o);
            if(Math.abs((o.gy||this.G)-p.gy)<=depthHalf(hb)&&Math.abs(p.x-this.heroX(o))<=hb.w*UNIT_SCALE/2&&p.h>=0&&p.h<=hb.h){p.hit.add(o);this.hurtHero(o,p.dmg*(isHead(o,p.h)?HEADSHOT.mul:1),p.src);
              this.fx.push({k:'spark',x:p.x,y:p.y,t:0,c:PCOL[p.kind]||'#fff'});if(p.pierce>0)p.pierce--;else{p.dead=true;break;}}}
          continue;}
        if(this.hardcore&&p.src&&p.src.key&&Math.abs(p.x-p.x0)>14){let ffHit=false;for(const o of this.alive()){if(o===p.src||p.hit.has(o))continue;const hb=hbOf(o);
            if(Math.abs((o.gy||this.G)-p.gy)<=depthHalf(hb)&&Math.abs(p.x-this.heroX(o))<=hb.w*UNIT_SCALE/2&&p.h>=0&&p.h<=hb.h){p.hit.add(o);this.hurtHero(o,p.dmg,null);this.fx.push({k:'spark',x:p.x,y:p.y,t:0,c:'#ff8080'});
              this.st8(p.src).ff=(this.st8(p.src).ff||0)+1;if(Math.random()<.5)Comms.bubble(this,o,Comms.pick(['Watch it!','Friendly fire!','I\'m on YOUR side!','Ow! Hey!']),true);if(p.pierce>0)p.pierce--;else{p.dead=true;ffHit=true;break;}}}
          if(ffHit)continue;}   /* 0.12.52 Hardcore: shots hit whoever is in the way, allies included */
        for(const e of this.enemies){if(e.dead||p.hit.has(e))continue;
          let ok;
          if(e.boss)ok=Math.abs(p.x-(e.x-e.w*.4))<e.w*.6&&p.h<220;
          else if(e.fly){const hb=HITBOX[e.type]||{w:16,h:16};const fh=(this.G-e.y)/UNIT_SCALE;ok=Math.abs(p.x-e.x)<=hb.w*UNIT_SCALE/2&&Math.abs(p.h-fh)<=hb.h/2;}   // fliers: any lane, height window around the body
          else{const hb=HITBOX[e.type]||{w:16,h:44};const hbT=(e.type==='werewolf'&&aimPose(e)===AIM_BOXES.werewolf.tall)?{w:hb.w,h:66}:hb;const lift=e.leapA?Math.sin(Math.PI*Math.min(1,e.leapA.t/e.leapA.dur))*28:0;const sc=(e.E.scale||1)*(e.elite?1.1:1);
            ok=Math.abs((e.gy!=null?e.gy:this.G)-p.gy)<=depthHalf(hb)*sc&&Math.abs(p.x-e.x)<=hb.w*sc*UNIT_SCALE/2&&p.h>=lift&&p.h<=lift+hbT.h*sc;if(ok)p.headNow=isHead(e,p.h-lift);}
          if(!ok)continue;
          p.hit.add(e);const big=BIGP[p.kind]||0;p.opt.onHit?p.opt.onHit(e,p.dmg,0):this.hitEnemy(e,p.dmg,p.src,{kb:big,critAdd:p.critAdd,critMul:p.critMul,head:!!p.headNow&&!e.fly&&!e.boss,sure:p.sure,nocrit:p.nocrit});p.headNow=false;
          if(p.aimedBy&&e.dead&&p.aimedBy.abT>0){p.aimedBy.abT*=.5;p.aimedBy=null;}   /* 0.12.63 (Kyle): an Aimed Shot kill halves what's left of its cooldown */
          if(p.blowBy&&isUndead(e)&&p.blowBy.bgT>0){p.blowBy.bgT*=.5;p.blowBy=null;}   /* Blow_Gun into a poison-immune target: remaining cooldown halved */
          if(p.poison&&!e.dead){let n=1;for(const ch of p.poison)if(this.rng()<ch)n++;this.addPoison(e,n);}
          if(p.kind==='kunai'&&!e.dead&&!isUndead(e)&&this.rng()<.5)this.addPoison(e,1);   /* 0.12.63 (Kyle): kunai have a 50% chance to add/refresh a poison stack */
          if(p.stunCh&&!e.dead&&this.rng()<p.stunCh){e.stun=Math.max(e.stun||0,p.stunT*(e.boss?.3:1));this.text(e.x,e.y-(e.fly?20:48),'STUNNED','#ffffff');}
          this.fx.push({k:'spark',x:p.x,y:p.y,t:0,c:PCOL[p.kind]||'#fff'});
          if(p.pierce>0)p.pierce--;else{p.dead=true;break;}}
        continue;}
      if(p.enemy){const tx=p.tx.x,ty=this.G-30;const dx=tx-p.x,dy=ty-p.y,d=Math.hypot(dx,dy);
        if(d<6||!p.tx.alive){p.dead=true;if(p.tx.alive)this.hurtHero(p.tx,p.dmg,p.src);continue;}
        p.x+=dx/d*p.spd*dt;p.y+=dy/d*p.spd*dt;continue;}
      let tg=p.tx;if(!tg||tg.dead){tg=this.enemies.filter(e=>!e.dead&&!p.hit.has(e)&&e.x>p.x-10).sort((a,b)=>a.x-b.x)[0];p.tx=tg;}
      if(!tg){p.x+=p.spd*dt;if(p.x>this.W+20)p.dead=true;continue;}
      const ty=tg.boss?tg.y-60:tg.fly?tg.y:tg.y-22;const tx=tg.x-(tg.boss?20:0);
      if(p.kind==='brick'){if(p.sx==null){p.sx=p.x;p.sy=p.y;p.T=Math.max(.35,Math.abs(tx-p.x)/p.spd);}const u=Math.min(1,p.t/p.T);
        p.x=p.sx+(tx-p.sx)*u;p.y=p.sy+(ty-p.sy)*u-46*4*u*(1-u);p.rot=(p.rot||0)+dt*14;if(u>=1){p.x=tx;p.y=ty;}}
      else{const dx=tx-p.x,dy=ty-p.y,d=Math.hypot(dx,dy)||1;p.x+=dx/d*p.spd*dt;p.y+=dy/d*p.spd*dt;}
      if(Math.abs(p.x-tx)<8&&Math.abs(p.y-ty)<(tg.boss?40:16)){
        p.hit.add(tg);const big=BIGP[p.kind]||0;const dmg=p.opt.onHit?p.opt.onHit(tg,p.dmg,0):this.hitEnemy(tg,p.dmg,p.src,{kb:big});
        if(p.splash)for(const o of this.enemies)if(o!==tg&&!o.dead&&Math.abs(o.x-tg.x)<p.splash)this.hitEnemy(o,p.dmg*.5,p.src,{nocrit:1});
        if(p.chill&&!tg.dead){tg.slow=Math.max(tg.slow,.25);tg.slowT=1.5;}
        this.fx.push({k:'spark',x:p.x,y:p.y,t:0,c:PCOL[p.kind]||'#fff'});
        if(p.opt.chain&&!p.chained){const n=this.enemies.filter(e=>!e.dead&&!p.hit.has(e)).sort((a,b)=>Math.abs(a.x-tg.x)-Math.abs(b.x-tg.x))[0];if(n){p.chained=1;p.tx=n;continue;}}
        if(p.pierce>0){p.pierce--;p.tx=null;}else p.dead=true;}
      if(p.t>4)p.dead=true;}
    for(const p of this.proj)if(p.dead&&p.aimed&&p.foes==='enemies'&&p.src&&p.src.key&&!(p.hit&&p.hit.size)&&!p._fc){p._fc=1;this.failAct(p.src);}
    this.proj=this.proj.filter(p=>!p.dead);
    // fx + text
    // 0.12.14 (Kyle): nothing lying on the ground slides along with the party: bodies, stuck arrows, thorns, scorch marks scroll with the ground
    this.stepRevive(dt);this.stepKennel(dt);/* 0.12.243 (Kyle) Dice-Boys_Banner is a ZONE: while you stand within 300px of it you hit 15% harder and get +0.5 energy a second. While ALL THREE heroes
       are in it at once, everyone gets +7% crit (it lasts as long as all three stay in, up to the banner's 8s) and they yell DICE BOYS! the first time. */
    for(const o of this.heroes)o.bnIn=null;
    if(this.banners&&this.banners.length){const team=this.alive().filter(o=>!o.pet);for(const B of this.banners){B.t-=dt;B.x-=(this.scroll||0)*dt;const ins=team.filter(o=>Math.abs(this.heroX(o)-B.x)<B.r);
        if(B.own&&B.own.cap&&B.own.cap.cz_boss){B.pT=(B.pT||0)+dt;if(B.pT>=2){B.pT=0;this.fx.push({k:'ring',x:B.x,y:B.gy-14,t:0,r:30,c:'#8cff46'});const O=B.own;for(const e of this.enemies)if(!e.dead&&!e.fly&&Math.abs(e.x-B.x)<B.r&&Math.abs((e.gy!=null?e.gy:this.G)-B.gy)<B.r)this.hitEnemy(e,this.rollDice([1,6])+2,O.alive?O:null,{sure:1,quiet:1});}}   /* 0.12.249 Final_Boss_of_Game_Night: the banner pulses */
        for(const o of ins){if(!o.bnIn||B.dmg>o.bnIn.dmg)o.bnIn=B;o.en=Math.min(o.enMax||100,(o.en||0)+B.regen*dt);}B.all=team.length>=3&&ins.length===team.length&&B.t>0;
        if(B.all&&!B.shouted){B.shouted=1;for(const o of ins)Comms.bubble(this,o,'DICE BOYS!',true);this.text(B.x,B.gy-60,'DICE BOYS!','#8cff46',true);}}
      this.banners=this.banners.filter(B=>B.t>0&&B.x>-20);}
    for(const o of this.heroes){const want=o.bnIn&&o.bnIn.all?o.bnIn.crit:0;if((o.bnCrit||0)!==want){o.crit=(o.crit||0)-(o.bnCrit||0)+want;o.bnCrit=want;}}
    if(this.waves&&this.waves.length)this.stepWaves(dt);
    for(const o of this.heroes)if(o.sakeB){o.sakeB.T-=dt;if(o.sakeB.T<=0||!o.alive)this.sakeEnd(o);}
    for(const e of this.enemies)if(e.armorCut>0){e.armorCut-=dt;if(e.armorCut<=0&&e.armor0!=null){e.armorPts=e.armor0;e.armor0=null;}}   /* 0.12.234 Cheez: banner, host buff, override */this.stepBarrels(dt,this.scroll||0);this.stepRadio(dt,this.scroll||0);if(this.nailFields&&this.nailFields.length){for(const F of this.nailFields){F.t-=dt;F.x0-=(this.scroll||0)*dt;F.x1-=(this.scroll||0)*dt;for(const e of this.enemies){if(e.dead||e.fly||e.boss)continue;if(e.x>=F.x0&&e.x<=F.x1&&Math.abs((e.gy!=null?e.gy:this.G)-F.gy)<6){e.slow=Math.max(e.slow||0,F.slow);e.slowT=Math.max(e.slowT||0,.25);}}}this.nailFields=this.nailFields.filter(F=>F.t>0);}   /* 0.12.211 Edward's Nail_Strip nails on the ground */this.stepGlNades(dt,scroll);this.stepClones(dt,scroll);this.stepWatchdog(dt);this.stepSandbags(dt,scroll);this.stepClimb(dt,scroll);this.stepHerbs(dt,scroll);this.stepDisarm(dt);
    for(const h of this.alive()){this.obClamp(h,true);this.mineClamp(h);}for(const e of this.enemies)if(!e.dead)this.obClamp(e,false);
    for(const x of this.fx){x.t+=dt;if(scroll&&GROUND_FX.has(x.k))x.x-=scroll*dt;}this.fx=this.fx.filter(x=>x.t<(x.life||.6));
    if(scroll)for(const h of this.heroes.concat(this.pets||[]))if(!h.alive&&h.x!=null)h.x-=scroll*dt;   // fallen heroes stay where they fell
    for(const x of this.texts){x.t+=dt;x.y-=dt*14;}this.texts=this.texts.filter(x=>x.t<.9);
    if(this.shake>0)this.shake-=dt;
  }
  // ---- 0.12.3 gunner (Flannel_Man): one body with a melee weapon and a gun on their own timers.
  //   Melee when something is in reach (crowbar), otherwise shoot. Each shot uses a round; with an empty clip he reloads.
  //   Shooting on the move costs accuracy (flat walkPenalty, never below 1) and plays the walking-fire animation.
  gunner(h,dt,f,findT){const AB_x=(C,id)=>(C.abilities||[]).find(a=>a.id===id);const C=h.base.char;const st=h.style;
    if(h.shoutT>0)h.shoutT-=dt;const cry=h.shoutT>0?h.shoutB:null;if(h.mom&&this.t-(h.momT||0)>2)h.mom=0;if(h.cloneT>0)h.cloneT-=dt;
    const spdB=(cry?1+cry.spd:1)*(h.rageT>0?1.2:1)*(1+(h.mom||0)*(h.momPer||0));h.cryDmg=(cry?1+cry.dmg:1)*(h.pactT>0?1+(h.pactDmg||.2):1);if(h.pactT>0)h.pactT-=dt;
    if(h.laughT>0)h.laughT-=dt;
    if(h.cozyT>0){h.cozyT-=dt;h._cozyAcc=(h._cozyAcc||0)+dt;while(h._cozyAcc>=.5){h._cozyAcc-=.5;this.healHero(h,.25,true,h);h.en=Math.min(h.enMax||100,(h.en||0)+.25);}}
    h.mT=(h.mT||0)+dt*h.meleeSpd*spdB*(h.cozyT>0?1+COZY.melee:1)*(h.key==='jp'?(h.highT>0?1.2:(h.soberT||0)>10?.9:1):1)*(h.lethalT>0?1.75:1)*(h.hunger>0?1-HUNGER.spd[h.hunger]:1);h.rT=(h.rT||0)+dt*h.rangedSpd*spdB*(h.hunger>0?1-HUNGER.spd[h.hunger]:1)*(h.ammoBuffT>0?1.15:1);if(h.animM>0)h.animM-=dt;if(h.animR>0)h.animR-=dt;
    if(h.ammo==null)h.ammo=C.ranged?(C.ranged.clip||Infinity):0;   // clip 0 = never reloads
    if(C.ranged&&h.ammo<=0&&C.ranged.clip>0){if(!h.reloadT&&C.ranged.reload>=1.5&&!C.ranged.quietReload)Comms.onReload(this,h);h.reloadT=(h.reloadT||0)+dt*h.rangedSpd*spdB*(h.key==='soldier'&&h.hp<h.max*.5?1.25:1)*(h.crateT>0?1.5:1);   /* 0.12.200 Ammo_Drop: 50% faster reloads near the crate */if(h.reloadT>=(h.key==='soldier'&&h.clipStk>0?3.5:C.ranged.reload)){if(h.key==='soldier'&&h.clipStk>0){h.clipStk--;this.text(this.heroX(h),(h.gy||this.G)-40,'SPARE MAG','#ffd27a');}h.reloadT=0;h.ammo=C.ranged.clip;}}
    if(h.key==='soldier'){h.clipCT=(h.clipCT||0)+dt;if(h.clipCT>=15){h.clipCT=0;if((h.clipStk||0)<2)h.clipStk=(h.clipStk||0)+1;}}   /* 0.12.202 (Kyle) Battle_Hardened: a spare mag every 15s (max 2); a reload with one takes 3.5s instead of 7s */
    const reachPx=ENEMY_BODY+C.melee.reach*UNIT_SCALE;   // same body gap the zombies measure from, so a 20 reach out-reaches a 12 reach zombie
    /* 0.12.67 Stealth AI (works for any stealth source): IF I'm hidden AND (I'm hurt under 45% OR a friend is down) THEN hold my fire and stay hidden
       (let heals land, get revived, or slip over and revive them: reviving doesn't break it); IF I'm hidden and healthy THEN take the free opening shot (which reveals me) */
    if(h.stealthT>0&&!h.pet&&(h.hp/h.max<.45||this.heroes.some(o=>!o.alive&&o.downed))){if(h.lz)h.lz=null;return;}
    if(h.gat){this.robotGat(h,dt,C);return;}
    // ---- 0.12.67 Warhound (Kyle's rework): everything IF/THEN on what's on the field; runs before the attack so it works up close too
    if(h.key==='robot'){const RB=id=>(C.abilities||[]).find(a=>a.id===id);const SU=RB('surge'),MS=RB('missiles'),SM=RB('smoke'),NB=RB('nano'),LZ=C.ranged&&C.ranged.lazer;
      for(const [A,k] of [[SU,'suT'],[MS,'msT'],[SM,'smT'],[NB,'nbT']])if(A){if(h[k]==null)h[k]=A.cd*.25;if(h[k]>0)h[k]-=dt;}if(h.pdT>0)h.pdT-=dt;
      if(h.surgeT>0)h.surgeT-=dt;if(h.launchT>0)h.launchT-=dt;if(h.throwT>0)h.throwT-=dt;if(h.lzReload>0)h.lzReload-=dt*h.rangedSpd*spdB;
      if(h.jet){this.robotJet(h,dt);return;}   // Tactical_Retreat flight
      const live=this.enemies.filter(e=>!e.dead&&e.x<this.W+4),en=h.en||0,hx=this.heroX(h);const onMe=live.filter(e=>!e.fly&&Math.abs(e.x-hx)<16).length;
      // Nano-Tech_Repair_Bots in progress: stopped, 5%/s; IF I get swarmed (2+ on me) and I'm not desperate THEN cut it short
      if(h.nano){const N=h.nano;N.t+=dt;if(!(h.cap&&h.cap.rb_titan)){h.pauseT=Math.max(h.pauseT||0,.05);h.moving=false;}   /* 0.12.249 Titan_Frame: repairs on the move */this._mech=1;this.healHero(h,h.max*NB.per*dt,true,h);this._mech=0;
        if(N.t>=NB.dur||(!(h.cap&&h.cap.rb_titan)&&N.t>1&&onMe>=2&&h.hp/h.max>.3)){const cut=N.t<NB.dur;h.nano=null;Comms.bubble(this,h,cut?Comms.pick(['REPAIR: ABORTED.','THREAT DETECTED. RESUMING.']):Comms.pick(['REPAIRS: COMPLETE.','HULL: RESTORED.','SYSTEMS: NOMINAL.']));}if(!(h.cap&&h.cap.rb_titan))return;}
      /* 0.12.249 Titan_Frame: repairs on the move, so he runs the bots at 70% even with zombies on him */
      if(NB&&h.nbT<=0&&en>=NB.en&&!h.nano&&h.hp/h.max<(h.cap&&h.cap.rb_titan?.7:NB.under)&&(h.cap&&h.cap.rb_titan||h.hp/h.max<.3||onMe===0)&&spendEnergy(h,NB.en)){h.nbT=NB.cd*(1-(h.cdr||0));h.nano={t:0};h.lz=null;this.ev('zap',{});Comms.bubble(this,h,Comms.pick(['DEPLOYING REPAIR SWARM.','DAMAGE DETECTED. REPAIRING.','NANITES: ENGAGE.']));return;}
      // Arc_Surge: IF the lazer is burning (or 3+ enemies are in lazer range) THEN overcharge it
      if(SU&&h.suT<=0&&!(h.surgeT>0)&&en>=SU.en&&LZ&&(h.lz&&h.lz.t>=LZ.charge*.5||live.filter(e=>Math.abs(e.x-hx)<=LZ.max).length>=3)&&spendEnergy(h,SU.en)){
        h.suT=SU.cd*(1-(h.cdr||0));h.surgeT=SU.dur;addMood(h,{range:SU.slide},SU.dur,'surge');this.ev('zap',{});this.fx.push({k:'ring',x:h.x,y:(h.gy||this.G)-24,r:18,t:0,c:'#49c8ff'});
        Comms.bubble(this,h,Comms.pick(['ARC SURGE: ONLINE.','OVERCHARGING LAZER.','POWER TO WEAPONS.']));}
      // IF a hurt ally has enemies on them (or I'm swarmed) THEN smoke the spot
      if(SM&&h.smT<=0&&en>=SM.en&&!(h.throwT>0)&&!h.lz){const al=this.alive();let spot=null,who=null;
        for(const o of al){if(o.hp/o.max>=SM.under||o===h)continue;const on=live.filter(e=>Math.abs(e.x-this.heroX(o))<40);if(on.length){spot=(on.reduce((s,e)=>s+e.x,0)/on.length+this.heroX(o))/2;who=o;break;}}
        if(spot==null&&onMe>=3)spot=hx+10;
        if(spot!=null&&Math.abs(spot-hx)<140&&spendEnergy(h,SM.en)){h.smT=SM.cd*(1-(h.cdr||0));h.throwT=.45;faceToward(h,spot,1);const gy=(who&&who.gy)||h.gy||this.G;
          setTimeoutSafe(this,.25,()=>{if(!h.alive)return;this.ev('whoosh',{});(this.nades=this.nades||[]).push({x0:h.x,x:h.x,x1:spot,gy0:h.gy||this.G,gy,t:0,T:SM.throw,A:SM,src:h});});
          Comms.say(this,h,'smoke',{x:spot,ally:who});return;}}
      /* 0.12.236 Carpet_Bomb: IF 4+ zombies (or a boss) are 40-390px ahead AND I'm over 45% THEN jetpack forward and bomb the road (Calculated Play wants 5+) */
      {const PD=RB('directive'),CB=PD&&PD.carpet;if(CB&&!(h.pdT>0)&&en>=CB.en&&!h.lz&&!h.nano&&h.hp/h.max>(h.cap&&h.cap.rb_omega?.3:.45)&&!this.exiting){const ahead=live.filter(e=>!e.fly&&e.x-hx>=13&&e.x-hx<=CB.dist+10);const need=(trait(h,'aggr')<.35?5:4)-(h.cap&&h.cap.rb_omega?1:0);   /* Omega_Directive: short cooldown, bombs more freely */
        if((ahead.length>=need||ahead.some(e=>e.boss))&&spendEnergy(h,CB.en)){h.abWhy='CARPET BOMB: '+ahead.length+' ahead';h.abWhyT=this.t+3;this.startJet(h,'carpet');return;}}}
      // IF 3+ enemies are bunched 40-260px out (or a boss is up) THEN missile barrage on the thickest spot
      if(MS&&h.msT<=0&&en>=MS.en&&!(h.launchT>0)&&!h.lz){let best=null,bn=0;for(const e of live){const d=e.x-hx;if(d<MS.min||d>MS.range)continue;const n=live.filter(o=>Math.abs(o.x-e.x)<MS.spread*1.6).length+(e.boss?3:0);if(n>bn){bn=n;best=e;}}
        if(best&&bn>=(h.cap&&h.cap.rb_swarm?2:3)&&spendEnergy(h,MS.en)){h.msT=MS.cd*(1-(h.cdr||0));h.launchT=.2+MS.n*MS.gap+.2;
          for(let i=0;i<MS.n;i++)setTimeoutSafe(this,.2+i*MS.gap,()=>{if(!h.alive)return;const T=best.dead?(live.find(e=>!e.dead)||best):best;this.fireMissile(h,T,MS);});
          Comms.say(this,h,'missiles',{});return;}}
      // Targeted Lazer in progress (he plants and holds the beam); IF something gets right on top of me THEN drop the beam and use the flamethrower
      if(h.lz){if(onMe>=1&&h.lz.t>LZ.charge){h.lz=null;h.lzReload=LZ.reload;}else{this.robotLazer(h,dt,LZ);return;}}}
    // ---- 0.12.75 Engineer: Build / Repair / Modify / Satchel_Charge (IF/THEN on the field). Building and repairing pause his other cooldowns.
    // ---- 0.12.180 Crimson_Knight: Shield_Wall, Crimson_Charge, Leap_Strike
    if(h.key==='cheez'){const AB=id=>(C.abilities||[]).find(a=>a.id===id);const IA=AB('iai'),SK=AB('sake'),EF=AB('errfix'),HO=AB('host');const T=k=>trait(h,k);const hx=this.heroX(h),gy=h.gy||this.G;
      for(const k of ['iaT','skT','efT','hoT'])if(h[k]>0)h[k]-=dt;if(h.sipT>0)h.sipT-=dt;if(h.iaT==null){h.iaT=IA.cd*.3;h.skT=SK.cd*.3;h.efT=EF.cd*.3;h.hoT=HO.cd*.4;}
      const live=this.enemies.filter(e=>!e.dead&&!e.fly&&e.x>2&&e.x<this.W+2);const lane=e=>e.gy!=null?e.gy:this.G;const al=this.alive().filter(o=>!o.pet);
      // Drunken_Style running
      if(h.sakeOn>0){h.sakeOn-=dt;if(h.sakeOn<=0)h.sakeShared=0;if(this.rng()<dt*SK.hic*1.2&&!(h.hicT>0)){h.hicT=.3;h.pauseT=Math.max(h.pauseT||0,.3);this.text(hx,gy-48,'*hic*','#b8ff7a');}if(h.hicT>0)h.hicT-=dt;
      }
      /* 0.12.236 (Kyle) Iaijutsu is now a WAVE: a short sheathe, then the draw-slash throws a cyan crescent down his lane (fast, ~600px a second, ~420px):
         2d8 to everything it passes, the first one a guaranteed crit. He does NOT dash. While the wave is out he can reactivate ONCE to blink to wherever
         the wave is right now. Half damage skill, half movement skill: he thinks about the blink 10 times a second. */
      if(h.iaiA){const A=h.iaiA;A.t+=dt;h.pauseT=Math.max(h.pauseT||0,.05);h.moving=false;h.face=A.dir;
        if(A.t>=IA.hold&&!A.done){A.done=1;(this.waves=this.waves||[]).push({x:hx+A.dir*8,x0:hx,gy,dir:A.dir,spd:IA.spd,left:IA.range,src:h,hit:new Set(),first:1,esc:A.esc,t:0});h.wave=this.waves[this.waves.length-1];h.blinkOK=1;this.ev('slash',{});
          if(A.esc)Comms.bubble(this,h,Comms.pick(['Brb!','Nope. Logging off.','Tactical anime exit!']),true);}
        if(A.t>=IA.hold+.2)h.iaiA=null;return;}
      /* Blink: the reactivation. Re-thought every 0.1s while the wave is out. */
      if(h.wave&&h.blinkOK&&(h.blinkThink=(h.blinkThink||0)-dt)<=0){h.blinkThink=.1;const W=h.wave,wx=W.x;let go=null;
        const near=x=>live.filter(e=>Math.abs(e.x-x)<18&&Math.abs(lane(e)-W.gy)<10).length,onMe=near(hx),atW=near(wx),dist=Math.abs(wx-hx);
        if(W.esc){if(dist>=55||W.left<12)go='escape';}   /* escape wave: ride it out once it's far enough (or about to fizzle) */
        else{const hp=h.hp/h.max;
          if((hp<.4&&onMe>=2||hp<.55&&onMe>=3)&&dist>=35&&atW<=1)go='bail';   /* swarmed and hurt: hop onto the wave if it's somewhere quieter */
          else if(dist>=30&&live.some(e=>(e.E&&(e.E.scream||e.type==='skarcher')||e.nem)&&Math.abs(e.x-wx)<10&&Math.abs(lane(e)-W.gy)<10)&&hp>.35)go='hunt';   /* the wave reached a priority target: go finish it */
          else{const pal=al.find(o=>o!==h&&o.hp/o.max<.5&&Math.abs(this.heroX(o)-wx)<16&&live.some(e=>Math.abs(e.x-this.heroX(o))<20)&&dist>=40);if(pal&&hp>.45)go='save';}   /* a friend in trouble right where the wave is */
          if(!go&&h.cap&&h.cap.cz_speed&&hp>.4&&dist>=30&&atW>=1&&T('aggr')>.3)go='engage';   /* Speedrun: a blink is a free buff, so he blinks in whenever there's something at the wave */
          if(!go&&hp>.5&&dist>=35&&onMe===0&&atW>=2&&W.hit.size>=1&&T('range')>.6&&this.rng()<.7)go='engage';   /* a Slasher: the wave just carved into a pack and he's not fighting: blink in and get stuck in */
          if(!go&&W.left<14&&dist>=60&&T('pace')>.6&&atW<=2&&hp>.5&&live.filter(e=>(e.x-hx)*W.dir>0).length===0)go='advance';}   /* nothing ahead: free ground, take it */
        if(go){h.blinkOK=0;if(h.cap&&h.cap.cz_speed){tbuff(h,{sp:.5,mv:.3},4);h.iaT=0;this.text(hx,gy-56,'SPEEDRUN','#3af0ff');}const x1=Math.max(6,Math.min(this.W-20,wx));this.fx.push({k:'iaicut',x0:hx,x1,gy:gy-14,t:0,life:.35,raw:1});this.fx.push({k:'puff',x:hx,y:gy-2,t:0,life:.4,s:1.2});h.x+=x1-hx;h.gy=W.gy;
          this.fx.push({k:'ring',x:x1,y:gy-14,t:0,r:10,c:'#3af0ff'});this.ev('whoosh',{});h.abWhy='IAI BLINK: '+go;h.abWhyT=this.t+3;
          if(go!=='escape'&&this.rng()<.5)Comms.bubble(this,h,Comms.pick(go==='save'?['Got you!','Cheez to the rescue!']:go==='bail'?['Respawning over here.','Lag switch!']:['Nothing personnel, kid.','Too slow.','Teleport behind you.']),true);return;}}
      /* Iaijutsu: offense: IF 2+ lined up in his lane within ~420px, or a Screamer / archer / Nemesis on it (Blind Aggression: any 1)
                   escape: IF he's under 45% with 2+ on him THEN throw the wave BACK toward the rear and ride it out */
      if(IA&&h.iaT<=0&&(h.en||0)>=IA.en&&!h.wave){const onMe=live.filter(e=>Math.abs(e.x-hx)<16&&Math.abs(lane(e)-gy)<10).length;let best=null;
        if(h.hp/h.max<.45&&onMe>=2&&hx>60){const dir=-1;best={dir,esc:1,n:0};}
        else for(const dir of [1,-1]){const L2=live.filter(e=>Math.abs(lane(e)-gy)<8&&Math.sign(e.x-hx)===dir&&Math.abs(e.x-hx)<=IA.range);const pri=L2.some(e=>e.E&&(e.E.scream||e.type==='skarcher')||e.nem);
          const gap=!L2.some(e=>Math.abs(e.x-hx)<25);if(L2.length>=(T('aggr')>.8||(gap&&T('range')>.6)?1:2)||pri){if(!best||L2.length>best.n)best={dir,n:L2.length,pri};}}
        if(best&&spendEnergy(h,IA.en)){h.iaT=IA.cd*(1-(h.cdr||0));h.iaiA={t:0,dir:best.dir,esc:best.esc};h.abWhy='IAIJUTSU: '+(best.esc?'escape wave':best.pri?'priority target':best.n+' lined up');h.abWhyT=this.t+3;
          if(!best.esc&&this.rng()<.5)Comms.bubble(this,h,Comms.pick(['Iai!','Clean cut.','Omae wa mou shindeiru.','Getsuga... no, wrong anime.']),true);return;}}
      /* Error_Code_Fix: REBOOT a hurt / bleeding / slowed / stunned friend, else OVERRIDE a Fireman or Nemesis */
      if(EF&&h.efT<=0&&(h.en||0)>=EF.en){const th=T('aware')>.6?.6:.5;const pat=al.filter(o=>Math.abs(this.heroX(o)-hx)<EF.r&&(o.hp/o.max<th||o.bleedT>0||o.slowT>0||o.stun>0)).sort((a,b)=>a.hp/a.max-b.hp/b.max)[0];
        const big=pat?null:live.filter(e=>(e.type==='fireman'||e.nem)&&Math.abs(e.x-hx)<EF.r*1.2).sort((a,b)=>Math.abs(a.x-hx)-Math.abs(b.x-hx))[0];
        if((pat||big)&&spendEnergy(h,EF.en)){h.efT=EF.cd*(1-(h.cdr||0));h.animM=.4;
          if(pat){const amt=pat.max*EF.heal;pat.hp=Math.min(pat.max,pat.hp+amt);pat.bleedT=0;pat.slowT=0;pat.slow=0;pat.stun=0;this.text(this.heroX(pat),(pat.gy||this.G)-44,'REBOOT +'+Math.round(amt),'#3af0ff');this.fx.push({k:'ring',x:this.heroX(pat),y:(pat.gy||this.G)-14,t:0,r:14,c:'#3af0ff'});h.abWhy='ERROR FIX: rebooting '+Comms.name(pat);
            if(this.rng()<.5)Comms.bubble(this,h,Comms.pick(['Have you tried turning it off and on again?','Error code fixed. You\'re welcome.','Rebooting you, hold still.']),true);}
          else{big.stun=Math.max(big.stun||0,EF.stun);big.armorCut=EF.arm;if(!big.armor0){big.armor0=big.armorPts||0;big.armorPts=Math.floor(big.armor0/2);}this.text(big.x,lane(big)-34,'OVERRIDE','#8cff46');this.fx.push({k:'ring',x:big.x,y:lane(big)-14,t:0,r:14,c:'#8cff46'});h.abWhy='ERROR FIX: override on the big one';
            if(this.rng()<.5)Comms.bubble(this,h,Comms.pick(['Tilt! Machine down.','Error 404: your armor.','Hard reset, buddy.']),true);}
          h.abWhyT=this.t+3;return;}}
      /* Sake_Break: IF 3+ within 180px or a boss/Nemesis close (Preserve: 4+ or a big one) */
      if(SK&&h.skT<=0&&!(h.sakeOn>0)&&(h.en||0)>=SK.en){const near=live.filter(e=>Math.abs(e.x-hx)<60);const bigN=this.enemies.some(e=>!e.dead&&(e.boss||e.nem)&&Math.abs(e.x-hx)<120);
        if((near.length>=(T('energy')>.65?4:3)||bigN)&&spendEnergy(h,SK.en)){h.skT=SK.cd*(1-(h.cdr||0));h.sakeOn=SK.dur;h.sakeShared=0;this.sakeBuff(h,1,SK.dur,SK);h.sipT=.6;h.pauseT=Math.max(h.pauseT||0,.5);
          this.text(hx,gy-50,'SAKE BREAK','#b8ff7a');h.abWhy='SAKE: '+(bigN?'a big one is here':near.length+' close');h.abWhyT=this.t+3;Comms.bubble(this,h,Comms.pick(['Kanpai!','Liquid courage, activate!','One for me, none for the zombies.','Drunken master mode.']),true);return;}}
      /* 0.12.238 (Kyle) Sake_Break, SHARE: while he's drunk he can pass the bottle once to a friend within 150px. They get half the effect for half the time
         (full effect and full time if they're standing in his Dice-Boys_Banner), and his remaining cooldown is halved and half the energy cost comes back.
         AI: a friend in a fight (2+ zombies on them) or a friend in the banner, the banner first; Team Player (pack) shares sooner. */
      if(SK&&h.sakeOn>0&&!h.sakeShared&&h.sakeOn<SK.dur-1){const cands=al.filter(o=>o!==h&&!o.sakeB&&Math.abs(this.heroX(o)-hx)<50&&o.alive).map(o=>{const fight=live.filter(e=>Math.abs(e.x-this.heroX(o))<20).length;return {o,fight,inB:!!o.bnIn};})
          .filter(c=>c.inB||c.fight>=(T('pack')>.6?1:2)||(h.cap&&h.cap.cz_happy&&c.fight>=(T('pack')>.4?0:1))).sort((a,b)=>(b.inB-a.inB)||(b.fight-a.fight));const c=cands[0];
        if(c&&h.cap&&h.cap.cz_happy){for(const d of cands.slice(1))this.sakeBuff(d.o,d.inB?1:.5,d.inB?SK.dur:SK.share,SK);if(cands.length>1)this.text(hx,gy-62,'HAPPY HOUR! x'+cands.length,'#b8ff7a',true);}   /* 0.12.249 Happy_Hour: the whole crew gets a swig */
        if(c){h.sakeShared=1;const full=c.inB;this.sakeBuff(c.o,full?1:.5,full?SK.dur:SK.share,SK);h.skT=Math.max(0,h.skT*(full?.25:.5));h.en=Math.min(h.enMax||100,(h.en||0)+SK.en*(full?.75:.5));   /* 0.12.238 (Kyle): sharing with a Dice Boy in the banner is really good: their full effect + full time, 75% of his remaining cooldown gone and 3/4 of the energy back */h.sipT=.4;
          this.text(this.heroX(c.o),(c.o.gy||this.G)-50,full?'SAKE! (full, Dice Boys)':'SAKE (half)','#b8ff7a');h.abWhy='SAKE SHARE: '+Comms.name(c.o)+(full?' (in the banner)':'');h.abWhyT=this.t+3;
          Comms.bubble(this,h,Comms.pick(['Here, take a swig.','Kanpai, '+Comms.name(c.o)+'!','Sharing is caring.','Drink up, buttercup.']),true);if(this.rng()<.6)Comms.bubble(this,c.o,Comms.pick(['Kanpai!','Oh that burns. Good burn.','Okay, NOW I can fight.']));return;}}
      /* Dice-Boys_Banner: IF 2+ friends within 300px of him and a fight is on (3+ zombies on screen) */
      if(HO&&h.hoT<=0&&(h.en||0)>=HO.en){const by=al.filter(o=>o!==h&&Math.abs(this.heroX(o)-hx)<HO.r);
        if(by.length>=(h.cap&&h.cap.cz_boss?(T('pack')>.5?1:2):2)&&live.length>=3&&spendEnergy(h,HO.en)){h.hoT=HO.cd*(1-(h.cdr||0));const B={x:hx-(h.face||1)*6,gy,t:HO.dur,T:HO.dur,r:HO.r,dmg:HO.dmg,crit:HO.crit,regen:HO.regen,own:h,isBanner:1};(this.banners=this.banners||[]).push(B);h.animM=.4;
          const inB=al.filter(o=>Math.abs(this.heroX(o)-B.x)<B.r);if(inB.length<3)Comms.bubble(this,h,Comms.pick(['Game night at my place!','Snacks are in the kitchen, zombies are outside.','Host privileges!']),true);
          h.abWhy='HOST: '+inB.length+' at the banner';h.abWhyT=this.t+3;return;}}
    }
    if(h.key==='knight'){const AB=id=>(C.abilities||[]).find(a=>a.id===id);const SW=AB('wall'),CC=AB('charge'),LS=AB('kleap'),BO=AB('oath');for(const k of ['swT','ccT','lsT'])if(h[k]>0)h[k]-=dt;if(h.swT==null){h.swT=SW.cd*.3;h.ccT=CC.cd*.3;h.lsT=LS.cd*.4;}
      h.oathOn=!!(BO&&h.hp<h.max*BO.under);if(BO&&BO.regen){const n=this.enemies.filter(e=>!e.dead&&Math.abs(e.x-this.heroX(h))<=BO.regR&&Math.abs((e.gy!=null?e.gy:this.G)-(h.gy||this.G))<=BO.regR).length;if(n)this.healHero(h,BO.regen*n*dt,true,h);}   /* 0.12.238 Blood_Oath regen */h.cryDmg=(h.cryDmg||1)*(h.oathOn?1+BO.dmg:1);
      const hx=this.heroX(h),gy=h.gy||this.G;const lane=e=>e.gy!=null?e.gy:this.G;
      if(h.wallT>0){h.wallT-=dt;h.kbv=0;h.pauseT=Math.max(h.pauseT||0,.05);h.moving=false;{const fw=h.face||1,front=this.enemies.filter(e=>!e.dead&&!e.boss&&!e.fly&&(e.x-hx)*fw>0&&(e.x-hx)*fw<22&&Math.abs((e.gy!=null?e.gy:this.G)-(h.gy||this.G))<8);if(front.length){h.x+=fw*5*dt;h.wallDrag=.2;for(const e of front){const res=(e.E&&e.E.kbRes)||0;if(res<1)e.x+=fw*7*dt*(1-res);}}else if(h.wallDrag>0)h.wallDrag-=dt;}   /* 0.12.214 (Kyle): Shield_Wall drags forward, shoving the zombies on it back */for(const e of this.enemies)if(!e.dead&&!e.boss&&Math.abs(e.x-hx)<SW.r&&!(e.tauntT>0)){e.tauntT=.6;e.tauntBy=h;e.target=h;}if(h.wallT<=0){h.wallT=0;h.kbRes=h.kbRes0;}else return;}
      if(h.charge){const K=h.charge;const st=K.dir*CC.spd*dt;h.x+=st;K.gone+=Math.abs(st);h.pauseT=Math.max(h.pauseT||0,.05);h.moving=false;const nx=this.heroX(h);
        for(const e of this.enemies){if(e.dead||e.fly||K.hit.has(e))continue;if(Math.abs(e.x-nx)<10&&Math.abs(lane(e)-K.gy)<7){K.hit.add(e);this.hitEnemy(e,this.rollDice(CC.dice)*(h.atk/h.base.atk)*(h.cryDmg||1),h,{sure:1});if(!e.dead&&!e.boss){e.kbv=CC.kb*(1-(e.E.kbRes||0));e.kbDir=K.dir;}}}
        if(K.gone>=K.dist||nx<6||nx>this.W-6){h.charge=null;h.animM=0;}return;}
      if(h.kleap){const L=h.kleap;L.t+=dt;h.pauseT=Math.max(h.pauseT||0,.05);h.moving=false;const u=Math.min(1,L.t/LS.T);h.x=L.x0+(L.x1-L.x0)*u;h.leapH=Math.sin(Math.PI*u)*34;
        if(u>=1){h.kleap=null;h.leapH=0;const tg=L.tg;this.fx.push({k:'ring',x:this.heroX(h)+L.dir*8,y:gy-2,t:0,r:16,c:'#ff5a5a'});this.ev('boom',{});this.shake=Math.max(this.shake||0,.3);
          if(tg&&!tg.dead){this.hitEnemy(tg,(this.rollDice(LS.dice)+(LS.flat||0))*(h.atk/h.base.atk)*(h.cryDmg||1),h,{sure:1});if(!tg.dead){tg.stun=Math.max(tg.stun||0,tg.boss?LS.stun*.4:LS.stun);this.text(tg.x,lane(tg)-26,'STUN','#ffe07a');}}
          for(const e of this.enemies){if(e.dead||e===tg||e.fly)continue;if(Math.abs(e.x-(this.heroX(h)+L.dir*8))<16&&Math.abs(lane(e)-gy)<10)this.hitEnemy(e,this.rollDice(LS.splash)*(h.atk/h.base.atk),h,{sure:1});}}
        return;}
      const live=this.enemies.filter(e=>!e.dead&&!e.fly&&e.x>2&&e.x<this.W+2);const al=this.alive().filter(o=>o!==h&&!o.pet);
      const onMe=live.filter(e=>Math.abs(e.x-hx)<20&&Math.abs(lane(e)-gy)<10).length;
      // Shield_Wall
      const T=k=>trait(h,k);
      /* 0.12.194 sliders: Selfless walls up to save allies sooner (under 55%), Selfish only when he's the one swarmed. Pack Hunters leap in for allies under 50%,
         Lone Wolves only under 30%. Blind Aggression charges a line of 2. Panicky won't charge or leap below half HP. */
      const allyHp=T('self')<.4?.55:T('self')>.65?0:.45,leapHp=T('pack')<.4?.65:T('pack')>.65?.45:.55,shaky=T('nerve')>.6&&h.hp/h.max<.5;
      /* 0.12.195 Shield_Bash: ALWAYS IF a Screamer is shrieking or a Skeleton_Archer is drawing within reach THEN bash it (interrupt).
           ELSE IF Pack Hunter AND an ally under 40% has one on them within reach THEN bash that one.
           ELSE IF Blind Aggression THEN bash whatever's in front on cooldown. (Calculated keeps it for the first two.) */
      {const SB=AB('bash');if(h.sbT>0)h.sbT-=dt;if(h.bash){h.bash.t+=dt;h.pauseT=Math.max(h.pauseT||0,.05);h.moving=false;if(h.bash.t>=h.bash.T)h.bash=null;return;}
        if(SB&&!(h.sbT>0)&&(h.en||0)>=SB.en){const inReach=live.filter(e=>Math.abs(e.x-hx)<SB.reach&&Math.abs(lane(e)-gy)<10);let tg=null,why='';
          tg=inReach.find(e=>e.scrT>0&&!e.scrDone)||inReach.find(e=>e.type==='skarcher'&&e.animT>0);if(tg)why='interrupt';
          if(!tg&&T('pack')<.45){for(const o of al){if(o.hp/o.max>=.4)continue;const m=inReach.find(e=>Math.abs(e.x-this.heroX(o))<16);if(m){tg=m;why='off a hurt ally';break;}}}
          if(!tg&&T('aggr')>.6&&inReach.length){tg=inReach[0];why='aggressive';}
          if(tg&&spendEnergy(h,SB.en)){h.sbT=SB.cd*(1-(h.cdr||0));faceToward(h,tg.x,1);h.bash={t:0,T:.4};h.animM=.36;h.swingAnim='attack2';this.hitEnemy(tg,this.rollDice(SB.dice)*(h.atk/h.base.atk),h,{sure:1,kb:15});
            if(!tg.dead){tg.stun=Math.max(tg.stun||0,tg.boss?.5:SB.stun);if(tg.scrT>0)tg.scrT=0;this.text(tg.x,lane(tg)-26,why==='interrupt'?'INTERRUPTED':'STUN','#ffe07a');}this.ev('hit',{});h.abWhy='BASH: '+why;h.abWhyT=this.t+3;return;}}}
      if(SW&&h.swT<=0&&(h.en||0)>=SW.en){const save=al.some(o=>o.hp/o.max<allyHp&&Math.abs(this.heroX(o)-hx)<40&&live.filter(e=>Math.abs(e.x-this.heroX(o))<18).length>=2);
        if((onMe>=(h.cap&&h.cap.kn_bastion?(T('aggr')>.6?1:2):3)||save)&&spendEnergy(h,SW.en)){   /* 0.12.249 Crimson_Bastion: the wall hits back, so he plants it sooner (sooner still with Blind Aggression) */h.abWhy='SHIELD WALL: '+(save?'protecting an ally':'swarmed');h.abWhyT=this.t+3;h.swT=SW.cd*(1-(h.cdr||0));h.wallT=SW.dur;h.wallDR=SW.dr;h.kbRes0=h.kbRes;h.kbRes=1;this.fx.push({k:'ring',x:hx,y:gy-12,t:0,r:SW.r,c:'#ff8080'});this.ev('shout',{});Comms.bubble(this,h,Comms.pick(['To me!','Hold the line!','Behind my shield!','Come on, then!']),true);
          for(const e of live)if(!e.boss&&Math.abs(e.x-hx)<SW.r){e.tauntT=SW.dur;e.tauntBy=h;e.target=h;}return;}}
      // Leap_Strike
      if(LS&&h.lsT<=0&&(h.en||0)>=LS.en&&!shaky){let tg=null;for(const o of al){if(o.hp/o.max>=leapHp)continue;const ox=this.heroX(o);const m=live.filter(e=>Math.abs(e.x-ox)<16).sort((a,b)=>Math.abs(a.x-ox)-Math.abs(b.x-ox))[0];if(m&&Math.abs(m.x-hx)>=LS.min&&Math.abs(m.x-hx)<=LS.max){tg=m;break;}}
        if(!tg)tg=live.find(e=>(e.nem||e.boss)&&Math.abs(e.x-hx)>=LS.min&&Math.abs(e.x-hx)<=LS.max)||null;
        let pack=0;if(!tg){for(const e of live){if(e.fly)continue;const d=Math.abs(e.x-hx);if(d<LS.min||d>LS.max)continue;const n=live.filter(o=>!o.fly&&Math.abs(o.x-e.x)<16&&Math.abs(lane(o)-lane(e))<10).length;if(n>=3&&n>pack){pack=n;tg=e;}}}   /* 0.12.202 (Kyle): he also leaps into a pack of 3+ */
        if(tg&&spendEnergy(h,LS.en)){h.abWhy='LEAP: '+(pack?'into a pack of '+pack:tg.nem||tg.boss?'big threat':'ally in trouble');h.abWhyT=this.t+3;h.lsT=LS.cd*(1-(h.cdr||0));const dir=tg.x>=hx?1:-1;h.face=dir;h.kleap={t:0,x0:h.x,x1:h.x+(tg.x-dir*12-hx),tg,dir};Comms.bubble(this,h,Comms.pick(['Get off them!','For the oath!','Hyaa!']),true);return;}}
      // Crimson_Charge
      if(CC&&h.ccT<=0&&(h.en||0)>=CC.en&&onMe<2&&!shaky){const cNeed=(T('aggr')>.65?2:3)-(h.cap&&h.cap.kn_jugg?1:0);   /* Unstoppable: kills reset it, so he charges smaller lines */let best=null,bn=0;for(const e of live){const d=e.x-hx;if(Math.abs(d)<CC.min||Math.abs(d)>CC.max)continue;const n=live.filter(o=>Math.abs(lane(o)-lane(e))<6&&Math.sign(o.x-hx)===Math.sign(d)&&Math.abs(o.x-hx)<=CC.max+20).length;if(n>bn){bn=n;best=e;}}
        if(best&&bn>=cNeed&&spendEnergy(h,CC.en)){h.abWhy='CHARGE: '+bn+' in a lane';h.abWhyT=this.t+3;h.ccT=CC.cd*(1-(h.cdr||0));const dir=best.x>=hx?1:-1;h.face=dir;h.gy=lane(best);h.charge={dir,gone:0,dist:CC.dist,gy:lane(best),hit:new Set()};this.ev('whoosh',{});Comms.bubble(this,h,Comms.pick(['CHARGE!','Out of my way!','Crimson!']),true);return;}}}
    // ---- 0.12.178 Chibi_Archer: Piercing_Shot and Tumble (both lock her into an animation)
    if(h.key==='carcher'){const AB=id=>(C.abilities||[]).find(a=>a.id===id);const PS=AB('pierce'),TB=AB('tumble');for(const k of ['psT','tbT'])if(h[k]>0)h[k]-=dt;if(h.psT==null){h.psT=PS.cd*.3;h.tbT=0;}
      const hx=this.heroX(h),gy=h.gy||this.G;
      if(h.tumble){const T=h.tumble;T.t+=dt;h.pauseT=Math.max(h.pauseT||0,.05);h.moving=false;const u=Math.min(1,T.t/T.T);h.x=T.x0+(T.x1-T.x0)*(1-(1-u)*(1-u));h.leapH=Math.sin(Math.PI*u)*14;
        if(!T.shot&&u>.45){T.shot=1;const tg=this.enemies.filter(e=>!e.dead&&!e.fly&&Math.abs(e.x-hx)<C.ranged.range).sort((a,b)=>Math.abs(a.x-hx)-Math.abs(b.x-hx))[0];if(tg){faceToward(h,tg.x,1);const p=this.shoot(h,tg,'arrow',(this.rollDice(C.ranged.dice)+C.ranged.flat)*(h.atk/h.base.atk)*h.rangedDmg,{});this.aim(p,h,tg);this.ev('bow',{});}}
        if(u>=1){h.tumble=null;h.leapH=0;}return;}
      if(h.pshot){const P=h.pshot;P.t+=dt;h.pauseT=Math.max(h.pauseT||0,.05);h.moving=false;if(!P.shot&&P.t>=P.T*.55){P.shot=1;if(!P.tg.dead){const p=this.shoot(h,P.tg,'arrow',this.rollDice(PS.dice)*(h.atk/h.base.atk)*h.rangedDmg,{pierce:PS.n});p.big=1;this.aim(p,h,P.tg);p.arc=0;p.h=p.h0=p.aimH=24;p.tgy=p.gy0=p.gy=P.tg.gy!=null?P.tg.gy:this.G;p.sure=1;this.ev('bow',{});   /* flat and true down the lane so it can go through the whole line */this.text(hx,gy-30,'PIERCE','#ffd0d0');}}if(P.t>=P.T)h.pshot=null;return;}
      const live=this.enemies.filter(e=>!e.dead&&!e.fly&&e.x>2&&e.x<this.W+2);
      /* 0.12.195 Snare_Arrow and Hunters_Mark (both use her Shot_2 draw, 0.7s)
         SNARE: IF a fast zombie (Screamer, werewolf) is coming OR one is within 35 of an ally under 40% THEN pin it.
           Pack Hunter checks allies first; Lone Wolf checks what's coming at her first; Panicky also snares anything within 30 of herself; Large Targets prefers the biggest.
         MARK: Ally Awareness marks what the most allies are fighting; Enemy Awareness marks the biggest threat closest to her.
           Preserve only marks a big one (Nemesis, boss, 60+ HP); Squander marks anything with real HP left. Never re-marks a marked zombie. */
      {const T0=k=>trait(h,k);const SN=AB('snare'),HM=AB('hmark');for(const k of ['snT','hmT'])if(h[k]>0)h[k]-=dt;if(h.snT==null){h.snT=SN?SN.cd*.3:0;h.hmT=HM?HM.cd*.4:0;}
        const lv=this.enemies.filter(e=>!e.dead&&!e.fly&&e.x>2&&e.x<this.W-2&&Math.abs(e.x-hx)<C.ranged.range);const lane=e=>e.gy!=null?e.gy:this.G;
        if(SN&&h.snT<=0&&(h.en||0)>=SN.en&&lv.length){const al2=this.alive().filter(o=>o!==h&&!o.pet);
          const allyT=()=>{for(const o of al2){if(o.hp/o.max>=.4)continue;const ox=this.heroX(o);const m=lv.filter(e=>!(e.rootT>0)&&Math.abs(e.x-ox)<35).sort((a,b)=>Math.abs(a.x-ox)-Math.abs(b.x-ox))[0];if(m)return [m,'stopping one on a hurt ally'];}return null;};
          const fastT=()=>{const f=lv.filter(e=>!(e.rootT>0)&&(e.E.spd||0)>=15).sort((a,b)=>T0('size')>.6?b.max-a.max:Math.abs(a.x-hx)-Math.abs(b.x-hx))[0];return f?[f,'a fast one']:null;};
          const meT=()=>{if(T0('nerve')<=.6)return null;const m=lv.filter(e=>!(e.rootT>0)&&Math.abs(e.x-hx)<30)[0];return m?[m,'too close (panicky)']:null;};
          const pick=(T0('pack')<.45?[allyT,fastT,meT]:[meT,fastT,allyT]).map(f=>f()).find(Boolean);
          if(pick&&spendEnergy(h,SN.en)){const [tg,why]=pick;h.snT=SN.cd*(1-(h.cdr||0));faceToward(h,tg.x,1);h.abWhy='SNARE: '+why;h.abWhyT=this.t+3;h.pshot={t:0,T:.7,tg,shot:1};
            setTimeoutSafe(this,.42,()=>{if(!h.alive||tg.dead)return;const p=this.shoot(h,tg,'arrow',this.rollDice(SN.dice)*(h.atk/h.base.atk),{onHit:(e,d)=>{this.hitEnemy(e,d,h,{});if(e.dead)return;if(!e.boss){e.slow=Math.max(e.slow||0,.97);e.slowT=Math.max(e.slowT||0,SN.root);e.rootT=SN.root;}else{e.slow=Math.max(e.slow||0,.5);e.slowT=Math.max(e.slowT||0,1);}
              if(e.scrT>0){e.scrT=0;}this.text(e.x,lane(e)-26,'SNARED','#c8ffb0');for(const o of this.enemies){if(o.dead||o===e||o.fly)continue;if(Math.abs(o.x-e.x)<SN.r&&Math.abs(lane(o)-lane(e))<10){o.slow=Math.max(o.slow||0,SN.slow);o.slowT=Math.max(o.slowT||0,SN.slowT);}}}});this.aim(p,h,tg);this.ev('bow',{});});return;}}
        if(HM&&h.hmT<=0&&(h.en||0)>=HM.en&&lv.length){const big=e=>e.boss||e.nem||e.max>=60;let cand=lv.filter(e=>!(e.markT>0)&&e.hp>8);if(T0('energy')>.6)cand=cand.filter(big);
          let tg=null,why='';if(cand.length){if(T0('aware')>.55){const al2=this.alive().filter(o=>o!==h&&!o.pet);let bs=-1;for(const e of cand){const n=al2.filter(o=>Math.abs(this.heroX(o)-e.x)<30).length+(big(e)?1:0);if(n>bs){bs=n;tg=e;}}why='what the team is on';}
            else{tg=cand.sort((a,b)=>(big(b)-big(a))||Math.abs(a.x-hx)-Math.abs(b.x-hx))[0];why=big(tg)?'the big threat':'closest threat';}}
          if(tg&&(T0('energy')<.35||big(tg)||lv.length>=3)&&spendEnergy(h,HM.en)){h.hmT=HM.cd*(1-(h.cdr||0));faceToward(h,tg.x,1);h.abWhy='MARK: '+why;h.abWhyT=this.t+3;h.pshot={t:0,T:.5,tg,shot:1};tg.markT=HM.dur;tg.markAmp=HM.amp;this.text(tg.x,lane(tg)-30,'MARKED','#ff8080');this.fx.push({k:'ring',x:tg.x,y:lane(tg)-14,t:0,r:9,c:'#ff6060'});Comms.bubble(this,h,Comms.pick(['That one!','Focus here!','Marked!']),true);return;}}}
      /* 0.12.194 sliders: Panicky tumbles away sooner (up to 24px), Steady lets them get to 10. IF Pack Hunter AND a hurt ally (under 35%) is right beside me THEN I stand my ground. */
      const T=k=>trait(h,k);const tr=10+14*T('nerve');const guard=T('pack')<.4&&this.alive().some(o=>o!==h&&!o.pet&&o.hp/o.max<.35&&Math.abs(this.heroX(o)-hx)<20);
      if(guard&&live.some(e=>Math.abs(e.x-hx)<tr)){h.abWhy='STAYING: covering a hurt ally';h.abWhyT=this.t+1;}
      if(TB&&h.tbT<=0&&(h.en||0)>=TB.en&&!guard){const on=live.filter(e=>Math.abs(e.x-hx)<tr&&Math.abs((e.gy!=null?e.gy:this.G)-gy)<9);if(on.length&&spendEnergy(h,TB.en)){h.abWhy='TUMBLE: too close'+(T('nerve')>.6?' (panicky)':'');h.abWhyT=this.t+2;h.tbT=TB.cd*(1-(h.cdr||0));const away=on[0].x>=hx?-1:1;const x1=Math.max(8,Math.min(this.W-8,hx+away*TB.dist));h.tumble={t:0,T:TB.T,x0:h.x,x1:h.x+(x1-hx)};h.face=-away;Comms.bubble(this,h,Comms.pick(['Nope!','Too close!','Hup!']),true);return;}}
      if(PS&&h.psT<=0&&(h.en||0)>=PS.en){let best=null,bn=0;for(const e of live){const d=e.x-hx;if(Math.abs(d)>C.ranged.range||Math.abs(d)<14)continue;const eg=e.gy!=null?e.gy:this.G;const n=live.filter(o=>Math.abs((o.gy!=null?o.gy:this.G)-eg)<5&&Math.sign(o.x-hx)===Math.sign(d)&&Math.abs(o.x-hx)>=Math.abs(d)).length;if(n>bn){bn=n;best=e;}}
        /* 0.12.194: Blind Aggression takes a line of 2 with a big one in it; Preserve holds out for 4 when she'd be left without Tumble energy */
        let need=PS.lineN;const bigIn=best&&live.some(o=>(o.boss||o.nem||o.max>=60)&&Math.abs((o.gy!=null?o.gy:this.G)-(best.gy!=null?best.gy:this.G))<5);if(T('aggr')>.6&&bigIn)need=2;if(T('energy')>.6&&(h.en||0)-PS.en<(TB?TB.en:0))need=Math.max(need,4);
        if(best&&bn>=need&&spendEnergy(h,PS.en)){h.abWhy='PIERCE: '+bn+' in a line';h.abWhyT=this.t+3;h.psT=PS.cd*(1-(h.cdr||0));h.pshot={t:0,T:1.0,tg:best,shot:0};faceToward(h,best.x,1);return;}}}
    // ---- 0.12.178 Chibi_Sorcerer: Chain_Lightning and Thunderclap
    if(h.key==='csorc'){const AB=id=>(C.abilities||[]).find(a=>a.id===id);const CH=AB('chain'),TC=AB('thunder');for(const k of ['chT','tcT'])if(h[k]>0)h[k]-=dt;if(h.chT==null){h.chT=CH.cd*.3;h.tcT=TC.cd*.4;}
      const hx=this.heroX(h),gy=h.gy||this.G;
      if(h.cast){const K=h.cast;K.t+=dt;h.pauseT=Math.max(h.pauseT||0,.05);h.moving=false;if(!K.done&&K.t>=K.at){K.done=1;K.fn();}if(K.t>=K.T)h.cast=null;return;}
      const live=this.enemies.filter(e=>!e.dead&&!e.fly&&e.x>2&&e.x<this.W+2);const al=this.alive().filter(o=>o!==h);const T=k=>trait(h,k);
      /* 0.12.195 Static_Shield: Selfless shields an ally under 50% with 2+ on them first, then himself; Selfish himself first (under 60% and being hit);
           Panicky shields himself as soon as 2+ are on him; Preserve waits until someone is under 35%. */
      {const SS=AB('static'),OC=AB('overcharge');for(const k of ['ssT','ocT'])if(h[k]>0)h[k]-=dt;if(h.ssT==null){h.ssT=SS?SS.cd*.3:0;h.ocT=OC?OC.cd*.3:0;}
        if(SS&&h.ssT<=0&&(h.en||0)>=SS.en){const lim=T('energy')>.6?.35:.5;const onU=o=>live.filter(e=>Math.abs(e.x-this.heroX(o))<18&&Math.abs((e.gy!=null?e.gy:this.G)-(o.gy||this.G))<10).length;
          const ally=()=>al.filter(o=>!o.pet&&!(o.staticT>0)&&o.hp/o.max<lim&&onU(o)>=1&&Math.abs(this.heroX(o)-hx)<SS.r).sort((a,b)=>a.hp/a.max-b.hp/b.max)[0];
          const me=()=>!(h.staticT>0)&&((h.hp/h.max<(T('energy')>.6?.35:.6)&&onU(h)>=1)||(T('nerve')>.6&&onU(h)>=2))?h:null;
          const tgt=T('self')>.6?(me()||ally()):(ally()||me());
          if(tgt&&spendEnergy(h,SS.en)){h.ssT=SS.cd*(1-(h.cdr||0));tgt.shield=Math.max(tgt.shield||0,tgt.max*SS.shield);tgt.shieldT=SS.dur;tgt.staticT=SS.dur;tgt.staticZap=SS.zap;tgt.staticBy=h;tgt.staticMul=h.atk/h.base.atk;
            this.fx.push({k:'ring',x:this.heroX(tgt),y:(tgt.gy||this.G)-14,t:0,r:12,c:'#fff08a'});this.ev('zap',{});h.abWhy='STATIC SHIELD: '+(tgt===h?'myself':(heroDef(tgt.key)||{name:tgt.key}).name);h.abWhyT=this.t+3;
            h.cast={t:0,T:.5,at:.01,anim:'nova',fn:()=>{}};return;}}
        /* Overcharge: Squander whenever 2+ are in range; Preserve only for a big one or 4+; otherwise 3+ or a big one. Not while a charge is still loaded. */
        if(OC&&h.ocT<=0&&!(h.ocN>0)&&(h.en||0)>=OC.en){const inR=live.filter(e=>Math.abs(e.x-hx)<C.ranged.range);const big=inR.some(e=>e.boss||e.nem||e.max>=60);
          const go=T('energy')<.35?inR.length>=2:T('energy')>.6?(big||inR.length>=4):(big||inR.length>=3);
          if(go&&spendEnergy(h,OC.en)){h.ocT=OC.cd*(1-(h.cdr||0));h.ocN=OC.n;h.ocMul=OC.mul;h.ocJump=OC.jump;this.fx.push({k:'ring',x:hx,y:(h.gy||this.G)-16,t:0,r:10,c:'#ffe04a'});this.ev('zap',{});h.abWhy='OVERCHARGE: '+inR.length+' in range';h.abWhyT=this.t+3;}}}
      if(TC&&h.tcT<=0&&(h.en||0)>=TC.en){const inR=(a,b,R)=>{const dx=a.x-b.x,dz=((a.gy!=null?a.gy:this.G)-(b.gy!=null?b.gy:this.G))/.45;return dx*dx+dz*dz<=R*R;};let best=null,bs=0;
        for(const e of live){const d=Math.abs(e.x-hx);if(d<TC.min||d>TC.max)continue;const sp={x:e.x,gy:e.gy!=null?e.gy:this.G};const got=live.filter(o=>inR(o,sp,TC.r*.85));const sc=got.length+(got.some(o=>o.boss||o.nem||o.max>=60)?1:0);if(sc>bs){bs=sc;best=sp;}}
        /* 0.12.194: Blind Aggression or Squander calls it on 2 with a big one; Optimal waits for 4 while he's safe */
        let need=3;if((T('aggr')>.65||T('energy')<.35)&&live.some(o=>o.boss||o.nem||o.max>=60))need=2;if(T('exec')>.7&&h.hp/h.max>.6)need=Math.max(need,4);
        if(best&&bs>=need&&spendEnergy(h,TC.en)){h.abWhy='THUNDER: '+bs+' bunched';h.abWhyT=this.t+3;h.tcT=TC.cd*(1-(h.cdr||0));faceToward(h,best.x,1);const sp=best;Comms.bubble(this,h,Comms.pick(['Get down!','Here it comes.','Thunder!']),true);
          h.cast={t:0,T:1.0,at:TC.T,anim:'cast',fn:()=>{this.fx.push({k:'strike',x:sp.x,gy:sp.gy,t:0,life:.5,raw:1});this.fx.push({k:'ring',x:sp.x,y:sp.gy-2,t:0,r:TC.r,c:'#fff08a'});this.ev('zap',{});this.ev('boom',{});this.shake=Math.max(this.shake||0,.35);
            const dmg=this.rollDice(TC.dice)*(h.atk/h.base.atk);for(const e of this.enemies){if(e.dead||e.fly)continue;if(!inR(e,sp,TC.r))continue;this.hitEnemy(e,dmg,h,{blast:1,bx:sp.x,sure:1});if(!e.dead){e.stun=Math.max(e.stun||0,e.boss?TC.stun*.4:TC.stun);if(!e.boss)this.text(e.x,(e.gy!=null?e.gy:this.G)-26,'STUN','#ffe07a');}}}};return;}}
      if(CH&&h.chT<=0&&(h.en||0)>=CH.en){const near=live.filter(e=>Math.abs(e.x-hx)<CH.r).sort((a,b)=>Math.abs(a.x-hx)-Math.abs(b.x-hx));
        /* 0.12.194: Preserve keeps enough energy for Thunderclap when it's nearly ready and a crowd is building; Squander chains even a lone big one */
        const hold=T('energy')>.6&&TC&&h.tcT<4&&live.length>=3&&(h.en||0)-CH.en<TC.en;const ok=near.length>=2||(T('energy')<.35&&near.some(o=>o.boss||o.nem||o.max>=60));
        if(hold&&ok){h.abWhy='SAVING energy for Thunderclap';h.abWhyT=this.t+1;}
        if(ok&&!hold&&spendEnergy(h,CH.en)){h.abWhy='CHAIN: '+near.length+' close';h.abWhyT=this.t+3;h.chT=CH.cd*(1-(h.cdr||0));faceToward(h,near[0].x,1);
          h.cast={t:0,T:.75,at:.4,anim:'nova',fn:()=>{const hit=[];let cur=near[0];let m=1;const pts=[[this.heroX(h)+(h.face||1)*8,gy-14]];const base=this.rollDice(CH.dice)*(h.atk/h.base.atk);
            for(let i=0;i<CH.n&&cur;i++){hit.push(cur);const cg=cur.gy!=null?cur.gy:this.G;pts.push([cur.x,cg-12]);this.hitEnemy(cur,base*m,h,{sure:1});if(!cur.dead)cur.stun=Math.max(cur.stun||0,CH.stun);m*=1-CH.fall;
              const nx=this.enemies.filter(o=>!o.dead&&!o.fly&&!hit.includes(o)&&Math.abs(o.x-cur.x)<CH.jump&&Math.abs((o.gy!=null?o.gy:this.G)-cg)<14).sort((a,b)=>Math.abs(a.x-cur.x)-Math.abs(b.x-cur.x))[0];cur=nx;}
            this.fx.push({k:'bolt',pts,t:0,life:.3,raw:1,c:'y'});this.ev('zap',{});}};return;}}}
    // ---- 0.12.175 Soldier: Frag_Grenade. IF 3+ zombies are bunched 40-130 out (or 2 with a big one) AND no ally would be caught THEN pull the pin and lob it.
    if(h.key==='edward'){const AE=id=>(h.base.char.abilities||[]).find(a=>a.id===id);const TB=AE('toolbox'),PF=AE('friend'),NS=AE('nails'),CZ=AE('chutz');const T=k=>trait(h,k);const hx=this.heroX(h),gy=h.gy||this.G;
      for(const k of ['tbT','pfT','nsT','czT'])if(h[k]>0)h[k]-=dt;if(h.tbT==null){h.tbT=TB.cd*.3;h.pfT=PF.cd*.3;h.nsT=NS?NS.cd*.3:0;h.czT=CZ?CZ.cd*.3:0;}if(h.chutzT>0)h.chutzT-=dt;
      if(h.nstrip){const N=h.nstrip;N.t+=dt;h.pauseT=Math.max(h.pauseT||0,.05);h.moving=false;h.face=N.dir;if(N.t>=N.T)h.nstrip=null;return;}
      if(h.pfOn>0){h.pfOn-=dt;if(h.pfOn<=0){h.atk/=1+PF.dmg;h.aspd/=1+PF.spd;for(const o of this.heroes)if(o.pfAlly){o.atk/=1+o.pfAlly;o.pfAlly=0;}}}
      if(h.throwT>0)h.throwT-=dt;   /* 0.12.224 fix: his throw pose never counted down, so after a Toolbox_Toss he was stuck in it */
      if(h.tossA){const A=h.tossA;A.t+=dt;h.pauseT=Math.max(h.pauseT||0,.05);h.moving=false;if(A.t>=A.T){h.tossA=null;h.throwT=0;}return;}
      const live=this.enemies.filter(e=>!e.dead&&!e.fly&&e.x>2&&e.x<this.W+2);const al=this.alive().filter(o=>!o.pet);const lane=e=>e.gy!=null?e.gy:this.G;
      /* Power_of_Friendship: IF 2+ friends under 60%, or one under 35%, or 4+ zombies on the team THEN power up (Preserve waits for the worse case) */
      if(PF&&h.pfT<=0&&!(h.pfOn>0)&&(h.en||0)>=PF.en){const hurt=al.filter(o=>o.hp/o.max<.6).length,dire=al.some(o=>o.hp/o.max<.35),onTeam=live.filter(e=>al.some(o=>Math.abs(this.heroX(o)-e.x)<18&&Math.abs((o.gy||this.G)-lane(e))<8)).length;
        /* 0.12.244 (Kyle): more reasons to power up: a friend is down, a boss or Nemesis is within 600px, he's under 40% with 2+ on him, Chutzpah is drawing 3+ onto him,
           all three Dice Boys are in the banner, or a friend was just helped up */
        const down=this.heroes.some(o=>!o.pet&&!o.alive&&o.downed),big=this.enemies.some(e=>!e.dead&&(e.boss||e.nem)&&Math.abs(e.x-hx)<200),onMe=live.filter(e=>Math.abs(e.x-hx)<20).length,
          self=h.hp/h.max<.4&&onMe>=2,chz=h.chutzT>0&&onMe>=3,dice=!!(h.bnIn&&h.bnIn.all),up=al.some(o=>o!==h&&o.upT>0);
        h.pfWhy=null;
        if(h.cap&&h.cap.ed_nakama&&al.filter(o=>o!==h&&o.hp/o.max<.8).length>=2&&onTeam>=2)h.pfWhy='Nakama: the team needs it';
        const go=(h.cap&&h.cap.ed_nakama&&h.pfWhy==='Nakama: the team needs it')||T('energy')>.65?(dire&&hurt>=2)||onTeam>=6||down||big||dice:(hurt>=2||dire||onTeam>=4||down||big||self||chz||dice||up);
        if(go)h.pfWhy=down?'a friend is down':big?'big one here':dice?'DICE BOYS':self?'backs to the wall':chz?'Chutzpah crowd':up?'friend back up':dire?'friend in trouble':hurt>=2?'friends hurt':'mobbed';
        if(go&&spendEnergy(h,PF.en)){h.pfT=PF.cd*(1-(h.cdr||0));h.pfOn=PF.dur;h.atk*=1+PF.dmg;h.aspd*=1+PF.spd;for(const o of al)if(o!==h&&Math.abs(this.heroX(o)-hx)<PF.r){o.pfAlly=PF.ally;o.atk*=1+PF.ally;if(h.cap&&h.cap.ed_nakama)tbuff(o,{sp:.3},PF.dur);}
          if(h.cap&&h.cap.ed_nakama)for(const o of this.alive())if(!o.pet)this.healHero(o,o.max*.15,false,h);   /* 0.12.249 Nakama_Unleashed */
          this.fx.push({k:'ring',x:hx,y:gy-14,t:0,r:22,c:'#f0b429'},{k:'ring',x:hx,y:gy-14,t:0,r:34,c:'#fff3a0'});this.shake=Math.max(this.shake||0,.2);this.text(hx,gy-58,'POWER OF FRIENDSHIP!','#f0b429',true);
          Comms.bubble(this,h,Comms.pick(['This is the power of FRIENDSHIP!','You guys are my nakama!','I\'m not holding back anymore!','Believe in the me that believes in you!','Plot armor: ACTIVATED.','This isn\'t even my final form!']),true);h.abWhy='FRIENDSHIP: '+(h.pfWhy||'swarmed');h.abWhyT=this.t+3;return;}}
      /* Chutzpah: IF 3+ zombies are on his friends (not him), or a friend under 40% has one on them, AND he's above 45% (Selfish: above 70%)
         THEN he dares them all: everything within 300px comes for him for 3s */
      if(CZ&&h.czT<=0&&(h.en||0)>=CZ.en&&h.hp/h.max>(T('self')>.6?.7:.45)){const fr=al.filter(o=>o!==h);const onF=live.filter(e=>fr.some(o=>Math.abs(this.heroX(o)-e.x)<18&&Math.abs((o.gy||this.G)-lane(e))<8));
        const dire=fr.some(o=>o.hp/o.max<.4&&live.some(e=>Math.abs(this.heroX(o)-e.x)<18));const near=live.filter(e=>Math.abs(e.x-hx)<CZ.r).length;
        if((onF.length>=3||dire)&&near>=2&&spendEnergy(h,CZ.en)){h.czT=CZ.cd*(1-(h.cdr||0));h.chutzT=CZ.dur;h.czDR=CZ.dr;for(const e of live)if(Math.abs(e.x-hx)<CZ.r){e.tauntT=Math.max(e.tauntT||0,CZ.dur);e.tauntBy=h;e.target=h;e.plan=null;}
          this.text(hx,gy-56,'CHUTZPAH!','#ffa040',true);this.fx.push({k:'ring',x:hx,y:gy-14,t:0,r:26,c:'#ffa040'});h.abWhy='CHUTZPAH: '+(dire?'a friend is getting mauled':onF.length+' on my friends');h.abWhyT=this.t+3;
          Comms.bubble(this,h,Comms.pick(['You want some? Come get some, putz!','Hey! Over here, schmucks!','Oy! Pick on someone your own size!','That all you got? My bubbe hits harder!','Come on then, you meshuggeneh corpses!']),true);return;}}
      /* Nail_Strip: IF a lane ahead (within 300px) has 3+ zombies coming, or a fast one (Screamer, werewolf), THEN spray that lane
         (Blind Aggression goes at 2; Preserve wants 4) */
      if(NS&&h.nsT<=0&&(h.en||0)>=NS.en){let best=null,bn=0,fast=false;for(const L of [...new Set(live.map(lane))])for(const dir of [1,-1]){const inL=live.filter(e=>Math.abs(lane(e)-L)<7&&Math.sign(e.x-hx)===dir&&Math.abs(e.x-hx)<NS.range);const f=inL.some(e=>(e.E.spd||0)>=20);const sc=inL.length+(f?2:0);if(sc>bn){bn=sc;best={gy:L,dir};fast=f;}}
        const need=T('aggr')>.8?2:T('energy')>.65?4:3;
        if(best&&bn>=need&&spendEnergy(h,NS.en)){h.nsT=NS.cd*(1-(h.cdr||0));h.nstrip={t:0,T:NS.T,dir:best.dir};h.face=best.dir;h.abWhy='NAIL STRIP: '+(fast?'fast one coming':bn+' in a lane');h.abWhyT=this.t+3;
          const mul=(h.atk/h.base.atk)*h.rangedDmg;const x0=hx,x1=hx+best.dir*NS.range;
          for(const e of live){if(Math.abs(lane(e)-best.gy)>=7||Math.sign(e.x-hx)!==best.dir||Math.abs(e.x-hx)>=NS.range)continue;this.hitEnemy(e,this.rollDice(NS.dice)*mul,h,{sure:1});if(!e.dead&&!e.E.noBleed){e.bleedT=Math.max(e.bleedT||0,NS.bleed[1]);e.bleedDps=Math.max(e.bleedT>0?(e.bleedDps||0):0,NS.bleed[0]/NS.bleed[1]);}}
          (this.nailFields=this.nailFields||[]).push({x0:Math.min(x0,x1),x1:Math.max(x0,x1),gy:best.gy,t:NS.field,T:NS.field,slow:NS.slow,seed:Math.random()*99});
          for(let i=0;i<10;i++)this.fx.push({k:'tracer',x0:hx+best.dir*6,y0:gy-16,x1:hx+best.dir*(20+this.rng()*(NS.range-20)),y1:best.gy-2-this.rng()*6,t:0,c:'#c8ccd4'});
          this.ev('gun',{});Comms.bubble(this,h,Comms.pick(['Nail strip!','Watch your feet!','Spreading some hardware!','Whole box of nails, go!']),true);return;}}
      /* Toolbox_Toss: IF the biggest threat (Nemesis, boss, fireman, or the zombie on the most-hurt friend) is 40-140 out THEN heave the toolbox */
      if(TB&&h.tbT<=0&&(h.en||0)>=TB.en){const inR=e=>{const d=Math.abs(e.x-hx);return d>=TB.min&&d<=TB.max;};let tg=T('aware')>.6?null:live.filter(e=>inR(e)&&(e.nem||e.boss||e.type==='fireman'||(e.dmgDone||0)>=10)).sort((a,b)=>(b.dmgDone||0)-(a.dmgDone||0)||b.hp-a.hp)[0];   /* he keeps tabs on who's been hurting his friends (the casino files guy) */let why='big threat';
        if(!tg){const hurt=al.filter(o=>o!==h).sort((a,b)=>a.hp/a.max-b.hp/b.max)[0];if(hurt&&hurt.hp/hurt.max<.6){const ox=this.heroX(hurt);tg=live.filter(e=>inR(e)&&Math.abs(e.x-ox)<18).sort((a,b)=>Math.abs(a.x-ox)-Math.abs(b.x-ox))[0];why='on '+Comms.name(hurt);}}
        if(!tg)tg=live.filter(e=>inR(e)&&(e.nem||e.boss||e.type==='fireman'||(e.dmgDone||0)>=10)).sort((a,b)=>(b.dmgDone||0)-(a.dmgDone||0)||b.hp-a.hp)[0]||null;   /* Ally Awareness checks his friends first, then the big ones */
        if(!tg&&T('energy')<.35){tg=live.filter(inR).sort((a,b)=>b.hp-a.hp)[0];why='Squander';}
        if(tg&&spendEnergy(h,TB.en)){h.tbT=TB.cd*(1-(h.cdr||0));h.face=tg.x>=hx?1:-1;h.throwT=TB.throw;h.throwT0=TB.throw;h.tossA={t:0,T:TB.throw};h.abWhy='TOOLBOX: '+why;h.abWhyT=this.t+3;
          const x0=hx,g0=gy;this.fx.push({k:'toolbox',x0,gy0:g0,x1:tg.x,gy1:lane(tg),t:0,life:.55,raw:1,d:.25});
          const czM=h.chzStk?1+.1*h.chzStk:1;h.chzStk=0;setTimeoutSafe(this,.55,()=>{if(tg.dead){return;}const mul=(h.atk/h.base.atk)*czM;this.hitEnemy(tg,this.rollDice(TB.dice)*mul,h.alive?h:null,{sure:1});if(!tg.dead){tg.stun=Math.max(tg.stun||0,tg.boss?TB.stun*.4:TB.stun);this.text(tg.x,lane(tg)-28,'BONK','#f0b429');}
            for(const e of this.enemies){if(e.dead||e===tg||e.fly)continue;if(Math.abs(e.x-tg.x)<16&&Math.abs(lane(e)-lane(tg))<10)this.hitEnemy(e,this.rollDice(TB.splash)*mul,h.alive?h:null,{sure:1});}
            this.fx.push({k:'ring',x:tg.x,y:lane(tg)-12,t:0,r:12,c:'#f0b429'});this.ev('clunk',{});this.shake=Math.max(this.shake||0,.15);});
          if(this.rng()<.6)Comms.bubble(this,h,Comms.pick(['Catch!','Toolbox!','Measure twice, throw once!','Here, hold this.']),true);return;}}
    }
    if(h.key==='soldier'){
      /* 0.12.199 Suppressing_Fire and Smoke_Grenade
         SUPPRESS: IF a lane has 3+ zombies coming (4+ if Calculated) OR a fast one (Screamer, werewolf) is closing THEN hose that lane.
           Blind Aggression goes at 2. Preserve won't if it leaves him short of a Frag that's nearly ready.
         SMOKE: IF an ally under 40% has 2+ zombies on them THEN smoke them (Selfless always; Selfish only if it's himself first).
           Takes Cover also smokes when 3+ are on the team's front and nobody is hurt yet; Out In The Open only for the hurt. */
      {const C2=h.base.char;const SP=(C2.abilities||[]).find(a=>a.id==='suppress'),SG=(C2.abilities||[]).find(a=>a.id==='smokegren');const T=k=>trait(h,k);const hx=this.heroX(h),gy=h.gy||this.G;
        for(const k of ['spT','sgT'])if(h[k]>0)h[k]-=dt;if(h.spT==null){h.spT=SP?SP.cd*.3:0;h.sgT=SG?SG.cd*.3:0;}
        if(h.supp){const U=h.supp;U.t+=dt;h.pauseT=Math.max(h.pauseT||0,.05);h.moving=false;h.face=U.dir;const every=U.T/U.n;while(U.fired<U.n&&U.t>=U.fired*every){U.fired++;
            const fr=this.alive().filter(o=>o!==h&&!o.pet);const nearF=e=>fr.reduce((m,o)=>Math.min(m,Math.abs(this.heroX(o)-e.x)+Math.abs((o.gy||this.G)-(e.gy!=null?e.gy:this.G))*2),999);
            const tg=this.enemies.filter(e=>!e.dead&&!e.fly&&Math.abs((e.gy!=null?e.gy:this.G)-U.gy)<7&&Math.sign(e.x-hx)===U.dir&&Math.abs(e.x-hx)<SP.range).sort((a,b)=>nearF(a)-nearF(b))[0];
            if(tg){h._accBonus=SP.acc||0;const p=this.shoot(h,tg,'bullet',(this.rollDice(SP.dice)+(SP.flat||0))*(h.atk/h.base.atk)*h.rangedDmg,{onHit:(e,d)=>{this.hitEnemy(e,d,h,{});if(!e.dead){e.slow=Math.max(e.slow||0,SP.slow);e.slowT=Math.max(e.slowT||0,SP.slowT);}}});this.aim(p,h,tg);h._accBonus=0;}this.ev('gun',{});}
          if(U.t>=U.T)h.supp=null;return;}
        const live=this.enemies.filter(e=>!e.dead&&!e.fly&&e.x>2&&e.x<this.W+2);const al=this.alive().filter(o=>!o.pet);const lane=e=>e.gy!=null?e.gy:this.G;
        /* 0.12.200 Ammo_Drop: IF 2+ shooters near me are low (under half a mag) or reloading, or I am and a fight is on THEN drop a crate.
           Ally Awareness drops it in the middle of the shooters (stepping over a little); Enemy Awareness / Selfish drops it at his own feet.
           Preserve waits for 2+ shooters in need; Squander drops it for one. Never while one of his crates is still out. */
        {const AD=(C2.abilities||[]).find(a=>a.id==='ammodrop');if(h.adT>0)h.adT-=dt;if(h.adT==null)h.adT=AD?AD.cd*.3:0;
          if(AD&&h.adT<=0&&(h.en||0)>=AD.en&&live.length&&!(this.crates||[]).some(K=>K.owner===h)){const shooters=al.filter(o=>{const C3=o.base.char;return C3&&C3.ranged&&C3.ranged.clip>0&&Math.abs(this.heroX(o)-hx)<70;});
            const need=shooters.filter(o=>(o.ammo||0)<=o.base.char.ranged.clip*.5||o.reloadT>0);const want=T('energy')>.6?2:T('energy')<.35?1:(need.includes(h)?1:2);
            if(need.length>=want&&spendEnergy(h,AD.en)){h.adT=AD.cd*(1-(h.cdr||0));const mid=(T('aware')>.55&&T('self')<.6)?shooters.reduce((a,o)=>a+this.heroX(o),0)/shooters.length:hx;const cx=Math.max(10,Math.min(this.W-10,hx+Math.max(-20,Math.min(20,mid-hx))));
              (this.crates=this.crates||[]).push({x:cx,gy,laneI:h.laneI,t:0,A:AD,owner:h,taken:new Set()});h.cast={t:0,T:.7};h.reloadT=.01;h.pauseT=Math.max(h.pauseT||0,.7);h.moving=false;
              this.fx.push({k:'ring',x:cx,y:gy-2,t:0,r:AD.r,c:'#ffd27a'});Comms.bubble(this,h,Comms.pick(['Ammo down!','Grab a mag!','Reload here!']),true);h.abWhy='AMMO: '+need.length+' low on ammo';h.abWhyT=this.t+3;return;}}}
        if(h.cast){h.cast.t+=dt;h.pauseT=Math.max(h.pauseT||0,.05);h.moving=false;if(h.cast.t>=h.cast.T)h.cast=null;else return;}
        if(SG&&h.sgT<=0&&(h.en||0)>=SG.en){const onU=o=>live.filter(e=>Math.abs(e.x-this.heroX(o))<18&&Math.abs(lane(e)-(o.gy||this.G))<10).length;
          let tgt=null,why='';const downed=this.heroes.filter(o=>!o.pet&&!o.alive&&o.downed&&Math.abs(o.x-hx)<=SG.max&&o.x>8).sort((a,b)=>Math.abs(a.x-hx)-Math.abs(b.x-hx))[0];   /* 0.12.199 (Kyle): first choice: smoke a downed ally so the team can get them up unseen */
          const hurt=al.filter(o=>o.hp/o.max<.4&&onU(o)>=2&&Math.abs(this.heroX(o)-hx)<=SG.max);
          if(downed){tgt=downed;why='covering a downed ally';}else if(T('self')>.6){tgt=hurt.find(o=>o===h)||hurt[0];}else tgt=hurt.sort((a,b)=>a.hp/a.max-b.hp/b.max)[0];if(tgt&&!why)why=tgt===h?'covering myself':'covering a hurt ally';
          if(!tgt&&T('cover')>.6){const front=al.reduce((b,o)=>!b||this.heroX(o)>this.heroX(b)?o:b,null);if(front&&onU(front)>=3&&Math.abs(this.heroX(front)-hx)<=SG.max){tgt=front;why='taking cover';}}
          const tx0=tgt?(tgt.alive?this.heroX(tgt):tgt.x):0;if(tgt&&!(this.clouds||[]).some(S=>Math.abs(S.x-tx0)<S.r)&&spendEnergy(h,SG.en)){h.sgT=SG.cd*(1-(h.cdr||0));const spot=tx0+(tgt===h?0:3),sgy=tgt.gy||this.G;faceToward(h,spot,1);h.throwT=h.throwT0=.75;h.pauseT=Math.max(h.pauseT||0,.75);h.moving=false;
            Comms.bubble(this,h,Comms.pick(['Smoke out!','Popping smoke!','Covering you!']),true);h.abWhy='SMOKE: '+why;h.abWhyT=this.t+3;
            setTimeoutSafe(this,.42,()=>{if(!h.alive)return;this.ev('whoosh',{});(this.nades=this.nades||[]).push({x0:h.x,x:h.x,x1:spot,gy0:h.gy||this.G,gy:sgy,t:0,T:SG.throw,A:SG,src:h});});return;}}
        if(SP&&h.spT<=0&&(h.en||0)>=SP.en&&!(h.throwT>0)){const FG2=(C2.abilities||[]).find(a=>a.id==='frag');const short=T('energy')>.6&&FG2&&(h.fgT||0)<3&&(h.en||0)-SP.en<FG2.en;
          let best=null,bn=0,fast=false;for(const L of [...new Set(live.map(lane))]){for(const dir of [1,-1]){const inL=live.filter(e=>Math.abs(lane(e)-L)<7&&Math.sign(e.x-hx)===dir&&Math.abs(e.x-hx)<SP.range);const f=inL.some(e=>(e.E.spd||0)>=15);if(inL.length+(f?2:0)>bn){bn=inL.length+(f?2:0);best={gy:L,dir};fast=f;}}}
          const need=T('aggr')>.65?2:T('exec')>.7?4:3;
          if(best&&bn>=need&&!short&&spendEnergy(h,SP.en)){h.spT=SP.cd*(1-(h.cdr||0));h.supp={t:0,T:SP.T,n:SP.n,fired:0,gy:best.gy,dir:best.dir};h.face=best.dir;Comms.bubble(this,h,Comms.pick(['Covering you!','Keep their heads down!','I got your back!','Covering fire!']),true);h.abWhy='SUPPRESS: '+(fast?'fast one coming':bn+' in a lane');h.abWhyT=this.t+3;return;}}}
      const FG=(C.abilities||[]).find(a=>a.id==='frag');if(FG){if(h.fgT==null)h.fgT=FG.cd*.25;if(h.fgT>0)h.fgT-=dt;if(h.throwT>0){h.throwT-=dt;return;}
      if(h.fgT<=0&&(h.en||0)>=FG.en&&!(h.animM>0)){const hx=this.heroX(h),live=this.enemies.filter(e=>!e.dead&&!e.fly&&e.x<this.W+4&&e.x>4);const al=this.alive().filter(o=>o!==h);
        const inR=(a,b,R)=>{const dx=a.x-b.x,dz=((a.gy!=null?a.gy:this.G)-(b.gy!=null?b.gy:this.G))/.45;return dx*dx+dz*dz<=R*R;};let best=null,bs=0;
        /* 0.12.194 sliders: IF Blind Aggression OR I'm reloading OR (Panicky AND they're on top of me) THEN a pair (plus a big one) is enough
           ELSE IF Optimal AND I'm healthy THEN hold it for a real crowd (4). Selfless keeps a wider safety margin around allies, Selfish a tighter one.
           IF Pack Hunter AND an ally under 40% has 2+ on them (and isn't in the blast) THEN that's the throw. */
        const T=k=>trait(h,k);let need=3;const why=[];if(T('aggr')>.65){need--;why.push('aggressive');}else if(h.ammo<=0&&C.ranged&&C.ranged.clip>0){need--;why.push('reloading');}
        else if(T('nerve')>.6&&live.filter(e=>Math.abs(e.x-hx)<30).length>=2){need--;why.push('panicking');}
        if(T('exec')>.7&&h.hp/h.max>.6&&need>=3){need++;why.push('waiting for a crowd');}need=Math.max(2,need);const margin=FG.r*(.95+.4*(1-T('self')));
        let save=null;if(T('pack')<.45)for(const o of al){if(o.hp/o.max>=.4)continue;const ox=this.heroX(o);const on=live.filter(e=>Math.abs(e.x-ox)<16);if(on.length>=2){const c=on.reduce((a,e)=>a+e.x,0)/on.length;const sp={x:c+Math.sign(c-ox||1)*12,gy:on[0].gy!=null?on[0].gy:this.G};if(Math.abs(sp.x-hx)>=FG.min&&Math.abs(sp.x-hx)<=FG.max&&!al.some(a=>inR({x:this.heroX(a),gy:a.gy||this.G},sp,margin))){save=sp;break;}}}
        for(const e of live){const d=Math.abs(e.x-hx);if(d<FG.min||d>FG.max)continue;const sp={x:e.x,gy:e.gy!=null?e.gy:this.G};
          if(al.some(o=>inR({x:this.heroX(o),gy:o.gy||this.G},sp,margin)))continue;
          const got=live.filter(o=>inR(o,sp,FG.r*.85));const big=got.some(o=>o.boss||o.nem||o.max>=60);const sc=got.length+(big?1:0);if(sc>bs){bs=sc;best=sp;}}
        if(save&&bs<need){best=save;bs=need;why.push('saving an ally');}
        if(best&&bs>=need&&spendEnergy(h,FG.en)){h.abWhy='FRAG: '+(why.join(', ')||bs+' bunched');h.abWhyT=this.t+3;h.fgT=FG.cd*(1-(h.cdr||0));h.throwT=h.throwT0=.75;faceToward(h,best.x,1);h.pauseT=Math.max(h.pauseT||0,.75);h.moving=false;
          Comms.bubble(this,h,Comms.pick(['Frag out!','Grenade!','Fire in the hole!','Frag, get down!']),true);const sp=best;
          setTimeoutSafe(this,.42,()=>{if(!h.alive)return;const x0=this.heroX(h)+(h.face||1)*4;(this.bomblets=this.bomblets||[]).push({x0,gy0:h.gy||this.G,x1:sp.x,gy1:sp.gy,t:0,H:16+Math.abs(sp.x-x0)*.12,T:FG.fly,fuse:-1,fz:FG.fuse,spin:0,R:FG.r,dmg:this.rollDice(FG.dice)*(h.atk/h.base.atk),stun:FG.stun,owner:h,frag:1});this.ev('whoosh',{});});return;}}}}
    if(h.key==='eng'){const EB=id=>(C.abilities||[]).find(a=>a.id===id);const BU=EB('build'),RP=EB('repair'),MO=EB('modify'),SC=EB('satchel');
      const working=!!(h.building||h.repairing);
      if(!working){for(const k of ['twT','brT2','tsT','moT','scT'])if(h[k]>0)h[k]-=dt;}
      if(h.twT==null){h.twT=2;h.brT2=4;h.tsT=6;h.moT=3;h.scT=SC.cd*.3;}
      const hx=this.heroX(h),gy=h.gy||this.G,live=this.enemies.filter(e=>!e.dead&&e.x<this.W+4);const near=r=>live.filter(e=>!e.fly&&Math.abs(e.x-hx)<r).length;
      const B=this.blds=this.blds||[];const tower=B.find(b=>b.k==='tower'&&b.hp>0&&b.owner===h);
      // satchel: IF one of mine is out AND 3+ zombies (or a big one) are on it THEN set it off
      for(const S of this.satchels||[]){if(S.owner!==h||S.boom||S.t<S.T)continue;const on=live.filter(e=>!e.fly&&Math.abs(e.x-S.x)<S.A.r*.6&&Math.abs((e.gy!=null?e.gy:this.G)-S.gy)<12);
        if(on.length>=3||on.some(e=>e.boss||e.elite||e.max>=60)||(S.t>6&&on.length>=2)||(S.t>12&&on.length>=1)){this.satchelBoom(S);Comms.bubble(this,h,Comms.pick(['Fire in the hole!','Clacker time.','Boom.','Cover your ears!']),true);}}
      // in-progress work
      if(h.building&&h.walkTo!=null){{const sc=this.scroll||0;h.walkTo-=sc*dt;h.building.x-=sc*dt;}   /* 0.12.166: the build spot is on the ground, so it slides with the world */const d=h.walkTo-hx;h.building.wt=(h.building.wt||0)+dt;if(h.building.wt>4){h.building.x=hx;h.walkTo=null;}else if(Math.abs(d)>6&&onMeE(this,h)<2){h.x+=Math.sign(d)*Math.min(Math.abs(d),(MOVE.eng||15)*dt*1.4);h.face=d>0?1:-1;h.moving=true;h.walkT=(h.walkT||0)+dt;return;}h.walkTo=null;}
      if(h.building){const W=h.building;W.t+=dt;{const sc=this.scroll||0;if(W.ax==null)W.ax=h.x;W.ax-=sc*dt;W.x-=sc*dt;h.x=W.ax;h.dodgeX=0;h.wanderX=0;h.kbv=0;h.dodge=null;}   /* 0.12.167 (Kyle): locked to his spot: no walking, shoves, dodges or drift until it's done */   /* 0.12.166 (Kyle): kneeling on the ground, he slides back with the world instead of gliding along it */h.pauseT=Math.max(h.pauseT||0,.05);h.moving=false;if(Math.random()<dt*6)this.fx.push({k:'spark',x:W.x+(Math.random()-.5)*10,gy:W.gy,t:0,life:.35,raw:1});
        if(W.t>=W.T){h.building=null;this.finishBuild(h,W);}return;}
      if(h.repairing){const R=h.repairing,T=R.tgt;R.t+=dt;if(T&&T.bld)h.x-=(this.scroll||0)*dt;   /* 0.12.166: stays with the building he's fixing */h.pauseT=Math.max(h.pauseT||0,.05);h.moving=false;
        const done=!T||(T.bld?(T.hp<=0||T.hp>=T.max):(!T.alive||T.hp>=T.max))||Math.abs((T.bld?T.x:this.heroX(T))-hx)>30||onMeE(this,h)>=2||R.t>6;
        if(done){h.repairing=null;}else{if(T.bld){const b0=T.hp;T.hp=Math.min(T.max,T.hp+RP.bld*dt);this.supXp(h,(T.hp-b0)*.036);}else{this._mech=1;this.healHero(T,T.max*RP.mech*dt,true,h);this._mech=0;}if(Math.random()<dt*8)this.fx.push({k:'spark',x:(T.bld?T.x:this.heroX(T))+(Math.random()-.5)*8,gy:T.gy||this.G,t:0,life:.3,raw:1});return;}}
      const safe=near(40)===0&&!this.heroes.some(o=>!o.alive&&o.downed),en=h.en||0;   // a friend down comes first: no building until they're up
      // IF there's a fight AND no tower of mine AND it's quiet right here THEN put a watchtower up a little behind me
      if(!h.perch&&BU&&!tower&&h.twT<=0&&en>=BU.en&&(safe||near(25)<=1)&&live.length>=1&&spendEnergy(h,BU.en))   /* 0.12.95: builds more eagerly (one zombie close by is OK, any fight counts) */{h.twT=BU.tower.cd*(1-(h.cdr||0));h.building={k:'tower',tier:1,t:0,T:BU.tower.T[0],x:Math.max(20,Math.min(this.W-40,hx+45)),gy};   /* 0.12.76: well up the road so the team doesn't walk past it right away */h.walkTo=h.building.x;Comms.bubble(this,h,Comms.pick(['Putting up a tower.','Give me three seconds.','Cover me, building!']));return;}
      // IF my tower can go higher AND it's quiet AND Modify is ready THEN add a tier
      if(!h.perch&&MO&&tower&&tower.tier<3&&h.moT<=0&&en>=MO.en&&(safe||near(25)<=1)&&Math.abs(tower.x-hx)<60&&spendEnergy(h,MO.en)){h.moT=MO.cd*(1-(h.cdr||0))*(1-(MO.towerBack||0));h.building={k:'tier',tgt:tower,t:0,T:BU.tower.T[tower.tier],x:tower.x,gy:tower.gy};return;}
      // IF a pack of 3+ is coming down one lane 30-120 out THEN drop a concrete barrier in front of them
      if(BU&&h.brT2<=0&&en>=BU.en){let bl=null,bn=0;for(const l of LANES){const n=live.filter(e=>!e.fly&&!e.boss&&Math.abs((e.gy!=null?e.gy:this.G)-l)<=BU.barrier.depth&&e.x-hx>30&&e.x-hx<120).length;if(n>bn){bn=n;bl=l;}}
        if(bl!=null&&bn>=3&&!B.some(b=>b.k==='barrier'&&b.hp>0&&Math.abs(b.gy-bl)<6&&b.x>hx)&&spendEnergy(h,BU.en)){h.brT2=BU.barrier.cd*(1-(h.cdr||0));h.building={k:'barrier',t:0,T:BU.barrier.T,x:Math.min(this.W-20,hx+24),gy:bl};Comms.bubble(this,h,Comms.pick(['HESCO going up!','Wall them off!','Filling a HESCO!']));return;}}
      // IF 2+ zombies are within ~300 screen px THEN plant a tesla coil a little ahead
      if(!h.perch&&BU&&h.tsT<=0&&en>=BU.en&&near(100)>=2&&near(20)===0&&spendEnergy(h,BU.en)){h.tsT=BU.tesla.cd*(1-(h.cdr||0));h.building={k:'tesla',t:0,T:BU.tesla.T,x:Math.min(this.W-20,hx+16),gy};return;}
      // IF a wreck is right here with no turret AND it's quiet THEN bolt a turret onto it
      if(!h.perch&&MO&&h.moT<=0&&en>=MO.en&&safe){const car=(this.obst||[]).find(o=>/^car_/.test(o.k)&&!o.turret&&Math.abs(o.x-hx)<35&&o.x>20&&o.x<this.W-20);if(car&&spendEnergy(h,MO.en)){h.moT=MO.cd*(1-(h.cdr||0));h.building={k:'turret',car,t:0,T:MO.turret.T,x:car.x,gy:LANES[Math.max(...car.lanes)]};Comms.bubble(this,h,Comms.pick(['Let me mount something on this.','This wreck needs a gun.']));return;}}
      // Repair: IF a building of mine (or the Warhound) is hurt AND I'm beside it AND it's quiet THEN fix it
      if(!h.perch&&RP&&safe)   /* 0.12.264 (Kyle): up on the tower he stays up and shoots; no building, upgrading or repairing from up there */{const T=B.filter(b=>b.hp>0&&b.hp<b.max*.75&&Math.abs(b.x-hx)<28).sort((p,q)=>p.hp/p.max-q.hp/q.max)[0]||this.alive().find(o=>o.key==='robot'&&o.hp<o.max*.6&&Math.abs(this.heroX(o)-hx)<24);if(T){h.repairing={tgt:T,t:0};return;}}
      // satchel: IF 3+ zombies are bunched 30-100 out THEN toss one onto them (he sets it off later)
      if(SC&&h.scT<=0&&en>=SC.en&&!(this.satchels||[]).some(S=>S.owner===h&&!S.boom)){let best=null,bn=0;for(const e of live){const d=e.x-hx;if(e.fly||d<SC.min||d>SC.max)continue;const n=live.filter(o=>Math.abs(o.x-e.x)<20).length;if(n>bn){bn=n;best=e;}}
        if(!(best&&bn>=3)){const big=live.filter(e=>!e.fly&&e.x-hx>=SC.min&&e.x-hx<=SC.max+40&&(e.boss||e.elite||e.max>=60)).sort((p,q)=>q.max-p.max)[0];if(big){best=big;bn=3;}else if(best&&bn>=2&&live.length>=4){bn=3;}}   /* 0.12.79: bosses/big ones, or a pair when the field is busy */
        if(best&&bn>=3&&spendEnergy(h,SC.en)){h.scT=SC.cd*(1-(h.cdr||0));h.animM=.45;h.face=1;(this.satchels=this.satchels||[]).push({x0:hx+3,x:hx,x1:best.x-6,gy0:gy,gy:best.gy!=null?best.gy:gy,gy1:best.gy!=null?best.gy:gy,t:0,T:SC.fly,A:SC,owner:h});this.ev('whoosh',{});return;}}}
    // ---- 0.12.70 Void_Cultist (Kyle's rework): life costs, all IF/THEN on the field; runs before the attack so Lethal_Strikes works up close
    if(h.key==='cultist'){const CB=id=>(C.abilities||[]).find(a=>a.id===id);const SY=CB('syphon'),LS=CB('lethal'),TN=CB('tentacle'),CT=CB('cthulhu');
      for(const [A,k] of [[SY,'syT'],[LS,'leT'],[TN,'tnT'],[CT,'ctT']])if(A){if(h[k]==null)h[k]=A.cd*.25;if(h[k]>0)h[k]-=dt*(k==='tnT'&&h.cthT>0?2:1);}
      if(h.lethalT>0)h.lethalT-=dt;if(h.cthT>0)h.cthT-=dt;
      if(h.summonT>0){h.summonT-=dt;h.pauseT=Math.max(h.pauseT||0,.05);return;}
      const live=this.enemies.filter(e=>!e.dead&&e.x<this.W+4),hx=this.heroX(h),hp=h.hp/h.max,afford=A=>A&&hp-A.hpCost>=.35;
      // Syphon_Life in progress: stand and drain
      if(h.syph){const S=h.syph,T=S.tg;S.t+=dt;S.acc+=dt;h.pauseT=Math.max(h.pauseT||0,.05);h.moving=false;if(T)h.face=T.x>=h.x?1:-1;
        if(!T||T.dead||Math.abs(T.x-hx)>SY.range*1.15||S.t>=SY.dur){h.syph=null;}
        else{while(S.acc>=.25){S.acc-=.25;const d=this.hitEnemy(T,SY.dps*.25*(h.atk/h.base.atk)*h.rangedDmg*(h.cryDmg||1),h,{sure:1,nocrit:1,quiet:1});if(d)this.healHero(h,d*SY.heal,true,h);}return;}}
      // IF Call_of_Cthulhu is ready AND (2+ tentacles are up OR 4+ zombies are coming) AND I can afford it THEN call
      const tents=(this.tentacles||[]).filter(T=>T.src===h&&T.anim!=='death');
      if(CT&&h.ctT<=0&&afford(CT)&&(tents.length>=2||live.filter(e=>e.x-hx<160).length>=4)&&this.payLife(h,CT.hpCost)){h.ctT=CT.cd*(1-(h.cdr||0));h.cthT=CT.dur;h.summonT=CT.cast;h.summonT0=CT.cast;
        Comms.bubble(this,h,Comms.pick(['Ph\'nglui mglw\'nafh!','HE WAKES!','Cthulhu fhtagn!','The deep calls you home!']),true);this.ev('wind',{});this.shake=Math.max(this.shake||0,.35);
        setTimeoutSafe(this,CT.cast*.7,()=>{if(!h.alive)return;const d=h.face||1,cx=this.heroX(h)+d*CT.move,ts=(this.tentacles||[]).filter(T=>T.src===h&&T.anim!=='death');
          ts.forEach((T,i)=>{this.fx.push({k:'burrow',x:T.x,gy:T.gy,t:0,life:.5,raw:1});T.x=Math.max(8,Math.min(this.W-8,cx+(i-(ts.length-1)/2)*16));T.gy=LANES[Math.max(0,Math.min(LANES.length-1,(h.laneI||2)+((i%3)-1)))]||T.gy;T.anim='emerge';T.aT=0;});
          for(const o of [{x:this.heroX(h),gy:h.gy||this.G}].concat(ts.map(T=>({x:T.x,gy:T.gy})))){this.fx.push({k:'dread',x:o.x,gy:o.gy,t:0,life:.8,raw:1,r:CT.r});
            for(const e of this.enemies){if(e.dead||e.boss)continue;if(Math.abs(e.x-o.x)<CT.r&&Math.abs((e.gy||this.G)-o.gy)<16){e.retreatT=Math.max(e.retreatT||0,CT.fear);e.fearT=CT.fear;e.slow=Math.max(e.slow||0,CT.slow);e.slowT=Math.max(e.slowT||0,CT.fear);}}}});
        return;}
      // IF zombies are bunched within 133 world AND I can afford it THEN Spawn_Tentacle in the middle of the biggest pack
      if(TN&&h.tnT<=0&&afford(TN)){const near=live.filter(e=>!e.fly&&Math.abs(e.x-hx)<=TN.range);let best=null,bn=0;for(const e of near){const n=near.filter(o=>Math.abs(o.x-e.x)<30).length+(e.boss?2:0);if(n>bn){bn=n;best=e;}}
        if(best&&(bn>=2||best.boss||best.max>=this.bb.maxE*.8)&&this.payLife(h,TN.hpCost)){h.tnT=TN.cd*(1-(h.cdr||0));h.summonT=TN.cast;h.summonT0=TN.cast;
          const pack=near.filter(o=>Math.abs(o.x-best.x)<30),tx=Math.max(8,Math.min(this.W-8,pack.reduce((a,o)=>a+o.x,0)/pack.length)),gy=best.gy!=null?best.gy:(h.gy||this.G);const mul=(h.atk/h.base.atk)*h.rangedDmg*(h.cryDmg||1);
          setTimeoutSafe(this,TN.cast*.7,()=>{if(!h.alive)return;(this.tentacles=this.tentacles||[]).push({x:tx,gy,t:0,life:TN.life,A:TN,src:h,mul,atkT:.6,anim:'emerge',aT:0,face:1,hp:TN.hp,max:TN.hp,swatT:0});this.ev('thorns',{});this.shake=Math.max(this.shake||0,.25);});
          Comms.say(this,h,'tentacle',{});return;}}
      // IF a zombie is in dagger range AND Lethal_Strikes is ready AND I can afford it THEN frenzy
      if(LS&&h.leT<=0&&afford(LS)&&live.some(e=>!e.fly&&Math.abs(e.x-hx)<26&&Math.abs((e.gy!=null?e.gy:this.G)-(h.gy||this.G))<4)&&this.payLife(h,LS.hpCost)){h.leT=LS.cd*(1-(h.cdr||0));h.lethalT=LS.dur;addMood(h,{range:10},LS.dur,'lethal');
        this.fx.push({k:'ring',x:h.x,y:(h.gy||this.G)-10,r:16,t:0,c:'#6aff4a'});Comms.bubble(this,h,Comms.pick(['Bleed for me!','Steel and venom!','Dance, little corpses!']));}
      // IF an enemy is in syphon range AND (I'm hurt OR nothing is on me) THEN drain it (free)
      if(SY&&h.syT<=0&&!h.syph&&(h.en||0)>=(SY.en||0)){const T=live.filter(e=>Math.abs(e.x-hx)<=SY.range&&e.x>-4).sort((p,q)=>(hp<.6?Math.abs(p.x-hx)-Math.abs(q.x-hx):q.hp-p.hp))[0];const onMe=live.some(e=>!e.fly&&Math.abs(e.x-hx)<16);
        if(T&&(hp<.9||!onMe)&&spendEnergy(h,SY.en||0)){h.syT=SY.cd*(1-(h.cdr||0));h.syph={t:0,acc:0,tg:T};unstealth(h);this.ev('zap',{});return;}}}
    const mt=this.enemies.filter(e=>!e.dead&&!e.fly&&(e.boss?e.x-e.w-h.x<=reachPx&&e.x>h.x-4:Math.abs(e.x-this.heroX(h))<=reachPx&&(e.gy==null||Math.abs(e.gy-h.gy)<2.5))).sort((p,q)=>Math.abs(p.x-h.x)-Math.abs(q.x-h.x))[0];
    // ---- Wave Dash in progress: slide forward along the lane, cutting everything in the line once
    if(h.dash){const D=h.dash;D.t+=dt;const k=Math.min(1,D.t/D.T);const nx=D.x0+(D.x1-D.x0)*(1-(1-k)*(1-k));const px=h.x;h.x=nx;h.pauseT=Math.max(h.pauseT||0,.05);
      D.trail.push(nx);if(D.trail.length>7)D.trail.shift();
      this.ffArea(h,(px+nx)/2+12,h.gy,(nx-px)/2+14,D.A.depth,D.dmg,D);
      for(const e of this.enemies){if(e.dead||e.fly||D.hit.has(e))continue;const dz=Math.abs((e.gy!=null?e.gy:this.G)-h.gy);
        if(dz<=D.A.depth&&e.x>=px+6&&e.x<=nx+25){/* hit zone = the wave's front crescent, sweeping along with him */D.hit.add(e);const dd=this.hitEnemy(e,D.dmg,h,{});
          if(dd&&!e.dead){e.kbv=Math.max(e.kbv||0,D.A.kb/100*40*8*(1-((e.E&&e.E.kbRes)||0)));e.kbDir=1;}this.fx.push({k:'slash',x:e.x-6,y:e.y-24,t:0});}}
      if(k>=1)h.dash=null;return;}
    const DA=(C.abilities||[]).find(a=>a.id==='dash'),SA=(C.abilities||[]).find(a=>a.id==='shout');
    if(DA){if(h.daT==null)h.daT=DA.cd*.3;if(h.daT>0)h.daT-=dt;}if(SA){if(h.shT==null)h.shT=0;if(h.shT>0)h.shT-=dt;}
    // IF War Cry is ready AND a fight is close AND I'm not already fired up THEN shout
    if(SA&&h.shT<=0&&!(h.shoutT>.5)&&(h.en||0)>=SA.en&&this.enemies.some(e=>!e.dead&&Math.abs(e.x-h.x)<150)&&spendEnergy(h,SA.en)){
      h.shT=SA.cd*(1-(h.cdr||0));for(const o of this.alive())if(Math.abs(this.heroX(o)-this.heroX(h))<=SA.range){o.shoutT=SA.dur;o.shoutB={dmg:SA.dmg,spd:SA.spd};o.buffT=Math.max(o.buffT||0,SA.dur);}
      this.fx.push({k:'ring',x:h.x,y:this.G-14,r:46,t:0,c:'#ffd23f'});this.ev('shout',{});}
    // IF Wave Dash is ready AND an enemy is in my lane a short way ahead (not in my face) THEN dash through the line
    if(DA&&h.daT<=0&&(h.en||0)>=DA.en*(1+.3*trait(h,'energy')-.15)){
      const inPath=this.enemies.filter(e=>!e.dead&&!e.fly&&Math.abs((e.gy!=null?e.gy:this.G)-h.gy)<=DA.depth&&e.x-h.x>14&&e.x-h.x<Math.min(DA.dist,this.W-h.x));
      // IF at least 2 enemies are in the wave's path (or 1 if it's the last one around) THEN ride the wave through them
      if((inPath.length>=DA.minHits||(inPath.length&&this.enemies.filter(e=>!e.dead).length===1))&&spendEnergy(h,DA.en)){h.daT=DA.cd*(1-(h.cdr||0));h.face=1;
        const dmg=(this.rollDice(C.melee.dice)+(C.melee.flat||0)+(h.flatMelee||0))*(C.melee.dmgMul||1)*(h.atk/h.base.atk)*h.meleeDmg*(h.cryDmg||1);   /* 0.12.61 (Kyle): base = a plain sword hit (no 1.4x); buffs like War Cry and crits still apply */
        h.dash={t:0,T:DA.dur,x0:h.x,x1:Math.min(this.W-12,h.x+DA.dist),hit:new Set(),dmg:dmg*(DA.dmgMul||1),A:DA,trail:[]};this.ev('dash',{});return;}}
    const tgt=mt||(C.ranged?(this.isMeleeHero(h)?(findT('melee'),findT('ranged')):findT('ranged')):(findT('melee'),null));const rd=faceToward(h,tgt?tgt.x:h.x+10,dt);if(!rd||!tgt)return;
    if(mt&&C.melee.flame){if(h.mT>=C.melee.every){h.mT=0;h.animM=.45;h.swingAnim=null;h.animT=0;unstealth(h);this.flameSpray(h,mt,C.melee.flame);}return;}   /* 0.12.67 Warhound: the flamethrower is his close-range attack */
    if(mt){if(h.mT>=C.melee.every){h.mT=0;unstealth(h);h.combo=(h.combo||0)+1;h.swingAnim=!C.combo?null:(h.moving?'runatk':(h.combo%2?'attack1':'attack2'));h.animM=h.swingAnim==='attack2'?.36:.45;h.animT=0;const roll=(this.rollDice(C.melee.dice)+(C.melee.flat||0)+(h.flatMelee||0))*(C.melee.dmgMul||1)*(h.atk/h.base.atk)*h.meleeDmg*(h.cryDmg||1);
        if(C.melee.arc)this.fx.push({k:'arc',x:h.x,gy:h.gy||this.G,dir:mt.x>=h.x?1:-1,t:0,life:.3,raw:1,big:h.surgeT>0});
        if(C.melee.claw)this.fx.push({k:'claw',x:h.x+(mt.x>=h.x?6:-6),gy:h.gy||this.G,tx:mt.x,dir:mt.x>=h.x?1:-1,t:0,life:.42,raw:1});
        setTimeoutSafe(this,C.melee.hitAt||.15,()=>{if(!h.alive||mt.dead)return;   // the blow lands a moment into the swing (Kyle: very slight delay)
        const K=Math.min(100,C.melee.kb+(h.kbAdd||0));const RY=(C.abilities||[]).find(a=>a.id==='rhythm');let fell=0;if(RY){h.rhyN=(this.t-(h.rhyT==null?-99:h.rhyT)<=RY.window)?(h.rhyN||0)+1:1;h.rhyT=this.t;if(h.rhyN>=RY.n){h.rhyN=0;fell=1;}}   /* 0.12.69 Feller's_Rhythm */
        const LT=h.lethalT>0?(C.abilities||[]).find(a=>a.id==='lethal'):null;const dealt=this.hitEnemy(mt,roll*(fell?1+RY.bonus:1)*(LT?1-LT.dmg:1),h,{});if(dealt&&!mt.dead&&!mt.boss&&C.melee.stunCh&&this.rng()<C.melee.stunCh){mt.stun=Math.max(mt.stun||0,C.melee.stun);this.text(mt.x,mt.y-30,'CLANG','#d8dce8');}
        {const RH=(C.abilities||[]).find(a=>a.id==='blade'&&a.cut);if(RH&&dealt&&mt.dead&&h.tnT>0){h.tnT=Math.max(0,h.tnT-RH.cut);this.text(h.x,this.G-58,'-'+RH.cut+'s','#b070ff');}}   /* 0.12.97 Ritual_Harvest */
        {const PBd=(C.abilities||[]).find(a=>a.id==='blade');if(PBd&&!mt.dead){if(mt.poison>0)mt.poisonT=POISON.dur;if(dealt&&this.rng()<PBd.ch*(LT?2:1))this.addPoison(mt,PBd.n*(LT?2:1));}}   /* 0.12.70 Poisoned_Blade */if(fell&&!mt.dead){if(!mt.boss)mt.stun=Math.max(mt.stun||0,RY.stun);this.text(mt.x,mt.y-34,'TIMBER!','#ffc860');this.shake=Math.max(this.shake||0,.12);}
        {const MO=(C.abilities||[]).find(a=>a.id==='momentum');if(MO){h.mom=this.t-(h.momT||0)<=MO.window?Math.min(MO.max,(h.mom||0)+1):1;h.momT=this.t;h.momPer=MO.per;}}   // Momentum
        h._mt=mt;   /* 0.12.107: the Shadow_Clone no longer mirrors his hits from behind him; it peels off and swings on its own (stepClones) */   // knockback, Kyle's scale: 0-100, 100 = about a 40px shove
        if(dealt&&!mt.dead&&K>0){const res=mt.boss?.9:((mt.E&&mt.E.kbRes)||0);mt.kbv=Math.max(mt.kbv||0,K/100*40*8*(1-res));mt.kbDir=mt.x>=h.x?1:-1;}   
        if(h.surgeT>0&&!mt.dead)this.arcChain(h,mt);
        if(!C.melee.claw&&!C.melee.arc)this.fx.push({k:'slash',x:mt.x-6,y:mt.boss?mt.y-50:mt.y-24,t:0});});}return;}
    const AB=(C.abilities||[]).find(a=>a.id==='aimed');h.sigT=Math.max(0,(h.abT==null?(h.abT=AB?AB.cd*.4:0):h.abT));if(AB&&h.abT>0)h.abT-=dt;
    // ---- Set_Camp (Flannel_Man)
    const GR=(C.abilities||[]).find(a=>a.id==='grit');if(GR){if(h.grT==null)h.grT=GR.cd*.2;if(h.grT>0)h.grT-=dt;if(h.gritT>0)h.gritT-=dt;
      const close=this.enemies.filter(e=>!e.dead&&!e.fly&&Math.abs(e.x-h.x)<45).length,hf=h.hp/h.max,onMe=(this.bb&&this.bb.heat.get(h))||0;
      if(h.grT<=0&&!(h.gritT>0)&&!h.camping&&(h.en||0)>=GR.en&&((hf<GR.under&&(close>=1||onMe>=1))||close>=3)&&spendEnergy(h,GR.en)){
        h.grT=GR.cd*(1-(h.cdr||0));h.gritT=GR.dur;h.gritDR=GR.dr;h.gritMv=GR.move||0;addMood(h,{range:10,aggr:10},GR.dur,'grit');h.thinkT=0;
        this.fx.push({k:'ring',x:h.x,y:this.G-14,r:30,t:0,c:'#e0b060'});this.ev('shout',{});Comms.say(this,h,'tank',{ally:h},trait(h,'talk')>.2);}}
    const CA=(C.abilities||[]).find(a=>a.id==='camp');if(CA){if(h.caT==null)h.caT=CA.cd*.1;if(h.caT>0)h.caT-=dt;
      if(h.camping){h.camping-=dt;h.pauseT=Math.max(h.pauseT||0,.05);if(h.camping<=0){h.camping=0;
          this.camp={x:h.x+(h.face<0?-11:11),gy:h.gy,life:CA.life,t:0,A:CA,owner:h,state:'start'};Comms.onCamp(this,h,this.camp.x);this.ev('camp',{});}
        return;}
      // IF there's no fire going AND nothing is right on top of us AND Set_Camp is ready THEN kneel and light one
      const close=this.enemies.some(e=>!e.dead&&Math.abs(e.x-h.x)<70);
      if(h.caT<=0&&!mt&&!close&&!(this.camp&&this.camp.state!=='dead')&&(h.en||0)>=CA.en&&spendEnergy(h,CA.en)){h.caT=CA.cd*(1-(h.cdr||0));h.camping=CA.cast;h.campT0=CA.cast;return;}}
    // ---- SHOSHI (0.12.110)
    if(h.key==='shoshi'){const AS=id=>(C.abilities||[]).find(a=>a.id===id);const RB=AS('reboot'),FT=AS('trial'),DM=AS('dad'),RM=AS('online'),UZ=AS('undo');
      for(const [A,k] of [[RB,'rbT'],[FT,'frT'],[DM,'ddT'],[UZ,'unT']])if(A){if(h[k]==null)h[k]=A.cd*.3;if(h[k]>0)h[k]-=dt;}
      if(h.dadT>0)h.dadT-=dt;
      const hx=this.heroX(h),al=this.alive().filter(o=>o!==h&&!o.pet);const near=(o,r)=>Math.abs(this.heroX(o)-hx)<Math.max(r,150);   /* 0.12.138 (Kyle: barely saw him cast): his abilities reach ~150 px, any lane */
      const foesOn=o=>this.enemies.filter(e=>!e.dead&&!e.fly&&Math.abs(e.x-this.heroX(o))<20).length;
      const cdsOf=o=>((o.base&&o.base.char&&o.base.char.abilities)||[]).filter(a=>!a.passive&&CD_KEY[a.id]&&o[CD_KEY[a.id]]>.5).map(a=>CD_KEY[a.id]);
      // phone in hand (Remote_Fix / reboot taps): stand still while it plays
      if(h.phoneT>0){h.phoneT-=dt;h.pauseT=Math.max(h.pauseT||0,.05);h.useT=h.phoneT;
        if(h.phoneT<=0&&h.phoneDo){const f=h.phoneDo;h.phoneDo=null;f();}return;}
      // Remote_Fix: an alarm going off within range -> tap it off from the phone
      if(RM){const car=(this.obst||[]).find(o=>o.alarmT>0&&Math.abs(o.x-hx)<RM.r);if(car&&!h.remoteCar){h.remoteCar=car;h.phoneT=RM.T;h.phoneDo=()=>{h.remoteCar=null;if(car.alarmT>0){car.alarmT=0;car.alarmN=0;this.supXp(h,2);this.fx.push({k:'ring',x:car.x,y:LANES[car.lanes[0]]-10,t:0,r:10,c:'#7affe0'});this.text(car.x,LANES[car.lanes[0]]-30,'ALARM OFF','#7affe0');
            Comms.bubble(this,h,Comms.pick(['Disabled it from my phone.','There\'s an app for that.','Alarm\'s off. You\'re welcome.','Remote access, baby.']),true);}};return;}}
      // Ctrl_Z: undo the last few seconds of damage on an ally who just got chunked
      if(UZ&&h.unT<=0&&(h.en||0)>=UZ.en){const lost=o=>(o.dmgLog||[]).filter(e=>this.t-e[0]<=UZ.win).reduce((a,e)=>a+e[1],0);
        const T=al.concat([h]).filter(o=>!o.downed&&o.alive&&(o===h||near(o,UZ.r))&&lost(o)>=o.max*Math.min(UZ.min,.15)).sort((p,q)=>lost(q)/q.max-lost(p)/p.max)[0];
        if(T&&spendEnergy(h,UZ.en)){h.unT=UZ.cd*(1-(h.cdr||0));const amt=Math.min(lost(T),T.max-T.hp);T.dmgLog=[];h.phoneT=.4;h.phoneDo=()=>{if(!T.alive)return;this.healHero(T,amt,false,h);
            this.fx.push({k:'ring',x:this.heroX(T),y:(T.gy||this.G)-14,r:14,t:0,c:'#7affe0'});this.text(this.heroX(T),(T.gy||this.G)-46,'CTRL+Z','#7affe0');
            Comms.bubble(this,h,Comms.pick(['Ctrl+Z. That never happened.','Undo! Undo!','Rolling you back to the last save.','Reverting that.']),true);};return;}}
      // Dad_Mode: an ally under 40% with 2+ zombies on them
      if(DM&&h.ddT<=0&&(h.en||0)>=DM.en){const T=al.filter(o=>near(o,DM.r)&&o.hp/o.max<Math.max(DM.under,.55)&&foesOn(o)>=1)[0];
        if(T&&spendEnergy(h,DM.en)){h.ddT=DM.cd*(1-(h.cdr||0));h.dadT=DM.dur;h.dadDR=DM.dr;h.x=this.heroX(T)+(T.x<h.x?6:-6);h.gy=T.gy;h.laneI=T.laneI;
          T.shield=Math.max(T.shield||0,T.max*DM.shield);T.shieldT=Math.max(T.shieldT||0,DM.dur);
          for(const e of this.enemies){if(e.dead||e.boss||Math.abs(e.x-this.heroX(T))>22)continue;const res=(e.E&&e.E.kbRes)||0;e.kbv=Math.max(e.kbv||0,DM.kb/100*40*8*(1-res));e.kbDir=e.x>=this.heroX(T)?1:-1;}
          this.fx.push({k:'ring',x:this.heroX(T),y:(T.gy||this.G)-12,r:16,t:0,c:'#b38cff'});this.text(this.heroX(h),(h.gy||this.G)-48,'DAD MODE','#b38cff');
          Comms.bubble(this,h,Comms.pick(['Nobody touches my people.','Dad mode: ON.','Get behind me.','Not today, buddy.']),true);return;}}
      // Turn_It_Off_And_On_Again
      if(RB&&h.rbT<=0&&(h.en||0)>=RB.en){const T=al.filter(o=>near(o,RB.r)&&!o.downed&&((o.bleedT>0)||(o.fearT>0)||(o.slow>0&&o.slowT>0)||(o.hp/o.max<RB.under&&cdsOf(o).length)))
          .sort((p,q)=>p.hp/p.max-q.hp/q.max)[0];
        if(T&&spendEnergy(h,RB.en)){h.rbT=RB.cd*(1-(h.cdr||0));h.phoneT=.6;h.phoneDo=()=>{if(!T.alive)return;T.bleedT=0;T.fearT=0;T.slow=0;T.slowT=0;this.healHero(T,T.max*RB.heal,false,h);
            const cds=cdsOf(T).sort(()=>this.rng()-.5);for(const k of cds.slice(0,RB.n||1))T[k]=0;
            this.fx.push({k:'ring',x:this.heroX(T),y:(T.gy||this.G)-14,r:12,t:0,c:'#7affe0'});this.text(this.heroX(T),(T.gy||this.G)-44,'REBOOTED','#7affe0');
            Comms.bubble(this,h,Comms.pick(['Have you tried turning it off and on again?','Hold power for ten seconds.','Rebooting you, one sec.','Clear your cache, buddy.','Fixed it. Don\'t touch anything.']),true);};return;}}
      // Tech_Support (was Free_Trial)
      if(FT&&h.frT<=0&&(h.en||0)>=FT.en){const grp=al.filter(o=>near(o,FT.r)&&!o.downed&&o.alive);const worth=grp;   /* 0.12.138: worth casting whenever someone's in reach and zombies are around (the +energy helps everyone) */
        if(worth.length&&this.enemies.some(e=>!e.dead&&e.x<this.W+10)&&spendEnergy(h,FT.en)){h.frT=FT.cd*(1-(h.cdr||0));
          this.supXp(h,.3*grp.length);for(const o of grp){for(const k of cdsOf(o))o[k]*=1-FT.cut;if(FT.energy)o.en=Math.min(o.enMax||100,(o.en||0)+FT.energy);this.fx.push({k:'ring',x:this.heroX(o),y:(o.gy||this.G)-14,r:10,t:0,c:'#ffd23f'});}
          this.text(hx,(h.gy||this.G)-48,'TECH SUPPORT','#ffd23f');if(this.rng()<.35)Comms.bubble(this,h,Comms.pick(['Tech support, how can I help?','Pushing an update to everyone.','Have you tried closing some tabs?','I just optimized you. You\'re welcome.','Ticket closed.']),true);return;}}}
    // ---- JP (0.12.66)
    if(h.key==='jp'){const AJ=id=>(C.abilities||[]).find(a=>a.id===id);const TK=AJ('toke'),FM=AJ('familia'),BS=AJ('noscope'),TT=AJ('trash'),BK=AJ('baked');
      for(const [A,k] of [[TK,'tkT'],[FM,'fmT'],[BS,'bsT'],[TT,'ttT']])if(A){if(h[k]==null)h[k]=A.cd*.2;if(h[k]>0)h[k]-=dt;}
      if(h._soberAcc&&h.highT>0){h.acc+=6;h._soberAcc=0;}if(!h._soberAcc&&!(h.highT>0)&&(h.soberT||0)>BK.soberAfter){h.acc-=6;h._soberAcc=1;}
      if(h.highT>0){h.highT-=dt;h.soberT=0;h.en=Math.min(h.enMax||100,(h.en||0)+BK.en*dt);}else{h.soberT=(h.soberT||0)+dt;if(h.soberT>BK.soberAfter&&!h._grump){h._grump=1;Comms.bubble(this,h,Comms.pick(['Ugh, I need a break.','Who touched my lighter?','Not now, I\'m sober.','Everybody shut up for a sec.']));}}
      h.dodgeB=h.dodgeB==null?h.dodge:h.dodgeB;h.dodge=h.dodgeB+(h.highT>0?BK.dodge:0);h._accBonus=(h._accBonus||0);if(h.trashT>0)h.trashT-=dt;
      // smoking: 2s, can walk, nothing else
      if(h.smoking){const S=h.smoking;S.t+=dt;if(S.t>=TK.dur){h.smoking=null;h.highT=TK.high;h._grump=0;addMood(h,{range:BK.slide||4},TK.high,'high');this.healHero(h,h.max*TK.heal,true,h);Comms.bubble(this,h,Comms.pick(['Ahh. Okay. Okay, I\'m good.','Now THAT\'S the stuff.','Alright, who wants some? ...No? More for me.','Lag\'s gone. Let\'s go.']));}return;}
      // rushing to family
      if(h.rush)return;   /* 0.12.201: the dash itself runs in familiaStep */
      // Protect_the_Familia
      if(FM&&h.fmT<=0&&(h.en||0)>=FM.en){const dn=this.heroes.filter(a=>a!==h&&!a.alive&&a.downed&&!a.pet&&Math.abs(a.x-h.x)<=FM.range&&this.enemies.some(e=>!e.dead&&Math.abs(e.x-a.x)<35));   /* 0.12.95 (Kyle): he can also rush a DOWNED friend with zombies over them */
        const o=dn[0]||this.alive().filter(a=>a!==h&&!a.pet&&!a.perch&&Math.abs(this.heroX(a)-h.x)<=FM.range&&(a.hp/a.max<.35||(a.hp/a.max<FM.under&&this.enemies.some(e=>!e.dead&&Math.abs(e.x-this.heroX(a))<30)))).sort((p,q)=>p.hp/p.max-q.hp/q.max)[0];
        if(o&&spendEnergy(h,FM.en)){h.fmT=999;h.rush={ally:o,t:0};h.rushT=1;h.laneI=o.laneI!=null?o.laneI:h.laneI;this.ev('dash',{});Comms.bubble(this,h,Comms.pick(['FAMILIA!','Hold on, I\'m coming!','HEY! That\'s my people!']),true);return;}}
      // No_Scope (0.12.93): IF 2+ zombies lined up ahead within range (or one big one, or 0.12.164 a lone one his last shot left nearly dead) THEN flick a piercing Kar98 shot through up to 3
      if(BS&&h.bsT<=0&&(h.en||0)>=BS.en){const line=this.enemies.filter(e=>!e.dead&&!e.fly&&e.x>h.x&&e.x-h.x<=BS.range).sort((p,q)=>p.x-q.x).slice(0,BS.pierce);
        const mul=(h.atk/h.base.atk)*(h.rangedDmg||1),avg=((BS.dice[0]*(BS.dice[1]+1))/2+(h.flatRanged||0))*mul;
        /* 0.12.164 (Kyle): follow-up finisher. IF I just fired my Kar98 (within ~1s) AND a lone zombie is left ahead with HP a No_Scope would very likely finish THEN flick it right away */
        const finish=line.length===1&&!line[0].boss&&h.rT<1&&!(h.aimHold>0)&&line[0].hp<=avg*1.1&&line[0].hp>3;
        if((line.length>=2||finish||(line[0]&&(line[0].boss||(line[0].E&&line[0].E.big))))&&spendEnergy(h,BS.en)){h.bsT=BS.cd*(1-(h.cdr||0));h.animR=.3;h.face=1;
          for(const e of line){let dmg=(this.rollDice(BS.dice)+(h.flatRanged||0))*(h.atk/h.base.atk)*(h.rangedDmg||1);if(Math.random()<(h.crit||0)+BS.crit){dmg*=h.critMul||2;this.text(e.x,e.y-30,'NO SCOPE!','#ffd23f');}this.hitEnemy(e,dmg,h,{kb:.4});}
          {const L=line[line.length-1],gy=h.gy!=null?h.gy:this.G,ty=L.gy!=null?L.gy:this.G;this.fx.push({k:'nstrace',x1:h.x+(h.face<0?-7:7),x2:L.x,y:gy-9,y2:ty-9,t:0,c:'#ffd23f'});}   /* 0.12.155 (Kyle): a hip-fire: from JP's hip to the last zombie's middle */this.ev('shot',{});
          if(Math.random()<.6)Comms.bubble(this,h,Comms.pick(['360 no scope, baby!','Get REKT.','Did you see that?! Clip it!','Collateral! Collateral!']),true);return;}}
      // Trash_Talk
      if(TT&&h.ttT<=0&&(h.en||0)>=TT.en){const near=this.enemies.filter(e=>!e.dead&&!e.boss&&Math.abs(e.x-h.x)<=TT.r);const onAlly=this.alive().some(a=>a!==h&&!a.pet&&this.enemies.filter(e=>!e.dead&&Math.abs(e.x-this.heroX(a))<22).length>=2);
        const selfOK=h.hp/h.max>.5&&near.length>=3;if(near.length>=2&&(onAlly||selfOK)&&spendEnergy(h,TT.en)){h.ttT=TT.cd*(1-(h.cdr||0));h.trashT=TT.dur;for(const e of near){e.tauntT=TT.dur;e.tauntBy=h;e.target=h;}for(const a of this.alive())if(!a.pet)a.laughT=TT.critT;
          Comms.bubble(this,h,Comms.pick(['Your mom walks faster than that!','Bro, you smell worse than my gaming chair.','Is that your best? My kids hit harder!','Come here, you rotten nerds!','Zero kills, all deaths. Classic.']),true);return;}}
      // Toke_Break
      if(TK&&h.tkT<=0&&!(h.highT>3)&&!this.enemies.some(e=>!e.dead&&Math.abs(e.x-h.x)<45)){h.tkT=TK.cd*(1-(h.cdr||0));h.smoking={t:0};if(Math.random()<.7)Comms.bubble(this,h,Comms.pick(['Hold up, smoke break.','Pause the game, I gotta hit this.','One sec, one sec...','Medicinal. Totally medicinal.']));return;}}
    // ---- Call Companion (Flannel_Man)
    const PB=(C.abilities||[]).find(a=>a.id==='pal');if(PB){if(h.palT==null)h.palT=PB.cd*.15;if(h.palT>0)h.palT-=dt;}
    if(h.calling){const S=h.calling;if(mt){h.calling=null;this.text(h.x,this.G-70,'interrupted','#9aa');}
      else{S.t+=dt;h.pauseT=Math.max(h.pauseT||0,.1);if(S.t>=S.T){h.calling=null;if(spendEnergy(h,PB.en)){h.palT=PB.cd*(1-(h.cdr||0));this.callPal(h,PB);}}return;}}
    if(PB&&!h.cast&&!h.setting&&!mt&&h.palT<=0&&(h.en||0)>=PB.en){const pal=(this.pets||[]).find(p=>p.owner===h&&p.alive);
      // IF she isn't out AND there's a fight THEN call her; IF she's out but hurt THEN patch her up
      if((!pal&&this.enemies.some(e=>!e.dead))||(pal&&pal.hp<pal.max*.93)){h.calling={t:0,T:PB.cast};return;}}
    // ---- Brick Throw (the companion): never misses, always hurts, usually stuns
    const BB=(C.abilities||[]).find(a=>a.id==='brick');if(BB){if(h.brT==null)h.brT=BB.cd*.3;if(h.brT>0)h.brT-=dt;
      if(h.brT<=0&&!mt&&tgt&&Math.abs(tgt.x-h.x)<=BB.range&&(h.en||0)>=BB.en*(1+.3*trait(h,'energy')-.15)&&spendEnergy(h,BB.en)){h.brT=BB.cd*(1-(h.cdr||0));h.animM=.45;
        const dmg=(this.rollDice(C.ranged.dice)+(C.ranged.flat||0)+(h.flatRanged||0))*(C.ranged.dmgMul||1)*BB.dmgMul*(h.atk/h.base.atk)*h.rangedDmg;
        h._forceBox='bot';const p=this.shoot(h,tgt,'brick',dmg,{});p.sure=1;p.stunCh=BB.stunCh;p.stunT=BB.stunT;p.spd=136;this.aim(p,h,tgt);h._forceBox=null;return;}}
    // ---- 0.12.68 Bottle_Distraction (the companion): IF a pack of 3+ is bunched up THEN lob a bottle 150-167 world px out, just BEHIND them,
    //   so they turn around and walk away from us to check the noise
    {const BO=(C.abilities||[]).find(a=>a.id==='bottle');if(BO){if(h.boT==null)h.boT=BO.cd*.4;if(h.boT>0)h.boT-=dt;
      if(h.boT<=0&&(h.en||0)>=BO.en){const hx=this.heroX(h),live=this.enemies.filter(e=>!e.dead&&!e.boss&&!e.fly&&e.x>hx&&e.x<this.W&&!(e.distractT>0));let best=null,bn=0;
        /* 0.12.230 (Kyle: the pull is half as wide now) she aims so the noise lands just behind the back of a tight knot: it only reaches zombies
           within 72px of the bottle, so she looks for the spot (just behind any zombie) that catches the most of them, same lane band (+-14) */
        const inR=(tx,gy)=>live.filter(o=>Math.abs(o.x-tx)<=BO.r&&Math.abs((o.gy!=null?o.gy:this.G)-gy)<=14);
        for(const e of live){const tx=e.x+BO.r*.35,gy=e.gy!=null?e.gy:this.G;const n=inR(tx,gy).length;if(n>bn||(n===bn&&best&&e.x>best.x)){bn=n;best=e;}}
        if(!(bn>=BO.min3)){const near=live.filter(o=>o.x-hx<110).sort((a,b)=>a.x-b.x)[0];if(near&&bn<2){best=near;bn=inR(near.x+BO.r*.35,near.gy!=null?near.gy:this.G).length;}else if(bn<2)best=null;}   /* no knot of 3: 2 will do; with less she still lobs it behind whatever is closing in */
        if(best){const far=best.x;const tx=Math.min(hx+BO.max,Math.max(hx+BO.min,far+BO.r*.35),this.W-6);
          if(tx-far>2&&spendEnergy(h,BO.en)){h.boT=BO.cd*(1-(h.cdr||0));h.animM=.45;h.face=1;const gy=best.gy!=null?best.gy:this.G;
            (this.bottles=this.bottles||[]).push({x0:hx+3,gy0:h.gy||this.G,x1:tx,gy1:gy,t:0,T:BO.fly,A:BO,src:h,rot:0});this.ev('whoosh',{});
            Comms.bubble(this,h,Comms.pick(['Hey! Over there!','Go fetch!','Look, shiny!','Catch!']),true);return;}}}}}
    // ---- Trip Bomb
    const TB=(C.abilities||[]).find(a=>a.id==='trip');if(TB){if(h.tbT==null)h.tbT=TB.cd*.25;if(h.tbT>0)h.tbT-=dt;}
    /* 0.12.64 Proximity_Bomb casts. PLACE: kneel 3s, no moving (a hit on him in crowbar range breaks it). TOSS / THROW: he keeps walking while the cast fills. */
    if(h.setting){const S=h.setting;if(mt){h.setting=null;this.text(h.x,this.G-70,'interrupted','#9aa');}
      else{S.t+=dt;h.pauseT=Math.max(h.pauseT||0,.1);
        if(S.t>=S.T){h.setting=null;if(spendEnergy(h,TB.en)){h.tbT=TB.cd*(1-(h.cdr||0));const P=TB.place;
          (this.traps=this.traps||[]).push({x:h.x+(h.face<0?-P.off:P.off),gy:h.gy!=null?h.gy:this.G,t:0,A:TB,owner:h,how:'plant',live:1,dice:P.dmg[0],flat:P.dmg[1],blast:{w0:P.w0,w1:P.w1}});Comms.onTrap(this,h,h.x);}}
        return;}}
    if(h.tossing){const K=h.tossing;K.t+=dt;   // no pauseT: he can move while it winds up
      if(K.t>=K.T){h.tossing=null;if(spendEnergy(h,TB.en)){h.tbT=TB.cd*(1-(h.cdr||0));const gy=K.gy,x0=h.x+(h.face<0?-8:8);
          const T={x:x0,gy,t:0,A:TB,owner:h,how:K.kind,air:0};
          if(K.kind==='toss'){const Lb=TB.lob;T.fly={t:0,T:Lb.dur,x0,x1:x0+Lb.dist,h:Lb.h};T.rollLeft=Lb.roll;T.roll0=Lb.roll;T.dice=Lb.early[0];T.flat=Lb.early[1];}
          else{const H=TB.hurl;const tx=Math.max(h.x+H.min,Math.min(h.x+H.max,K.tx));T.fly={t:0,T:H.dur,x0,x1:tx,h:H.h};T.rollLeft=0;T.impact=1;T.dice=H.dmg[0];T.flat=H.dmg[1];T.blast={w0:TB.blast.w0,w1:H.w1};}
          (this.traps=this.traps||[]).push(T);this.ev('whoosh',{});if(Math.random()<.55)Comms.bubble(this,h,K.kind==='toss'?Comms.pick(['Rolling one in!','Fire in the hole!','Bowling!']):Comms.pick(['Catch!','Heads up!','Present for you!']),true);}}}
    /* 0.12.64 Proximity_Bomb choice (Kyle): he knows PLACING is the strongest (6d4+2, wider) but slow (3s on his knees), tossing/throwing is quick.
       IF a zombie is close or on him THEN he can't afford to kneel: quick only.
       IF a bunch / a big one sits 100-150px out THEN THROW it right on them (2d4+6 on impact) when he wants quick results.
       IF zombies are 25-60px ahead in his lane THEN TOSS it so it lands short and rolls into them.
       IF the nearest threat is still far (>70px) THEN he invests: PLACE it (Careful and Calculated lean this way).
       IF nothing is near at all THEN he randomly scouts a spot to place or to toss for later. */
    if(TB&&!h.cast&&!h.setting&&!h.tossing&&!mt&&h.tbT<=0&&!(this.traps||[]).some(t=>t.owner===h)&&(h.en||0)>=TB.en*(1+.3*trait(h,'energy')-.15)){
      const hx=h.x,gy0=h.gy!=null?h.gy:this.G,live=this.enemies.filter(e=>!e.dead&&!e.fly&&e.x<this.W-4);
      const H=TB.hurl;let best=null;for(const e of live){const d=e.x-hx;if(d<H.min||d>H.max)continue;const n=live.filter(o=>Math.abs(o.x-e.x)<16&&Math.abs((o.gy||this.G)-(e.gy||this.G))<10).length;const sc=n+(e.boss||e.max>=40?2:0);if(!best||sc>best.sc)best={e,sc,n};}
      const near1=live.reduce((m,e)=>Math.min(m,Math.abs(e.x-hx)),999),inLane=live.filter(e=>e.x-hx>=25&&e.x-hx<=60&&Math.abs((e.gy!=null?e.gy:this.G)-gy0)<=9);
      const aggr=trait(h,'aggr'),plan=trait(h,'plan'),wantQuick=near1<45||(h.hp/h.max<.5)||aggr>.65;
      if(best&&best.sc>=2&&(wantQuick||near1<70||Math.random()<.5)){const cx=live.filter(o=>Math.abs(o.x-best.e.x)<16).reduce((s,o)=>s+o.x,0)/Math.max(1,best.n);h.tossing={t:0,T:H.cast,kind:'throw',tx:cx-4,gy:best.e.gy!=null?best.e.gy:gy0};return;}
      if(inLane.length&&near1>=18){h.tossing={t:0,T:TB.lob.cast,kind:'toss',gy:gy0};return;}
      if(near1>70&&near1<260&&!wantQuick&&Math.random()<.35+.4*(1-aggr)+.2*plan){h.setting={t:0,T:TB.place.cast};return;}
      if(!live.length&&this._clear&&Math.random()<dt*.25){if(Math.random()<.5)h.setting={t:0,T:TB.place.cast};else h.tossing={t:0,T:TB.lob.cast,kind:'toss',gy:gy0};return;}}
    // Aimed Shot has a 2s cast: he stands still with a laser on the target, then fires. A foe in crowbar reach breaks the cast
    //   (no energy spent, the cooldown doesn't start). If the target dies mid-cast he swings the laser to the next one in range.
    if(h.cast){const K=h.cast;
      if(mt){h.cast=null;this.text(h.x,this.G-70,'interrupted','#9aa');}
      else{if(!K.tgt||K.tgt.dead){K.tgt=findT('ranged');if(!K.tgt){h.cast=null;return;}}
        K.t+=dt;h.pauseT=Math.max(h.pauseT||0,.1);
        if(K.t>=K.T){h.cast=null;if(!spendEnergy(h,AB.en))return;
          h.abT=AB.cd*(1-(h.cdr||0));h.rT=0;h.ammo-=1;h.animR=.5;h.firedMoving=false;this.ev('gun',{rifle:1});this.shake=Math.max(this.shake||0,.2);
          const dmg=(this.rollDice(C.ranged.dice)+(C.ranged.flat||0)+(h.flatRanged||0))*(h.atk/h.base.atk)*h.rangedDmg;
          h._forceBox=AB.box;const p=this.shoot(h,K.tgt,st.proj,dmg,{pierce:AB.pierce||0});p.critAdd=AB.critAdd;p.critMul=AB.critMul;p.aimedBy=h;this.aim(p,h,K.tgt);h._forceBox=null;}
        return;}}
    // IF Aimed Shot is ready AND loaded AND standing still AND enough energy (Preserve-minded units keep a cushion) THEN start the cast
    if(AB&&!mt&&h.abT<=0&&h.ammo>0&&!h.moving&&h.rT>=.5&&(h.en||0)>=AB.en*(1+.4*trait(h,'energy')-.2)){h.cast={t:0,T:AB.cast||2,tgt};return;}
    const RA=(C.abilities||[]).find(a=>a.id==='rapid');if(RA){if(h.raT==null)h.raT=RA.cd*.3;if(h.raT>0)h.raT-=dt;
      // IF One Nocked, Two in Hand is ready AND an enemy is in bow range AND I'm not already rapid-firing THEN nock up
      if(h.raT<=0&&!h.volley3&&!mt&&tgt&&Math.abs(tgt.x-h.x)<=C.ranged.range&&(h.en||0)>=RA.en*(1+.3*trait(h,'energy')-.15)&&spendEnergy(h,RA.en)){
        h.raT=RA.cd*(1-(h.cdr||0));h.volley3={left:RA.shots,t:0,tgt};this.ev('shout',{});}}
    // 0.12.23 (Kyle): One Nocked, Two in Hand = 3 real basic shots rapid-fired inside 1.5s (one every 0.5s), then back to normal
    if(h.volley3&&RA){const V=h.volley3;V.t-=dt;h.pauseT=Math.max(h.pauseT||0,.05);
      if(V.t<=0&&V.left>0){V.left--;V.t=RA.over/RA.shots;h.rT=0;h.animR=.42;h.animRT=.42;h.firedMoving=false;
        const inR=this.liveE().filter(e=>Math.abs(e.x-h.x)<=C.ranged.range);const pk=inR.length?Brain.pickTarget(this,h,inR,this.alive(),true):null;const tg0=pk&&pk.tgt;   /* each shot is its own choice through the behavior system: same target or a different one */
        if(tg0){faceToward(h,tg0.x,1);const dmg=(this.rollDice(C.ranged.dice)+(C.ranged.flat||0)+(h.flatRanged||0))*(C.ranged.dmgMul||1)*(h.atk/h.base.atk)*h.rangedDmg*(h.cryDmg||1);
          setTimeoutSafe(this,.2,()=>{if(!h.alive)return;const tg=tg0.dead?this.liveE().sort((p,q)=>Math.abs(p.x-h.x)-Math.abs(q.x-h.x))[0]:tg0;if(!tg)return;this.ev('bow',{});
            const WR=(C.abilities||[]).find(a=>a.id==='wind');const far=WR&&Math.abs(tg.x-h.x)>WR.far;h._accBonus=(far?WR.acc:0)-(RA.accPen||0);   /* rushed shots: slightly less accurate */
            const p=this.shoot(h,tg,st.proj,dmg,{});p.nocrit=1;this.aim(p,h,tg);h._accBonus=0;if(far)p.critMul=(h.critMul||1.75)+WR.critMul;});}}
      if(V.left<=0&&V.t<=0)h.volley3=null;
      return;}
    // ---- Poultice (Chibi_Warrior): self heal over time when he's hurt
    const CL=AB_x(C,'clone');if(CL){if(h.clT==null)h.clT=CL.cd*.3;if(h.clT>0)h.clT-=dt;
      const close=this.enemies.filter(e=>!e.dead&&!e.fly&&Math.abs(e.x-h.x)<50).length,onMe=(this.bb&&this.bb.heat.get(h))||0;
      if(h.clT<=0&&!(h.cloneT>0)&&(close>=2||(h.hp/h.max<.6&&onMe>=1))&&(h.en||0)>=CL.en&&spendEnergy(h,CL.en)){h.clT=CL.cd*(1-(h.cdr||0));h.cloneT=CL.dur;h.cloneMirror=CL.mirror;h.cloneDecoy=CL.decoy;(this.clones=this.clones||[]).push({owner:h,x:h.x-(h.face||1)*10,gy:h.gy||this.G,face:h.face||1,t:0,life:CL.dur,atkT:.3,tgt:null,animM:0,walkT:0,moving:false,mirror:CL.mirror});   /* 0.12.107 (Kyle): the clone detaches and fights on its own */
        this.fx.push({k:'poof',x:h.x-(h.face||1)*10,y:this.G-20,t:0});this.ev('whoosh',{});Comms.say(this,h,'clone',{});}}
    const PO=AB_x(C,'poultice');if(PO){if(h.poT==null)h.poT=PO.cd*.2;if(h.poT>0)h.poT-=dt;
      if(h.poT<=0&&h.hp/h.max<PO.under&&!(h.hotT>0)&&(h.en||0)>=PO.en&&spendEnergy(h,PO.en)){h.poT=PO.cd*(1-(h.cdr||0));h.hotT=PO.dur;h.hotTick=0;h.hotSrc=h;h.hotAmt=h.max*PO.pct;h.hotEvery=PO.tick;h.poulticeT=PO.dur;
        this.ev('heal',{});}}
    if(h.poulticeT>0)h.poulticeT-=dt;
    // ---- Lumber_Jack abilities
    const WH=AB_x(C,'whirl'),CP=AB_x(C,'chop'),LP=AB_x(C,'leap'),RG=AB_x(C,'rage'),RL=AB_x(C,'roll');
    if(WH||CP||LP||RG||RL){for(const [A,k] of [[WH,'whT'],[CP,'cpT'],[LP,'lpT'],[RG,'rgT'],[RL,'rlT']])if(A){if(h[k]==null)h[k]=A.cd*.25;if(h[k]>0)h[k]-=dt;}
      if(h.rageT>0)h.rageT-=dt;
      const mul=(h.atk/h.base.atk)*h.meleeDmg*(h.cryDmg||1)*(h.rageT>0?1+RG.dmg:1);const flat=(C.melee.flat||0)+(h.flatMelee||0);
      // in-progress moves
      if(h.whirl){const W=h.whirl;W.t+=dt;W.tick+=dt;
        const inReach=this.enemies.some(e=>!e.dead&&!e.fly&&Math.abs(e.x-h.x)<=WH.r+(e.boss?e.w:0));W.idle=inReach?0:(W.idle||0)+dt;
        if((h.plan&&h.plan.intent==='retreat'&&h.hp/h.max<.3)||W.idle>1.5){h.whirl=null;return;}   /* breaks off early */
        if(W.tick>=WH.every){W.tick-=WH.every;this.disturb(h.x,h.gy||this.G,WH.r);for(const e of this.enemies){if(e.dead||e.fly)continue;if(Math.abs(e.x-h.x)<=WH.r+(e.boss?e.w:0)&&(e.boss||Math.abs((e.gy!=null?e.gy:this.G)-h.gy)<=WH.depth)){this.hitEnemy(e,(this.rollDice(WH.dice)+flat)*mul,h,{kb:.6});if(!e.dead&&WH.bleed){e.bleedT=WH.bleed.dur;e.bleedDps=WH.bleed.dmg/WH.bleed.dur;}}}this.ffArea(h,h.x,h.gy,WH.r,WH.depth,(this.rollDice(WH.dice)+flat)*mul);this.ev('whoosh',{});}
        if(W.t>=WH.dur)h.whirl=null;return;}
      if(h.leap){const P=h.leap;P.t+=dt;const k=Math.min(1,P.t/LP.dur);h.x=P.x0+(P.x1-P.x0)*k;h.leapH=Math.sin(Math.PI*k)*22;h.pauseT=Math.max(h.pauseT||0,.05);
        if(k>=1){h.leap=null;h.leapH=0;this.shake=Math.max(this.shake||0,.35);this.fx.push({k:'ring',x:h.x,y:this.G-4,r:LP.r*1.6,t:0,c:'#c8a060'});this.ev('thorns',{});
          this.fx.push({k:'crack',x:h.x,gy:h.gy||this.G,t:0,life:3.2,raw:1,r:LP.r},{k:'slam',x:h.x,gy:h.gy||this.G,t:0,life:.7,raw:1,r:LP.r,seed:Math.random()*99});
          for(const e of this.enemies){if(e.dead||e.fly)continue;const dx=Math.abs(e.x-h.x);if(dx<=LP.r+(e.boss?e.w:0)&&(e.boss||Math.abs((e.gy!=null?e.gy:this.G)-h.gy)<=8)){this.hitEnemy(e,(this.rollDice(LP.dice)+flat)*mul,h,{kb:1});
            if(!e.dead&&!e.boss&&LP.stun0){const q=Math.min(1,dx/LP.r);e.stun=Math.max(e.stun||0,LP.stun0-(LP.stun0-LP.stun1)*q);}}}   /* 0.12.69: stun, longest at the centre */this.ffArea(h,h.x,h.gy,LP.r,8,(this.rollDice(LP.dice)+flat)*mul);}
        return;}
      if(h.rolling)h.rolling=null;
      if(h.chopping){h.chopping-=dt;h.pauseT=Math.max(h.pauseT||0,.05);if(h.chopping<=0){h.chopping=0;const x0=h.x+(h.face<0?-CP.dist:0),x1=x0+CP.dist;this.shake=Math.max(this.shake||0,.3);this.ev('thorns',{});
          this.fx.push({k:'quake',x:h.x+(h.face<0?-CP.dist/2:CP.dist/2),gy:h.gy,w:CP.dist,t:0,life:.6,raw:1,chop:h.face<0?-1:1});this.fx.push({k:'chopwave',x0:h.x+(h.face<0?-4:4),dir:h.face<0?-1:1,len:CP.dist+6,gy:h.gy||this.G,t:0,life:.75,raw:1,seed:Math.random()*99});   /* 0.12.222 (Kyle): a tall shockwave tearing through the ground */this.ffArea(h,h.x+(h.face<0?-CP.dist/2:CP.dist/2),h.gy,CP.dist/2+2,CP.depth,(this.rollDice(CP.dice)+flat)*mul);this.fx.push({k:'ring',x:h.x+(h.face<0?-6:6),y:(h.gy||this.G)-2,r:10,t:0,c:'#c8a060'});
          for(const e of this.enemies){if(e.dead||e.fly)continue;if(e.x>=x0-4&&e.x<=x1+(e.boss?e.w:0)&&(e.boss||Math.abs((e.gy!=null?e.gy:this.G)-h.gy)<=CP.depth)){const d=this.hitEnemy(e,(this.rollDice(CP.dice)+flat)*mul,h,{});
            if(d&&!e.dead){e.stun=Math.max(e.stun||0,CP.stun*(e.boss?.3:1));const res=e.boss?.9:((e.E&&e.E.kbRes)||0);e.kbv=Math.max(e.kbv||0,CP.kb/100*40*8*(1-res));e.kbDir=e.x>=h.x?1:-1;}}}}
        return;}
      const en=h.en||0,hp=h.hp/h.max,close=this.enemies.filter(e=>!e.dead&&!e.fly&&Math.abs(e.x-h.x)<=24&&Math.abs((e.gy!=null?e.gy:this.G)-h.gy)<=6);
      // IF hurt AND something is in my face AND Log_Roll is ready THEN roll back out of it (can't be hit while rolling)
      if(RL){const lane=this.enemies.filter(e=>!e.dead&&!e.fly&&e.x-h.x>6&&e.x-h.x<=RL.range&&Math.abs((e.gy!=null?e.gy:this.G)-h.gy)<=RL.depth);
       if(RL&&h.rlT<=0&&(lane.length>=2||lane.some(e=>e.boss||e.max>=40))&&en>=RL.en&&spendEnergy(h,RL.en)){h.rlT=RL.cd*(1-(h.cdr||0));h.face=1;h.animT=.32;h.lunge=4;
         (this.logs=this.logs||[]).push({x:h.x+8,gy:h.gy||this.G,x0:h.x+8,A:RL,h,hit:new Set(),mul,flat,t:0});this.ev('whoosh',{});return;}}
      // IF under half health AND Timber_Rage is ready THEN get angry
      if(RG&&h.rgT<=0&&hp<RG.under&&en>=RG.en&&this.enemies.some(e=>!e.dead&&Math.abs(e.x-h.x)<120)&&spendEnergy(h,RG.en)){h.rgT=RG.cd*(1-(h.cdr||0));h.rageT=RG.dur;h.rageAnim=.7;this.ev('shout',{});}
      // IF 2+ enemies are around me AND Whirl_Wind is ready THEN spin
      if(WH&&h.whT<=0&&close.length>=2&&en>=WH.en&&spendEnergy(h,WH.en)){h.whT=WH.cd*(1-(h.cdr||0));h.whirl={t:0,tick:WH.every*.7};this.ev('whoosh',{});return;}
      // IF an enemy is in my lane a little ahead (inside the shockwave) AND Ground_Chop is ready THEN chop
      const ahead=this.enemies.filter(e=>!e.dead&&!e.fly&&e.x-h.x>0&&e.x-h.x<=CP.dist&&Math.abs((e.gy!=null?e.gy:this.G)-h.gy)<=CP.depth);
      if(CP&&h.cpT<=0&&ahead.length&&en>=CP.en&&spendEnergy(h,CP.en)){h.cpT=CP.cd*(1-(h.cdr||0));h.chopping=CP.cast;h.chopT0=CP.cast;h.face=1;return;}
      // IF a big target is 24-60px away (too far to swing, close enough to jump) AND Hatchet_Leap is ready THEN leap onto it
      const lt=this.enemies.filter(e=>!e.dead&&!e.fly&&Math.abs(e.x-h.x)>=LP.min&&Math.abs(e.x-h.x)<=LP.range).sort((p,q)=>(q.max-p.max))[0];
      if(LP&&h.lpT<=0&&lt&&en>=LP.en&&spendEnergy(h,LP.en)){h.lpT=LP.cd*(1-(h.cdr||0));h.leap={t:0,x0:h.x,x1:lt.x-(lt.x>h.x?10:-10)};faceToward(h,lt.x,1);h.laneI=lt.laneI!=null?lt.laneI:h.laneI;return;}}
    // ---- Druid abilities
    const AB_=id=>(C.abilities||[]).find(a=>a.id===id);const MD=AB_('mend'),BL=AB_('bloom'),TH=AB_('thorns'),CY=AB_('cyclone');
    if(MD||BL||TH||CY){for(const [A,k] of [[MD,'mdT'],[BL,'blT'],[TH,'thT'],[CY,'cyT']])if(A){if(h[k]==null)h[k]=A.cd*.2;if(h[k]>0)h[k]-=dt;}
      if(h.casting){h.casting-=dt;h.pauseT=Math.max(h.pauseT||0,.05);if(h.casting<=0)h.casting=0;return;}
      const allies=this.alive().filter(fleshy);let hurt=allies.slice().sort((p,q)=>p.hp/p.max-q.hp/q.max)[0];const mul=(h.atk/h.base.atk)*h.rangedDmg*(h.cryDmg||1);
      {const O=Comms.ord(h,this,['heal']);if(O&&O.from&&O.from.alive&&fleshy(O.from)&&O.from.hp/O.from.max<.9)hurt=O.from;}   // IF someone shouted for a heal AND I listened THEN them first
      // IF an ally is low (under 85%) AND Mend is ready THEN heal them now
      if(MD&&h.mdT<=0&&hurt&&hurt.hp/hurt.max<MD.under&&(h.en||0)>=MD.en&&spendEnergy(h,MD.en)){h.mdT=MD.cd*(1-(h.cdr||0));this.healHero(hurt,hurt.max*MD.heal,false,h);
        this.fx.push({k:'mend',x:this.heroX(hurt),gy:hurt.gy||this.G,t:0,life:.9,raw:1});this.ev('heal',{});h.animC=.35;}
      // IF an ally is under 90% AND not already blooming AND Bloom is ready THEN wrap them in a healing vine heart
      const bt=allies.filter(o=>!(o.hotT>0)&&o.hp/o.max<BL.under).sort((p,q)=>p.hp/p.max-q.hp/q.max)[0];
      if(BL&&h.blT<=0&&bt&&(h.en||0)>=BL.en&&spendEnergy(h,BL.en)){h.blT=BL.cd*(1-(h.cdr||0));bt.hotT=BL.dur;bt.hotTick=0;bt.hotSrc=h;bt.hotAmt=bt.max*BL.pct;bt.hotEvery=BL.tick;bt.hotFx=0;
        this.ev('heal',{});h.animC=.35;}
      // IF 2+ enemies are down my lane (or something big) AND Thorn Wave is ready THEN send thorns rolling along the ground
      if(TH&&h.thT<=0&&!mt&&(h.en||0)>=TH.en){const lane=this.enemies.filter(e=>!e.dead&&!e.fly&&e.x>h.x&&e.x-h.x<=TH.dist&&Math.abs((e.gy!=null?e.gy:this.G)-h.gy)<=TH.depth);
        if((lane.length>=2||lane.some(e=>e.boss))&&spendEnergy(h,TH.en)){h.thT=TH.cd*(1-(h.cdr||0));h.casting=TH.cast;h.castT0=TH.cast;
          setTimeoutSafe(this,TH.cast,()=>{this.ev('thorns',{});(this.thornWaves=this.thornWaves||[]).push({x0:h.x+8,gy:h.gy,t:0,n:0,A:TH,src:h,mul,hit:new Set(),flat:(C.ranged.flat||0)+(h.flatRanged||0)});});return;}}
      // IF Cyclone is ready AND 2+ enemies are down my lane (or something big) THEN send a tornado along it
      if(CY&&h.cyT<=0&&!mt&&(h.en||0)>=CY.en){const lane=this.enemies.filter(e=>!e.dead&&!e.fly&&e.x-h.x>=CY.near-20&&e.x-h.x<=CY.dist&&Math.abs((e.gy!=null?e.gy:this.G)-h.gy)<=CY.depth);   /* 0.12.38 (Kyle): it forms ~450 screen px (150 world) ahead of her, so it wants enemies out there */
        if((lane.length>=2||lane.some(e=>e.boss))&&spendEnergy(h,CY.en)){h.cyT=CY.cd*(1-(h.cdr||0));h.casting=CY.cast;h.castT0=CY.cast;
          setTimeoutSafe(this,CY.cast,()=>{this.ev('wind',{});(this.cyclones=this.cyclones||[]).push({x:Math.min(this.W-14,h.x+CY.ahead),x0:h.x,gy:h.gy,t:0,A:CY,src:h,mul});});return;}}}
    const PN=(C.abilities||[]).find(a=>a.id==='pin');if(PN){if(h.piT==null)h.piT=PN.cd*.3;if(h.piT>0)h.piT-=dt;
      // IF the biggest (or fastest) enemy in range isn't marked yet THEN pin it
      const pt=!mt&&this.enemies.filter(e=>!e.dead&&!e.fly&&Math.abs(e.x-h.x)<=PN.range&&!(e.markT>0)).sort((p,q)=>((q.max+(q.E&&q.E.spd||0))-(p.max+(p.E&&p.E.spd||0))))[0];
      if(h.piT<=0&&pt&&(h.en||0)>=PN.en&&spendEnergy(h,PN.en)){h.piT=PN.cd*(1-(h.cdr||0));h.animR=PN.anim;h.animRT=PN.anim;faceToward(h,pt.x,1);
        setTimeoutSafe(this,PN.releaseAt,()=>{if(!h.alive)return;const tg=pt.dead?this.enemies.find(e=>!e.dead):pt;if(!tg)return;this.ev('bow',{});
          const dmg=this.rollDice(PN.dice)*(h.atk/h.base.atk)*h.rangedDmg*(h.cryDmg||1);
          const p=this.shoot(h,tg,'yarrow',dmg,{onHit:(e,d)=>{this.hitEnemy(e,d,h,{});if(e.dead)return;e.markT=PN.mark;e.markAmp=PN.amp;if(!e.boss){e.slow=Math.max(e.slow||0,.97);e.slowT=Math.max(e.slowT||0,PN.root);e.rootT=PN.root;}
            this.fx.push({k:'pinned',e,x:e.x,gy:e.gy!=null?e.gy:this.G,dir:e.x>=h.x?1:-1,t:0,life:PN.root+.4,raw:1});}});p.pin=1;p.sure=1;h._forceBox='bot';this.aim(p,h,tg);h._forceBox=null;});   /* 0.12.68 (Kyle): auto-aimed at the legs, ignores accuracy */
        return;}}
    const AR=(C.abilities||[]).find(a=>a.id==='rain');if(AR){if(h.arT==null)h.arT=AR.cd*.25;if(h.arT>0)h.arT-=dt;
      if(h.volley){h.volley-=dt;h.pauseT=Math.max(h.pauseT||0,.05);if(h.volley<=0)h.volley=0;return;}
      // IF Arrow_Rain is ready AND 2+ enemies are bunched up in range THEN rain on the thickest group
      if(h.arT<=0&&!mt&&(h.en||0)>=AR.en){const foes=this.enemies.filter(e=>!e.dead&&!e.fly&&Math.abs(e.x-h.x)<=AR.range);
        let best=null,bn=0;for(const e of foes){const n=foes.filter(o=>Math.abs(o.x-e.x)<=AR.spread&&Math.abs((o.gy||this.G)-(e.gy||this.G))<=AR.lanes).length;if(n>bn){bn=n;best=e;}}
        if(best&&bn>=2&&spendEnergy(h,AR.en)){h.arT=AR.cd*(1-(h.cdr||0));h.volley=AR.cast;h.volleyT0=AR.cast;faceToward(h,best.x,1);
          const cx=best.x,cgy=best.gy!=null?best.gy:this.G,mul=(h.atk/h.base.atk)*h.rangedDmg*(h.cryDmg||1);
          setTimeoutSafe(this,AR.cast,()=>{this.ev('bow',{});this.rain=this.rain||[];
            for(let i=0;i<AR.count;i++){const at=AR.over*i/AR.count+this.rng()*.08;const gy=Math.max(LANES[0],Math.min(LANES[LANES.length-1],cgy+(this.rng()*2-1)*AR.lanes));
              this.rain.push({x:cx+(this.rng()*2-1)*AR.spread,gy,t:-at,T:AR.fall,dmg:(this.rollDice(AR.dice)+(C.ranged.flat||0)+(h.flatRanged||0))*mul,src:h,A:AR});}});
          return;}}}
    const BG=(C.abilities||[]).find(a=>a.id==='blowgun');if(BG){if(h.bgT==null)h.bgT=BG.cd*.2;if(h.bgT>0)h.bgT-=dt;
      if(h.blowing){h.blowing-=dt;h.pauseT=Math.max(h.pauseT||0,.05);if(h.blowing<=0)h.blowing=0;return;}
      // IF Blow_Gun is ready AND a living (not undead) enemy is in range AND not in my face THEN poison it
      /* 0.12.63: prefers the living (poison works on them) but will dart an undead too now that the dart does 1d4 on its own; an immune hit refunds half the cooldown */
      const live=!mt&&this.enemies.filter(e=>!e.dead&&Math.abs(e.x-h.x)<=BG.range).sort((p,q)=>((isUndead(p)?1:0)-(isUndead(q)?1:0))||(q.max-p.max)||(Math.abs(p.x-h.x)-Math.abs(q.x-h.x)))[0];
      if(h.bgT<=0&&live&&(h.en||0)>=BG.en&&spendEnergy(h,BG.en)){h.bgT=BG.cd*(1-(h.cdr||0));h.blowing=BG.anim;h.blowT0=BG.anim;faceToward(h,live.x,1);
        
        setTimeoutSafe(this,BG.releaseAt,()=>{if(!h.alive)return;const tg=live.dead?this.enemies.find(e=>!e.dead&&Math.abs(e.x-h.x)<=BG.range):live;if(!tg)return;this.ev('bow',{});
          const mz=MUZZLE[h.key];MUZZLE[h.key]=[12,12];const p=this.shoot(h,tg,'dart',(this.rollDice(BG.base)+(isUndead(tg)?0:this.rollDice(BG.dice)))*(h.atk/h.base.atk)*h.rangedDmg*(h.cryDmg||1),{});MUZZLE[h.key]=mz;
          p.poison=isUndead(tg)?null:BG.extra;if(isUndead(tg))p.blowBy=h;this.aim(p,h,tg);});
        return;}}
    if(C.ranged&&C.ranged.lazer){const LZ=C.ranged.lazer;   // 0.12.67 Warhound: IF the lazer is reloaded AND a target is 200-500 screen px out THEN charge it up
      if(!h.lz&&!(h.lzReload>0)&&tgt&&tgt.x<this.W-4){const d=Math.abs(tgt.x-this.heroX(h));if(d>=LZ.min&&d<=LZ.max){const dir=tgt.x>=h.x?1:-1;h.face=dir;unstealth(h);
        h.lz={t:0,tg:tgt,dir,tx:tgt.x-dir*LZ.lead,gy:tgt.gy!=null?tgt.gy:this.G,ct:0,dt:0};this.ev('zap',{});}}return;}
    const rap=false;
    if(C.ranged&&C.ranged.burst&&tgt){   /* 0.12.110 Shoshi's trigger discipline: short bursts, or dump the mag when it's worth it */
      const big=tgt.boss||(tgt.E&&(tgt.E.hp>=38||tgt.type==='werewolf'))||tgt.hp>=26;const onHurt=this.alive().some(o=>!o.pet&&o!==h&&o.hp/o.max<.45&&Math.abs(this.heroX(o)-tgt.x)<22);
      if(!(h.freeUntil>this.t)&&!big&&!onHurt&&(h.burstN||0)>=C.ranged.burst&&h.rT>=C.ranged.burstGap&&this.rng()<.015)h.freeUntil=this.t+.5+this.rng()*.6;   /* 0.12.110 (Kyle): now and then he just lets it rip for no reason */
      h.unload=big||onHurt||h.freeUntil>this.t;h.shAcc=h.unload?(C.ranged.sprayAcc||0):(C.ranged.tapAcc||0);if(!h.unload&&(h.burstN||0)>=C.ranged.burst){if(h.rT<C.ranged.burstGap)return;h.burstN=0;}}
    if(C.ranged&&h.ammo>0&&h.rT>=C.ranged.every*(rap?RA.every:1)){if(C.ranged.burst)h.burstN=(h.burstN||0)+1;
      if(h.moving&&trait(h,'exec')>.5&&!(h.plan&&h.plan.intent==='retreat')&&(h.plantT=(h.plantT||0)+dt)<.2+1.2*(trait(h,'exec')-.5)*2)return;   // optimal shooters plant their feet first (but not when running away)
      h.plantT=0;h.rT=0;h.ammo-=1;unstealth(h);const AIM=C.ranged.aimT||0;
      if(AIM){h.aimHold=AIM;h.pauseT=Math.max(h.pauseT||0,AIM);h.moving=false;faceToward(h,tgt.x,1);   /* 0.12.163 aim wind-up: he plants, shoulders it, then fires */
        setTimeoutSafe(this,AIM,()=>{if(!h.alive)return;h.aimHold=0;h.animR=C.ranged.anim||.5;h.animRT=h.animR;h.firedMoving=false;this.ev('gun',{rifle:h.key==='jp'});});}
      else{h.animR=rap?RA.anim:(C.ranged.anim||.5);h.animRT=h.animR;h.firedMoving=h.moving;if(!C.ranged.releaseAt)this.ev('gun',{});}
      const rel=AIM?AIM:C.ranged.releaseAt?C.ranged.releaseAt*(h.animR/(C.ranged.anim||.5)):0;if(rap)h.rapid--;
      const dmg=(this.rollDice(C.ranged.dice)+(C.ranged.flat||0)+(h.flatRanged||0))*(C.ranged.dmgMul||1)*(h.atk/h.base.atk)*h.rangedDmg*(h.cryDmg||1)*(h.crateT>0?1.15:1)*(h.chzStk?1+.1*h.chzStk:1);if(h.chzStk)h.chzStk=0;   /* 0.12.200 Ammo_Drop: +15% near the crate; 0.12.220 Chutzpah stacks */
      const fire=()=>{if(!h.alive)return;const tg=tgt.dead?this.liveE().sort((p,q)=>Math.abs(p.x-h.x)-Math.abs(q.x-h.x))[0]:tgt;if(!tg)return;if(C.ranged.flame){this.flameSpray(h,tg,C.ranged.flame);return;}if(C.ranged.gl){this.launchNade(h,tg,dmg,C.ranged.gl);return;}if(C.ranged.releaseAt)this.ev('bow',{});
        const WR=(C.abilities||[]).find(a=>a.id==='wind');const far=WR&&Math.abs(tg.x-h.x)>WR.far;   // Wind_Reading
        for(let i=0;i<C.ranged.pellets;i++){const acc=h.moving?Math.max(1,h.acc-C.walkPenalty):h.acc;h._accBonus=acc-h.acc+(far?WR.acc:0)+(C.ranged.burst?(h.shAcc||0):0);
          let T2=tg;if(C.ranged.spread&&i>0){const side=i===1?-1:1;const alt=this.liveE().filter(e=>e!==tg&&Math.abs(e.x-h.x)<=C.ranged.range&&Math.sign((e.gy||this.G)-(tg.gy||this.G))===side).sort((p,q)=>Math.abs(p.x-tg.x)-Math.abs(q.x-tg.x))[0];if(alt&&Math.abs(alt.x-tg.x)<50)T2=alt;}   /* outer pellets go after whoever is up or down a lane from the target */
          const p=this.shoot(h,T2,C.ranged.proj||st.proj,dmg/C.ranged.pellets,{});if(C.ranged.spread&&i>0)h._accBonus-=12;this.aim(p,h,T2);h._accBonus=0;if(far)p.critMul=(h.critMul||1.75)+WR.critMul;
          if(C.ranged.spread&&i>0&&T2===tg){const side=i===1?-1:1;p.tgy+=side*(4+this.rng()*3);p.aimH+=(this.rng()*2-1)*8;}   /* wild outer pellets angle off up and down the lanes */
          else if(C.ranged.spread&&i>0){p.tgy+=(this.rng()*2-1)*2;}}};
      const nb=C.ranged.burst||1;for(let b=0;b<nb;b++){const tt=rel+b*(C.ranged.burstGap||.08);if(tt>0)setTimeoutSafe(this,tt,fire);else fire();}}}
  /* 0.12.44 Guard Dog Kennel: one dog, out from the start of every stage; each Kennel tier makes him a bit tougher and harder-biting */
  /* 0.12.204 (Kyle) Kennel: max 1 dog out (2 at tier IV). Each dog is a random breed with its own little temperament.
     A dog that goes down is gone; the kennel sends a new one 40s later (if the stage is still on). */
  stepKennel(dt){const kt=upgT(this.run,'kennel');if(!kt||this.demo||!this.dogQ||!this.dogQ.length||this.over||this.exiting)return;const cap=kt>=4?2:1;
    while(this.dogQ.length&&this.t>=this.dogQ[0]){this.dogQ.shift();if((this.pets||[]).filter(p=>p.dog&&p.alive).length<cap){const d=this.spawnDog(kt,0,1);if(d){d.x=-8;this.text(10,this.G-50,'NEW DOG!','#ffe08a');}}}}
  spawnDog(t,i,fresh){this.pets=this.pets||[];if(!fresh){if(!i&&t>=4&&!this._dog2){this._dog2=1;this.spawnDog(t,1);}if(!i&&this.pets.some(p=>p.key==='dog'&&!p.second))return;}const lv=Math.max(1,Math.round(this.heroes.reduce((s,h)=>s+(h.lvl||1),0)/Math.max(1,this.heroes.length)));
    const key='dog',b=heroBase(key,lv,this.run.team.length);const hm=1,dm=[1.1,1.2,1.3,1.4][t-1];   /* 0.12.204 (Kyle): tier I dog bites 10% harder */const h0=this.heroes[i?Math.min(1,this.heroes.length-1):0];
    const hitsMax=t>=3?7:6;   /* 0.12.204: 6 hits (7 from tier III) */const BR=DOG_BREEDS[Math.floor(this.rng()*DOG_BREEDS.length)];const dg={key,def:{key,name:i?'Guard_Dog 2':'Guard_Dog'},style:STYLE[key],lvl:lv,base:b,spells:[],items:[],alive:true,owner:h0,pet:1,dog:1,second:!!i,hits:hitsMax,hitsMax,hitRegEvery:t>=3?8:12,skin:BR.skin,breed:BR.name,hitRegT:0,x:(h0?h0.x:60)-10-(i?14:0),gy:(h0&&h0.gy)||LANES[2],laneI:h0&&h0.laneI!=null?h0.laneI:2,
      atkT:0,anim:0,animT:0,walkT:0,shield:0,shieldT:0,buffT:0,lowT:0,nearT:0,hitFlash:0,alt:0,face:1,
      max:b.hp*hm,hp:b.hp*hm,atk:b.atk*dm,aspd:1,crit:b.crit,acc:b.acc+2*(t-1),dr:0,armor:0,cdr:0,dodge:b.dodge+.02*(t-1),luck:0,scoreM:1,pow:1,reach:1,critMul:b.critMul,armorPts:b.armorPts+(t-1),kbRes:b.kbRes,
      enMaxB:100,enRegenB:5,xpBonus:0,lifesteal:0,mvMul:1,meleeDmg:1,rangedDmg:1,meleeSpd:1+.1*(t-1),rangedSpd:1,kbAdd:0,flatRanged:0,flatMelee:0};
    dg.def.name=(i?'Dog 2 · ':'')+BR.name;personaOf(dg);addMood(dg,BR.mood,1e9,'breed');if(BR.dodge)dg.dodge+=BR.dodge;if(BR.bite)dg.atk*=1+BR.bite;
    this.pets.push(dg);return dg;}
  callPal(h,PB){this.pets=this.pets||[];let pal=this.pets.find(p=>p.owner===h&&p.alive);
    if(pal){const amt=pal.max*PB.heal;pal.hp=Math.min(pal.max,pal.hp+amt);this.text(pal.x,this.G-50,'+'+Math.round(amt),'#7dff9a');return;}
    const key='flannel_pal',b=heroBase(key,h.lvl,this.run.team.length);
    pal={key,def:{key,name:'Traveling_Companion'},style:STYLE[key],lvl:h.lvl,base:b,spells:[],items:[],alive:true,owner:h,pet:1,x:h.x-14,gy:h.gy,laneI:Math.max(0,Math.min(LANES.length-1,(h.laneI||2)+(this.rng()<.5?-1:1))),
      atkT:0,anim:0,animT:0,walkT:0,shield:0,shieldT:0,buffT:0,lowT:0,nearT:0,hitFlash:0,alt:0,face:1,
      max:b.hp,hp:b.hp,atk:b.atk,aspd:1,crit:b.crit,acc:b.acc,dr:0,armor:0,cdr:0,dodge:b.dodge,luck:0,scoreM:1,pow:1,reach:1,critMul:b.critMul,armorPts:b.armorPts,kbRes:b.kbRes,
      enMaxB:100,enRegenB:5,xpBonus:0,lifesteal:0,mvMul:1,meleeDmg:1,rangedDmg:1,meleeSpd:1,rangedSpd:1,kbAdd:0,flatRanged:0,flatMelee:0};
    this.pets.push(pal);this.fx.push({k:'poof',x:pal.x,y:this.G-20,t:0});}
  tripBoom(T){const A=T.A,h=T.owner;T.done=1;this.fx.push({k:'boom',x:T.x,gy:T.gy,t:0,life:1.15,raw:1});this.ev('boom',{});this.shake=Math.max(this.shake||0,.55);
    const base=this.rollDice(T.dice||[2,4])+(T.flat||0)+((h&&h.flatRanged)||0);const mul=(h&&h.base?(h.atk/h.base.atk)*(h.rangedDmg||1):1)*(h&&hasPerk(h,'sapper')?1.25:1);   /* 0.12.55: a Sapper's own bomb hits 25% harder */
    for(const e of this.enemies){if(e.dead||e.fly)continue;const dx=Math.abs(e.x-T.x),dz=Math.abs((e.gy!=null?e.gy:this.G)-T.gy);
      // 0.12.64 (Kyle): blast covers its own lane wide and the lanes just above and below narrower
      const BW=T.blast||A.blast;const own=dz<=3.5,side=dz>3.5&&dz<=11.5;const lim=own?BW.w0:side?BW.w1:-1;if(dx>lim)continue;
      const fall=1-.45*Math.min(1,dx/Math.max(1,lim));const dealt=this.hitEnemy(e,base*mul*fall,h&&h.alive?h:null,{blast:1});   // AoE: full damage in the middle, half at the edge
      if(dealt&&!e.dead){const res=e.boss?.9:((e.E&&e.E.kbRes)||0);e.kbv=Math.max(e.kbv||0,A.kb/100*40*8*(1-res)*fall);e.kbDir=e.x>=T.x?1:-1;
        if(this.rng()<A.bleed.chance){e.bleedT=A.bleed.dur;e.bleedDps=A.bleed.dmg/A.bleed.dur;}}
      e._tripHit=T;}
    if(this.hardcore)for(const o of this.alive()){const dx=Math.abs(this.heroX(o)-T.x),dz=Math.abs((o.gy||this.G)-T.gy);const BW=T.blast||A.blast;const lim=dz<=3.5?BW.w0:dz<=11.5?BW.w1:-1;
      if(dx<=lim){this.hurtHero(o,base*mul*.8,null);this.st8(h||o).ff=(this.st8(h||o).ff||0)+1;}}   /* Hardcore: your own bomb hurts your people too */
    /* 0.12.38 (Kyle): shockwave. A wider ring around the cross: anything it reaches that the cross missed takes half damage and a heavier shove (no bleed) */
    const SW=A.shock;if(SW){this.fx.push({k:'ring',x:T.x+6,y:T.gy-4,t:0,r:SW.r,c:'#ffd9a0'});
      for(const e of this.enemies){if(e.dead||e.fly||e._tripHit===T)continue;const dx=Math.abs(e.x-T.x),dz=Math.abs((e.gy!=null?e.gy:this.G)-T.gy);
        if((dx/SW.r)**2+(dz/SW.depth)**2>1)continue;const dealt=this.hitEnemy(e,base*mul*.5,h&&h.alive?h:null,{blast:1});
        if(dealt&&!e.dead){const res=e.boss?.9:((e.E&&e.E.kbRes)||0);e.kbv=Math.max(e.kbv||0,A.kb*SW.kbMul/100*40*8*(1-res));e.kbDir=e.x>=T.x?1:-1;}}}}
  addPoison(e,n){if(!e||e.dead||n<=0)return 0;if(isUndead(e)){this.text(e.x,e.y-(e.boss?100:44),'IMMUNE','#9aa');return 0;}
    e.poison=(e.poison||0)+n;e.poisonT=POISON.dur;if(e.poisonTick==null)e.poisonTick=0;this.text(e.x,e.y-(e.boss?100:46),'POISON x'+e.poison,'#7dff6a');return n;}
  rollDice([n,d]){let r=0;for(let i=0;i<n;i++)r+=1+Math.floor(this.rng()*d);return r;}
  // 0.12.2 test move for the energy sliders (until real abilities come back): a Power Attack costs 30 energy and hits x1.8
  powerMul(u){if(this.demo||!Brain.energyCall(u))return 1;if(!spendEnergy(u,30)){u.burst=0;return 1;}if(u.burst>0)u.burst--;
    const x=u.key?this.heroX(u):u.x;return 1.8;}
  basic(h,tgt,kind,mult){
    const st=h.style;kind=kind||st.atk;const [nd,ds]=h.base.dice||[2,4];let roll=0;for(let i=0;i<nd;i++)roll+=1+Math.floor(this.rng()*ds);const A=roll*(h.atk/h.base.atk);   // basic attack: a fresh 2d4 every swing/shot (item/team damage bonuses still apply)
    const M=mult==null?1:mult;
    if(kind==='melee'){const hits=st.double&&!ABILITIES_OFF?2:1;
      for(let i=0;i<hits;i++){this.hitEnemy(tgt,A*M*(i?0.8:1),h,{kb:1});}
      if(!ABILITIES_OFF)for(const o of this.enemies)if(o!==tgt&&!o.dead&&!o.fly&&Math.abs(o.x-tgt.x)<12)this.hitEnemy(o,A*.4,h,{nocrit:1});
      this.fx.push({k:'slash',x:tgt.x-6,y:tgt.boss?tgt.y-50:tgt.fly?tgt.y:tgt.y-24,t:0});return;}
    const pk=kind==='ranged'||kind==='caster'?st.proj:kind;
    setTimeoutSafe(this,.11,()=>{if(!h.alive)return;const tg=tgt.dead?this.liveE().sort((p,q)=>p.x-q.x)[0]:tgt;if(!tg)return;
    h._accBonus=h.moving?-45*(1-trait(h,'exec')):12*trait(h,'exec');const p=this.shoot(h,tg,pk,A*M,{});this.aim(p,h,tg);h._accBonus=0;if(st.atk==='duo')p.x=(st.companion?h.x+(h.compX||-12):h.x-9)+(MUZZLE[h.key]||[10])[0];if(!ABILITIES_OFF){p.splash=st.splash||(pk==='orb'?12:0);p.chill=st.chill;}});
  }
  // the scout roams around her partner (can't be targeted), and now and then pounces on the front enemy with a knife
  companion(h,dt,f){
    h.compT=(h.compT||0)+dt;h.pounceT=(h.pounceT==null?5:h.pounceT)-dt;
    if(h.pounce){const P=h.pounce;P.t+=dt;const u=Math.min(1,P.t/.35);
      if(P.t<.35){h.compX=P.x0+(P.tx-P.x0)*u;h.compY=Math.sin(u*Math.PI)*22;}
      else if(!P.hit){P.hit=1;if(!P.tgt.dead){this.hitEnemy(P.tgt,h.atk*1.5,h,{});this.fx.push({k:'slash',x:P.tgt.x-6,y:P.tgt.boss?P.tgt.y-50:P.tgt.fly?P.tgt.y:P.tgt.y-24,t:0});}}
      else if(P.t<.95){const v=(P.t-.6)/.35;if(v>0){h.compX=P.tx+(P.x0-P.tx)*Math.min(1,v);h.compY=Math.sin(Math.min(1,v)*Math.PI)*14;}}
      else{h.pounce=null;h.compY=0;}
      h.compV=0;return;}
    const want=-6+Math.sin(h.compT*1.3)*26+Math.sin(h.compT*3.1)*7;const prev=h.compX==null?want:h.compX;   // quick, wide patrol
    h.compX=prev+Math.max(-70*dt,Math.min(70*dt,(want-prev)*Math.min(1,dt*5)));h.compV=(h.compX-prev)/Math.max(dt,1e-3);h.compY=0;
    if(!ABILITIES_OFF&&h.pounceT<=0){const t=this.liveE().filter(e=>e.x-(e.boss?e.w:0)-f.x<50).sort((p,q)=>p.x-q.x)[0];
      if(t){h.pounce={t:0,x0:h.compX,tx:(t.x-(t.boss?t.w*.6:0))-h.x,tgt:t};h.pounceT=5;}else h.pounceT=1;}
  }
  liveE(){return this.enemies.filter(e=>!e.dead&&e.x<this.W+4);}
  sigArea(h,R,dmg,o){const f=this.front();let any=false;
    for(const e of this.liveE())if(e.x-(e.boss?e.w:0)-f.x<R&&!(o.ground&&e.fly)){this.hitEnemy(e,dmg,h,{kb:o.kb||0});if(o.slow){e.slow=Math.max(e.slow,o.slow);e.slowT=2;}any=true;}
    if(any){if(o.fx==='slash')this.fx.push({k:'slash',x:f.x+18,y:this.G-26,t:0});else if(o.fx==='frost')this.fx.push({k:'frost',t:0});else if(o.fx==='beamline')this.fx.push({k:'beamline',x:h.x,y:this.G-30,t:0,c:o.c});else this.fx.push({k:'ring',x:f.x+R/2,y:this.G-22,r:Math.min(R,80)*.7,t:0,c:o.c||'#fff'});}
    return any;}
  sigShot(h,kind,dmg,o){const t=this.liveE().sort((p,q)=>p.x-q.x)[0];if(!t)return false;const p=this.shoot(h,t,kind,dmg,{});p.splash=o.splash||0;
    p.opt.onHit=(e,d)=>{const r=this.hitEnemy(e,d,h,{kb:o.kb||0});if(o.stun)e.stun=Math.max(e.stun,o.stun);if(o.splash)for(const x of this.enemies)if(x!==e&&!x.dead&&Math.abs(x.x-e.x)<o.splash)this.hitEnemy(x,d*.5,h,{nocrit:1});return r;};
    if(h.style.atk==='duo'){p.x=(h.style.companion?h.x+(h.compX||-12):h.x-9)+(MUZZLE[h.key]||[10])[0];h.animT=.32;}return true;}
  sigMulti(h,kind,dmg,n,o){const L=this.liveE();if(!L.length)return false;for(let i=0;i<n;i++)setTimeoutSafe(this,i*.25,()=>{const M=this.liveE();if(!M.length||!h.alive)return;const p=this.shoot(h,M[Math.floor(this.rng()*M.length)],kind,dmg,{});p.splash=(o&&o.splash)||0;});return true;}
  sigChain(h,dmg,n){let L=this.liveE().sort((p,q)=>p.x-q.x);if(!L.length)return false;let prev={x:h.x,y:this.G-30};
    for(const e of L.slice(0,n)){this.fx.push({k:'zap',x:prev.x,y:prev.y,tx:e.x,ty:e.fly?e.y:e.y-24,t:0});this.hitEnemy(e,dmg,h,{});prev={x:e.x,y:e.fly?e.y:e.y-24};}return true;}
  sigFront(h,dmg,o){const f=this.front();const t=this.liveE().filter(e=>e.x-(e.boss?e.w:0)-f.x<40).sort((p,q)=>p.x-q.x)[0];if(!t)return false;
    let tot=0;for(let i=0;i<(o.hits||1);i++)tot+=this.hitEnemy(t,dmg,h,{kb:o.kb||0});if(o.stun)t.stun=Math.max(t.stun,o.stun);if(o.burn){t.burn=Math.max(t.burn,o.burn);t.burnT=3;}
    if(o.heal)this.healHero(h,tot*o.heal);this.fx.push({k:'slash',x:t.x-6,y:t.boss?t.y-50:t.y-24,t:0});h.animT=.32;return true;}
  sigMark(h,dmg){const t=this.liveE().sort((p,q)=>q.hp-p.hp)[0];if(!t)return false;t.shred=6;this.shoot(h,t,'quarrel',dmg,{});this.fx.push({k:'ring',x:t.x,y:t.boss?t.y-60:t.y-24,r:10,t:0,c:'#ffd23f'});return true;}
  sigDrain(h,dmg,n){const L=this.liveE().sort(()=>this.rng()-.5).slice(0,n);if(!L.length)return false;let tot=0;
    for(const e of L){tot+=this.hitEnemy(e,dmg,h,{});this.fx.push({k:'drain',x:e.x,y:e.y-(e.fly?0:24),tx:h.x,c:'#ff3a5a',t:0});}for(const o of this.alive())this.healHero(o,tot*.5/this.alive().length);return true;}
  enemyShot(e,t){if(!t)return;const p={enemy:true,kind:e.E?e.E.proj:'bat',x:e.x+(e.face>0?8:-8),y:e.fly?e.y:e.y-30,tx:t,dmg:e.dmg,src:e,spd:150,t:0,pierce:(e.E&&e.E.pierce)||0,opt:{},hit:new Set()};
    this.proj.push(p);if(!e.boss)this.aim(p,e,t);}
  /* 0.12.127 (Kyle) THE HARVEST KNIGHT (stage 10). Every move is telegraphed on the ground first.
     Reaping_Sweep (every 3.2s, 2.4s enraged): a wide arc in front of him.  Pitchfork_Slam (every 8s): the scythe brought down two-handed on one hero.
     Murder_of_Crows (every 11s): crows dive at three heroes.  Bonfire_Harvest: at half HP his head flares up (enraged): faster sweeps and
     fire patches erupting under two heroes every 5s. */
  harvestAI(b,dt,al,f){if(!al.length)return;const A=b.act;
    if(!b.phase&&b.hp<b.max*.5){b.phase=1;this.ev('enrage');this.shake=.5;this.fx.push({k:'ring',x:b.x,y:this.G-40,t:0,r:30,c:'#ff8a20'});b.tF=2;}
    if(A){A.t+=dt;if(!A.done&&A.t>=A.hit){A.done=1;A.fn&&A.fn();}if(A.t>=A.T)b.act=null;return;}
    const go=(name,T,hit,fn)=>{b.act={name,t:0,T,hit,fn};b.anim=1;b.animT=T;};
    if(b.phase){b.tF=(b.tF||5)-dt;if(b.tF<=0){b.tF=5;const ts=al.slice().sort(()=>this.rng()-.5).slice(0,2);go('cast',.75,.3,()=>{for(const t of ts)this.zone(this.heroX(t),14,1.1,b.dmg*.8,b,'fire','#ff7a1a');});return;}}
    if(b.t3<=0){b.t3=11;go('cast',.75,.4,()=>{for(let i=0;i<3;i++){const t=al[Math.floor(this.rng()*al.length)];this.proj.push({enemy:true,kind:'batswarm',x:b.x-10,y:b.y-70,tx:t,dmg:b.dmg*.5,src:b,spd:120+i*25,t:0});}});return;}
    if(b.t2<=0){b.t2=8;const t=al[Math.floor(this.rng()*al.length)];const tx=this.heroX(t);this.zone(tx,14,.65,b.dmg*1.6,b,'slam','#ffb040');go('slam',.9,.65,()=>{this.shake=Math.max(this.shake,.5);this.fx.push({k:'quake',x:tx,gy:t.gy||this.G,t:0,life:.4,raw:1});});return;}
    if(b.t1<=0){b.t1=b.phase?3:4;this.zone(b.x-24,16,.5,b.dmg*1.1,b,'sweep','#ffb040');go('sweep',1,.5,null);return;}}
  /* 0.12.130 THE HOLLOW WRAITH (stage 20). Telegraphed like the Harvest Knight.
     Scythe_Reap (every 3.5s, 2.6s in phase 2): an arc in front.  Soul_Drain (every 9s): a claw grab on one hero: they bleed for 3s and the
     wraith mends a little.  Phase_Dash (every 12s): a streak of cold through the whole party's line.  Spectral_Orbs (every 10s): three
     homing orbs.  Shroud: at half HP it calls up two shades, and everything comes faster. */
  wraithAI(b,dt,al,f){if(!al.length)return;const A=b.act;
    if(!b.phase&&b.hp<b.max*.5){b.phase=1;this.ev('enrage');this.shake=.5;this.fx.push({k:'ring',x:b.x,y:this.G-40,t:0,r:34,c:'#5ae0e8'});for(let i=0;i<2;i++)this.spawnEnemy('zombie',{x:b.x+12+i*10,elite:'roll'});}
    if(A){A.t+=dt;if(!A.done&&A.t>=A.hit){A.done=1;A.fn&&A.fn();}if(A.t>=A.T)b.act=null;return;}
    const go=(name,T,hit,fn)=>{b.act={name,t:0,T,hit,fn};b.anim=1;b.animT=T;};const P=b.phase?.75:1;
    b.t4=(b.t4==null?6:b.t4)-dt;
    if(b.t4<=0){b.t4=12*P;const xs=al.map(h=>this.heroX(h)),x0=Math.min(...xs)-6,x1=Math.max(...xs)+6;this.zone((x0+x1)/2,(x1-x0)/2+8,.7,b.dmg*.9,b,'dash','#5ae0e8');go('dash',.9,.7,()=>{this.shake=Math.max(this.shake,.35);});return;}
    if(b.t3<=0){b.t3=10*P;go('cast',.8,.45,()=>{for(let i=0;i<3;i++){const t=al[Math.floor(this.rng()*al.length)];this.proj.push({enemy:true,kind:'wisp',x:b.x-10,y:b.y-70,tx:t,dmg:b.dmg*.55,src:b,spd:110+i*20,t:0});}});return;}
    if(b.t2<=0){b.t2=9*P;const t=al[Math.floor(this.rng()*al.length)];const tx=this.heroX(t);const z=this.zone(tx,10,.6,b.dmg*.8,b,'drain','#5ae0e8');
      go('claw',.95,.6,()=>{if(t.alive&&Math.abs(this.heroX(t)-tx)<14){if(fleshy(t)){t.bleedT=3;t.bleedDps=b.dmg*.3;t.bleedTick=0;}b.hp=Math.min(b.max,b.hp+b.dmg*1.2);this.text(b.x,this.G-70,'+'+Math.round(b.dmg*1.2),'#5ae0e8');}});return;}
    if(b.t1<=0){b.t1=3.5*P;this.zone(b.x-24,16,.5,b.dmg*1.1,b,'sweep','#5ae0e8');go('sweep',1,.5,null);return;}}
  bossAI(b,dt,sp,f){
    const al=this.alive();const k=b.type;b.walkT+=dt;b.age=(b.age||0)+dt;if(b.age>90&&!b.enraged){b.enraged=1;this.ev('enrage');}if(b.enraged)b.dmg*=1+.012*dt;   // enrage after 90s so fights always end
    const stop=k==='maw'?Math.max(f.x+b.w+30,this.W-96):f.x+b.w+(k==='countess'?14:18);
    if(b.x>stop)b.x-=Math.max(18,b.B.spd)*sp*dt*(k==='maw'?2.2:1.6);
    if(k==='countess')b.y=this.G-40+Math.sin(this.t*1.6)*10;
    b.t1-=dt;b.t2-=dt;b.t3-=dt;
    if(k==='harvest'){if(b.x<=stop+4)this.harvestAI(b,dt,al,f);return;}
    if(k==='wraith'){if(b.x<=stop+4)this.wraithAI(b,dt,al,f);return;}   /* 0.12.127: his own moves, not gated by ABILITIES_OFF */
    if(ABILITIES_OFF){b.t2=b.t3=b.t4=99;}   // bosses keep only their basic attack while abilities are rebuilt
    if(b.x>stop+4)return;
    if(k==='gravelord'){
      if(b.t1<=0){b.t1=2.2;b.anim=1;b.animT=.5;this.hurtHero(f,b.dmg,b);}
      if(b.t2<=0){b.t2=7;b.anim=1;b.animT=.6;this.zone(f.x-14,34,1.3,b.dmg*1.1,b,'slam','#a6ff2e');}
      if(b.t3<=0){b.t3=9;for(let i=0;i<3;i++)this.spawnEnemy('zombie',{x:b.x+10+i*12,hp:CFG.enemies.zombie.hp*this.st.hpMul*.8,max:CFG.enemies.zombie.hp*this.st.hpMul*.8});}
    }else if(k==='countess'){
      if(b.t1<=0){b.t1=1.3;b.anim=1;b.animT=.4;for(let i=0;i<2;i++){const t=al[Math.floor(this.rng()*al.length)];this.proj.push({enemy:true,kind:'batswarm',x:b.x-20,y:b.y-60,tx:t,dmg:b.dmg*.55,src:b,spd:130+i*30,t:0});}}
      if(b.t2<=0){b.t2=8;b.anim=1;b.animT=.6;let tot=0;for(const h of al){const d=b.dmg*.5;this.hurtHero(h,d,b);tot+=d;}b.hp=Math.min(b.max,b.hp+tot*.5);this.fx.push({k:'drainall',t:0,x:b.x,y:b.y-60});}
      b.t4=(b.t4==null?4:b.t4)-dt;if(b.t4<=0){b.t4=6;for(let i=0;i<2;i++){const t=al[Math.floor(this.rng()*al.length)];this.zone(t.x+(this.rng()*12-6),17,1.1,b.dmg*.9,b,'bloodrain','#ff2a3a');}}
      if(b.t3<=0){b.t3=10;for(let i=0;i<3;i++)this.spawnEnemy('zombie',{x:b.x+i*10});}
    }else{
      if(b.t1<=0){b.t1=2.6;b.anim=1;b.animT=.5;const t=al[Math.floor(this.rng()*al.length)];this.zone(t.x,15,1.0,b.dmg*1.25,b,'tentacle','#c050ff');}
      if(b.t2<=0){b.t2=7.5;b.anim=1;b.animT=.8;this.shake=.4;this.fx.push({k:'beamall',t:0,x:b.x,y:b.y-70});for(const h of al)this.hurtHero(h,b.dmg*.6,b);}
      if(b.t3<=0){b.t3=6.5;for(let i=0;i<2;i++)this.spawnEnemy('zombie',{x:b.x-30+i*10});}
    }
  }
  // ---- telegraphed danger zones: marked on the ground, then they hit whoever is still inside
  zone(cx,hw,T,dmg,src,kind,c){const z={cx,hw,T,t:0,dmg,src,kind,c};(this.zones=this.zones||[]).push(z);
    for(const h of this.alive()){const hx=this.heroX(h);if(Math.abs(hx-cx)>hw+4)continue;
      // 0.12.2: the old Reflex stat is gone; the unit's personality decides if, when and how well it steps out (Brain.dangerCall)
      const D=Brain.dangerCall(this,h,z,hx);if(D.react){
        const need=hx<cx?-(hw+8-(cx-hx)):(hw+8-(hx-cx));const out=need*D.mul;h.dodge={at:this.t+D.delay,dx:(h.dodgeX||0)+out,until:this.t+T+.5,spd:D.spd};}
      h.dangerWhy='⚠ '+D.why;h.dangerT=this.t+T+.6;if(!D.react)(z.missed=z.missed||[]).push(h);}
    if(z.missed)Comms.onDanger(this,z,z.missed);
    return z;}
  /* 0.12.68 Elite_Survivors: +10% dodge for Flannel_Man and his companion while they're within 50 world px of each other */
  eliteDodge(h){const fm=h&&h.key==='flannel'?h:h&&h.key==='flannel_pal'?h.owner:null;if(!fm||!fm.alive)return 0;const E=((fm.base.char&&fm.base.char.abilities)||[]).find(a=>a.id==='elite');if(!E)return 0;
    const pal=h.key==='flannel'?(this.pets||[]).find(p=>p.owner===fm&&p.key==='flannel_pal'&&p.alive):h;if(!pal||!pal.alive)return 0;return Math.abs(this.heroX(fm)-this.heroX(pal))<=E.r?E.dodge:0;}
  hurtMinion(m,amt,from){if(!m||m.dead)return;if(m.key==='flannel_pal'&&this.rng()<(m.dodge||0)+this.eliteDodge(m)){this.text(m.x,this.G-40,'dodge','#9ae6ff');return;}m.hp-=amt;m.hitFlash=.12;this.text(m.x,this.G-40,Math.round(amt),'#ffb0b0');}
  heroX(h){return h.x+(h.dodgeX||0)+(h.wanderX||0);}
  obHw(o){return Math.max(3,OBST[o.k].fw*.5*.5*.8);}   // half-width in world px (sheet is 2 px per world px)
  // each obstacle's footprint follows its picture: a rock blocks only under its base; the diagonal log blocks its left end in the near lane and its right end in the far lane
  obSpan(o,l){const F=OBST[o.k].foot;const i=o.lanes.length===2?(l===Math.max(...o.lanes)?0:1):0;const f=F[i]||F[0];return o.flip?[o.x-f[1],o.x-f[0]]:[o.x+f[0],o.x+f[1]];}
  /* shot vs obstacle: the shot has to be in one of its lanes and below the sprite's own outline at that spot (per-column heights baked from the art) */
  obHitsShot(o,p){if(!(o.blk>0))return false;const D=OBST[o.k];if(p.x0!=null&&Math.abs(p.x0-o.x)<D.fw/4+14)return false;   /* shooting from right behind cover: he leans out over it */if(!o.lanes.some(l=>Math.abs(LANES[l]-p.gy)<=3.5))return false;
    if(!D.prof){const l=o.lanes[0];const [a,b]=this.obSpan(o,l);return p.h<=o.blk&&p.x>=a&&p.x<=b;}
    const col=Math.floor((p.x-o.x)*(o.flip?-1:1)+D.fw/4);if(col<0||col>=D.prof.length)return false;return p.h<=D.prof[col]-1;}
  laneBlocked(l,x0,x1){for(const P of this.pools||[]){if(P.fire>0&&Math.abs(P.gy-LANES[l])<P.dz&&P.x1>x0&&P.x0<x1)return {pool:P};}for(const B of this.barrels||[]){if(!B.gone&&B.l===l&&B.x+5>x0&&B.x-5<x1)return {barrel:B};}for(const M of this.mines||[]){if(M===this._ignoreMine||M.owner||!M.armed||!M.spotted)continue;if(M.l===l&&M.x+9>x0&&M.x-9<x1)return {mine:M};if(M.shotgun&&M.avoid&&Math.abs(M.l-l)<=1&&M.x+6>x0&&M.x-SG_SENSE<x1)return {mine:M};}for(const o of this.obst||[]){if(OBST[o.k].flat||OBST[o.k].pass||!o.lanes.includes(l))continue;const [a,b]=this.obSpan(o,l);if(b>x0&&a<x1)return o;}return null;}
  // IF the lane I want is blocked just ahead THEN take the nearest open lane (ties go to whichever way I was already heading)
  freeLane(want,cur,x0,x1){if(!this.laneBlocked(want,x0,x1))return want;let best=null,bd=99;for(let l=0;l<LANES.length;l++){if(this.laneBlocked(l,x0,x1))continue;const d=Math.abs(l-want)+Math.abs(l-cur)*.3;if(d<bd){bd=d;best=l;}}return best==null?want:best;}
  onKillDark(e){
    if(e.hexT>0&&e.hexJ>0){const n=this.enemies.filter(o=>!o.dead&&o!==e&&!(o.hexT>0)&&Math.abs(o.x-e.x)<80).sort((p,q)=>Math.abs(p.x-e.x)-Math.abs(q.x-e.x))[0];
      if(n){n.hexT=e.hexA.dur;n.hexJ=e.hexJ-1;n.hexA=e.hexA;n.hexSrc=e.hexSrc;n.hexTick=0;this.fx.push({k:'bolt',pts:[[e.x,(e.gy||this.G)-14],[n.x,(n.gy||this.G)-14]],t:0,life:.35,raw:1,c:'v'});}}
    for(const h of this.alive()){const CM=h.base&&h.base.char&&(h.base.char.abilities||[]).find(a=>a.id==='communion');if(!CM||Math.abs(this.heroX(h)-e.x)>CM.r)continue;
      h.en=Math.min(h.enMax||100,(h.en||0)+CM.en);this.healHero(h,h.max*CM.heal,true);this.fx.push({k:'soul',x:e.x,y:(e.gy||this.G)-12,tx:this.heroX(h),ty:(h.gy||this.G)-20,t:0,life:.6,raw:1});}}
  stepDark(dt,scroll){
    for(const e of this.enemies){if(e.dead||!(e.hexT>0))continue;e.hexT-=dt;e.hexTick=(e.hexTick||0)+dt;if(e.hexTick>=.5){e.hexTick-=.5;this.hitEnemy(e,e.max*e.hexA.pct*.5,e.hexSrc&&e.hexSrc.alive?e.hexSrc:null,{nocrit:1,sure:1});}
      if(e.fearT>0)e.fearT-=dt;}
    this.stepEng(dt,scroll);
    if(!this.tentacles||!this.tentacles.length)return;
    for(const T of this.tentacles){T.t+=dt;T.x-=scroll*dt;T.aT+=dt;const A=T.A;
      if(T.anim==='emerge'&&T.aT>=.5){T.anim='idle';T.aT=0;}
      // enemies standing on it swat at it (it has 15 HP); IF it drops to 0 THEN it wilts early
      T.swatT-=dt;if(T.swatT<=0&&T.anim!=='death'){T.swatT=1.25;for(const e of this.enemies){if(e.dead||e.fly||e.boss||e.retreatT>0)continue;if(Math.abs(e.x-T.x)<10&&Math.abs((e.gy!=null?e.gy:this.G)-T.gy)<5){T.hp-=e.dmg;T.hitT=.15;if(T.anim!=='attack'){T.anim='hit';T.aT=0;}this.text(T.x,T.gy-40,Math.round(e.dmg),'#c8a0ff');}}}
      if(T.anim==='hit'&&T.aT>=.25){T.anim='idle';T.aT=0;}
      if(T.anim!=='emerge'&&T.anim!=='death')T.hp-=T.max*(A.decay||.05)*dt;
      if(T.heraldT>0){T.heraldT-=dt;T.hp=Math.min(T.max,T.hp+2*dt);}   // Herald crit: +1 HP every 0.5s for 5s   // 0.12.22 (Kyle): it withers 5% of max HP a second; only its life steal keeps it up
      if(T.hp<=0&&T.anim!=='death'){T.anim='death';T.aT=0;}
      if(T.anim==='death'){if(T.aT>=.8)T.done=1;continue;}
      if(T.anim==='attack'&&T.aT>=.6){T.anim='idle';T.aT=0;}
      const big=T.src&&T.src.cthT>0?1.25:1;T.big=big;T.atkT-=dt*big;   /* 0.12.70 Call_of_Cthulhu: 25% bigger, longer reach, 25% faster */
      if(T.anim==='idle'&&T.atkT<=0){const tg=this.enemies.filter(e=>!e.dead&&!e.fly&&Math.abs(e.x-T.x)<=A.reach*big+(e.boss?e.w*.5:0)&&(e.boss||Math.abs((e.gy!=null?e.gy:this.G)-T.gy)<=A.depth)).sort((p,q)=>Math.abs(p.x-T.x)-Math.abs(q.x-T.x))[0];
        if(tg){T.atkT=A.every;T.anim='attack';T.aT=0;T.face=tg.x>=T.x?1:-1;const dir=T.face;
          setTimeoutSafe(this,.32,()=>{if(T.done)return;this.ev('hit',{});this.shake=Math.max(this.shake||0,.15);
            for(const e of this.enemies){if(e.dead||e.fly)continue;const dx=(e.x-T.x)*dir;if(dx>=-4&&dx<=A.reach*(T.big||1)+(e.boss?e.w*.5:0)&&(e.boss||Math.abs((e.gy!=null?e.gy:this.G)-T.gy)<=A.depth)){
              const d=this.hitEnemy(e,(this.rollDice(A.dice)+(A.flat||0)+(T.src.flatRanged||0)*.5)*T.mul,T.src&&T.src.alive?T.src:null,{fromTent:1});if(d)T.hp=Math.min(T.max,T.hp+d*A.steal);/* 0.12.38 (Kyle): heals 20% of the damage it deals */if(d&&!e.dead&&!e.boss){const res=(e.E&&e.E.kbRes)||0;e.kbv=Math.max(e.kbv||0,A.kb/100*40*8*(1-res));e.kbDir=dir;}}}
            this.fx.push({k:'quake',x:T.x+dir*A.reach*.8,gy:T.gy,t:0,life:.4,raw:1});});}}}
    this.tentacles=this.tentacles.filter(T=>!T.done);}
  // 0.12.22 Revive (Kyle): a living hero standing on a downed ally for 5s (4s with a Herald up) helps them back to their feet with 25% HP and 0 energy.
  // 0.12.27 Scavenger (inspiration passive): herbs found on kills or foraged while marching; used on any hurt hero within 17 world px (50 screen px)
  /* 0.12.37 (Kyle): where a searcher stands: in the lane just in front of it, right beside a car's door (a bit toward its front end),
     or practically on top of a rock / stump / log (its middle) */
  searchSpot(o,h){const fl=Math.max(...o.lanes),bl=Math.min(...o.lanes)-1,fr=fl+1<LANES.length?fl+1:-1;const cur=h?h.laneI:fr;   /* the lane right in front of it or right behind it, whichever is closer */
    const nl=fr<0?bl:bl<0?fr:(Math.abs(cur-bl)<Math.abs(cur-fr)?bl:fr);const [a,b]=this.obSpan(o,fl);const mid=(a+b)/2;
    const car=/^car_/.test(o.k);if(OBST[o.k].flat)return {x:mid,lane:fl};const x=car?mid-(o.flip?-1:1)*.16*(b-a):mid;return {x,lane:Math.max(0,nl)};}
  atSpot(h,o){const S=this.searchSpot(o,h);return Math.abs(h.x-S.x)<=(/^car_/.test(o.k)?5:4)&&Math.abs((h.gy||this.G)-LANES[S.lane])<3;}
  obNear(h,o){const l=o.lanes.reduce((b,l)=>Math.abs(LANES[l]-(h.gy||this.G))<Math.abs(LANES[b]-(h.gy||this.G))?l:b,o.lanes[0]);if(Math.abs(LANES[l]-(h.gy||this.G))>7)return false;const [a,b]=this.obSpan(o,l);return h.x>a-9&&h.x<b+9;}
  stepHerbs(dt,scroll){const al=this.alive().filter(o=>!o.pet||true);
    for(const o of al){if(o.herbT>0){o.herbT-=dt;const b0=o.hp;o.hp=Math.min(o.max,o.hp+o.herbHps*dt);if(o.herbSrc&&o.herbSrc.key)this.st8(o.herbSrc).heal+=o.hp-b0;}}
    for(const h of al){const sp=insP(h);if(h.pet)continue;const RE=SEARCH_RE[sp]||/^$/,ST0=(SEARCH_T[sp]||2)*[1,.75,.6][upgT(this.run,'lamp')],full=sp==='herbalist'?(h.herbs||0)>=3:sp==='scavenger'?(h.kit||[]).length>=2:true   /* 0.12.34 (Kyle): Scavenger holds 2 items total */;
      const canAmb=o=>o.k==='car_ambulance'&&!h.medkit;   // 0.12.33: anyone can search an ambulance for a Medkit
      // searching debris: stand next to an unsearched rock/stump/log for 1.5s; chance 45% + 1.2% per Luck (max 95%)
      if(h.search&&h.search.disarm)continue;
      if(h.search){const S=h.search,o=S.o;const near=o&&this.obst&&this.obst.includes(o)&&this.atSpot(h,o);
        const close=!near&&o&&this.obst&&this.obst.includes(o)&&(()=>{const SP=this.searchSpot(o,h);return Math.abs(this.heroX(h)-SP.x)<12&&Math.abs((h.gy||this.G)-LANES[SP.lane])<8;})();   /* 0.12.156: shoved a few px off the spot: pause, step back, keep the job */
        if(close&&!this.exiting&&!o.looted){h.x-=(this.scroll||0)*dt;}
        else if(!near||this.exiting||o.looted){h.search=null;}else{const ST=searchFit(h,o)==='perk'?ST0:2.6*[1,.75,.6][upgT(this.run,'lamp')];S.T=ST;h.pauseT=Math.max(h.pauseT||0,.05);h.x-=(this.scroll||0)*dt*(o.par||1);   /* 0.12.37 (Kyle): searching means standing still at it: he stays with the wreck while the world scrolls */
          if(h.moving){continue;}S.t+=dt;   /* no progress while still moving */
          if(S.t>=(S.T||ST0)){o.looted=1;o.searched=o.searched||{};o.searched[h.key]=1;h.search=null;this.searchLoot(h,o,sp,full,RE);this.supXp(h,o.k==='city_front'||o.k==='city_lootbox'?2:1);}}}
      else{const o=(this.obst||[]).find(o=>(searchFit(h,o)||canAmb(o))&&g_free(o,h)&&this.atSpot(h,o)&&h.plan&&h.plan.intent==='search'&&h.plan.goTo&&h.plan.goTo.ob===o);   /* 0.12.37 (Kyle): searching is a decision (the Brain picked THIS object), never automatic for being in range */if(o){o.searchBy=h;h.search={o,t:0,T:ST0};if(ALARMABLE.test(o.k))this.disturb(o.x,LANES[o.lanes[0]],2,Math.max(.03,(o.k==='city_front'?.4:.25)-.006*(h.luck||0))*(.4+1.2*trait(h,'noise')),o);   /* Loud searchers set alarms off far more often */   /* careful searching: 25% minus luck (about 13% at 20 Luck), blasts are 50% */}}
      if(h.medkit&&!((h.herbCd||0)>this.t)){const thr=.62-.3*trait(h,'energy');const tg=al.filter(o=>fleshy(o)&&o.hp/o.max<thr&&Math.abs(this.heroX(o)-this.heroX(h))<=17&&Math.abs((o.gy||this.G)-(h.gy||this.G))<6).sort((p,q)=>p.hp/p.max-q.hp/q.max)[0];
        if(tg){h.medkit=0;h.herbCd=this.t+.6;this.healHero(tg,tg.max*.35,false,h.medkitCamp?{}:h);h.medkitCamp=0;   /* a Triage-built medkit is the player's doing, not the unit's: it doesn't count toward his healing stat */this.fx.push({k:'mend',x:this.heroX(tg),gy:tg.gy||this.G,t:0,life:.8,raw:1});this.ev('heal',{});if(tg!==h)Comms.bubble(this,h,Comms.pick(['Medkit, hold still!','Patching you up!','Here, take this!']));}}
      // Scavenger: use a Medkit on anyone close under 60%, a Battery on anyone close under 30 energy who has abilities
      if(sp==='scavenger'&&(h.kit||[]).length&&!((h.herbCd||0)>this.t)){const near=al.filter(o=>Math.abs(this.heroX(o)-this.heroX(h))<=17&&Math.abs((o.gy||this.G)-(h.gy||this.G))<6);
        const mi=h.kit.indexOf('med'),bi=h.kit.indexOf('bat');const mt=mi>=0&&near.filter(o=>fleshy(o)&&o.hp/o.max<.72-.3*trait(h,'energy')).sort((p,q)=>p.hp/p.max-q.hp/q.max)[0];
        const bt=bi>=0&&near.filter(o=>o.key==='robot'&&(o.en||0)<42-24*trait(h,'energy')).sort((p,q)=>(p.en||0)-(q.en||0))[0];
        if(mt){h.kit.splice(mi,1);h.herbCd=this.t+.6;this.healHero(mt,mt.max*.25,false,h);this.fx.push({k:'mend',x:this.heroX(mt),gy:mt.gy||this.G,t:0,life:.7,raw:1});this.ev('heal',{});if(mt!==h&&Math.random()<.5)Comms.bubble(this,h,Comms.pick(['Patch up!','Here, a medkit!','Hold still.']));}
        else if(bt){h.kit.splice(bi,1);h.herbCd=this.t+.6;bt.en=Math.min(bt.enMax||100,(bt.en||0)+30);this.fx.push({k:'ring',x:this.heroX(bt),y:this.G-14,r:10,t:0,c:'#ffe060'});if(bt!==h&&Math.random()<.5)Comms.bubble(this,h,'Catch, fresh battery!');}}
      if(!(h.herbs>0)||(h.herbCd||0)>this.t)continue;
      const tg=al.filter(o=>fleshy(o)&&o.hp/o.max<.9-.3*trait(h,'energy')&&!(o.herbT>0)&&Math.abs(this.heroX(o)-this.heroX(h))<=17&&Math.abs((o.gy||this.G)-(h.gy||this.G))<6).sort((p,q)=>p.hp/p.max-q.hp/q.max)[0];
      if(tg){h.herbs--;h.herbCd=this.t+.6;tg.herbT=5;tg.herbSrc=h;tg.herbHps=tg.max*.2/5*(hasPerk(h,'medicine')?1.3:1);this.fx.push({k:'mend',x:this.heroX(tg),gy:tg.gy||this.G,t:0,life:.7,raw:1});this.ev('heal',{});
        if(tg!==h&&Math.random()<.5)Comms.bubble(this,h,Comms.pick(['Here, chew this.','Herb for you!','Hold still.','This\'ll help.','Eat up!']));}}}
  stepDisarm(dt){for(const h of this.alive()){const P=h.plan;if(!P||P.intent!=='disarm'||!P.goTo||!P.goTo.ob)continue;const o=P.goTo.ob;
      if(!(o.alarmT>0)){if(h.search&&h.search.disarm)h.search=null;h.plan=null;h.alDecide=null;h.thinkT=0;continue;}   /* 0.12.102 fix: the alarm is already off (e.g. it ran out while I was down): drop the job and think again */
      if(!this.atSpot(h,o)){const SP=this.searchSpot(o,h);if(h.search&&h.search.disarm&&!(Math.abs(this.heroX(h)-SP.x)<12&&Math.abs((h.gy||this.G)-LANES[SP.lane])<8))h.search=null;continue;}   /* 0.12.156: a small shove pauses the job, it doesn't end it */
      const need=5*(1.15-.3*trait(h,'tech'))*[1,.7,.45][upgT(this.run,'cutters')];   /* 0.12.63 (Kyle): shutting an alarm off takes about 5s (Techy a bit less; Wire Cutters 30%/55% faster) */if(!h.search||!h.search.disarm)h.search={o,t:0,T:need,disarm:1};const S=h.search;h.x-=(this.scroll||0)*dt*(o.par||1);if(!h.moving)S.t+=dt;h.pauseT=Math.max(h.pauseT||0,.05);
      if(S.t>=need){o.alarmT=0;o.alarmN=0;this.supXp(h,2);h.search=null;h.plan=null;h.thinkT=0;this.fx.push({k:'ring',x:o.x,y:LANES[o.lanes[0]]-10,t:0,r:10,c:'#c8d0d8'});Comms.bubble(this,h,Comms.pick(['Alarm\'s off!','Got it!','Quiet, you.','Wires cut!','Silenced!']));}}}
  /* 0.12.51 (Kyle) ENEMY TRAPS: rusted scrap mines on tripwires, 1-5 per stage (0.12.160), dropped in random lanes ahead.
     IF a unit ahead of one rolls under its Perception (Sapper perk helps) THEN it's spotted: marked, called out, and units path around it.
     IF an unspotted one is right underfoot THEN a last-second dodge (better when Perceptive), ELSE it blows: hurts heroes AND zombies nearby.
     IF I have the Sapper perk AND one is spotted AND it's calm around it THEN I may go defuse it (faster when Techy) and keep it as a one-time mine,
     which I plant in front of zombies coming down my lane. */
  stepMines(dt,scroll){if(this.demo)return;this.mines=this.mines||[];this.stepBomblets(dt,scroll);
    if(this.mineAt==null){const n=1+Math.floor(this.rng()*5);   /* 0.12.160 (Kyle): 1-5 traps a stage */this.mineAt=[];for(let i=0;i<n;i++)this.mineAt.push(this.st.len*(.12+.76*this.rng()));this.mineAt.sort((a,b)=>a-b);}
    while(this.mineAt.length&&this.dist>=this.mineAt[0]&&!this.exiting){this.mineAt.shift();let l=Math.floor(this.rng()*LANES.length);for(let k=0;k<5&&this.laneBlocked(l,this.W+20,this.W+44);k++)l=Math.floor(this.rng()*LANES.length);
      {const r=this.rng();this.mines.push({x:this.W+30,l,gy:LANES[l],t:0,armed:true,spotted:false,chk:0,cluster:r<.3,shotgun:r>=.3&&r<.6});}}   /* 0.12.160 (Kyle): 30% cluster mines, 30% tripwire shotguns, 40% rust mines */
    const al=this.alive().filter(h=>!h.pet||h.dog);for(const h of al)this.mineClamp(h);   /* 0.12.156: re-check after dodges and shoves so nobody gets carried onto a mine they know about */
    for(const M of this.mines){M.x-=scroll*dt;M.t+=dt;if(!M.armed)continue;
      if(M.owner){if(M.t<M.arm)continue;if(bombTrig(this,M.x,M.gy))this.mineBoom(M);continue;}   /* 0.12.64: same proximity zone as the Proximity_Bomb */
      if(!M.spotted){M.chk-=dt;if(M.chk<=0){M.chk=1.25;   /* 0.12.191 (Kyle): checked every 1.25s (was 0.8s) */   /* 0.12.64 (Kyle): checked less often (0.5s -> 0.8s) and harder to spot */for(const h of al){const d=M.x-this.heroX(h);if(d<-10||d>85)continue;   /* 0.12.192 (Kyle): spotted from 85 world px out (was 75) */const sp=(hasPerk(h,'sapper')?.3:0)+trait(h,'perc');
          if(this.rng()<(.03+.031*sp+(Math.abs(d)<=15?.02:0))*(M.shotgun?1.6:1)){M.spotted=true;M.avoid=this.rng()<.8;   /* 0.12.203 (Kyle): shotgun traps are easier to spot (x1.6); once seen, most of the time the team routes around its wire */   /* 0.12.194 (Kyle): +2% when it's right in front of them (15 world px; the trigger is 9) */   /* 0.12.193 (Kyle): 3% a check with no Perception, ~6% sharp-eyed, ~7% sharp-eyed with Sapper (+0.3 Perception) */   /* 0.12.189 (Kyle): harder to spot again, about 15 of 27 for a team with no perception (.11 -> .052; was .14 before 0.12.156) */M.by=h;this.fx.push({k:'ring',x:M.x,y:M.gy-3,t:0,r:8,c:'#ff4a3a'});Comms.bubble(this,h,Comms.pick(['Trap!','Mine, watch it!','Tripwire!','Careful, mine!']),true);for(const o of al)o.thinkT=Math.min(o.thinkT||1,.1);break;}}}}
      for(const h of al){if(h.leap||h.rush)continue;if(M.shotgun){const d=M.x-this.heroX(h);if(d<-6||d>SG_SENSE||Math.abs((h.gy||this.G)-M.gy)>11.5)continue;}else if(bombTrig(this,M.x,M.gy,{w0:9,w1:4.5},[h])!==h)continue;   /* 0.12.203 (Kyle): the shotgun's wire covers its lane and the lanes either side, 125px out */   /* 0.12.156 (Kyle): a wider trigger zone (was 6.7 / 3.3) */   /* 0.12.64 (Kyle): 40px wide in its lane, 20px wide one lane up/down (defusers work from 27px out, safely outside it) */
        if(h.defuse&&h.defuse.M===M)continue;
        if(!M.spotted&&!M.dodged){M.dodged=1;if(false){M.spotted=true;h.x-=6;   /* 0.12.191 (Kyle): the last-second catch is gone */   /* 0.12.189: last-second catch a bit rarer too (was .12+.5 perc) */h.pauseT=Math.max(h.pauseT||0,.3);Comms.bubble(this,h,Comms.pick(['Whoa! Trap!','Nearly stepped on that!','MINE!']),true);continue;}}
        if(!M.spotted||this.rng()<dt*8){this.mineBoom(M);break;}}}   /* 0.12.156: a spotted mine still goes off almost at once if you step on it (was ~2 a second) */
    this.mines=this.mines.filter(M=>M.armed&&M.x>-30);
    // defusing (Sapper)
    for(const h of al){const D=h.defuse;if(!D)continue;const M=D.M;const busy=M.armed&&this.mines.includes(M)&&h.search&&h.search.trap&&h.search.t>0;
      if(busy){if(!h.plan||h.plan.intent!=='defuse')h.plan={intent:'defuse',goTo:{mine:M},runMul:.4};h.thinkT=Math.max(h.thinkT||0,.5);   /* 0.12.187 (Kyle): once he starts working on it, nothing pulls him off: only failing (it blows) or going down ends it */
        h.x=M.x-DEFUSE_D-(h.dodgeX||0);h.gy=M.gy;h.kbv=0;h.dodge=null;h.wanderX=0;}
      if(!M.armed||!this.mines.includes(M)||h.plan&&h.plan.intent!=='defuse'){h.defuse=null;if(h.search&&h.search.trap)h.search=null;continue;}
      if(Math.abs(h.x+(h.dodgeX||0)-(M.x-DEFUSE_D))>1.6||Math.abs((h.gy||this.G)-M.gy)>3)continue;h.wanderX=0;   /* 0.12.156 fix: his idle sway kept him off the spot, so defusing never finished; he holds still while he works */   /* defuse from DEFUSE_D (12 px) out: clear of the 9 px trigger even with a 1.6 px wobble */h.pauseT=Math.max(h.pauseT||0,.05);h.x-=scroll*dt;h.moving=false;   /* tiny nudges toward the spot counted as 'moving' and froze his progress */
      h.search=h.search&&h.search.trap?h.search:{o:M,t:0,T:D.need,disarm:1,trap:1};h.search.t+=dt;
      if(h.search.t>=D.need){h.search=null;h.defuse=null;h.plan=null;h.thinkT=0;
        if(this.rng()>defuseOdds(h)){this.mineBoom(M);Comms.bubble(this,h,Comms.pick(['Oh no.','Wrong wire!','Was it the red one?!','Uh oh.']),true);this.st8(h).fumbled=(this.st8(h).fumbled||0)+1;this.failAct(h);continue;}   /* failed: it goes off in his hands */
        M.armed=false;this.st8(h).defused=(this.st8(h).defused||0)+1;this.supXp(h,3);   /* 0.12.151: defusing a trap gives a little XP */
        if(this.rng()<(hasPerk(h,'sapper')?.75:.4)){h.mine=(h.mine||0)+1;this.fx.push({k:'herbget',x:h.x,y:(h.gy||this.G)-26,t:0,life:.9,raw:1,kit:'defib'});Comms.bubble(this,h,Comms.pick(['Disarmed. Mine now.','Got it. I\'ll save this for them.','Wire cut. Keeping it.']),true);}   /* 0.12.52 (Kyle): 75% he keeps the mine */
        else{this.gainParts(null,{x:M.x,lanes:[M.l]});Comms.bubble(this,h,Comms.pick(['Fell apart. Parts, at least.','Busted it. Spare parts.','Not usable, but salvageable.']),true);}}}   /* ...25% it comes apart into spare parts */
    // planting a defused mine in front of zombies coming down my lane
    for(const h of al){const P=h.planting;
      if(P){if(this.enemies.some(e=>!e.dead&&!e.fly&&Math.abs(e.x-this.heroX(h))<16&&Math.abs((e.gy!=null?e.gy:this.G)-(h.gy||this.G))<4)){h.planting=null;this.text(h.x,this.G-70,'interrupted','#9aa');continue;}
        P.t+=dt;h.pauseT=Math.max(h.pauseT||0,.1);if(P.t<P.T)continue;h.planting=null;h.mine--;h.mineCd=this.t+1;const gy=h.gy!=null?h.gy:this.G;const l=LANES.reduce((b,y,i)=>Math.abs(y-gy)<Math.abs(LANES[b]-gy)?i:b,0);
      /* 0.12.54 (Kyle): a planted mine is our own rust mine: 4d4, 60px blast, no stage bonus; its punch comes from who set it (Sapper +25%, Techy up to +30%, Optimal up to +10%, a little Luck) */
      const mult=1+(hasPerk(h,'sapper')?.25:0)+.3*trait(h,'tech')+.1*trait(h,'exec')+.004*Math.max(0,(h.luck||0)-10);
      this.mines.push({x:P.x,l,gy:LANES[l],t:0,armed:true,spotted:true,chk:0,owner:h,mult,arm:.6});Comms.bubble(this,h,Comms.pick(['Mine down!','Step on this.','Present for you!']),true);continue;}
      /* IF I carry a mine AND zombies are coming down my lane (not in my face yet) THEN kneel and plant it in front of me */
      if(!(h.mine>0)||(h.mineCd||0)>this.t||h.search||h.setting)continue;const lane=this.enemies.filter(e=>!e.dead&&!e.fly&&!e.boss&&Math.abs((e.gy!=null?e.gy:this.G)-(h.gy||this.G))<4&&e.x-this.heroX(h)>40&&e.x-this.heroX(h)<190);
      if(!lane.length||this.enemies.some(e=>!e.dead&&Math.abs(e.x-this.heroX(h))<16))continue;h.planting={t:0,T:plantTime(h),x:this.heroX(h)+12};h.mineCd=this.t+.5;}}
  mineBoom(M){if(!M.armed)return;M.armed=false;this.fx.push({k:'boom',x:M.x,gy:M.gy,t:0,life:1.15,raw:1,small:M.cluster?0:1});this.fx.push({k:'ring',x:M.x,y:M.gy-2,t:0,r:20,c:'#ff8a5a'});this.ev('boom',{});this.shake=Math.max(this.shake||0,.4);
    /* 0.12.157 (Kyle): an enemy rust mine is 2d4+4 (+5% a stage), 24 world px blast (72 screen px), full damage in the inner third, 60% out to the edge.
       A CLUSTER mine pops for 2d4+2 in a 30-50 screen px blast and throws 5-6 bomblets 50-150 screen px out either side (random lanes too);
       each arcs, lands, and goes off 0.25s later for 2d4+2 in its own 30-50 screen px blast. Our own planted mines are unchanged (4d4 x who set it). */
    const sc=M.owner?M.mult:(1+.05*(this.st.n-1));
    if(M.shotgun&&!M.owner){this._noDodge=1;try{this.shotgunFire(M,sc);}finally{this._noDodge=0;}return;}
    if(M.cluster&&!M.owner){const R=10+this.rng()*6.7;this.blastAt(M.x,M.gy,R,R*.45,(this.rollDice([2,4])+2)*sc,null,0,1);
      const n=5+(this.rng()<.5?1:0);for(let i=0;i<n;i++){const dir=this.rng()<.5?-1:1,dx=dir*(16.7+this.rng()*33.3),dl=Math.floor(this.rng()*3)-1,l=Math.max(0,Math.min(LANES.length-1,(M.l!=null?M.l:2)+dl));
        (this.bomblets=this.bomblets||[]).push({x0:M.x,gy0:M.gy,x1:M.x+dx,gy1:LANES[l],t:0,...(()=>{const H=9+this.rng()*11;return {H,T:.28+.025*H+this.rng()*.05};})(),fuse:-1,   /* 0.12.159 (Kyle): each bomblet arcs a bit higher or lower, so they land and pop at slightly different times */
        R:10+this.rng()*6.7,dmg:(this.rollDice([2,4])+2)*sc,spin:this.rng()*6});}
      return;}
    const R=M.owner?20:24,RD=M.owner?9:10,dmg=M.owner?this.rollDice([4,4])*sc:(this.rollDice([2,4])+4)*sc;this.blastAt(M.x,M.gy,R,RD,dmg,M.owner&&M.owner.alive?M.owner:null,!!M.owner,!M.owner);}
  /* 0.12.158 (Kyle) TRIPWIRE SHOTGUN: a sawed-off hidden in a bush (a trash pile downtown) aimed back down its lane. Crossing the wire fires a pellet spread
     to the left: 3d4+3 point-blank falling to half at 60 world px (180 screen px) in its lane; one lane over within 40 world px takes half again. Hits zombies too. */
  /* 0.12.158 (Kyle): tripwire shotgun. One loud blast, 7 pellets fanned out to the left, 1d4 each (+5%/stage). Each pellet stops in the first body
     in its path. Anyone hit bleeds (3 per pellet over 4s) and is slowed 30% for 2.5s. Hurts heroes and zombies alike. */
  shotgunFire(M,sc){const RNG=70,N=7,offs=[];for(let i=0;i<N;i++)offs.push((i/(N-1)*2-1)*20+(this.rng()-.5)*14);   /* semi-random: each pellet wobbles inside its slice of the cone */   /* large cone: about two lanes either way at full range */
    this.fx.push({k:'pellets',x:M.x-4,gy:M.gy,t:0,life:.35,raw:1,offs,R:RNG});this.ev('shotgun',{});this.shake=Math.max(this.shake||0,.4);
    const T=[];for(const h of this.alive())T.push({u:h,hero:1,x:this.heroX(h),gy:h.gy||this.G});
    for(const e of this.enemies){if(e.dead||e.fly)continue;T.push({u:e,x:e.x,gy:e.gy!=null?e.gy:this.G});}
    const hits=new Map();
    for(const o of offs){let best=null,bd=1e9;for(const t of T){const dx=M.x-t.x;if(dx<-4||dx>RNG)continue;const py=M.gy+o*Math.max(0,dx)/RNG;if(Math.abs(t.gy-py)>4)continue;if(dx<bd){bd=dx;best=t;}}
      if(best)hits.set(best,(hits.get(best)||0)+1);}
    for(const [t,n] of hits){let d=0;for(let i=0;i<n;i++)d+=this.rollDice([1,4]);d*=sc;const u=t.u;
      if(t.hero){this.hurtHero(u,d,null);if(u.alive){this.bleed(u,3*n,4);u.slow=Math.max(u.slow||0,.3);u.slowT=Math.max(u.slowT||0,2.5);}u.x-=1.5*n*(1-Math.min(.95,u.kbRes||0));}
      else{this.hitEnemy(u,d,null,{sure:1,kb:.15*n});if(!u.dead){u.bleedT=4;u.bleedDps=Math.max(u.bleedDps&&u.bleedT>0?u.bleedDps:0,3*n/4);u.slow=Math.max(u.slow||0,.3);u.slowT=Math.max(u.slowT||0,2.5);}}}}
  blastAt(x,gy,R,RD,dmg,owner,ours,noDodge){const _nd=this._noDodge;if(noDodge)this._noDodge=1;try{this._blastAt(x,gy,R,RD,dmg,owner,ours);}finally{this._noDodge=_nd;}}
  _blastAt(x,gy,R,RD,dmg,owner,ours){const inB=(px,pgy)=>{const dx=px-x,dz=pgy-gy;const q=(dx/R)**2+(dz/RD)**2;return q<=1?(q<=1/9?1:.6):0;};this.igniteAt(x,gy,R);
    for(const h of this.alive()){if(ours&&!this.hardcore)break;const f=inB(this.heroX(h),h.gy||this.G);if(!f)continue;this.hurtHero(h,dmg*f,null);h.x-=Math.sign(x-this.heroX(h)||1)*6*(1-Math.min(.95,h.kbRes||0));}
    for(const e of this.enemies){if(e.dead||e.fly)continue;const f=inB(e.x,e.gy!=null?e.gy:this.G);if(!f)continue;this.hitEnemy(e,dmg*f,owner,{blast:1,bx:x,sure:1});}}
  /* 0.12.216 (Kyle) OIL BARRELS: rusty oil drums sit in a lane like obstacles (can't be looted, block the lane). Shooting one spews an oil pool out the side
     it was hit from: mostly in its own lane, a little into the lanes above and below. Any fire (explosions, flamethrowers, the Warhound's lazer,
     a burning zombie walking in) lights the pools. Past 15 damage the barrel blows: one of the biggest blasts in the game (6d6, about 150px wide)
     and it lights every pool. A burning pool does 1d3 every 0.35s to anyone standing in it (nobody gets the credit) and burns out after 6s.
     Heroes see a burning pool as a wall and walk around/out of it. A shooter only fires at a barrel on purpose when 2+ zombies are next to it
     and no friend is within 150px of it. 0-2 a stage from stage 2. */
  /* 0.12.217 (Kyle) RADIO easter egg: now and then (about 1 stage in 4) a little beat-up radio sits half-hidden at the back edge of the road.
     Units ignore it. The PLAYER can click/tap it: it crackles to life, plays one static-y message (a roast of the crew or something fun,
     with subtitles), then flickers out and dies for good. Spotting them is the minigame. */
  stepRadio(dt,scroll){if(this.demo)return;if(this.radioAt==null){this.radioAt=this.rng()<.25?this.st.len*(.2+.6*this.rng()):-1;}
    if(this.radioAt>0&&this.dist>=this.radioAt&&!this.radio){this.radio={x:this.W+20,gy:LANES[0]-3,state:'idle',t:0,flip:this.rng()<.5};}
    const R=this.radio;if(!R)return;R.x-=scroll*dt;R.t+=dt;if(R.state==='dying'){R.dieT-=dt;if(R.dieT<=0)R.state='dead';}}
  stepBarrels(dt,scroll){if(this.demo)return;this.barrels=this.barrels||[];this.pools=this.pools||[];
    if(this.barAt==null){const n=(this.st.n||1)<2?0:Math.floor(this.rng()*3);this.barAt=[];for(let i=0;i<n;i++)this.barAt.push(this.st.len*(.15+.7*this.rng()));this.barAt.sort((a,b)=>a-b);}
    while(this.barAt.length&&this.dist>=this.barAt[0]&&!this.exiting){this.barAt.shift();let l=Math.floor(this.rng()*LANES.length);for(let k=0;k<5&&this.laneBlocked(l,this.W+20,this.W+44);k++)l=Math.floor(this.rng()*LANES.length);this.barrels.push({x:this.W+30,l,gy:LANES[l],hp:15,dmg:0,wob:0});   /* 0.12.218 (Kyle): 15 HP (was 30) */}
    for(const B of this.barrels){B.x-=scroll*dt;if(B.wob>0)B.wob-=dt;
      if(B.dmg>0&&B.pool&&!B.pool.gone){const fr=Math.min(1,B.dmg/B.hp);B.leakT=(B.leakT||0)-dt*(1+4*fr);if(B.leakT<=0&&(B.oil||0)<70){B.leakT=.5;const P=B.pool;const add=1+2*fr;if(P.x1-P.x0<46){if(B.side>0)P.x1+=add;else P.x0-=add;B.oil=(B.oil||0)+add;}P.t=Math.max(P.t,20);}}   /* 0.12.218 (Kyle): a barrel only holds so much: about 210px of oil in all, then it's empty */   // a holed barrel keeps leaking, faster the worse it's hit
      // units bump into it like an obstacle
      for(const u of this.alive().concat(this.enemies.filter(e=>!e.dead&&!e.fly&&!e.boss))){const ux=u.key?this.heroX(u):u.x,ug=u.gy!=null?u.gy:this.G;if(Math.abs(ug-B.gy)>3.5)continue;const d=ux-B.x;if(Math.abs(d)<5){u.x+=(d>=0?5-d:-5-d);}}
      // a shooter shoots it on purpose: 2+ zombies by it, no friend within 50 world px
      if((B.aimT=(B.aimT||0)-dt)<=0&&B.x>10&&B.x<this.W-6){B.aimT=1;const zs=this.enemies.filter(e=>!e.dead&&!e.fly&&Math.abs(e.x-B.x)<22&&Math.abs((e.gy!=null?e.gy:this.G)-B.gy)<12).length;const safe=!this.alive().some(o=>Math.abs(this.heroX(o)-B.x)<50);
        if(zs>=2&&safe){const sh=this.alive().filter(o=>!o.pet&&o.base&&o.base.char&&o.base.char.ranged&&Math.abs(this.heroX(o)-B.x)<((o.base.char.ranged.range)||150)&&!(o.cast||o.search||o.building)).sort((a,b)=>Math.abs(this.heroX(a)-B.x)-Math.abs(this.heroX(b)-B.x))[0];
          if(sh&&this.rng()<.6+.4*trait(sh,'perc')){const hx=this.heroX(sh);sh.face=B.x>=hx?1:-1;this.fx.push({k:'tracer',x0:hx+sh.face*6,y0:(sh.gy||this.G)-16,x1:B.x,y1:B.gy-6,t:0});this.ev('gun',{});sh.abWhy='SHOOT THE BARREL: '+zs+' zombies by it';sh.abWhyT=this.t+3;this.hitBarrel(B,12,sh.face);if(this.rng()<.5)Comms.bubble(this,sh,Comms.pick(['Shoot the barrel!','Light \'em up!','Bye bye!','Classic.']),true);}}}}
    this.barrels=this.barrels.filter(B=>!B.gone&&B.x>-30);
    for(const P of this.pools){P.x0-=scroll*dt;P.x1-=scroll*dt;if(P.fire>0){P.fire-=dt;P.tick=(P.tick||0)+dt;
        while(P.tick>=.35){P.tick-=.35;const inP=(x,g)=>x>=P.x0&&x<=P.x1&&Math.abs(g-P.gy)<P.dz;
          for(const h of this.alive())if(inP(this.heroX(h),h.gy||this.G))this.hurtHero(h,1+Math.floor(this.rng()*3),null);
          for(const e of this.enemies)if(!e.dead&&!e.fly&&inP(e.x,e.gy!=null?e.gy:this.G)&&!0)this.hitEnemy(e,1+Math.floor(this.rng()*3),null,{sure:1,fire:1,quiet:1});}
        if(P.fire<=0)P.gone=1;}
      else{P.t-=dt;if(P.t<=0)P.gone=1;for(const e of this.enemies)if(!e.dead&&e.burnT>0&&!e.fly&&e.x>=P.x0&&e.x<=P.x1&&Math.abs((e.gy!=null?e.gy:this.G)-P.gy)<P.dz){this.lightPool(P);break;}}}
    this.pools=this.pools.filter(P=>!P.gone&&P.x1>-20);
    // heroes standing in fire step out of it
    for(const h of this.alive()){const hx=this.heroX(h),g=h.gy||this.G;const P=this.pools.find(P=>P.fire>0&&hx>=P.x0-2&&hx<=P.x1+2&&Math.abs(g-P.gy)<P.dz);if(P){const toL=hx-P.x0,toR=P.x1-hx;h.x+=(toL<toR?-1:1)*30*dt;if(this.rng()<dt*.5)Comms.bubble(this,h,Comms.pick(['HOT HOT HOT!','I\'m on fire!','Get out of the fire!']),true);}}}
  hitBarrel(B,d,dir){if(B.gone)return;B.dmg+=d;B.wob=.25;
    const fr=Math.min(1,B.dmg/B.hp);B.side=-(dir||1);
    B.oil=B.oil||0;if(B.oil<70&&(!B.spilled||B.dmg>=B.spilled+Math.max(1.5,5*(1-fr)))){B.spilled=B.dmg;const side=B.side;const w=6+12*fr,cx=B.x+side*(8+w*.6);   // 0.12.218 (Kyle): the closer it is to blowing, the more oil gushes out
      const P={x0:cx-w,x1:cx+w,gy:B.gy,dz:3+1.5*fr,t:25,fire:0,seed:Math.random()*99};this.pools.push(P);B.pool=P;B.oil+=2*w;
      for(const dl of [-1,1]){const l=B.l+dl;if(l<0||l>=LANES.length||this.rng()<.4)continue;this.pools.push({x0:cx-5+side*3,x1:cx+5+side*3,gy:LANES[l],dz:3.5,t:25,fire:0,seed:Math.random()*99});}}
    if(B.dmg>=B.hp)this.barrelBoom(B);}
  barrelBoom(B){if(B.gone)return;B.gone=1;this.fx.push({k:'boom',x:B.x,gy:B.gy,t:0,life:1.4,raw:1,big:1},{k:'ring',x:B.x,y:B.gy-6,t:0,r:40,c:'#ff8a3a'},{k:'slam',x:B.x,gy:B.gy,t:0,life:.9,raw:1,r:40,seed:Math.random()*99});
    this.ev('boom',{big:1});this.shake=Math.max(this.shake||0,1.1);this.blastAt(B.x,B.gy,50,18,this.rollDice([6,6]),null);for(const P of this.pools)if(Math.abs((P.x0+P.x1)/2-B.x)<90)this.lightPool(P);}
  lightPool(P){if(P.fire>0)return;P.fire=6;P.tick=0;}
  igniteAt(x,gy,R){for(const P of this.pools||[])if(!(P.fire>0)&&P.x1>=x-R&&P.x0<=x+R&&Math.abs(P.gy-gy)<R*.6+P.dz)this.lightPool(P);for(const B of this.barrels||[])if(!B.gone&&Math.abs(B.x-x)<R*.8&&Math.abs(B.gy-gy)<R*.5)this.hitBarrel(B,40,B.x>=x?-1:1);}
  /* 0.12.175 Screamer: IF she's on screen AND a hero is within 115 AND she has a shriek left (2, 14s apart) THEN she stops and shrieks for 1.4s.
     Halfway through, the call goes out: 2-4 zombies (+1 every 5 stages, max 6) come running in from the right. Killed or stunned before then: no call. */
  /* 0.12.201 (Kyle) Protect_the_Familia, reworked: an uninterruptible dash straight through everything (immune, sets off no traps) to the
     spot in FRONT of the friend (between them and the nearest zombie). The moment he gets there the immunity ends and the shove happens:
     the friend is pushed back out of the way (a real slide, not a teleport), and only a zombie actually next to where he lands gets
     shield-bashed: 2d4, 1s stun, and sent flying. A bashed zombie that slams into other zombies hurts them (and itself) and shoves them too.
     Shoved friends and zombies set off whatever they slide into (traps, mines): helping can go very wrong. The cooldown starts when he lands. */
  familiaStep(h,dt){const FM=(CHAR[h.key].abilities||[]).find(a=>a.id==='familia'),R=h.rush,o=R.ally;R.t+=dt;h.dodgeX=0;h.wanderX=0;h.kbv=0;h.dodge=null;h.moving=true;h.pauseT=Math.max(h.pauseT||0,.05);
    if((!o.alive&&!o.downed)||o===h){this.familiaEnd(h,null,FM,1);return;}
    const ox=this.heroX(o),og=o.gy!=null?o.gy:this.G;const th=this.enemies.filter(e=>!e.dead&&!e.fly).sort((p,q)=>Math.abs(p.x-ox)-Math.abs(q.x-ox))[0];
    const side=th?(th.x>=ox?1:-1):1,tx=Math.max(6,Math.min(this.W-6,ox+side*12)),dx=tx-h.x,dg=og-h.gy,L=Math.hypot(dx,dg),st=FM.spd*1.6*dt;
    if(L<=st+.5||R.t>2.2){h.x=tx;h.gy=og;this.familiaEnd(h,o,FM,side);return;}
    h.x+=dx/L*st;h.gy+=dg/L*st;h.face=dx<0?-1:1;if(Math.random()<.5)this.fx.push({k:'ring',x:h.x-h.face*4,y:h.gy-8,t:0,r:4,c:'#ffa040'});}
  familiaEnd(h,o,FM,side){h.rush=null;h.rushT=0;h.fmT=FM.cd*(1-(h.cdr||0));   /* cooldown starts once the dash is over */
    if(!o)return;for(const u of [h,o]){u.shield=Math.max(u.shield||0,h.max*FM.shield);u.shieldT=FM.shieldT;}h.face=side;
    const adir=-side;   // the friend goes back, away from the zombies
    if(o.alive){o.kbv=Math.max(o.kbv||0,FM.push*8);o.kbDir=adir;o.thinkT=0;}else{(this.glides=this.glides||[]).push({u:o,v:FM.push*8,dir:adir});for(const u of this.heroes){u.revDecide=null;u.thinkT=0;u.walkTo=null;}}
    const hx=h.x,reach=ENEMY_BODY+22;const be=this.enemies.filter(e=>!e.dead&&!e.fly&&Math.abs((e.gy!=null?e.gy:this.G)-h.gy)<10&&(e.x-hx)*side>-6&&Math.abs(e.x-hx)<=reach).sort((p,q)=>Math.abs(p.x-hx)-Math.abs(q.x-hx))[0];
    if(be){h.animM=.35;h.animMT=.35;this.hitEnemy(be,(this.rollDice(FM.bashDice)+(h.flatMelee||0))*(h.atk/h.base.atk)*h.meleeDmg,h,{kb:0});
      if(!be.dead){const res=be.boss?.9:((be.E&&be.E.kbRes)||0);if(res<1){be.kbv=Math.max(be.kbv||0,FM.bashPush*8*(1-res));be.kbDir=side;be.shoveT=.6;be.shoveSrc=h;be.shoved=new Set([be]);}be.stun=Math.max(be.stun||0,FM.bashStun*(be.boss?.3:1));}
      this.fx.push({k:'slam',x:be.x,gy:be.gy||this.G,t:0,life:.6,raw:1,r:18,seed:Math.random()*99});this.ev('hit',{});this.shake=Math.max(this.shake||0,.15);}
    this.fx.push({k:'ring',x:this.heroX(o),y:(o.gy||this.G)-10,t:0,r:12,c:'#ffa040'});Comms.bubble(this,h,Comms.pick(['Get behind me!','Not my family!','Back up, I got this!','Nobody touches them!']),true);}
  /* a shoved zombie bowling into others: both take 1d4, the one hit is shoved on at half the speed (and can bowl into more) */
  shoveStep(e,dt){e.shoveT-=dt;if(!(e.kbv>30))return;const S=e.shoved||(e.shoved=new Set([e]));
    for(const o of this.enemies){if(o.dead||o.fly||o.boss||S.has(o))continue;if(Math.abs((o.gy!=null?o.gy:this.G)-(e.gy!=null?e.gy:this.G))>8)continue;const d=(o.x-e.x)*(e.kbDir||1);if(d<-2||d>8)continue;
      S.add(o);const src=e.shoveSrc&&e.shoveSrc.alive?e.shoveSrc:null;this.hitEnemy(o,this.rollDice([1,4]),src,{sure:1,nocrit:1});this.hitEnemy(e,this.rollDice([1,4]),src,{sure:1,nocrit:1});
      if(!o.dead){const res=(o.E&&o.E.kbRes)||0;if(res<1){o.kbv=Math.max(o.kbv||0,e.kbv*.5*(1-res));o.kbDir=e.kbDir;o.shoveT=.5;o.shoveSrc=e.shoveSrc;o.shoved=S;}}
      e.kbv*=.6;this.text(o.x,(o.gy||this.G)-30,'THUD','#ffb070');this.fx.push({k:'ring',x:(o.x+e.x)/2,y:(o.gy||this.G)-14,t:0,r:6,c:'#ffb070'});}}
  /* 0.12.206 Giant_Bat: picks a hero, circles above them (a small bob makes it a harder target), swoops down, bites for 1d3 and climbs away */
  batAI(e,dt,scroll,al){if(!al.length){e.x-=scroll*dt;return;}let T=e.target;if(!T||!T.alive||this.rng()<dt*.05)T=e.target=al[Math.floor(this.rng()*al.length)];
    const tx=this.heroX(T),tgy=T.gy||this.G;e.gy=tgy;e.atkT=(e.atkT||0)+dt;e.walkT+=dt;const sp=e.E.spd*(1-(e.slow||0));
    if(e.swoop){const S=e.swoop;S.t+=dt;const u=Math.min(1,S.t/S.T);const dip=Math.sin(Math.PI*u);e.x+=(tx+S.side*2-e.x)*Math.min(1,dt*6)-scroll*dt;e.y=S.y0+(tgy-20-S.y0)*dip;e.face=tx<e.x?-1:1;
      if(!S.hit&&u>=.5){S.hit=1;if(Math.abs(e.x-tx)<14&&T.alive){const d=Math.max(1,Math.floor((1+Math.floor(this.rng()*3))*e.dmgMul));this.hurtHero(T,d,e);}}
      if(u>=1)e.swoop=null;return;}
    e.orb=(e.orb||this.rng()*6)+dt*2.2;const hx=tx+Math.cos(e.orb)*26,hy=tgy-40-Math.sin(e.orb*2)*5+Math.sin(this.t*7+e.phase)*3.5;   // circle above, with a bob
    const dx=hx-e.x,dy=hy-e.y,L=Math.hypot(dx,dy)||1,st=Math.min(L,sp*dt);e.x+=dx/L*st-scroll*dt;e.y+=dy/L*st;e.face=dx<0?-1:1;
    if(e.atkT>=e.E.atk&&Math.abs(e.x-tx)<40&&!(e.stun>0)){e.atkT=0;e.swoop={t:0,T:.75,y0:e.y,side:e.x>tx?1:-1};}}
  screamAI(e,dt,scroll,al){const SC=e.E.scream;if(e.scrCd>0)e.scrCd-=dt;
    if(e.scrT>0){e.x-=scroll*dt;e.scrT-=dt;e.moving=false;e.ringT=(e.ringT||0)-dt;if(e.ringT<=0&&!e.scrDone){e.ringT=.22;this.fx.push({k:'ring',x:e.x+e.face*3,y:(e.gy!=null?e.gy:this.G)-15,t:0,r:14,c:'#ff8a8a'});}
      if(!e.scrDone&&e.scrT<=SC.T*.5){e.scrDone=1;this.screamCall(e);}return true;}
    if(e.x<=this.W-14){if(e.onScrT==null)e.onScrT=5+this.rng()*2;e.onScrT-=dt;}
    if((e.scrN||0)>=SC.max||e.scrCd>0||e.x>this.W-14||!al.length||!(e.onScrT<=0))return false;   /* 0.12.201 (Kyle): she has to be on screen 5-7s before her first shriek */
    let near=null,nd=1e9;for(const h of al){const d=Math.abs(this.heroX(h)-e.x);if(d<nd){nd=d;near=h;}}
    if(!near||nd>SC.r)return false;
    e.scrT=SC.T;e.scrDone=0;e.scrN=(e.scrN||0)+1;e.scrCd=SC.cd;e.face=this.heroX(near)>e.x?1:-1;e.ringT=0;this.ev('shriek',{});this.text(e.x,(e.gy!=null?e.gy:this.G)-30,'SHRIEK!','#ff6a6a');return true;}
  screamCall(e){const SC=e.E.scream,n=this.st.n||1;let k=SC.n[0]+Math.floor(this.rng()*(SC.n[1]-SC.n[0]+1))+Math.floor((n-1)/5);k=Math.min(6,k);
    const live=this.enemies.filter(x=>!x.dead).length;k=Math.max(0,Math.min(k,30-live));
    for(let i=0;i<k;i++)this.spawnEnemy(this.pickType(),{x:this.W+10+this.rng()*40,elite:'roll'});
    if(k)this.text(e.x,(e.gy!=null?e.gy:this.G)-38,'+'+k+' coming!','#ffb0b0');}
  /* 0.12.175 the Soldier's Frag_Grenade going off: the pack's explosion, blast damage (heroes only in Hardcore), and a stun on every zombie caught */
  fragBoom(b){this.fx.push({k:'frag',x:b.x1,gy:b.gy1,t:0,life:.75,raw:1});this.fx.push({k:'ring',x:b.x1,y:b.gy1-2,t:0,r:b.R,c:'#ffd27a'});this.ev('boom',{big:1});this.shake=Math.max(this.shake||0,.4);
    const inB=(px,pgy)=>{const dx=px-b.x1,dz=(pgy-b.gy1)/.45;return dx*dx+dz*dz<=b.R*b.R;};
    const caught=this.enemies.filter(e=>!e.dead&&!e.fly&&inB(e.x,e.gy!=null?e.gy:this.G));this.blastAt(b.x1,b.gy1,b.R,b.R*.45,b.dmg,b.owner&&b.owner.alive?b.owner:null,1);
    for(const e of caught){if(e.dead)continue;e.stun=Math.max(e.stun||0,e.boss?b.stun*.4:b.stun);if(!e.boss)this.text(e.x,(e.gy!=null?e.gy:this.G)-26,'STUN','#ffe07a');}}
  stepBomblets(dt,scroll){const B=this.bomblets;if(!B||!B.length)return;
    for(const b of B){b.x0-=scroll*dt;b.x1-=scroll*dt;if(b.fuse<0){b.t+=dt;b.spin+=dt*14;if(b.t>=b.T){b.fuse=b.fz!=null?b.fz:.25;this.fx.push({k:'puff',x:b.x1,y:b.gy1-1,t:0,life:.3,s:.6});}}
      else{b.fuse-=dt;if(b.fuse<=0){b.done=1;if(b.frag){this.fragBoom(b);continue;}this.fx.push({k:'boom',x:b.x1,gy:b.gy1,t:0,life:.8,raw:1,small:1});this.fx.push({k:'ring',x:b.x1,y:b.gy1-2,t:0,r:b.R,c:'#ffb05a'});this.ev('boom',{});this.shake=Math.max(this.shake||0,.25);this.blastAt(b.x1,b.gy1,b.R,b.R*.45,b.dmg,null,0,1);}}}
    this.bomblets=B.filter(b=>!b.done);}
  /* 0.12.38 what a finished search turns up (each thing is looted once in total).
     Ambulance (anyone): a Medkit (60% + Luck/Perception, if he has none), a Defibrillator (30%, if he has none), spare parts (55%), food or water (30%).
     Scavenger, on any wreck incl. the ambulance (on top of the ambulance table): medkit/battery (max 2), food/water (good odds), spare parts or a little gold.
     Herbalist, on rocks/logs/stumps: an herb (max 3). Food, water and spare parts are camp supplies: they do nothing during the stage. */
  searchLoot(h,o,sp,full,RE){const luck=h.luck||0,perc=trait(h,'perc'),tech=trait(h,'tech');const pick=a=>Comms.pick(a);let got=0;
    const pop=kit=>this.fx.push({k:'herbget',x:h.x,y:(h.gy||this.G)-26,t:0,life:.9,raw:1,kit});
    const ch=Math.min(.95,.35+.012*luck+.3*perc+(sp==='scavenger'?.15*(tech-.5)*2:.15*(.5-tech)*2));
    this.st8(h).searches++;
    if(o.k==='car_ambulance'){
      if(!h.medkit&&this.rng()<Math.min(.95,.6+.01*luck+.2*perc)){h.medkit=1;h.medkitCamp=0;pop('med');got=1;Comms.bubble(this,h,pick(['A medkit!','Jackpot, first aid!','Still sealed!']));}
      if(!h.defib&&this.rng()<.3+.004*luck){h.defib=1;pop('defib');got=1;Comms.bubble(this,h,pick(['A defibrillator!','Paddles! Still charged!','Clear!']));}
      if(this.rng()<.55){this.gainParts(h,o);got=1;}
      if(this.rng()<.3){this.gainSupply(h,o);got=1;}}
    if(o.k==='city_front'){   /* 0.12.119 (Kyle): looting a storefront always pays, by what kind of shop it is */
      const S2=o.shop;got=1;const gold=(a,b)=>{const gd=a+Math.floor(this.rng()*(b-a+1)+luck*.1);this.stageGold+=gd;this.text(o.x,LANES[0]-30,'+'+gd,'#ffd23f');};
      if(S2==='deli'||S2==='liquor'){this.gainSupply(h,o);if(this.rng()<.4)this.gainSupply(h,o);Comms.bubble(this,h,pick(S2==='deli'?['Sandwich meat... still sealed!','Deli\'s got food!']:['Bottled water and... other bottles.','Liquor store run!']));}
      else if(S2==='hardware'){this.gainParts(h,o);this.gainParts(h,o);if(this.rng()<.5)this.gainParts(h,o);Comms.bubble(this,h,pick(['Tools and wire!','Hardware store, jackpot!','Duct tape fixes everything.']));}
      else if(S2==='grocery'){this.gainSupply(h,o);this.gainSupply(h,o);   /* 0.12.140 (Kyle): a grocery always gives 2 */Comms.bubble(this,h,pick(['Canned food!','Bottled water, jackpot!','Still some stock on the shelves!']));}
      else if(S2==='pharmacy'){if(fleshy(h)&&(h.kit||[]).length<2&&this.rng()<.7){(h.kit=h.kit||[]).push('med');pop('med');}else if((h.herbs||0)<3){h.herbs=(h.herbs||0)+1;pop();}if(this.rng()<.4)this.gainSupply(h,o);Comms.bubble(this,h,pick(['Painkillers!','Bandages, nice!','The pharmacy\'s not empty!']));}
      else if(S2==='pawn'){this.gainParts(h,o);if(this.rng()<.5)this.gainParts(h,o);gold(3,8);Comms.bubble(this,h,pick(['Pawn shop goodies!','Tools and scrap!','This was somebody\'s stuff once.']));}
      else{gold(10,22);Comms.bubble(this,h,pick(['The register\'s still full!','Cash drawer!','Money\'s no good now... I\'ll take it anyway.']));}}
    if(o.k==='city_lootbox'){   /* 0.12.119 (Kyle): loot boxes always pay out something, for anyone; a Scavenger digs deeper (below) */
      const r=this.rng();got=1;if(r<.35)this.gainParts(h,o);else if(r<.65)this.gainSupply(h,o);
      else{const gd=5+Math.floor(this.rng()*8+luck*.1);this.stageGold+=gd;this.text(o.x,LANES[o.lanes[0]]-30,'+'+gd,'#ffd23f');}
      if(this.rng()<.25+.005*luck&&(h.kit||[]).length<2&&fleshy(h)){(h.kit=h.kit||[]).push('med');pop('med');}
      Comms.bubble(this,h,pick(['Loot box!','Ooh, what\'s in here?','Supply drop!','Somebody left the good stuff.']));}
    if(sp==='scavenger'&&RE.test(o.k)&&this.rng()<ch){const r=this.rng();got=1;
      if(r<.35){this.gainSupply(h,o);}
      else if(r<.6){this.gainParts(h,o);}
      else if(r<.85&&!full){const it=this.heroes.some(o=>o.key==='robot')&&this.rng()<.4?'bat':'med';   /* 0.12.105 (Kyle): batteries only turn up when there's a Warhound to run on them */(h.kit=h.kit||[]).push(it);pop(it);Comms.bubble(this,h,it==='med'?pick(['Medkit!','Bandages!','First aid!']):pick(['A battery!','Still has juice!','Power cell!']));}
      else{const gd=2+Math.floor(this.rng()*5);this.stageGold+=gd;this.text(o.x,LANES[o.lanes[0]]-30,'+'+gd,'#ffd23f');Comms.bubble(this,h,pick(['Scrap!','Spare change!','Something shiny!']));}}
    else if(sp==='herbalist'&&o.k!=='car_ambulance'&&RE.test(o.k)&&this.rng()<ch&&(h.herbs||0)<3){h.herbs=(h.herbs||0)+1;pop();got=1;Comms.bubble(this,h,pick(['Found one!','An herb!','Aha!','Lucky!']));}
    /* 0.12.58: without the perk for it, a search rarely turns anything up */
    if(!got&&o.k!=='car_ambulance'&&searchFit(h,o)==='weak'){const car=CONTAINER.test(o.k);
      if(car&&sp!=='scavenger'&&this.rng()<Math.min(.4,.14+.004*luck+.1*tech+.05*perc)){got=1;if(this.rng()<.6)this.gainParts(h,o);else this.gainSupply(h,o);}
      else if(!car&&sp!=='herbalist'&&(h.herbs||0)<1&&this.rng()<Math.min(.35,.12+.004*luck+.12*perc)){h.herbs=1;pop();got=1;Comms.bubble(this,h,pick(['Huh, an herb.','Is this one edible?','Found something green.']));}}
    if(!got){this.failAct(h);this.fx.push({k:'poof',x:o.x,y:(LANES[o.lanes[0]])-10,t:0});Comms.bubble(this,h,pick(['Nothing.','Empty.','Just dirt.','Picked clean.']));}}
  gainParts(h,o){const n=1+(this.rng()<.5?1:0);this.stageParts=(this.stageParts||0)+n;this.text(o?o.x:h.x,(o?LANES[o.lanes[0]]:this.G)-30,'+'+n+' PARTS','#c8d0d8');if(h)Comms.bubble(this,h,Comms.pick(['Spare parts!','Useful bits.','Gears and wire!']));}
  gainSupply(h,o){const w=this.rng()<.5;if(w)this.stageWater=(this.stageWater||0)+1;else this.stageFood=(this.stageFood||0)+1;this.text(o?o.x:h.x,(o?LANES[o.lanes[0]]:this.G)-36,w?'+1 WATER':'+1 FOOD',w?'#7fd0ff':'#e8b060');
    if(h)Comms.bubble(this,h,w?Comms.pick(['Clean water!','A bottle!','Water!']):Comms.pick(['Canned food!','Rations!','Still sealed!']));}
  /* 0.12.104 (Kyle): a mechanical check that keeps units on track (no thinking, just "is this job actually moving?").
     Every job a unit walks to (helping someone up, an alarm, a search, a mine, an herb, a pickpocket try) must show progress:
     the unit is getting closer, or the job's own timer is going up. After 6s with neither, the job is dropped, the unit stands up
     and thinks again, and that same target is skipped for 5s. Units that went down or are mid-ability are left alone. */
  stepWatchdog(dt){for(const h of this.heroes)if(h.alertT>0){h.alertT-=dt;if(h.alertT<=0)h.acc-=10;}
    {const S_=this.heroes.find(o=>o.key==='shoshi'&&o.alive);for(const o of this.heroes){const on=!!S_&&o!==S_&&o.alive&&Math.abs(this.heroX(o)-this.heroX(S_))<100;if(on&&!o.olAcc){o.olAcc=1;o.acc+=5;}else if(!on&&o.olAcc){o.olAcc=0;o.acc-=5;}}}   /* Always_Online: target calls on the headset */
    for(const h of this.heroes)if(h.key==='shoshi'){const on=h.alive&&h.pingT>0;if(h.pingT>0)h.pingT-=dt;if(on&&!h.pingOn){h.pingOn=1;h.mvMul+=.4;}else if(!on&&h.pingOn){h.pingOn=0;h.mvMul-=.4;}}   /* Circle_Ping speed */
    for(const h of this.heroes)if(h.cap&&h.cap.adren){const on=h.alive&&h.hp/h.max<.4;if(on&&!h.adrOn){h.adrOn=1;h.meleeSpd+=.25;h.rangedSpd+=.25;h.mvMul+=.15;}else if(!on&&h.adrOn){h.adrOn=0;h.meleeSpd-=.25;h.rangedSpd-=.25;h.mvMul-=.15;}}   /* Adrenaline talent */   /* Radio Shack ALERT wears off */
    const JOB=/^(revive|disarm|search|defuse|herb|sneak)$/;
    for(const u of this.heroes.concat(this.pets||[])){if(!isFinite(u.gy))u.gy=LANES[u.laneI!=null&&LANES[u.laneI]?u.laneI:2];if(!isFinite(u.x))u.x=60;}   /* bad numbers never stick: a unit with no lane height or position gets put back on a lane */
    for(const h of this.alive()){if(h.pet)continue;const P=h.plan;const tgt=P&&(P.reviveD||(P.goTo&&(P.goTo.ob||P.goTo.mine))||P.goTo);
      if(!P||!JOB.test(P.intent||'')||!tgt||h.cast||h.rush){h._wd=null;continue;}
      const prog=(tgt.revT||0)+(h.search&&h.search.t||0)+(tgt.disT||0),dist=Math.abs((tgt.x!=null?tgt.x:h.x)-h.x);
      const W=h._wd;if(!W||W.tgt!==tgt||W.intent!==P.intent){h._wd={tgt,intent:P.intent,t:0,prog,dist};continue;}
      if(prog>W.prog+.05||dist<W.dist-3){W.t=0;W.prog=prog;W.dist=dist;continue;}
      W.t+=dt;
      if(P.intent==='revive'&&W.t>=2.5&&tgt.downed&&dist<60){tgt.x=h.x+(tgt.x>h.x?5:-5);tgt.gy=h.gy||tgt.gy;tgt.laneI=h.laneI!=null?h.laneI:tgt.laneI;W.t=0;W.dist=0;   /* blocked by a wreck or a lane: he reaches over and pulls the body to him */
        if(this.debugWD)this.debugWD.push([h.key,'pull',+this.t.toFixed(1)]);continue;}
      if(W.t<6)continue;
      h._wd=null;h.plan=null;h.thinkT=0;h.revDecide={D:P.reviveD||null,until:this.t+5,go:false};h.alDecide=P.intent==='disarm'?{o:tgt,until:this.t+5,go:false}:h.alDecide;
      if(h.search)h.search=null;if(h.defuse&&P.intent==='defuse')h.defuse=null;h.pauseT=0;h.animM=0;
      if(this.debugWD)this.debugWD.push([h.key,P.intent,+this.t.toFixed(1),Math.round(h.x),Math.round(h.gy||0),tgt.key||tgt.k,Math.round(tgt.x),Math.round(tgt.gy||0),!!tgt.alive,!!tgt.downed,+(tgt.revT||0).toFixed(1),!!(h.riseT>0),h.moving]);}}
  /* 0.12.104 Sandbag Wall (camp item). IF I carry sandbags AND a pack of 4+ is coming down a lane (3+ late in the stage, or 3+ already close)
     THEN heave the wall into that lane, as far out as it can still land in front of them: aim for about 3/4 across the screen
     (mid-to-far right), never behind the zombies, never in my own face. 0.7s heave, then it lands. */
  stepSandbags(dt,scroll){const SB=[null,{hp:70,acc:0,barb:0},{hp:110,acc:8,barb:0},{hp:140,acc:8,barb:3}];
    for(const h of this.alive()){if(!h.sandbag||h.pet)continue;
      if(h.sbThrow){const T=h.sbThrow;T.t+=dt;T.x-=scroll*dt;h.pauseT=Math.max(h.pauseT||0,.05);if(T.t<.7)continue;h.sbThrow=null;
        const A=Object.assign({depth:8,behind:40},SB[h.sandbag]);const B=this.blds=this.blds||[];B.push({bld:1,k:'sandbag',x:T.x,gy:T.gy,hp:A.hp,max:A.hp,A,owner:h,t:0});h.sandbag=0;
        this.fx.push({k:'puff',x:T.x,y:T.gy-2,t:0,life:.6,s:2});this.text(T.x,T.gy-34,'SANDBAGS!','#d8c08a');this.shake=Math.max(this.shake||0,.15);continue;}
      if((h.sbCd||0)>this.t)continue;h.sbCd=this.t+.4;
      const hx=this.heroX(h),live=this.enemies.filter(e=>!e.dead&&!e.fly&&!e.boss&&e.x<this.W+30&&e.x>hx+20);let best=null;
      for(let li=0;li<LANES.length;li++){const l=LANES[li],ln=live.filter(e=>Math.abs((e.gy!=null?e.gy:this.G)-l)<=8);if(!ln.length)continue;
        const front=Math.min(...ln.map(e=>e.x)),close=ln.filter(e=>e.x-hx<110).length;
        if((ln.length>=(this.dist>this.st.len*.6?3:4)||close>=3)&&(!best||ln.length>best.n))best={l,n:ln.length,front};}
      if(!best)continue;if((this.blds||[]).some(b=>b.k==='sandbag'&&b.hp>0&&Math.abs(b.gy-best.l)<=8&&b.x>hx))continue;
      const tx=Math.min(this.W*.78,best.front-14);if(tx<hx+22)continue;   /* too late to get it in front of them */
      h.sbThrow={t:0,x:tx,gy:best.l};h.animM=.5;h.face=1;Comms.bubble(this,h,Comms.pick(['Sandbags out!','Wall going down!','Heads up, bags!']),true);this.ev('whoosh',{});}}
  /* 0.12.104 (Kyle): allies don't walk through a HESCO cell any more. It has a little ladder on its left side: a unit
     that reaches it climbs up and drops down the far side (about 0.9s). Coming back from the right he climbs over it too.
     A Sandbag Wall is low, so it's a quick hop (0.45s). Downed bodies, pets and anyone mid-ability are left alone. */
  stepClimb(dt,scroll){const B=(this.blds||[]).filter(b=>(b.k==='barrier'||b.k==='sandbag')&&b.hp>0);
    for(const h of this.alive()){if(h.dog)continue;const px=h._cpx;h._cpx=h.x;
      if(h.climb){const C=h.climb;C.t+=dt;C.x0-=scroll*dt;C.x1-=scroll*dt;const u=Math.min(1,C.t/C.T);h.x=C.x0+(C.x1-C.x0)*(u<.55?u*.25/.55:.25+(u-.55)/.45*.75);
        h.leapH=C.H*(u<.55?u/.55:Math.max(0,1-(u-.55)/.45*1.2));h.pauseT=Math.max(h.pauseT||0,.05);h.face=C.x1>C.x0?1:-1;h._cpx=h.x;
        if(u>=1){h.climb=null;h.leapH=0;h.x=C.x1;h._cpx=h.x;}continue;}
      if(px==null||h.jet||h.rush||h.perch||h.sbThrow)continue;
      for(const b of B){if(Math.abs((h.gy||this.G)-b.gy)>b.A.depth)continue;const L=b.x-8,R=b.x+9;
        const right=px<L&&h.x>=L,left=px>R&&h.x<=R;if(!right&&!left)continue;
        if(h._tx!=null&&!this.exiting&&(right?h._tx<R+6:h._tx>L-6)){h.x=right?L:R;h._cpx=h.x;break;}   /* only climb when he's actually going somewhere past it; shuffling around next to it, he just stops at it */
        const low=b.k==='sandbag';h.climb={t:0,T:low?.45:.9,x0:right?L:R,x1:right?R+1:L-1,H:low?9:19};h.x=h.climb.x0;h._cpx=h.x;break;}}}
  /* 0.12.107 Shadow_Clone, detached (Kyle). The copy steps out and goes its own way: it picks a zombie that ISN'T the one he's
     fighting (one bothering an ally first, else the nearest other one), runs over at 1.5x his speed and swings his sword for
     `mirror` of a normal hit (40%, 60% with Twin Shadows) on his swing timer. Every zombie it hits turns to fight it for a moment
     (they stop going for the party). It fades when its time runs out or if he goes down. */
  stepClones(dt,scroll){if(!this.clones||!this.clones.length)return;
    for(const c of this.clones){const h=c.owner;c.t+=dt;c.x-=scroll*dt;if(c.animM>0)c.animM-=dt;if(!h.alive||c.t>=c.life){c.done=1;this.fx.push({k:'poof',x:c.x,y:c.gy-20,t:0});continue;}
      const live=this.enemies.filter(e=>!e.dead&&!e.fly&&e.x<this.W+4);const mine=h._mt&&!h._mt.dead?h._mt:null;
      if(!c.tgt||c.tgt.dead){const bother=live.filter(e=>e!==mine&&this.alive().some(o=>o!==h&&!o.pet&&Math.abs(this.heroX(o)-e.x)<26));
        const pool=(bother.length?bother:live.filter(e=>e!==mine)).length?(bother.length?bother:live.filter(e=>e!==mine)):live;
        c.tgt=pool.sort((p,q)=>Math.abs(p.x-c.x)+Math.abs((p.gy||this.G)-c.gy)*2-Math.abs(q.x-c.x)-Math.abs((q.gy||this.G)-c.gy)*2)[0]||null;}
      const T=c.tgt;if(!T){c.moving=false;const hx=this.heroX(h)-(h.face||1)*12;const d=hx-c.x;if(Math.abs(d)>2){c.x+=Math.sign(d)*Math.min(Math.abs(d),(MOVE.chibi||20)*1.5*dt);c.moving=true;c.face=d>0?1:-1;c.walkT+=dt;}continue;}
      const tgy=T.gy!=null?T.gy:this.G;const dx=T.x-c.x-(T.x>c.x?9:-9),dz=tgy-c.gy;c.face=T.x>=c.x?1:-1;
      if(Math.abs(dx)>1.5||Math.abs(dz)>1){const sp=(MOVE.chibi||20)*1.5*dt;c.x+=Math.sign(dx)*Math.min(Math.abs(dx),sp);c.gy+=Math.sign(dz)*Math.min(Math.abs(dz),sp*.6);c.moving=true;c.walkT+=dt;}else c.moving=false;
      c.atkT-=dt;const C=h.base.char;
      if(Math.abs(T.x-c.x)<=12&&Math.abs(tgy-c.gy)<=4&&c.atkT<=0){c.atkT=(C.melee.every||1.2)/((h.meleeSpd||1)*(h.aspd||1));c.animM=.35;
        const roll=(this.rollDice(C.melee.dice)+(C.melee.flat||0)+(h.flatMelee||0))*(h.atk/h.base.atk)*(h.meleeDmg||1)*(h.cryDmg||1);
        this.hitEnemy(T,roll*(c.mirror||.4),h,{nocrit:1});this.fx.push({k:'slash',x:T.x-2,y:(tgy)-20,t:0});
        if(!T.dead&&!T.boss){T.distractT=Math.max(T.distractT||0,.9);T.distractX=c.x;}}}   /* the zombie turns on the clone */
    this.clones=this.clones.filter(c=>!c.done);for(const h of this.heroes)if(h.cloneT>0&&!(this.clones||[]).some(c=>c.owner===h))h.cloneT=0;}
  stepRevive(dt){const downs=this.heroes.filter(h=>!h.alive&&h.downed);   /* 0.12.204: dogs aren't helped up any more */if(!downs.length)return;
    const al=this.alive().filter(o=>!o.pet);const herald=o=>(o.base.char&&o.base.char.abilities||[]).some(a=>a.id==='herald');
    for(const d of downs){if(d.windT&&this.t>=d.windT){d.windT=0;   /* 0.12.202 fix: this shared a name with the Knight's Shield_Wall cooldown, so a downed Knight with Shield_Wall on cooldown got back up free */this.text(d.x,(d.gy||this.G)-40,'SECOND WIND!','#7dff9a');this.revive(d);continue;}
      if(!isFinite(d.gy))d.gy=LANES[d.laneI!=null&&LANES[d.laneI]?d.laneI:2];if(!isFinite(d.x))d.x=60;   /* 0.12.104 fix: the dog's body could end up with no lane height (NaN), so nobody could ever reach it */if(!d.dog){if(d.x<10)d.x=10;if(d.x>this.W-10)d.x=this.W-10;}   /* (a downed dog that scrolls off is still left behind, as before) */if(d.gy!=null){let bi=0;for(let i=1;i<LANES.length;i++)if(Math.abs(LANES[i]-d.gy)<Math.abs(LANES[bi]-d.gy))bi=i;d.laneI=bi;}   /* 0.12.104 fix: a body that was dragged (Protect_the_Familia) or knocked between lanes kept its old lane, so helpers knelt one lane off and never got anywhere */   /* 0.12.104 fix: a body that scrolled to the screen edge stays where helpers can reach it (the dog could slide off-screen and everyone kneeled at the edge forever) */
      const helpers=al.filter(o=>Math.abs(o.x-d.x)<9&&Math.abs((o.gy||this.G)-(d.gy||this.G))<4.5&&!(o.riseT>0));const need=(helpers.some(herald)?4:5)*(1-Math.min(.5,Math.max(0,...helpers.map(o=>o.revBonus||0))))*(1-[0,.2,.4][(!this.demo&&this.run&&upgT(this.run,'stretch'))||0]);d.revNeed=need;   /* 4s when the Herald is the one helping, 5s for everyone else */
      {const df=helpers.find(o=>o.defib);if(df){df.defib=0;this.fx.push({k:'ring',x:d.x,y:(d.gy||this.G)-10,t:0,r:16,c:'#9ad0ff'});this.fx.push({k:'arc',x:d.x,gy:d.gy||this.G,t:0,life:.4,dir:1,raw:1});this.ev('zap',{});Comms.bubble(this,df,Comms.pick(['Clear!','Shocking you awake!','Get up!']),true);this.st8(df).revives++;this.revive(d);continue;}}   /* 0.12.38 Defibrillator: one use, instant revive */
      if(helpers.length){d.revT=(d.revT||0)+dt*(inSmoke(this,d.x,d.gy)?1.25:1);   /* 0.12.199: 25% faster inside the Soldier's smoke */if(!d.revCall){d.revCall=1;Comms.say(this,helpers[0],'reviving',{ally:d});}}
      else{d.revT=Math.max(0,(d.revT||0)-dt*.5);if(d.revT<=0)d.revCall=0;}
      if(d.revT>=need){if(helpers[0]){this.st8(helpers[0]).revives++;for(const o of helpers)this.supXp(o,3.5);}this.revive(d,helpers.some(o=>hasPerk(o,'medicine')));}}}
  revive(h,med){if(h.dog)return;   /* back up with 2 hits */
    const smk=inSmoke(this,h.x,h.gy);h.alive=true;h.downed=0;h.hp=Math.max(1,h.max*((med?.35:.25)+(smk?.15:0)));   /* 0.12.199 (Kyle): picked up inside the Soldier's smoke: +15% HP (40%, 50% with Medicine) */h.en=0;h.revT=0;h.revCall=0;h.riseT=.6;h.riseT0=.6;h.invulnT=2;h.upT=2;h.plan=null;h.thinkT=0;   /* 0.12.243 (Kyle): helped up = 2s untouchable, +20% move speed, and they scramble away from the zombies; all of it ends at 2s */h.bleedT=0;h.hotT=0;
    this.fx.push({k:'ring',x:h.x,y:this.G-10,r:16,t:0,c:'#7dff9a'});this.ev('heal',{});this.text(h.x,this.G-56,'+'+Math.round(h.hp),'#7dff9a');
    Comms.bubble(this,h,Comms.pick(['Thanks!','I\'m up!','Back in it!','Not done yet!','Owe you one!','Still kicking!']));}
  tryResurge(h){if((this.resurgeT||-99)>this.t||h.pet)return false;const D=this.alive().find(o=>o!==h&&o.base&&o.base.char&&(o.base.char.abilities||[]).some(a=>a.id==='resurge'));if(!D)return false;
    const A=D.base.char.abilities.find(a=>a.id==='resurge');this.resurgeT=this.t+(A.icd||25)*(1-(D.cdr||0));h.hp=1;h.invulnT=A.dur;h.bleedT=0;h.hotT=A.dur;h.hotTick=0;h.hotSrc=D;h.hotEvery=.5;h.hotAmt=h.max*A.heal/(A.dur/.5);
    this.fx.push({k:'mend',x:this.heroX(h),gy:h.gy||this.G,t:0,life:1.2,raw:1});this.ev('heal',{});Comms.bubble(this,D,Comms.pick(['Not today!','I\'ve got you!','Stay with me!','Roots, hold!','Not yet!']));return true;}
  robotGat(h,dt,C){const G=h.gat,A=G.A;G.t+=dt;G.acc+=dt;h.pauseT=Math.max(h.pauseT||0,.05);
    const live=this.enemies.filter(e=>!e.dead&&e.x>h.x-6&&e.x-h.x<=A.range);
    while(G.acc>=1/A.rate&&G.t<A.dur){G.acc-=1/A.rate;if(!live.length)break;const tg=live[Math.floor(this.rng()*live.length)];faceToward(h,tg.x,1);
      const dmg=(this.rollDice(A.dice)+(h.flatRanged||0)*.25)*(h.atk/h.base.atk)*h.rangedDmg*(h.cryDmg||1);
      h._accBonus=A.accPen;const p=this.shoot(h,tg,'gat',dmg,{});this.aim(p,h,tg);h._accBonus=0;p.tgy+=(this.rng()*2-1)*A.spreadGy;p.aimH+=(this.rng()*2-1)*A.spreadH;{const dh=(this.rng()*2-1)*(A.startH||0);p.h0=(p.h0!=null?p.h0:p.h)+dh;p.h=p.h0;p.y-=dh*UNIT_SCALE;}h.gatFlash=.05;if(this.rng()<.45)this.ev('gun',{});}
    if(G.t>=A.dur||!live.length&&G.t>.6)h.gat=null;}
  // Arc_Surge: lightning jumps from the blade's target to up to N more enemies nearby
  arcChain(h,from){const A=(h.base.char.abilities||[]).find(a=>a.id==='surge');if(!A)return;let cur=from;const done=new Set([from]);const pts=[[from.x,(from.gy||this.G)-12]];
    for(let i=0;i<A.chains;i++){const nx=this.enemies.filter(e=>!e.dead&&!done.has(e)&&Math.abs(e.x-cur.x)<A.r&&Math.abs((e.gy||this.G)-(cur.gy||this.G))<14).sort((p,q)=>Math.abs(p.x-cur.x)-Math.abs(q.x-cur.x))[0];if(!nx)break;
      done.add(nx);pts.push([nx.x,(nx.gy||this.G)-12]);this.hitEnemy(nx,this.rollDice(A.dice)*(h.atk/h.base.atk)*h.meleeDmg,h,{});if(!nx.dead)nx.stun=Math.max(nx.stun||0,A.stun*(nx.boss?.3:1));cur=nx;}
    if(pts.length>1)this.fx.push({k:'bolt',pts,t:0,life:.28,raw:1});}
  /* 0.12.105 Grenade_Launcher. A lobbed grenade: IF it reaches a zombie in the air THEN it blows on impact. Otherwise it lands,
     and from up high (the watchtower) it comes down hard enough to BOUNCE a couple of times before it settles into a roll, so it
     carries further; from standing height it just rolls. It blows on touching a zombie while rolling, or 0.45s after it stops
     (never later than 3s). Accuracy decides whether the lob is on target or lands a little short or long. */
  launchNade(h,tg,dmg,GL){const hx=this.heroX(h),dir=tg.x>=hx?1:-1;h.face=dir;this.ev('gun',{});
    const acc=h.moving?Math.max(1,h.acc-(h.base.char.ranged.walkPenalty||h.base.char.walkPenalty||0)):h.acc,hit=this.rng()<Math.min(.92,.5+acc/60);
    const off=hit?0:(this.rng()<.5?-1:1)*(8+this.rng()*14);const tx=tg.x+off,tgy=tg.gy!=null?tg.gy:this.G;
    const z0=12+(h.leapH||0),zEnd=hit?9:0,T=Math.max(.35,Math.min(.95,Math.abs(tx-hx)/150)),G=360;
    const N={high:(h.leapH||0)>=25,x:hx+dir*5,gy:h.gy||this.G,gy0:h.gy||this.G,gy1:tgy,z:z0,vx:(tx-hx-dir*5)/T,vz:(zEnd-z0+.5*G*T*T)/T,G,t:0,T,st:'fly',rot:0,bounces:0,dmg,GL,src:h,dir,fuseT:0,life:0};
    (this.glNades=this.glNades||[]).push(N);}
  stepGlNades(dt,scroll){if(!this.glNades||!this.glNades.length)return;
    for(const N of this.glNades){N.life+=dt;N.x-=scroll*dt;N.x+=N.vx*dt;
      const touch=()=>this.enemies.find(e=>!e.dead&&!e.fly&&Math.abs(e.x-N.x)<(e.boss?e.w*.5:5)&&Math.abs((e.gy!=null?e.gy:this.G)-N.gy)<=5&&N.z<20);
      if(N.st==='fly'){N.t+=dt;N.gy=N.gy0+(N.gy1-N.gy0)*Math.min(1,N.t/N.T);N.vz-=N.G*dt;N.z+=N.vz*dt;N.rot+=dt*14*N.dir;
        const e=touch();if(e){this.nadeBoom(N,e);continue;}
        if(N.z<=0){N.z=0;N.gy=N.gy1;const imp=-N.vz;
          if(N.high&&imp>95&&N.bounces<2){N.bounces++;N.vz=imp*.42;N.vx*=.78;this.fx.push({k:'puff',x:N.x,y:N.gy-1,t:0,life:.3,s:.6});}   /* hit hard (from height): bounce */
          else{N.st='roll';N.vz=0;N.vx*=N.bounces?.7:.5;}}}
      else if(N.st==='roll'){N.rot+=N.vx*dt*.35;const fr=70*dt;N.vx=Math.abs(N.vx)<=fr?0:N.vx-Math.sign(N.vx)*fr;
        const e=touch();if(e){this.nadeBoom(N,e);continue;}
        if(N.vx===0){N.fuseT+=dt;if(N.fuseT>=N.GL.fuse){this.nadeBoom(N,null);continue;}}}
      if(N.life>=N.GL.maxT||N.x<-20||N.x>this.W+40)this.nadeBoom(N,null);}
    this.glNades=this.glNades.filter(N=>!N.done);}
  nadeBoom(N,hitE){if(N.done)return;N.done=1;const GL=N.GL,h=N.src&&N.src.alive?N.src:null;this.fx.push({k:'boom',x:N.x,gy:N.gy,t:0,life:.9,raw:1},{k:'crack',x:N.x,gy:N.gy,t:0,life:2.5,raw:1,r:GL.r*.6});this.ev('boom',{});this.shake=Math.max(this.shake||0,.35);
    for(const e of this.enemies){if(e.dead)continue;const dx=Math.max(0,Math.abs(e.x-N.x)-(e.boss?e.w*.4:0)),dz=e.fly?0:Math.abs((e.gy!=null?e.gy:this.G)-N.gy);const d=Math.hypot(dx,dz*1.6);
      const full=e===hitE||d<3;if(!full&&d>GL.r)continue;this.hitEnemy(e,N.dmg*(full?1:GL.splash),h,{sure:1,nocrit:!full,quiet:1});
      if(!e.dead&&!e.boss){const res=(e.E&&e.E.kbRes)||0;e.kbv=Math.max(e.kbv||0,GL.kb/100*40*8*(1-res)*(full?1:.5));e.kbDir=e.x>=N.x?1:-1;}}}
  stepRobot(dt,scroll){
    if(this.bottles&&this.bottles.length){for(const B of this.bottles){B.t+=dt;B.x0-=scroll*dt;B.x1-=scroll*dt;B.rot+=dt*11;const u=Math.min(1,B.t/B.T);B.x=B.x0+(B.x1-B.x0)*u;B.gy=B.gy0+(B.gy1-B.gy0)*u;B.hgt=14*(1-u)+62*Math.sin(Math.PI*u);
        if(u>=1&&!B.done){B.done=1;this.ev('shatter',{});this.fx.push({k:'glass',x:B.x1,gy:B.gy1,t:0,life:.9,raw:1});
          let drawn=0;for(const e of this.enemies){if(e.dead||e.boss||e.fly)continue;if(Math.abs(e.x-B.x1)<=B.A.r&&Math.abs((e.gy!=null?e.gy:this.G)-B.gy1)<=14){e.distractT=B.A.dur;e.distractX=B.x1+(this.rng()*2-1)*6;e.target=null;e.plan=null;drawn++;}}
          this.ev('glass',{n:drawn});}}   /* 0.12.228 (Kyle): a glass smash, then zombie grunts if it pulled any */
      this.bottles=this.bottles.filter(B=>!B.done);}
    if(this.missiles&&this.missiles.length){for(const M of this.missiles){M.t+=dt;M.x0-=scroll*dt;M.tx-=scroll*dt;const u=Math.min(1,M.t/M.T);M.x=M.x0+(M.tx-M.x0)*u;M.gyNow=M.gy+(M.tgy-M.gy)*u;M.hgt=(1-u)*(23+(M.h0||0)*.6)+46*Math.sin(Math.PI*u);
        M.trail-=dt;if(M.trail<=0){M.trail=.035;this.fx.push({k:'puff',x:M.x,y:M.gyNow-M.hgt,t:0,life:.7+this.rng()*.3,s:.6+this.rng()*.5,raw:1});}
        if(u>=1&&!M.done){M.done=1;this.fx.push({k:'boom',x:M.x,gy:M.tgy,t:0,life:.8,raw:1,small:1});this.ev('boom',{});this.shake=Math.max(this.shake||0,.25);
          for(const e of this.enemies){if(e.dead||e.fly)continue;if(Math.abs(e.x-M.x)<=M.A.r+(e.boss?e.w*.5:0)&&(e.boss||Math.abs((e.gy!=null?e.gy:this.G)-M.tgy)<=8))this.hitEnemy(e,(this.rollDice(M.A.dice)+(M.src.flatRanged||0)*.5)*M.mul,M.src&&M.src.alive?M.src:null,{blast:1});}
          if(this.hardcore)for(const o of this.alive()){if(Math.abs(this.heroX(o)-M.x)<=M.A.r&&Math.abs((o.gy||this.G)-M.tgy)<=8)this.hurtHero(o,this.rollDice(M.A.dice)*M.mul*.8,null);}}}   /* Hardcore: missiles don't care whose side you're on */
      this.missiles=this.missiles.filter(M=>!M.done);}
    if(this.nades&&this.nades.length){for(const N of this.nades){N.t+=dt;N.x1-=scroll*dt;N.x0-=scroll*dt;const u=Math.min(1,N.t/N.T);N.x=N.x0+(N.x1-N.x0)*u;N.gyNow=N.gy0+(N.gy-N.gy0)*u;N.hgt=18*(1-u)+22*Math.sin(Math.PI*u);
        if(u>=1&&!N.done){N.done=1;(this.clouds=this.clouds||[]).push({x:N.x1,gy:N.gy,r:N.A.r,t:0,life:N.A.dur,A:N.A,seed:Math.floor(this.rng()*999)});this.ev('wind',{});}}
      this.nades=this.nades.filter(N=>!N.done);}
    if(this.clouds&&this.clouds.length){for(const S of this.clouds){S.t+=dt;S.x-=scroll*dt;const A=S.A;
        for(const e of this.enemies){if(e.dead||e.fly||e.boss)continue;if(Math.abs(e.x-S.x)<S.r&&Math.abs((e.gy!=null?e.gy:this.G)-S.gy)<14){e.smokeT=.25;e.smokeMiss=A.miss||.5;e.slow=Math.max(e.slow||0,A.slow);e.slowT=Math.max(e.slowT||0,.25);}}
        for(const o of this.alive()){if(Math.abs(this.heroX(o)-S.x)<S.r&&Math.abs((o.gy||this.G)-S.gy)<14){o.smokeT=.25;if(A.stealth&&o.key!=='robot'&&!(o.stealthCd>0)){if(!(o.stealthT>0))this.text(o.x,this.G-56,'hidden','#c8d0d8');o.stealthT=A.stealth;}}}}
      this.clouds=this.clouds.filter(S=>S.t<S.life);}
    for(const e of this.enemies){if(e.smokeT>0)e.smokeT-=dt;if(e.markT>0)e.markT-=dt;if(e.rootT>0)e.rootT-=dt;}for(const o of this.alive()){if(o.smokeT>0)o.smokeT-=dt;if(o.stealthT>0)o.stealthT-=dt;if(o.stealthCd>0)o.stealthCd-=dt;}}
  // 0.12.30 car alarms (Kyle): disturbing a wrecked car (a damaging ability's blast nearby, or searching it) has a 50% chance to set off
  //   its alarm, once per car. The alarm blares for 3s and a fresh pack of zombies comes in from the edge, on top of the normal waves.
  disturb(x,gy,r,chance,only){chance=chance==null?.5:chance;for(const o of this.obst||[]){if(only&&o!==only)continue;if(!ALARMABLE.test(o.k)||o.alarmed!=null)continue;const l=o.lanes.reduce((b,l)=>Math.abs(LANES[l]-gy)<Math.abs(LANES[b]-gy)?l:b,o.lanes[0]);
      if(Math.abs(LANES[l]-gy)>r*.5+6)continue;const [a,b]=this.obSpan(o,l);if(x<a-r||x>b+r)continue;
      o.alarmed=this.rng()<chance;if(o.alarmed)this.carAlarm(o);}}
  // 0.12.38: 30s, one zombie every 2s (was 10s / ~1.25s) (a little faster on later stages), up to 8 (+1 per
  //   3 stages). Ignoring it adds about one medium cluster - survivable - but shutting it off in the first few seconds saves most of them.
  carAlarm(o){const other=(this.obst||[]).some(q=>q!==o&&q.alarmT>0&&q.alarmN>0);o.alarmT=30;o.alarmN=other?1:99;   /* 0.12.38 (Kyle): blares up to 30s, a zombie from off-screen every 2s until shut off; a second alarm at the same time only adds 1 */o.alarmEvery=1.6;o.alarmTick=.4;o.alarmScare=1;this.ev(o.k==='city_front'?'bell':'shout',{});this.shake=Math.max(this.shake||0,.45);   /* 0.12.63 (Kyle): scarier: a zombie every 1.6s, the first almost at once, and a harder jolt */
    const sp=this.alive().filter(h=>h.key).sort((p,q)=>Math.abs(p.x-o.x)-Math.abs(q.x-o.x))[0];if(sp){Comms.bubble(this,sp,Comms.pick(o.k==='city_front'?['Burglar alarm!','The store\'s alarm!','Kill that bell!','Every zombie in town heard that!']:['Car alarm!','Shut it off!','Great, now they heard us!','Here they come!','Who touched the car?!']));
      for(const o2 of this.alive())if(o2!==sp&&Math.random()<.4+.5*trait(o2,'listen'))o2.alDecide=null,o2.thinkT=Math.min(o2.thinkT||1,.1);}   // everyone rethinks right away
    for(const h of this.alive())if(Math.abs(this.heroX(h)-o.x)<140)Brain.panic(this,h,'alarm');
    if(this.demo)o.alarmN=0;}
  stepObstacles(dt,scroll){if(!this.obst)this.obst=[];if(this.obNext==null)this.obNext=60+this.rng()*120;
    this.stepRoofs(dt);for(const o of this.obst){o.x-=scroll*dt*(o.par||1);if(o.alarmT>0){o.alarmT-=dt;o.alarmTick-=dt;const age=30-o.alarmT,avol=age<3?1:Math.max(.2,1-(age-3)/4*.8);if(o.alarmV==null)o.alarmV=Math.floor(this.rng()*3);   /* 0.12.203 (Kyle): alarms are loud at first, then settle to a quiet reminder until they're shut off; a few different alarm sounds */
        if(o.k==='city_front'&&(o.bellT=(o.bellT||0)-dt)<=0){o.bellT=1.4;this.ev('bell',{vol:avol});}
        if((o.sirT=(o.sirT||0)-dt)<=0&&o.x>-20&&o.x<this.W+20){o.sirT=[.9,1.1,.8][o.alarmV];this.ev('alarm',{v:o.alarmV,vol:avol*(o.k==='city_front'?.6:1)});}   // the alarm keeps pulling zombies in until it runs out or someone shuts it off
        if(o.alarmTick<=0&&o.alarmN>0&&!this.over&&!this.exiting){o.alarmN--;o.alarmTick=o.alarmEvery||1.25;this.spawnEnemy('zombie',{x:this.W+8+this.rng()*24,elite:'roll',alarm:1});}
        if(o.alarmT<=0)o.alarmN=0;}}
    if(!this.demo)for(const h of this.heroes){if(!h.alive||insP(h)!=='pickpocket'||trait(h,'self')<.75||(h.thiefCd||0)>this.t)continue;const sneaking0=h.plan&&h.plan.intent==='sneak';if(!sneaking0){if((h.thiefChk||0)>this.t)continue;h.thiefChk=this.t+2;}   /* opportunistic check every 2s; a deliberate sneak checks every frame */
      const sneaking=h.plan&&h.plan.intent==='sneak';if(!sneaking&&this.rng()>.06+.3*(trait(h,'self')-.75))continue;
      const v=this.heroes.filter(o=>o!==h&&o.alive&&Math.abs(this.heroX(o)-this.heroX(h))<16&&Math.abs((o.gy||this.G)-(h.gy||this.G))<8).find(o=>(o.defib&&!h.defib)||(o.medkit&&!h.medkit)||((o.kit||[]).length&&(h.kit||[]).length<2)||(o.herbs>0&&(h.herbs||0)<3));if(!v)continue;
      let what;if(v.defib&&!h.defib){v.defib=0;h.defib=1;what='defib';}else if(v.medkit&&!h.medkit){v.medkit=0;h.medkit=1;h.medkitCamp=v.medkitCamp;v.medkitCamp=0;what='medkit';}
      else if((v.kit||[]).length&&(h.kit||[]).length<2){const it=v.kit.pop();(h.kit=h.kit||[]).push(it);what=it==='bat'?'battery':'medicine';}else{v.herbs--;h.herbs=(h.herbs||0)+1;what='herb';}
      h.thiefCd=this.t+18+this.rng()*14;this.fx.push({k:'herbget',x:h.x,y:(h.gy||this.G)-26,t:0,life:.9,raw:1,kit:what==='defib'?'defib':what==='battery'?'bat':what==='herb'?null:'med'});
      const V=Comms.name(v),T=Comms.name(h),r=this.rng();h.thDecide=null;h.plan=null;h.thinkT=0;const caught=this.rng()<Math.min(.95,.2+.5*trait(h,'noise')+.35*trait(v,'perc'));
      const brag=['Finders keepers.','Mine now.','You weren\'t using that, right?','Sharing is caring. Mostly for me.','I\'ll hold onto this '+what+' for you.','Slick.'];
      const caughtL=['Hey! Where\'d my '+what+' go?!',T+', did you just...?','Give that back!','I KNOW you took my '+what+'.','Unbelievable.','Check his pockets!'];
      const reply=['Took what?','Never saw it.','It fell. Into my pocket.','Relax, I\'m holding it for you.','Prove it.','Must\'ve been the zombies.'];
      if(!caught){if(r<.5)Comms.bubble(this,h,Comms.pick(brag),true);}   /* got away with it: maybe a smug mutter */
      else{addMood(v,{listen:-3},20,'robbed');v.robbedBy=h;   /* caught: the victim stops listening to the thief's calls for a while */
        if(r<.5)Comms.bubble(this,v,Comms.pick(caughtL),true);else{Comms.bubble(this,v,Comms.pick(caughtL),true);setTimeoutSafe(this,1.1,()=>{if(h.alive)Comms.bubble(this,h,Comms.pick(reply),true);});}}
      this.st8(h).steals=(this.st8(h).steals||0)+1;}
    if(!this.demo)for(const h of this.heroes)if(h.alive&&h.courage&&this.rng()<dt*.02)Comms.bubble(this,h,Comms.pick(['*hic*','Who wants some?!','I can take \'em all!','*hic* ...what?']),true);   /* Liquid Courage */
    /* 0.12.45 (Kyle): a Pickpocket who is truly Selfish (8+) sometimes lifts what a nearby ally is carrying: a medkit, defib, battery or herb.
     Sometimes the thief brags, sometimes the victim notices, sometimes both. */
    /* 0.12.43 Light-Footed <-> Loud: loud units clanking right past a wreck can set its alarm off, and their racket draws lonely zombies in from off-screen */
    if(!this.demo&&!this.over&&!this.exiting)for(const h of this.alive()){if(!h.key)continue;const nz=trait(h,'noise');if(nz<.3)continue;
      if(h.moving)for(const o of this.obst){if(!/^car_/.test(o.k)||o.alarmed||o.alarmT>0)continue;const l=o.lanes.find(l=>Math.abs(LANES[l]-(h.gy||this.G))<=7);if(l==null)continue;const [a,b]=this.obSpan(o,l);
        if(h.x>a-6&&h.x<b+6&&this.rng()<dt*.05*nz*nz*(h.running?2:1)){o.alarmed=true;this.carAlarm(o);Comms.bubble(this,h,Comms.pick(['Oops.','That wasn\'t me!','My bad!']));}}
      if(!this.boss&&this.enemies.filter(e=>!e.dead).length<20&&this.rng()<dt*.012*nz*nz)this.spawnEnemy('zombie',{x:this.W+10+this.rng()*22,elite:'roll',stray:1});}
    // blasts from damaging abilities disturb wrecks near them (no damage to the car)
    for(const f of this.fx){if(f._dist)continue;f._dist=1;const R={boom:22,quake:18,thorn:8,stuck:6,ring:f.r||0}[f.k];if(R)this.disturb(f.x,f.gy!=null?f.gy:(f.y!=null?f.y+10:this.G),R);}this.obst=this.obst.filter(o=>o.x>-50);
    if(scroll&&!this.exiting)this.spawnFronts();if(scroll&&!this.exiting&&this.dist>=this.obNext&&!(this.boss&&!this.boss.dead)){this.obNext=this.dist+110+this.rng()*230;
      const M=this.mods||{};const city=this.st.biome&&this.st.biome.id==='city';const wOf=(n,w)=>w*(n==='car_ambulance'?(M.amb||1)*(M.cars||1):/^car_/.test(n)?(M.cars||1):/^(rock|log|stump|trunk)/.test(n)?(M.grove||1):1)*(city?(/^car_/.test(n)?2.3:/^city_/.test(n)?1:0):(/^city_moss/.test(n)?0:/^city_crate/.test(n)?.65:n==='city_lootbox'?.8:1));   /* 0.12.119 (Kyle) downtown: vehicles > moss > shops > crates > loot crates. The lake gets the odd crate and a rare loot crate (old camp supplies) */   /* 0.12.119 (Kyle): downtown = wrecked cars, crates, loot boxes and moss; no rocks, logs or trees. The city props stay downtown */
      const tot=OBST_POOL.reduce((s,p)=>s+wOf(p[0],p[1]),0);let r=this.rng()*tot,k='rock_crack';for(const [n,w] of OBST_POOL){if((r-=wOf(n,w))<0){k=n;break;}}const D=OBST[k];
      const x=this.W+40;const near=D.flat?[]:this.obst.filter(o=>Math.abs(o.x-x)<90&&!OBST[o.k].flat&&!OBST[o.k].pass);const used=new Set(near.flatMap(o=>o.lanes));
      for(let tries=0;tries<8;tries++){const l=/^car_/.test(k)?1+Math.floor(this.rng()*(3-D.lanes+1)):Math.floor(this.rng()*(LANES.length-D.lanes+1));   /* 0.12.38 (Kyle): cars only in the middle three lanes */const lanes=D.lanes===2?[l,l+1]:[l];const all=new Set([...used,...lanes]);
        if(all.size>2)continue;const arr=[...all].sort();if(arr.length===2&&arr[1]-arr[0]>1&&near.length)continue;   // never two lanes walled off side by side plus another
        this.obst.push({k,x:x+this.rng()*20,lanes,blk:D.blk,flip:/^car_/.test(k)&&this.rng()<.5});   /* cars can face either way */break;}}}
  /* 0.12.119 (Kyle): lootable storefronts. Each lives at the middle of its building in the downtown backdrop and moves with it (the
     building's parallax speed), so it never drifts off its building or into a gap. As a shop's building scrolls in, ~45% of them are open
     for looting (shown by a gold glint and an alarm bell). */
  /* 0.12.122 (Kyle) storefront rooftops. Two reasons to go up the ladder (1.1s climb, busy while climbing):
     - a crate up there: anyone free goes up, loots it (1.5s) and comes straight back down;
     - a fight: a shooter takes the roof (+6 accuracy, +30% range) while there's something to shoot. IF nothing's in range for 2s, or
       they drop under 30% HP, or the shop scrolls off THEN they climb down. Nobody hangs out up there doing nothing.
     Zombies can get up too: they walk into the shop's front door, vanish inside (1.2s) and come out the stairwell door on the roof
     (at most 2 per roof), then go for whoever's up there. With nobody left up top they hop back down. */
  stepRoofs(dt){for(const o of this.obst||[]){const R=o.roof;if(!R)continue;const hw=(o.bw||36)/2,lx=o.x+hw+1.5;R.dx=0;   /* the roof door is a recessed doorway in the middle of the wall above the roof */
      const off=h=>{if(!h)return;h.perch=null;h.leapH=0;h.roofBusy=0;if(R.acc){h.acc-=R.acc;R.acc=0;}R.occ=null;};
      if(R.occ&&(!R.occ.alive||o.x<10)){off(R.occ);}
      const foes=x=>this.enemies.filter(e=>!e.dead&&e.inside==null&&Math.abs(e.x-x)<170).length;
      if(!R.occ&&o.x>40&&o.x<this.W-30){R.wait=(R.wait||0)-dt;const quiet=this.enemies.filter(e=>!e.dead&&Math.abs(e.x-lx)<50&&!e.onRoof).length<2;
        const free=(h,r)=>!h.pet&&h.key!=='robot'&&!h.perch&&!h.jet&&!h.search&&!h.building&&!h.repairing&&Math.abs(this.heroX(h)-lx)<(r||40)&&h.hp/h.max>.4;
        const near=(L)=>L.sort((p,q)=>Math.abs(this.heroX(p)-lx)-Math.abs(this.heroX(q)-lx))[0];
        let h=null,why=null;
        if(R.crate&&quiet){h=near(this.alive().filter(h=>free(h)));why='crate';}   /* 0.12.124 (Kyle): the crate first */
        if(!h&&R.wait<=0){R.wait=2;const sh=near(this.alive().filter(h=>free(h,60)&&h.base.char&&h.base.char.ranged&&!this.isMeleeHero(h)));if(sh&&foes(lx)>=3&&this.rng()<.25){h=sh;why='fight';}}   /* the high ground second */
        if(h){R.roofP=1;R.occ=h;h.perch=R;h.roofBusy=1;R.st='up';R.t=0;R.why=why;R.idle=0;h.x=lx;h.laneI=0;h.gy=LANES[0];
          Comms.bubble(this,h,Comms.pick(why==='fight'?['Taking the roof!','High ground!','I\'ll cover you from up here.']:['Crate on the roof!','Grabbing that crate.','Be right back down.']),true);}}
      if(R.occ){const h=R.occ;h.laneI=0;h.gy=LANES[0];const lift=Math.max(10,LANES[0]-R.y)/(1.2*UNIT_SCALE);R.t+=dt;   /* 0.12.125: pinned to the back lane while up there so the roof wall draws in front of them */
        const down=()=>{R.st='down';R.t=0;R.dt2=0;h.roofBusy=1;if(R.acc){h.acc-=R.acc;R.acc=0;}};
        const lootCrate=()=>{R.crate=false;R.crateDone=1;this.supXp(h,1.5);const r=this.rng();if(r<.45)this.gainSupply(h,o);else if(r<.8)this.gainParts(h,o);else{const gd=4+Math.floor(this.rng()*7);this.stageGold+=gd;this.text(h.x,R.y-10,'+'+gd,'#ffd23f');}
          Comms.bubble(this,h,Comms.pick(['Rooftop stash!','Someone hid this up here.','Found a crate up top!']));};
        if(R.st==='up'){h.pauseT=Math.max(h.pauseT||0,.05);h.moving=false;h.x+=(lx-h.x)*Math.min(1,dt*12);h.leapH=lift*Math.min(1,R.t/1.1);
          if(R.t>=1.1){R.t=0;if(R.why==='fight'){R.st='fight';h.roofBusy=0;R.acc=6;h.acc+=6;}else R.st='loot';}}
        else if(R.st==='loot'){h.pauseT=Math.max(h.pauseT||0,.05);h.moving=false;h.x+=(o.x-hw*.55-h.x)*Math.min(1,dt*6);h.leapH=lift;if(R.t>=1.5){lootCrate();   /* a shooter with targets stays up to use the height */
          if(h.base.char&&h.base.char.ranged&&!this.isMeleeHero(h)&&foes(h.x)>=1&&h.hp/h.max>.4){R.st='fight';R.t=0;R.idle=0;h.roofBusy=0;R.acc=6;h.acc+=6;Comms.bubble(this,h,Comms.pick(['Staying up, good angle!','Nice view from up here.']),true);}else down();}}
        else if(R.st==='fight'){h.pauseT=Math.max(h.pauseT||0,.05);h.moving=false;h.leapH=lift;const spot=o.x+hw*.25;h.x+=(spot-h.x)*Math.min(1,dt*6);h.face=1;
          if(R.crate&&R.t>1.5)lootCrate();
          R.idle=foes(h.x)?0:R.idle+dt;if(R.idle>2||h.hp/h.max<.3||o.x<16)down();
          else{R.dnT=(R.dnT||0)+dt;if(R.dnT>=2){R.dnT=0;const nd=this.heroes.filter(x=>!x.pet&&!x.alive&&x.downed).length;   /* 0.12.174 (Kyle): every 2s up here, 20% per downed ally to head down and help */
            if(nd&&this.rng()<Math.min(1,.2*nd)){Comms.bubble(this,h,Comms.pick(['Man down! Coming down!','Hang on, I\'m on my way!']),true);down();}}}}
        else{h.pauseT=Math.max(h.pauseT||0,.05);h.moving=false;h.x+=(lx-h.x)*Math.min(1,dt*10);if(Math.abs(h.x-lx)<1.5||R.t>.6){R.dt2=(R.dt2||0)+dt;h.leapH=lift*Math.max(0,1-R.dt2/1);if(R.dt2>=1)off(h);}}}
      if(R.doorT>0)R.doorT-=dt;}}
  /* zombies and storefront roofs: walk in the front door -> vanish -> come out the roof door -> fight whoever's up there -> hop down */
  roofEnemy(e,dt,scroll){if(e.emergeT>0)e.emergeT-=dt;
    if(e.nem&&e.nemHas&&e.nemHas('howl')){e.howlT=(e.howlT==null?4:e.howlT)-dt;if(e.howlT<=0){e.howlT=12;for(let i=0;i<2;i++)this.spawnEnemy('zombie',{x:this.W+10+i*10});this.text(e.x,(e.gy||this.G)-44,'HOWLS!','#ff6a4a');this.ev('shout',{});}}
    if(e.inside!=null){const o=e.roofO;e.inside-=dt;if(o)e.x=o.x;if(e.inside>0&&o&&this.obst.includes(o))return true;
      e.inside=null;if(e.goingDown||!o||!o.roof||!this.obst.includes(o)||!o.roof.occ){e.goingDown=0;e.gy=LANES[0];e.laneI=0;e.roofO=null;if(o)e.x=o.x;e.emergeT=.5;return false;}   /* back out the front door */
      e.onRoof=1;e.rx=o.roof.dx||0;e.gy=o.roof.y;o.roof.doorT=.6;e.atkT2=.6;e.emergeT=.5;return true;}   /* 0.12.130 (Kyle): steps out of the dark doorway faded and brightens */
    if(e.onRoof){const o=e.roofO,R=o&&o.roof;if(!R||!this.obst.includes(o)){e.onRoof=0;e.gy=LANES[0];e.laneI=0;e.roofO=null;return false;}
      const hw=(o.bw||36)/2,occ=R.occ&&R.st!=='down'&&R.st!=='up'?R.occ:null;e.gy=R.y;
      if(occ){const tx=occ.x-o.x-4;const d=tx-e.rx;e.face=d>0?1:-1;if(Math.abs(d)>1){e.rx+=Math.sign(d)*Math.min(Math.abs(d),e.E.spd*(1-(e.slow||0))*dt);e.walkT+=dt;}
        e.atkT2-=dt;if(Math.abs(d)<=2&&e.atkT2<=0){e.atkT2=e.E.atk||1.25;e.animT=.3;const dm=e.E.dmgDie?Math.max(1,Math.floor((1+Math.floor(this.rng()*e.E.dmgDie))*e.dmgMul)):e.dmg;this.hurtHero(occ,dm,e);}e.rIdle=0;}
      else{e.rIdle=(e.rIdle||0)+dt;if(e.rIdle>.6){const d=(R.dx||0)-e.rx;e.face=d>0?1:-1;if(Math.abs(d)>1){e.rx+=Math.sign(d)*Math.min(Math.abs(d),e.E.spd*dt);e.walkT+=dt;}
          else{e.onRoof=0;e.goingDown=1;e.inside=1.2;R.doorT=.6;return true;}}}   /* 0.12.122 (Kyle): nobody left up top: back through the roof door, down the stairs and out the front door */
      e.rx=Math.max(-hw+2,Math.min(hw-2,e.rx));e.x=o.x+e.rx;return true;}
    if(e.roofGo){const o=e.roofO,R=o&&o.roof;if(!R||!R.occ||!this.obst.includes(o)){e.roofGo=0;e.roofO=null;return false;}
      e.x-=scroll*dt;const dx=o.x-e.x,ty=LANES[0];e.face=dx>0?1:-1;const v=e.E.spd*(1-(e.slow||0))*dt;
      if(Math.abs(dx)>1)e.x+=Math.sign(dx)*Math.min(Math.abs(dx),v*1.2);if(Math.abs(e.gy-ty)>.5)e.gy+=Math.sign(ty-e.gy)*Math.min(Math.abs(ty-e.gy),LANE_SPD*dt);e.walkT+=dt;
      if(Math.abs(dx)<3&&Math.abs(e.gy-ty)<1){e.roofGo=0;e.inside=1.2;this.fx.push({k:'puff',x:o.x,y:ty-4,t:0,life:.35,s:1});}return true;}
    // IF a roof has a shooter on it AND fewer than 2 zombies are on their way up THEN a nearby zombie may head for the shop door
    if(!e.boss&&!e.fly&&e.E.undead&&e.gy!=null&&this.rng()<dt*.5){for(const o of this.obst||[]){const R=o.roof;if(!R||!R.occ||R.st!=='fight')continue;if(Math.abs(e.x-o.x)>45)continue;
        const n=this.enemies.filter(q=>!q.dead&&q.roofO===o).length;if(n>=2)continue;e.roofGo=1;e.roofO=o;e.target=null;e.plan=null;return true;}}
    return false;}
  spawnFronts(){if(!(this.st.biome&&this.st.biome.id==='city')||typeof BGA==='undefined'||!BGA.city)return;const L=BGA.city.layers.find(l=>l.shops);if(!L)return;
    const s=L.w/L.r[2],T=L.tile,d=this.dist*L.sp;this.frontSeen=this.frontSeen||{};
    for(const [ax,kind,bw] of L.shops){const base=ax*s-d,k=Math.ceil((this.W+2-base)/T),x=base+k*T;if(x>this.W+30)continue;const id=k+':'+ax;if(this.frontSeen[id])continue;this.frontSeen[id]=1;
      if(this.rng()<.3){const BW=(bw||40)*s;const F={k:'city_front',x,lanes:[0],blk:0,par:L.sp,shop:kind,bw:BW};this.obst.push(F);
        if(this.rng()<.5)F.roof={hp:1,y:L.y+L.front*s-7,crate:this.rng()<.7,occ:null};   /* 0.12.122 (Kyle): some have a flat roof with a ladder up the side and maybe a crate up top */   /* 0.12.121 (Kyle): two pillars stand out front: the only part you can't walk through */
        for(const sd of [-1,1])this.obst.push({k:'city_pillar',x:x+sd*(BW/2-2),lanes:[0],blk:0,par:L.sp,front:1,F,sd});}}}
  // keep bodies out of obstacles: IF a unit ends up inside one in its lane THEN push it out the near side
  /* 0.12.156 (Kyle): heroes don't walk onto a SPOTTED enemy mine: in its lane they stop 11 px short (the trigger reaches 9), one lane over
     they keep 6 px clear. Whoever is defusing it, leaping or jetting is exempt. Unspotted mines still catch them. */
  mineClamp(h){if(!this.mines||h.leap||h.jet||h.perch||h.dog&&false)return;const gy=h.gy;if(gy==null)return;
    for(const M of this.mines){if(M.owner||!M.armed||!M.spotted)continue;if(h.defuse&&h.defuse.M===M)continue;const dz=Math.abs(gy-M.gy);const R=dz<=3.5?11:dz<=11.5?6:0;if(!R)continue;
      if(h.building&&h.walkTo==null)continue;const hx=this.heroX(h),d=hx-M.x;if(Math.abs(d)<R){h.x+=(d>=0?R-d:-R-d);}}}
  obClamp(u,isHero){if(!this.obst||!this.obst.length||u.fly||u.boss)return;const gy=u.gy;if(gy==null)return;
    for(const o of this.obst){if(OBST[o.k].flat||OBST[o.k].pass)continue;const l=o.lanes.find(l=>Math.abs(LANES[l]-gy)<3.5);if(l==null)continue;const pad=isHero?3:2;const [a,b]=this.obSpan(o,l);if(u.x>a-pad&&u.x<b+pad)u.x=(u.x-(a+b)/2)>=0?b+pad:a-pad;}}   // where a hero actually stands right now
  stepZones(dt){
    // beat-'em-up shuffle: everyone drifts a little on their own (bigger while standing and fighting) — can carry them clear of danger by luck
    for(const h of this.heroes){if(!h.alive)continue;const ph=(h.key.length*1.7)%6.3;const amp=this.scroll?3:7;
      h.wanderX=(h.defuse||h.search||(h.building&&h.walkTo==null)||h.repairing||(h.plan&&/^(search|disarm|defuse)$/.test(h.plan.intent||'')))?0:Math.sin(this.t*1.1+ph)*amp+Math.sin(this.t*2.7+ph*2)*amp*.45;}   /* no idle sway while defusing or cutting an alarm */
    if(!this.zones)return;for(const h of this.heroes){if(!h.alive)continue;h.dodgeX=h.dodgeX||0;
      if(h.dodge&&this.t>=h.dodge.at){const tgt=this.t<h.dodge.until?h.dodge.dx:0;const d=tgt-h.dodgeX,st=h.dodge.spd*dt;h.dodgeX+=Math.abs(d)<=st?d:Math.sign(d)*st;h.dodging=Math.abs(d)>1;if(this.t>=h.dodge.until&&Math.abs(h.dodgeX)<.5){h.dodge=null;h.dodgeX=0;}}
      else if(!h.dodge&&h.dodgeX){h.dodgeX*=Math.max(0,1-dt*4);}}
    for(const z of this.zones){z.t+=dt;if(z.t>=z.T&&!z.done){z.done=1;this.shake=Math.max(this.shake,.3);
      this.fx.push(z.kind==='tentacle'?{k:'tentacle',x:z.cx,y:this.G,t:0}:{k:'ring',x:z.cx,y:this.G-4,r:z.hw*1.4,t:0,c:z.c});
      for(const h of this.alive()){const hx=this.heroX(h);if(Math.abs(hx-z.cx)<=z.hw)this.hurtHero(h,z.dmg,z.src);else if(Math.abs(hx-z.cx)<z.hw+12)this.text(hx,this.G-62,'dodged','#9ae6ff');}}}
    this.zones=this.zones.filter(z=>z.t<z.T+.25);}
  // snapshot what carries to the save point
  saveBack(){for(const h of this.heroes){const sv=this.run.heroes[h.key];sv.hpf=h.alive?h.hp/h.max:0;sv.dead=!h.alive;sv.spells=h.spells.map(s=>({card:s.card,arch:s.arch,r:s.r,augs:s.augs||[]}));}}
}
function setTimeoutSafe(g,t,fn){(g.timers=g.timers||[]).push({t,fn});}
const BIGP={};
// where shots leave each hero (px ahead of the hero's x, px above the ground), matched to the strike frame
const MUZZLE={edward:[18,16],knight:[12,16],carcher:[12,15],csorc:[12,15],soldier:[18,16],shoshi:[13,16],eng:[12,14],jp:[13,14],cultist:[10,11],robot:[13,17],lumberjack:[12,15],druid:[14,16],chibi:[10,15],archer:[17,16],flannel:[11,14],flannel_pal:[9,13],vile:[3,30],thing:[14,30],kykar:[15,46],dragons:[18,38],mathas:[17,33],marina:[11,25],thranduil:[12,34],joel:[11,33],robots:[18,33],blood:[13,46],mech:[20,30],weather:[14,47]};
const ARC={kunai:16,dart:6};   // how high each kind is tossed above a straight line (ruler units): kunai lobbed, dart a slight drop
const PSPD={void:165,gat:420,buck:380,leaf:190,dart:330,kunai:200,yarrow:230,bullet:420,arrow:200,quarrel:215,bolt:150,orb:135,fire:150,shard:160,zap:170,wisp:120,plasma:180,blood:140,shell:160,frost:145,brick:190};   // px/s   // ranged shots don't shove, except the thrown brick (a little)
const PCOL={void:'#b05cff',gat:'#ffd27a',buck:'#ffe0a0',skull:'#7dff9a',hex:'#c050ff',bolt:'#ffb040',orb:'#c050ff',arrow:'#e8e0c8',quarrel:'#e8e0c8',fire:'#ff8a1f',shard:'#6ff0ff',zap:'#bfefff',wisp:'#7dff9a',plasma:'#3ff0ff',blood:'#ff2a3a',shell:'#ffd23f',frost:'#9ae6ff',brick:'#c0603a'};

// ======================================================================= RUN / PICKS (pure)
/* 0.12.56: remember who is acting while an ability, proc or signature runs, so heals inside it count as theirs (Medicine Man) */
for(const nm of ['cast','procs','basic','companion','callPal','sigArea','sigShot','sigMulti','sigChain','sigFront','sigMark','sigDrain']){const f=Game.prototype[nm];if(!f)continue;Game.prototype[nm]=function(h){const p=this._healBy;this._healBy=h&&h.key?h:p;try{return f.apply(this,arguments);}finally{this._healBy=p;}};}
function newRun(team,slot){if(slot){slot.gold=0;slot.parts=0;slot._stash=null;for(const k of team){const H=slot.heroes&&slot.heroes[k];if(H&&H.insp&&INSP[H.insp]&&INSP[H.insp].passive==='bankroll')slot.gold+=50;const St=H&&H.insp&&INSP[H.insp]&&INSP[H.insp].stash;if(St){slot.gold+=St.gold||0;slot.parts+=St.parts||0;slot._stash=slot._stash||{food:0,water:0};slot._stash.food+=St.food||0;slot._stash.water+=St.water||0;}}}   /* 0.12.41 (Kyle): every new run starts broke: gold and spare parts reset to 0 */
  if(slot){slot.partySize=3;team=team.slice(0,3);}
  const run={team:team.slice(),stage:1,prestige:0,score:0,xp:0,lv:0,pending:0,rerolls:1,heroes:{},bag:[]};
  if(slot&&slot._stash){run.food=slot._stash.food;run.water=slot._stash.water;delete slot._stash;}   /* deck starting stashes */
  for(const k of team){const d=heroDef(k);run.heroes[k]={hpf:1,dead:false,spells:ABILITIES_OFF||!d.spells.length?[]:[{card:d.spells[0].card,arch:d.spells[0].arch,r:1,augs:[]}],items:[]};}
  return run;
}
function rollRarity(rng,luck,prestige,min){
  const R=CFG.rarity.filter(r=>!(r.minPrestige>prestige));let tot=0;const ws=R.map((r,i)=>{const w=r.w*(i?1+luck*.005:1);tot+=w;return w;});
  let x=rng()*tot;let pick=R[0];for(let i=0;i<R.length;i++){x-=ws[i];if(x<=0){pick=R[i];break;}}
  if(min&&CFG.rarity.indexOf(pick)<CFG.rarity.findIndex(r=>r.id===min))pick=CFG.rarity.find(r=>r.id===min);
  return pick;
}
// ---- loadout: per-hero slots grow with the hero's permanent level; a shared 6-space backpack holds the rest
function slotCaps(lvl){lvl=lvl||1;return {active:lvl>=12?4:lvl>=5?3:2,passive:lvl>=8?2:1,item:CFG.slots.item};}
const BAG_SIZE=6;
function typeOf(e){return e.kind==='item'||ITEM[e.arch]&&!SPELL[e.arch]?'item':SPELL[e.arch].passive?'passive':'active';}
function heroLvl(slot,k){return (slot&&slot.heroes[k]||{lvl:1}).lvl;}
function countType(hv,t){return t==='item'?hv.items.length:hv.spells.filter(s=>!!SPELL[s.arch].passive===(t==='passive')).length;}
function findEntry(run,o){   // equipped on its hero, then the bag
  const hv=run.heroes[o.hero];const list=o.slot==='spell'?hv.spells:hv.items;let e=list.find(x=>x.card===o.card);if(e)return {e,list};
  for(const k of run.team){const L=o.slot==='item'?run.heroes[k].items:[];e=L.find(x=>x.card===o.card&&x.from===o.hero);if(e)return {e,list:L};}
  run.bag=run.bag||[];e=run.bag.find(x=>x.card===o.card&&x.owner===o.hero&&(o.slot==='item')===(x.kind==='item'));return e?{e,list:run.bag,bag:1}:null;}
function owned(run,hk,card,slot){return !!findEntry(run,{hero:hk,card,slot});}
function offers(run,rng,n,opt){
  if(ABILITIES_OFF)return [];
  rng=rng||Math.random;opt=opt||{};const out=[];run.bag=run.bag||[];
  const luck=run.team.reduce((m,k)=>m+heroBase(k,1,3).luck,0)/run.team.length+Object.values(run.heroes).reduce((m,h)=>m+h.spells.filter(s=>s.arch==='insight').reduce((a,s)=>a+s.r,0)+h.items.filter(i=>i.arch==='charm').reduce((a,i)=>a+i.r,0),0);
  const pool=[];const room=run.bag.length<BAG_SIZE;
  for(const k of run.team){const d=heroDef(k),hv=run.heroes[k];
    for(const s of d.spells)if(!owned(run,k,s.card,'spell'))pool.push({kind:'new',slot:'spell',hero:k,card:s.card,arch:s.arch,w:1.1});
    const mine=[...hv.spells.map(e=>['spell',e]),...run.bag.filter(b=>b.owner===k&&b.kind!=='item').map(e=>['spell',e])];   // level-ups are skills only; items come from drops and the merchant
    for(const [sl,e] of mine){if(e.r<CFG.maxRank)pool.push({kind:'up',slot:sl,hero:k,card:e.card,arch:e.arch,w:sl==='spell'?1.5:1.2});
      if(sl==='spell'){const A=SPELL[e.arch].augs.filter(g=>!(e.augs||[]).includes(g));if(A.length&&(e.augs||[]).length<1+Math.floor(e.r/4))pool.push({kind:'aug',slot:'spell',hero:k,card:e.card,arch:e.arch,aug:A[Math.floor(rng()*A.length)],w:.8});}}}
  const used=new Set();
  while(out.length<(n||3)&&pool.length){let tot=pool.reduce((m,p)=>m+p.w,0),x=rng()*tot,i=0;for(;i<pool.length;i++){x-=pool[i].w;if(x<=0)break;}
    const p=pool.splice(Math.min(i,pool.length-1),1)[0];const key=p.hero+p.card+p.kind;if(used.has(key))continue;used.add(key);
    if(opt.blessed){const L=CFG.rarity.find(r=>r.id==='L');const roll=rng()*100;const canL=!(L.minPrestige>run.prestige);   // blessed: 55% Uncommon, 40% Rare, 5% Legendary once unlocked
      p.rar=CFG.rarity.find(r=>r.id===(canL&&roll>=95?'L':roll>=55?'R':'U'));p.blessed=1;}
    else p.rar=rollRarity(rng,luck+(opt.luck||0),run.prestige,opt.min||(p.kind==='aug'?'U':null));out.push(p);}
  return out;
}
// returns 'ok' (equipped or bagged) or 'full' (no slot and no bag room: caller asks what to drop)
function applyOffer(run,o,slot){
  run.bag=run.bag||[];const hv=run.heroes[o.hero];
  if(o.kind==='new'){const e={card:o.card,arch:o.arch,r:o.rar.pts,augs:[]};if(o.slot==='item'){e.proc=procFor(o.card);e.from=o.hero;}
    const t=o.slot==='item'?'item':SPELL[o.arch].passive?'passive':'active';const cap=slotCaps(heroLvl(slot,o.hero))[t];
    if(countType(hv,t)<cap)(o.slot==='spell'?hv.spells:hv.items).push(e);
    else if(run.bag.length<BAG_SIZE)run.bag.push(Object.assign(e,{owner:o.hero,kind:o.slot==='item'?'item':'spell'}));
    else return 'full';}
  else{const f=findEntry(run,o);if(!f)return 'ok';const e=f.e;if(o.kind==='up')e.r=Math.min(CFG.maxRank,e.r+o.rar.pts);else{(e.augs=e.augs||[]).push(o.aug);e.r=Math.min(CFG.maxRank,e.r+o.rar.pts-1);}}
  run.pending=Math.max(0,run.pending-1);return 'ok';
}
// ---- gold + items: items come from drops and the merchant (not level-ups)
function teamItemPool(run){const out=[];for(const k of run.team)for(const it of heroDef(k).items)if(!owned(run,k,it.card,'item'))out.push({hero:k,card:it.card,arch:it.arch});return out;}
// source caps keep the best gear off basic mobs: mob ≤ Uncommon, elite ≤ Rare, boss/merchant can reach Legendary (once unlocked)
const SRC_CAP={mob:'U',elite:'R',boss:'L',shop:'L'};
function itemTier(run){return Math.round(.6*run.stage)+9*(run.prestige||0);}
function rollItem(run,rng,min,src){const pool=teamItemPool(run);if(!pool.length)return null;const p=pool[Math.floor(rng()*pool.length)];
  // odds climb with depth (stage + 9 per prestige); each source has its own table and cap
  const depth=itemTier(run),x=rng(),Lok=!(RAR('L').minPrestige>run.prestige);let id;
  if(src==='shop'||src==='boss'){const pL=Lok?Math.min(.12,.03+.004*depth):0,pR=Math.min(.6,(src==='shop'?.28:.22)+.02*depth);id=x<pL?'L':x<pL+pR?'R':'U';}
  else if(src==='elite'){const pR=Math.min(.35,.06+.012*depth),pU=.45;id=x<pR?'R':x<pR+pU?'U':'C';}
  else{const pU=Math.min(.5,.2+.015*depth);id=x<pU?'U':'C';}
  if(min&&CFG.rarity.findIndex(r=>r.id===id)<CFG.rarity.findIndex(r=>r.id===min))id=min;
  const rar=RAR(id);
  return {hero:p.hero,card:p.card,arch:p.arch,rar:rar.id,tier:depth};}
// Gear Score: rank (rarity + honing) and how deep it was found
function gearScore(e){return Math.round(10*(e.r||1)+4*(e.tier||1));}
function heroGear(hv){return hv.items.reduce((m,e)=>m+gearScore(e),0);}
const RAR=id=>CFG.rarity.find(r=>r.id===id)||CFG.rarity[0];
function itemPrice(rarId,stage){return Math.round({C:45,U:110,R:260,L:700}[rarId]*(1+.108*((stage||1)-1)));}
function honePrice(r,stage){return Math.round(30*(r+1)*(1+.072*((stage||1)-1)));}
function sellValue(it){return Math.round(12*(it.r||1));}
// put an item on its hero / any hero with room, else the bag; returns false if nowhere fits
function giveItem(run,slot,it){run.bag=run.bag||[];const e={card:it.card,arch:it.arch,r:RAR(it.rar).pts,augs:[],proc:procFor(it.card),from:it.hero,tier:it.tier||run.stage,rar:it.rar};
  const order=[it.hero,...run.team.filter(k=>k!==it.hero)];
  for(const k of order){const hv=run.heroes[k];if(hv.items.length<slotCaps(heroLvl(slot,k)).item){hv.items.push(e);return k;}}
  if(run.bag.length<BAG_SIZE){run.bag.push(Object.assign(e,{owner:it.hero,kind:'item'}));return 'bag';}return false;}
function stockShop(run,rng,n){rng=rng||Math.random;const items=[];const used=new Set();for(let i=0;i<(n||4);i++){const it=rollItem(run,rng,'U','shop');if(!it||used.has(it.card))continue;used.add(it.card);items.push(it);}run.shop={stage:run.stage,items};return run.shop;}
// camp actions
function unequip(run,hk,slotName,idx){run.bag=run.bag||[];if(run.bag.length>=BAG_SIZE)return false;const hv=run.heroes[hk];const L=slotName==='item'?hv.items:hv.spells;if(slotName!=='item'&&L.length<=1)return false;
  const e=L.splice(idx,1)[0];run.bag.push(Object.assign(e,{owner:slotName==='item'?(e.from||hk):hk,kind:slotName==='item'?'item':'spell'}));return true;}
function equip(run,slot,bagIdx,hk){const e=run.bag[bagIdx];if(!e)return false;if(e.kind!=='item'&&e.owner!==hk)return false;const hv=run.heroes[hk];const t=typeOf(e);
  if(countType(hv,t)>=slotCaps(heroLvl(slot,hk))[t])return false;run.bag.splice(bagIdx,1);const c=Object.assign({},e);delete c.owner;delete c.kind;(t==='item'?hv.items:hv.spells).push(c);return true;}
function discard(run,where,hk,idx){if(where==='bag'){run.bag.splice(idx,1);return;}const hv=run.heroes[hk];(where==='item'?hv.items:hv.spells).splice(idx,1);}
function describe(o,run,slot){
  const f=findEntry(run,o);const cur=f&&f.e;
  const r0=cur?cur.r:0,r1=o.kind==='new'?o.rar.pts:Math.min(CFG.maxRank,r0+(o.kind==='aug'?o.rar.pts-1:o.rar.pts));
  const b=heroBase(o.hero,heroLvl(slot,o.hero),run.team.length);const a=b.atk*b.pow;const fake={max:b.hp};
  const augs={};for(const g of (cur&&cur.augs)||[])augs[g]=1;if(o.kind==='aug')augs[o.aug]=1;
  let txt;if(o.slot==='spell')txt=SPELL[o.arch].txt(r1,a,{aug:augs},fake,o.hero);else{txt=ITEM[o.arch].txt(r1);const pr=cur?cur.proc:procFor(o.card);if(pr)txt+='. '+PROCS[pr].txt(procChance(r1));}
  let where='';if(o.kind==='new'){const t=o.slot==='item'?'item':SPELL[o.arch].passive?'passive':'active';const hv=run.heroes[o.hero];where=countType(hv,t)<slotCaps(heroLvl(slot,o.hero))[t]?'Equips now':'Goes to the backpack';}
  return {r0,r1,txt,augs:Object.keys(augs),where};
}

// ======================================================================= SAVES
const SKEY='podrundown-crawl-v1';
const Save={
  load(){try{return JSON.parse(localStorage.getItem(SKEY))||{v:1,players:{}};}catch(e){return {v:1,players:{}};}},
  write(d){try{localStorage.setItem(SKEY,JSON.stringify(d));}catch(e){}},
  pinHash(p,pin){return String(strHash('crypt:'+p+':'+pin+':pod'));},
};
const SAVE_EPOCH=2;   // 0.12.1: runs reset when the roster was cut to two heroes   // bump only for a change so big that runs in progress can't be carried over (hero levels still stay)
function migrateSlot(slot,player){
  for(const h of DATA.heroes)if(!slot.heroes[h.key])slot.heroes[h.key]={lvl:1,xp:0};
  for(const k of Object.keys(slot.heroes))if(!heroDef(k))delete slot.heroes[k];
  /* 0.12.249 (Kyle): heroes with their own capstones get any old shared capstone picks refunded, to pick again from their new pair */
  for(const [k,H] of Object.entries(slot.heroes))if(HCAP[k]&&H.tal&&H.tal.some(id=>{const [t,L,b]=id.split(':');return t==='cap'&&!(HCAP[k][L]&&HCAP[k][L][b]);})){H.tal=H.tal.filter(id=>{const [t,L,b]=id.split(':');return t!=='cap'||(HCAP[k][L]&&HCAP[k][L][b]);});H.offer=null;}
  slot.best=slot.best||{score:0,stage:0,prestige:0};slot.gold=slot.gold||0;
  slot.partySize=3;   /* 0.12.33: 3-hero parties again */
  const run=slot.run;if(!run)return slot;
  if((slot.epoch||1)!==SAVE_EPOCH){slot.run=null;slot.epoch=SAVE_EPOCH;return slot;}
  run.team=run.team.filter(k=>heroDef(k));if(!run.team.length){slot.run=null;return slot;}
  if(run.team.length>3){for(const k of run.team.slice(3))delete run.heroes[k];run.team=run.team.slice(0,3);}
  for(const k of run.team){const d=heroDef(k);const hv=run.heroes[k]=run.heroes[k]||{hpf:1,dead:false,spells:[],items:[]};
    const fix=(list,pool)=>{const out=[];for(const e of list){let m=pool.find(x=>x.card===e.card&&x.arch===e.arch)||pool.find(x=>x.card===e.card);
        if(!m)m=pool.find(x=>x.arch===e.arch&&!out.some(o=>o.card===x.card)&&!list.some(o=>o.card===x.card));
        if(!m)m=pool.find(x=>!out.some(o=>o.card===x.card)&&!list.some(o=>o.card===x.card));
        if(m)out.push(Object.assign({},e,{card:m.card,arch:m.arch,augs:(e.augs||[]).filter(g=>SPELL[m.arch]&&SPELL[m.arch].augs.includes(g)),r:Math.min(CFG.maxRank,e.r||1)}));}
      return out;};
    hv.spells=fix(hv.spells||[],d.spells);hv.items=fix(hv.items||[],d.items).slice(0,CFG.slots.item).map(it=>Object.assign(it,{proc:procFor(it.card),augs:[]}));
    if(!hv.spells.length&&d.spells.length)hv.spells=[{card:d.spells[0].card,arch:d.spells[0].arch,r:1,augs:[]}];}
  for(const k of Object.keys(run.heroes))if(!run.team.includes(k))delete run.heroes[k];
  run.bag=(run.bag||[]).filter(b=>heroDef(b.owner)&&(b.kind==='item'?heroDef(b.owner).items:heroDef(b.owner).spells).some(x=>x.card===b.card)).slice(0,BAG_SIZE);
  if(run.stage>CFG.maxStage)run.stage=CFG.maxStage;
  return slot;}
function newSlot(player){const heroes={};for(const h of DATA.heroes)heroes[h.key]={lvl:1,xp:0};return {epoch:SAVE_EPOCH,partySize:3,gold:0,heroes,best:{score:0,stage:0,prestige:0},runs:0,run:null,created:Date.now()};}

// ======================================================================= exports for node sims

// ======================================================================================================================
// 0.12.38 CAMP (Kyle): food & water upkeep, spare parts, camp upgrades (offered 3 at a time, tiered, roguelike: they last the run),
//   Triage crafting, and level-up stat points. Gold, spare parts, supplies and upgrades all belong to the run (gold and parts reset in newRun).
// ======================================================================================================================
/* 0.12.103 (Kyle: average hero damage in stage 1 about 300, healer and utility heroes lower). Scales ALL of a hero's damage: basic attacks, abilities and anything he summons or builds. */
const ENEMY_HP=.54;   /* 0.12.104: .63 -> .52 with the bigger waves, to hold ~300 */   /* every enemy's HP; heroes hit for about .76 of before on average, so time-to-kill stays about the same and the numbers land near 300 */
const HERO_DMG={cheez:.6,edward:.6,knight:.6,carcher:.6,csorc:.55,soldier:.62,shoshi:.95,jp:.48,chibi:.58,archer:.64,flannel:.72,druid:.50,eng:.37,lumberjack:.61,robot:.46,cultist:.36};
const CAMP_UPG={
  water:{name:'Water Filtration System',icon:'💧',tiers:[100,175,275],txt:t=>`${[25,50,75][t-1]}% chance to give one hungry unit water by itself when you get back to camp.`},
  triage:{name:'Triage Station',icon:'🩺',tiers:[125,200,300],txt:t=>`Build a Medkit (${TRIAGE.med[t-1]} spare parts), a Defibrillator (${TRIAGE.defib[t-1]}) or, with the Warhound on the team, a Battery for him (${TRIAGE.bat[t-1]}) for a unit to carry into the next stage. ${t>=3?'Up to 2 builds':'1 build'} per camp.`},
  garden:{name:'Garden Plot',icon:'🌱',tiers:[100,175,275],txt:t=>['50% chance of 1 food each time you get back.','1 food each time you get back.','2 food each time you get back.'][t-1]},
  rain:{name:'Rain Barrels',icon:'🛢️',tiers:[100,175],txt:t=>['50% chance of 1 water each time you get back.','1 water each time you get back.'][t-1]},
  smoker:{name:'Smokehouse',icon:'🍖',tiers:[125],txt:()=>'Smoked rations go further: one food feeds two units.'},
  kitchen:{name:'Camp Kitchen',icon:'🍲',tiers:[200],txt:()=>'Real cooked meals: each food lowers Hunger by 2 tiers instead of 1.'},   /* 0.12.72 food quality */
  purifier:{name:'Water Purifier',icon:'🚰',tiers:[200],txt:()=>'Clean water: each water lowers Thirst by 2 tiers instead of 1.'},   /* 0.12.72 water quality */
  cots:{name:'Med Cots',icon:'🛏️',tiers:[100,175,275],txt:t=>`Everyone rests up: +${[10,20,30][t-1]}% HP when you get back to camp.`},
  bench:{name:'Weapon Bench',icon:'🔧',tiers:[100,200,325],txt:t=>`+${t} damage on every basic attack, melee and ranged.`},
  gen:{name:'Generator',icon:'🔋',tiers:[100,175,275],txt:t=>`Everyone regains energy faster: +${[.25,.5,.75][t-1]} energy per second.`},   // 0.12.63: no tier IV (Radio Tower removed)
  dummy:{name:'Training Dummy',icon:'🎯',tiers:[100,175,275],txt:t=>`+${[10,20,30][t-1]}% XP for everyone.`},
  shrine:{name:'Lucky Shrine',icon:'🍀',tiers:[100,200],txt:t=>`+${[5,10][t-1]} Luck for everyone (better odds when searching).`},
  board:{name:'Bounty Board',icon:'📌',tiers:[100,175,275],txt:t=>`Gold piles are worth ${[25,50,75][t-1]}% more.`},
  yard:{name:'Scrap Yard',icon:'⚙️',tiers:[100,175],txt:t=>`+${t} spare part${t>1?'s':''} each time you get back.`},
  cutters:{name:'Wire Cutters',icon:'✂️',tiers:[100,175],txt:t=>`Shutting a car alarm off is ${[30,55][t-1]}% faster (normally about 5s).`},
  lamp:{name:"Scavenger's Lamp",icon:'🔦',tiers:[100,175],txt:t=>`Searching takes ${[25,40][t-1]}% less time.`},
  kennel:{name:'Guard Dog Kennel',icon:'🐕',tiers:[125,200,300,450],txt:t=>['A guard dog (random breed, each with its own temperament) joins every stage: 6 hits, one back every 12s, bites 10% harder. If it goes down it\'s gone, and the kennel sends a new one 40s later. Eats 0.5 food and 0.5 water every camp.','Your dog bites 20% harder and a little quicker, and dodges more.','Your dog takes 7 hits, gets one back every 8s, and bites 30% harder.','Two dogs out at once (both bite 40% harder).'][t-1]},   // 0.12.65 (Kyle): 4 tiers, two dogs at the top
  tower:{name:'Watchtower',icon:'🗼',tiers:[100,175,275,400],txt:t=>['Scouts the road ahead: each camp, pick 1 of 2 reports to shape the next stage (more ambulances, more loot, fewer zombies...).','3 reports to pick from.','3 reports, and every one is 50% stronger.','MAP TABLE: 4 reports to pick from, and you can follow TWO of them at once.'][t-1]},   /* 0.12.105 (Kyle): the Map Table idea merged in as tier IV */
  still:{name:'Moonshine Still',icon:'🫙',tiers:[125,150,200,225],txt:t=>`Brew Liquid Courage: ${[2,1.5,1,1][t-1]} food + 1 water a jar${t===4?' (a cleaner brew: -15% accuracy instead of -20%, and 15% less damage taken instead of 10%)':''}${t===3?'; 50% chance the buff survives going down':t===4?'; the buff survives going down (only the stage end clears it)':''}, a jar for anyone you can afford. Whoever drinks it fights the next stage with +20% damage, +10% attack speed, 10% less damage taken, -20% accuracy and steadier nerves. *hic*`},   /* 0.12.252 (Kyle): 3 tiers, 125/150/200 gold */
  // 0.12.63 (Kyle): Radio Tower removed
  radio:{name:'Radio Shack',icon:'📻',tiers:[100,175],txt:t=>['A scratchy radio picks up chatter about the road ahead: you see what\'s coming, and the team heads out ready: everyone starts each stage at FULL energy, and the first wave finds them ALERT (+10 accuracy for 5s).','Early warning on every wave (ALERT +10 accuracy for 5s), and once a stage the radio guides in a SUPPLY DROP halfway down the road: food, water and spare parts.'][t-1]},   /* 0.12.246 (Kyle: knowing what's coming was useless when the team is set): Radio Shack reworked */
  jukebox:{name:'Old Jukebox',icon:'🎵',tiers:[60],txt:()=>'Music round the fire: everyone heads out with steadier nerves (+2 Steady for the whole stage), so they panic less.'},   /* 0.12.105 (Kyle): a cheap one */
  stretch:{name:'Stretchers',icon:'🩼',tiers:[100,175],txt:t=>`Helping a downed ally up takes ${[20,40][t-1]}% less time (normally 5s).`},   /* 0.12.102 */
  sandbag:{name:'Sandbag Wall',icon:'🧱',tiers:[100,175,275],txt:t=>['One random hero heads into each stage carrying a Sandbag Wall (70 HP). When a pack comes down the road he heaves it out into their path, toward the far right of the screen: zombies in that lane and the ones next to it can\'t pass until they tear through it.','The wall is heavier (110 HP), and allies standing just behind it get +8 accuracy.','TWO heroes carry one each (140 HP), and they\'re barbed: every swing a zombie takes at the wall costs it 3 HP.'][t-1]},   /* 0.12.104 (Kyle): an item a hero carries in, not a shield */
  forage:{name:'Foraging Packs',icon:'🎒',tiers:[100,175],txt:t=>`Food and water drop from kills ${[15,30][t-1]}% more often.`},   /* 0.12.102 */
  hearth:{name:'Hearth',icon:'🔥',tiers:[90],txt:t=>`Everyone sets out warm: each stage starts with COZY (10s: +0.25 life and energy every 0.5s, +10% melee attack speed and move speed).`},
};
const SCOUT={amb:{name:'Ambulance Route',icon:'🚑',txt:s=>`Ambulances are ${Math.round(1+3*s)}x as likely to turn up.`},
  cars:{name:'Wreck Yard',icon:'🚗',txt:s=>`${Math.round(100*s)}% more wrecked cars (more loot, more alarms).`},
  grove:{name:'Overgrown Path',icon:'🌲',txt:s=>`${Math.round(100*s)}% more rocks, logs and stumps to search.`},
  quiet:{name:'Quiet Road',icon:'🤫',txt:s=>`${Math.round(20*s)}% fewer zombies.`},
  supplies:{name:'Supply Trail',icon:'🥫',txt:s=>`Food and water drop ${Math.round(1+2*s)}x as often.`},
  scrap:{name:'Junk Pile',icon:'⚙️',txt:s=>`Spare parts drop ${Math.round(1+2*s)}x as often.`},
  gold:{name:'Gold Rumors',icon:'💰',txt:s=>`Gold drops ${Math.round(60*s)}% more often, but ${Math.round(15*s)}% more zombies.`}};
function scoutMods(run){const m={amb:1,cars:1,grove:1,foes:1,supply:1,parts:1,gold:1};const ids=[].concat((run&&run.scoutNow)||[]).filter(id=>SCOUT[id]);if(!ids.length)return m;const s=run.scoutTier>=3?1.5:1;
  for(const id of ids){if(id==='amb')m.amb*=1+3*s;if(id==='cars')m.cars*=1+s;if(id==='grove')m.grove*=1+s;if(id==='quiet')m.foes*=1-.2*s;if(id==='supplies')m.supply*=1+2*s;if(id==='scrap')m.parts*=1+2*s;if(id==='gold'){m.gold*=1+.6*s;m.foes*=1+.15*s;}}return m;}   /* 0.12.105: two reports at once with the Map Table */
/* 0.12.105 Radio Shack: a rough forecast of the next stage (the same numbers the stage itself uses) */
function radioForecast(run){const st=CFG.stage(run.stage,run.prestige);const CL=st.n===1?CLUSTERS1:CLUSTERS;const avg=(CL.first+(CL.last[0]+CL.last[1])/2)/2;
  const foes=Math.round(avg*CL.count*st.countMul*scoutMods({scoutNow:run.scoutPick,scoutTier:upgT(run,'tower')}).foes+WOLVES_PER_STAGE(st.n));return {waves:CL.count,foes,wolves:st.n>=2,firemen:st.n>=3};}
function scoutRoll(run){const t=upgT(run,'tower');if(!t)return null;const k=Object.keys(SCOUT).sort(()=>Math.random()-.5);return k.slice(0,t===1?2:t>=4?4:3);}
const STILL_FOOD=[2,1.5,1,1];   /* 0.12.252 (Kyle): food per jar by tier (plus 1 water); no per-camp cap, one jar per hero */
function brewCourage(run,k){const t=upgT(run,'still');if(!t)return 'no';const cost=STILL_FOOD[t-1];if((run.food||0)<cost-1e-9)return 'food';if((run.water||0)<1)return 'water';   /* 0.12.251 (Kyle): fruit AND liquid: tier I 2 food + 1 water, tier II 1 food + 1 water */
  if(k==='robot')return 'no';const cr=run.heroes[k].carry=run.heroes[k].carry||{kit:[]};if(cr.courage)return 'has';cr.courage=1;run.food=Math.round((run.food-cost)*2)/2;run.water=Math.round((run.water-1)*2)/2;run.brewN=(run.brewN||0)+1;return 'ok';}
const TRIAGE={med:[15,13,11],bat:[12,10,8],defib:[25,22,19],max:[1,1,2]};
/* ======================================================================= 0.12.106 (Kyle) TALENTS: the level-up revamp
   Every level gives a talent point. What you get offered depends on the level that earned it:
     - most levels: pick 1 of 3 STAT cards (a bigger pool than before, weighted to what the hero actually uses) or, now and then, a PERSONALITY card
     - every 3rd level (3, 6, 9, 12...): pick 1 of 3 SKILL MODS that change one of the hero's own abilities
     - level 5 and level 10: a CAPSTONE fork, pick 1 of 2 big talents
   Offers are rolled once per point and kept, so closing camp doesn't reroll them. */
const TAL_STAT={
  tough:{name:'Toughness',icon:'❤️',txt:'+8% max HP',hpPct:8},
  power:{name:'Power',icon:'⚔️',txt:'+6% damage',dmgPct:6},
  aim:{name:'Deadeye',icon:'🎯',txt:'+5 accuracy',mod:{acc:5}},
  edge:{name:'Killer Edge',icon:'✴️',txt:'+3% crit chance',mod:{crit:3}},
  fortune:{name:'Fortune',icon:'🍀',txt:'+6 Luck',mod:{luck:6}},
  hide:{name:'Thick Hide',icon:'🛡️',txt:'+2 armor',mod:{armor:2}},
  quick:{name:'Quick Hands',icon:'⚡',txt:'+8% attack speed (melee and ranged)',mod:{meleeSpd:8,rangedSpd:8}},
  fleet:{name:'Fleet',icon:'👟',txt:'+6% move speed',mod:{move:6}},
  well:{name:'Deep Well',icon:'🔷',txt:'+15 max energy',mod:{enMax:15},abil:1},
  focus:{name:'Focus',icon:'🌀',txt:'+0.5 energy per second',mod:{enRegen:.5},abil:1},
  haste:{name:'Haste',icon:'⏱️',txt:'-5% cooldowns',mod:{cdr:5},abil:1},
  brawn:{name:'Brawn',icon:'💪',txt:'+15 knockback, +10% knockback resistance',mod:{kb:15,kbRes:10},melee:1},
  evade:{name:'Evasion',icon:'💨',txt:'+2.5% dodge',mod:{dodge:2.5}},
  medic:{name:'Field Medic',icon:'🩹',txt:'+12% healing done',heal:12,healer:1},
  rescue:{name:'Rescuer',icon:'🤝',txt:'helps allies up 20% faster',rev:20}};
const TAL_PERSONA={
  steady:{name:'Nerves of Steel',icon:'🧊',txt:'+2 Steady (panics less)',shift:{nerve:-2}},
  fury:{name:'Bloodlust',icon:'🔥',txt:'+2 Blind Aggression (fights harder, backs off later)',shift:{aggr:2}},
  calm:{name:'Cool Head',icon:'🧠',txt:'+2 Calculated Play (backs off earlier, picks safer fights)',shift:{aggr:-2}},
  eyes:{name:'Sharp Eyes',icon:'👁️',txt:'+2 Perceptive (spots loot, mines and danger sooner)',shift:{perc:2}},
  team:{name:'Brothers in Arms',icon:'🫂',txt:'+2 Selfless and +1 Pack Hunter',shift:{self:-2,pack:-1}}};
/* skill mods: each one patches the hero's own ability numbers (only this hero, only while he has it) */
const TAL_MOD={
  jp:{scope:{name:'Hollow Tip Scope',icon:'🎯',txt:'No_Scope pierces 5 zombies (was 3) and hits for 4d6 (was 3d6).',ab:'noscope',set:{pierce:5,dice:[4,6]}},
      familia:{name:'Familia Forever',icon:'🛡️',txt:'Protect_the_Familia shields for 75% (was 50%) and comes back in 15s (was 20s).',ab:'familia',set:{shield:.75,cd:15}},
      hotbox:{name:'Hotbox',icon:'🌿',txt:'Toke_Break lasts 3s (was 2s) and heals 10% (was 6%).',ab:'toke',set:{dur:3,heal:.1}}},
  chibi:{twin:{name:'Twin Shadows',icon:'👥',txt:'Shadow_Clone lasts 7s (was 5s) and its own sword hits land at 60% (was 40%).',ab:'clone',set:{dur:7,mirror:.6}},
      tsunami:{name:'Tsunami Dash',icon:'🌊',txt:'Wave Dash rides 140px (was 100) and hits 50% harder.',ab:'dash',set:{dist:140,dmgMul:1.5}},
      hymn:{name:'Battle Hymn',icon:'📣',txt:'War Cry gives +35% damage (was 25%) for 9s (was 7s).',ab:'shout',set:{dmg:.35,dur:9}}},
  archer:{three:{name:'Five in Hand',icon:'🏹',txt:'One Nocked, Two in Hand fires 5 quick arrows (was 3).',ab:'rapid',set:{shots:5}},
      monsoon:{name:'Monsoon',icon:'🌧️',txt:'Arrow_Rain drops 26 arrows (was 16).',ab:'rain',set:{count:26}},
      deeppin:{name:'Deep Pin',icon:'📌',txt:'Pinning_Shot roots for 4s (was 2.5s) and its mark makes the target take 40% more (was 25%).',ab:'pin',set:{root:4,amp:.4}}},
  flannel:{hollow:{name:'Hollow Point',icon:'🔫',txt:'Aimed Shot pierces 3 zombies (was 1) and crits for 3x (was 2.5x).',ab:'aimed',set:{pierce:3,critMul:3}},
      nails:{name:'Hard as Nails',icon:'🪨',txt:'True_Grit blocks 65% of damage (was 50%) for 11s (was 8s).',ab:'grit',set:{dr:.65,dur:11}},
      boom:{name:'Bigger Boom',icon:'💥',txt:'Proximity_Bomb throws zombies much harder (70 knockback, was 45) and is back in 7s (was 10s).',ab:'trip',set:{kb:70,cd:7}}},
  druid:{overgrow:{name:'Overgrowth',icon:'🌸',txt:'Rejuvenating Bloom lasts 12s (was 8s).',ab:'bloom',set:{dur:12}},
      bramble:{name:'Bramble Tide',icon:'🌵',txt:'Thorn Wave hits for 3d6 (was 2d6) and poisons 80% of the time (was 50%).',ab:'thorns',set:{dice:[3,6],poisonCh:.8}},
      eye:{name:'Eye of the Storm',icon:'🌪️',txt:'Cyclone lasts 8s (was 5s) and pulls much harder.',ab:'cyclone',set:{dur:8,pull:26}}},
  lumberjack:{widow:{name:'Widowmaker Spin',icon:'🌀',txt:'Whirl_Wind spins for 7s (was 5s) with a wider reach.',ab:'whirl',set:{dur:7,r:32}},
      split:{name:'Earthsplitter',icon:'🪓',txt:'Ground_Chop splits the ground 60px out (was 40) and stuns for 1.4s (was 0.8s).',ab:'chop',set:{dist:60,stun:1.4}},
      unbridled:{name:'Unbridled',icon:'😤',txt:'Timber_Rage gives +45% damage (was 30%) for 9s (was 6s).',ab:'rage',set:{dmg:.45,dur:9}}},
  cultist:{arms:{name:'Many-Armed',icon:'🐙',txt:'Tentacles have 25 HP (was 15) and hit for 2d6+2 (was 1d6+2).',ab:'tentacle',set:{hp:25,dice:[2,6]}},
      elder:{name:'Elder Sign',icon:'👁️',txt:'Call_of_Cthulhu lasts 14s (was 10s) and terrifies for 3s (was 2s).',ab:'cthulhu',set:{dur:14,fear:3}},
      thirst:{name:'Thirsting Shadows',icon:'🩸',txt:'Syphon_Life drains 5 a second (was 3).',ab:'syphon',set:{dps:5}}},
  eng:{cells:{name:'Reinforced Cells',icon:'🧱',txt:'His HESCO cell has 130 HP (was 80).',ab:'build',path:'barrier',set:{hp:130}},
      coil:{name:'Overcharged Coil',icon:'⚡',txt:'His tesla coil lasts 40s (was 25s) and zaps every 1s (was 1.5s).',ab:'build',path:'tesla',set:{life:40,every:1}},
      shaped:{name:'Shaped Charge',icon:'🧨',txt:'Satchel_Charge hits for 8d4 (was 6d4) over a bigger blast.',ab:'satchel',set:{dice:[8,4],r:42}}},
  knight:{bulwark:{name:'Bulwark',icon:'🛡️',txt:'Shield_Wall lasts 6s (was 4s) and blocks 75% (was 60%).',ab:'wall',set:{dur:6,dr:.75}},
      ram:{name:'Battering Ram',icon:'🐎',txt:'Crimson_Charge hits for 3d6 (was 2d6) and goes 140px farther.',ab:'charge',set:{dice:[3,6],dist:140}},
      oathkeeper:{name:'Oathkeeper',icon:'🩸',txt:'Blood_Oath heals 6% a kill (was 3%).',ab:'oath',set:{heal:.06}}},
  carcher:{broad:{name:'Broadhead',icon:'🏹',txt:'Piercing_Shot hits for 3d6 (was 2d6) and goes through up to 7 (was 5).',ab:'pierce',set:{dice:[3,6],n:7}},
      roll:{name:'Combat Roll',icon:'🤸',txt:'Tumble goes 50% farther and its cooldown is 8s (was 12s).',ab:'tumble',set:{dist:68,cd:8}}},
  csorc:{storm:{name:'Storm Caller',icon:'⛈️',txt:'Chain_Lightning jumps to 5 more (was 3) and stuns for 0.8s (was 0.4s).',ab:'chain',set:{n:6,stun:.8}},
      clap:{name:'Thunderhead',icon:'🌩️',txt:'Thunderclap hits for 4d6 (was 3d6) and stuns for 1.5s (was 1s).',ab:'thunder',set:{dice:[4,6],stun:1.5}},
      flow:{name:'Overflow',icon:'🔋',txt:'Arcane_Flow gives +6 energy a kill (was +3).',ab:'arcflow',set:{en:6}}},
  cheez:{blitz:{name:'Battou',icon:'⚡',txt:'The Iaijutsu wave flies 540px (was 420px) and costs 22 energy (was 30).',ab:'iai',set:{range:180,en:22}},
      bar:{name:'Open Bar',icon:'🍶',txt:'Sake_Break lasts 14s (was 10s) and drops the hiccups.',ab:'sake',set:{dur:14,hic:0}},
      party:{name:'House Party',icon:'🎉',txt:'Dice-Boys_Banner lasts 14s (was 8s) and gives +20% damage (was +15%).',ab:'host',set:{dur:14,dmg:.2}}},
  edward:{heavy:{name:'Heavy Toolbox',icon:'🧰',txt:'Toolbox_Toss hits for 3d8 (was 2d8) and stuns for 2s (was 1.2s).',ab:'toolbox',set:{dice:[3,8],stun:2}},
      nakama:{name:'Nakama',icon:'✨',txt:'Power_of_Friendship lasts 9s (was 6s) and friends get +20% (was +10%).',ab:'friend',set:{dur:9,ally:.2}},
      nerve:{name:'Big Nerve',icon:'😤',txt:'Chutzpah lasts 5s (was 3s) and he takes 45% less (was 30%).',ab:'chutz',set:{dur:5,dr:.45}},
      box:{name:'Bulk Box',icon:'📦',txt:'Nail_Strip reaches 450px (was 300px) and the nails stay down 8s (was 5s).',ab:'nails',set:{range:150,field:8}},
      ride:{name:'Ride or Die',icon:'🤝',txt:'Loyal_to_a_Fault kicks in under 45% (was 30%) and takes 50% (was 40%).',ab:'loyal',set:{under:.45,share:.5}}},
  soldier:{cook:{name:'Cooked Fuse',icon:'⏱️',txt:'Frag_Grenade blows the moment it lands (no 0.5s tick) and stuns for 2s (was 1.5s).',ab:'frag',set:{fuse:.05,stun:2}},
      heavy:{name:'Heavy Frag',icon:'💣',txt:'Frag_Grenade hits for 5d6 (was 4d6) in a 120px-wide blast (was 90px).',ab:'frag',set:{dice:[5,6],r:40}},
      tough:{name:'Hardened Veteran',icon:'🎖️',txt:'Battle_Hardened kicks in below 65% HP (was 50%) and blocks 25% (was 15%).',ab:'hardened',set:{under:.65,dr:.25}}},
  shoshi:{undo:{name:'Version History',icon:'🕘',txt:'Ctrl_Z reaches back 5s (was 3s) and triggers at 18% lost (was 25%).',ab:'undo',set:{win:5,min:.18}},
      reset:{name:'Hard Reset',icon:'🔄',txt:'Turn_It_Off_And_On_Again refreshes 2 cooldowns (was 1) and heals 15% (was 8%).',ab:'reboot',set:{n:2,heal:.15}},
      premium:{name:'Priority Support',icon:'🎧',txt:'Tech_Support cuts cooldowns by 22% (was 15%) and gives +8 energy (was 5).',ab:'trial',set:{cut:.22,energy:8}},
      dadstr:{name:'Dad Strength',icon:'💪',txt:'Dad_Mode blocks 60% of damage (was 40%) and the shield is worth 35% of their max HP (was 20%).',ab:'dad',set:{dr:.6,shield:.35}}},
  robot:{swarm:{name:'Swarm Protocol',icon:'🚀',txt:'Missile_Barrage fires 5 missiles (was 3).',ab:'missiles',set:{n:5}},
      smoke:{name:'Thick Smoke',icon:'🌫️',txt:'Smoke_Screen lasts 9s (was 6s) and zombies inside miss 65% of the time (was 50%).',ab:'smoke',set:{dur:9,miss:.65}},
      nanite:{name:'Nanite Overdrive',icon:'🔧',txt:'Nano-Tech_Repair_Bots fix 10% a second (was 7%).',ab:'nano',set:{per:.1}}}};

/* ======================================================================= 0.12.249 (Kyle) HERO CAPSTONES
   Level 5 and level 10 each offer a pick between TWO capstones made for that hero only. Each one is far stronger than a normal level-up: it
   reworks how an ability behaves, patches its numbers, and adds stat boosts. (Heroes not reworked yet still roll the old shared four.)
   patch: [{ab, set, path}] patches an ability ('_melee'/'_ranged' = the basic attacks; path = a sub-object such as 'flame' or 'carpet')
   stat: {hpPct, dmgPct, mod:{...}} same keys as the stat talents. The behavior lives in CAPFX (hit / kill / hurt / tick / down / cast hooks). */
const HCAP={
 cheez:{5:{
   cz_ronin:{name:'Nat_20_Ronin',icon:'🎲',txt:'Iaijutsu: 3d8, flies 540px, 6s cooldown. Every Beam_Katana CRIT also fires a free mini-wave down his lane (1d8+2, no blink). +8% crit.',patch:[{ab:'iai',set:{dice:[3,8],range:180,cd:6}}],stat:{mod:{crit:8}}},
   cz_happy:{name:'Happy_Hour',icon:'🍻',txt:'Sake_Break is shared with EVERY friend within 150px (banner rules apply to each). While he\'s in Drunken_Style he heals 10% of the damage he deals. +15% max HP.',stat:{hpPct:15}}},
  10:{
   cz_boss:{name:'Final_Boss_of_Game_Night',icon:'👑',txt:'Dice-Boys_Banner lasts 16s on an 18s cooldown, all-in crit is +15%, and the banner pulses neon every 2s: 1d6+2 to every zombie within 300px of it.',patch:[{ab:'host',set:{dur:16,cd:18,crit:.15}}]},
   cz_speed:{name:'Speedrun_Any%',icon:'🏆',txt:'Perfect_Attendance saves him TWICE a stage. Every save and every Iaijutsu blink starts a 4s SPEEDRUN: +50% attack speed, +30% move speed, and Iaijutsu\'s cooldown resets. +10% damage.',stat:{dmgPct:10}}}},
 edward:{5:{
   ed_frame:{name:'Framing_Crew',icon:'🔨',txt:'Nail_Gun holds 30 nails, +10% ranged damage, and every 5th nail is a FRAMING NAIL: triple damage and it pins the zombie in place for 1s.',patch:[{ab:'_ranged',set:{clip:30}}],stat:{mod:{rangedDmg:10}}},
   ed_jobs:{name:'Works_Two_Jobs',icon:'💼',txt:'+30% energy regen. Every ability gives back 30% of its energy when a friend is within 300px. Toolbox_Toss: 3d8 on a 9s cooldown.',patch:[{ab:'toolbox',set:{dice:[3,8],cd:9}}],stat:{mod:{enRegen:1.65}}}},
  10:{
   ed_nakama:{name:'Nakama_Unleashed',icon:'🌟',txt:'Power_of_Friendship lasts 10s, friends within 300px get the FULL +30% damage AND +30% attack speed, and it heals the whole team 15% when it starts. +15% max HP.',patch:[{ab:'friend',set:{dur:10,ally:.3}}],stat:{hpPct:15}},
   ed_bond:{name:'Unbreakable_Bond',icon:'🤝',txt:'Loyal_to_a_Fault starts at 60% and takes 60% of the hits. Every hit he soaks heals that friend 4% of their max HP, and soaked hits land 25% softer on him. +3 armor.',patch:[{ab:'loyal',set:{under:.6,share:.6}}],stat:{mod:{armor:3}}}}},
 knight:{5:{
   kn_bastion:{name:'Crimson_Bastion',icon:'🏰',txt:'Shield_Wall lasts 6s and blocks 75%, and everything it blocks is thrown back at the attacker as crimson fire. +4 armor.',patch:[{ab:'wall',set:{dur:6,dr:.75}}],stat:{mod:{armor:4}}},
   kn_blood:{name:'Blood_Knight',icon:'🩸',txt:'Every hit heals him 2% of his max HP. Blood_Oath: +35% damage under half HP (was 15%) and 0.40 HP/s per zombie near him (was 0.20). +10% max HP.',patch:[{ab:'oath',set:{dmg:.35,regen:.4}}],stat:{hpPct:10}}},
  10:{
   kn_avatar:{name:'Avatar_of_the_Oath',icon:'👼',txt:'Once a stage, when he would go down he rises in crimson fire at 60% HP, untouchable for 3s, and every zombie within 150px takes 3d6 and is blown away.'},
   kn_jugg:{name:'Unstoppable',icon:'🐎',txt:'Crimson_Charge: 3d6 on a 6s cooldown. Any kill resets Crimson_Charge and Shield_Bash (once every 2s). He can\'t be knocked back. +20% damage.',patch:[{ab:'charge',set:{dice:[3,6],cd:6}}],stat:{dmgPct:20,mod:{kbRes:100}}}}},
 robot:{5:{
   rb_inferno:{name:'Inferno_Protocol',icon:'🔥',txt:'Flamethrower: 50% longer cone, 5 on contact, burns 3d4 over 3s. Anything burning takes 20% more from all his damage. +15% max HP.',patch:[{ab:'_melee',path:'flame',set:{len:84,hit:5,burnDice:[3,4]}}],stat:{hpPct:15}},
   rb_swarm:{name:'Hunter-Killer_Swarm',icon:'🚀',txt:'Missile_Barrage: 6 missiles on a 9s cooldown. Carpet_Bomb drops 15. +10% ranged damage.',patch:[{ab:'missiles',set:{n:6,cd:9}},{ab:'directive',path:'carpet',set:{shots:15}}],stat:{mod:{rangedDmg:10}}}},
  10:{
   rb_titan:{name:'Titan_Frame',icon:'🛡️',txt:'+40% max HP, +6 armor, immune to stuns and slows. Nano-Tech_Repair_Bots heal 10% a second and he keeps moving and shooting while they work.',patch:[{ab:'nano',set:{per:.1}}],stat:{hpPct:40,mod:{armor:6}}},
   rb_omega:{name:'Omega_Directive',icon:'⚡',txt:'Primary_Directive: 15s cooldown for both choices, twice the missiles in the air, and his landing smash hits 4d6 in 210px and stuns for 1.5s.',patch:[{ab:'directive',path:'retreat',set:{icd:15,shots:6}},{ab:'directive',path:'carpet',set:{cd:15,shots:18}}]}}},
};
/* temporary buffs anyone can carry (capstones hand them out): +attack speed, +move, +damage for a while */
function tbuff(o,B,dur){const b={T:dur,sp:B.sp||0,mv:B.mv||0,dm:B.dm||0};(o.tb=o.tb||[]).push(b);o.meleeSpd*=1+b.sp;o.rangedSpd=(o.rangedSpd||1)*(1+b.sp);o.mvMul=(o.mvMul||1)+b.mv;o.atk*=1+b.dm;}
function tbuffStep(o,dt){if(!o.tb||!o.tb.length)return;for(const b of o.tb){b.T-=dt;if(b.T<=0||!o.alive){o.meleeSpd/=1+b.sp;o.rangedSpd/=1+b.sp;o.mvMul-=b.mv;o.atk/=1+b.dm;b.dead=1;}}o.tb=o.tb.filter(b=>!b.dead);}
const CAPFX={
  cz_ronin:{hit(g,h,e,amt,crit,opt){if(crit&&!opt.wave&&!opt.blast)(g.waves=g.waves||[]).push({x:g.heroX(h)+(h.face||1)*8,x0:g.heroX(h),gy:h.gy||g.G,dir:h.face||1,spd:200,left:90,src:h,hit:new Set([e]),first:0,mini:1,dice:[1,8],flat:2,t:0});return amt;}},
  cz_happy:{hit(g,h,e,amt){if(h.sakeB&&h.alive){h.hp=Math.min(h.max,h.hp+amt*.1);}return amt;}},
  cz_speed:{},cz_boss:{},
  ed_frame:{hit(g,h,e,amt,crit,opt){if(opt.blast||opt.fire)return amt;h.nailN=(h.nailN||0)+1;if(h.nailN%5===0){amt*=3;e.slow=1;e.slowT=Math.max(e.slowT||0,1);g.text(e.x,(e.gy||g.G)-50,'FRAMED!','#f0b429');}return amt;}},
  ed_jobs:{cast(g,h,en){if(en>0&&g.alive().some(o=>o!==h&&!o.pet&&Math.abs(g.heroX(o)-g.heroX(h))<100))h.en=Math.min(h.enMax||100,(h.en||0)+en*.3);}},
  ed_nakama:{},ed_bond:{hurt(g,h,amt){return g._loyal?amt*.75:amt;}},
  kn_bastion:{hurt(g,h,amt,from){if(h.wallT>0&&from&&from.E&&!from.dead)g.hitEnemy(from,amt*3,h,{sure:1,fire:1,quiet:1});return amt;}},
  kn_blood:{hit(g,h,e,amt,crit,opt){if(!opt.fire&&h.alive)g.healHero(h,h.max*.02,true,h);return amt;}},
  kn_avatar:{down(g,h){if(h.avUsed)return false;h.avUsed=1;h.hp=h.max*.6;h.invulnT=3;const gy=h.gy||g.G,x=g.heroX(h);g.fx.push({k:'smash',x,gy,r:50,t:0,life:.8,raw:1},{k:'ring',x,y:gy-14,t:0,r:40,c:'#ff3a3a'});g.shake=Math.max(g.shake||0,.45);g.ev('boom',{});
      for(const e of g.enemies){if(e.dead||e.fly)continue;if(Math.abs(e.x-x)<=50&&Math.abs((e.gy!=null?e.gy:g.G)-gy)<=30)g.hitEnemy(e,g.rollDice([3,6])*(h.atk/h.base.atk),h,{sure:1,kb:4,fire:1});}
      g.text(x,gy-60,'THE OATH HOLDS!','#ff3a3a',true);Comms.bubble(g,h,Comms.pick(['Not while I draw breath!','My oath is not yet kept!','RISE!']),true);return true;}},
  kn_jugg:{kill(g,h){if(!(h.jgT>g.t)){h.jgT=g.t+2;h.ccT=0;h.sbT=0;}}},
  rb_inferno:{hit(g,h,e,amt){return e.fb?amt*1.2:amt;}},
  rb_swarm:{},rb_omega:{},
  rb_titan:{tick(g,h){h.stun=0;if(h.slowT>0){h.slowT=0;h.slow=0;}}},
};
function capHook(name,g,h,...a){let r=a[1];for(const f of h.capF){const F=CAPFX[f];if(F&&F[name]){const v=F[name](g,h,...a);if(name==='hit'||name==='hurt')a[1]=r=v;else if(name==='down'&&v)return true;}}return name==='down'?false:r;}
/* capstones: real game changers. Level 5 and level 10 each offer two (rolled from the list, kept once rolled) */
const TAL_CAP={
  5:{glass:{name:'Glass Cannon',icon:'💥',txt:'+15% damage, but -10% max HP.'},
     bulwark:{name:'Bulwark',icon:'🏰',txt:'+20% max HP and +2 armor.'},
     adren:{name:'Adrenaline',icon:'💉',txt:'Under 40% HP he fights at +25% attack speed and moves 15% faster.'},
     wind:{name:'Second Wind',icon:'🌬️',txt:'Once a stage, when he goes down he gets back up by himself after 3s.'}},
  10:{last:{name:'Last Stand',icon:'🗿',txt:'Once a stage, a hit that would put him down leaves him at 1 HP and untouchable for 3s instead.'},
      exec:{name:'Executioner',icon:'🪦',txt:'His hits deal +60% damage to anything under 25% health.'},
      over:{name:'Overclock',icon:'⚙️',txt:'-20% cooldowns, and his abilities cost 20% less energy.'},
      jugg:{name:'Juggernaut',icon:'🦏',txt:'+3 armor, +40% knockback resistance, and every hit on him lands 10% softer.'}}};
function talKind(L){return L===5||L===10?'cap':'stat';}   /* 0.12.249 (Kyle): 5 and 10 are capstone forks; every other level is a 1-of-3 upgrade with a signature (hero-only) card in the mix */
function talPicks(H){return (H&&H.tal)||[];}
function talFree(H){const used=Object.values(H.pts||{}).reduce((a,b)=>a+b,0)+talPicks(H).length;return Math.max(0,(H.lvl||1)-1-used);}
function talCard(id,k){const [t,a,b]=id.split(':');if(t==='st')return TAL_STAT[a];if(t==='ps')return TAL_PERSONA[a];if(t==='cap')return (HCAP[k]&&HCAP[k][a]&&HCAP[k][a][b])||(TAL_CAP[a]||{})[b];if(t==='mod')return ((TAL_MOD[k]||{})[a]);return null;}
/* the level a point came from: points are spent in order, so the next free point belongs to level (spent+2) */
function talNextLevel(H){const used=Object.values(H.pts||{}).reduce((a,b)=>a+b,0)+talPicks(H).length;return used+2;}
function talRoll(k,H,rng){rng=rng||Math.random;const L=talNextLevel(H),kind=talKind(L),have=new Set(talPicks(H));const C=CHAR[k]||{};const abil=(C.abilities||[]).some(a=>!a.passive);
  const healer=k==='druid',melee=!!(C.melee&&!C.ranged)||k==='lumberjack'||k==='chibi';
  if(kind==='cap'){const own=HCAP[k]&&HCAP[k][L];const ids=own?Object.keys(own):Object.keys(TAL_CAP[L]).sort(()=>rng()-.5).slice(0,2);return {L,kind,ids:ids.map(x=>'cap:'+L+':'+x)};}
  const sig=Object.keys(TAL_MOD[k]||{}).filter(x=>!have.has('mod:'+x)).sort(()=>rng()-.5);
  const pool=[];for(const [x,S] of Object.entries(TAL_STAT)){if(S.abil&&!abil)continue;let w=1;if(S.healer)w=healer?2.5:.3;if(S.melee)w=melee?1.6:.5;if(x==='edge'&&healer)w=.4;pool.push(['st:'+x,w]);}
  for(const x of Object.keys(TAL_PERSONA))if(!have.has('ps:'+x))pool.push(['ps:'+x,.35]);
  const ids=sig.length?['mod:'+sig[0]]:[];if(sig.length>1&&rng()<.35)ids.push('mod:'+sig[1]);while(ids.length<3&&pool.length){let tot=pool.reduce((a,p)=>a+p[1],0),r=rng()*tot,i=0;for(;i<pool.length;i++){r-=pool[i][1];if(r<=0)break;}ids.push(pool.splice(Math.min(i,pool.length-1),1)[0][0]);}
  return {L,kind:'stat',ids};}
function talOffer(k,H){if(talFree(H)<1){H.offer=null;return null;}const L=talNextLevel(H);if(!H.offer||H.offer.L!==L)H.offer=talRoll(k,H);return H.offer;}
function talTake(k,H,id){const O=talOffer(k,H);if(!O||!O.ids.includes(id))return false;(H.tal=H.tal||[]).push(id);H.offer=null;return true;}
/* the hero's ability set with his skill mods patched in (a private copy: nobody else's numbers change) */
function talChar(k,H){const C=CHAR[k];const mods=talPicks(H).filter(x=>x.startsWith('mod:')).map(x=>(TAL_MOD[k]||{})[x.slice(4)]).filter(Boolean);
  for(const id of talPicks(H))if(id.startsWith('cap:')){const [,L,b]=id.split(':');const Cp=HCAP[k]&&HCAP[k][L]&&HCAP[k][L][b];if(Cp&&Cp.patch)mods.push(...Cp.patch);}   /* 0.12.249 hero capstones patch abilities too */
  if(!C||!mods.length)return C;
  const C2=Object.assign({},C,{abilities:(C.abilities||[]).map(a=>JSON.parse(JSON.stringify(a)))});if(C.melee)C2.melee=JSON.parse(JSON.stringify(C.melee));if(C.ranged)C2.ranged=JSON.parse(JSON.stringify(C.ranged));
  for(const M of mods){const A=M.ab==='_melee'?C2.melee:M.ab==='_ranged'?C2.ranged:C2.abilities.find(a=>a.id===M.ab);if(!A)continue;const T=M.path?A[M.path]:A;if(T)Object.assign(T,JSON.parse(JSON.stringify(M.set)));}
  return C2;}
const LVPTS={hp:{name:'Toughness',icon:'❤️',txt:'+4% max HP'},dmg:{name:'Power',icon:'⚔️',txt:'+3% damage'},acc:{name:'Aim',icon:'🎯',txt:'+2 accuracy'},
  crit:{name:'Edge',icon:'✴️',txt:'+1% crit chance'},luck:{name:'Fortune',icon:'🍀',txt:'+3 Luck'},armor:{name:'Hide',icon:'🛡️',txt:'+1 armor point'}};
/* 0.12.53 (Kyle): anyone can try to defuse a mine; a failure sets it off. Sapper makes it far safer, and fiddly-job traits help:
   Slow and Steady (biggest), Techy, Steady nerves, Optimal, and a little Luck. */
function defuseOdds(h){const sap=hasPerk(h,'sapper');   /* 0.12.156 (Kyle): about 40% for anybody, up to ~65% with everything high and stacked (Sapper +12%, Techy, Slow and Steady, Calm, Optimal, Luck) */
  let s=.40+(sap?.12:0)+.12*(trait(h,'tech')-.5)+.06*(.5-trait(h,'pace'))+.04*(.5-trait(h,'nerve'))+.04*(trait(h,'exec')-.5)+.002*((h.luck||15)-15);return Math.max(.3,Math.min(.65,s));}
/* 0.12.55 (Kyle): planting any bomb or mine takes ~3s, shaved by: Sapper -0.8s, Techy up to -0.7s, Optimal up to -0.3s, Slow and Steady up to -0.3s, a little Luck (min 1.2s) */
function plantTime(h){return Math.max(1.2,3-(hasPerk(h,'sapper')?.8:0)-.7*trait(h,'tech')-.3*trait(h,'exec')-.3*(1-trait(h,'pace'))-.004*Math.max(0,(h.luck||0)-10));}
function hasPerk(u,p){const I=u&&u.insp&&INSP[u.insp];return !!(I&&I.perk===p);}
for(const U of Object.values(CAMP_UPG))U.tiers=U.tiers.map(x=>x*2);CAMP_UPG.cutters.tiers=[125,225];   /* Wire Cutters only shortens the fix now, so it's cheaper (Kyle) */   /* 0.12.58 (Kyle): every camp upgrade costs twice the gold */
function upgT(run,id){return (run&&run.upg&&run.upg[id])||0;}
function lvPtsFree(H){const used=Object.values(H.pts||{}).reduce((a,b)=>a+b,0);return Math.max(0,(H.lvl||1)-1-used);}
const REROLL_EVERY=2;
function campOffers(run){const n=3;const pool=Object.keys(CAMP_UPG).filter(id=>{const t=upgT(run,id),U=CAMP_UPG[id];if(t>=U.tiers.length)return false;const nd=U.needs&&U.needs[t+1];return !nd||upgT(run,nd)>0;});
  const out=[];const bag=pool.slice();while(out.length<n&&bag.length){const i=Math.floor(Math.random()*bag.length);out.push(bag.splice(i,1)[0]);}return out;}
function upgBase(run,id){const t=upgT(run,id);const h=run.haggle||0;return CAMP_UPG[id].tiers[t]*(1-h);}
/* 0.12.187 (Kyle): the 3 camp picks are 25% cheaper than their listed tier price, rounded to the nearest 25 (200 -> 150, 350 -> 275, 550 -> 425).
   Construction keeps its old price (double the listed tier price). */
const FIXED_PRICE={still:[125,150,200,225]};   /* 0.12.252 (Kyle): the Still's camp-pick prices exactly */
function upgPrice(run,id){if(FIXED_PRICE[id]){const p=FIXED_PRICE[id][upgT(run,id)];if(p!=null)return Math.round(p*(1-(run.haggle||0))/25)*25;}return Math.max(25,Math.round(upgBase(run,id)*.75/25)*25);}
function resourcefulOf(s,run){return run.team.some(k=>{const H=s.heroes[k];return H&&H.insp&&INSP[H.insp]&&INSP[H.insp].passive==='resourceful';});}
function upgParts(run,id){return Math.ceil(upgPrice(run,id)/4);}function conBase(run,id){if(FIXED_PRICE[id]){const p=FIXED_PRICE[id][upgT(run,id)];if(p!=null)return Math.round(p*2*(1-(run.haggle||0))/25)*25;}return Math.max(25,Math.round(upgBase(run,id)*2/25)*25);}
/* 0.12.93 (Kyle) Construction: build ANY available upgrade or tier, as many as you like in one camp, at double the pick price */
function conList(run){return Object.keys(CAMP_UPG).filter(id=>{const t=upgT(run,id),U=CAMP_UPG[id];if(t>=U.tiers.length)return false;const nd=U.needs&&U.needs[t+1];return !nd||upgT(run,nd)>0;});}
function conPrice(run,id){return conBase(run,id);}function conParts(run,id){return Math.ceil(conBase(run,id)/4);}
function haggleOf(s,run){const n=run.team.filter(k=>{const H=s.heroes[k];return H&&H.insp&&INSP[H.insp]&&INSP[H.insp].passive==='haggler';}).length;return n?.2:0;}   /* 0.12.46 (Kyle): 20% off, doesn't stack */
/* back at camp after a cleared stage: the camp's own systems run once, then the player feeds whoever is still hungry */
function campArrive(s,run){if(run.campAt===run.stage)return [];run.campAt=run.stage;const log=[];
  run.food=run.food||0;run.water=run.water||0;s.parts=s.parts||0;run.fed={};run.triageN=0;run.brewN=0;run.upgBought=0;run.picked=[];run.offers=campOffers(run);if(run.reroll==null)run.reroll=1;else if(run.reroll<1){run.rerollWait=(run.rerollWait||0)+1;if(run.rerollWait>=REROLL_EVERY){run.reroll=1;run.rerollWait=0;}}   /* 0.12.188 (Kyle): one camp-pick reroll; after you use it, it comes back 2 camps later */run.scoutOffers=scoutRoll(run);run.scoutPick=null;
  const hungry=(run.needFeed||[]).filter(k=>run.team.includes(k)&&k!=='robot');run.needFeed=hungry;
  for(const k of hungry){const hv=run.heroes[k];if(!hv||hv.dead)continue;hv.hunger=Math.min(3,(hv.hunger||0)+1);hv.thirst=Math.min(3,(hv.thirst||0)+1);}   /* 0.12.72 Hunger & Thirst */
  const g=upgT(run,'garden');if(g){const n=g===1?(Math.random()<.5?1:0):g===2?1:2;if(n){run.food+=n;log.push(`🌱 Garden: +${n} food`);}}
  const r=upgT(run,'rain');if(r){const n=r===1?(Math.random()<.5?1:0):1;if(n){run.water+=n;log.push(`🛢️ Rain Barrels: +1 water`);}}
  if(upgT(run,'kennel')){const f0=run.food||0,w0=run.water||0;run.food=Math.max(0,Math.round((f0-.5)*2)/2);run.water=Math.max(0,Math.round((w0-.5)*2)/2);log.push(`🐕 Feeding the doggos: -${f0-run.food} food, -${w0-run.water} water`);}   /* 0.12.204 (Kyle): the kennel eats 0.5 food and 0.5 water every camp */
  const y=upgT(run,'yard');if(y){s.parts+=y;log.push(`⚙️ Scrap Yard: +${y} spare part${y>1?'s':''}`);}
  const w=upgT(run,'water');if(w&&hungry.length&&Math.random()<[.25,.5,.75][w-1]){const th=hungry.filter(k=>run.heroes[k].thirst>0);const k=th[Math.floor(Math.random()*th.length)];if(k){run.heroes[k].thirst=Math.max(0,run.heroes[k].thirst-1);log.push(`💧 Water Filtration gave ${heroDef(k).name} a drink`);}}
  const cb=upgT(run,'cots');if(cb){for(const k of run.team){const hv=run.heroes[k];if(!hv.dead)hv.hpf=Math.min(1,(hv.hpf==null?1:hv.hpf)+[.1,.2,.3][cb-1]);}log.push(`🛏️ Med Cots: everyone +${[10,20,30][cb-1]}% HP`);}
  return log;}
/* 0.12.72 (Kyle) Hunger & Thirst: tiers that only get worse while ignored. Every time the team gets back to camp each unit that eats and drinks
   goes up one tier of each (max 3); each food lowers Hunger by 1 and each water lowers Thirst by 1 (by 2 with the Camp Kitchen / Water Purifier).
   Whatever tier they leave camp at lasts the whole next stage. The Warhound needs neither. Hard-roguelike punishing on purpose. */
const HUNGER={names:['Satiated','Hungry','Very Hungry','Starving'],heal:[0,.15,.3,.5],spd:[0,.06,.13,.22],acc:[0,2,5,9],hp:[0,.1,.2,.35]};
const THIRST={names:['Quenched','Parched','Mildly Dehydrated','Severely Dehydrated'],perc:[0,2,4,7],think:[0,1,2,4],slow:[1,1.15,1.35,1.65],drain:[0,.0004,.001,.002]};
function needsOf(run,k){const hv=run.heroes&&run.heroes[k];return {h:(hv&&hv.hunger)||0,t:(hv&&hv.thirst)||0};}
function fedOf(run,k){const n=needsOf(run,k);return {food:!n.h,water:!n.t};}   // kept for the UI: true = nothing needed
function missingOf(run,k){if(k==='robot'||!run.team.includes(k))return 0;const n=needsOf(run,k);return n.h+n.t;}
function feedUnit(run,k,what){if(k==='robot')return false;const hv=run.heroes[k];if(!hv||hv.dead)return false;const key=what==='water'?'thirst':'hunger';if(!(hv[key]>0))return false;
  if(what==='water'){if(run.water<1)return false;run.water-=1;}else{const cost=upgT(run,'smoker')?.5:1;if(run.food<cost-1e-9)return false;run.food=Math.round((run.food-cost)*2)/2;}
  hv[key]=Math.max(0,hv[key]-(upgT(run,what==='water'?'purifier':'kitchen')?2:1));return true;}
/* Feed all: spends what's in the pack on whoever needs it most: the worst tiers first, then lowest HP; never wastes a ration on someone who's fine */
function feedAll(run){let n=0;for(let guard=0;guard<40;guard++){const L=run.team.filter(k=>k!=='robot'&&run.heroes[k]&&!run.heroes[k].dead&&missingOf(run,k));if(!L.length)break;
    const pick=(key)=>L.filter(k=>run.heroes[k][key]>0).sort((a,b)=>(run.heroes[b][key]-run.heroes[a][key])||((run.heroes[a].hpf==null?1:run.heroes[a].hpf)-(run.heroes[b].hpf==null?1:run.heroes[b].hpf)))[0];
    const a=pick('hunger'),b=pick('thirst');let did=0;if(a&&feedUnit(run,a,'food')){n++;did=1;}if(b&&feedUnit(run,b,'water')){n++;did=1;}if(!did)break;}return n;}
/* leaving camp: Hunger takes its bite out of their HP for the next stage (Thirst works during the stage) */
function campDepart(run){run.scoutNow=run.scoutPick||null;run.scoutTier=upgT(run,'tower');run.scoutOffers=null;run.scoutPick=null;const starved=[];
  for(const k of run.team){if(k==='robot')continue;const hv=run.heroes[k];if(!hv||hv.dead)continue;const n=needsOf(run,k);if(n.h)hv.hpf=Math.max(.05,(hv.hpf==null?1:hv.hpf)*(1-HUNGER.hp[n.h]));if(n.h||n.t)starved.push(k);}
  run.needFeed=[];run.fed={};return starved;}
function triageBuild(s,run,what,k){const t=upgT(run,'triage');if(!t)return 'no';if((run.triageN||0)>=TRIAGE.max[t-1])return 'max';const cost=TRIAGE[what][t-1];if((s.parts||0)<cost)return 'parts';
  const cr=run.heroes[k].carry=run.heroes[k].carry||{kit:[]};
  if(what==='med'){if(cr.medkit)return 'has';cr.medkit=1;}else if(what==='defib'){if(cr.defib)return 'has';cr.defib=1;}else{if(!run.team.includes('robot'))return 'no';cr.kit=cr.kit||[];if(cr.kit.length>=2)return 'has';cr.kit.push('bat');}
  s.parts-=cost;run.triageN=(run.triageN||0)+1;return 'ok';}

const API={radioForecast,reticle,ABIL_DESC,HEADSHOT,isHead,inspHelp,PLAYER_ICON,BEHAVIOR,INSP,inspText,CHAR,AIM_BOXES,aimOdds,aimBoxesOf,hbOf,HERO_HITBOX,ENERGY,spendEnergy,faceToward,AIM_RANGE,accTighten,LANES,UNIT_SCALE,HITBOX,aimBands,airBands,rollAirAim,rollAimHeight,rollLaneOffset,ABILITIES_OFF,armorReduction,HP_PER_STAMINA,gearScore,heroGear,giveItem,rollItem,stockShop,itemPrice,honePrice,slotCaps,equip,unequip,discard,typeOf,BAG_SIZE,migrateSlot,CFG,STYLE,SIG,SPELL,ITEM,PROCS,Game,newRun,offers,applyOffer,describe,heroBase,heroDef,DATA,newSlot,needHeroXp};
if(typeof module!=='undefined'&&module.exports){module.exports=API;}
if(typeof document==='undefined')return;

/*__CRAWLUI__*/

})();
