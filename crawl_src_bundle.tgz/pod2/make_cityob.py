"""0.12.119 (Kyle) Downtown props: no rocks or logs in the city. Wooden crates, a stacked pair, a military loot box (each with an
opened frame for after it's been searched) and flat moss patches growing through the asphalt. The moss is built from the moss and
leaf pixels of our own rock_moss and bush sprites (crawl_obst.png). Sheet px = half a world px, like the rocks.
Writes crawl_cityob.png and prints the OBST entries (JSON) to merge into crawl_src.js."""
import random, json
from PIL import Image, ImageDraw
R = random.Random(11)
OB = Image.open('/home/claude/pod2/crawl_obst.png').convert('RGBA')
OUTL = (22, 18, 22, 255)
def P(im, x, y, c):
    if 0 <= x < im.width and 0 <= y < im.height: im.putpixel((x, y), c if len(c) == 4 else c + (255,))
def outline(im):
    src = im.copy()
    for y in range(im.height):
        for x in range(im.width):
            if src.getpixel((x, y))[3]: continue
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                xx, yy = x + dx, y + dy
                if 0 <= xx < im.width and 0 <= yy < im.height and src.getpixel((xx, yy))[3] > 200 and src.getpixel((xx, yy))[:3] != OUTL[:3]:
                    im.putpixel((x, y), OUTL); break

# ---------------- wooden crate (30 x 30): planks, a Z brace, nail heads, worn corners, a faded stencil
W1, W2, W3, W4 = (70, 56, 48), (92, 74, 58), (114, 92, 70), (52, 42, 38)
def crate(w, h, opened=False, stencil=True):
    im = Image.new('RGBA', (w, h + 6), (0, 0, 0, 0)); d = ImageDraw.Draw(im); top = 6
    d.rectangle([1, top, w - 2, h + 4], fill=W2)
    for y in range(top + 1, h + 4, 5):  # plank seams
        d.line([(2, y), (w - 3, y)], fill=W4)
        for x in range(2, w - 2):
            if R.random() < .25: P(im, x, y + 1, W3)
    d.rectangle([1, top, 4, h + 4], fill=W1); d.rectangle([w - 5, top, w - 2, h + 4], fill=W1)        # corner posts
    d.rectangle([1, top, w - 2, top + 2], fill=W3); d.rectangle([1, h + 2, w - 2, h + 4], fill=W1)
    d.line([(5, h + 1), (w - 6, top + 3)], fill=W1, width=2); d.line([(5, h), (w - 6, top + 2)], fill=W3)  # diagonal brace
    for (x, y) in [(2, top + 1), (w - 4, top + 1), (2, h + 3), (w - 4, h + 3)]: P(im, x, y, (150, 150, 150))
    for _ in range(int(w * h * .04)):                                                                      # grain and grime
        x, y = R.randint(2, w - 3), R.randint(top + 1, h + 3); c = im.getpixel((x, y))
        if c[3]: P(im, x, y, tuple(int(v * R.choice([.85, 1.1])) for v in c[:3]))
    if stencil:                                                                                            # faded stencil arrow + bar
        for k in range(5): P(im, w // 2 - 6 + k, top + 9, (130, 120, 100)); P(im, w // 2 - 4, top + 8 + k // 2, (130, 120, 100))
        for k in range(7): P(im, w // 2 + 1 + k, top + 13, (120, 110, 94))
    for (x, y) in [(1, top), (w - 2, top), (w - 2, top + 1)]: P(im, x, y, (0, 0, 0, 0))                  # chipped corners
    if opened:                                                                                             # lid pried off, leaning on the side; dark inside, straw
        d.rectangle([3, top, w - 4, top + 3], fill=(16, 12, 14))
        for x in range(4, w - 4):
            if R.random() < .5: P(im, x, top + R.randint(0, 2), (150, 130, 70))
        d.polygon([(w - 6, top - 5), (w - 1, top - 6), (w + 0, top + 6), (w - 4, top + 6)], fill=W3)
        d.line([(w - 6, top - 5), (w - 4, top + 6)], fill=W1)
    outline(im); return im

# ---------------- military loot box (32 x 22): olive steel footlocker, rope handles, latches, yellow stripe; opened = lid up
O1, O2, O3 = (48, 58, 44), (66, 80, 58), (90, 106, 76)
def lootbox(opened=False):
    w, h = 32, 22; im = Image.new('RGBA', (w, h), (0, 0, 0, 0)); d = ImageDraw.Draw(im); top = 9
    d.rectangle([1, top, w - 2, h - 2], fill=O2); d.rectangle([1, h - 4, w - 2, h - 2], fill=O1)
    d.line([(1, top + 4), (w - 2, top + 4)], fill=O1)
    for x in range(3, w - 3, 4):                                                                           # hazard stripe along the base
        d.line([(x, h - 4), (x + 1, h - 3)], fill=(170, 140, 50))
    for x in (6, w - 8): d.rectangle([x, top + 2, x + 2, top + 5], fill=(150, 150, 140)); P(im, x + 1, top + 4, (60, 60, 60))   # latches
    d.text((w // 2 - 6, top + 5), '', fill=(0, 0, 0))
    for k in range(5): P(im, w // 2 - 2 + k, top + 7, (170, 170, 150))                                    # stencil star bar
    P(im, w // 2, top + 6, (170, 170, 150)); P(im, w // 2, top + 8, (170, 170, 150))
    for _ in range(40):
        x, y = R.randint(2, w - 3), R.randint(top + 1, h - 3); c = im.getpixel((x, y))
        if c[3] and R.random() < .6: P(im, x, y, tuple(int(v * R.choice([.8, 1.12])) for v in c[:3]))
    for k in range(3): P(im, R.randint(3, w - 4), R.randint(top + 2, h - 5), (96, 64, 50))                # rust spots
    if not opened:
        d.rectangle([0, top - 3, w - 1, top], fill=O3); d.line([(0, top - 3), (w - 1, top - 3)], fill=(120, 136, 100))
        d.line([(0, top), (w - 1, top)], fill=O1)
    else:                                                                                                  # lid swung up and back, dark inside
        d.rectangle([2, top - 1, w - 3, top + 1], fill=(14, 14, 12))
        d.polygon([(1, top - 1), (w - 2, top - 1), (w - 5, 0), (4, 0)], fill=O3); d.polygon([(3, top - 2), (w - 4, top - 2), (w - 6, 2), (6, 2)], fill=O1)
        d.line([(4, 0), (w - 5, 0)], fill=(120, 136, 100))
        for k in range(4): P(im, 6 + k * 6, top, (200, 180, 90))                                         # a glint of what's left
    outline(im); return im

# ---------------- moss patches: palette and leaf tufts taken from our own rock_moss and bush sprites
def greens(box):
    out = []
    reg = OB.crop(box)
    for c in reg.getdata():
        if c[3] > 200 and c[1] > c[0] + 8 and c[1] > c[2]: out.append(c[:3])
    return sorted(set(out), key=lambda c: sum(c))
MOSS = greens((0, 33, 44, 69)); LEAF = greens((343, 47, 390, 69))
def city_tone(c): return (int(c[0] * .78), int(c[1] * .9), int(c[2] * .85 + 12))   # cooled toward the night-blue palette
MOSS = [city_tone(c) for c in MOSS]; LEAFT = [city_tone(c) for c in LEAF]
def tufts():  # small opaque crops out of the bush sprites to stamp as weed tufts
    out = []
    for bx, by, bw, bh in [(343, 49, 22, 20), (367, 47, 23, 22)]:
        for _ in range(6):
            w, h = R.randint(4, 7), R.randint(4, 6); x = bx + R.randint(0, bw - w); y = by + R.randint(0, bh // 2)
            t = OB.crop((x, y, x + w, y + h))
            if sum(1 for c in t.getdata() if c[3] > 200) > w * h * .45: out.append(t)
    return out
TUFTS = tufts()
PAL = sorted(MOSS + LEAFT, key=sum)
def moss(w, h, crack=True):
    im = Image.new('RGBA', (w, h + 5), (0, 0, 0, 0)); cy = h // 2 + 5; rx = w / 2 - 1; ry = h / 2 - .5
    for y in range(h + 5):
        for x in range(w):
            v = ((x - w / 2) / rx) ** 2 + ((y - cy) / ry) ** 2 + R.random() * .5
            if v < 1:
                k = min(len(PAL) - 1, max(0, int((.35 + (1 - v) * .75) * len(PAL) + R.randint(-3, 3))))
                P(im, x, y, PAL[k])
            elif v < 1.25 and R.random() < .35: P(im, x, y, MOSS[0])
    if crack:                                                                                               # a pavement crack running through it
        x, y = 1, cy + R.randint(-1, 1)
        while x < w - 1:
            P(im, x, y, (14, 20, 26)); x += 1; y = int(max(cy - ry + 1, min(cy + ry - 1, y + R.choice([-1, 0, 0, 1]))))
    for _ in range(max(2, w // 12)):                                                                        # weed tufts sprouting from it
        t = R.choice(TUFTS).copy()
        px_ = t.load()
        for yy in range(t.height):
            for xx in range(t.width):
                c = px_[xx, yy]
                if c[3]: px_[xx, yy] = city_tone(c[:3]) + (255,)
        im.alpha_composite(t, (R.randint(1, w - t.width - 1), R.randint(0, max(0, cy - t.height))))
    return im


# ---------------- storefronts (64 x 58): a slice of shop facade on the sidewalk edge. Brick pilasters, a torn awning, a display
# window with stock behind cracked glass, a door, and a burglar-alarm bell up top. Frame 2 = looted: door kicked in, window smashed out,
# stock spilled on the pavement. 'grocery' (cans, bottles: food and water) and 'pharmacy' (green cross, pill bottles: medkits).
def shop(kind, looted=False):
    w, h = 64, 58; im = Image.new('RGBA', (w, h), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    B1, B2, B3 = (50, 40, 50), (64, 50, 58), (80, 64, 70)
    d.rectangle([0, 6, w - 1, h - 1], fill=B2)
    for y in range(6, h, 3):                                                                       # brick courses
        off = 0 if (y // 3) % 2 else 3
        for x in range(off, w, 6): P(im, x, y, B1)
        if y % 6 == 0: d.line([(0, y), (w - 1, y)], fill=B1)
    d.rectangle([0, 0, w - 1, 6], fill=(40, 46, 58)); d.line([(0, 0), (w - 1, 0)], fill=(90, 104, 124))   # sign band
    if kind == 'grocery':
        for i, c in enumerate('MART'):
            pass
        for x in range(6, 40, 2): P(im, x, 3, (150, 170, 190)) if R.random() < .7 else None              # worn lettering
        d.rectangle([44, 2, 52, 4], fill=(170, 130, 60))
    else:
        d.rectangle([8, 1, 12, 5], fill=(60, 150, 90)); d.rectangle([6, 2, 14, 4], fill=(60, 150, 90))     # green cross
        for x in range(18, 50, 2): P(im, x, 3, (150, 170, 190)) if R.random() < .7 else None
    aw = (110, 40, 46) if kind == 'grocery' else (40, 90, 80); aw2 = (150, 140, 130)
    for x in range(0, w):                                                                          # striped awning, ripped and sagging
        if R.random() < .12: continue
        c = aw if (x // 4) % 2 else aw2
        hang = 4 + (R.randint(0, 4) if R.random() < .2 else 0)
        for y in range(8, 8 + hang): P(im, x, y, tuple(int(v * (.85 if y > 9 else 1)) for v in c))
    d.rectangle([0, 14, 4, h - 1], fill=B3); d.rectangle([w - 5, 14, w - 1, h - 1], fill=B3)       # pilasters
    wx0, wx1, wy0, wy1 = 6, 38, 16, 46
    d.rectangle([wx0 - 1, wy0 - 1, wx1 + 1, wy1 + 1], fill=(70, 80, 96))
    d.rectangle([wx0, wy0, wx1, wy1], fill=(14, 22, 32))
    for sy in (wy0 + 9, wy0 + 19, wy1 - 1):                                                        # shelves and stock
        d.line([(wx0, sy), (wx1, sy)], fill=(40, 46, 54))
        for x in range(wx0 + 1, wx1, 3):
            if R.random() < (.35 if looted else .8):
                if kind == 'grocery': c = R.choice([(140, 60, 50), (170, 150, 70), (70, 110, 140), (120, 120, 130)]); d.rectangle([x, sy - 4, x + 1, sy - 1], fill=c)
                else: c = R.choice([(180, 150, 70), (200, 200, 200), (90, 140, 170)]); d.rectangle([x, sy - 3, x + 1, sy - 1], fill=c); P(im, x, sy - 4, (230, 230, 230))
    if not looted:                                                                                 # cracked glass, a few glare streaks
        for k in range(3): d.line([(wx0 + 4 + k * 9, wy0), (wx0 + k * 9, wy1)], fill=(60, 96, 130))
        cx, cy = wx0 + 22, wy0 + 12
        for a in range(0, 360, 60):
            import math
            for r in range(1, 6): P(im, int(cx + math.cos(math.radians(a)) * r), int(cy + math.sin(math.radians(a)) * r), (120, 160, 200))
    else:                                                                                          # glass smashed out: shards left in the frame
        for x in range(wx0, wx1 + 1, 2):
            if R.random() < .5: P(im, x, wy0 + R.randint(0, 2), (90, 130, 170))
            if R.random() < .5: P(im, x, wy1 - R.randint(0, 2), (90, 130, 170))
    dx0, dx1 = 42, 56                                                                              # door
    d.rectangle([dx0 - 1, 15, dx1 + 1, h - 1], fill=(70, 80, 96))
    if looted:
        d.rectangle([dx0, 16, dx1, h - 1], fill=(6, 8, 12)); d.polygon([(dx0, 16), (dx0 - 5, 19), (dx0 - 5, h - 2), (dx0, h - 1)], fill=(44, 56, 70))   # kicked in, hanging open
    else:
        d.rectangle([dx0, 16, dx1, h - 1], fill=(34, 44, 58)); d.rectangle([dx0 + 2, 18, dx1 - 2, 34], fill=(18, 28, 40))
        d.rectangle([dx0 + 3, 26, dx1 - 3, 30], fill=(150, 60, 50)); P(im, dx1 - 2, 40, (170, 170, 150))     # dangling sign, handle
    d.rectangle([w - 12, 9, w - 7, 13], fill=(30, 30, 34)); d.ellipse([w - 12, 8, w - 7, 13], fill=(150, 34, 34)); P(im, w - 10, 9, (220, 120, 110))   # alarm bell
    for _ in range(int(w * h * .03)):                                                              # grime
        x, y = R.randint(0, w - 1), R.randint(6, h - 1); c = im.getpixel((x, y))
        if c[3] and R.random() < .6: P(im, x, y, tuple(int(v * .82) for v in c[:3]))
    if looted:                                                                                     # spilled stock on the pavement
        for _ in range(9): x = R.randint(4, w - 6); P(im, x, h - 1 - R.randint(0, 1), R.choice([(140, 60, 50), (170, 150, 70), (200, 200, 200), (70, 110, 140)]))
    outline(im); return im

items = []  # name, frames
items.append(('crate', [crate(30, 26), crate(30, 26, True)]))
items.append(('crate_tall', [crate(26, 32, stencil=False), crate(26, 32, True, stencil=False)]))
stk = []
for opened in (False, True):
    im = Image.new('RGBA', (40, 54), (0, 0, 0, 0)); im.alpha_composite(crate(36, 24, stencil=True), (4, 24)); im.alpha_composite(crate(28, 22, opened, stencil=False), (0, 0) if False else (2, 4))
    stk.append(im)
items.append(('crate_stack', stk))
items.append(('lootbox', [lootbox(), lootbox(True)]))
items.append(('moss_a', [moss(44, 10)])); items.append(('moss_b', [moss(32, 8)])); items.append(('moss_c', [moss(58, 12)]))
H = max(f.height for _, fr in items for f in fr)
Wt = sum(fr[0].width * len(fr) + 2 for _, fr in items)
sheet = Image.new('RGBA', (Wt, H), (0, 0, 0, 0)); x = 0; meta = {}
for n, fr in items:
    fw, fh = fr[0].width, fr[0].height
    for i, f in enumerate(fr): sheet.alpha_composite(f, (x + i * fw, H - fh))
    flat = n.startswith('moss')
    # cover height (blk) and the profile over the sheet columns (every 2 px), like the rocks
    prof = []
    for c in range(0, fw, 2):
        col = [y for y in range(fh) if fr[0].getpixel((min(fw - 1, c), y))[3] > 0]
        prof.append(fh - min(col) if col else 0)
    hw = round(fw * .5 * .5 * .72, 2)
    meta['city_' + n] = dict(x=x, y=H - fh, fw=fw, fh=fh, lanes=1, blk=0 if flat else max(prof) - 2, foot=[[-hw, hw]], prof=[0] * len(prof) if flat else prof,
                             img='cityob', **({'flat': 1} if flat else {'open': 1}), **({'shop': 1, 'bell': [fw - 9.5, 10.5]} if n.startswith('shop') else {}))
    x += fw * len(fr) + 2
sheet.save('/home/claude/pod2/crawl_cityob.png')
big = Image.new('RGBA', sheet.size, (24, 32, 44, 255)); big.alpha_composite(sheet); big.resize((sheet.width * 4, sheet.height * 4), Image.NEAREST).save('/tmp/cityob4.png')
json.dump(meta, open('/tmp/cityob_meta.json', 'w'))
print(json.dumps({k: (v['fw'], v['fh'], v['blk']) for k, v in meta.items()}), len(MOSS), len(LEAFT), len(TUFTS))
