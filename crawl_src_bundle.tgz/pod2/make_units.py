"""Packs the hand-picked unit sprites (assets/enemies/*) into crawl_units.png and writes atlas['units'].
Every animation is stored facing LEFT (toward the heroes). Anchor = feet centre / ground line of frame 0 of each animation."""
import json, numpy as np
from PIL import Image
A='/home/claude/pod2/assets/enemies/'
# per unit: animation -> (file, frame width, flip-to-face-left, optional crop box (x0,y0,x1,y1) applied to every frame)
WOLF_CROP=(10,4,122,80)
UNITS={
 'zombie':  dict(walk=('zombie_walk_sheet.png',32,False,None),atk=('zombie_atk_sheet.png',64,True,None)),
 'zombie_f':dict(walk=('zombie_f_walk_sheet.png',32,False,None),atk=('zombie_f_atk_sheet.png',64,True,None)),
 'zombie_b':dict(walk=('zombie_b_walk_sheet.png',32,False,None),atk=('zombie_b_atk_sheet.png',64,True,None)),
 'zombie_fire':dict(walk=('fire_walk_sheet.png',56,False,None),atk=('fire_atk_sheet.png',56,False,None),idle=('fire_idle_sheet.png',56,False,None),die=('fire_die_sheet.png',56,False,None)),   # 0.12.62 Kyle's firefighter zombie (already faces left)
 'werewolf':dict(walk=('run_sheet.png',128,True,WOLF_CROP),atk=('attack_sheet.png',128,True,WOLF_CROP),die=('ko_sheet.png',128,True,WOLF_CROP),jump=('jump_sheet.png',128,True,WOLF_CROP),fall=('fall_sheet.png',128,True,WOLF_CROP)),
}
DIRS={'zombie':'zombie','zombie_f':'zombie_f','zombie_b':'zombie_b','werewolf':'werewolf','zombie_fire':'zombie_fire'}
sheets=[];meta={}
for k,anims in UNITS.items():
    meta[k]={}
    for an,(f,fw,flip,crop) in anims.items():
        im=Image.open(A+DIRS[k]+'/'+f).convert('RGBA');n=im.width//fw
        frs=[im.crop((i*fw,0,(i+1)*fw,im.height)) for i in range(n)]
        if crop: frs=[fr.crop(crop) for fr in frs]
        if flip: frs=[fr.transpose(Image.FLIP_LEFT_RIGHT) for fr in frs]
        if k.startswith('zombie'):   # 0.12.38 (Kyle): zombies 12% smaller, smoothly resampled (premultiplied Lanczos) so they're drawn 1:1
            def _sm(fr,f=.88):   # 0.12.39: crisper: Lanczos for shape, then snap every pixel back to the sprite's own palette, hard alpha edges, and a dark outline kept
                a=np.array(fr).astype(float);al=a[...,3:]/255;a[...,:3]*=al;big=Image.fromarray(a.astype('uint8')).resize((fr.width*4,fr.height*4),Image.NEAREST)
                w,h=round(fr.width*f),round(fr.height*f);sm=np.array(big.resize((w,h),Image.LANCZOS)).astype(float);sa=sm[...,3:]/255
                sm[...,:3]=np.where(sa>0,sm[...,:3]/np.maximum(sa,1e-6),0)
                src=np.array(fr).reshape(-1,4);pal=np.unique(src[src[:,3]>200][:,:3],axis=0).astype(float)
                if len(pal):
                    flat=sm[...,:3].reshape(-1,3);d=((flat[:,None,:]-pal[None,:,:])**2).sum(2);sm[...,:3]=pal[d.argmin(1)].reshape(sm.shape[0],sm.shape[1],3)
                sm[...,3]=np.where(sm[...,3]>=110,255,0)
                return Image.fromarray(np.clip(sm,0,255).astype('uint8'))
            frs=[_sm(fr) for fr in frs]
        a=np.array(frs[0])[...,3]>0;ys=np.where(a.any(1))[0];bot=ys.max()
        legs=np.where(a[max(0,bot-14):bot+1])[1];ax=int(np.median(legs))
        sheets.append((k,an,frs));meta[k][an]=dict(fw=frs[0].width,fh=frs[0].height,n=n,ax=ax,ay=int(bot))
        if k.startswith('zombie'):meta[k][an].update(pre=.88)
W=sum(sum(fr.width for fr in frs) for _,_,frs in sheets);H=max(frs[0].height for _,_,frs in sheets)
x=0;out=Image.new('RGBA',(W,H))
for k,an,frs in sheets:
    meta[k][an]['x']=x;meta[k][an]['y']=0
    for fr in frs: out.alpha_composite(fr,(x,0));x+=fr.width
out.save('/home/claude/pod2/crawl_units.png',optimize=True)

def clean_edges(im,passes=2):
    """Strip light, washed-out pixels on the outer edge (leftover background halo) - Kyle: no white bits around the edges."""
    import numpy as np
    from scipy import ndimage as ndi
    a=np.array(im).astype(float);rgb=a[...,:3]/255
    mx,mn=rgb.max(2),rgb.min(2);sat=np.where(mx>0,(mx-mn)/np.maximum(mx,1e-6),0)
    for _ in range(passes):
        al=a[...,3]>0;edge=al&ndi.binary_dilation(~al,structure=np.ones((3,3)))
        bad=edge&(sat<.28)&(mx>.5)
        a[bad,3]=0
    return Image.fromarray(a.astype('uint8'))
# 0.12.4 Flannel_Man at FULL size (Kyle: no shrinking/expanding of his art) in his own sheet: one row per animation.
HA='/home/claude/pod2/assets/heroes/flannel/';FA=['idle','walk','run','melee','ranged','reload','hurt','death','walkfire','kneel','toss','throw']   # 0.12.58: Proximity_Bomb underhand toss + overhand throw (/home/claude/bomb/throw.py)
ims=[Image.open(HA+f+'.png').convert('RGBA') for f in FA];fw,fh=230,208
BUL=Image.open(HA+'bullet.png').convert('RGBA');TRP=Image.open(HA+'tripbomb_hd.png').convert('RGBA')
hs=Image.new('RGBA',(max(i.width for i in ims),fh*len(ims)+max(BUL.height,TRP.height)+2));meta['flannel']={}
for r,(an,im) in enumerate(zip(FA,ims)):
    hs.alpha_composite(im,(0,r*fh));meta['flannel'][an]=dict(fw=fw,fh=fh,n=im.width//fw,ax=140,ay=200,x=0,y=r*fh,img='flannel',art=1)
hs.alpha_composite(BUL,(0,fh*len(ims)));meta['flannel']['bullet']=dict(fw=BUL.width,fh=BUL.height,n=1,ax=BUL.width-2,ay=BUL.height//2,x=0,y=fh*len(ims),img='flannel',art=1)   # his bullet, cut from his Ranged row
hs.alpha_composite(TRP,(40,fh*len(ims)));meta['flannel']['tripbomb']=dict(fw=TRP.width,fh=TRP.height,n=1,ax=9,ay=14,x=40,y=fh*len(ims),img='flannel')   # HD trap: 1 sprite px = 1 canvas px when drawn at .5   # pixel art: drawn like the zombies
BALL=Image.open(HA+'bomb_ball.png').convert('RGBA');hs.alpha_composite(BALL,(90,fh*len(ims)));meta['flannel']['bombball']=dict(fw=BALL.width,fh=BALL.height,n=1,ax=BALL.width//2,ay=BALL.height//2,x=90,y=fh*len(ims),img='flannel')   # just the ball from his trip bomb
hs.save('/home/claude/pod2/crawl_flannel.png',optimize=True)
# 0.12.5 Flannel_Man's companion (her own sheet; no idle/walk rows in the art, so the first Ranged frame stands in)
PA='/home/claude/pod2/assets/heroes/flannel_pal/';PF=['idle','walk','melee','ranged','reload','hurt','death']
pims=[Image.open(PA+f+'.png').convert('RGBA') for f in PF]
ps=Image.new('RGBA',(max(i.width for i in pims),fh*len(pims)));meta['flannel_pal']={}
for r,(an,im) in enumerate(zip(PF,pims)):
    ps.alpha_composite(im,(0,r*fh));meta['flannel_pal'][an]=dict(fw=fw,fh=fh,n=im.width//fw,ax=140,ay=200,x=0,y=r*fh,img='pal',art=1)
ps.save('/home/claude/pod2/crawl_pal.png',optimize=True)
# 0.12.6 Chibi_Warrior (sword fighter): only the panels the game uses
CA='/home/claude/pod2/assets/heroes/chibi/';CF=['idle','walk','run','attack1','attack2','runatk','hurt','death','throw']
cims=[clean_edges(Image.open(CA+f+'.png').convert('RGBA'),3) for f in CF];cw,chh=320,208
cs=Image.new('RGBA',(max(i.width for i in cims),chh*len(cims)));meta['chibi']={}
for r,(an,im) in enumerate(zip(CF,cims)):
    cs.alpha_composite(im,(0,r*chh));meta['chibi']['ranged' if an=='throw' else an]=dict(fw=cw,fh=chh,n=im.width//cw,ax=170,ay=200,x=0,y=r*chh,img='chibi',art=1)
# pre-render him at the exact on-canvas size (art px x 21/152 world x 4 canvas px) so he's sharp instead of blurred at runtime
from PIL import ImageFilter
K=round(21/152*4,4);import numpy as np
def shrink(im):
    from scipy import ndimage as ndi
    a=np.array(im).astype(float)
    near=np.abs(a[...,:3]-162).sum(2)<75;a[...,3]=np.where(near,0,a[...,3])   # strip the grey-background fringe
    a[...,3]=np.where(ndi.binary_erosion(a[...,3]>0,iterations=1),255,0)
    pm=a.copy();pm[...,:3]*=a[...,3:]/255
    w,h=round(im.width*K),round(im.height*K)
    s2=np.array(Image.fromarray(pm.astype(np.uint8)).resize((w,h),Image.LANCZOS)).astype(float)
    al=np.array(Image.fromarray(a[...,3].astype(np.uint8)).resize((w,h),Image.LANCZOS)).astype(float)
    rgb=np.where(al[...,None]>0,s2[...,:3]*255/np.maximum(al[...,None],1),0)
    out=Image.fromarray(np.dstack([np.clip(rgb,0,255),np.where(al>100,255,0)]).astype(np.uint8))
    return out
cs=clean_edges(shrink(cs),1)
for an in meta['chibi']:
    E=meta['chibi'][an];E.update(fw=round(cw*K),fh=round(chh*K),ax=round(170*K),ay=round(200*K),y=round(E['y']*K),pre=K)
    E.pop('art',None)
cs.save('/home/claude/pod2/crawl_chibi.png',optimize=True)
# 0.12.7 the archer: same treatment as Chibi_Warrior (pre-shrunk to his on-canvas size, halo stripped)
AA='/home/claude/pod2/assets/heroes/archer/';AF=['idle','walk','run','melee','ranged','hurt','death','blowgun']
aims=[clean_edges(Image.open(AA+f+'.png').convert('RGBA'),2) for f in AF];aw,ah=370,258
ash=Image.new('RGBA',(max(i.width for i in aims),ah*len(aims)+16));meta['archer']={}
for r,(an,im) in enumerate(zip(AF,aims)):
    ash.alpha_composite(im,(0,r*ah));meta['archer'][an]=dict(fw=aw,fh=ah,n=im.width//aw,ax=200,ay=250,x=0,y=r*ah,img='archer')
ARW=Image.open(AA+'arrow.png').convert('RGBA');ash.alpha_composite(ARW,(0,ah*len(aims)));meta['archer']['arrow']=dict(fw=ARW.width,fh=ARW.height,n=1,ax=ARW.width-2,ay=ARW.height//2,x=0,y=ah*len(aims),img='archer')
ash=clean_edges(shrink(ash),1)
for an in meta['archer']:
    E=meta['archer'][an];E.update(fw=round(E['fw']*K),fh=round(E['fh']*K),ax=round(E['ax']*K),ay=round(E['ay']*K),x=round(E['x']*K),y=round(E['y']*K),pre=K)
ash.save('/home/claude/pod2/crawl_archer.png',optimize=True)
# 0.12.9 Druid: crisp pixel art (sampled back to her native 8px grid), drawn like the zombies; one 8-frame walk cycle
meta['druid']={}
# 0.12.15 her own idle (breathing, hair sway, staff glint), melee swipe, staff-raise cast and hurt rows (built by /home/claude/druid2/frames.py)
for an,n,yy in [('walk',8,0),('idle',6,56),('melee',3,112),('ranged',4,168),('hurt',2,224),('death',1,280),('run',8,336)]:   # 0.12.58: 4-frame staff swing + run row
    meta['druid'][an]=dict(fw=64,fh=56,n=n,ax=33,ay=53,x=0,y=yy,img='druid',**({'fall':1} if an=='death' else {}))
# 0.12.17 Moss_Mech: original pixel-art mech drawn from shapes by /home/claude/robot/robot.py (64x56 frames, faces left like the druid)
meta['robot']={}
# 0.12.19c (Kyle: a smidgen smaller, not blocky): every 96x84 frame is resampled to 85% with premultiplied Lanczos, then drawn 1:1
RK=.85;RW,RH=round(96*RK),round(84*RK);RS=Image.open('/home/claude/pod2/assets/heroes/warhound_full.png').convert('RGBA');ROUT=Image.new('RGBA',(RW*8,RH*8))
for r_ in range(8):
    for c_ in range(8):
        fr=np.array(RS.crop((c_*96,r_*84,(c_+1)*96,(r_+1)*84))).astype(float)
        if fr[...,3].max()==0:continue
        pm=fr.copy();pm[...,:3]*=fr[...,3:]/255
        ch=[np.array(Image.fromarray(pm[...,k].astype(np.float32),'F').resize((RW,RH),Image.LANCZOS)) for k in range(4)]
        al=np.clip(ch[3],0,255);rgb=np.stack(ch[:3],-1)*255/np.maximum(al[...,None],1)
        al=np.where(al<40,0,np.clip((al-40)*1.25,0,255))   # crisp-but-smooth edge
        ROUT.alpha_composite(Image.fromarray(np.dstack([np.clip(rgb,0,255),al]).astype(np.uint8)),(c_*RW,r_*RH))
ROUT.save('/home/claude/pod2/crawl_robot.png',optimize=True)
for an,n,yy in [('walk',8,0),('idle',4,1),('melee',4,2),('ranged',4,3),('missile',4,4),('throw',3,5),('hurt',2,6),('death',5,7)]:   # Warhound sheet (robot3/des.py), rows at 85%
    yy=yy*RH
    meta['robot'][an]=dict(fw=RW,fh=RH,n=n,ax=round(46*RK),ay=round(80*RK),x=0,y=yy,img='robot',sc=1,pk=1.3,**({'fall':0} if an=='death' else {}))
# 0.12.21 Void_Cultist + his tentacle: original pixel art from /home/claude/cult (cultist.py, tentacle.py), drawn 1:1 like the druid
def resheet(src,dst,fw,fh,cols,rows,K):
    S=Image.open(src).convert('RGBA');W2,H2=round(fw*K),round(fh*K);O=Image.new('RGBA',(W2*cols,H2*rows))
    for r_ in range(rows):
        for c_ in range(cols):
            fr=np.array(S.crop((c_*fw,r_*fh,(c_+1)*fw,(r_+1)*fh))).astype(float)
            if fr[...,3].max()==0:continue
            pm=fr.copy();pm[...,:3]*=fr[...,3:]/255
            ch=[np.array(Image.fromarray(pm[...,k].astype(np.float32),'F').resize((W2,H2),Image.LANCZOS)) for k in range(4)]
            al=np.clip(ch[3],0,255);rgb=np.stack(ch[:3],-1)*255/np.maximum(al[...,None],1);al=np.where(al<40,0,np.clip((al-40)*1.25,0,255))
            O.alpha_composite(Image.fromarray(np.dstack([np.clip(rgb,0,255),al]).astype(np.uint8)),(c_*W2,r_*H2))
    O.save(dst,optimize=True);return W2,H2
CK=.6;CW,CH=resheet('/home/claude/cult/cultist.png','/home/claude/pod2/crawl_cultist.png',64,66,8,7,CK)   # smooth 78% so he matches the other heroes
meta['cultist']={an:dict(fw=CW,fh=CH,n=n,ax=round(32*CK),ay=round(63*CK),x=0,y=yy*CH,img='cultist',pk=1.0) for an,n,yy in [('walk',8,0),('idle',4,1),('melee',4,2),('ranged',4,3),('summon',4,4),('hurt',2,5),('death',5,6)]}
meta['tentacle']={an:dict(fw=112,fh=88,n=n,ax=78,ay=84,x=0,y=yy*88,img='tentacle') for an,n,yy in [('emerge',5,0),('idle',8,1),('attack',6,2),('hit',2,3),('death',6,4)]}   # 0.12.22: 15% taller, no claw tip
# 0.12.11 Lumber_Jack: native art (snapped to 16 colours) upscaled 4x with Scale2x, then smoothed down to his on-canvas size
LA='/home/claude/pod2/assets/heroes/lumberjack/';LF=['idle','walk','run','melee','ranged','hurt','death','spin','chop','leap','rage','roll']
SRC={'idle':('fun',[0]),'walk':('walk',None),'run':('run',None),'melee':('djump',[3,4,5]),'ranged':('bow',None),'hurt':('angry',[0,1]),'death':('pullup',[2,1,0]),
     'chop':('sit',None),'leap':('djump',[0,1,2,3]),'rage':('angry',None),'roll':('roll',None)}
lw,lh=224,188
def lrow(name,idx):
    im=Image.open(LA+name+'.png').convert('RGBA');n=im.width//lw;idx=idx if idx is not None else list(range(n))
    r=Image.new('RGBA',(lw*len(idx),lh))
    for j,i in enumerate(idx):r.alpha_composite(im.crop((i*lw,0,(i+1)*lw,lh)),(j*lw,0))
    return r
rows={}
for an,(src,idx) in SRC.items():rows[an]=lrow(src,idx)
# 0.12.25 (Kyle: the walk didn't read as a walk): re-anchor every walk frame on his head/torso so the body travels smoothly
#   while the legs and arms swing, instead of the whole figure twitching side to side
def steady(row):
    A=np.array(row);n=A.shape[1]//lw;hx=[]
    for i in range(n):
        al=A[:,i*lw:(i+1)*lw,3]>0;ys,xs=np.nonzero(al);top=ys.min();hx.append(xs[(ys>=top)&(ys<top+40)].mean())
    ref=float(np.mean(hx));out=np.zeros_like(A)
    for i in range(n):
        d=int(round(ref-hx[i]));fr=A[:,i*lw:(i+1)*lw];out[:,i*lw:(i+1)*lw]=np.roll(fr,d,axis=1)
    return Image.fromarray(out)
rows['walk']=steady(rows['walk'])
# Whirl_Wind: the 3 spin panels plus the turn-around filled in (mirrored halves of the swing), 6 frames in all
sp=Image.open(LA+'spin.png').convert('RGBA');f=[sp.crop((i*lw,0,(i+1)*lw,lh)) for i in range(3)]
mir=lambda im:im.transpose(Image.FLIP_LEFT_RIGHT)
spin=[f[0],f[1],f[2],mir(f[1]),mir(f[2]),mir(f[0])];rs=Image.new('RGBA',(lw*6,lh))
for j,im in enumerate(spin):rs.alpha_composite(im,(j*lw,0))
rows['spin']=rs
ls=Image.new('RGBA',(max(r.width for r in rows.values()),lh*len(LF)));meta['lumberjack']={}
for r_,an in enumerate(LF):
    ls.alpha_composite(rows[an],(0,r_*lh));meta['lumberjack'][an]=dict(fw=lw,fh=lh,n=rows[an].width//lw,ax=lw-104,ay=176,x=0,y=r_*lh,img='lumberjack',**({'fall':1} if an=='death' else {}))
K2=round(88/128,4)
def lshrink(im):
    a=np.array(im).astype(float);pm=a.copy();pm[...,:3]*=a[...,3:]/255;w,h=round(im.width*K2),round(im.height*K2)
    s2=np.array(Image.fromarray(pm.astype(np.uint8)).resize((w,h),Image.LANCZOS)).astype(float);al=np.array(Image.fromarray(a[...,3].astype(np.uint8)).resize((w,h),Image.LANCZOS)).astype(float)
    rgb=np.where(al[...,None]>0,s2[...,:3]*255/np.maximum(al[...,None],1),0)
    return Image.fromarray(np.dstack([np.clip(rgb,0,255),np.clip((al-40)*1.6,0,255)]).astype(np.uint8))   # soft (not jagged) outline
ls=lshrink(ls)
for an in meta['lumberjack']:
    E=meta['lumberjack'][an];E.update(fw=round(lw*K2),fh=round(lh*K2),ax=round(E['ax']*K2),ay=round(176*K2),y=round(E['y']*K2),pre=K)   # pre=K: 1 sheet px = 1 canvas px
ls.save('/home/claude/pod2/crawl_lumberjack.png',optimize=True)
meta['dog']=json.load(open('/home/claude/dog/dog.json'))   # 0.12.44 Guard Dog (drawn by /home/claude/dog/dog.py)
a=json.load(open('/home/claude/pod2/crawl_atlas.json'));a['units']=meta;json.dump(a,open('/home/claude/pod2/crawl_atlas.json','w'))
print(out.size,{k:{a:(v['n'],v['ax'],v['ay']) for a,v in m.items()} for k,m in meta.items()})
