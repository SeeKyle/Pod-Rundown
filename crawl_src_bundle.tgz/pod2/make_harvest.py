"""0.12.110 (Kyle) THE HARVEST KNIGHT, stage 10 boss. Original pixel art, drawn by code.
A towering scarecrow knight: rusted farm-iron plate stitched over straw, a tattered burlap cape, a carved
jack-o'-lantern for a head with a candle glow that lights up his shoulders, and a huge rusted scythe.
Each part is shaded against one light (top left) plus the warm glow from his head, quantised to short colour
ramps, then the whole frame gets a dark outline like the rest of the game's sprites.
Writes crawl_harvest.png and returns the atlas entries (128x128 frames, facing right; the game flips him)."""
import math, random, json
import numpy as np
from PIL import Image

FW = FH = 160
OX, OY = 16, 32   # 0.12.121: frames grew from 128 to 160 so a raised scythe never clips; everything shifts by (OX, OY)
GROUND = 122 + OY
L = np.array([-0.55, -0.7, 0.45]); L = L / np.linalg.norm(L)

IRON = [(16, 16, 22), (32, 32, 40), (52, 50, 58), (76, 72, 78), (104, 98, 100), (138, 130, 126), (182, 174, 162)]
RUST = [(78, 36, 18), (118, 58, 26), (160, 86, 38)]
BURL = [(38, 28, 18), (62, 46, 28), (92, 70, 42), (126, 98, 60), (160, 130, 84)]
STRAW = [(96, 68, 24), (150, 112, 40), (204, 166, 70), (238, 208, 114)]
PUMP = [(70, 26, 8), (122, 44, 12), (176, 72, 18), (220, 108, 30), (246, 150, 56), (255, 196, 104)]
STEM = [(30, 34, 16), (56, 62, 26), (88, 94, 40)]
WOOD = [(34, 22, 14), (60, 40, 22), (92, 62, 34), (128, 92, 52)]
BLADE = [(40, 42, 50), (70, 72, 82), (104, 108, 118), (142, 146, 154), (186, 190, 196), (236, 238, 240)]
GLOW_IN, GLOW_MID, GLOW_OUT = (255, 246, 190), (255, 206, 90), (255, 130, 30)
OUTL = (16, 10, 10)
CROW = [(10, 10, 14), (26, 26, 36), (50, 52, 70)]


def ramp(pal, v):
    v = max(0.0, min(0.999, v))
    return pal[int(v * len(pal))]


class Canvas:
    def __init__(s):
        s.c = np.zeros((FH, FW, 4), np.float32)
        s.glow = []          # (x, y, strength) warm light sources
        s.add = np.zeros((FH, FW, 3), np.float32)   # additive light (embers, glow halo)

    def put(s, x, y, col, a=1.0):
        if 0 <= x < FW and 0 <= y < FH:
            s.c[y, x, :3] = col
            s.c[y, x, 3] = a

    # ---- shaded primitives -------------------------------------------------
    def capsule(s, p0, p1, r0, r1, pal, light=1.0, bias=0.0, tex=None):
        (x0, y0), (x1, y1) = p0, p1
        dx, dy = x1 - x0, y1 - y0
        ln = math.hypot(dx, dy) or 1e-6
        ux, uy = dx / ln, dy / ln
        px_, py_ = -uy, ux
        rmax = max(r0, r1)
        xa, xb = int(min(x0, x1) - rmax - 1), int(max(x0, x1) + rmax + 2)
        ya, yb = int(min(y0, y1) - rmax - 1), int(max(y0, y1) + rmax + 2)
        for y in range(max(0, ya), min(FH, yb)):
            for x in range(max(0, xa), min(FW, xb)):
                qx, qy = x + .5 - x0, y + .5 - y0
                t = max(0, min(1, (qx * ux + qy * uy) / ln))
                r = r0 + (r1 - r0) * t
                cx, cy = x0 + ux * ln * t, y0 + uy * ln * t
                ddx, ddy = x + .5 - cx, y + .5 - cy
                d = math.hypot(ddx, ddy)
                if d > r:
                    continue
                k = d / r
                nx, ny = ddx / (d or 1) * k, ddy / (d or 1) * k
                nz = math.sqrt(max(0, 1 - k * k))
                v = (nx * L[0] + ny * L[1] + nz * L[2]) * .5 + .5
                v = v * light + bias
                if tex: v += tex(x, y, t, k)
                s.put(x, y, ramp(pal, v))

    def blob(s, cx, cy, rx, ry, pal, light=1.0, bias=0.0, tex=None, rot=0.0):
        cr, sr = math.cos(rot), math.sin(rot)
        R = int(max(rx, ry)) + 2
        for y in range(max(0, int(cy - R)), min(FH, int(cy + R + 1))):
            for x in range(max(0, int(cx - R)), min(FW, int(cx + R + 1))):
                qx, qy = x + .5 - cx, y + .5 - cy
                lx, ly = qx * cr + qy * sr, -qx * sr + qy * cr
                e = (lx / rx) ** 2 + (ly / ry) ** 2
                if e > 1:
                    continue
                nx, ny = lx / rx, ly / ry
                nx, ny = nx * cr - ny * sr, nx * sr + ny * cr
                nz = math.sqrt(max(0, 1 - e))
                v = (nx * L[0] + ny * L[1] + nz * L[2]) * .5 + .5
                v = v * light + bias
                if tex: v += tex(x, y, lx / rx, ly / ry)
                s.put(x, y, ramp(pal, v))

    def poly(s, pts, pal, base=.5, grad=(0, 0), edge=.18, tex=None):
        """flat plate: base tone, a gradient along grad, bright bevel on edges facing the light, dark on the others"""
        xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
        n = len(pts)
        for y in range(max(0, int(min(ys)) - 1), min(FH, int(max(ys)) + 2)):
            for x in range(max(0, int(min(xs)) - 1), min(FW, int(max(xs)) + 2)):
                px_, py_ = x + .5, y + .5
                inside = False; j = n - 1; best = 9e9; bn = (0, 0)
                for i in range(n):
                    xi, yi = pts[i]; xj, yj = pts[j]
                    if (yi > py_) != (yj > py_) and px_ < (xj - xi) * (py_ - yi) / ((yj - yi) or 1e-9) + xi:
                        inside = not inside
                    ex, ey = xj - xi, yj - yi; el = math.hypot(ex, ey) or 1e-6
                    t = max(0, min(1, ((px_ - xi) * ex + (py_ - yi) * ey) / (el * el)))
                    d = math.hypot(px_ - (xi + ex * t), py_ - (yi + ey * t))
                    if d < best: best = d; bn = (ey / el, -ex / el)
                    j = i
                if not inside:
                    continue
                v = base + grad[0] * (px_ - xs[0]) / 40 + grad[1] * (py_ - ys[0]) / 40
                if best < 1.6:
                    f = bn[0] * L[0] + bn[1] * L[1]
                    v += edge * (1 if f < 0 else -1)
                if tex: v += tex(x, y)
                s.put(x, y, ramp(pal, v))

    def line(s, p0, p1, col, w=1):
        (x0, y0), (x1, y1) = p0, p1
        n = int(max(abs(x1 - x0), abs(y1 - y0)) * 2) + 1
        for i in range(n + 1):
            t = i / n
            x, y = x0 + (x1 - x0) * t, y0 + (y1 - y0) * t
            for oy in range(w):
                s.put(int(x), int(y) + oy, col)

    def finish(s, outline=True):
        img = s.c.copy()
        a = img[:, :, 3] > 0
        # warm glow from the head lights up whatever is near it (strongest on the side facing it)
        if s.glow:
            yy, xx = np.mgrid[0:FH, 0:FW]
            for (gx, gy, st, R) in s.glow:
                d = np.hypot(xx - gx, yy - gy)
                f = np.clip(1 - d / R, 0, 1) ** 1.6 * st
                f = f * a
                for k, c in enumerate((255, 150, 50)):
                    img[:, :, k] = img[:, :, k] * (1 - f * .55) + c * f * .55
        if outline:
            m = a
            o = np.zeros_like(m)
            o[1:, :] |= m[:-1, :]; o[:-1, :] |= m[1:, :]; o[:, 1:] |= m[:, :-1]; o[:, :-1] |= m[:, 1:]
            o &= ~m
            img[o, :3] = OUTL; img[o, 3] = 1
        img[:, :, :3] = np.clip(img[:, :, :3] + s.add, 0, 255)
        out = np.zeros((FH, FW, 4), np.uint8)
        out[:, :, :3] = np.clip(img[:, :, :3], 0, 255)
        out[:, :, 3] = (np.clip(img[:, :, 3], 0, 1) * 255).astype(np.uint8)
        # additive glow outside the body (halo, embers): written where transparent
        halo = (s.add.sum(axis=2) > 6) & (out[:, :, 3] == 0)
        out[halo, :3] = np.clip(s.add[halo], 0, 255)
        out[halo, 3] = np.clip(s.add[halo].max(axis=1) * 1.4, 0, 200).astype(np.uint8)
        return Image.fromarray(out, 'RGBA')


def rot(p, o, a):
    x, y = p[0] - o[0], p[1] - o[1]
    return (o[0] + x * math.cos(a) - y * math.sin(a), o[1] + x * math.sin(a) + y * math.cos(a))


def jitter(seed):
    r = random.Random(seed)
    return lambda: r.random()


# ---------------------------------------------------------------------------- the knight
def knight(P, seed=1):
    """P: pose dict. All angles in radians, 0 = pointing straight down for limbs."""
    C = Canvas()
    R = random.Random(seed)
    bob, lean = P.get('bob', 0), P.get('lean', 0)
    hip = (62 + OX + P.get('dx', 0), 78 + OY + bob)
    neck = rot((hip[0] + 1, hip[1] - 35), hip, lean)
    sh_f = rot((hip[0] + 11, hip[1] - 30), hip, lean)     # front shoulder
    sh_b = rot((hip[0] - 10, hip[1] - 31), hip, lean)     # back shoulder
    head = rot((hip[0] + 2, hip[1] - 49), hip, lean)
    head = (head[0] + P.get('hx', 0), head[1] + P.get('hy', 0))
    glow = P.get('glow', 1.0)

    def limb(o, a, l):
        return (o[0] + math.sin(a) * l, o[1] + math.cos(a) * l)

    straw_tex = lambda x, y, t, k: (0.12 if (x * 7 + y * 3) % 5 == 0 else 0)

    # --- cape (behind everything): tattered burlap hanging from the shoulders, swinging with motion
    cs = P.get('cape', 0)
    top_l, top_r = rot((hip[0] - 10, hip[1] - 28), hip, lean), rot((hip[0] + 4, hip[1] - 29), hip, lean)
    bot_y = hip[1] + 26
    pts = [top_l, top_r, (top_r[0] - 4 - cs * 3, bot_y - 6)]
    for i in range(7):   # ragged bottom edge
        x = top_r[0] - 6 - cs * 3 - i * 4.2 - cs * i * .8
        pts.append((x, bot_y + (4 if i % 2 else -1) + R.randint(-1, 2)))
    pts.append((top_l[0] - 6 - cs * 6, bot_y - 10))
    C.poly(pts, BURL, base=.32, grad=(.25, -.12), edge=.1, tex=lambda x, y: (-.12 if (x + 2 * y) % 7 == 0 else 0) + (.08 if y % 6 == 0 else 0))

    # --- back arm + back leg
    ka, kb = P.get('lb', (0.15, -0.1)), P.get('lf', (-0.15, 0.1))   # (thigh angle, shin angle relative)
    def leg(side, A, front):
        hp = (hip[0] + side * 6, hip[1] + 2)
        knee = limb(hp, A[0], 19)
        foot = limb(knee, A[0] + A[1], 20)
        pal_bias = 0 if front else -.18
        C.capsule(hp, knee, 8.0, 6.6, BURL, bias=pal_bias - .2, tex=lambda x, y, t, k: (-.15 if (x + y) % 4 == 0 else 0))   # burlap trouser
        C.capsule(knee, foot, 7.0, 6.0, IRON, bias=pal_bias + .02, tex=lambda x, y, t, k: (-.25 if ((x * 13 + y * 7) % 29) < 3 else 0))
        for k in range(5):
            sx = foot[0] - 5 + k * 2.4; C.line((sx, foot[1] - 4), (sx - 2 + k, foot[1] - 9 - k % 2), ramp(STRAW, .55 + (k % 3) * .15 + pal_bias))                                                       # greave
        C.blob(knee[0] + 1, knee[1], 6.2, 5.4, IRON, bias=pal_bias + .1)                                                 # knee cop
        for k in range(5):                                                                                               # straw poking out at the knee
            sx = knee[0] - 5 + k * 2.4; C.line((sx, knee[1] + 4), (sx - 2 + k, knee[1] + 9 + k % 2), ramp(STRAW, .55 + (k % 3) * .15 + pal_bias))
        bt = (foot[0] + 4, foot[1] + 2)
        C.poly([(foot[0] - 7, foot[1] - 4), (foot[0] + 5, foot[1] - 5), (bt[0] + 7, bt[1] + 1), (bt[0] + 7, bt[1] + 4), (foot[0] - 8, bt[1] + 4)], IRON, base=.38 + pal_bias, grad=(.2, .1), edge=.25)
        return foot

    def arm(side, sh, A, front, hold=False):
        el = limb(sh, A[0], 15)
        hand = limb(el, A[0] + A[1], 14)
        b = 0 if front else -.2
        C.capsule(sh, el, 5.0, 4.4, IRON, bias=b - .06, tex=lambda x, y, t, k: (.22 if abs(t - .55) < .05 else -.22 if ((x * 7 + y * 13) % 29) < 3 else 0))
        C.capsule(el, hand, 4.6, 4.0, IRON, bias=b + .02, tex=lambda x, y, t, k: (.25 if abs(t - .3) < .05 else -.2 if ((x * 11 + y * 5) % 31) < 3 else 0))
        C.blob(el[0], el[1], 4.0, 3.8, IRON, bias=b + .08)
        for k in range(5):   # straw out of the wrist and the elbow
            a_ = A[0] + A[1] + (k - 2) * .35
            w0 = limb(el, A[0] + A[1], 13)
            C.line(w0, limb(w0, a_ + 1.2, 5 + k % 2), ramp(STRAW, .5 + (k % 3) * .17 + b))
            C.line(el, limb(el, A[0] + 3.0 + (k - 2) * .3, 6), ramp(STRAW, .45 + (k % 3) * .17 + b))
        C.blob(hand[0], hand[1], 4.4, 4.0, IRON, bias=b + .12)       # gauntlet
        for k in range(3): C.put(int(hand[0] - 2 + k * 2), int(hand[1] + 2), ramp(IRON, .1 + b))
        return el, hand

    leg(-1, ka, False)
    el_b, hand_b = arm(-1, sh_b, P.get('ab', (0.3, -0.4)), False)

    # --- torso: straw-stuffed body under a rusted breastplate, burlap tabard, rope belt
    C.blob(hip[0] - 1, hip[1] - 16, 17, 21, STRAW, bias=-.15, tex=lambda x, y, a_, b_: (.15 if (x * 3 + y) % 4 == 0 else -.05), rot=lean)
    tor = [rot(p, hip, lean) for p in [(hip[0] - 17, hip[1] - 33), (hip[0] + 16, hip[1] - 33), (hip[0] + 20, hip[1] - 19), (hip[0] + 14, hip[1] - 2), (hip[0] - 15, hip[1] - 2), (hip[0] - 20, hip[1] - 19)]]
    def rust_tex(x, y):
        h = (x * 73856093 ^ y * 19349663) & 1023
        return -.22 if h < 70 else (.08 if h > 990 else 0)
    C.poly(tor, IRON, base=.55, grad=(-.45, .3), edge=.28, tex=rust_tex)
    for k in range(40):   # rust blooms
        rx_, ry_ = R.uniform(-15, 15), R.uniform(-30, -4)
        p = rot((hip[0] + rx_, hip[1] + ry_), hip, lean)
        if C.c[int(p[1]), int(p[0]), 3] > 0 and C.c[int(p[1]), int(p[0]), 0] < 200: C.put(int(p[0]), int(p[1]), RUST[R.randint(0, 2)])
    # plate seam + rivets + a rust streak
    a1, a2 = rot((hip[0] - 18, hip[1] - 18), hip, lean), rot((hip[0] + 19, hip[1] - 18), hip, lean)
    C.line(a1, a2, ramp(IRON, .12))
    for k in range(5):
        p = rot((hip[0] - 13 + k * 7, hip[1] - 30), hip, lean); C.put(int(p[0]), int(p[1]), ramp(IRON, .95))
        p = rot((hip[0] - 13 + k * 7, hip[1] - 16), hip, lean); C.put(int(p[0]), int(p[1]), ramp(IRON, .95))
    for k in range(6):
        p = rot((hip[0] + 3, hip[1] - 12 + k * 2), hip, lean); C.put(int(p[0]), int(p[1]), RUST[k % 3])
    # stitched patch on the plate
    for k in range(4):
        p = rot((hip[0] - 7 + k * 2, hip[1] - 20 + (k % 2)), hip, lean); C.put(int(p[0]), int(p[1]), (26, 18, 12))
    # tabard / skirt of burlap strips
    for i in range(7):
        x0 = hip[0] - 15 + i * 4.8
        p0 = rot((x0, hip[1] - 2), hip, lean); p1 = (p0[0] + P.get('skirt', 0) * (i - 2) * .5, p0[1] + 12 + (i % 2) * 3)
        C.capsule(p0, p1, 3.0, 2.4, BURL, bias=-.02 + (i % 2) * .06)
    # rope belt with a knot
    b0, b1 = rot((hip[0] - 16, hip[1] - 3), hip, lean), rot((hip[0] + 15, hip[1] - 3), hip, lean)
    C.capsule(b0, b1, 1.8, 1.8, STRAW, bias=-.12, tex=lambda x, y, t, k: (.18 if x % 3 == 0 else 0))
    C.blob(b1[0] - 3, b1[1] + 1, 2.6, 2.4, STRAW, bias=0)
    # straw bursting out at the waist
    for k in range(12):
        p = rot((hip[0] - 16 + k * 2.8, hip[1] - 1), hip, lean)
        C.line(p, (p[0] - 1 + R.randint(-1, 1), p[1] + 3 + R.randint(0, 3)), ramp(STRAW, .55 + R.random() * .4))

    leg(1, kb, True)

    # --- pauldrons (big, rounded, riveted) and a straw collar
    def pauldron(sh, bias):
        for k in range(6):
            C.line((sh[0] - 4 + k * 1.8, sh[1] + 6), (sh[0] - 6 + k * 2.4, sh[1] + 11 + k % 3), ramp(STRAW, .5 + (k % 3) * .15 + bias))
        C.blob(sh[0], sh[1] + 1, 11.5, 8.4, IRON, bias=bias + .08, rot=lean - .25, tex=lambda x, y, a_, b_: (-.2 if abs(b_ - .35) < .1 else 0))
        C.put(int(sh[0] - 3), int(sh[1] - 2), ramp(IRON, .97)); C.put(int(sh[0] + 3), int(sh[1] - 1), ramp(IRON, .97))
    pauldron(sh_b, -.18)
    for k in range(18):
        p = (neck[0] - 11 + k * 1.3, neck[1] + 3)
        C.line(p, (p[0] + R.randint(-3, 3), p[1] - 4 - R.randint(0, 5)), ramp(STRAW, .45 + R.random() * .5))

    # --- jack-o'-lantern head: ribbed pumpkin, curled stem, carved face glowing from inside
    hr, hrx, hry = head, 15.5, 13
    flick = glow
    def rib(x, y, nx, ny):
        return .16 * math.cos(nx * 3.4 * math.pi / 1.0) - .04
    C.blob(hr[0], hr[1], hrx, hry, PUMP, bias=-.05, tex=rib, rot=P.get('tilt', 0))
    # ribs as dark grooves
    for kx in (-0.62, -0.22, 0.22, 0.62):
        for yy in range(-12, 13):
            yf = yy / 13
            w = math.sqrt(max(0, 1 - yf * yf))
            x = hr[0] + kx * hrx * w
            y = hr[1] + yy
            if C.c[int(y), int(x), 3] > 0: C.put(int(x), int(y), ramp(PUMP, .18))
    # stem + a curled vine
    st0 = (hr[0] + 1, hr[1] - hry + 1)
    C.capsule(st0, (st0[0] + 2, st0[1] - 6), 2.6, 1.8, STEM, bias=.05)
    for k in range(8):
        a = k * .7
        C.put(int(st0[0] + 3 + math.cos(a) * (2 + k * .4)), int(st0[1] - 5 + math.sin(a) * 2), STEM[1 + (k % 2)])
    # carved face (facing right, so the face sits a little right of centre)
    fx, fy = hr[0] + 4, hr[1]
    def glow_px(x, y, kin):
        col = GLOW_IN if kin > .66 else GLOW_MID if kin > .33 else GLOW_OUT
        if flick < .5: col = tuple(int(c * (.55 + flick * .8)) for c in col)
        C.put(int(x), int(y), col)
    for (ex, ey) in ((fx - 6, fy - 4), (fx + 5, fy - 4)):     # triangle eyes
        for yy in range(0, 6):
            for xx in range(-yy, yy + 1):
                if abs(xx) <= yy * .9: glow_px(ex + xx * .8, ey - 2 + yy, 1 - yy / 6 + (0 if abs(xx) < 1 else -.3))
    glow_px(fx, fy + 1, .8); glow_px(fx - 1, fy + 2, .5); glow_px(fx + 1, fy + 2, .5)   # nose
    for xx in range(-10, 11):                                                            # jagged grin
        top = fy + 6 + (0 if xx % 4 in (0, 1) else 1) - (1 if abs(xx) > 6 else 0)
        h = 4 if abs(xx) < 7 else 2
        if xx in (-3, 3): h = 1   # teeth
        for yy in range(h):
            glow_px(fx + xx, top + yy, .9 - yy * .3 - abs(xx) / 20)
    C.glow.append((fx, fy + 2, .6 * flick, 40))
    # halo + light spilling out of the face
    yy_, xx_ = np.mgrid[0:FH, 0:FW]
    d = np.hypot(xx_ - fx, yy_ - (fy + 1))
    h = np.clip(1 - d / 28, 0, 1) ** 2.0 * 75 * flick
    C.add[:, :, 0] += h; C.add[:, :, 1] += h * .55; C.add[:, :, 2] += h * .15
    if P.get('fire'):   # flaming head (enraged): licks of fire off the top
        for i in range(14):
            x = hr[0] - 9 + i * 1.4 + R.uniform(-1, 1)
            hgt = 4 + R.random() * 9 * P['fire']
            for k in range(int(hgt)):
                c = GLOW_IN if k < 2 else GLOW_MID if k < hgt * .6 else GLOW_OUT
                C.put(int(x + math.sin(k * .7 + i) * .8), int(hr[1] - hry - k + 2), c)
    for (ex, ey, life) in P.get('embers', []):
        C.add[int(ey) % FH, int(ex) % FW] += (255 * life, 170 * life, 60 * life)

    # --- front arm holding the scythe
    ab = P.get('af', (-0.4, -0.6))
    el_f, hand_f = None, None
    # scythe: haft through the front hand along angle wa; blade at the top end
    wa = P.get('wa', -2.6)   # angle of the haft from the hand toward the blade end (radians, screen)
    hand_pos = limb(sh_f, ab[0], 15); hand_pos = limb(hand_pos, ab[0] + ab[1], 14)
    hx, hy = hand_pos
    HL = P.get('haft', 52)   # 0.12.121: shorter when it's tipped toward the camera (overhead wind-up)
    top = (hx + math.cos(wa) * HL, hy + math.sin(wa) * HL)
    butt = (hx - math.cos(wa) * 20, hy - math.sin(wa) * 20)
    C.capsule(butt, top, 2.4, 2.1, WOOD, bias=.02, tex=lambda x, y, t, k: (-.18 if int(t * 40) % 7 == 0 else 0))
    C.blob(top[0], top[1], 3.4, 3.4, IRON, bias=.12)   # iron collar at the head
    # blade: a long curved crescent sweeping back from the top of the haft
    bd = P.get('bd', 1)  # +1: the blade juts out to his front and curls down
    spine = [top]; ang = wa + bd * 1.45; n_ = 18; Lb = 54
    for i in range(n_):
        t = (i + 1) / n_
        ang += bd * .075 * (1 + t)
        spine.append((spine[-1][0] + math.cos(ang) * Lb / n_, spine[-1][1] + math.sin(ang) * Lb / n_))
    backs, fronts = [], []
    for i, (x, y) in enumerate(spine):
        t = i / n_
        j = min(i, n_ - 1)
        dx, dy = spine[j + 1][0] - spine[j][0], spine[j + 1][1] - spine[j][1]
        ll = math.hypot(dx, dy) or 1
        nx, ny = -dy / ll * bd, dx / ll * bd          # points to the blade's back (convex, upper side)
        wb, wf = 3.0 * (1 - t) + .5 + (1.6 if (i % 3 == 1 and t < .8) else 0), 9.5 * (1 - t ** 1.5) + .3
        backs.append((x - nx * wb, y - ny * wb)); fronts.append((x + nx * wf, y + ny * wf))
    blade = backs + fronts[::-1]
    C.poly(blade, BLADE, base=.6, grad=(-.15, -.05), edge=.32, tex=lambda x, y: (-.22 if ((x * 31 + y * 17) % 23) < 3 else 0))
    eg = P.get('edge', 1.0)
    for i in range(n_):   # the cutting edge glows ember-hot (like the light in his head), rust and pitting near the haft
        f0, f1 = fronts[i], fronts[i + 1]
        C.line(f0, f1, GLOW_MID if i > 2 else GLOW_OUT)
        mx, my = (f0[0] + f1[0]) / 2, (f0[1] + f1[1]) / 2
        ix, iy = mx + (spine[i][0] - mx) * .25, my + (spine[i][1] - my) * .25
        C.put(int(ix), int(iy), GLOW_OUT if i % 2 else (200, 90, 30))
        if i < 7: C.put(int(backs[i][0]), int(backs[i][1]), RUST[1 + i % 2])
        yy_, xx_ = int(my), int(mx)
        for oy in range(-3, 4):
            for ox in range(-3, 4):
                if 0 <= yy_ + oy < FH and 0 <= xx_ + ox < FW:
                    w = max(0, 1 - math.hypot(ox, oy) / 3.6) * 34 * eg
                    C.add[yy_ + oy, xx_ + ox] += (w, w * .5, w * .12)
    for k in range(3):    # embers dripping off the edge
        i = 5 + k * 4
        if i < len(fronts):
            ex, ey = fronts[i]
            for d_ in range(1, 3 + k):
                C.add[int(ey + d_ * 2) % FH, int(ex) % FW] += (180 / d_, 90 / d_, 20 / d_)
    # a tattered strip of burlap knotted under the blade, fluttering
    tx_, ty_ = top
    C.blob(tx_, ty_ + 3, 2.6, 2.2, BURL, bias=.05)
    for k in range(3):
        C.capsule((tx_ - 1 + k, ty_ + 4), (tx_ - 4 + k * 2 - P.get('cape', 0) * 3, ty_ + 12 + k * 3), 1.3, .9, BURL, bias=-.05 + k * .05)
    pts_out = fronts
    el_f, hand_f = arm(1, sh_f, ab, True, hold=True)
    pauldron(sh_f, 0)

    # --- crows on the back shoulder (idle only; they flap off when he fights)
    crows = list(P.get('crows', []))
    if P.get('perch'): crows.append((sh_b[0] - 2, sh_b[1] - 8 + P.get('perch_dy', 0), 0))
    for (cx_, cy_, flap) in crows:
        C.blob(cx_, cy_, 4.2, 3.2, CROW, bias=.05)
        C.blob(cx_ + 4, cy_ - 3, 2.6, 2.4, CROW, bias=.1)
        C.line((cx_ + 6, cy_ - 3), (cx_ + 8, cy_ - 2), (200, 170, 60)); C.put(int(cx_ + 5), int(cy_ - 4), (250, 60, 40))
        if flap:
            C.poly([(cx_ - 1, cy_ - 1), (cx_ - 7, cy_ - 7 - flap * 3), (cx_ + 2, cy_ - 2)], CROW, base=.4)
        else:
            C.poly([(cx_ - 3, cy_ - 1), (cx_ + 2, cy_ - 1), (cx_ - 5, cy_ + 2)], CROW, base=.35)
        C.line((cx_ - 1, cy_ + 2), (cx_ - 1, cy_ + 4), (90, 80, 40))
    for (fxs, fys) in P.get('smear', []):    # swing smear (pale arc behind the blade)
        C.add[int(fys) % FH, int(fxs) % FW] += (150, 150, 140)
    return C


def frame(P, seed=1):
    return knight(P, seed).finish()


# ---------------------------------------------------------------------------- animations
def anims():
    A = {}
    crows_idle = lambda i: [(54 - 3 + (i % 2) * .5, 50 - (1 if i % 3 == 0 else 0), 0)]
    # idle: slow breathing, eyes flicker, a crow shifting on his shoulder
    A['idle'] = [dict(lf=(-0.28, .08), lb=(0.3, .02), bob=[0, 0, 1, 1, 1, 0][i], glow=[1, .9, 1, .8, 1, .95][i], af=(0.22, -0.55), ab=(-0.12, -0.25), wa=-1.22,
                      perch=1, perch_dy=[0, 0, 1, 1, 0, -1][i], cape=[0, .1, .2, .1, 0, -.1][i]) for i in range(6)]
    # walk: heavy, weighted stride, the scythe carried upright
    W = []
    for i in range(8):
        ph = i / 8 * 2 * math.pi
        s = math.sin(ph)
        W.append(dict(bob=round(abs(math.cos(ph)) * 2) - 1, lean=.04, lf=(-0.45 * s, max(0, .5 * s) + .05), lb=(0.45 * s, max(0, -.5 * s) + .05),
                      af=(0.2 + .12 * s, -0.55), ab=(-0.1 - .2 * s, -0.25), wa=-1.25 + .04 * s, glow=.95 + .05 * math.cos(ph * 2), cape=.3 + .2 * s, skirt=.4 * s))
    A['walk'] = W
    # run (the charge): leaning in, long strides, scythe swept back low
    Rn = []
    for i in range(6):
        ph = i / 6 * 2 * math.pi
        s = math.sin(ph)
        Rn.append(dict(bob=round(abs(math.cos(ph)) * 3) - 2, lean=.22, lf=(-0.8 * s, max(0, .9 * s) + .1), lb=(0.8 * s, max(0, -.9 * s) + .1),
                       af=(0.5, -0.3), ab=(-0.5 - .4 * s, -0.6), wa=-2.9, glow=1, cape=1 + .3 * s, skirt=.8 * s, hx=1))
    A['run'] = Rn
    # sweep: wind up high behind him, a smeared arc across, follow-through low
    sw = [(-0.4, -1.95, 0), (-1.6, -3.0, 0), (-2.3, -3.6, 0), (-1.2, -2.2, 1), (0.2, -0.6, 1), (0.8, 0.4, 1), (0.9, 0.7, 0), (0.3, -0.6, 0)]
    S = []
    for i, (sa, wa, sm) in enumerate(sw):
        sm_pts = []
        if sm:
            for k in range(30):
                a = -2.6 + k * .1
                sm_pts.append((76 + OX + math.cos(a) * 44, 56 + OY + math.sin(a) * 44))
        S.append(dict(af=(sa, -0.3), ab=(0.2 + sa * .3, -0.5), wa=wa, lean=[.0, -.12, -.18, .05, .2, .25, .22, .08][i], bob=[0, 0, -1, 0, 1, 2, 2, 1][i],
                      lf=(-0.3, .2), lb=(0.35, .1), glow=[1, 1.1, 1.2, 1.2, 1.1, 1, 1, 1][i], smear=sm_pts, cape=[0, -.3, -.5, .3, .8, 1, .7, .3][i]))
    A['sweep'] = S
    # slam: scythe raised overhead with both hands, brought straight down into the ground
    sl = [(-2.4, -1.6), (-2.6, -1.25), (-2.7, -1.1), (-1.0, -.2), (0.3, 1.2), (0.35, 1.35), (0.0, .6)]
    A['slam'] = [dict(af=((-3.2, 0.15) if i < 3 else (a, -0.2)), ab=((-2.95, 0.3) if i < 3 else (a * .9, -0.3)), haft=[38, 36, 34, 52, 52, 52, 52][i], wa=w, lean=[-.1, -.15, -.18, .1, .3, .32, .15][i], bob=[0, -1, -2, 0, 3, 3, 1][i],
                      lf=(-0.5, .5) if i >= 4 else (-0.2, .1), lb=(0.5, .3) if i >= 4 else (0.3, .1), glow=1.1, cape=[0, -.2, -.4, .4, 1, .9, .4][i], bd=1)
                 for i, (a, w) in enumerate(sl)]
    # cast (Murder of Crows / Bonfire): arms flung up, head flares, embers pour from the grin
    Cst = []
    for i in range(6):
        emb = []
        rr = random.Random(i)
        for k in range(4 + i * 3):
            emb.append((72 + OX + rr.uniform(-6, 10) + k * .8, 40 + OY - rr.uniform(0, 26) - i * 1.5, max(.2, 1 - k / 20)))
        Cst.append(dict(af=(-2.2 - i * .06, -0.2), ab=(-2.5 + i * .05, -0.3), wa=-1.3, lean=-.1, bob=-1, glow=1 + i * .12, embers=emb, fire=.3 + i * .12, cape=.2,
                        crows=[(46 + OX - i * 4, 40 + OY - i * 6, 1 + i % 2), (58 + OX + i * 3, 36 + OY - i * 7, 2 - i % 2)] if i < 5 else []))
    A['cast'] = Cst
    A['hurt'] = [dict(lean=-.2, bob=0, hx=-2, glow=.6, af=(0.1, -0.4), ab=(0.3, -0.3), wa=-1.1, cape=-.4),
                 dict(lean=-.1, bob=1, hx=-1, glow=.8, af=(0.18, -0.5), ab=(0.1, -0.3), wa=-1.18, cape=-.2)]
    A['enraged'] = [dict(A['idle'][i], fire=1, glow=1.25, crows=[]) for i in range(6)]
    return A


def death_frames():
    """he buckles to his knees, topples forward into a heap of straw and armour, the pumpkin rolls off and the glow dies"""
    out = []
    for i in range(10):
        if i < 4:
            P = dict(bob=i * 4, lean=.1 + i * .12, lf=(-0.2 - i * .3, 1.2 * i / 3), lb=(0.2 + i * .25, 1.2 * i / 3), af=(0.4 + i * .3, -0.2),
                     ab=(0.6, -0.3), wa=-1.2 + i * .6, glow=1 - i * .12, cape=-.2)
            out.append(frame(P, seed=40 + i))
        else:
            k = (i - 4) / 5
            C = Canvas()
            R = random.Random(9)
            # heap of straw and armour plates on the ground
            # 0.12.121 (Kyle: bigger heap): a real pile of the knight: the cape spread out, plates and greaves, a pile of straw spilling out
            cx0 = 64 + OX
            C.poly([(cx0 - 40, GROUND), (cx0 - 30, GROUND - 14 + k * 2), (cx0 - 8, GROUND - 22 + k * 3), (cx0 + 20, GROUND - 17 + k * 2), (cx0 + 40, GROUND)], BURL, base=.3, grad=(.2, -.1), edge=.12,
                   tex=lambda x, y: (-.12 if (x + 2 * y) % 7 == 0 else 0))
            for (px_, py_, rx, ry) in [(cx0 - 14, GROUND - 13, 17, 10), (cx0 + 10, GROUND - 10, 13, 8), (cx0 - 28, GROUND - 5, 9, 5), (cx0 + 26, GROUND - 5, 10, 5), (cx0 - 2, GROUND - 21, 10, 7)]:
                C.blob(px_, py_ + k * 2, rx, ry * (1 - k * .15), IRON, bias=-.05, tex=lambda x, y, a_, b_: (-.2 if ((x * 7 + y * 13) % 29) < 3 else 0))
            for j in range(110):
                x = cx0 - 36 + R.uniform(0, 72); y = GROUND - 1 - R.uniform(0, 26 * (1 - k * .2)) * (1 - abs(x - cx0) / 46)
                C.line((x, y), (x + R.uniform(-5, 5), y + R.uniform(1, 6)), ramp(STRAW, .25 + R.random() * .7))
            for k2 in range(8):
                x = cx0 - 20 + k2 * 6; C.line((x, GROUND - 2), (x + R.uniform(-3, 3), GROUND - 10 - R.uniform(0, 5) * (1 - k)), ramp(STRAW, .6))
            C.capsule((cx0 - 40, GROUND - 2), (cx0 + 40, GROUND - 7 + k * 3), 2.2, 2.0, WOOD)   # the scythe lies across the heap
            # the pumpkin rolls away to the right, wobbling, its glow fading out
            rx_ = 70 + OX + 10 + k * 34
            C.blob(rx_, GROUND - 10, 11, 9.5, PUMP, bias=-.08, rot=k * 2.5, tex=lambda x, y, nx, ny: .16 * math.cos(nx * 3.4 * math.pi) - .04)
            g = max(0, 1 - k * 1.1)
            for (ex, ey) in ((rx_ - 2, GROUND - 13), (rx_ + 6, GROUND - 13)):
                for yy in range(4):
                    for xx in range(-yy, yy + 1):
                        c = tuple(int(v * g + 30 * (1 - g)) for v in GLOW_MID)
                        C.put(int(ex + xx * .8), int(ey - 2 + yy), c)
            for xx in range(-6, 7):
                c = tuple(int(v * g + 30 * (1 - g)) for v in GLOW_OUT)
                C.put(int(rx_ + 2 + xx), int(GROUND - 6 + (xx % 3 == 0)), c)
            out.append(C.finish())
    return out


def build():
    A = anims()
    rows = [(k, [frame(P, seed=7 + i) for i, P in enumerate(v)]) for k, v in A.items()]
    rows.append(('die', death_frames()))
    ncol = max(len(f) for _, f in rows)
    sheet = Image.new('RGBA', (ncol * FW, len(rows) * FH), (0, 0, 0, 0))
    meta = {}
    for r, (k, fr) in enumerate(rows):
        for i, im in enumerate(fr):
            sheet.alpha_composite(im, (i * FW, r * FH))
        meta[k] = dict(fw=FW, fh=FH, n=len(fr), ax=64 + OX, ay=GROUND, x=0, y=r * FH, img='harvest', art=0)
    sheet.save('/home/claude/pod2/crawl_harvest.png', optimize=True)
    return meta


if __name__ == '__main__':
    m = build()
    print(json.dumps({k: (v['n'], v['y']) for k, v in m.items()}))
