# 0.12.80 Needs Repair for Eddie's decks (prices: Scryfall USD, Nov 2026)
REPAIR_ED = {
 "eddie_vivi": [
  {
   "card": "Fog Bank",
   "read": 2,
   "why": "A defensive wall in a deck that wins by attacking with Vivi; it never grows him or pings.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Izzet Signet",
     "why": "2-mana rock; Mana is the deck's weakest stat",
     "usd": 0.34
    },
    {
     "tier": "Super budget",
     "card": "Third Path Iconoclast",
     "why": "every noncreature spell makes a Soldier",
     "usd": 0.34
    },
    {
     "tier": "Medium",
     "card": "Ponder",
     "why": "1-mana cantrip: grows Vivi and digs",
     "usd": 1.54
    },
    {
     "tier": "Any cost",
     "card": "Mana Vault",
     "why": "huge early burst for the big spell turn",
     "usd": 111.47
    }
   ]
  },
  {
   "card": "Staff of the Flame Magus",
   "read": 2,
   "why": "3 mana for 1 life per red spell; it doesn't touch the board or grow Vivi.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Expressive Iteration",
     "why": "2-mana dig that grows Vivi",
     "usd": 0.33
    },
    {
     "tier": "Super budget",
     "card": "Arcane Signet",
     "why": "2-mana any-color rock",
     "usd": 0.56
    },
    {
     "tier": "Medium",
     "card": "Ledger Shredder",
     "why": "connives on your second spell each turn",
     "usd": 8.73
    },
    {
     "tier": "Any cost",
     "card": "Jeweled Lotus",
     "why": "a free turn-3 Vivi plus a spell",
     "usd": 39.84
    }
   ]
  },
  {
   "card": "Staff of the Mind Magus",
   "read": 2,
   "why": "Same as the Flame Magus: small life gain for 3 mana.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Consider",
     "why": "1-mana cantrip",
     "usd": 0.38
    },
    {
     "tier": "Super budget",
     "card": "Mind Stone",
     "why": "2-mana rock that cashes in for a card",
     "usd": 0.47
    },
    {
     "tier": "Medium",
     "card": "Lightning Greaves",
     "why": "free haste and shroud for Vivi",
     "usd": 2.71
    },
    {
     "tier": "Any cost",
     "card": "Mana Crypt",
     "why": "the best rock there is",
     "usd": 35.88
    }
   ]
  },
  {
   "card": "Lightning Talons",
   "read": 3,
   "why": "+3/+0 first strike aura: fine, but an aura that dies with Vivi and doesn't draw.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Mirrorshell Crab",
     "why": "ward 3 creature that also counters",
     "usd": 0.29
    },
    {
     "tier": "Super budget",
     "card": "Rogue's Passage",
     "why": "makes Vivi unblockable from a land slot",
     "usd": 0.31
    },
    {
     "tier": "Medium",
     "card": "Kessig Flamebreather",
     "why": "pings on every noncreature spell",
     "usd": 2.32
    },
    {
     "tier": "Any cost",
     "card": "Sword of Fire and Ice",
     "why": "protection, damage and a card each hit",
     "usd": 46.54
    }
   ]
  }
 ],
 "eddie_bruce": [
  {
   "card": "Fated Firepower",
   "read": 2,
   "why": "XRRR for a damage boost; the deck rarely deals that many separate hits.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Tatyova, Steward of Tides",
     "why": "lands become 5/5s once you have seven",
     "usd": 0.23
    },
    {
     "tier": "Super budget",
     "card": "Growth Spiral",
     "why": "draw and an extra land",
     "usd": 0.25
    },
    {
     "tier": "Medium",
     "card": "Three Visits",
     "why": "a dual land into play for 2",
     "usd": 5.05
    },
    {
     "tier": "Any cost",
     "card": "Field of the Dead",
     "why": "Zombies from every land drop",
     "usd": 27.41
    }
   ]
  },
  {
   "card": "Cavalcade of Calamity",
   "read": 2,
   "why": "Pings with 1-power attackers; this deck's creatures are big.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Harrow",
     "why": "two lands, both landfall triggers",
     "usd": 0.3
    },
    {
     "tier": "Super budget",
     "card": "Rampant Growth",
     "why": "basic land into play",
     "usd": 0.31
    },
    {
     "tier": "Medium",
     "card": "Lotus Cobra",
     "why": "landfall mana",
     "usd": 3.06
    },
    {
     "tier": "Any cost",
     "card": "Amulet of Vigor",
     "why": "bounce lands and tapped lands untap",
     "usd": 47.96
    }
   ]
  },
  {
   "card": "Hawkeye's Bow",
   "read": 3,
   "why": "A 1-mana ping equipment; fine but small next to the deck's threats.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Explore",
     "why": "extra land and a card",
     "usd": 0.19
    },
    {
     "tier": "Super budget",
     "card": "Ranger's Path",
     "why": "two Forests into play",
     "usd": 0.26
    },
    {
     "tier": "Medium",
     "card": "Oracle of Mul Daya",
     "why": "lands off the top",
     "usd": 2.68
    },
    {
     "tier": "Any cost",
     "card": "Rites of Flourishing",
     "why": "everyone plays an extra land and draws",
     "usd": 0.55
    }
   ]
  },
  {
   "card": "Treasure Nabber",
   "read": 3,
   "why": "Only works if opponents tap artifacts on your turn.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Farseek",
     "why": "a typed dual into play",
     "usd": 0.43
    },
    {
     "tier": "Super budget",
     "card": "Kodama's Reach",
     "why": "two basics",
     "usd": 2.18
    },
    {
     "tier": "Medium",
     "card": "Ohran Frostfang",
     "why": "attacking creatures draw on hit",
     "usd": 7.04
    },
    {
     "tier": "Any cost",
     "card": "Rishkar's Expertise",
     "why": "draw equal to the Hulk's power",
     "usd": 4.61
    }
   ]
  }
 ],
 "eddie_cloud": [
  {
   "card": "Ultimate Magic: Meteor",
   "read": 2,
   "why": "Hits your own team as hard as theirs in a deck that wants a big board.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Chaos Warp",
     "why": "answers anything",
     "usd": 0.63
    },
    {
     "tier": "Super budget",
     "card": "Austere Command",
     "why": "pick the modes that spare your equipment",
     "usd": 0.69
    },
    {
     "tier": "Medium",
     "card": "Farewell",
     "why": "one-sided if you pick",
     "usd": 5.14
    },
    {
     "tier": "Any cost",
     "card": "Generous Gift",
     "why": "destroy any permanent",
     "usd": 1.94
    }
   ]
  },
  {
   "card": "Ashe, Princess of Dalmasca",
   "read": 3,
   "why": "A 3/2 that digs for an artifact only when it attacks.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Godo, Bandit Warlord",
     "why": "fetches Equipment and gives an extra combat",
     "usd": 1.18
    },
    {
     "tier": "Super budget",
     "card": "Sram, Senior Edificer",
     "why": "draws on every Equipment",
     "usd": 1.76
    },
    {
     "tier": "Medium",
     "card": "Steelshaper's Gift",
     "why": "1-mana Equipment tutor",
     "usd": 8.37
    },
    {
     "tier": "Any cost",
     "card": "Stoneforge Mystic",
     "why": "tutors an Equipment and cheats it in",
     "usd": 29.18
    }
   ]
  },
  {
   "card": "Seifer Almasy",
   "read": 3,
   "why": "Double strike only for a lone attacker, and Cloud wants several equipped attackers.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Kemba, Kha Regent",
     "why": "Cat tokens from equipment",
     "usd": 0.25
    },
    {
     "tier": "Super budget",
     "card": "Fervent Champion",
     "why": "1-drop with cheaper equip",
     "usd": 0.33
    },
    {
     "tier": "Medium",
     "card": "Reconnaissance",
     "why": "free untaps after combat",
     "usd": 5.22
    },
    {
     "tier": "Any cost",
     "card": "Sword of Feast and Famine",
     "why": "untap lands and discard",
     "usd": 40.25
    }
   ]
  },
  {
   "card": "Cartographer's Survey",
   "read": 3,
   "why": "4 mana for two tapped lands; slow ramp next to the rocks.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Rampant Growth",
     "why": "2-mana ramp",
     "usd": 0.31
    },
    {
     "tier": "Super budget",
     "card": "Wayfarer's Bauble",
     "why": "colorless ramp",
     "usd": 0.32
    },
    {
     "tier": "Medium",
     "card": "Three Visits",
     "why": "2-mana dual into play",
     "usd": 5.05
    },
    {
     "tier": "Any cost",
     "card": "Jeweled Lotus",
     "why": "a free turn-3 Cloud",
     "usd": 39.84
    }
   ]
  }
 ],
 "eddie_kasla": [
  {
   "card": "Cathartic Reunion",
   "read": 2,
   "why": "Discard two to draw three; the deck has better card flow through Kasla.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Inspiring Overseer",
     "why": "a flier and a card",
     "usd": 0.24
    },
    {
     "tier": "Super budget",
     "card": "Faithless Looting",
     "why": "cheap filtering",
     "usd": 0.48
    },
    {
     "tier": "Medium",
     "card": "Welcoming Vampire",
     "why": "draws when small creatures enter",
     "usd": 3.32
    },
    {
     "tier": "Any cost",
     "card": "Rhystic Study",
     "why": "draws all game",
     "usd": 67.49
    }
   ]
  },
  {
   "card": "Venerated Loxodon",
   "read": 3,
   "why": "Counters on the convokers; fine but small.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Intangible Virtue",
     "why": "tokens +1/+1 and vigilance",
     "usd": 0.29
    },
    {
     "tier": "Super budget",
     "card": "Divine Visitation",
     "why": "tokens become 4/4 fliers",
     "usd": 0.46
    },
    {
     "tier": "Medium",
     "card": "Cathars' Crusade",
     "why": "counters on every creature entering",
     "usd": 8.12
    },
    {
     "tier": "Any cost",
     "card": "Anointed Procession",
     "why": "doubles tokens",
     "usd": 59.89
    }
   ]
  },
  {
   "card": "Shatter the Source",
   "read": 3,
   "why": "6 mana convoke removal; fine but narrow.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Lightning Helix",
     "why": "kill and life",
     "usd": 0.32
    },
    {
     "tier": "Super budget",
     "card": "Chaos Warp",
     "why": "answers anything",
     "usd": 0.63
    },
    {
     "tier": "Medium",
     "card": "Flawless Maneuver",
     "why": "free team indestructible",
     "usd": 7.74
    },
    {
     "tier": "Any cost",
     "card": "Teferi's Protection",
     "why": "saves the board from anything",
     "usd": 47.1
    }
   ]
  },
  {
   "card": "Temporal Cleansing",
   "read": 3,
   "why": "A convoke tuck; slow for what it does.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Skyclave Apparition",
     "why": "exiles a cheap permanent",
     "usd": 0.3
    },
    {
     "tier": "Super budget",
     "card": "March of the Multitudes",
     "why": "convoke X tokens at instant speed",
     "usd": 1.74
    },
    {
     "tier": "Medium",
     "card": "Chord of Calling",
     "why": "convoke creature tutor",
     "usd": 7.37
    },
    {
     "tier": "Any cost",
     "card": "Smothering Tithe",
     "why": "Treasure whenever they draw",
     "usd": 60.05
    }
   ]
  }
 ],
 "eddie_splinter": [
  {
   "card": "Unexpected Fangs",
   "read": 2,
   "why": "One counter and lifelink for 2; small.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Prosperous Thief",
     "why": "Treasure on every Ninja hit",
     "usd": 0.19
    },
    {
     "tier": "Super budget",
     "card": "Ingenious Mastery",
     "why": "draw three",
     "usd": 0.24
    },
    {
     "tier": "Medium",
     "card": "Mist-Syndicate Naga",
     "why": "copies itself on every hit (twice with Splinter)",
     "usd": 2.68
    },
    {
     "tier": "Any cost",
     "card": "Fierce Guardianship",
     "why": "free counterspell",
     "usd": 64.5
    }
   ]
  },
  {
   "card": "Arcane Adaptation",
   "read": 2,
   "why": "Makes everything a Ninja, but most of the deck already is one.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Gingerbrute",
     "why": "evasive haste 1-drop for ninjutsu",
     "usd": 0.35
    },
    {
     "tier": "Super budget",
     "card": "Ninja of the Deep Hours",
     "why": "classic ninjutsu draw",
     "usd": 1.67
    },
    {
     "tier": "Medium",
     "card": "Throat Slitter",
     "why": "ninjutsu that kills a creature",
     "usd": 3.44
    },
    {
     "tier": "Any cost",
     "card": "Smothering Tithe",
     "why": "Treasure whenever they draw",
     "usd": 60.05
    }
   ]
  },
  {
   "card": "Vanquish the Horde",
   "read": 3,
   "why": "An 8-mana wipe in a deck of small creatures.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Fatal Push",
     "why": "1-mana kill",
     "usd": 0.88
    },
    {
     "tier": "Super budget",
     "card": "Anguished Unmaking",
     "why": "instant exile anything",
     "usd": 1.26
    },
    {
     "tier": "Medium",
     "card": "Toxic Deluge",
     "why": "flexible wipe",
     "usd": 2.6
    },
    {
     "tier": "Any cost",
     "card": "Teferi's Protection",
     "why": "saves your board",
     "usd": 47.1
    }
   ]
  },
  {
   "card": "Executioner's Hood",
   "read": 3,
   "why": "Intimidate equipment; Splinter already makes Ninjas unblockable.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Arcane Signet",
     "why": "2-mana any-color rock",
     "usd": 0.56
    },
    {
     "tier": "Super budget",
     "card": "Talisman of Dominance",
     "why": "2-mana U/B rock",
     "usd": 0.83
    },
    {
     "tier": "Medium",
     "card": "Fellwar Stone",
     "why": "2-mana rock",
     "usd": 2.64
    },
    {
     "tier": "Any cost",
     "card": "Rhystic Study",
     "why": "draws all game",
     "usd": 67.49
    }
   ]
  }
 ],
 "eddie_miles": [
  {
   "card": "Web-Shooters",
   "read": 3,
   "why": "+1/+1 reach and a tap on attack; small in a counters deck.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Rampant Growth",
     "why": "ramp; only 45% reach 5 by turn 6",
     "usd": 0.31
    },
    {
     "tier": "Super budget",
     "card": "Rishkar, Peema Renegade",
     "why": "counters and mana dorks",
     "usd": 0.36
    },
    {
     "tier": "Medium",
     "card": "Guardian Project",
     "why": "draws on every new creature",
     "usd": 5.17
    },
    {
     "tier": "Any cost",
     "card": "Nature's Lore",
     "why": "untapped ramp",
     "usd": 2.53
    }
   ]
  },
  {
   "card": "Nyxborn Wolf",
   "read": 3,
   "why": "A 3/1 or a +3/+1 bestow; plain.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Conclave Mentor",
     "why": "an extra counter and life",
     "usd": 0.79
    },
    {
     "tier": "Super budget",
     "card": "Corpsejack Menace",
     "why": "doubles counters",
     "usd": 0.9
    },
    {
     "tier": "Medium",
     "card": "Walking Ballista",
     "why": "counter sink and removal",
     "usd": 7.97
    },
    {
     "tier": "Any cost",
     "card": "Doubling Season",
     "why": "doubles counters",
     "usd": 32.68
    }
   ]
  },
  {
   "card": "Path of Discovery",
   "read": 3,
   "why": "Every creature explores: slow card flow for 4 mana.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Shamanic Revelation",
     "why": "draw per creature",
     "usd": 1.68
    },
    {
     "tier": "Super budget",
     "card": "Return of the Wildspeaker",
     "why": "draw equal to greatest power",
     "usd": 2.93
    },
    {
     "tier": "Medium",
     "card": "Rishkar's Expertise",
     "why": "draw equal to your biggest creature",
     "usd": 4.61
    },
    {
     "tier": "Any cost",
     "card": "The Great Henge",
     "why": "draws and counters every creature",
     "usd": 63.59
    }
   ]
  },
  {
   "card": "Friendly Neighborhood",
   "read": 3,
   "why": "Three 1/1s and a pump land; slow.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Cultivate",
     "why": "two basics",
     "usd": 0.32
    },
    {
     "tier": "Super budget",
     "card": "Beast Within",
     "why": "answers anything",
     "usd": 0.47
    },
    {
     "tier": "Medium",
     "card": "Heroic Intervention",
     "why": "saves the board",
     "usd": 6.7
    },
    {
     "tier": "Any cost",
     "card": "Three Visits",
     "why": "a dual into play",
     "usd": 5.05
    }
   ]
  }
 ],
 "eddie_narset": [
  {
   "card": "Soulfire Grand Master",
   "read": 3,
   "why": "Lifelink spells and a buyback; little to do with Narset's free spells.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Jeskai Charm",
     "why": "removal or a team pump",
     "usd": 0.25
    },
    {
     "tier": "Super budget",
     "card": "Azorius Signet",
     "why": "2-mana W/U rock",
     "usd": 0.31
    },
    {
     "tier": "Medium",
     "card": "Relentless Assault",
     "why": "an extra combat Narset can cast free",
     "usd": 3.26
    },
    {
     "tier": "Any cost",
     "card": "Mana Crypt",
     "why": "turn-3 Narset",
     "usd": 35.88
    }
   ]
  },
  {
   "card": "Chain Reaction",
   "read": 3,
   "why": "Damage-based wipe that also hits your few creatures.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Hour of Revelation",
     "why": "destroy all nonland permanents",
     "usd": 1.29
    },
    {
     "tier": "Super budget",
     "card": "Blasphemous Act",
     "why": "13 damage wipe, usually 1 mana",
     "usd": 1.72
    },
    {
     "tier": "Medium",
     "card": "Farewell",
     "why": "choose what to exile",
     "usd": 5.14
    },
    {
     "tier": "Any cost",
     "card": "Cyclonic Rift",
     "why": "one-sided bounce",
     "usd": 38.41
    }
   ]
  },
  {
   "card": "Combat Celebrant",
   "read": 3,
   "why": "4/1 that only gives an extra combat if it survives; fragile.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Seize the Day",
     "why": "an extra combat with flashback",
     "usd": 1.93
    },
    {
     "tier": "Super budget",
     "card": "Moraug, Fury of Akoum",
     "why": "extra combat on landfall",
     "usd": 2.11
    },
    {
     "tier": "Medium",
     "card": "Aurelia, the Warleader",
     "why": "an extra combat on attack",
     "usd": 4.86
    },
    {
     "tier": "Any cost",
     "card": "Hellkite Charger",
     "why": "flying extra combats",
     "usd": 3.44
    }
   ]
  },
  {
   "card": "Clash of Titans",
   "read": 3,
   "why": "5-mana fight; your creatures are few and small.",
   "swaps": [
    {
     "tier": "Super budget",
     "card": "Lightning Helix",
     "why": "kill and life",
     "usd": 0.32
    },
    {
     "tier": "Super budget",
     "card": "Chaos Warp",
     "why": "answers anything",
     "usd": 0.63
    },
    {
     "tier": "Medium",
     "card": "Generous Gift",
     "why": "destroy any permanent",
     "usd": 1.94
    },
    {
     "tier": "Any cost",
     "card": "Teferi's Protection",
     "why": "saves Narset from anything",
     "usd": 47.1
    }
   ]
  }
 ]
}
