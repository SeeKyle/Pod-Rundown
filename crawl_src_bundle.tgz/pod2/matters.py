"""0.12.313 Matters formula (Kyle's Deck_Bump_Formula):
card value x (1 + 0.04*Y), Y = cards in the deck over the Matters type's flat value.
Each card gets only its single best Matters boost (no stacking). Applied on top of every existing formula:
it scales the card's existing tag points, so nothing old is removed."""
import re, json
CT = json.load(open('/home/claude/pod2/card_text.json'))
FLAT = dict(lands=35, typal=30, spells=35, noncreature=25, graveyard=10, artifacts=40, enchantments=35, tokens=20)
NAME = dict(lands='Lands Matters', typal='Typal', spells='Spellslinger', noncreature='Noncreature Spells Matters',
            graveyard='Graveyard Matters', artifacts='Artifacts Matters', enchantments='Enchantments Matters', tokens='Tokens Matters')
SEES = {
 'lands': r"landfall|whenever (a|one or more|another) lands? (you control )?enters?|(number of|for each) lands? (you control|on the battlefield|in your graveyard)|equal to the number of lands|differently named lands|land cards? (in|from) your graveyard",
 'spells': r"\bprowess\b|magecraft|spell mastery|whenever you cast an instant or sorcery|whenever you cast or copy an instant or sorcery|instant (and|or) sorcery spells? (you cast )?costs?|instant or sorcery card",
 'noncreature': r"noncreature spell",
 'graveyard': r"threshold|flashback|unearth|\bescape\b|\bdelve\b|descend|undergrowth|scavenge|embalm|eternalize|disturb|from your graveyard (to|onto) the battlefield|cards? in your graveyard|creature cards? in your graveyard|cast [^.]{0,30}from your graveyard|return target [^.]{0,40}card from your graveyard",
 'artifacts': r"for each artifact|number of artifacts|whenever an artifact|whenever (you cast )?an artifact|artifact spells? (you cast )?costs?|equipment you control|whenever an equipment|artifacts you control (have|are)|\bbargain\b|affinity for artifacts|improvise|metalcraft|artifact cards? (from|in) your graveyard",
 'enchantments': r"constellation|whenever an enchantment|for each enchantment|number of enchantments|enchantment spells? (you cast )?costs?|whenever you cast an aura|aura spells|lore counter|\beerie\b|enchantment cards? (from|in) your graveyard",
 'tokens': r"populate|tokens? you control|would create (one or more )?tokens?|twice that many|sacrifice (a|another) (creature|permanent|token)|\bbargain\b|casualty|creatures you control get \+\d",
}
def _tl(name):
    t = CT.get(name, '').split('\n')
    return (t[1] if len(t) > 1 else ''), '\n'.join(t[2:])
def _subtypes(tl):
    if 'Creature' not in tl and 'Kindred' not in tl: return []
    return tl.split('—')[1].split() if '—' in tl else []
def _plural(t):
    irr = {'Elf': 'Elves', 'Dwarf': 'Dwarves', 'Wolf': 'Wolves', 'Werewolf': 'Werewolves', 'Fungus': 'Fungi', 'Octopus': 'Octopi', 'Mouse': 'Mice'}
    return irr.get(t, t + ('es' if t.endswith(('s', 'x', 'ch', 'sh')) else 's'))

def counts(cards):
    n = dict(lands=0, spells=0, noncreature=0, graveyard=0, artifacts=0, enchantments=0, tokens=0)
    typ = {}
    for c in cards:
        tl, tx = _tl(c['name']) if c['note'] != 'basic land' else ('Basic Land', '')
        low = tx.lower()
        if c.get('is_land'): n['lands'] += 1
        else:
            if 'Creature' not in tl:
                n['spells'] += 1; n['noncreature'] += 1
        if 'Artifact' in tl: n['artifacts'] += 1
        if 'Enchantment' in tl: n['enchantments'] += 1
        if re.search(r'create[^.]{0,80}token', low): n['tokens'] += 1
        if re.search(r'\bmill|\bsurveil|discard (a|two|three|that|your|x|up to)|put [^.]{0,60}into your graveyard', low) and 'cycling' not in low:
            n['graveyard'] += 1
        for s in _subtypes(tl): typ[s] = typ.get(s, 0) + 1
    return n, typ

def apply(cards, M):
    n, typ = counts(cards)
    Y = {k: max(0, n[k] - FLAT[k]) for k in n}
    ytyp = {t: v - FLAT['typal'] for t, v in typ.items() if v > FLAT['typal']}
    info = dict(counts=n, Y=Y, typal={t: typ[t] for t in ytyp}, boosted=[])
    if not any(Y.values()) and not ytyp: return info
    for c in cards:
        if c['note'] == 'basic land': continue
        tl, tx = _tl(c['name'])
        best = (0, None)
        for k, rx in SEES.items():
            if Y.get(k) and re.search(rx, tx, re.I) and Y[k] > best[0]: best = (Y[k], NAME[k])
        for t, y in ytyp.items():
            if y > best[0] and re.search(r"\b(other|another|each|whenever an?|number of|for each|spells? cost|you control|target)\b[^.\n]{0,30}\b(" + t + '|' + _plural(t) + r")\b", tx):
                best = (y, 'Typal (' + t + ')')
        if best[1]:
            m = 1 + 0.04 * best[0]
            for e in c['entries']: e['pts'] = round(e['pts'] * m, 4)
            c['matters'] = (best[1], round(m, 2))
            info['boosted'].append((c['name'], best[1], round(m, 2)))
    return info
