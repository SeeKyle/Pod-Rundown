# 0.12.234 (Kyle) CHEEZ: the free CraftPix samurai repainted into a neon-lit techno samurai (Kamigawa: Neon Dynasty vibe) that looks like Cheez:
# short spiky black hair (no ponytail), black glasses with a cyan glint, goatee + mustache; matte black-navy kimono whose light folds glow neon cyan,
# a hot-magenta sash and scabbard, a cyan beam katana.
import pickle,numpy as np,json
from PIL import Image
F=pickle.load(open('frames.pkl','rb'))
lum=lambda c:.3*c[0]+.59*c[1]+.11*c[2]
SKIN={(209,175,162),(163,142,137)}
NEONC=(60,235,255);NEONC2=(30,150,200);MAG=(255,60,200);MAGD=(120,24,96)
def remap(c):
    c=tuple(int(v) for v in c)
    if c==(54,60,93):return (24,96,130)            # kimono highlight folds: deep teal glow
    if c==(50,60,92):return (34,40,62)
    if c==(73,61,81):return NEONC
    if c in ((33,28,50),(37,36,57),(29,28,48),(33,28,48),(27,31,49),(33,28,52),(33,31,50)):return (22,22,32)   # matte kimono
    if c in ((21,22,36),(27,22,36),(14,18,39)):return (14,14,22)
    if c==(185,98,83):return MAG                               # sash / ties / soles
    if c==(79,46,56):return MAGD
    if c==(71,84,83):return MAG                                # scabbard
    if c in ((16,39,47),(7,15,26)):return MAGD
    return c
def dehalo(o):
    m=o[...,3]>0;H,W=m.shape;kill=[]
    for y,x in zip(*np.where(m)):
        c=tuple(int(v) for v in o[y,x,:3])
        if not(c in SKIN or lum(c)>110):continue
        n=sum(1 for dy,dx in ((1,0),(-1,0),(0,1),(0,-1)) if not(0<=y+dy<H and 0<=x+dx<W) or not m[y+dy,x+dx])
        if n>=2:kill.append((y,x))
    for y,x in kill:o[y,x,3]=0
    return o
def facecomp(o,top,H,blade):
    m=o[...,3]>0;sk=np.zeros(m.shape,bool)
    for y,x in zip(*np.where(m)):
        if tuple(int(v) for v in o[y,x,:3]) in SKIN and y<top+H*.32 and not blade[y,x]:sk[y,x]=True
    seen=np.zeros_like(sk);comps=[]
    for y,x in zip(*np.where(sk)):
        if seen[y,x]:continue
        st=[(y,x)];seen[y,x]=1;comp=[]
        while st:
            cy,cx=st.pop();comp.append((cy,cx))
            for dy in (-1,0,1):
                for dx in (-1,0,1):
                    ny,nx=cy+dy,cx+dx
                    if 0<=ny<sk.shape[0] and 0<=nx<sk.shape[1] and sk[ny,nx] and not seen[ny,nx]:seen[ny,nx]=1;st.append((ny,nx))
        if len(comp)>=4:comps.append(comp)
    if not comps:return []
    # the head is the highest skin patch (hands can be bigger when the arms are up), merge patches right beside it
    comps.sort(key=lambda c:np.mean([p[0] for p in c]));h0=comps[0];hy=np.mean([p[0] for p in h0]);hx=np.mean([p[1] for p in h0])
    return [p for c in comps if abs(np.mean([q[0] for q in c])-hy)<5 and abs(np.mean([q[1] for q in c])-hx)<8 for p in c]
def paint(f):
    o=dehalo(dehalo(f.copy()));m=o[...,3]>0;ys,xs=np.where(m)
    if not len(ys):return o
    top=ys.min();H=ys.max()-top
    # blade: long horizontal runs of light pixels -> cyan beam
    light=np.zeros(m.shape,bool)
    for y,x in zip(ys,xs):
        if tuple(int(v) for v in o[y,x,:3]) in SKIN or lum(o[y,x,:3])>120:light[y,x]=True
    blade=np.zeros(m.shape,bool)
    for y in range(o.shape[0]):
        run=0
        for x in range(o.shape[1]+1):
            if x<o.shape[1] and light[y,x]:run+=1
            else:
                if run>=6:
                    x0=x-run;thick=sum(light[yy,x0:x].sum() for yy in (y-2,y+2) if 0<=yy<o.shape[0])
                    if thick<run*.5:blade[y,x0:x]=True   # a blade is a thin line; a face is a thick patch
                run=0
    # face: skin pixels in the upper part, not blade
    face=facecomp(o,top,H,blade)
    for y,x in zip(ys,xs):o[y,x,:3]=remap(o[y,x,:3])
    for y,x in zip(*np.where(blade)):o[y,x,:3]=(210,255,255) if (y+x)%2 else NEONC
    # 0.12.234: replace the whole head with Cheez's (drawn template, facing right): find the collar (top of the kimono), erase everything above it
    # around the head (old head + big ponytail), and stamp the new head on the neck.
    K={(24,96,130),(22,22,32)}   # kimono body colours only (the hair shares the darkest navy)
    ys2,xs2=np.where(o[...,3]>0)
    if len(ys2) and (xs2.max()-xs2.min())<(ys2.max()-ys2.min())*1.3:
        neck=(max(p[0] for p in face)+1) if len(face)>=6 else None   # the old face's chin is the most reliable neck
        for y in (range(ys2.min()+8,ys2.max()) if neck is None else []):
            row=[x for x in range(o.shape[1]) if o[y,x,3] and tuple(int(v) for v in o[y,x,:3]) in K]
            if len(row)>=5:neck=y;break
        if neck:
            sk=[x for y in range(neck-12,neck) for x in range(o.shape[1]) if o[y,x,3] and tuple(int(v) for v in o[y,x,:3]) in SKIN]
            cx=int(np.median(sk)) if sk else int(np.median([x for y in range(neck-10,neck) for x in range(o.shape[1]) if o[y,x,3]] or [48]))
            keep=lambda c:c in ((210,255,255),NEONC)   # beam katana
            for y in range(0,neck):
                for x in (range(o.shape[1]) if y<neck-14 else range(max(0,cx-20),min(o.shape[1],cx+10))):
                    if o[y,x,3] and not keep(tuple(int(v) for v in o[y,x,:3])):o[y,x,3]=0
            HEAD=["..H.H..H.H..",".HHhHHhHHH.H","HHHHHHHHHHHH","HHHHHHHHHHHO","HHHHSHSSSSHO","HHHSSSSSSSSO","HHGGGGGGGGG.","HHsSGLGSGLG.","HOsSSSSSSSSO",".HsSSSSSSBBO","..sSSBBBBBB.","..sSSSBBBS..","...SSSBBB...","....SSBB...."]
            COL={'H':(14,12,16),'h':(60,60,80),'S':(214,172,150),'s':(170,120,104),'G':(10,10,14),'L':(150,240,255),'B':(26,18,18),'O':(8,6,8)}
            hy0=neck-len(HEAD)+1;hx0=cx-7
            for r,row in enumerate(HEAD):
                for c,ch in enumerate(row):
                    if ch=='.':continue
                    y,x=hy0+r,hx0+c
                    if 0<=y<o.shape[0] and 0<=x<o.shape[1]:o[y,x]=(*COL[ch],255)
    # circuit dots on the matte kimono
    for y,x in zip(*np.where(o[...,3]>0)):
        if tuple(o[y,x,:3])==(22,22,32) and (x*7+y*13)%29==0:o[y,x,:3]=NEONC
    return o
P={k:[paint(f) for f in v] for k,v in F.items()}
pickle.dump(P,open('painted.pkl','wb'))
pv=Image.new('RGBA',(96*8,96*2),(40,44,52,255))
for i,f in enumerate(P['idle'][:2]+P['walk'][:2]+P['atk2'][:4]):pv.alpha_composite(Image.fromarray(f),(i*96,0))
for i,f in enumerate(P['run'][:2]+P['atk3'][:2]+P['atk1'][3:5]+P['hurt'][:1]+P['dead'][2:3]):pv.alpha_composite(Image.fromarray(f),(i*96,96))
pv.resize((pv.width*2,pv.height*2),0).save('/tmp/cz_paint.png')
