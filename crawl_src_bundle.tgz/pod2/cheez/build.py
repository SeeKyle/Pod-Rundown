# 0.12.234 CHEEZ sheet: frames from extract.py + paint.py (CraftPix free samurai, repainted). Faces right.
import pickle,json,numpy as np
from PIL import Image
P=pickle.load(open('/home/claude/cheez_refs/painted.pkl','rb'))
from scipy import ndimage
import sys;sys.path.insert(0,'/home/claude/pod2/cheez');from palettes import apply   # 0.12.237 (Kyle): the green samurai (option B, Acid Green)
def pick(L,idx):return [L[i] for i in idx]
MAG={(255,60,200),(120,24,96),(38,22,38)}
def clean(f):   # 0.12.235: drop tiny stray specks (old ponytail tips, hair crumbs) not touching the body
    f=f.copy();m=f[...,3]>0;lab,n=ndimage.label(m,structure=np.ones((3,3)));
    if n<2:return f
    sz=ndimage.sum(m,lab,range(1,n+1));big=int(np.argmax(sz))+1;core=ndimage.binary_dilation(lab==big,iterations=1)
    for k in range(1,n+1):
        if k!=big and sz[k-1]<40 and not (core&(lab==k)).any():f[lab==k,3]=0
        elif k!=big:
            ys=np.where(lab==k)[0];bt=np.where(lab==big)[0].min()
            if ys.max()<bt+4:f[lab==k,3]=0   # floats above his head (old ponytail tip)
    return f
def beam(f,ax):   # drawn blade (right of the body) -> cyan beam with a soft bloom
    f=f.copy();H,W=f.shape[:2];bl=np.zeros((H,W),bool)
    for y in range(H-14):
        for x in range(ax+12,W):
            if f[y,x,3] and tuple(f[y,x,:3]) in MAG:bl[y,x]=1
    f[bl,:3]=(60,235,255);core=bl&~ndimage.binary_erosion(bl);f[bl&(np.arange(H)[:,None]%2==0),:3]=(210,255,255)
    halo=ndimage.binary_dilation(bl)&(f[...,3]==0);f[halo]=(60,235,255,90)
    return f
BEAM={(60,235,255),(210,255,255)}
def extend(f,ax,EXT=7):   # 0.12.238 (Kyle): longer beam blade: every horizontal beam run of 5+ grows EXT px at its tip (the end away from his body)
    f=f.copy();H,W=f.shape[:2];isb=lambda y,x:f[y,x,3]==255 and tuple(f[y,x,:3]) in BEAM
    add=[]
    for y in range(H-14):
        x=0
        while x<W:
            if isb(y,x):
                x0=x
                while x<W and isb(y,x):x+=1
                x1=x-1
                if x1-x0+1>=5:
                    d=1 if (x0+x1)/2>=ax else -1;tip=x1 if d>0 else x0;c=tuple(f[y,tip,:3])
                    for k in range(1,EXT+1):
                        xx=tip+d*k
                        if 0<=xx<W and f[y,xx,3]<255:add.append((y,xx,c))
            else:x+=1
    for y,x,c in add:f[y,x]=(*c,255)
    for y,x,c in add:
        for dy in(-1,1):
            if 0<=y+dy<H and f[y+dy,x,3]==0:f[y+dy,x]=(60,235,255,90)
    return f
def glint(f):   # visor glint: one cyan pixel on the glasses lens (darkest row near the top of the head)
    return f
rows=[('idle',P['idle']),('walk',P['walk']),('run',P['run']),('melee',P['atk3'][:3]),('iai',[P['atk1'][0],P['atk1'][1],P['atk2'][2],P['atk2'][3]]),('draw',pick(P['atk1'],[0,1,1,3,3])),('sake',P['shield']),('hurt',P['hurt']),('death',pick(P['dead'],[0,0,2])),('jump',pick(P['jump'],[1,1,2,3,4,4,6,7]))]
fw=fh=96;W=max(len(f) for _,f in rows)*fw;out=Image.new('RGBA',(W,fh*len(rows)));meta={}
f0=P['idle'][0];m=f0[...,3]>0;ys,xs=np.where(m);y0,y1=ys.min(),ys.max();legs=np.where(m[y1-5:y1+1].any(0))[0]
AX=int(round(legs.mean()));AY=int(y1)+1;PRE=float(round(.4737*int(y1-y0+1)/68,4))
for r,(an,fr) in enumerate(rows):
    for i,f in enumerate(fr):
        f=clean(f)
        if an=='run' and i==6:f=f.copy();f[:44,:36,3]=0   # 0.12.246: stray old ponytail in this one frame
        if an in('melee','draw'):f=beam(f,AX)
        f=apply(f,'B_acid_green')
        f=extend(f,AX)
        out.alpha_composite(Image.fromarray(f),(i*fw,r*fh))
    meta[an]=dict(fw=fw,fh=fh,n=len(fr),ax=AX,ay=AY,x=0,y=r*fh,img='cheez',pre=PRE,art=1,faceR=1,pk=1.8)
meta['death']['fall']=0;meta['ranged']=dict(meta['iai'])
out.save('/home/claude/pod2/crawl_cheez.png',optimize=True)
A=json.load(open('/home/claude/pod2/crawl_atlas.json'));A['units']['cheez']=meta;json.dump(A,open('/home/claude/pod2/crawl_atlas.json','w'))
print({k:v['n'] for k,v in meta.items()},AX,AY,PRE)
