# 0.12.234 CHEEZ sheet: frames from extract.py + paint.py (CraftPix free samurai, repainted). Faces right.
import pickle,json,numpy as np
from PIL import Image
P=pickle.load(open('/home/claude/cheez_refs/painted.pkl','rb'))
from scipy import ndimage
import sys;sys.path.insert(0,'/home/claude/pod2/cheez');from palettes import apply   # 0.12.237 (Kyle): the green samurai (option B, Acid Green)
def pick(L,idx):return [L[i] for i in idx]
MAG={(255,60,200),(120,24,96)}
def clean(f):   # 0.12.235: drop tiny stray specks (old ponytail tips, hair crumbs) not touching the body
    f=f.copy();m=f[...,3]>0;lab,n=ndimage.label(m,structure=np.ones((3,3)));
    if n<2:return f
    sz=ndimage.sum(m,lab,range(1,n+1));big=int(np.argmax(sz))+1;core=ndimage.binary_dilation(lab==big,iterations=1)
    for k in range(1,n+1):
        if k!=big and sz[k-1]<40 and not (core&(lab==k)).any():f[lab==k,3]=0
    return f
def beam(f,ax):   # drawn blade (right of the body) -> cyan beam with a soft bloom
    f=f.copy();H,W=f.shape[:2];bl=np.zeros((H,W),bool)
    for y in range(H-14):
        for x in range(ax+12,W):
            if f[y,x,3] and tuple(f[y,x,:3]) in MAG:bl[y,x]=1
    f[bl,:3]=(60,235,255);core=bl&~ndimage.binary_erosion(bl);f[bl&(np.arange(H)[:,None]%2==0),:3]=(210,255,255)
    halo=ndimage.binary_dilation(bl)&(f[...,3]==0);f[halo]=(60,235,255,90)
    return f
def glint(f):   # visor glint: one cyan pixel on the glasses lens (darkest row near the top of the head)
    return f
rows=[('idle',P['idle']),('walk',P['walk']),('run',P['run']),('melee',P['atk3'][:3]),('iai',P['atk2']),('draw',pick(P['atk1'],[0,1,1,3,3])),('sake',P['shield']),('hurt',P['hurt']),('death',pick(P['dead'],[0,0,2])),('jump',pick(P['jump'],[1,1,2,3,4,4,6,7]))]
fw=fh=96;W=max(len(f) for _,f in rows)*fw;out=Image.new('RGBA',(W,fh*len(rows)));meta={}
f0=P['idle'][0];m=f0[...,3]>0;ys,xs=np.where(m);y0,y1=ys.min(),ys.max();legs=np.where(m[y1-5:y1+1].any(0))[0]
AX=int(round(legs.mean()));AY=int(y1)+1;PRE=float(round(.4737*int(y1-y0+1)/68,4))
for r,(an,fr) in enumerate(rows):
    for i,f in enumerate(fr):
        f=clean(f)
        if an in('melee','draw'):f=beam(f,AX)
        f=apply(f,'B_acid_green')
        out.alpha_composite(Image.fromarray(f),(i*fw,r*fh))
    meta[an]=dict(fw=fw,fh=fh,n=len(fr),ax=AX,ay=AY,x=0,y=r*fh,img='cheez',pre=PRE,art=1,faceR=1,pk=1.4)
meta['death']['fall']=0;meta['ranged']=dict(meta['iai'])
out.save('/home/claude/pod2/crawl_cheez.png',optimize=True)
A=json.load(open('/home/claude/pod2/crawl_atlas.json'));A['units']['cheez']=meta;json.dump(A,open('/home/claude/pod2/crawl_atlas.json','w'))
print({k:v['n'] for k,v in meta.items()},AX,AY,PRE)
