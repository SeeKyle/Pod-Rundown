# 0.12.234 CHEEZ sheet: frames from extract.py + paint.py (CraftPix free samurai, repainted). Faces right.
import pickle,json,numpy as np
from PIL import Image
P=pickle.load(open('/home/claude/cheez_refs/painted.pkl','rb'))
rows=[('idle',P['idle']),('walk',P['walk']),('run',P['run']),('melee',P['atk3'][:3]),('iai',P['atk2']),('draw',P['atk1'][:5]),('sake',P['shield']),('hurt',P['hurt']),('death',P['dead']),('jump',P['jump'])]
fw=fh=96;W=max(len(f) for _,f in rows)*fw;out=Image.new('RGBA',(W,fh*len(rows)));meta={}
f0=P['idle'][0];m=f0[...,3]>0;ys,xs=np.where(m);y0,y1=ys.min(),ys.max();legs=np.where(m[y1-5:y1+1].any(0))[0]
AX=int(round(legs.mean()));AY=int(y1)+1;PRE=float(round(.4737*int(y1-y0+1)/68,4))
for r,(an,fr) in enumerate(rows):
    for i,f in enumerate(fr):out.alpha_composite(Image.fromarray(f),(i*fw,r*fh))
    meta[an]=dict(fw=fw,fh=fh,n=len(fr),ax=AX,ay=AY,x=0,y=r*fh,img='cheez',pre=PRE,art=1,faceR=1,pk=1.4)
meta['death']['fall']=0
out.save('/home/claude/pod2/crawl_cheez.png',optimize=True)
A=json.load(open('/home/claude/pod2/crawl_atlas.json'));A['units']['cheez']=meta;json.dump(A,open('/home/claude/pod2/crawl_atlas.json','w'))
print({k:v['n'] for k,v in meta.items()},AX,AY,PRE)
