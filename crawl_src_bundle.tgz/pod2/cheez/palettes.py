# 0.12.236 Cheez color options (no pink). Maps the sheet's magenta family (+ the kimono highlight) to each option.
import numpy as np
PINK=[(255,60,200),(120,24,96),(38,22,38),(19,11,19)];K=(24,96,130)
OPTS={
 'A_cyber_cyan': dict(p=[(60,235,255),(18,110,140),(20,34,44),(12,18,24)],k=(30,60,96)),
 'B_acid_green': dict(p=[(140,255,70),(40,110,30),(24,36,22),(12,18,12)],k=(40,58,78)),
 'C_amber_tron': dict(p=[(255,176,40),(130,70,10),(40,28,16),(20,14,8)],k=K),
 'D_red_ronin':  dict(p=[(255,56,56),(120,16,20),(40,16,18),(20,8,10)],k=(44,48,62)),
}
def apply(a,name):
    a=a.copy();O=OPTS[name];rgb=a[...,:3]
    for src,dst in list(zip(PINK,O['p']))+[(K,O['k'])]:
        m=(rgb==np.array(src,np.uint8)).all(-1);a[m,:3]=dst
    return a
