# 0.12.234 frames for Cheez from Kyle's previews of CraftPix's free "Free Samurai Pixel Art Sprite Sheets" (preview JPGs at about 2x):
# cut each animation row into frames by column gaps, shrink 2x by majority colour, drop the grey background, snap to a small palette.
import numpy as np,json
from PIL import Image
def frames(path,names):
    a=np.array(Image.open(path).convert('RGB')).astype(int);bg=a[5,1790]
    m=np.abs(a-bg).sum(-1)>46;m[:, :255]=False
    ys=np.where(m.any(1))[0];bands=[];s=p=ys[0]
    for y in ys[1:]:
        if y-p>8:bands.append((s,p));s=y
        p=y
    bands.append((s,p));out={}
    for (y0,y1),nm in zip(bands,names):
        if nm is None:continue
        col=m[y0:y1+1].any(0);xs=np.where(col)[0];segs=[];s=p=xs[0]
        for x in xs[1:]:
            if x-p>14:segs.append((s,p));s=x
            p=x
        segs.append((s,p));fr=[]
        for x0,x1 in segs:
            if x1-x0<20:continue
            fr.append((x0,x1))
        out[nm]=(y0,y1,fr)
    return a,m,out
A,MA,ra=frames('sam_a.jpg',['idle','walk','run','jump','atk1'])
B,MB,rb=frames('sam_b.jpg',['atk2','atk3','shield','hurt','dead'])
for k,v in list(ra.items())+list(rb.items()):print(k,len(v[2]),v[2][:2])
CW=192.4;X0=258
def cell_frames(a,m,y0,y1):
    res=[]
    for i in range(8):
        x0=int(round(X0+i*CW));x1=int(round(x0+CW))
        if x1>a.shape[1]:break
        if m[y0:y1+1,x0:x1].sum()<60:continue
        H=192;top=y1+1-H   # bottom aligned
        sub=a[max(0,top):y1+1,x0:x1];sm=m[max(0,top):y1+1,x0:x1]
        if top<0:pad=-top;sub=np.pad(sub,((pad,0),(0,0),(0,0)));sm=np.pad(sm,((pad,0),(0,0)))
        h,w=sm.shape;h2,w2=h//2,w//2;out=np.zeros((h2,w2,4),'uint8')
        for y in range(h2):
            for x in range(w2):
                blk=sm[2*y:2*y+2,2*x:2*x+2]
                if blk.sum()>=2:
                    c=sub[2*y:2*y+2,2*x:2*x+2][blk];out[y,x,:3]=np.median(c,0);out[y,x,3]=255
        res.append(out)
    return res
F={}
for nm,(y0,y1,_) in ra.items():F[nm]=cell_frames(A,MA,y0,y1)
for nm,(y0,y1,_) in rb.items():F[nm]=cell_frames(B,MB,y0,y1)
# palette snap
allpx=np.concatenate([f[f[...,3]>0][:,:3] for v in F.values() for f in v]).astype('uint8')
pal_img=Image.fromarray(allpx.reshape(-1,1,3)).quantize(28,method=Image.Quantize.MEDIANCUT)
pal=np.array(pal_img.getpalette()[:28*3]).reshape(-1,3)
def snap(f):
    o=f.copy();m=o[...,3]>0;px=o[m][:,:3].astype(int);d=((px[:,None,:]-pal[None])**2).sum(-1);o[m,:3]=pal[d.argmin(1)];return o
F={k:[snap(f) for f in v] for k,v in F.items()}
import pickle;pickle.dump(F,open('frames.pkl','wb'))
print({k:len(v) for k,v in F.items()},F['idle'][0].shape)
pv=Image.new('RGBA',(96*8,96*2),(40,40,48,255))
for i,f in enumerate(F['idle'][:4]+F['atk1'][:4]):pv.alpha_composite(Image.fromarray(f),((i%8)*96,0))
for i,f in enumerate(F['atk2'][:4]+F['run'][:4]):pv.alpha_composite(Image.fromarray(f),((i%8)*96,96))
pv.resize((pv.width*2,pv.height*2),0).save('/tmp/cz_raw.png')
