"""0.12.108 (Kyle) Downtown: a city backdrop in the Blackwater Lake pack's style (few flat colours, rim-lit edges), in blue tones.
Only the street lights are warm. Tall buildings run up past the top of the screen; a few shorter ones show rooftops.
Writes assets/biome4_city/{sky,far,mid,street}.png (art px; the game draws them at 0.75 scale like the lake)."""
import random
from PIL import Image, ImageDraw
OUT='/home/claude/pod2/assets/biome4_city/'
R=random.Random(7)
BG=(0,22,40);SL=(18,34,52);SL2=(24,44,66);MB=(30,56,84);BL=(52,98,142);HL=(112,170,222);HL2=(170,214,245)
WIN0=(12,24,38);WINB=(70,130,186);WINW=(255,200,110)
WARM=(255,214,130);WARMD=(214,150,70)
ASP=(22,32,44);ASP2=(30,44,58);ASP3=(40,56,72);CURB=(66,86,106);CURB2=(88,110,130);LINE=(150,162,166)
BLOOD=(110,20,30);BLOOD2=(80,12,22);BLOOD3=(140,30,38)
H=300
def px(im,x,y,c):
    if 0<=x<im.width and 0<=y<im.height: im.putpixel((x,y),c+(255,) if len(c)==3 else c)
def rect(d,x0,y0,x1,y1,c): d.rectangle([x0,y0,x1,y1],fill=c)

# ---- sky tile (48 x 160): flat night with faint horizontal haze bands, like the lake's back.png
sky=Image.new('RGBA',(48,160),BG+(255,));d=ImageDraw.Draw(sky)
for y in range(0,160):
    if y%9==0 and y>40:
        for x in range(0,48,2): px(sky,x+(y//9)%2,y,(4,28,48))
sky.save(OUT+'sky.png')

# ---- far skyline (272 x 300, tiles): dark silhouettes, most running off the top, sparse cold windows
far=Image.new('RGBA',(272,H),(0,0,0,0));d=ImageDraw.Draw(far)
x=0
while x<272:
    w=R.randint(18,40);top=R.choice([0,0,0,R.randint(20,90),R.randint(90,150)])
    c=SL if R.random()<.6 else SL2
    rect(d,x,top,min(271,x+w),H-1,c)
    if top>0 and R.random()<.5: rect(d,x+w//2,top-R.randint(6,16),x+w//2,top,c)   # antenna
    for wy in range(top+6,H-40,7):
        for wx in range(x+3,x+w-2,5):
            r=R.random()
            if r<.07: rect(d,wx,wy,wx+1,wy+2,WINB)
    x+=w+R.randint(0,3)
far.save(OUT+'far.png')

# ---- mid buildings (544 x 300, tiles): rim-lit from the left (like the lake trees' orange edges), window grids, fire escapes,
#      a couple of shorter roofs with a water tower, storefronts at street level, and the warm street lamps
mid=Image.new('RGBA',(544,H),(0,0,0,0));d=ImageDraw.Draw(mid)
GROUND=H-8
x=4;blds=[]
while x<540:
    w=R.randint(46,82);short=R.random()<.28;top=R.randint(70,150) if short else 0
    if x+w>540:w=540-x
    blds.append((x,w,top));x+=w+R.choice([0,0,6,10])
for (x,w,top) in blds:
    body=R.choice([(20,38,58),(24,42,64),(18,34,54)])
    rect(d,x,top,x+w-1,GROUND,body)
    rect(d,x,top,x,GROUND,BL);rect(d,x+1,top,x+1,GROUND,MB)          # left rim light
    rect(d,x+w-1,top,x+w-1,GROUND,(12,24,38))                          # right edge in shadow
    if top>0:
        rect(d,x-1,top-2,x+w,top,MB);rect(d,x-1,top-2,x+w,top-2,HL)    # parapet catching the moonlight
        if R.random()<.6:                                                # rooftop water tower
            tx=x+R.randint(8,max(9,w-20));rect(d,tx,top-14,tx+9,top-6,SL2);rect(d,tx,top-14,tx,top-6,BL)
            d.polygon([(tx-1,top-14),(tx+5,top-19),(tx+11,top-14)],fill=SL2);px(mid,tx+5,top-19,HL)
            for lx in (tx+1,tx+8):rect(d,lx,top-6,lx,top-2,SL)
    # window grid
    cols=max(2,(w-8)//9);gap=(w-8)//cols
    for wy in range(top+8,GROUND-34,11):
        for c in range(cols):
            wx=x+5+c*gap;r=R.random()
            col=(150,200,240) if r<.03 else WINB if r<.20 else WIN0
            rect(d,wx,wy,wx+4,wy+6,col)
            if col==WIN0: px(mid,wx,wy,(30,52,76))
            else: rect(d,wx,wy+5,wx+4,wy+6,(col[0]//2,col[1]//2,col[2]//2))
            rect(d,wx-1,wy+7,wx+5,wy+7,MB)   # sill
    # fire escape on some
    if R.random()<.55 and w>50:
        fx=x+w-22
        for fy in range(top+20,GROUND-40,22):
            rect(d,fx,fy,fx+16,fy,SL2);rect(d,fx,fy,fx+16,fy,(40,70,100))
            for k in range(0,17,3):px(mid,fx+k,fy-3,(40,70,100));
            rect(d,fx,fy-3,fx+16,fy-3,(34,60,88))
            for k in range(12):px(mid,fx+2+k,fy+1+int(k*1.6),(46,80,112))   # ladder/stairs
    # storefront at street level
    sy=GROUND-26
    rect(d,x+2,sy,x+w-3,GROUND,(14,26,40))
    aw=R.choice([(28,60,92),(22,48,76),(60,30,40)])
    rect(d,x+2,sy-4,x+w-3,sy,aw);
    for k in range(x+2,x+w-3,4):px(mid,k,sy+1,aw)
    rect(d,x+6,sy+6,x+w-16,GROUND-4,(10,20,32));rect(d,x+6,sy+6,x+w-16,sy+6,MB)   # dark display window
    if R.random()<.4:rect(d,x+8,sy+8,x+14,sy+14,(40,80,120))                     # a dim sign glow
    rect(d,x+w-13,sy+4,x+w-6,GROUND,(8,16,26))                                        # door
    if R.random()<.35:   # boarded up
        for k in range(3):rect(d,x+6,sy+8+k*5,x+w-16,sy+9+k*5,(46,40,36))
# street lamps (the only warm light): post, arm, lamp head, soft halo
for lx in range(30,544,136):
    rect(d,lx,GROUND-58,lx+1,GROUND,(10,18,28));rect(d,lx,GROUND-58,lx,GROUND,(46,70,96))
    rect(d,lx,GROUND-58,lx+9,GROUND-57,(10,18,28));rect(d,lx+8,GROUND-57,lx+11,GROUND-55,(30,30,30))
    rect(d,lx+7,GROUND-54,lx+12,GROUND-53,WARM);px(mid,lx+9,GROUND-52,(255,240,200));px(mid,lx+10,GROUND-52,(255,240,200))
    halo=Image.new('RGBA',(60,80),(0,0,0,0))
    for yy in range(80):
        for xx in range(60):
            dx=xx-30;dy=yy-10
            r=(dx*dx+(dy*(.42 if dy>0 else 1.6))**2)**.5
            a=int(max(0,62-r*3.1))
            if a>0: halo.putpixel((xx,yy),(255,186,90,a))
    mid.alpha_composite(halo,(lx+10-30,GROUND-64))
    px(mid,lx+9,GROUND-53,WARMD);px(mid,lx+10,GROUND-53,WARMD)
rect(d,0,GROUND,543,H-1,(12,22,34))
mid.save(OUT+'mid.png')

# ---- street (272 x 48): sidewalk + curb at the top, asphalt, dashed lane line, a manhole, cracks, blood. No bones.
st=Image.new('RGBA',(272,48),ASP+(255,));d=ImageDraw.Draw(st)
rect(d,0,0,271,5,CURB);rect(d,0,0,271,0,CURB2)
for k in range(0,272,17):rect(d,k,0,k,5,(54,72,90))
rect(d,0,6,271,7,(52,70,88));rect(d,0,8,271,8,(14,22,32))
for y in range(9,48):
    for x in range(272):
        if R.random()<.06: px(st,x,y,ASP2)
        elif R.random()<.015: px(st,x,y,ASP3)
for k in range(4,272,34):rect(d,k,27,k+15,28,(118,124,120))      # faded dashed line
for (cx,cy) in [(60,38),(204,16)]:                                # manholes
    d.ellipse([cx-8,cy-3,cx+8,cy+3],fill=(18,26,36));d.ellipse([cx-7,cy-2,cx+7,cy+2],outline=(48,64,80))
    for k in range(-5,6,3):px(st,cx+k,cy,(48,64,80))
for _ in range(7):                                                 # cracks
    x0=R.randint(0,271);y0=R.randint(10,46)
    for k in range(R.randint(6,16)):
        x0+=R.choice([-1,1,1]);y0+=R.choice([-1,0,1]);px(st,x0%272,max(9,min(47,y0)),(12,18,26))
import math
def pool(cx,cy,rx,ry):
    for y in range(cy-ry-1,cy+ry+2):
        for x in range(cx-rx-2,cx+rx+3):
            v=((x-cx)/rx)**2+((y-cy)/ry)**2+R.random()*.35
            if v<1: px(st,x%272,max(9,min(47,y)),BLOOD2 if v<.45 else BLOOD)
    for _ in range(rx//2):   # spatter around it
        a=R.random()*6.28;r=rx*(1.2+R.random()*.8);px(st,int(cx+r*math.cos(a))%272,max(9,min(47,int(cy+r*.4*math.sin(a)))),BLOOD)
for (cx,cy,rx,ry) in [(34,20,7,2),(176,38,9,3),(250,16,4,1)]:pool(cx,cy,rx,ry)
for k in range(18):px(st,(186+k*2)%272,37-(k//6),BLOOD if k%3 else BLOOD2)          # a drag smear from the pool
st.convert('RGB').save(OUT+'street.png')
print('ok')
