"""0.12.108 (Kyle) Downtown: a city backdrop in the Blackwater Lake pack's style (few flat colours, rim-lit edges), in blue tones.
Only the street lights are warm. Tall buildings run up past the top of the screen; a few shorter ones show rooftops.
Writes assets/biome4_city/{sky,far,mid,street}.png (art px; the game draws them at 0.75 scale like the lake)."""
import random,math
from PIL import Image, ImageDraw
OUT='/home/claude/pod2/assets/biome4_city/'
R=random.Random(7)
BG=(0,22,40);SL=(18,34,52);SL2=(24,44,66);MB=(30,56,84);BL=(52,98,142);HL=(112,170,222);HL2=(170,214,245)
WIN0=(12,24,38);WINB=(70,130,186);WINW=(255,200,110)
WARM=(255,214,130);WARMD=(214,150,70)
ASP=(22,32,44);ASP2=(30,44,58);ASP3=(40,56,72);CURB=(66,86,106);CURB2=(88,110,130);LINE=(150,162,166)
BLOOD=(110,20,30);BLOOD2=(80,12,22);BLOOD3=(140,30,38)
H=300
def px(im,x,y,c):
    if 0<=x<im.width and 0<=y<im.height: im.putpixel((x,y),c+(255,) if len(c)==3 else c)
def rect(d,x0,y0,x1,y1,c): d.rectangle([x0,y0,x1,y1],fill=c)

# ---- sky tile (48 x 160): flat night with faint horizontal haze bands, like the lake's back.png
sky=Image.new('RGBA',(48,160),BG+(255,));d=ImageDraw.Draw(sky)
for y in range(0,160):
    if y%9==0 and y>40:
        for x in range(0,48,2): px(sky,x+(y//9)%2,y,(4,28,48))
sky.save(OUT+'sky.png')

# ---- far skyline (544 x 300, tiles): dark silhouettes, most running off the top, some with broken, gap-toothed tops
far=Image.new('RGBA',(544,H),(0,0,0,0));d=ImageDraw.Draw(far)
x=0
while x<544:
    w=R.randint(18,44);top=R.choice([0,0,0,R.randint(20,90),R.randint(90,150)])
    c=SL if R.random()<.6 else SL2
    if x+w>543:w=543-x
    rect(d,x,top,x+w,H-1,c)
    if top>0 and R.random()<.45:                                    # bombed-out crown: jagged bites out of the roof
        for k in range(x,x+w):
            dep=int(abs(math.sin(k*.7+x))*R.randint(0,9)) if R.random()<.7 else 0
            if dep: rect(d,k,top,k,top+dep,(0,0,0,0))
        for k in range(R.randint(1,3)):                              # bent beams poking up
            bx=x+R.randint(2,max(3,w-3));rect(d,bx,top-R.randint(4,12),bx,top+4,c)
    elif top>0 and R.random()<.5: rect(d,x+w//2,top-R.randint(6,16),x+w//2,top,c)   # antenna
    for wy in range(top+6,H-40,7):
        for wx in range(x+3,x+w-2,5):
            if R.random()<.035: rect(d,wx,wy,wx+1,wy+2,WINB)
    x+=w+R.randint(0,3)
for (sx,sw) in [(130,22),(400,30)]:                                    # two thin smoke plumes drifting off burnt-out towers
    for yy in range(0,170):
        cx=sx+int(math.sin(yy*.05)*6)+int(yy*.12);ww=sw*(1-yy/200)
        for xx in range(int(cx-ww/2),int(cx+ww/2)):
            if R.random()<.5: px(far,xx%544,170-yy,(30,46,62,70))
far.save(OUT+'far.png')

# ---- mid buildings (1088 x 300, tiles: two screens before it loops). Realistic, beat-up blocks: stained and cracked facades,
#      broken and boarded windows, soot from old fires, chunks blown out, a collapsed shell and a parking garage.
#      The street lamps are only posts here: the game lights the heads live so they can flicker and spark.
MW=1088
mid=Image.new('RGBA',(MW,H),(0,0,0,0));d=ImageDraw.Draw(mid)
GROUND=H-8
x=4;blds=[]
STYLES=['brick','glass','deco','brown','concrete','hotel','ruin','garage']
order=STYLES[:];R.shuffle(order);o2=STYLES[:];R.shuffle(o2)
if o2[0]==order[-1]:o2=o2[1:]+o2[:1]
order+=o2;si=0
while x<MW-4:
    st=order[si%len(order)];si+=1
    w={'brick':R.randint(48,62),'glass':R.randint(58,78),'deco':R.randint(56,70),'brown':R.randint(40,52),'concrete':R.randint(60,80),'hotel':R.randint(46,58),'ruin':R.randint(50,66),'garage':R.randint(70,88)}[st]
    short={'brick':R.random()<.55,'glass':False,'deco':R.random()<.35,'brown':True,'concrete':R.random()<.3,'hotel':False,'ruin':True,'garage':True}[st]
    top={'ruin':R.randint(70,110),'garage':R.randint(150,175)}.get(st,R.randint(80,150)) if short else 0
    if x+w>MW-4:w=MW-4-x
    if w<24:break
    blds.append((x,w,top,st));x+=w+R.choice([0,0,4,8])
def tint(c,k): return tuple(max(0,min(255,int(v*k))) for v in c[:3])
def get(x,y): return mid.getpixel((x,y)) if 0<=x<MW and 0<=y<H else (0,0,0,0)
def shade(x,y,k):
    c=get(x,y)
    if c[3]: mid.putpixel((x,y),tint(c,k)+(c[3],))
WSTATE=[]
def win(x0,y0,ww,hh,lit,cold=True):
    """a window that is lit, dark, smashed (jagged shards), boarded, or has torn blinds"""
    r=R.random()
    if r<.13:                                             # smashed: dark hole, a few shards still in the frame
        rect(d,x0,y0,x0+ww-1,y0+hh-1,(6,12,20))
        for k in range(R.randint(2,4)):
            sx=x0+R.randint(0,ww-1);L=R.randint(1,max(1,hh//2))
            for j in range(L): px(mid,sx+(j if R.random()<.4 else 0)-(j//2),y0+(0 if R.random()<.5 else hh-1-j) if False else y0+j if k%2 else y0+hh-1-j,(70,100,128))
        return
    if r<.22:                                             # boarded over with plywood, a nail-dot or two
        rect(d,x0,y0,x0+ww-1,y0+hh-1,(52,50,54))
        for j in range(y0+1,y0+hh,3): rect(d,x0,j,x0+ww-1,j,(40,38,44))
        if ww>3: d.line([(x0,y0+hh-1),(x0+ww-1,y0)],fill=(64,60,62))
        return
    c=(150,200,240) if lit>.985 else WINB if lit>.9 else WIN0
    rect(d,x0,y0,x0+ww-1,y0+hh-1,c)
    if c!=WIN0:
        rect(d,x0,y0+hh-1,x0+ww-1,y0+hh-1,tint(c,.6))
        if R.random()<.5:                                 # half-drawn, torn blinds
            for j in range(y0,y0+R.randint(1,hh-1)):
                if j%2==0: rect(d,x0,j,x0+ww-1,j,tint(c,.55))
    else:
        px(mid,x0,y0,(30,52,76))
        if R.random()<.25: px(mid,x0+ww-1,y0+R.randint(0,hh-1),(56,80,104))    # a crack catching the light
def rim(x,top,w,body):
    rect(d,x,top,x,GROUND,BL);rect(d,x+1,top,x+1,GROUND,tint(body,1.35));rect(d,x+w-1,top,x+w-1,GROUND,(10,20,32))

def weather(x,w,top,st):
    """grime: stain streaks under ledges and windows, cracks, soot plumes, blown-out chunks, chipped rooflines"""
    y0=max(top,0)
    for yy in range(y0,GROUND):                            # mottled dirt
        for xx in range(x,x+w):
            r=R.random()
            if r<.07: shade(xx,yy,.86)
            elif r<.085: shade(xx,yy,1.1)
    for xx in range(x,x+w):                                # grime collects toward the street
        for yy in range(GROUND-60,GROUND):
            if R.random()<(yy-(GROUND-60))/60*.35: shade(xx,yy,.82)
    for _ in range(w//5):                                  # rain stains running down from ledges
        sx=R.randint(x+2,x+w-3);sy=R.randint(y0+2,GROUND-50);L=R.randint(12,50)
        for j in range(L):
            k=.78+.22*j/L;shade(sx,sy+j,k)
            if R.random()<.3: shade(sx+1,sy+j,k+.08)
    for _ in range(R.randint(2,4)+w//30):                  # cracks: wandering dark lines with a lit edge
        cx=R.randint(x+3,x+w-4);cy=R.randint(y0,GROUND-40) if R.random()<.6 else y0
        for j in range(R.randint(10,32)):
            cx+=R.choice([-1,0,0,1]);cy+=1
            if not(x<cx<x+w-1):break
            shade(cx,cy,.5)
            if R.random()<.35: shade(cx+1,cy,1.25)
            if R.random()<.08:                             # a branch
                bx,by=cx,cy
                for q in range(R.randint(3,7)): bx+=R.choice([-1,1]);by+=1;shade(bx,by,.6)
    if R.random()<.55:                                     # soot plume from an old fire, licking up out of a window
        sx=R.randint(x+8,x+w-10);sy=R.randint(y0+30,GROUND-50);rect(d,sx-3,sy,sx+3,sy+6,(4,8,12))
        for j in range(0,R.randint(26,48)):
            hw=3+j*.28;cx_=sx+math.sin(j*.18)*2
            for xx in range(int(cx_-hw),int(cx_+hw)+1):
                if x<xx<x+w-1 and R.random()<.85-j/60: shade(xx,sy-j,.45+.5*abs(xx-cx_)/hw*.8+j/120)
    if st in('concrete','deco','hotel','brown') and R.random()<.7:      # a chunk blown out of the facade: exposed brick and a dark ragged rim
        cx=R.randint(x+8,x+w-10);cy=R.randint(y0+20,GROUND-46);rx=R.randint(4,8);ry=R.randint(3,6)
        for yy in range(cy-ry-1,cy+ry+2):
            for xx in range(cx-rx-1,cx+rx+2):
                v=((xx-cx)/rx)**2+((yy-cy)/ry)**2+R.random()*.4
                if v<1: px(mid,xx,yy,(46,34,40) if (yy%3==0 or (xx+(yy//3)*3)%6==0) else (66,48,52))
                elif v<1.35: px(mid,xx,yy,(14,18,26))
    if top>0:                                              # chipped roofline: bites taken out of the parapet, rubble on the ledge
        for _ in range(R.randint(1,4)):
            bx=R.randint(x,x+w-6);bw=R.randint(2,6)
            for k in range(bw):
                for j in range(R.randint(1,4)): px(mid,bx+k,top-5+j,(0,0,0,0)) if get(bx+k,top-5+j)[3] else None
                px(mid,bx+k,top-1,tint(get(bx+k,top+1),.7)+(255,)) if get(bx+k,top+1)[3] else None

SHOPS=[]
for (x,w,top,st) in blds:
    if st=='brick':                                  # brick walk-up: paired windows with arched tops, a sagging fire escape
        body=(34,40,58);rect(d,x,top,x+w-1,GROUND,body)
        for yy in range(top,GROUND,3):
            off=0 if (yy//3)%2 else 3
            for xx in range(x+off,x+w,6): px(mid,xx,yy,(26,30,46))
            rect(d,x,yy,x+w-1,yy,(28,33,50)) if yy%6==0 else None
        rim(x,top,w,body)
        for wy in range(top+8,GROUND-36,12):
            for wx in range(x+5,x+w-8,11):
                for k in (0,5):
                    win(wx+k,wy,4,7,R.random());px(mid,wx+k+1,wy-1,(60,70,92));px(mid,wx+k+2,wy-1,(60,70,92));rect(d,wx+k,wy+7,wx+k+3,wy+7,(52,58,78))
                    if R.random()<.12: rect(d,wx+k,wy+8,wx+k+3,wy+10,(48,56,64));rect(d,wx+k,wy+8,wx+k+3,wy+8,(70,80,92))   # window AC unit
        fx_=x+w-20;broke=R.randint(0,3)
        for i,fy in enumerate(range(top+18,GROUND-40,24)):
            if i==broke:                             # one landing has torn loose and hangs at an angle, ladder dangling
                d.line([(fx_,fy-2),(fx_+14,fy+7)],fill=(56,84,112));d.line([(fx_,fy-6),(fx_+14,fy+3)],fill=(44,66,92))
                for k in range(0,15,3): px(mid,fx_+k,fy-6+int(k*.64),(48,72,98))
                for k in range(14): px(mid,fx_+12,fy+8+k,(50,78,106));px(mid,fx_+15,fy+8+k,(50,78,106)) if k%3 else None
                continue
            rect(d,fx_,fy,fx_+14,fy,(56,84,112));[px(mid,fx_+k,fy-4,(48,72,98)) for k in range(0,15,3)];rect(d,fx_,fy-4,fx_+14,fy-4,(44,66,92))
            for k in range(10): px(mid,fx_+2+k,fy+1+int(k*2),(50,78,106))
            for k in range(R.randint(0,4)): px(mid,fx_+R.randint(0,14),fy+1+R.randint(0,8),(70,56,52))   # rust drips
        if top>0:
            rect(d,x-1,top-3,x+w,top,(44,52,72));rect(d,x-1,top-3,x+w,top-3,HL)
            tx=x+R.randint(6,max(7,w-18))                # water tower, one leg buckled so it lists
            d.polygon([(tx,top-15),(tx+9,top-14),(tx+9,top-5),(tx,top-6)],fill=SL2);rect(d,tx,top-15,tx,top-6,BL)
            d.polygon([(tx-1,top-15),(tx+5,top-20),(tx+11,top-14)],fill=SL2)
            for j in range(top-13,top-6,3): d.line([(tx,j),(tx+9,j+1)],fill=(30,48,68))
            rect(d,tx+1,top-6,tx+1,top-2,SL);d.line([(tx+8,top-5),(tx+10,top-2)],fill=SL)
    elif st=='glass':                                # glass office tower: curtain wall with missing and cracked panes
        body=(16,30,48);rect(d,x,top,x+w-1,GROUND,body)
        for yy in range(top,GROUND):
            for xx in range(x,x+w):
                if (xx-x)%7==0: px(mid,xx,yy,(40,64,90))
                elif yy%9==0: px(mid,xx,yy,(26,44,66))
        band=set(R.sample(range(top//9,(GROUND-40)//9),3))
        for yy in range(top,GROUND-40):
            if yy//9 in band and yy%9 in (2,3,4,5,6):
                for xx in range(x+1,x+w-1):
                    if (xx-x)%7 and ((xx-x)//7)%5!=3 and ((xx-x)//7+yy//9)%4: px(mid,xx,yy,(84,140,196) if yy%9!=6 else (60,104,150))
        for k in range(0,w+120,1):
            for t_ in range(3):
                xx=x+k-60+t_;yy=top+int(k*1.6)
                if x<xx<x+w-1 and top<=yy<GROUND-30 and (xx-x)%7: px(mid,xx,yy,(70,120,170) if t_ else (130,180,225))
        for _ in range(R.randint(2,4)):              # a blown-out cluster of panes: black holes, bent mullions
            cx=x+7*R.randint(1,max(1,w//7-2));cy=R.randint(top+20,GROUND-60);n=R.randint(2,6)
            for q in range(n):
                px0=cx+7*R.randint(-1,1);py0=cy+9*R.randint(-1,1)
                rect(d,px0+1,py0+1,px0+6,py0+8,(4,8,14))
                for j in range(R.randint(1,3)): px(mid,px0+1+R.randint(0,5),py0+1+R.randint(0,7),(60,96,130))
            d.line([(cx,cy-9),(cx+2,cy+10)],fill=(46,70,96))
        for _ in range(R.randint(4,8)):              # spider-web cracks on surviving panes
            px0=x+7*R.randint(0,max(0,w//7-1));py0=9*R.randint(max(1,top//9),(GROUND-50)//9)
            c0=(px0+3,py0+4)
            for ang in range(0,360,72):
                a_=math.radians(ang+R.randint(-20,20))
                for j in range(1,4): px(mid,int(c0[0]+math.cos(a_)*j),int(c0[1]+math.sin(a_)*j*1.3),(120,160,200))
        rim(x,top,w,body)
    elif st=='deco':                                 # art deco: stepped setbacks, vertical piers, a chevron crown with its spire snapped
        body=(30,44,68);rect(d,x,top,x+w-1,GROUND,body)
        steps=[(x,w)] if top==0 else [(x,w),(x+5,w-10),(x+11,w-22)]
        if top>0:
            for i,(sx,sw) in enumerate(steps[1:],1):
                rect(d,sx,top-12*i,sx+sw-1,top,body);rect(d,sx,top-12*i,sx+sw-1,top-12*i,HL);rect(d,sx,top-12*i,sx,top,BL)
            cx=x+w//2;ct=top-12*(len(steps)-1)
            for k in range(6): d.line([(cx-6+k,ct-k),(cx+6-k,ct-k)],fill=(60,96,136))
            d.line([(cx,ct-6),(cx+5,ct-11)],fill=(80,110,140))          # the spire, snapped and bent over
        for px_ in range(x+4,x+w-3,6):
            rect(d,px_,top,px_+1,GROUND-30,(46,66,96));rect(d,px_,top,px_,GROUND-30,(70,100,140))
        for wy in range(top+6,GROUND-34,9):
            for wx in range(x+7,x+w-6,6): win(wx,wy,3,6,R.random())
        for yy in range(top+40,GROUND-34,48): rect(d,x,yy,x+w-1,yy+1,(54,80,112))
        rim(x,top,w,body)
    elif st=='brown':                                # brownstone: cornices, lintels and sills, one cornice sagging off
        body=(38,40,58);rect(d,x,top,x+w-1,GROUND,body)
        for yy in range(top,GROUND):
            for xx in range(x,x+w):
                if (xx*3+yy*7)%23==0: px(mid,xx,yy,(46,48,68))
        rect(d,x-2,top-4,x+w+1,top,(54,58,80));rect(d,x-2,top-4,x+w+1,top-4,HL)
        hang=R.randint(x+4,x+w-12)                   # a run of cornice has broken off and hangs down
        rect(d,hang,top-4,hang+9,top,(0,0,0,0));d.polygon([(hang,top),(hang+9,top+1),(hang+8,top+5),(hang+1,top+3)],fill=(50,54,74));px(mid,hang,top,HL)
        for k in range(x,x+w,4): px(mid,k,top+1,(30,32,48))
        for fy in range(top+6,GROUND-30,16):
            rect(d,x,fy+13,x+w-1,fy+13,(56,60,84))
            for wx in range(x+5,x+w-6,9):
                win(wx,fy,5,10,R.random());rect(d,wx-1,fy-1,wx+5,fy-1,(70,76,100));rect(d,wx-1,fy+10,wx+5,fy+10,(64,70,92))
        rim(x,top,w,body)
        if R.random()<.7:
            for k in range(3): rect(d,x+w-24+k*4,top-6-k,x+w-21+k*4,top-1,(40,44,58))
    elif st=='concrete':                             # concrete block: heavy bands, deep windows, balconies, one balcony slab collapsed
        body=(40,48,62);rect(d,x,top,x+w-1,GROUND,body)
        for fy in range(top+4,GROUND-30,13):
            rect(d,x,fy+10,x+w-1,fy+12,(54,62,78));rect(d,x,fy+10,x+w-1,fy+10,(78,90,108))
            for wx in range(x+4,x+w-8,12):
                rect(d,wx,fy+1,wx+8,fy+8,(14,22,32));win(wx+1,fy+2,7,6,R.random())
                if R.random()<.5:
                    if R.random()<.15:               # collapsed balcony: slab hanging off one side, railing twisted
                        d.line([(wx-1,fy+9),(wx+9,fy+14)],fill=(70,82,100));d.line([(wx+2,fy+7),(wx+9,fy+12)],fill=(58,66,82))
                    else:
                        rect(d,wx-1,fy+9,wx+9,fy+9,(70,82,100))
                        for k in range(wx-1,wx+10,2): px(mid,k,fy+7,(70,82,100)) if R.random()<.85 else None
                for k in range(R.randint(0,3)): px(mid,wx+R.randint(0,8),fy+12+k,(60,50,46))   # rebar rust bleeding down
        rim(x,top,w,body)
        if top>0:
            rect(d,x,top-2,x+w-1,top,(60,70,86))
            for k in range(2): rect(d,x+6+k*14,top-7,x+15+k*14,top-2,(30,36,46));rect(d,x+6+k*14,top-7,x+15+k*14,top-7,(70,80,96))
    elif st=='hotel':                                # old hotel: rows of rooms, a vertical neon sign with the E burnt out
        body=(44,54,72);rect(d,x,top,x+w-1,GROUND,body)
        for wy in range(top+6,GROUND-36,8):
            for wx in range(x+4,x+w-5,7): win(wx,wy,4,5,R.random()*1.06)
        rim(x,top,w,body)
        sx=x+w-7;sy0=120;sy1=GROUND-44
        rect(d,sx-1,sy0-2,sx+5,sy1+2,(14,20,30));rect(d,sx-1,sy0-2,sx+5,sy0-2,(60,80,100))
        glyph={'H':['1.1','111','1.1'],'O':['111','1.1','111'],'T':['111','.1.','.1.'],'E':['111','11.','111'],'L':['1..','1..','111']}
        for i,ch in enumerate('HOTEL'):
            gy0=sy0+2+i*((sy1-sy0)//5);dead=ch=='E'
            for r_,row in enumerate(glyph[ch]):
                for c_,v in enumerate(row):
                    if v=='1':
                        if dead: px(mid,sx+1+c_,gy0+r_*2,(40,60,66));px(mid,sx+1+c_,gy0+r_*2+1,(30,46,52))
                        else: px(mid,sx+1+c_,gy0+r_*2,(120,255,240));px(mid,sx+1+c_,gy0+r_*2+1,(80,210,210))
        halo=Image.new('RGBA',(30,sy1-sy0+20),(0,0,0,0))
        eY=(2+3*((sy1-sy0)//5))+10
        for yy in range(halo.height):
            for xx in range(30):
                a_=int(max(0,40-abs(xx-15)*3.2))
                if abs(yy-eY-2)<6: a_=a_//3                       # darker around the dead letter
                if a_>0: halo.putpixel((xx,yy),(100,240,230,a_))
        mid.alpha_composite(halo,(sx+2-15,sy0-10))
    elif st=='ruin':                                 # collapsed shell: the top storeys gone, floor slabs and rebar sticking out, rubble at the foot
        body=(36,44,60)
        prof=[top+int(abs(math.sin(k*.21+x))*28+R.randint(0,6)+(k/w)*24) for k in range(w)]   # jagged broken top edge
        for k in range(w): rect(d,x+k,prof[k],x+k,GROUND,body)
        for k in range(w):
            px(mid,x+k,prof[k],(70,84,104));px(mid,x+k,prof[k]+1,(20,26,36))
        for fy in range(top+16,GROUND-30,15):        # gutted floors: the windows are just holes onto a dark interior
            rect(d,x,fy+11,x+w-1,fy+12,(48,56,72))
            for wx in range(x+4,x+w-9,11):
                if fy>prof[min(w-1,wx-x+4)]+3: rect(d,wx,fy+1,wx+7,fy+8,(6,10,16));px(mid,wx+R.randint(0,7),fy+8,(30,36,46))
        for k in range(R.randint(2,4)):              # slabs and rebar jutting from the break
            sx=x+R.randint(2,w-10);sy=prof[sx-x]+R.randint(4,14)
            rect(d,sx,sy,sx+R.randint(6,12),sy+1,(60,68,84))
            for q in range(R.randint(2,4)):
                bx=sx+R.randint(0,8);L=R.randint(4,10)
                for j in range(L): px(mid,bx+(j//3 if q%2 else -(j//4)),sy-j,(70,58,54))
        rim(x,min(prof),w,body)
        for k in range(w):                           # the rim only where the wall still stands
            for j in range(min(prof),prof[k]): px(mid,x+k,j,(0,0,0,0)) if k<2 or k>w-2 else None
        for k in range(-6,w+6):                      # rubble pile at the base
            hh=int(max(0,14-abs(k-w*.55)*.35)+R.randint(0,3))
            for j in range(hh): px(mid,x+k,GROUND-j,R.choice([(40,46,58),(52,58,72),(30,34,44),(60,50,48)]))
    elif st=='garage':                               # parking garage: open decks, a few abandoned cars, one deck pancaked
        body=(44,50,62)
        rect(d,x,top,x+w-1,GROUND,(10,14,22))
        decks=list(range(top,GROUND-20,16));sag=R.randint(1,max(1,len(decks)-2))
        for i,fy in enumerate(decks):
            if i==sag:                               # this deck has dropped at one end onto the one below
                d.polygon([(x,fy),(x+w-1,fy+11),(x+w-1,fy+14),(x,fy+3)],fill=body);d.line([(x,fy),(x+w-1,fy+11)],fill=(80,90,106))
            else:
                rect(d,x,fy,x+w-1,fy+3,body);rect(d,x,fy,x+w-1,fy,(80,90,106))
                for k in range(x,x+w,2):
                    if R.random()<.1: px(mid,k,fy+3,(0,0,0,0))
            if i!=sag and fy+16<GROUND-20:
                for cx in range(x+R.randint(4,14),x+w-14,R.randint(18,26)):
                    if R.random()<.45:               # a car silhouette parked on the deck
                        rect(d,cx,fy+10,cx+11,fy+13,(24,32,44));rect(d,cx+2,fy+7,cx+8,fy+10,(24,32,44));rect(d,cx+3,fy+8,cx+7,fy+9,(40,60,84))
                        px(mid,cx+2,fy+14,(8,10,14));px(mid,cx+9,fy+14,(8,10,14))
        for cx in range(x,x+w,16): rect(d,cx,top,cx+2,GROUND,body);rect(d,cx,top,cx,GROUND,(70,80,96))   # columns
        rim(x,top,w,body)
        rect(d,x+w-22,top-10,x+w-6,top-1,(36,42,54));rect(d,x+w-22,top-10,x+w-6,top-10,(70,80,96))      # stair tower
        for k in range(4): rect(d,x+w-20+k*4,top-8,x+w-19+k*4,top-4,(52,60,74))
    weather(x,w,top if st!='ruin' else top+8,st)
    # street level: each building gets its own (mostly dead) shop front
    sy=GROUND-26
    kind={'brick':'diner','glass':'pharmacy' if R.random()<.6 else 'lobby','deco':'bank','brown':'stoop','concrete':'pawn','hotel':'hotelfront','ruin':'rubble','garage':'garagefront'}[st]
    if kind=='diner':
        rect(d,x+2,sy,x+w-3,GROUND,(14,24,38))
        for k in range(x+2,x+w-3):                   # torn awning: strips hanging, a gap ripped out
            if R.random()<.8: rect(d,k,sy-4,k,sy-1+(R.randint(0,3) if R.random()<.3 else 0),(30,64,96) if (k//3)%2 else (24,50,76))
        rect(d,x+5,sy+6,x+w-15,GROUND-5,(22,40,58));rect(d,x+5,sy+6,x+w-15,sy+6,(60,100,140))
        for k in range(x+7,x+w-17,5): rect(d,k,GROUND-11,k+2,GROUND-9,(40,62,86))
        for k in range(3): d.line([(x+8+k*7,sy+7),(x+5+k*7,sy+14)],fill=(90,130,170))      # cracked glass
    elif kind=='pharmacy':                           # 0.12.119: a pharmacy: dark glass front, green cross sign, pill-bottle shelves
        rect(d,x+2,sy-6,x+w-3,GROUND,(12,24,32));rect(d,x+2,sy-7,x+w-3,sy-5,(30,44,52))
        cx_=x+w//2;rect(d,cx_-1,sy-15,cx_+1,sy-9,(60,170,110));rect(d,cx_-3,sy-13,cx_+3,sy-11,(60,170,110));rect(d,cx_,sy-8,cx_,sy-7,(30,40,50))
        for k in range(x+5,x+w-5):
            for yy in (sy+2,sy+9):
                if R.random()<.55: px(mid,k,yy,R.choice([(170,150,70),(190,190,190),(90,140,170)]))
        rect(d,cx_-4,sy+4,cx_+4,GROUND,(6,12,18))
    elif kind=='lobby':
        rect(d,x+2,sy-6,x+w-3,GROUND,(12,26,40))
        for i,k in enumerate(range(x+4,x+w-4,7)):
            if i%3==1: rect(d,k,sy-4,k+5,GROUND-1,(6,12,20));[px(mid,k+R.randint(0,5),GROUND-R.randint(1,3),(60,96,130)) for _ in range(4)]   # shattered panel, glass on the floor
            else: rect(d,k,sy-4,k+5,GROUND-1,(30,60,90));rect(d,k,sy-4,k,GROUND-1,(80,130,180))
        rect(d,x+w//2-4,sy+4,x+w//2+4,GROUND,(8,16,26))
    elif kind=='bank':
        rect(d,x+2,sy-4,x+w-3,GROUND,(26,36,54))
        for i,k in enumerate(range(x+6,x+w-5,8)):
            if i==1: d.line([(k,GROUND),(k+5,sy+4)],fill=(60,84,116));continue    # a column knocked over
            rect(d,k,sy-2,k+2,GROUND,(60,84,116));px(mid,k,sy-2,HL)
        rect(d,x+2,sy-6,x+w-3,sy-4,(54,76,106))
    elif kind=='stoop':
        rect(d,x+w//2-5,sy+6,x+w//2+5,GROUND-8,(10,18,28))
        for k in range(4): rect(d,x+w//2-7-k,GROUND-8+k*2,x+w//2+7+k,GROUND-7+k*2,(56,60,80))
        for k in range(x+3,x+w-3,3): px(mid,k,GROUND-16,(70,80,100)) if R.random()<.8 else None
    elif kind=='pawn':
        rect(d,x+2,sy,x+w-3,GROUND,(18,24,34))
        pry=R.randint(x+8,x+w-16)
        for yy in range(sy+2,GROUND,2): rect(d,x+4,yy,x+w-5,yy,(46,54,66))
        d.polygon([(pry,GROUND),(pry+10,GROUND),(pry+8,GROUND-9),(pry+2,GROUND-8)],fill=(6,10,16))      # grate pried up at the bottom
        rect(d,x+6,sy-5,x+26,sy-1,(20,30,44))
        for k in range(4): rect(d,x+8+k*5,sy-4,x+10+k*5,sy-2,(90,170,220) if k!=2 else (30,50,64))
    elif kind=='hotelfront':
        rect(d,x+2,sy-2,x+w-3,GROUND,(16,24,36));rect(d,x+1,sy-6,x+w-2,sy-3,(36,50,72));rect(d,x+1,sy-6,x+w-2,sy-6,HL)
        rect(d,x+w//2-5,sy+2,x+w//2+5,GROUND,(10,20,30))
        for k in (x+w//2-8,x+w//2+7): rect(d,k,sy,k+1,GROUND,(60,80,104))
    elif kind=='garagefront':
        rect(d,x+6,sy+2,x+30,GROUND,(6,10,16));d.line([(x+6,sy+6),(x+30,sy+4)],fill=(150,60,60))   # entrance, the boom gate snapped
        d.line([(x+30,sy+4),(x+38,sy+10)],fill=(150,60,60))
    if kind in('diner','pawn','bank','pharmacy'): SHOPS.append([x+w/2,{'diner':'grocery','pawn':'pawn','bank':'bank','pharmacy':'pharmacy'}[kind],w])
    if R.random()<.35 and kind in('diner','pawn','stoop','lobby'):
        for k in range(3): rect(d,x+6,sy+8+k*5,x+w-16,sy+9+k*5,(46,40,36))
    if kind!='rubble':                               # graffiti tags and peeling posters at street level
        for _ in range(R.randint(1,3)):
            gx=R.randint(x+3,x+w-16);gy=R.randint(GROUND-22,GROUND-8);col=R.choice([(84,58,104),(48,104,104),(118,124,134),(104,60,64)])
            for j in range(R.randint(8,14)):
                px(mid,gx+j,gy+int(math.sin(j*1.3+gx)*2.2),col)
                if R.random()<.4: px(mid,gx+j,gy+int(math.sin(j*1.3+gx)*2.2)+1,col)
        if R.random()<.6:
            ppx=R.randint(x+3,x+w-10);ppy=R.randint(GROUND-24,GROUND-14);rect(d,ppx,ppy,ppx+5,ppy+7,(86,92,104));rect(d,ppx+1,ppy+2,ppx+4,ppy+3,(50,56,70))
            px(mid,ppx+5,ppy+7,(0,0,0,0));px(mid,ppx+4,ppy+8,(70,76,88))

# ---- easter eggs
FONT={'A':'010101111101101','B':'110101110101110','C':'011100100100011','D':'110101101101110','E':'111100110100111','F':'111100110100100',
 'H':'101101111101101','I':'111010010010111','K':'101101110101101','L':'100100100100111','N':'110101101101101','O':'010101101101010',
 'P':'110101110100100','R':'110101110101101','S':'011100010001110','T':'111010010010010','U':'101101101101111','W':'101101101111101',
 'Y':'101101010010010','Z':'111001010100111','X':'101101010101101','?':'110001010000010',' ':'000000000000000','!':'010010010000010'}
def text(x0,y0,s_,col,wob=0):
    for i,ch in enumerate(s_):
        g=FONT[ch];dy=int(math.sin(i*1.7)*wob)
        for k,v in enumerate(g):
            if v=='1': px(mid,x0+i*4+k%3,y0+dy+k//3,col)
def first(*sts):
    for b in blds:
        if b[3] in sts: return b
eggs=[]
b=first('garage','concrete','ruin')                      # a spray-painted shout-out
if b: text(b[0]+6,GROUND-33 if b[3]=='garage' else GROUND-16,'POD RUNDOWN',(150,80,170),wob=1);eggs.append('POD RUNDOWN tag')
b=first('concrete') or first('brick')                      # Shoshi's repair shop: the sign still lit, a phone glowing in the window
if b:
    x,w=b[0],b[1];sx=x+4;sy=GROUND-34
    rect(d,sx-1,sy-1,sx+38,sy+5,(12,18,26));text(sx+1,sy,'SHOSHI PC',(120,230,255))
    rect(d,sx+14,GROUND-20,sx+18,GROUND-13,(20,26,34));rect(d,sx+15,GROUND-19,sx+17,GROUND-15,(140,230,255));px(mid,sx+16,GROUND-14,(70,90,110))
    eggs.append('SHOSHI PC')
b=first('brown')                                          # a jack-o'-lantern on the stoop. Something's coming at stage 10 ...
if b:
    x,w=b[0],b[1];cx=x+w//2+9;cy=GROUND-6
    d.ellipse([cx-3,cy-3,cx+3,cy+2],fill=(150,70,20));px(mid,cx,cy-4,(40,70,30));px(mid,cx-1,cy-1,(255,210,90));px(mid,cx+1,cy-1,(255,210,90));rect(d,cx-1,cy+1,cx+1,cy+1,(255,180,60))
    eggs.append('pumpkin')
for b in blds[::-1]:                                      # KYLE WUZ HERE, low on a brick wall
    if b[3] in('brick','brown','hotel') and b[1]>=54: text(b[0]+3,GROUND-9,'KYLE WUZ HERE',(110,120,132));eggs.append('KYLE WUZ HERE');break

# street lamps: posts and dark heads only (the game lights them). Uneven spacing and a mix of kinds so the long loop never feels
# repeated: ok (steady hum), flicker (bursts of stutter), sputter (mostly out, comes on for a while), dying (dim, brownouts),
# dead (never lights) and broken (head dangling by its wire, shorting out in sparks)
LAMPS=[];kinds=['ok','flicker','dead','ok','dying','broken','ok','sputter','flicker']
lx=26;i=0
while lx<MW-16:
    k=kinds[i%len(kinds)];seed=round(R.random(),3)
    rect(d,lx,GROUND-58,lx+1,GROUND,(10,18,28));rect(d,lx,GROUND-58,lx,GROUND,(46,70,96))
    for j in range(GROUND-20,GROUND,4): px(mid,lx+1,j,(60,50,46))
    if k=='broken':
        rect(d,lx,GROUND-58,lx+5,GROUND-57,(10,18,28));d.line([(lx+5,GROUND-57),(lx+8,GROUND-50)],fill=(10,18,28))
        rect(d,lx+7,GROUND-49,lx+10,GROUND-46,(30,30,30));rect(d,lx+7,GROUND-46,lx+10,GROUND-45,(44,40,36))
        LAMPS.append([lx+8.5,GROUND-45,k,seed])
    else:
        rect(d,lx,GROUND-58,lx+9,GROUND-57,(10,18,28));rect(d,lx+8,GROUND-57,lx+11,GROUND-55,(30,30,30))
        rect(d,lx+7,GROUND-54,lx+12,GROUND-53,(52,48,40) if k!='dead' else (34,34,36))
        if k=='dead': px(mid,lx+9,GROUND-53,(16,16,18))
        LAMPS.append([lx+9.5,GROUND-53,k,seed])
    lx+=R.randint(96,150);i+=1
print('shops',[(round(a),k) for a,k,w in SHOPS],'eggs',eggs,'lamps',len(LAMPS),[l[2] for l in LAMPS])
rect(d,0,GROUND,MW-1,H-1,(12,22,34))
mid.save(OUT+'mid.png')
import json;json.dump(dict(lamps=LAMPS,ground=GROUND,shops=SHOPS,front=GROUND-26),open(OUT+'lamps.json','w'))

# ---- street (272 x 48): sidewalk + curb at the top, asphalt, dashed lane line, a manhole, cracks, blood. No bones.
st=Image.new('RGBA',(272,48),ASP+(255,));d=ImageDraw.Draw(st)
rect(d,0,0,271,5,CURB);rect(d,0,0,271,0,CURB2)
for k in range(0,272,17):rect(d,k,0,k,5,(54,72,90))
rect(d,0,6,271,7,(52,70,88));rect(d,0,8,271,8,(14,22,32))
for y in range(9,48):
    for x in range(272):
        if R.random()<.06: px(st,x,y,ASP2)
        elif R.random()<.015: px(st,x,y,ASP3)
for k in range(4,272,34):rect(d,k,27,k+15,28,(118,124,120))      # faded dashed line
for (cx,cy) in [(60,38),(204,16)]:                                # manholes
    d.ellipse([cx-8,cy-3,cx+8,cy+3],fill=(18,26,36));d.ellipse([cx-7,cy-2,cx+7,cy+2],outline=(48,64,80))
    for k in range(-5,6,3):px(st,cx+k,cy,(48,64,80))
for _ in range(7):                                                 # cracks
    x0=R.randint(0,271);y0=R.randint(10,46)
    for k in range(R.randint(6,16)):
        x0+=R.choice([-1,1,1]);y0+=R.choice([-1,0,1]);px(st,x0%272,max(9,min(47,y0)),(12,18,26))
import math
def pool(cx,cy,rx,ry):
    for y in range(cy-ry-1,cy+ry+2):
        for x in range(cx-rx-2,cx+rx+3):
            v=((x-cx)/rx)**2+((y-cy)/ry)**2+R.random()*.35
            if v<1: px(st,x%272,max(9,min(47,y)),BLOOD2 if v<.45 else BLOOD)
    for _ in range(rx//2):   # spatter around it
        a=R.random()*6.28;r=rx*(1.2+R.random()*.8);px(st,int(cx+r*math.cos(a))%272,max(9,min(47,int(cy+r*.4*math.sin(a)))),BLOOD)
for (cx,cy,rx,ry) in [(34,20,7,2),(176,38,9,3),(250,16,4,1)]:pool(cx,cy,rx,ry)
for k in range(18):px(st,(186+k*2)%272,37-(k//6),BLOOD if k%3 else BLOOD2)          # a drag smear from the pool
st.convert('RGB').save(OUT+'street.png')
print('ok')
