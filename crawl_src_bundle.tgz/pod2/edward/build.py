"""0.12.207 (Kyle) EDWARD (Eddie): built from CraftPix 'Free Soldier Sprite Sheets Pixel Art' (Soldier_2), which Kyle downloaded
(license https://craftpix.net/file-licenses/), repainted into Eddie: the helmet becomes a short black Jewish fro, the balaclava comes
off (his face, a dark beard and glasses), the field jacket becomes a black hoodie, the trousers jeans, the belt a leather tool belt,
the boots tan work boots, and the rifle a yellow-and-black nail gun. Faces right like the Soldier.
His idle is his own: he stands, then fiddles with the nail gun (the pack's Recharge frames), pushes his glasses up, and stands again."""
import json,numpy as np
from PIL import Image
S='/tmp/cpx/sol/Soldier_2/'
def frames(f):
    im=Image.open(S+f+'.png').convert('RGBA');return [np.array(im.crop((i*128,0,(i+1)*128,128))) for i in range(im.width//128)]
H=lambda h:tuple(int(h[i:i+2],16) for i in (0,2,4))
EYES={H('f9a31b'),H('fa6a0a')}
HOOD={H('322b28'):(38,38,44),H('4c3d2e'):(62,62,72),H('271f1b'):(28,28,33),H('586335'):(52,52,60)}
JEANS={H('322b28'):(52,66,98),H('4c3d2e'):(78,96,134),H('271f1b'):(40,50,76),H('171819'):(30,36,56)}
BELT={H('61683a'):(122,84,46),H('181c19'):(78,52,30),H('586335'):(122,84,46)}
BOOT={H('2d1b1e'):(138,98,58),H('0e0c0c'):(78,54,32),H('3b1725'):(110,76,44)}
GUN={H('333941'):(226,52,46),H('242234'):(186,30,30),H('6d758d'):(240,96,84),H('171516'):(24,24,26),H('5b3138'):(36,36,40),H('3b1725'):(24,24,26),H('464762'):(222,58,50)}   # 0.12.207 (Kyle): a red-and-black framing nailer
SKIN=(214,166,136);SKIND=(176,126,100);BEARD=(44,30,24);BEARDL=(66,46,36);FRO=(22,18,18);FROL=(48,40,38);GLASS=(70,70,78);LENS=(170,200,220);TINT=(150,104,82);TINTD=(112,74,58)
def paint(a,eyes_ok=True):
    a=a.copy();op=a[...,3]>0
    rgb=[tuple(int(v) for v in a[y,x,:3]) for y,x in zip(*np.where(op))]
    ys,xs=np.where(op)
    if not len(ys):return a
    top=ys.min()
    core=np.zeros(op.shape,bool)
    for y,x in zip(ys,xs):
        if tuple(a[y,x,:3]) in (H('333941'),H('6d758d'),H('464762')):core[max(0,y-2):y+3,max(0,x-3):x+4]=True
    by=[y for y,x in zip(ys,xs) if tuple(a[y,x,:3]) in (H('61683a'),H('181c19'))]
    belt=int(np.median(by)) if by else top+40
    # 0.12.224: find the head from the torso, not the topmost pixel (an arm raised over the head, as in the toolbox throw, fooled it before)
    tor=[x for y,x in zip(ys,xs) if belt-14<=y<=belt-4];cx=np.median(tor) if tor else np.median(xs)
    ey=[(y,x) for y,x in zip(ys,xs) if tuple(a[y,x,:3]) in EYES and belt-30<y<belt-6 and abs(x-cx)<12]
    if ey:
        ex0=np.mean([p[1] for p in ey]);ey0=min(p[0] for p in ey);hy=[y for y,x in zip(ys,xs) if abs(x-ex0)<6 and y<ey0];top=min(hy) if hy else top
    out=a.copy()
    for y,x in zip(ys,xs):
        c=tuple(int(v) for v in a[y,x,:3])
        if c in GUN and (core[y,x] or c in (H('333941'),H('6d758d'),H('464762'))) and not (c==H('3b1725') and y>belt+10):out[y,x,:3]=GUN[c];continue
        if c==H('242234'):out[y,x,:3]=(30,30,36);continue
        if c==(0,0,0) and core[y,x] and y<belt-1:out[y,x,:3]=(70,12,14);continue
        if y>belt+14 and c in BOOT:out[y,x,:3]=BOOT[c];continue
        if abs(y-belt)<=1 and c in BELT:out[y,x,:3]=BELT[c];continue
        if y>belt+1 and c in JEANS:out[y,x,:3]=JEANS[c];continue
        if c in HOOD:out[y,x,:3]=HOOD[c]
    if ey:
        eyv=int(np.mean([p[0] for p in ey]));exm=int(np.mean([p[1] for p in ey]));exs=[p[1] for p in ey]
        # head region: everything above the eye row, plus the face rows, within 9 px of the eyes
        hx0,hx1=min(exs)-9,max(exs)+5
        for y in range(top,eyv+6):
            for x in range(max(0,hx0),min(128,hx1+1)):
                if not op[y,x]:continue
                c=tuple(int(v) for v in a[y,x,:3])
                if y<eyv-1:out[y,x,:3]=FROL if ((x*5+y*3)%7==0) else FRO          # fro over the old helmet
                elif y in (eyv-1,eyv,eyv+1) and min(exs)-2<=x<=max(exs)+1:pass   # glasses drawn below
                elif y<=eyv+1 and x>=min(exs)-1:out[y,x,:3]=SKIN
                elif y>=eyv+3 and y<=eyv+5 and x>=min(exs)-3:out[y,x,:3]=BEARDL if (x+y)%3==0 else BEARD           # beard on the lower face
                elif y>=eyv+2:out[y,x,:3]=(30,30,36)   # hoodie collar
                else:out[y,x,:3]=SKIND
        # 0.12.207 (Kyle: make it read as glasses) big readable frames: two 3x3 dark rims with bright 2-row lenses, a bridge, and an arm back to the ear
        x0=min(exs)-2;fx=max(exs)+1;cx=(x0+fx)//2
        for x in range(x0,fx+2):   # forehead + cheeks in skin, then the frames on top
            for y in (eyv-2,eyv-1,eyv,eyv+1):
                if 0<=x<128 and out[y,x,3] and x>=x0:out[y,x,:3]=SKIN
        rims=[(x0,cx-1),(cx+1,fx+1)]
        for (a0,a1) in rims:
            for x in range(a0,a1+1):
                if out[eyv-1,x,3]:out[eyv-1,x,:3]=GLASS   # thin metal frames (top rim + sides), like his sunglasses
                for y in (eyv,eyv+1):
                    if out[y,x,3]:out[y,x,:3]=GLASS if x in (a0,a1) else ((236,226,210) if (y==eyv and x==a0+1) else TINT if y==eyv else TINTD)
        if out[eyv,cx,3]:out[eyv,cx,:3]=GLASS   # bridge
        for x in range(x0-4,x0):
            if 0<=x<128 and out[eyv,x,3]:out[eyv,x,:3]=GLASS   # the arm, back to the ear
        # 0.12.207 (Kyle: the fro looked flat at the hairline) a curly, uneven hairline dipping onto the forehead, hair down the back and sides
        for x in range(x0-1,fx+1):
            if out[eyv-2,x,3] and (x*7)%5 in (0,1,3):out[eyv-2,x,:3]=FRO if (x%2) else FROL
        for y in (eyv-1,eyv+1,eyv+2):
            for x in range(x0-5,x0-1):
                if 0<=x<128 and out[y,x,3]:out[y,x,:3]=FRO if (x+y)%3 else FROL
        for x in range(x0-5,x0-1):
            if 0<=x<128 and out[eyv,x,3] and tuple(out[eyv,x,:3])!=GLASS:out[eyv,x,:3]=FRO
        # puff the fro out a pixel (rounder, taller), and a little curl texture on the edge
        hy=[y for y in range(top,eyv-1)];
        if hy:
            m=out[...,3]>0;add=[]
            for y in range(top-2,eyv-1):
                for x in range(max(0,hx0-1),min(127,hx1+2)):
                    if 0<=y<128 and not m[y,x] and (m[min(127,y+1),x] or (0<x and m[y,x-1]) or (x<127 and m[y,x+1])):
                        if y<eyv-2 and (y>=top or (x//2)%2==0):add.append((y,x))
            for y,x in add:out[y,x]=(*FRO,255)
    return out
def glint(a):   # glasses glint for the glasses-push frames
    b=a.copy();ys,xs=np.where(np.all(b[...,:3]==TINT,axis=-1)&(b[...,3]>0))
    for y,x in zip(ys,xs):b[y,x,:3]=(255,255,255)
    return b
REDS=None
def nailer(a):
    """0.12.208 (Kyle) make the rifle read as a framing nailer: drop the carry handle into the body (no gap), and hang a long nail magazine
    off the front, angled back. Only on frames where the gun is roughly level (shooting, walking with it up)."""
    global REDS
    if REDS is None:REDS={tuple(v) for v in GUN.values() if sum(v)>150}|{(70,12,14)}
    b=a.copy();m=np.zeros(b.shape[:2],bool)
    for y,x in zip(*np.where(b[...,3]>0)):
        if tuple(int(v) for v in b[y,x,:3]) in REDS:m[y,x]=True
    ys,xs=np.where(m)
    if len(xs)<10:return b
    band=(ys<=ys.min()+8);ys,xs=ys[band],xs[band];m2=np.zeros_like(m);m2[ys,xs]=True;m=m2   # the gun itself: the top band of red
    w,h=xs.max()-xs.min()+1,ys.max()-ys.min()+1
    if w<2*h:return b
    cols=range(xs.min(),xs.max()+1);tops={x:ys[xs==x].min() for x in cols if (xs==x).any()};bots={x:ys[xs==x].max() for x in cols if (xs==x).any()}
    body=int(np.percentile(list(tops.values()),70))
    col=np.array(sorted({tuple(int(v) for v in b[y,x,:3]) for y,x in zip(ys,xs)},key=sum)[-1])   # brightest red
    mid=(186,30,30)
    for x,t in tops.items():
        if t<body-1:   # handle: everything above the body line goes, then the column is filled solid down to the body
            for y in range(t,body-1):
                if m[y,x]:b[y,x]=0
            for y in range(body-1,bots[x]+1):
                if b[y,x,3]==0 or not m[y,x]:
                    if y==body-1:b[y,x]=(*col,255)
                    elif b[y,x,3]==0 or m[y-1,x]:b[y,x]=(*mid,255)
            if b[body-2,x,3]==0:b[body-2,x]=(20,14,14,255)   # outline the new top
    # 0.12.209 (Kyle) short nose: cut the black barrel off past the red body, and put a flat contact plate (the bit you press down) on the front
    rx=xs.max();y0b,y1b=max(0,ys.min()-1),min(127,ys.max()+2)
    for y in range(y0b,y1b+1):
        for x in range(rx+1,128):
            if b[y,x,3] and int(b[y,x,:3].sum())<160:b[y,x]=0
    for y in range(body-2,body+5):
        if 0<=y<128:
            b[y,rx+1]=(20,20,22,255);b[y,rx+2]=(150,150,160,255) if body-1<=y<=body+3 else (20,20,22,255);b[y,rx+3]=(20,20,22,255)
    # long nail magazine, hanging off the front at an angle back toward him
    fx=xs.max()-3;by=bots.get(fx,ys.max())+1
    for i in range(9):
        X,Y=fx-i//2-1,by+i
        if 0<=Y<128 and 0<=X<126:
            b[Y,X]=(34,34,38,255);b[Y,X+1]=(84,84,92,255);b[Y,X+2]=(20,20,22,255)
    return b
src={k:frames(f) for k,f in [('idle','Idle'),('walk','Walk'),('run','Run'),('ranged','Shot_1'),('melee','Attack'),('reload','Recharge'),('throw','Grenade'),('hurt','Hurt'),('death','Dead'),('shot2','Shot_2')]}
def buttstrike(a,impact):
    """0.12.212 (Kyle) the smack: on the thrust frames he flips the nailer round and leads with the blunt back end, with a little impact burst"""
    b=a.copy();REDS2={tuple(v) for v in GUN.values() if sum(v)>150}|{(70,12,14)}
    m=np.zeros(b.shape[:2],bool)
    for y,x in zip(*np.where(b[...,3]>0)):
        if tuple(int(v) for v in b[y,x,:3]) in REDS2:m[y,x]=True
    ys,xs=np.where(m)
    if len(xs)<6:return b
    y0,y1,x0,x1=ys.min(),ys.max(),xs.min(),xs.max()
    # include the dark outline pixels that hug the red body
    box=b[y0-1:y1+2,x0-1:x1+2].copy();mm=np.zeros(box.shape[:2],bool)
    for y in range(box.shape[0]):
        for x in range(box.shape[1]):
            Y,X=y+y0-1,x+x0-1
            if m[Y,X] or (b[Y,X,3] and b[Y,X,:3].sum()<90 and m[max(0,Y-1):Y+2,max(0,X-1):X+2].any() and X>x0+1):mm[y,x]=True
    for y,x in zip(*np.where(mm)):b[y+y0-1,x+x0-1]=0
    fl=box[:,::-1];fm=mm[:,::-1]
    for y,x in zip(*np.where(fm)):b[y+y0-1,x+x0-1]=fl[y,x]
    # redraw it bigger and clearer: a chunky red body with the grip toward the front, nail magazine trailing back, black butt-plate leading
    for y,x in zip(*np.where(fm)):b[y+y0-1,x+x0-1]=0
    hy=(y0+y1)//2;bx0,bx1=x0-1,x0+11
    for y in range(hy-2,hy+2):
        for x in range(bx0,bx1+1):b[y,x]=(20,14,14,255) if y in (hy-2,hy+1) or x in (bx0,bx1) else ((226,52,46,255) if y==hy-1 else (186,30,30,255))
    for i in range(4):b[hy+2+i,bx1-4]=(20,14,14,255);b[hy+2+i,bx1-3]=(36,36,40,255);b[hy+2+i,bx1-2]=(20,14,14,255)   # grip
    for i in range(5):X=bx0+2-i//2;b[hy+2+i,X]=(34,34,38,255);b[hy+2+i,X+1]=(84,84,92,255)   # magazine
    x1=bx1;y0,y1=hy-2,hy+1
    # a blunt butt-plate on the leading end
    for y in range(y0,y1+1):
        b[y,x1+1]=(20,20,22,255);b[y,x1+2]=(70,70,78,255)
    for y in range(max(0,y0-3),min(128,y1+4)):
        for x in range(x1+3,128):b[y,x]=0   # leftover barrel bits
    if impact:
        cx,cy=x1+4,(y0+y1)//2
        # 0.12.213 (Kyle: it looked like it was firing) a physical whack: swing streaks trailing above and below, and a grey dust puff / crack at the contact point, no flash
        for (sx,sy,L) in [(x0-2,y0-3,6),(x0-4,y1+3,5)]:
            for i in range(L):
                X,Y=sx+i,sy
                if 0<=X<128 and 0<=Y<128 and b[Y,X,3]==0:b[Y,X]=(220,224,232,200)
        for dx,dy in [(1,-2),(2,-3),(1,2),(2,3),(3,-1),(3,1),(2,0)]:
            if 0<=cx+dx-2<128 and 0<=cy+dy<128:b[cy+dy,cx+dx-2]=(176,170,160,255) if abs(dy)>1 else (210,204,194,255)
    return b
P={k:[nailer(paint(f)) if k in ('ranged','shot2','reload') else paint(f) for f in v] for k,v in src.items()}
P['melee']=[f if i<2 else buttstrike(f,i==2) for i,f in enumerate(P['melee'])]
# his own idle: stand (5) -> tinker with the nail gun (reload frames) -> stand, glasses glint
P['idle']=P['idle'][:5]+P['reload']+[glint(P['idle'][5]),glint(P['idle'][6])]+P['idle'][5:]
rows=[(k,P[k]) for k in ['idle','walk','run','ranged','melee','reload','throw','hurt','death','shot2']]
fw=fh=128;W=max(len(f) for _,f in rows)*fw;out=Image.new('RGBA',(W,fh*len(rows)),(0,0,0,0));meta={}
def bbox(a):m=a[...,3]>0;ys,xs=np.where(m);return xs.min(),ys.min(),xs.max(),ys.max()
x0,y0,x1,y1=bbox(P['idle'][0]);m=P['idle'][0][...,3]>0;legs=np.where(m[y1-6:y1+1].any(0))[0];AX=int(round(legs.mean()));AY=int(y1)+1;PRE=float(round(.4737*int(y1-y0+1)/68,4))
for r,(an,fr) in enumerate(rows):
    for i,f in enumerate(fr):out.alpha_composite(Image.fromarray(f),(i*fw,r*fh))
    meta[an]=dict(fw=fw,fh=fh,n=len(fr),ax=AX,ay=AY,x=0,y=r*fh,img='edward',pre=PRE,art=1,faceR=1,pk=1.5)
meta['death']['fall']=0
out.save('/home/claude/pod2/crawl_edward.png',optimize=True)
A=json.load(open('/home/claude/pod2/crawl_atlas.json'));A['units']['edward']=meta;json.dump(A,open('/home/claude/pod2/crawl_atlas.json','w'))
pv=Image.new('RGBA',(128*8,128*3),(90,110,100,255))
for i,f in enumerate(P['idle'][:8]):pv.alpha_composite(Image.fromarray(f),(i*128,0))
for i,f in enumerate(P['ranged']+P['melee']):pv.alpha_composite(Image.fromarray(f),(i*128,128))
for i,f in enumerate(P['run']):pv.alpha_composite(Image.fromarray(f),(i*128,256))
pv.crop((0,40,1024,384)).resize((2048,688),0).save('/tmp/edward.png')
print({k:v['n'] for k,v in meta.items()},AX,AY,PRE)
