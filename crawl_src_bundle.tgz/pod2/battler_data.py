"""Crypt Crawl (auto-battler) data: one hero per deck (partners = duo), stats from deck ratings,
spells and items drawn from that deck's own cards. Writes battler_data.json (embedded by build_site)."""
import json, importlib, re, sys
sys.path.insert(0, '/home/claude/pod2/decks'); sys.path.insert(0, '/home/claude/pod2')
CT = json.load(open('/home/claude/pod2/card_text.json'))
D = json.load(open('/home/claude/pod2/data.json'))
KEY = {'The Grim Throne': 'grim', 'A Vile Smashing': 'vile', 'Felothar': 'felothar', 'Truly Fantastic': 'thing',
       'Kykar, Zada & Feather': 'kykar', 'Tame Depala': 'depala', 'Armed Robbery': 'kotis', 'Double Dragons': 'dragons',
       "Life Swappin' Bounty Poppin'": 'mathas', 'Turtle Power': 'turtle', 'House on Haunted Hill': 'marina',
       'Korvold Eats Everything': 'korvold', 'Thranduil': 'thranduil', 'The Last of Us': 'joel',
       'Primary Directive': 'robots', 'Blood Suckers': 'blood', 'Mechanized Mayhem': 'mech', 'Ominous Weather': 'weather'}
# Original heroes, built from each deck's theme and colors (not likenesses of the commanders).
HERO = {
 'grim':     dict(name='The Bone Monarch', cls='melee', duo=False, blurb='A crowned grave-king who hauls a greatsword out of the tomb.'),
 'vile':     dict(name='Hex & Smash', cls='caster', duo=True, blurb='A hooded owl hexer and a goblin brute with a spiked maul.'),
 'felothar': dict(name='The Bulwark', cls='tank', duo=False, blurb='A walking stone rampart with a tower shield.'),
 'thing':    dict(name='Geode Golem', cls='caster', duo=False, blurb='A cracked crystal brute that flings spell shards.'),
 'kykar':    dict(name='Gale Magus', cls='caster', duo=False, blurb='A storm-feathered wizard trailed by spirit wisps.'),
 'depala':   dict(name='Goggles Ironbeard', cls='melee', duo=False, blurb='A dwarf pilot with a rocket hammer and too much confidence.'),
 'kotis':    dict(name='Fang Thief', cls='melee', duo=False, blurb='A masked serpent rogue with twin stolen daggers.'),
 'dragons':  dict(name='Twinscale', cls='ranged', duo=False, blurb='A two-headed wyrmling; one head breathes fire, one breathes frost.'),
 'mathas':   dict(name='Bounty Fiend', cls='ranged', duo=False, blurb='A horned bounty hunter with a soul crossbow.'),
 'turtle':   dict(name='Shell Brothers', cls='melee', duo=True, blurb='Two tortoise knights: a shield-bearer and a spear-hand.'),
 'marina':   dict(name='Lantern Witch', cls='caster', duo=False, blurb='A witch whose lantern keeps a captive ghost.'),
 'korvold':  dict(name='Gorge King', cls='melee', duo=False, blurb='A winged glutton-drake that eats what it kills.'),
 'thranduil':dict(name='Leafwarden', cls='ranged', duo=False, blurb='An elf ranger-lord with a silverwood bow.'),
 'joel':     dict(name='The Spore Runners', cls='ranged', duo=True, blurb='A hooded scout with a bow and a bearded brawler with a pipe.'),
 'robots':   dict(name='Aegis Prime-X', cls='tank', duo=False, blurb='A battle robot with an arm cannon and a reactor heart.'),
 'blood':    dict(name='Nightwing Cleric', cls='caster', duo=False, blurb='A bat-winged priestess who heals on every bite.'),
 'mech':     dict(name='Gearbrain', cls='ranged', duo=False, blurb='A goblin tinkerer piloting a spider-legged walker.'),
 'weather':  dict(name='Frostfang Yeti', cls='melee', duo=False, blurb='A shaggy yeti shaman who calls blizzards.'),
}
# effect archetypes the engine knows
RULES = [  # (archetype, regex on oracle text) first match wins
 ('freeze', r"\btap (target|all|each|up to)|doesn.t untap|stun counter|freeze|snow"),
 ('counter', r"counter target"),
 ('smite', r"(destroy|exile) target (creature|permanent|nonland)|fights? (target|another|up to)"),
 ('nova', r"(damage to each (creature|opponent|player)|destroy all|exile all|each creature gets -|deals? \w+ damage divided)"),
 ('drain', r"loses? \w+ life|lose life|each opponent loses|drain"),
 ('bolt', r"deals? (\w+|X) damage"),
 ('summon', r"create .*token"),
 ('regen', r"gain \w+ life|lifelink|you gain life"),
 ('aegis', r"indestructible|hexproof|protection from|ward"),
 ('pump', r"\+1/\+1 counter|gets? \+\w+/\+\w+|double strike"),
 ('devour', r"sacrifice (a|another|two|X)"),
 ('haste', r"add \{|search your library for (a|up to \w+) (basic )?land|treasure"),
 ('insight', r"draw|scry|surveil|look at the top"),
]
ITEM_RULES = [('blade', r"gets \+[1-9]|double strike|first strike|deathtouch"), ('armor', r"indestructible|hexproof|toughness|shield|protection"),
              ('relic', r"untap|add (\{|one|two|three|\w+ mana)|cost.*less|copy"), ('blade', r"equip"), ('charm', r".")]
ARCH_INFO = {  # label, max-rank suffix titles
 'bolt': ('Bolt', ['Starfall', 'Hellfire Lance', 'the Pyre Eternal']),
 'nova': ('Nova', ['Cataclysm', 'the Last Sunrise', 'Worldbreaker']),
 'smite': ('Smite', ['Executioner', 'Final Verdict', 'the Godslayer']),
 'drain': ('Drain', ['Soul Harvest', 'the Bleeding Moon', 'Crimson Tithe']),
 'summon': ('Summon', ['Legion Eternal', 'the Endless Horde', 'Army of the Damned']),
 'regen': ('Regen', ['Undying Grace', 'the Phoenix Psalm', 'Everbloom']),
 'aegis': ('Aegis', ['Bastion Unbroken', 'the Last Wall', 'Adamant Dawn']),
 'pump': ('Pump', ['Titan Rising', 'the Warlord Ascendant', 'Giantblood']),
 'devour': ('Devour', ['the Gluttonous Abyss', 'Bone Feast', 'Maw of Ages']),
 'haste': ('Haste', ['Overdrive', 'the Thousand Hands', 'Quickening Storm']),
 'insight': ('Insight', ['the Open Eye', 'Omniscient', 'Library of Ash']),
 'freeze': ('Freeze', ['Absolute Zero', 'the Long Winter', 'Glacial Tomb']),
 'counter': ('Counter', ['Null Mirror', 'the Silent Ward', 'Spellbreaker']),
 'blade': ('Weapon', ['Kingsbane', 'the Red Edge', 'Doomforged']),
 'armor': ('Armor', ['Aegis of Ages', 'the Unbreakable', 'Ironsoul']),
 'relic': ('Relic', ['Clockwork Heart', 'the Ever-Turning', 'Infinity Engine']),
 'charm': ('Charm', ['Lucky Bones', "Fate's Favorite", 'the Gilded Skull']),
}
# ---- ability names: themed on the deck, not card/creature names (the card still shows as "inspired by")
THEME = {  # element word, noun, minions
 'grim': ('Grave', 'the Throne', 'Behemoths'), 'vile': ('Hex', 'Ruin', 'Imps'), 'felothar': ('Stone', 'the Wall', 'Wardens'),
 'thing': ('Arcane', 'the Rift', 'Elementals'), 'kykar': ('Storm', 'the Gale', 'Spirits'), 'depala': ('Forge', 'the Anvil', 'Shieldbrothers'),
 'kotis': ('Venom', 'the Fang', 'Serpents'), 'dragons': ('Dragon', 'Scales', 'Whelps'), 'mathas': ('Infernal', 'the Bounty', 'Imps'),
 'turtle': ('Shell', 'the Brotherhood', 'Hatchlings'), 'marina': ('Spectral', 'the Manor', 'Phantoms'), 'korvold': ('Glutton', 'the Feast', 'Fae'),
 'thranduil': ('Sylvan', 'the Grove', 'Wardens'), 'joel': ('Spore', 'the Bloom', 'Sporelings'), 'robots': ('Plasma', 'the Core', 'Drones'),
 'blood': ('Blood', 'the Night', 'Bats'), 'mech': ('Gear', 'the Machine', 'Automatons'), 'weather': ('Frost', 'the Blizzard', 'Snow Wraiths'),
}
TPL = {
 'bolt': ['{E} Bolt', '{E} Lance', '{E} Missile'], 'nova': ['{E} Nova', '{E} Burst', 'Shockwave of {N}'],
 'smite': ['{E} Smite', 'Judgment of {N}', '{E} Strike'], 'drain': ['{E} Siphon', 'Drain Life', 'Leech of {N}'],
 'summon': ['Call {M}', 'Summon {M}', 'Rally the {M}'], 'regen': ['{E} Mending', 'Rejuvenate', 'Blessing of {N}'],
 'aegis': ['{E} Ward', 'Aegis of {N}', '{E} Barrier'], 'freeze': ['Frost Nova', 'Glacial Grip', 'Deep Freeze'],
 'counter': ['Spellbreak', '{E} Rebuke', 'Null Ward'], 'pump': ['Battle Cry', '{E} Fury', 'War Chant'],
 'haste': ['Quicken', 'Adrenaline', '{E} Haste'], 'insight': ['Foresight', '{E} Insight', 'Scholar\'s Eye'],
 'devour': ['Feast', '{E} Hunger', 'Gorge'],
}
import zlib
def ability_name(key, arch, card, used):
    E, N, Mn = THEME[key]; opts = TPL[arch]; h = zlib.crc32((key + card).encode())
    for i in range(len(opts)):
        nm = opts[(h + i) % len(opts)].format(E=E, N=N, M=Mn)
        if nm not in used: used.add(nm); return nm
    nm = opts[h % len(opts)].format(E=E, N=N, M=Mn) + ' II'; used.add(nm); return nm
def oracle(name):
    t = CT.get(name) or CT.get(name.split(' // ')[0]) or ''
    lines = t.split('\n'); return lines[0], (lines[1] if len(lines) > 1 else ''), '\n'.join(lines[2:])
pts = {}
for c in D['cards']: pts[(c['deck'], c['card'])] = pts.get((c['deck'], c['card']), 0) + c['points']
KEEP = set()   # 0.12.3 (Kyle): the deck-built heroes are retired; Flannel_Man is the only character for now   # 0.12.1 (Kyle): only The Spore Runners and Bounty Fiend stay playable while the game is rebuilt
out = {'heroes': [], 'arch': {k: dict(label=v[0], titles=v[1]) for k, v in ARCH_INFO.items()}}
for dk in D['decks']:
    if KEY.get(dk['deck']) not in KEEP: continue
    key = KEY[dk['deck']]; mod = importlib.import_module(key)
    cmdrs = set(mod.META['cmdr'])
    spells, items = [], []
    for name in mod.TAGS:
        if name in cmdrs: continue
        head, typ, txt = oracle(name)
        if not typ or 'Land' in typ and 'Creature' not in typ: continue
        low = txt.lower().replace(name.lower(), 'this')
        s = pts.get((dk['deck'], name), 0) + (1.5 if 'Legendary' in typ else 0) + min(2, len(txt) / 300)
        if 'Artifact' in typ and 'Creature' not in typ or ('Aura' in typ and 'enchanted creature' in low):
            arch = next(a for a, r in ITEM_RULES if re.search(r, low))
            items.append(dict(card=name, arch=arch, score=round(s, 2)))
        else:
            arch = next((a for a, r in RULES if re.search(r, low)), None)
            if arch: spells.append(dict(card=name, arch=arch, score=round(s, 2)))
    # keep variety: best card per archetype first, then fill
    def pick(lst, n):
        lst.sort(key=lambda x: -x['score']); seen, res = set(), []
        for x in lst:
            if x['arch'] not in seen: res.append(x); seen.add(x['arch'])
        for x in lst:
            if len(res) >= n: break
            if x not in res: res.append(x)
        return res[:n]
    sp = pick(spells, 8); it = pick(items, 5)
    START = {'thing': 'nova'}   # Geode Golem opens with a melee slam shockwave
    if key in START:
        j = next((i for i, x in enumerate(sp) if x['arch'] == START[key]), None)
        if j is not None: sp.insert(0, sp.pop(j))
    r = {k: dk[k] for k in ['mana', 'cards', 'consistency', 'threats', 'clock', 'reach', 'answers', 'staying', 'control']}
    # weapons: every equipment/blade item gets a weapon type from its name; decks with few weapons get one more (about +15% weapons overall)
    def wtype(card, txt=''):
        n = (card + ' ' + txt).lower()
        for kw, t in (('bow', 'bow'), ('crossbow', 'crossbow'), ('gun', 'cannon'), ('cannon', 'cannon'), ('blaster', 'cannon'), ('spear', 'spear'), ('lance', 'spear'), ('trident', 'spear'),
                      ('halberd', 'halberd'), ('axe', 'axe'), ('cleaver', 'axe'), ('chopper', 'axe'), ('hammer', 'hammer'), ('mace', 'hammer'), ('maul', 'maul'), ('club', 'maul'),
                      ('dagger', 'dagger'), ('knife', 'dagger'), ('spike', 'dagger'), ('fang', 'dagger'), ('rapier', 'rapier'), ('whip', 'rapier'), ('greatsword', 'greatsword'),
                      ('blade', 'sword'), ('sword', 'sword'), ('staff', 'staff'), ('rod', 'staff'), ('wand', 'wand'), ('scepter', 'wand'), ('lantern', 'lantern'), ('orb', 'wand'), ('claw', 'claws')):
            if kw in n: return t
        pool = {'ranged': ['bow', 'crossbow', 'cannon'], 'caster': ['staff', 'wand', 'lantern', 'staff']}.get(HERO[key]['cls'], ['sword', 'axe', 'hammer', 'spear', 'greatsword', 'halberd', 'dagger', 'maul', 'rapier'])
        return pool[zlib.crc32(card.encode()) % len(pool)]   # no weapon word in the name: something this hero would wield
    nblade = sum(1 for x in it if x['arch'] == 'blade')
    if nblade < 2:
        cand = [x for x in it if x['arch'] in ('charm', 'relic')]
        if cand: cand[-1]['arch'] = 'blade'
    for x in it:
        if x['arch'] == 'blade': x['wtype'] = wtype(x['card'], oracle(x['card'])[2][:120])
    used = set()
    h = dict(key=key, deck=dk['deck'], icon=dk['icon'], owner=dk['owner'], cmdr=dk['cmdr'], **HERO[key], stats=r,
             spells=[dict(card=x['card'], arch=x['arch'], name=('Seismic Slam' if (key == 'thing' and i == 0) else ability_name(key, x['arch'], x['card'], used))) for i, x in enumerate(sp)], items=[dict(card=x['card'], arch=x['arch'], **({'wtype': x['wtype']} if x.get('wtype') else {})) for x in it])
    out['heroes'].append(h)
out['heroes'] = [h for h in out['heroes'] if h['key'] in KEEP]
# 0.12.3: real characters (not built from a deck). Stats live in crawl_src.js CHAR; the deck they draw on is the Inspiration pick.
out['heroes'].insert(0, dict(key='flannel', char=1, deck='', icon='🌲', owner='Kyle', cmdr='', name='Flannel_Man', cls='duo', duo=False,
    blurb='A bearded drifter in green flannel with a bolt-action rifle and a crowbar.', stats={}, spells=[], items=[]))
out['heroes'].insert(1, dict(key='chibi', char=1, deck='', icon='⚔️', owner='Kyle', cmdr='', name='Chibi_Warrior', cls='melee', duo=False,
    blurb='A small, fearless swordsman in a long brown coat.', stats={}, spells=[], items=[]))
out['heroes'].insert(2, dict(key='archer', char=1, deck='', icon='🏹', owner='Kyle', cmdr='', name='Yumi_Archer', cls='ranged', duo=False,
    blurb='A red-armored longbow archer.', stats={}, spells=[], items=[]))
out['heroes'].insert(3, dict(key='druid', char=1, deck='', icon='🌿', owner='Kyle', cmdr='', name='Druid', cls='caster', duo=False,
    blurb='A sea-green druid with a gnarled staff.', stats={}, spells=[], items=[]))
out['heroes'].insert(4, dict(key='lumberjack', char=1, deck='', icon='🪓', owner='Kyle', cmdr='', name='Lumber_Jack', cls='melee', duo=False,
    blurb='A red-bearded lumberjack with an axe and a hunting bow.', stats={}, spells=[], items=[]))
out['heroes'].insert(5, dict(key='robot', char=1, deck='', icon='🤖', owner='Kyle', cmdr='', name='Warhound', cls='melee', duo=False,
    blurb='A hunched olive war-walker with brass trim: a flamethrower up close, a Targeted Lazer at range and a jetpack on its back.', stats={}, spells=[], items=[]))
out['heroes'].insert(6, dict(key='cultist', char=1, deck='', icon='🕯️', owner='Kyle', cmdr='', name='Void_Cultist', cls='caster', duo=False,
    blurb='A hooded void cultist with a bone mask and a ritual dagger.', stats={}, spells=[], items=[]))
# 0.12.66 (Kyle): JP goes first in the roster
out['heroes'].insert(0, dict(key='jp', char=1, deck='', icon='🧡', owner='Kyle', cmdr='', name='JP', cls='duo', duo=False,
    blurb='A bearded guy in a big orange hoodie with a Kar98, a sword and a homemade wooden shield. Probably high.', stats={}, spells=[], items=[]))
# 0.12.110 (Kyle): Shoshi, Kyle's cousin and tech guy
out['heroes'].insert(1, dict(key='shoshi', char=1, deck='', icon='📱', owner='Kyle', cmdr='', name='Shoshi', cls='ranged', duo=False,
    blurb='Kyle\'s cousin and go-to tech guy: purple hoodie, glasses, a headset and an Automatic_Pistol with a 20-round mag. Keeps everybody running.', stats={}, spells=[], items=[]))
# 0.12.75 (Kyle): the Engineer
out['heroes'].insert(2, dict(key='eng', char=1, deck='', icon='🔧', owner='Kyle', cmdr='', name='Engineer', cls='duo', duo=False,
    blurb='A hard-hatted engineer in a red shirt and overalls with a big wrench and a sawn-off. Builds towers, barriers, tesla coils and turrets.', stats={}, spells=[], items=[]))
# 0.12.175 (Kyle): the Soldier (CraftPix 'Free Soldier Sprite Sheets Pixel Art', Soldier_1)
out['heroes'].insert(3, dict(key='soldier', char=1, deck='', icon='🪖', owner='Kyle', cmdr='', name='Soldier', cls='ranged', duo=False,
    blurb='A helmeted soldier in a balaclava and plate carrier with an assault rifle and a bag of frag grenades.', stats={}, spells=[], items=[]))
# 0.12.178 (Kyle): Chibi_Archer and Chibi_Sorcerer (CraftPix 'Free Fantasy Chibi Male Sprites Pixel Art': Archer, Wizard)
out['heroes'].append(dict(key='carcher', char=1, deck='', icon='🎯', owner='Kyle', cmdr='', name='Chibi_Archer', cls='ranged', duo=False,
    blurb='A little red-hooded archer with white hair and a short bow. Shoots from far away and hops back out of reach.', stats={}, spells=[], items=[]))
out['heroes'].append(dict(key='csorc', char=1, deck='', icon='⚡', owner='Kyle', cmdr='', name='Chibi_Sorcerer', cls='caster', duo=False,
    blurb='A small dark-haired sorcerer in a dark cloak who throws yellow lightning.', stats={}, spells=[], items=[]))
# 0.12.180 (Kyle): the Crimson_Knight (CraftPix 'Free Knight Character Sprites Pixel Art', Knight_3)
out['heroes'].append(dict(key='knight', char=1, deck='', icon='🛡️', owner='Kyle', cmdr='', name='Crimson_Knight', cls='melee', duo=False,
    blurb='A knight in crimson plate with a sword and a kite shield.', stats={}, spells=[], items=[]))
# 0.12.207 (Kyle): Edward, for Eddie (CraftPix 'Free Soldier Sprite Sheets Pixel Art', Soldier_2, repainted)
out['heroes'].insert(2, dict(key='edward', char=1, deck='', icon='🧰', owner='Eddie', cmdr='', name='Edward', cls='ranged', duo=False,
    blurb='A bearded guy with a short black fro and glasses, in a black hoodie, jeans and a tool belt, with a yellow nail gun and a heavy red toolbox.', stats={}, spells=[], items=[]))
json.dump(out, open('/home/claude/pod2/battler_data.json', 'w'), ensure_ascii=False)
if __name__ == '__main__':
    for h in out['heroes']:
        print(h['owner'], h['name'], '|', ', '.join(f"{x['name']}[{x['arch']}]" for x in h['spells']))
        print('   items:', ', '.join(f"{x['card']}[{x['arch']}]" for x in h['items']))
