import re
CT = __import__('json').load(open('/home/claude/pod2/card_text.json'))
import json, random, math, sys
sys.path.insert(0, '/home/claude/pod2')
from score import run, STATS, STAT_NAME, BASICS

KEYMAP = {'mana': 'mana', 'cards': 'cards', 'consistency': 'consistency', 'threats': 'threats',
          'finish': 'clock', 'reach': 'reach', 'interaction': 'answers', 'survival': 'staying', 'politics': 'control'}
ICON = {'mana': '⚡', 'cards': '🃏', 'consistency': '🎯', 'threats': '🗡️', 'finish': '🏁', 'reach': '🥷',
        'interaction': '✨', 'survival': '🔰', 'politics': '🗣️'}

def mana_t7(r, n=1000, seed=3):
    """Goldfish turn-7 mana: land each turn, ramp cast cheapest first."""
    rng = random.Random(seed)
    deck = []
    for c in r['cards']:
        if c['is_land']:
            bounce = any('bounce land' in e['label'] for e in c['entries'])
            deck.append(('L', 2 if bounce else 1, 0, False))
        else:
            rs = [e for e in c['entries'] if e.get('kind') == 'ramp']
            if rs:
                e = max(rs, key=lambda e: e['amount'])
                deck.append(('R', e['amount'], c['mv'], e.get('rkind') == 'E' or e.get('landramp')))
            else:
                deck.append(('X', 0, 0, False))
    deck = [d for d in deck][:99]
    tot = 0
    for _ in range(n):
        rng.shuffle(deck)
        hand = deck[:7]; lib = deck[7:]; lands = 0; perm = 0.0
        for t in range(1, 8):
            if t > 1: hand.append(lib.pop(0))
            ls = [h for h in hand if h[0] == 'L']
            if ls: hand.remove(ls[0]); lands += ls[0][1]
            avail = lands + perm
            if t < 7:
                for h in sorted([h for h in hand if h[0] == 'R'], key=lambda h: h[2]):
                    if h[2] <= avail:
                        avail -= h[2]; hand.remove(h)
                        if h[3]: perm += min(h[1], 3)
        tot += lands + perm
    return round(tot / n, 1)

def stat_list(c):
    return [STAT_NAME[s] for s in STATS if c['stats'][s] > 0.04]

def roles(c):
    out = []
    for e in sorted(c['entries'], key=lambda e: -e['pts']):
        lab = e['label'].split(' (MV')[0]
        if lab not in out and e['pts'] > 0.04: out.append(lab)
    return out[:3]

def build(texts):
    res, divs = run()
    order = sorted(res, key=lambda r: -r['total'])
    decks, cards, stats, takes = [], [], [], []
    for rank, r in enumerate(order, 1):
        M = r['meta']
        row = dict(deck=M['deck'], icon=M['icon'], owner=M['owner'], archetype=M['archetype'])
        for s in STATS: row[KEYMAP[s]] = r['rating'][s]
        row.update(engine=r['engine'], offense=r['offense'], defense=r['defense'], total=r['total'], was=None,
                   salt=r['salt'], cmdr=' + '.join(M['cmdr']))
        decks.append(row)
        for s in STATS:
            contrib = sorted([c for c in r['cards'] if c['stats'][s] > 0], key=lambda c: -c['stats'][s])
            seen = set()
            k = 0
            for c in contrib:
                if c['name'] in seen: continue
                seen.add(c['name']); k += 1
                labs = [e['label'] for e in c['entries'] if e['stat'] == s]
                cards.append(dict(deck=M['deck'], stat=KEYMAP[s], rank=k, card=c['name'], points=round(c['stats'][s], 2),
                                  commander=c['commander'] or c['secret'], note=c['note'] + ' · ' + '; '.join(labs)))
            tot = r['final'][s]
            top3 = sum(c['stats'][s] for c in contrib[:3])
            allv = sorted([x['final'][s] for x in res], reverse=True)
            notes = ' · '.join(t for a, t in r['adj'][s]) or 'no deck-level changes'
            stats.append(dict(deck=M['deck'], stat=KEYMAP[s], name=STAT_NAME[s], rating=r['rating'][s], was=None,
                              points=round(tot, 2), per_point=divs[s], for_ten=round(divs[s] * 10, 2),
                              contributors=len(seen), top3_share=round(top3 / tot, 3) if tot else 0,
                              pod_rank=allv.index(tot) + 1, pod_avg=round(sum(allv) / len(allv) / divs[s], 1),
                              adjust=round(sum(a for a, _ in r['adj'][s]), 2), notes=notes))
        # takeaway computed parts
        nonland = [c for c in r['cards'] if not c['is_land']]
        pool = [c for c in nonland if not (c['commander'])]
        best = sorted(pool, key=lambda c: -c['total'])[:5]
        weak = sorted(pool, key=lambda c: c['total'])[:5]
        tx = texts.get(r['key'], {})
        # Needs Repair: blend of our score, EDHREC inclusion, and my read
        INC = json.load(open('/home/claude/pod2/inclusion.json'))
        from judge import J, FIX2
        allinc = sorted(INC.values())
        rpool = [c for c in nonland if not c['commander'] and not c['secret']]
        sv = sorted(c['total'] for c in rpool)
        for c in rpool:
            c['_sp'] = sum(1 for a in sv if a < c['total']) / len(sv)
            c['_ip'] = sum(1 for a in allinc if a < INC[c['name']]) / len(allinc)
            j = J.get(r['key'], {}).get(c['name'])
            c['_j'] = j[0] if j else 4
            c['_jp'] = (c['_j'] - 1) / 4
            c['_bl'] = (c['_sp'] + c['_ip'] + c['_jp']) / 3
        rank_of = {c['name']: i + 1 for i, c in enumerate(sorted(rpool, key=lambda c: -c['total']))}
        READ = {1: 'weak', 2: 'below average', 3: 'okay', 4: 'good', 5: 'great'}
        repair = []
        _prot = r['meta'].get('protect_type')   # e.g. Bats in Blood Suckers: never listed as weak links
        _ok = lambda c: not (_prot and re.search(r'\b' + _prot + r's?\b', CT.get(c['name'], ''), re.I))
        for c in sorted([c for c in rpool if c['_j'] < 4 and _ok(c)], key=lambda c: c['_bl'])[:5]:   # 0.10.16: only cards worth replacing
            repair.append(dict(card=c['name'], value=round(c['total'], 2), our_rank=rank_of[c['name']], of=len(rpool),
                               inclusion=INC[c['name']], read=READ[c['_j']], blend=round(c['_bl'], 2),
                               why=J[r['key']][c['name']][1],
                               idea=(J[r['key']][c['name']][2] if len(J[r['key']][c['name']]) > 2 else ''),
                               budget=FIX2.get(r['key'], {}).get(c['name'], ('', ''))[0], anycost=FIX2.get(r['key'], {}).get(c['name'], ('', ''))[1]))
        from repair_data import REPAIR as _RP
        if r['key'] in _RP:   # 0.12.0: hand-picked weak links with 4 swaps each
            byname = {c['name']: c for c in rpool}
            repair = []
            for x in _RP[r['key']]:
                c = byname.get(x['card'])
                if not c: continue
                repair.append(dict(card=x['card'], value=round(c['total'], 2), our_rank=rank_of[x['card']], of=len(rpool),
                                   inclusion=INC.get(x['card']), read=READ[x['read']], blend=round(c['_bl'], 2), why=x['why'],
                                   idea='', swaps=x['swaps'], budget='', anycost=''))
        whys = tx.get('weak_why', {})
        def why(c):
            if c['name'] in whys: return whys[c['name']]
            st = stat_list(c)
            return 'only helps ' + ' and '.join(st) if st else 'no stat sees what it does'
        icards = sum(1 for c in r['cards'] if c['stats']['interaction'] > 0)
        routes = []
        if r['rating']['threats'] >= 4 or r['rating']['reach'] >= 6: routes.append('Combat')
        if sum(1 for c in r['cards'] if any(e.get('kind') == 'drain' or e.get('ftype') == 'Burst' for e in c['entries'])) >= 3: routes.append('Drain/Burn')
        if any(e.get('ftype') == 'Alt Win' for c in r['cards'] for e in c['entries']): routes.append('Alt Win')
        if any(e.get('ftype') == 'Combo Piece' for c in r['cards'] for e in c['entries']): routes.append('Combo')
        if any('Quietus' in c['name'] or 'Colossification' in c['name'] for c in r['cards']): routes.append('Commander Damage')
        lvl = 'LOW' if icards < 8 else 'OK' if icards <= 12 else 'GOOD'
        sorted_stats = sorted(STATS, key=lambda s: -r['rating'][s])
        t = dict(deck=M['deck'], rank=rank, mana_t7=mana_t7(r), lands=r['lands'], land_drop=r['land_drop'],
                 land_drop8=r['land_drop8'], avg_mv=r['avg_mv'], interaction_cards=icards, routes=routes,
                 removal_level=lvl,
                 shines=[STAT_NAME[s] for s in sorted_stats[:3]], lacks=[STAT_NAME[s] for s in sorted_stats[-3:]],
                 best=[dict(card=c['name'], value=round(c['total'], 2), stats=stat_list(c), note=c['note'], roles=roles(c)) for c in best],
                 weakest=[dict(card=c['name'], value=round(c['total'], 2), stats=stat_list(c), note=c['note'], roles=roles(c), why=why(c)) for c in weak],
                 commander=[dict(card=c['name'], value=round(c['total'], 2), stats=stat_list(c), note=c['note'], roles=roles(c))
                            for c in r['cards'] if c['commander'] or c['secret']],
                 attack={}, repair=repair)
        for k in ['tagline', 'feel', 'phases', 'wins', 'fears', 'tips', 'land', 'removal_text', 'hh', 'dream', 'xcards', 'fixes']:
            t[k] = tx.get(k, '' if k in ('tagline', 'feel', 'land', 'removal_text') else [])
        takes.append(t)
    return dict(decks=decks, cards=cards, stats=stats, takeaways=takes), res, divs

if __name__ == '__main__':
    data, res, divs = build({})
    for t, d in zip(data['takeaways'], data['decks']):
        print('=====', d['deck'], d['total'], 'rank', t['rank'], '| t7 mana', t['mana_t7'], '| lands', t['lands'], 'drop', t['land_drop'],
              '| answers', t['interaction_cards'], t['removal_level'], '| routes', t['routes'], '| avgMV', t['avg_mv'], '| salt', d['salt'])
        print('  ratings', {k: d[k] for k in ['mana','cards','consistency','threats','clock','reach','answers','staying','control']}, 'E/O/D', d['engine'], d['offense'], d['defense'])
        print('  best', [(b['card'], b['value']) for b in t['best']])
        print('  weak', [(b['card'], b['value'], b['why']) for b in t['weakest']])
        print('  cmdr', [(b['card'], b['value']) for b in t['commander']])
