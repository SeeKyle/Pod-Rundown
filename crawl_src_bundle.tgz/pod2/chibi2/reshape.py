"""0.12.179 (Kyle): slimmer chibis without squashing them: the head is shrunk evenly (same shape, a bit smaller, a touch narrower) and the
body below the neck is narrowed. Scaling goes 4x-up nearest, then a smooth downscale, then every pixel snapped back to the frame's own
colours with a hard alpha cut, so the result stays clean pixel art."""
import numpy as np
from PIL import Image
HEAD_S=.80      # head: 80% size
HEAD_X=.90      # and 10% narrower on top of that
BODY_X=.68      # body below the neck: 32% thinner
def _scale(im,sx,sy):
    w,h=im.size;W,H=max(1,round(w*sx)),max(1,round(h*sy))
    if W<1 or H<1: return im
    big=im.resize((w*4,h*4),Image.NEAREST);return big.resize((W,H),Image.LANCZOS)
def _snap(im,pal):
    a=np.array(im).astype(np.float32);out=np.zeros(a.shape,np.uint8)
    m=a[:,:,3]>110
    if m.any():
        px=a[m][:,:3];d=((px[:,None,:]-pal[None,:,:])**2).sum(2);out[m,:3]=pal[d.argmin(1)];out[m,3]=255
    return Image.fromarray(out,'RGBA')
def reshape(fr,ax,Hidle):
    a=np.array(fr);al=a[:,:,3]>0
    if not al.any(): return fr
    ys,xs=np.where(al);top,bot=int(ys.min()),int(ys.max())
    cols=a[al][:,:3];pal=np.unique(cols,axis=0).astype(np.float32)
    out=Image.new('RGBA',fr.size,(0,0,0,0))
    if bot-top+1<.62*Hidle:   # lying down / tucked: just slim the whole thing evenly
        crop=fr.crop((0,top,fr.width,bot+1));s=_snap(_scale(crop,BODY_X,.9),pal)
        out.alpha_composite(s,(int(round(ax-ax*BODY_X)),bot+1-s.height));return out
    neck=top+int(round(.49*Hidle))
    # 0.12.182 (Kyle): only the torso core is slimmed; whatever sticks out past it (a sword, a bow, a staff, an arm) is moved in rigidly,
    # pixel for pixel, so weapons keep their exact size and look
    C=13;L0,R0=max(0,ax-C),min(fr.width,ax+C);cw=int(round((R0-L0)*BODY_X));nl=int(round(ax-(ax-L0)*BODY_X))
    core=fr.crop((L0,neck,R0,bot+1));b=_snap(_scale(core,BODY_X,1),pal);out.alpha_composite(b,(nl,neck))
    left=fr.crop((0,neck,L0,bot+1));right=fr.crop((R0,neck,fr.width,bot+1))
    if L0>0: out.alpha_composite(left,(nl-L0,neck))
    if R0<fr.width: out.alpha_composite(right,(nl+b.width,neck))
    head=fr.crop((0,top,fr.width,neck));hb=np.array(head)[:,:,3]>0;hx=np.where(hb.any(0))[0]
    cx=(hx.min()+hx.max()+1)/2 if len(hx) else ax
    hs=_snap(_scale(head,HEAD_S*HEAD_X,HEAD_S),pal)
    nx=int(round(ax+(cx-ax)*BODY_X-cx*HEAD_S*HEAD_X));out.alpha_composite(hs,(nx,neck+1-hs.height))   # sits on the neck (1px overlap)
    # the body was pasted first; put the head on top, then redraw any body pixels that should overlap the chin
    return out
