"""0.12.176 (Kyle): Chibi_Warrior's new art: the Swordsman from CraftPix's 'Free Fantasy Chibi Male Sprites Pixel Art' (license: https://craftpix.net/file-licenses/),
with his blonde hair darkened to a medium brown (Kyle's ask). Replaces the old chibi art, which turned out not to be free. The sheet faces right (faceR)."""
import json, sys, numpy as np
from PIL import Image
sys.path.insert(0,'/home/claude/pod2/chibi2');from reshape import reshape
S='/tmp/cpx/chibi/Swordsman/'
HAIR={(255,213,65):(168,118,70),(248,197,58):(146,98,58),(249,163,27):(128,84,48),(232,138,54):(104,66,40),(176,91,44):(72,44,30)}
def load(f):
    a=np.array(Image.open(S+f+'.png').convert('RGBA'))
    for k,v in HAIR.items():
        m=np.all(a[:,:,:3]==k,axis=2)&(a[:,:,3]>0);a[m,:3]=v
    im=Image.fromarray(a,'RGBA');n=im.width//128;return [im.crop((i*128,0,(i+1)*128,128)) for i in range(n)]
rows=[('idle','Idle'),('walk','Walk'),('run','Run'),('attack1','Attack_3'),('attack2','Attack_2'),('runatk','Attack_3'),('hurt','Hurt'),('death','Dead'),('ranged','Attack_1')]   # 0.12.178: sword slash/thrust for melee; the kunai toss is built from Attack_1 below
fr={k:load(f) for k,f in rows}
def _main_only(im):   # keep only the body (largest connected blob); drops the swing trail
    from scipy import ndimage
    a=np.array(im);m=a[:,:,3]>0;lab,n=ndimage.label(m,structure=np.ones((3,3)))
    if n>1:
        sz=ndimage.sum(m,lab,range(1,n+1));keep=1+int(np.argmax(sz));a[(lab!=keep)&m,3]=0
    return Image.fromarray(a,'RGBA')
def _kunai_back(im):   # 0.12.180: the kunai in his hand while it's cocked back behind him (left-most pixels at hand height)
    a=np.array(im);m=a[:,:,3]>0;ys,xs=np.where(m);top,bot=ys.min(),ys.max();rows=set(range(top+int((bot-top)*.5),top+int((bot-top)*.7)))
    pts=[(y,x) for y,x in zip(ys,xs) if y in rows];hy,hx=min(pts,key=lambda p:p[1])
    for k in range(5):a[hy-1-k,hx-1+ (k//2),:]=(46,48,64,255) if k<3 else (220,226,236,255)   # blade pointing up and back
    a[hy-6,hx+1,:]=(255,255,255,255)
    return Image.fromarray(a,'RGBA')
def _arm_out(im,kunai):   # 0.12.180: the arm snapped straight out in front at shoulder height, hand open (and the kunai just leaving it)
    a=np.array(im);m=a[:,:,3]>0;ys,xs=np.where(m);top,bot=ys.min(),ys.max();sy=top+int((bot-top)*.56)
    sx=max(x for y,x in zip(ys,xs) if y in (sy,sy+1))
    OUT=(6,6,8,255);SLV=(20,52,100,255);SKN=(255,194,161,255)
    L=15   # long enough to still read as a straight arm after the body is slimmed
    for k in range(L):
        x=sx-2+k;a[sy-1,x,:]=OUT;a[sy,x,:]=SLV if k<L-3 else SKN;a[sy+1,x,:]=SLV if k<L-3 else SKN;a[sy+2,x,:]=OUT
    a[sy-1:sy+3,sx-2+L,:]=OUT
    if kunai:
        for k in range(9):a[sy,sx+L+k,:]=(46,48,64,255) if k<6 else (220,226,236,255)
        a[sy-1,sx+L+8,:]=(255,255,255,255);a[sy+1,sx+L+8,:]=(255,255,255,255)
    return Image.fromarray(a,'RGBA')
_A=fr['ranged']   # 0.12.180 (Kyle): kunai toss: draw back, cock (kunai glints), snap the arm forward (trail removed), follow through
fr['ranged']=[_A[1],_kunai_back(_A[1]),_A[3],_arm_out(_main_only(_A[4]),1),_arm_out(_main_only(_A[4]),0)]
_a=np.array(fr['idle'][0])[:,:,3]>0;_ys,_xs=np.where(_a);_y1=int(_ys.max());_AX=int(round(np.where(_a[_y1-5:_y1+1].any(0))[0].mean()));_H0=int(_ys.max()-_ys.min()+1)
fr={k:[reshape(f,_AX,_H0) for f in v] for k,v in fr.items()}   # 0.12.179 (Kyle): smaller head, slimmer body (see reshape.py)   # 0.12.178 (Kyle): kunai toss: draw back, cock, snap the arm forward (no slash trail), follow through
a=np.array(fr['idle'][0])[:,:,3]>0;ys,xs=np.where(a);y1=int(ys.max());legs=np.where(a[y1-5:y1+1].any(0))[0];AX=int(round(legs.mean()));AY=y1+1;H=int(ys.max()-ys.min()+1)
PRE=round(.6713*H/71,4)   # 0.12.179: keep the on-screen height he had (71 px at .6713) now that the head is smaller   # about the old Chibi_Warrior's size (a big chibi head reads larger, so a touch smaller)
W=max(len(v) for v in fr.values())*128;out=Image.new('RGBA',(W,128*len(rows)),(0,0,0,0));meta={}
for r,(k,_) in enumerate(rows):
    for i,f in enumerate(fr[k]): out.alpha_composite(f,(i*128,r*128))
    meta[k]=dict(fw=128,fh=128,n=len(fr[k]),ax=AX,ay=AY,x=0,y=r*128,img='chibi',pre=PRE,faceR=1,pk=1.5)
out.save('/home/claude/pod2/crawl_chibi.png',optimize=True)
A=json.load(open('/home/claude/pod2/crawl_atlas.json'));old=A['units'].get('chibi',{})
for k in meta:
    if old.get(k,{}).get('fall'):meta[k]['fall']=old[k]['fall']
A['units']['chibi']=meta;json.dump(A,open('/home/claude/pod2/crawl_atlas.json','w'))
print(AX,AY,H,PRE,{k:v['n'] for k,v in meta.items()})
