"""0.12.176 (Kyle): Chibi_Warrior's new art: the Swordsman from CraftPix's 'Free Fantasy Chibi Male Sprites Pixel Art' (license: https://craftpix.net/file-licenses/),
with his blonde hair darkened to a medium brown (Kyle's ask). Replaces the old chibi art, which turned out not to be free. The sheet faces right (faceR)."""
import json, numpy as np
from PIL import Image
S='/tmp/cpx/chibi/Swordsman/'
HAIR={(255,213,65):(168,118,70),(248,197,58):(146,98,58),(249,163,27):(128,84,48),(232,138,54):(104,66,40),(176,91,44):(72,44,30)}
def load(f):
    a=np.array(Image.open(S+f+'.png').convert('RGBA'))
    for k,v in HAIR.items():
        m=np.all(a[:,:,:3]==k,axis=2)&(a[:,:,3]>0);a[m,:3]=v
    im=Image.fromarray(a,'RGBA');n=im.width//128;return [im.crop((i*128,0,(i+1)*128,128)) for i in range(n)]
rows=[('idle','Idle'),('walk','Walk'),('run','Run'),('attack1','Attack_3'),('attack2','Attack_2'),('runatk','Attack_3'),('hurt','Hurt'),('death','Dead'),('ranged','Attack_1')]   # 0.12.178: sword slash/thrust for melee; the kunai toss is built from Attack_1 below
fr={k:load(f) for k,f in rows}
fr['ranged']=[fr['ranged'][i] for i in (1,2,3,5)]   # 0.12.178 (Kyle): kunai toss: draw back, cock, snap the arm forward (no slash trail), follow through
a=np.array(fr['idle'][0])[:,:,3]>0;ys,xs=np.where(a);y1=int(ys.max());legs=np.where(a[y1-5:y1+1].any(0))[0];AX=int(round(legs.mean()));AY=y1+1;H=int(ys.max()-ys.min()+1)
PRE=round(.5526*H/82*1.15*1.22,4)   # about the old Chibi_Warrior's size (a big chibi head reads larger, so a touch smaller)
W=max(len(v) for v in fr.values())*128;out=Image.new('RGBA',(W,128*len(rows)),(0,0,0,0));meta={}
for r,(k,_) in enumerate(rows):
    for i,f in enumerate(fr[k]): out.alpha_composite(f,(i*128,r*128))
    meta[k]=dict(fw=128,fh=128,n=len(fr[k]),ax=AX,ay=AY,x=0,y=r*128,img='chibi',pre=PRE,faceR=1,pk=1.7,sx=.72)
out.save('/home/claude/pod2/crawl_chibi.png',optimize=True)
A=json.load(open('/home/claude/pod2/crawl_atlas.json'));old=A['units'].get('chibi',{})
for k in meta:
    if old.get(k,{}).get('fall'):meta[k]['fall']=old[k]['fall']
A['units']['chibi']=meta;json.dump(A,open('/home/claude/pod2/crawl_atlas.json','w'))
print(AX,AY,H,PRE,{k:v['n'] for k,v in meta.items()})
