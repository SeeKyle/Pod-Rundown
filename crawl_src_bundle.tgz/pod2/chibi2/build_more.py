"""0.12.178 (Kyle): Chibi_Archer and Chibi_Sorcerer from CraftPix's 'Free Fantasy Chibi Male Sprites Pixel Art' (Archer, Wizard),
drawn at the same small, slim scale as Chibi_Warrior. The Sorcerer's Thunderclap uses Explosion_7 (lightning) from CraftPix's
'Free Animated Explosion Sprite Pack'. License for both: https://craftpix.net/file-licenses/  Sheets face right (faceR)."""
import json, glob, sys, numpy as np
from PIL import Image
sys.path.insert(0,'/home/claude/pod2/chibi2');from reshape import reshape
C='/tmp/cpx/chibi/'
def load(ch,f):
    im=Image.open(C+ch+'/'+f+'.png').convert('RGBA');n=im.width//128;return [im.crop((i*128,0,(i+1)*128,128)) for i in range(n)]
def build(ch,key,rows,extra=None):
    fr={k:load(ch,f) for k,f in rows}
    a=np.array(fr['idle'][0])[:,:,3]>0;ys,xs=np.where(a);y1=int(ys.max());AX0=int(round(np.where(a[y1-5:y1+1].any(0))[0].mean()));H0=int(ys.max()-ys.min()+1)
    fr={k:[reshape(f,AX0,H0) for f in v] for k,v in fr.items()}   # 0.12.179 (Kyle): smaller head, slimmer body
    a=np.array(fr['idle'][0])[:,:,3]>0;ys,xs=np.where(a);y1=int(ys.max());legs=np.where(a[y1-5:y1+1].any(0))[0];AX=int(round(legs.mean()));AY=y1+1;H=int(ys.max()-ys.min()+1)
    PRE=round(.6713*H/71*H0/H*H/H0,4)   # same pixel scale as Chibi_Warrior
    ex=extra or []
    W=max([len(v) for v in fr.values()]+[len(e[1]) for e in ex])*128;Ht=128*len(rows)+sum(e[2] for e in ex)
    out=Image.new('RGBA',(W,Ht),(0,0,0,0));meta={}
    for r,(k,_) in enumerate(rows):
        for i,f in enumerate(fr[k]): out.alpha_composite(f,(i*128,r*128))
        meta[k]=dict(fw=128,fh=128,n=len(fr[k]),ax=AX,ay=AY,x=0,y=r*128,img=key,pre=PRE,faceR=1,pk=1.5)
    y=128*len(rows);others={}
    for name,frames,fh,fw,ax,ay in ex:
        for i,f in enumerate(frames): out.alpha_composite(f,(i*fw,y))
        others[name]=dict(fw=fw,fh=fh,n=len(frames),ax=ax,ay=ay,x=0,y=y,img=key);y+=fh
    out.save('/home/claude/pod2/crawl_%s.png'%key,optimize=True)
    print(key,AX,AY,H,PRE,{k:v['n'] for k,v in meta.items()},list(others))
    return meta,others
am,ao=build('Archer','carcher',[('idle','Idle'),('walk','Walk'),('run','Run'),('ranged','Shot_1'),('shot2','Shot_2'),('melee','Attack_1'),('jump','Jump'),('hurt','Hurt'),('death','Dead')])
# lightning strike: Explosion_7/1, scaled to 52x264, anchored at the bottom middle
L=[Image.open(f).convert('RGBA').resize((52,264),Image.LANCZOS) for f in sorted(glob.glob('/tmp/cpx/expl/PNG/Explosion_7/1/*.png'))]
wm,wo=build('Wizard','csorc',[('idle','Idle'),('walk','Walk'),('run','Run'),('ranged','Attack_2'),('cast','Attack_1'),('nova','Attack_3'),('melee','Attack_2'),('hurt','Hurt'),('death','Dead')],
            extra=[('bolt',L,264,52,26,262)])
A=json.load(open('/home/claude/pod2/crawl_atlas.json'))
A['units']['carcher']=am;A['units']['csorc']=wm;A['strike']=wo['bolt']
json.dump(A,open('/home/claude/pod2/crawl_atlas.json','w'))
