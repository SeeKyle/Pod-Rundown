import json, sys
sys.path.insert(0, '/home/claude/pod2')
from takeaways_text import TEXTS
from build_data import build
d, res, divs = build(TEXTS)
json.dump(d, open('/home/claude/pod2/data.json', 'w'), ensure_ascii=False)
t = open('/home/claude/pod2/template.html').read()
import time as _t; t = t.replace('crawl.js?v=0.12.1', 'crawl.js?v=%d' % int(_t.time()))   # 0.12.23: cache-bust the game script on every build so new art/code always loads
a = t.index("      <h2>What's new</h2>"); b = t.index('    </section>\n  </div>\n</div>\n\n<script>')
t = t[:a] + open('/home/claude/pod2/notes.html').read() + t[b:]
import re as _re   # 0.12.0: the old Clock/⛔ patches now live in template.html itself

from stat_page import STATDOCS, RATING_MATH
t = t.replace('__STATDOCS__', json.dumps(dict(stats=STATDOCS, math=RATING_MATH), ensure_ascii=False).replace('</', '<\\/'))
from story_kit import KIT, PAIR
GATE = False   # 0.12.1: members-only login page. Off for now (Kyle's call); flip to True to turn it back on.
if not GATE:
    t = _re.sub(r'<!--GATE-->.*?<!--/GATE-->', '', t, flags=_re.S)
_D = json.load(open('/home/claude/pod2/data.json'))['decks']
_top = sorted(_D, key=lambda r: -r['total'])[:8]
t = t.replace('__HISCORE__', ''.join(f"<span>{i+1:02d}</span><span>{r['deck'][:16].upper()}</span><span>{int(r['total']*100):06d}</span>" for i, r in enumerate(_top)))
t = t.replace('__DECKCOUNT__', str(len(_D)))
t = t.replace('__TICKER__', ' ★ '.join(f"{r['icon']} {r['deck'].upper()}" for r in sorted(_D, key=lambda r: r['deck'])) + ' ★ HIGH ROLLERS WELCOME ★ ')
t = t.replace('__SIMDATA__', open('/tmp/claude-0/simdata.json').read().replace('</', '<\\/'))
t = t.replace('__SIMENGINE__', open('/home/claude/pod2/sim_engine.js').read())
t = t.replace('__STORYKIT__', json.dumps(dict(KIT, __pair=PAIR), ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/'))
t = t.replace('__OUTCOMES__', open('/home/claude/pod2/pod_outcomes.json').read().replace('</', '<\\/'))
t = t.replace('__DATA__', json.dumps(d, ensure_ascii=False).replace('</', '<\\/'))
open('/home/claude/pod2/index.html', 'w').write(t)
for k in d['takeaways']: print(k['deck'], [(x['card'], x['read']) for x in k['repair']])
