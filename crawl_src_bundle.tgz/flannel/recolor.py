import numpy as np
from PIL import Image
from skimage.color import rgb2hsv
from scipy import ndimage as nd
src=Image.open('flannel_orig.png').convert('RGBA');A=np.array(src).astype(float);rgb=A[...,:3]/255
Hh,Ww=rgb.shape[:2]
bg=np.array([94,107,100])/255
fg=(np.linalg.norm(rgb-bg,axis=2)>0.11)
fg[:, :250]=False   # row labels
# separator lines: long horizontal dark runs
rowdark=(rgb.sum(2)<0.25).mean(1)>0.5;fg[rowdark,:]=False
lab,n=nd.label(nd.binary_dilation(fg,iterations=3))
objs=nd.find_objects(lab)
hsv=rgb2hsv(rgb);H=hsv[...,0]*360;S=hsv[...,1];V=hsv[...,2]
out=A.copy()
AP=3.5
PL={'base':(48,86,44),'band':(30,58,31),'cross':(18,36,21),'light':(92,128,72),'black':(14,24,16)}
def plaid(cx,cy):
    u,v=cx%6,cy%6;bu,bv=u<2,v<2
    if u==4 or v==4: return PL['light'] if (cx//6+cy//6)%2==0 else PL['black']
    if bu and bv: return PL['cross']
    if bu or bv: return PL['band']
    return PL['base']
rng=np.random.default_rng(7)
stats={'coat':0,'hair':0}
for i,sl in enumerate(objs):
    if sl is None: continue
    ys,xs=sl;h=ys.stop-ys.start;w=xs.stop-xs.start
    if h*w<900: continue   # specks, muzzle flashes
    death=ys.start>1470
    m=(lab[sl]==i+1)&fg[sl]
    hh,ss,vv=H[sl],S[sl],V[sl]
    rows=np.arange(h)[:,None]/max(1,h);cols=np.arange(w)[None,:]
    head=(rows<0.27) if not death else np.ones_like(rows,bool)
    hair=m&head&(((hh>=12)&(hh<=40))&(ss>=0.42)&(vv>=0.18)&(vv<=0.74))
    coat=m&(~hair)&(((hh>=342)|(hh<=17))&(ss>=0.38)&(ss<=0.8)&(vv>=0.14)&(vv<=0.52))
    if not death: coat&=(rows>0.2)&(rows<0.6)
    yy,xx=np.nonzero(coat)
    for y,x in zip(yy,xx):
        cx=int(x/AP);cy=int(y/AP);c=np.array(plaid(cx,cy),float)
        f=np.clip(vv[y,x]/0.33,0.55,1.45);out[ys.start+y,xs.start+x,:3]=np.clip(c*f,0,255)
    yy,xx=np.nonzero(hair)
    for y,x in zip(yy,xx):
        cx=int(x/2);cy=int(y/2);r=((cx*73856093)^(cy*19349663)^(i*83492791))%1000/1000
        base=(92,92,99) if r<0.13 else (30,28,33)
        f=np.clip(0.55+vv[y,x]/0.75,0.6,1.35);out[ys.start+y,xs.start+x,:3]=np.clip(np.array(base,float)*f,0,255)
    stats['coat']+=len(yy)*0+coat.sum();stats['hair']+=hair.sum()
Image.fromarray(out.astype(np.uint8),'RGBA').save('flannel_man_green.png')
print(stats,len(objs))
t=Image.open('flannel_man_green.png');t2=t.crop((290,50,380,220));t2.resize((t2.width*6,t2.height*6),Image.NEAREST).save('zoom_new.png')
p=t.copy();p.thumbnail((900,900));p.save('preview_new.png')
