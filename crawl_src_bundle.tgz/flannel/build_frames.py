import numpy as np, json
from PIL import Image
from scipy import ndimage as nd
S=np.array(Image.open('flannel_man_green.png').convert('RGBA')).astype(int)
bg=np.array([94,107,100]);fg=np.abs(S[...,:3]-bg).sum(2)>28
dark=(S[...,:3].sum(2)<190).mean(1)>0.5;fg[:, :240]=False;fg[dark,:]=False
for y in range(1440,1475):
    if (S[y,:,:3].sum(1)<190).mean()>0.25: fg[y,:]=False
for yy in [231,485,692,887,1072,1256,1449]: fg[yy-6:yy+7,:]=False
ROWS={'idle':(0,231),'walk':(231,485),'run':(485,692),'melee':(692,887),'ranged':(887,1072),'reload':(1072,1254),'hurt':(1254,1462),'death':(1462,1652)}
lab,n=nd.label(nd.binary_dilation(fg,iterations=2));objs=nd.find_objects(lab)
res={}
for name,(y0,y1) in ROWS.items():
    comps=[]
    for i,sl in enumerate(objs):
        if not sl: continue
        cy=(sl[0].start+sl[0].stop)/2
        if not (y0<=cy<y1): continue
        m=(lab[sl]==i+1)&fg[sl];area=m.sum()
        if area<8: continue
        px=S[sl][m][:,:3];txt=(px.sum(1)<110).mean()>0.8 and sl[1].start<340
        if txt: continue
        comps.append((sl[1].start,i,sl,area))
    first=min(c[0] for c in comps if c[3]>2500)
    groups={}
    for x,i,sl,a in comps:
        k=int((x-first+10)//192)
        if k<0: continue
        groups.setdefault(k,[]).append((i,sl))
    frames=[]
    for k in sorted(groups):
        m=np.zeros(S.shape[:2],bool)
        for i,sl in groups[k]: m[sl]|=(lab[sl]==i+1)&fg[sl]
        if m.sum()<1500: continue
        frames.append((first+k*192,m))
    res[name]=(y0,y1,frames)
    print(name,len(frames),[f[0] for f in frames])
import pickle;pickle.dump(res,open('/tmp/fm_rows.pkl','wb'))
