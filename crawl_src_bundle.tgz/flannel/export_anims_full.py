import numpy as np, pickle, os
from PIL import Image
S=np.array(Image.open('flannel_man_green.png').convert('RGBA')).astype(np.uint8)
res=pickle.load(open('/tmp/fm_rows.pkl','rb'))
F=1.0;L,R,U=90,140,200   # window around the anchor (sheet px): left, right, up
OUT='/home/claude/pod2/assets/heroes/flannel/';os.makedirs(OUT,exist_ok=True)
def frame_from(mask,img,ax,gy):
    x0,x1,y0,y1=int(ax-L),int(ax+R),int(gy-U),int(gy+8)
    c=np.zeros((y1-y0,x1-x0,4),np.uint8)
    sy0,sx0=max(0,y0),max(0,x0);sy1,sx1=min(img.shape[0],y1),min(img.shape[1],x1)
    sub=img[sy0:sy1,sx0:sx1].copy();m=mask[sy0:sy1,sx0:sx1]
    sub[...,3]=np.where(m,255,0);c[sy0-y0:sy1-y0,sx0-x0:sx1-x0]=sub;return c
def shrink(c):
    if F==1.0:
        rgb=c[...,:3].astype(float);al=c[...,3]
        near=np.abs(rgb-np.array([94,107,100])).sum(2)<40
        o=c.copy();o[...,3]=np.where((al>0)&~near,255,0);return o
    im=Image.fromarray(c);w,h=round(im.width/F),round(im.height/F)
    a=np.array(im).astype(float);pm=a.copy();pm[...,:3]*=a[...,3:]/255
    s=np.array(Image.fromarray(pm.astype(np.uint8)).resize((w,h),Image.BOX)).astype(float)
    al=np.array(Image.fromarray(c[...,3]).resize((w,h),Image.BOX)).astype(float)
    rgb=np.where(al[...,None]>0,s[...,:3]*255/np.maximum(al[...,None],1),0)
    near=np.abs(rgb-np.array([94,107,100])).sum(2)<45;light=(rgb.min(2)>150)&(al<200)
    o=np.dstack([np.clip(rgb,0,255),np.where((al>110)&~near&~light,255,0)]).astype(np.uint8);return o
def export(name,frames_hr):
    sm=[shrink(f) for f in frames_hr]
    sm=[np.ascontiguousarray(f[:,::-1]) for f in sm]   # stored facing LEFT like the other units
    fw=sm[0].shape[1];sheet=np.concatenate(sm,1);Image.fromarray(sheet).save(OUT+name+'.png');return fw,len(sm)
info={}
for name,(y0,y1,frames) in res.items():
    gy=max(np.nonzero(m.any(1))[0].max() for _,m in frames)
    # anchor x: per frame, centre of the lowest 30 px (feet), using the median offset from the cell so the grid stays steady
    offs=[]
    for cx,m in frames:
        ys,xs=np.nonzero(m[gy-60:gy+1]);offs.append(np.median(xs)-cx)
    off=float(np.median(offs))
    hr=[frame_from(m,S,cx+off,gy) for cx,m in frames]
    info[name]=export(name,hr)
# walk-fire: rebuild from its strip (same pixel size as the sheet)
st=np.array(Image.open('flannel_walk_fire_strip.png').convert('RGBA'));fw=st.shape[1]//8
hr=[]
for i in range(8):
    f=st[:,i*fw:(i+1)*fw];a=f[...,3]>0;gy=np.nonzero(a.any(1))[0].max();ys,xs=np.nonzero(a[gy-60:gy+1]);ax=np.median(xs)
    pad=np.zeros((f.shape[0]+400,f.shape[1]+400,4),np.uint8);pad[200:200+f.shape[0],200:200+f.shape[1]]=f
    hr.append(frame_from(pad[...,3]>0,pad,ax+200,gy+200))
# keep walk-fire steps steady: reuse the walk frames' anchor rule (median)
info['walkfire']=export('walkfire',hr)
print(info)
