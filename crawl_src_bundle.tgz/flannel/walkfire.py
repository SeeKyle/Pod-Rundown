import numpy as np
from PIL import Image, ImageDraw, ImageFont
S=np.array(Image.open('flannel_man_green.png').convert('RGBA')).astype(int)
bg=np.array([94,107,100])
def crop(x0,x1,y0,y1):
    c=S[y0:y1,x0:x1].copy();m=np.abs(c[...,:3]-bg).sum(2)>25;c[...,3]=np.where(m,255,0);return c
WALK=[(278,362),(470,545),(662,730),(854,914),(1046,1114),(1238,1314),(1430,1510),(1617,1696)]
walk=[crop(x0-6,x1+6,250,446) for x0,x1 in WALK]          # same top/bottom for all, so bob is kept
RNG=[(330,466),(526,718),(718,918),(918,1104),(1104,1300)]
rng=[crop(x0,x1,900,1062) for x0,x1 in RNG]
def green(c): return (c[...,3]>0)&(c[...,1]>c[...,0]+12)&(c[...,1]>c[...,2]+4)
def hip(c):
    g=green(c).sum(1);lim=int(c.shape[0]*0.72);rows=np.nonzero(g[:lim]>4)[0];return rows.max()+1
def pants_cx(c,row,xmax=None):
    for k in (3,5,8,1):
        xs=np.nonzero(c[min(row+k,c.shape[0]-1),:xmax,3]>0)[0]
        if len(xs): return xs.mean()
    return c.shape[1]/2
def ground(c): return np.nonzero(c[...,3].sum(1)>0)[0].max()
SEQ=[0,1,2,3,4,0,0,0]
frames=[]
for i,w in enumerate(walk):
    r=rng[SEQ[i]]
    hw=hip(w);hr=hip(r)
    # torso x: centre of the pants just under the hip in both
    cw=pants_cx(w,hw);cr=pants_cx(r,hr,int(r.shape[1]*0.55))
    H=230;W=260;out=np.zeros((H,W,4),int)
    gy=H-14;ox_w=40;oy_w=gy-ground(w)
    lower=w.copy();lower[:hw]=0
    # walk frame's hand-in-pocket and satchel bottom poke out below the coat: paint them as pants
    for y in range(hw,min(hw+16,lower.shape[0])):
        row=lower[y];a=row[:,3]>0
        hot=a&((row[:,0]-row[:,2])>45)
        calm=a&~hot&(row[:,0]>40)
        if hot.any() and calm.any():
            xs=np.nonzero(calm)[0];
            for x in np.nonzero(hot)[0]:
                j=xs[np.argmin(abs(xs-x))];row[x,:3]=row[j,:3]
    def paste(img,ox,oy):
        h,wd=img.shape[:2]
        for y in range(h):
            yy=y+oy
            if not 0<=yy<H: continue
            row=img[y];m=row[:,3]>0;xs=np.nonzero(m)[0]+ox;ok=(xs>=0)&(xs<W)
            out[yy,xs[ok]]=row[m][ok]
    paste(lower,ox_w,oy_w)
    upper=r.copy();upper[hr+2:]=0
    oy_r=oy_w+hw-hr;ox_r=int(round(ox_w+cw-cr))
    paste(upper,ox_r,oy_r)
    frames.append(out.astype(np.uint8))
# crop all frames to one shared box
al=np.stack([f[...,3] for f in frames]).max(0);ys,xs=np.nonzero(al)
y0,y1,x0,x1=max(0,ys.min()-2),ys.max()+3,max(0,xs.min()-2),xs.max()+3
frames=[f[y0:y1,x0:x1] for f in frames]
fw,fh=frames[0].shape[1],frames[0].shape[0]
strip=Image.new('RGBA',(fw*8,fh),(0,0,0,0))
for i,f in enumerate(frames): strip.paste(Image.fromarray(f),(i*fw,0))
strip.save('flannel_walk_fire_strip.png');print('frame',fw,fh)
# add as a new row on the sheet (sheet's other rows untouched)
sheet=Image.open('flannel_man_green.png').convert('RGBA');SW,SH=sheet.size
rowh=fh+40;new=Image.new('RGBA',(SW,SH+rowh),(94,107,100,255));new.paste(sheet,(0,0))
d=ImageDraw.Draw(new);d.rectangle((0,SH,SW,SH+5),fill=(20,20,20,255))
try: f=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',54)
except: f=ImageFont.load_default()
d.text((20,SH+rowh//2-34),'Walk',fill=(10,10,10,255),font=f);d.text((20,SH+rowh//2+14),'Fire',fill=(10,10,10,255),font=f)
step=(SW-260)//8
for i,fr in enumerate(frames):
    im=Image.fromarray(fr);new.alpha_composite(im,(260+i*step,SH+22))
new.save('flannel_man_sheet_v2.png')
z=strip.resize((strip.width*3,strip.height*3),Image.NEAREST);bgz=Image.new('RGBA',z.size,(94,107,100,255));bgz.alpha_composite(z);bgz.save('wf_zoom.png')
# gif preview
g=[]
for fr in frames:
    im=Image.new('RGBA',(fw,fh),(94,107,100,255));im.alpha_composite(Image.fromarray(fr));g.append(im.resize((fw*3,fh*3),Image.NEAREST).convert('P',palette=Image.ADAPTIVE))
g[0].save('flannel_walk_fire.gif',save_all=True,append_images=g[1:],duration=110,loop=0)
