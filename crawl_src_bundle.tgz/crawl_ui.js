// ======================================================================= UI (browser only)
const IMG=new Image();IMG.src='crawl.png?v=__VER__';const BGI=new Image();BGI.src='crawl_bg.png?v=__VER__';
const SP=ATLAS.sprites,BGA=ATLAS.bg,RES=ATLAS.res||1;const UNITS=ATLAS.units||{};const UIMG=new Image();UIMG.src='crawl_units.png?v=__VER__';const RAIN={f:{fw:5,fh:18,n:1,ax:2,ay:17,x:0,y:0,img:'rain'},s:{fw:5,fh:11,n:1,ax:2,ay:10,x:8,y:7,img:'rain'}};
const CAMPF={fw:34,fh:40,ax:17,ay:37,y:0,img:'camp'};
const XIMG={cityob:new Image(),cars:new Image(),cultist:new Image(),tentacle:new Image(),robot:new Image(),obst:new Image(),lumberjack:new Image(),camp:new Image(),druid:new Image(),tornado:new Image(),vine:new Image(),thorn:new Image(),rain:new Image(),flannel:new Image(),alchemist:new Image(),boom:new Image(),pal:new Image(),chibi:new Image(),wave:new Image(),archer:new Image()};XIMG.archer.src='crawl_archer.png?v=__VER__';XIMG.wave.src='crawl_wave.png?v=__VER__';XIMG.chibi.src='crawl_chibi.png?v=__VER__';XIMG.flannel.src='crawl_flannel.png?v=__VER__';XIMG.alchemist.src='crawl_alch.png?v=__VER__';XIMG.jp=new Image();XIMG.jp.src='crawl_jp.png?v=__VER__';XIMG.eng=new Image();XIMG.eng.src='crawl_eng.png?v=__VER__';XIMG.shoshi=new Image();XIMG.shoshi.src='crawl_shoshi.png?v=__VER__';XIMG.teeg=new Image();XIMG.teeg.src='crawl_teeg.png?v=__VER__';XIMG.seekyle=new Image();XIMG.seekyle.src='crawl_seekyle.png?v=__VER__';XIMG.kids=new Image();XIMG.kids.src='crawl_kids.png?v=__VER__';XIMG.gear=new Image();XIMG.gear.src='crawl_gear.png?v=__VER__';XIMG.portals=new Image();XIMG.portals.src='crawl_portals.png?v=__VER__';XIMG.skel=new Image();XIMG.skel.src='crawl_skel.png?v=__VER__';XIMG.knight=new Image();XIMG.knight.src='crawl_knight.png?v=__VER__';XIMG.strike=new Image();XIMG.strike.src='crawl_strike.png?v=__VER__';XIMG.soldier=new Image();XIMG.soldier.src='crawl_soldier.png?v=__VER__';XIMG.bghood=new Image();XIMG.bghood.src='crawl_bg_hood.png?v=__VER__';XIMG.bloater=new Image();XIMG.hazmat=new Image();XIMG.hazmat.src='crawl_hazmat.png?v=__VER__';XIMG.bloater.src='crawl_bloater.png?v=__VER__';XIMG.screamer=new Image();XIMG.screamer.src='crawl_screamer.png?v=__VER__';XIMG.flame=new Image();XIMG.flame.src='crawl_flame.png?v=__VER__';XIMG.rain.src='crawl_rain.png?v=__VER__';XIMG.druid.src='crawl_druid.png?v=__VER__';XIMG.camp.src='crawl_campfire.png?v=__VER__';XIMG.lumberjack.src='crawl_lumberjack.png?v=__VER__';XIMG.tornado.src='crawl_fx_tornado.png?v=__VER__';XIMG.vine.src='crawl_fx_vine.png?v=__VER__';XIMG.thorn.src='crawl_fx_thorn.png?v=__VER__';
const TORN={fw:96,fh:96,n:16,ax:48,ay:90,x:0,y:0,img:'tornado',art:1},VINE={fw:260,fh:116,n:7,ax:130,ay:110,x:0,y:0,img:'vine',art:1};
const THORNS=[[0,35,53],[37,67,79],[106,36,82],[144,87,74]].map(([x,w,h])=>({fw:w,fh:h,n:1,ax:w/2,ay:81,x,y:82-h,img:'thorn',art:1}));XIMG.pal.src='crawl_pal.png?v=__VER__';XIMG.axe=new Image();XIMG.axe.src='crawl_axe.png?v=__VER__';XIMG.fxp=new Image();XIMG.fxp.src='crawl_fxpack.png?v=__VER__';XIMG.nest=new Image();XIMG.nest.src='crawl_mgnest.png?v=__VER__';XIMG.dog=new Image();XIMG.dog.src='crawl_dog.png?v=__VER__';XIMG.bat=new Image();XIMG.bat.src='crawl_bat.png?v=__VER__';XIMG.edward=new Image();XIMG.edward.src='crawl_edward.png?v=__VER__';XIMG.cheez=new Image();XIMG.cheez.src='crawl_cheez.png?v=__VER__';XIMG.obst.src='crawl_obst.png?v=__VER__';XIMG.cityob.src='crawl_cityob.png?v=__VER__';XIMG.cars.src='crawl_cars.png?v=__VER__';XIMG.robot.src='crawl_robot.png?v=__VER__';XIMG.cultist.src='crawl_cultist.png?v=__VER__';XIMG.tentacle.src='crawl_tentacle.png?v=__VER__';XIMG.boom.src='crawl_boom.png?v=__VER__';
const WAVE={fw:110,fh:68,n:1,ax:48,ay:63,x:0,y:0,img:'wave'};   // Wave Dash energy wave (3 flickering frames)
const BOOM={fw:128,fh:131,n:15,ax:64,ay:128,x:0,y:0,img:'boom',art:1};   // explosion frames from Kyle's sheet (15 frames, half size)
const ART_SCALE=21/152;   // full-detail character art drawn at the in-game size Kyle liked (his 152px-tall art = 21 world px)
const GQ=2;   // the game canvas renders at 2x its old pixel density so full-detail art stays clean (pixel art still draws crisp)
const $=(s,r)=>(r||document).querySelector(s);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const fmt=n=>Math.round(n).toLocaleString('en-US');
// ---------------------------------------------------------------- sound (tiny WebAudio blips)
let AC=null,muted=false;try{muted=localStorage.getItem('podrundown-crawl-mute')==='1';}catch(e){}
// ---- 0.12.35 music: one original track (Night Shift, made for the game) + four dark-synth tracks from OpenGameArt (all CC0 / public domain),
//   streamed from OpenGameArt like the old loop. ⏭ cycles them; a track that won't load is skipped automatically.
const OGA='https://opengameart.org/sites/default/files/';
const TRACKS=[{name:'Night Shift',by:'made for Crypt Crawl',info:'gritty pulse + sax',src:['music/nightshift.ogg','music/nightshift.mp3']},
  {name:'Dark Night',by:'Alex McCulloch (Pro Sensory)',info:'dark synthwave rock',src:[OGA+'dark_night.mp3']},
  {name:'Nova',by:'SpringySpringo',info:'melancholy dark synthwave',src:[OGA+'nova.mp3']},
  {name:'Futility Belt',by:'iamoneabe',info:'long darksynth / synthpop',src:[OGA+'futilitybelt.mp3']},
  {name:'Dark Things',by:'iamoneabe',info:'short dark synth loop',src:[OGA+'dark_things_loop.mp3']},
  {name:'Zombie Main',by:'Augmentality (Brandon Morris), CC0',info:'eerie zombie-game menu music',src:[OGA+'zombie%20main%20music.ogg']},   /* 0.12.219 (Kyle): more creepy tracks, all CC0 from OpenGameArt */
  {name:'Insistent',by:'yd, CC0',info:'dark, quiet horror loop',src:[OGA+'Insistent.ogg']},
  {name:'Dark Cavern',by:'Paul Wortmann, CC0',info:'creepy ambient: moans, wind, creaks',src:[OGA+'dark_cavern_ambient_002.ogg']},
  {name:'Ambient Horror',by:'ShggothSlave, CC0',info:'long ambient horror piece',src:[OGA+'ambient_horror_song.mp3']}];
let BGM=null,musicMuted=false,musicVol=.45,trackI=0,trackFails=0;try{musicMuted=localStorage.getItem('podrundown-crawl-music-mute')==='1';const v=localStorage.getItem('podrundown-crawl-music-vol');if(v!=null)musicVol=+v;
  const ti=+localStorage.getItem('podrundown-crawl-music-track');if(ti>=0&&ti<TRACKS.length)trackI=ti;}catch(e){}
function trackSrc(i){const s=TRACKS[i].src;const a=new Audio();return s.find(x=>!x.endsWith('.ogg')||a.canPlayType('audio/ogg; codecs="vorbis"'))||s[s.length-1];}
function musicStart(){try{if(!BGM){BGM=new Audio();BGM.loop=true;BGM.preload='auto';
      BGM.addEventListener('error',()=>{if(++trackFails<TRACKS.length){const T=musicNext(true);if(typeof flash==='function'&&!root.hidden)flash('♫ couldn\'t load that one, now: '+T.name,1800);}});
      BGM.addEventListener('playing',()=>{trackFails=0;});BGM.src=trackSrc(trackI);}
  BGM.volume=musicVol;if(!musicMuted&&musicVol>0)BGM.play().catch(()=>{});else BGM.pause();}catch(e){}}
function musicNext(auto){trackI=(trackI+1)%TRACKS.length;if(!auto)trackFails=0;try{localStorage.setItem('podrundown-crawl-music-track',trackI);}catch(_){}
  try{if(BGM){BGM.pause();BGM.src=trackSrc(trackI);BGM.load();}}catch(e){}musicStart();try{const tb=document.querySelector('#cc [data-a="track"]');if(tb)tb.title='Next track (now: '+TRACKS[trackI].name+')';}catch(_){}return TRACKS[trackI];}
function musicStop(){try{if(BGM)BGM.pause();}catch(e){}}
/* 0.12.310 recorded clips (Tee_Grizzle): decoded once, played through the same AudioContext as the synth sounds */
const SAMP={teeg1:{src:'crawl_teeg1',off:.34},teeg2:{src:'crawl_teeg2',off:0},teeg3:{src:'crawl_teeg3',off:0},jp1:{src:'crawl_jp1',off:0},kidhowl:{src:'crawl_kidhowl',off:0},leiftag:{src:'crawl_leiftag',off:0}};   /* 0.12.394: the boys' howl, Leif's "tag!" */   /* 0.12.380: Tee's Pistol_Play line, JP's No_Scope line */
function sampLoad(k){const S=SAMP[k];if(!S||S.buf||S.loading||!AC)return;S.loading=1;const ext=(new Audio()).canPlayType('audio/ogg; codecs="vorbis"')?'.ogg':'.mp3';
  fetch(S.src+ext+'?v=__VER__').then(r=>r.arrayBuffer()).then(b=>AC.decodeAudioData(b,d=>{S.buf=d;},()=>{})).catch(()=>{});}
function sampPlay(k,off,vol,soft){const S=SAMP[k];if(!S)return;if(!S.buf){sampLoad(k);return;}const src=AC.createBufferSource(),g=AC.createGain();src.buffer=S.buf;g.gain.value=vol==null?.55:vol;
  if(soft){const lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.value=soft;lp.Q.value=.5;src.playbackRate.value=.94+Math.random()*.1;src.connect(lp);lp.connect(g);}else src.connect(g);g.connect(AC.destination);src.start(0,off==null?S.off:off);}   /* 0.12.329 (Kyle: a bit less annoying): Tee's clips play softer, muffled (low-pass) and with a little pitch wobble */
function sfx(k,o){if(muted)return;try{AC=AC||new (window.AudioContext||window.webkitAudioContext)();const t=AC.currentTime;
  if(!sampLoad.pre){sampLoad.pre=1;sampLoad('teeg1');sampLoad('teeg2');sampLoad('teeg3');sampLoad('jp1');sampLoad('kidhowl');sampLoad('leiftag');}
  if(k==='teegshot'){const n=performance.now();if(n-(sfx.tgT||0)<380)return;sfx.tgT=n;sampPlay('teeg1',null,.28,2400);return;}if(k==='teegsweep'){sampPlay('teeg2',o&&o.first?0:.5,.32,2800);return;}if(k==='teegpp'){sampPlay('teeg3',0,.3,2600);return;}if(k==='jpns'){sampPlay('jp1',0,.4);return;}if(k==='kidhowl'){sampPlay('kidhowl',0,.45);return;}if(k==='leiftag'){const n=performance.now();if(n-(sfx.ltT||0)<350)return;sfx.ltT=n;sampPlay('leiftag',0,.42);return;}   /* 0.12.382 (Kyle): his whole line, clear (no muffling or speed wobble) */   /* softened and muffled like Tee's other clips */
  const tone=(f,d,type,v,f2)=>{const o=AC.createOscillator(),g=AC.createGain();o.type=type||'square';o.frequency.setValueAtTime(f,t);if(f2)o.frequency.exponentialRampToValueAtTime(f2,t+d);
    g.gain.setValueAtTime(v||.05,t);g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g);g.connect(AC.destination);o.start(t);o.stop(t+d);};
  if(k==='fusebeep'){const kk=(o&&o.k)||0;tone(520+500*kk,.07,'square',.03,380+400*kk);tone(90,.08,'sine',.07,60);return;}   /* 0.12.385 swelling Bloater: a wet throb that rises in pitch */
  if(k==='bloatswell'){const o2=AC.createOscillator(),g2=AC.createGain(),lf=AC.createOscillator(),lg=AC.createGain();o2.type='sawtooth';o2.frequency.setValueAtTime(70,t);o2.frequency.linearRampToValueAtTime(110,t+.7);lf.frequency.value=18;lg.gain.value=14;lf.connect(lg);lg.connect(o2.frequency);
    const fl=AC.createBiquadFilter();fl.type='lowpass';fl.frequency.value=500;g2.gain.setValueAtTime(.0001,t);g2.gain.exponentialRampToValueAtTime(.12,t+.1);g2.gain.exponentialRampToValueAtTime(.0001,t+.8);o2.connect(fl);fl.connect(g2);g2.connect(AC.destination);o2.start(t);lf.start(t);o2.stop(t+.82);lf.stop(t+.82);return;}   /* a deep, gurgling groan */
  if(k==='gutpop'){const d=.16,n=Math.floor(AC.sampleRate*d),b=AC.createBuffer(1,n,AC.sampleRate),c=b.getChannelData(0);let v=0;for(let i=0;i<n;i++){v=v*.55+(Math.random()*2-1)*.45;c[i]=v*Math.pow(1-i/n,3);}
    const s=AC.createBufferSource(),f=AC.createBiquadFilter(),g=AC.createGain();s.buffer=b;f.type='lowpass';f.frequency.value=900+Math.random()*500;g.gain.value=.45;s.connect(f);f.connect(g);g.connect(AC.destination);s.start(t);tone(260+Math.random()*120,.07,'sine',.06,90);return;}   /* 0.12.384 a gib popping */
  if(k==='gutthrow'||k==='gutsplat'){   /* 0.12.383 Bloater: a wet heave when he throws; a heavy, sloppy SPLAT when it lands */
    const sp=k==='gutsplat',d=sp?.42:.22,n=Math.floor(AC.sampleRate*d),b=AC.createBuffer(1,n,AC.sampleRate),c=b.getChannelData(0);let v=0;for(let i=0;i<n;i++){v=v*.6+(Math.random()*2-1)*.4;c[i]=v*Math.pow(1-i/n,sp?3:2);}
    const s=AC.createBufferSource(),f=AC.createBiquadFilter(),g=AC.createGain();s.buffer=b;f.type='lowpass';f.frequency.setValueAtTime(sp?1400:900,t);f.frequency.exponentialRampToValueAtTime(sp?260:300,t+d);g.gain.value=sp?.9:.45;s.connect(f);f.connect(g);g.connect(AC.destination);s.start(t);
    tone(sp?120:200,sp?.22:.14,'sine',sp?.18:.06,sp?42:90);
    if(sp)for(let i=0;i<4;i++){const t0=t+.04+Math.random()*.22,o=AC.createOscillator(),gg=AC.createGain();o.type='sine';o.frequency.setValueAtTime(380+Math.random()*420,t0);o.frequency.exponentialRampToValueAtTime(120,t0+.05);gg.gain.setValueAtTime(.05,t0);gg.gain.exponentialRampToValueAtTime(.0001,t0+.06);o.connect(gg);gg.connect(AC.destination);o.start(t0);o.stop(t0+.07);}
    return;}
  if(k==='hit')tone(180,.06,'square',.025,90);if(k==='crit')tone(520,.1,'square',.04,180);
  if(k==='howl'){[[0,330,660,.9],[.25,300,620,1.1]].forEach(([d,f0,f1,L])=>{const o=AC.createOscillator(),g=AC.createGain(),v=AC.createOscillator(),vg=AC.createGain();o.type='sawtooth';v.frequency.value=6;vg.gain.value=12;v.connect(vg);vg.connect(o.frequency);o.frequency.setValueAtTime(f0,t+d);o.frequency.linearRampToValueAtTime(f1,t+d+L*.35);o.frequency.linearRampToValueAtTime(f0*.9,t+d+L);g.gain.setValueAtTime(.0001,t+d);g.gain.linearRampToValueAtTime(.05,t+d+.08);g.gain.exponentialRampToValueAtTime(.0001,t+d+L);const lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.value=1600;o.connect(lp);lp.connect(g);g.connect(AC.destination);o.start(t+d);v.start(t+d);o.stop(t+d+L+.05);v.stop(t+d+L+.05);});return;}   /* 0.12.331 placeholder wolf howl (Kyle will send the boys' real howl) */
  if(k==='flare'){const o=AC.createOscillator(),g=AC.createGain();o.type='square';o.frequency.setValueAtTime(220,t);o.frequency.exponentialRampToValueAtTime(1400,t+.5);g.gain.setValueAtTime(.03,t);g.gain.exponentialRampToValueAtTime(.0001,t+.6);o.connect(g);g.connect(AC.destination);o.start(t);o.stop(t+.62);return;}
  if(k==='level'){[523,659,784,1046].forEach((f,i)=>{const o=AC.createOscillator(),g=AC.createGain();o.type='square';o.frequency.value=f;g.gain.setValueAtTime(.04,t+i*.07);g.gain.exponentialRampToValueAtTime(.0001,t+i*.07+.12);o.connect(g);g.connect(AC.destination);o.start(t+i*.07);o.stop(t+i*.07+.13);});}
  if(k==='glass'){   /* 0.12.228 bottle smash: a sharp crack, bright tinkling shards, then (if it drew any) a few low zombie grunts */
    const n=Math.floor(AC.sampleRate*.3),b=AC.createBuffer(1,n,AC.sampleRate),c=b.getChannelData(0);for(let i=0;i<n;i++)c[i]=(Math.random()*2-1)*Math.pow(1-i/n,6);
    const s=AC.createBufferSource(),f=AC.createBiquadFilter(),g=AC.createGain();s.buffer=b;f.type='highpass';f.frequency.value=3000;g.gain.value=.35;s.connect(f);f.connect(g);g.connect(AC.destination);s.start(t);
    for(let i=0;i<9;i++){const dt=.02+Math.random()*.35,o=AC.createOscillator(),gg=AC.createGain();o.type='sine';o.frequency.value=3500+Math.random()*4500;gg.gain.setValueAtTime(.03+Math.random()*.03,t+dt);gg.gain.exponentialRampToValueAtTime(.0001,t+dt+.06+Math.random()*.06);o.connect(gg);gg.connect(AC.destination);o.start(t+dt);o.stop(t+dt+.15);}
    const z=Math.min(3,(o&&o.n)||0);for(let i=0;i<z;i++){const t0=t+.55+i*(.35+Math.random()*.25),d=.45+Math.random()*.3,os=AC.createOscillator(),fl=AC.createBiquadFilter(),gn=AC.createGain(),lfo=AC.createOscillator(),lg=AC.createGain();
      os.type='sawtooth';const f0=70+Math.random()*40;os.frequency.setValueAtTime(f0,t0);os.frequency.linearRampToValueAtTime(f0*1.25,t0+d*.4);os.frequency.linearRampToValueAtTime(f0*.8,t0+d);lfo.frequency.value=22+Math.random()*10;lg.gain.value=12;lfo.connect(lg);lg.connect(os.frequency);
      fl.type='lowpass';fl.frequency.value=700;gn.gain.setValueAtTime(0,t0);gn.gain.linearRampToValueAtTime(.12,t0+.06);gn.gain.exponentialRampToValueAtTime(.001,t0+d);os.connect(fl);fl.connect(gn);gn.connect(AC.destination);os.start(t0);lfo.start(t0);os.stop(t0+d);lfo.stop(t0+d);}
    return;}
  if(k==='clunk'){tone(70,.22,'sine',.5,40);tone(150,.1,'square',.08,90);   /* 0.12.222 (Kyle) Toolbox_Toss: a heavy metal box clunking into something, tools rattling inside */
    const n=Math.floor(AC.sampleRate*.35),b=AC.createBuffer(1,n,AC.sampleRate),c=b.getChannelData(0);for(let i=0;i<n;i++){const q=i/n;c[i]=(Math.random()*2-1)*Math.pow(1-q,4)*.9+((i%Math.floor(AC.sampleRate/1700))<3?.25*Math.pow(1-q,2):0);}
    const s=AC.createBufferSource(),f=AC.createBiquadFilter(),g=AC.createGain();s.buffer=b;f.type='bandpass';f.frequency.value=2300;f.Q.value=3;g.gain.value=.45;s.connect(f);f.connect(g);g.connect(AC.destination);s.start(t);
    for(const [dt,fq] of [[.07,3100],[.13,2600],[.2,3400]]){const o=AC.createOscillator(),gg=AC.createGain();o.type='triangle';o.frequency.value=fq;gg.gain.setValueAtTime(.04,t+dt);gg.gain.exponentialRampToValueAtTime(.0001,t+dt+.05);o.connect(gg);gg.connect(AC.destination);o.start(t+dt);o.stop(t+dt+.06);}return;}
  if(k==='riflesoft'){const d=.6,n=Math.floor(AC.sampleRate*d),buf=AC.createBuffer(1,n,AC.sampleRate),ch=buf.getChannelData(0);   /* 0.12.381 (Kyle): No_Scope's crack, muffled and quieter so JP's line stays clear on top */
    for(let i=0;i<n;i++){const q=i/n;ch[i]=(Math.random()*2-1)*(Math.pow(1-q,5)+.18*Math.pow(1-q,1.8)*(q>.12?1:0));}
    const s=AC.createBufferSource(),f=AC.createBiquadFilter(),g=AC.createGain();s.buffer=buf;f.type='lowpass';f.frequency.value=1300;f.Q.value=.6;g.gain.value=.3;s.connect(f);f.connect(g);g.connect(AC.destination);s.start(t);
    tone(95,.25,'sine',.22,36);return;}
  if(k==='rifle'){const d=.7,n=Math.floor(AC.sampleRate*d),buf=AC.createBuffer(1,n,AC.sampleRate),ch=buf.getChannelData(0);   /* 0.12.201 (Kyle) JP's Kar98: a loud sharp crack with a rolling echo */
    for(let i=0;i<n;i++){const q=i/n;ch[i]=(Math.random()*2-1)*(Math.pow(1-q,5)+.22*Math.pow(1-q,1.6)*(q>.12?1:0));}
    const s=AC.createBufferSource(),f=AC.createBiquadFilter(),g=AC.createGain();s.buffer=buf;f.type='lowpass';f.frequency.value=3200;g.gain.value=.85;s.connect(f);f.connect(g);g.connect(AC.destination);s.start(t);
    tone(110,.3,'sine',.45,38);tone(2200,.04,'square',.06,900);return;}
  if(k==='nail'){const d=.09,n=Math.floor(AC.sampleRate*d),buf=AC.createBuffer(1,n,AC.sampleRate),ch=buf.getChannelData(0);   /* 0.12.268 (Kyle): Edward's nail gun: a soft pneumatic thup, not a gunshot */
    for(let i=0;i<n;i++)ch[i]=(Math.random()*2-1)*Math.pow(1-i/n,5);
    const s=AC.createBufferSource(),f=AC.createBiquadFilter(),g=AC.createGain();s.buffer=buf;f.type='lowpass';f.frequency.value=900;g.gain.value=.07;
    s.connect(f);f.connect(g);g.connect(AC.destination);s.start(t);tone(210,.05,'sine',.035,120);}
  if(k==='gun'||k==='biggun'){const big=k==='biggun',d=big?.45:.16,n=Math.floor(AC.sampleRate*d),buf=AC.createBuffer(1,n,AC.sampleRate),ch=buf.getChannelData(0);
    for(let i=0;i<n;i++)ch[i]=(Math.random()*2-1)*Math.pow(1-i/n,big?2.2:3.5);
    const s=AC.createBufferSource(),f=AC.createBiquadFilter(),g=AC.createGain();s.buffer=buf;f.type='lowpass';f.frequency.value=big?2400:1800;g.gain.value=big?.55:.16;
    s.connect(f);f.connect(g);g.connect(AC.destination);s.start(t);tone(big?90:140,big?.35:.12,'sine',big?.35:.09,big?32:60);if(big)tone(1400,.06,'square',.03,500);}
  if(k==='shriek'){const d=1.25,g=AC.createGain(),f=AC.createBiquadFilter();f.type='bandpass';f.frequency.value=1400;f.Q.value=1.2;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.265,t+.08);g.gain.setValueAtTime(.265,t+d*.7);   /* 0.12.201 (Kyle): ~17% quieter */g.gain.exponentialRampToValueAtTime(.001,t+d);   /* 0.12.175 the Screamer's shriek: two detuned saws wailing up and cracking, with a raspy noise layer */
    for(const det of [0,23]){const o=AC.createOscillator(),lfo=AC.createOscillator(),lg=AC.createGain();o.type='sawtooth';o.frequency.setValueAtTime(700+det,t);o.frequency.linearRampToValueAtTime(1500+det,t+.25);o.frequency.linearRampToValueAtTime(1250+det,t+.8);o.frequency.linearRampToValueAtTime(820+det,t+d);
      lfo.frequency.value=9+det/10;lg.gain.value=60;lfo.connect(lg);lg.connect(o.frequency);o.connect(f);lfo.start(t);o.start(t);o.stop(t+d);lfo.stop(t+d);}
    {const n=Math.floor(AC.sampleRate*d),b=AC.createBuffer(1,n,AC.sampleRate),c=b.getChannelData(0);for(let i=0;i<n;i++)c[i]=(Math.random()*2-1)*.35;const s=AC.createBufferSource();s.buffer=b;s.connect(f);s.start(t);}
    f.connect(g);g.connect(AC.destination);}
  if(k==='shotgun'){const d=.6,n=Math.floor(AC.sampleRate*d),buf=AC.createBuffer(1,n,AC.sampleRate),ch=buf.getChannelData(0);for(let i=0;i<n;i++)ch[i]=(Math.random()*2-1)*Math.pow(1-i/n,3);   /* 0.12.158 one big loud shotgun blast */
    const s=AC.createBufferSource(),f=AC.createBiquadFilter(),g=AC.createGain();s.buffer=buf;f.type='lowpass';f.frequency.setValueAtTime(5000,t);f.frequency.exponentialRampToValueAtTime(400,t+d);g.gain.value=.9;
    s.connect(f);f.connect(g);g.connect(AC.destination);s.start(t);tone(70,.45,'sine',.55,28);tone(2200,.04,'square',.06,600);}
  if(k==='boom'){const d=1.1,n=Math.floor(AC.sampleRate*d),buf=AC.createBuffer(1,n,AC.sampleRate),ch=buf.getChannelData(0);for(let i=0;i<n;i++)ch[i]=(Math.random()*2-1)*Math.pow(1-i/n,1.6);
    const s=AC.createBufferSource(),f=AC.createBiquadFilter(),g=AC.createGain();s.buffer=buf;f.type='lowpass';f.frequency.setValueAtTime(1600,t);f.frequency.exponentialRampToValueAtTime(220,t+d);g.gain.value=.7;
    s.connect(f);f.connect(g);g.connect(AC.destination);s.start(t);tone(60,.8,'sine',.5,24);}
  if(k==='lazer'){const d=(o&&o.d)||1,out=AC.createGain(),lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.value=2200;out.gain.setValueAtTime(.0001,t);out.gain.exponentialRampToValueAtTime(.09,t+.04);out.gain.setValueAtTime(.09,t+d-.08);out.gain.exponentialRampToValueAtTime(.0001,t+d);
    const am=AC.createGain();am.gain.value=.55;const lfo=AC.createOscillator();lfo.frequency.value=48;const lg=AC.createGain();lg.gain.value=.45;lfo.connect(lg);lg.connect(am.gain);   /* the bzzzz: two buzzy tones chopped 48 times a second */
    for(const [f,ty,v] of [[92,'sawtooth',.9],[184,'square',.35],[1240,'sine',.12]]){const os=AC.createOscillator(),g2=AC.createGain();os.type=ty;os.frequency.setValueAtTime(f,t);if(f>1000)os.frequency.exponentialRampToValueAtTime(820,t+d);g2.gain.value=v;os.connect(g2);g2.connect(am);os.start(t);os.stop(t+d);}
    am.connect(lp);lp.connect(out);out.connect(AC.destination);lfo.start(t);lfo.stop(t+d);}
  if(k==='flame'){if(t-(sfx.lastFlame||0)<.3)return;sfx.lastFlame=t;const d=.55,n=Math.floor(AC.sampleRate*d),buf=AC.createBuffer(1,n,AC.sampleRate),ch=buf.getChannelData(0);let b=0;
    for(let i=0;i<n;i++){b=b*.82+(Math.random()*2-1)*.18;ch[i]=(b*2.2+(Math.random()*2-1)*.35)*Math.min(1,i/(AC.sampleRate*.04))*Math.pow(1-i/n,.7)*(.8+.2*Math.sin(i/AC.sampleRate*60));}   /* roaring, flickering rumble */
    const src=AC.createBufferSource(),bp=AC.createBiquadFilter(),lp2=AC.createBiquadFilter(),g2=AC.createGain();src.buffer=buf;bp.type='bandpass';bp.frequency.setValueAtTime(700,t);bp.frequency.linearRampToValueAtTime(1100,t+d);bp.Q.value=.6;lp2.type='lowpass';lp2.frequency.value=2600;g2.gain.value=.32;
    src.connect(bp);bp.connect(lp2);lp2.connect(g2);g2.connect(AC.destination);src.start(t);tone(70,.45,'sine',.12,45);}
  if(k==='alarm'){const V=(o&&o.vol)||1,v=(o&&o.v)||0,g0=AC.createGain(),f=AC.createBiquadFilter();f.type='lowpass';f.frequency.value=2600;g0.gain.value=.075*V;f.connect(g0);g0.connect(AC.destination);   /* 0.12.203 alarm variants: wee-woo, whoop, chirp */
    const os=AC.createOscillator();os.type=v===1?'sawtooth':'square';
    if(v===0){os.frequency.setValueAtTime(980,t);os.frequency.setValueAtTime(720,t+.42);}
    else if(v===1){os.frequency.setValueAtTime(520,t);os.frequency.exponentialRampToValueAtTime(1350,t+.85);}
    else{for(let i=0;i<6;i++)os.frequency.setValueAtTime(i%2?1500:1150,t+i*.12);}
    const ga=AC.createGain();ga.gain.setValueAtTime(0,t);ga.gain.linearRampToValueAtTime(1,t+.03);ga.gain.setValueAtTime(1,t+(v===2?.7:.8));ga.gain.linearRampToValueAtTime(0,t+(v===2?.74:.86));
    os.connect(ga);ga.connect(f);os.start(t);os.stop(t+.9);}
  if(k==='bell'){const d=1.1,gn=AC.createGain(),BV=(o&&o.vol)||1;gn.gain.setValueAtTime(0,t);for(let i=0;i<d*28;i++){const tt=t+i/28;gn.gain.setValueAtTime(.05*BV,tt);gn.gain.exponentialRampToValueAtTime(.004,tt+.03);}gn.gain.setValueAtTime(0,t+d);gn.connect(AC.destination);
    for(const f of [2330,3110,4480]){const o=AC.createOscillator();o.type=f>4000?'sine':'square';o.frequency.value=f;const g2=AC.createGain();g2.gain.value=f>4000?.6:.35;o.connect(g2);g2.connect(gn);o.start(t);o.stop(t+d);}}
  if(k==='dash'){tone(240,.25,'sawtooth',.05,900);tone(1200,.2,'sine',.04,300);}
  if(k==='shout'){tone(160,.5,'sawtooth',.07,120);tone(240,.45,'square',.04,200);}
  if(k==='bow'){tone(320,.09,'triangle',.06,120);tone(900,.05,'sine',.03,400);}
  if(k==='heal'){[660,880,1320].forEach((f,i)=>{const o=AC.createOscillator(),gn=AC.createGain();o.type='sine';o.frequency.value=f;gn.gain.setValueAtTime(.035,t+i*.06);gn.gain.exponentialRampToValueAtTime(.0001,t+i*.06+.25);o.connect(gn);gn.connect(AC.destination);o.start(t+i*.06);o.stop(t+i*.06+.26);});}
  if(k==='thorns'){tone(110,.35,'square',.06,50);tone(70,.4,'sawtooth',.05,40);}
  if(k==='wind'){const d=1.6,n=Math.floor(AC.sampleRate*d),buf=AC.createBuffer(1,n,AC.sampleRate),ch=buf.getChannelData(0);for(let i=0;i<n;i++)ch[i]=(Math.random()*2-1)*Math.sin(Math.PI*i/n);
    const s2=AC.createBufferSource(),f2=AC.createBiquadFilter(),g2=AC.createGain();s2.buffer=buf;f2.type='bandpass';f2.frequency.setValueAtTime(500,t);f2.frequency.linearRampToValueAtTime(1400,t+d);g2.gain.value=.25;s2.connect(f2);f2.connect(g2);g2.connect(AC.destination);s2.start(t);}
  if(k==='camp'){tone(1800,.04,'square',.03,1200);setTimeout(()=>tone(220,.6,'triangle',.05,120),180);}
  if(k==='whoosh'){tone(300,.18,'sawtooth',.03,90);}
  if(k==='boss')tone(70,1.2,'sawtooth',.08,40);if(k==='clear')tone(392,.5,'triangle',.07,784);if(k==='die')tone(220,.6,'sawtooth',.06,55);
}catch(e){}}
// ---------------------------------------------------------------- pixel font (3x5) for numbers + a few letters
const FONT={'0':'111101101101111','1':'010110010010111','2':'111001111100111','3':'111001111001111','4':'101101111001001','5':'111100111001111','6':'111100111101111','7':'111001010010010','8':'111101111101111','9':'111101111001111','+':'000010111010000',
  'm':'000111111101101','i':'010000010010010','s':'011100010001110','d':'001001111101111','o':'000111101101111','g':'111101111001110','e':'111101111100111','L':'100100100100111','V':'101101101101010',' ':'000000000000000','x':'000101010101000'};
function ptext(ctx,s,x,y,col,sc){sc=sc||1;
  if([...s].some(ch=>!FONT[ch])){ctx.save();ctx.font=`${8*sc}px "Press Start 2P",monospace`;ctx.textAlign='center';ctx.textBaseline='top';ctx.fillStyle='#0c0810';ctx.fillText(s.toUpperCase(),Math.round(x)+1,Math.round(y)+1);ctx.fillStyle=col;ctx.fillText(s.toUpperCase(),Math.round(x),Math.round(y));ctx.restore();return;}const w=s.length*4*sc;let cx=Math.round(x-w/2);y=Math.round(y);
  for(const ch of s){const g=FONT[ch];if(g){ctx.fillStyle='#0c0810';for(let i=0;i<15;i++)if(g[i]==='1')ctx.fillRect(cx+(i%3)*sc+sc,y+Math.floor(i/3)*sc+sc,sc,sc);
    ctx.fillStyle=col;for(let i=0;i<15;i++)if(g[i]==='1')ctx.fillRect(cx+(i%3)*sc,y+Math.floor(i/3)*sc,sc,sc);}cx+=4*sc;}}
// ---------------------------------------------------------------- renderer
function spr(ctx,name,fr,x,y,flip,alpha,flash){const a=SP[name];if(!a)return;const [sx,sy,w,h,n]=a;fr=Math.max(0,Math.min(n-1,fr|0));const dw=w/RES,dh=h/RES;
  const X=Math.round(x*RES)/RES,Y=Math.round(y*RES)/RES;
  ctx.save();if(alpha!=null)ctx.globalAlpha=alpha;
  if(flip){ctx.translate(X+dw,Y);ctx.scale(-1,1);ctx.drawImage(IMG,sx+fr*w,sy,w,h,0,0,dw,dh);}
  else ctx.drawImage(IMG,sx+fr*w,sy,w,h,X,Y,dw,dh);
  if(flash>0){ctx.globalCompositeOperation='lighter';ctx.globalAlpha=Math.min(1,flash*6)*.7;if(flip)ctx.drawImage(IMG,sx+fr*w,sy,w,h,0,0,dw,dh);else ctx.drawImage(IMG,sx+fr*w,sy,w,h,X,Y,dw,dh);}
  ctx.restore();}
const FW=a=>a[2]/RES,FH=a=>a[3]/RES;
// new hand-picked unit sprites: one image per frame strip, drawn with the feet on the ground line
/* 0.12.394 (Kyle): a target 2+ lanes above (or flying, or a hero shooting up) -> the aim-up shot; 2+ lanes below (or down off a tower) -> aim-down */
function rTilt(h,U){const t=h.aimTilt||0;return (t>0&&U.rangedUp)||(t<0&&U.rangedDown)||U.ranged;}
function unitFrame(e,U){const A=e.animT>0&&U.atk?U.atk:U.walk;let fr;
  if(e.scrT>0&&U.scream){const T=e.E.scream.T,k=1-e.scrT/T,n=U.scream.n;return [U.scream,k<.3?Math.floor(k/.3*2):2+Math.floor(k*14)%(n-2)];}   /* 0.12.175 Screamer: rears back, then shrieks (last frames looping) */
  if(e.leapA&&U.jump){const v=e.leapA.t/e.leapA.dur;const J=v<.5?U.jump:U.fall;return [Object.assign({},J,{ay:U.walk.ay-Math.round(Math.sin(Math.PI*Math.min(1,v))*14)}),Math.min(J.n-1,Math.floor((v<.5?v*2:(v-.5)*2)*J.n))];}   // leap arc
  if(A===U.atk){const dur=e.E.animAtk||.3;fr=Math.min(A.n-1,Math.floor((1-e.animT/dur)*A.n));return [A,fr];}
  if(U.idle&&e.moving===false)return [U.idle,Math.floor(e.walkT*6)%U.idle.n];
  return [A,Math.floor(e.walkT*(e.E.fps||7))%A.n];}
let GHOST_A=1;   /* 0.12.107: <1 while drawing the Shadow_Clone */
/* 0.12.301 (Kyle): real fire. Standing flames reuse the burst frames of the flamethrower sheet (crawl_flame.png) turned upright,
   each one on its own flicker phase, with a hot additive glow, rising embers and the pack's smoke drifting off the top. */
function fireTongue(ctx,x,y,h,ph,flip,alpha){const IM=XIMG.flame;if(!IM||!IM.complete||!IM.naturalWidth)return;const fi=5+Math.floor(ph*14)%5,s=h/250;
  ctx.save();ctx.translate(Math.round(x),Math.round(y));ctx.rotate(-Math.PI/2);ctx.scale(s,s*(flip?-1:1)*(.85+.15*Math.sin(ph*9)));ctx.globalAlpha=alpha==null?.95:alpha;
  ctx.drawImage(IM,fi*290,0,290,200,-30,-108,290,200);ctx.globalCompositeOperation='lighter';ctx.globalAlpha=(alpha==null?.95:alpha)*.35;ctx.drawImage(IM,fi*290,0,290,200,-30,-108,290,200);ctx.restore();}
function embers(ctx,t,x,y,w,n,seed,rise){for(let k=0;k<n;k++){const q=((t*.7+k*.173+(seed||0)*.31)%1),ex=x+Math.sin(k*12.9898+(seed||0))*w+Math.sin(t*3+k)*2,ey=y-q*(rise||34);ctx.globalAlpha=1-q;ctx.fillStyle=q<.3?'#fff2a0':q<.65?'#ffb030':'#ff4a1a';ctx.fillRect(Math.round(ex),Math.round(ey),1,1);}ctx.globalAlpha=1;}
function fireGlow(ctx,x,y,r,a){ctx.save();ctx.globalCompositeOperation='lighter';const gr=ctx.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,`rgba(255,150,40,${a})`);gr.addColorStop(1,'rgba(255,80,10,0)');ctx.fillStyle=gr;ctx.fillRect(x-r,y-r,r*2,r*2);ctx.restore();}
function drawUnit(ctx,A,fr,x,gy,sc,alpha,flash,rot,flip){const IM=A.img?XIMG[A.img]:UIMG;if(!IM||!IM.complete)return;ctx.save();ctx.translate(Math.round(x*RES)/RES,Math.round(gy*RES)/RES);if(rot)ctx.rotate(rot);{const sx=sc*(A.sx||1);ctx.scale(flip?-sx:sx,sc);}if(alpha!=null)ctx.globalAlpha=alpha*GHOST_A;else if(GHOST_A<1)ctx.globalAlpha*=GHOST_A;
  if(A.art){ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';}const sx=A.x+fr*A.fw;ctx.drawImage(IM,sx,A.y,A.fw,A.fh,-A.ax,-A.ay-1,A.fw,A.fh);
  if(flash>0){ctx.globalCompositeOperation='lighter';ctx.globalAlpha=Math.min(1,flash*6)*.7;ctx.drawImage(IM,sx,A.y,A.fw,A.fh,-A.ax,-A.ay-1,A.fw,A.fh);}ctx.restore();}
/* 0.12.117 (Kyle): downtown street lamps are lit live. Each lamp has a kind and its own timing (seed), so along the
   two-screen loop some hum steadily, some stutter, one sputters on and off, one is dying, one is dead, and one hangs by its wire.
   The faulty ones throw sparks now and then: they fall, most burn out in the air, a few land and flicker out on the pavement. */
const LH=(n)=>{const v=Math.sin(n*12.9898+78.233)*43758.5453;return v-Math.floor(v);};
let LAMP_HALO=null;
function lampHalo(){if(LAMP_HALO)return LAMP_HALO;const c=document.createElement('canvas');c.width=60;c.height=80;const x=c.getContext('2d'),im=x.createImageData(60,80);
  for(let yy=0;yy<80;yy++)for(let xx=0;xx<60;xx++){const dx=xx-30,dy=yy-10,r=Math.hypot(dx,dy*(dy>0?.42:1.6)),a=Math.max(0,62-r*3.1);if(a>0){const i=(yy*60+xx)*4;im.data[i]=255;im.data[i+1]=186;im.data[i+2]=90;im.data[i+3]=a;}}
  x.putImageData(im,0,0);return LAMP_HALO=c;}
function lampLevel(k,t,sd){
  if(k==='dead'||k==='broken')return 0;
  if(k==='ok')return .94+.06*Math.sin(t*47+sd*9);
  if(k==='flicker'){const burst=((t*.21+sd)%1)<.3;if(!burst)return 1;const n=LH(Math.floor(t*17)+sd*977);return n<.4?0:n<.55?.35:1;}
  if(k==='sputter'){const P=7+sd*4,ph=((t+sd*20)%P)/P;if(ph>.42)return 0;const n=LH(Math.floor(t*11)+sd*311);return (ph<.04||n<.12)?(n<.5?0:.5):1;}
  if(k==='dying'){const n=LH(Math.floor(t*6)+sd*53);const surge=((t*.13+sd)%1)<.05;return surge?(LH(Math.floor(t*20))<.5?1:.2):(n<.15?.05:.32+.06*Math.sin(t*30));}
  return 1;}
function drawLamps(ctx,L,x0,y0,W,t){const s=L.w/L.r[2],gy=y0+L.ground*s;const H=lampHalo();
  for(const [ax,ay,k,sd] of L.lamps){const hx=x0+ax*s,hy=y0+ay*s;if(hx<-40||hx>W+40)continue;
    // spark events: a lamp shorts out every few seconds (not every period, so it never feels metronomic)
    let flash=0;const spk=k==='flicker'||k==='broken'||k==='sputter'||k==='dying';
    if(spk){const P=(k==='broken'?2.2:3.5)+sd*4,ofs=sd*7,e=Math.floor((t+ofs)/P),dt=t+ofs-e*P;
      if(LH(e*7.1+sd*13)<(k==='broken'?.75:.5)&&dt<2){if(dt<.1)flash=1-dt/.1;
        const N=4+Math.floor(LH(e+sd)*7),G=150*s/.75;
        for(let i=0;i<N;i++){const h1=LH(e*31+i*7+sd*100),h2=LH(e*17+i*3+sd*50),h3=LH(e*13+i*11+sd*70);
          const vx=(h1-.5)*40*s,vy=(-4-h2*22)*s,life=.12+h3*.9;
          const tl=(-vy+Math.sqrt(vy*vy+2*G*(gy-hy)))/G;   // when it would reach the pavement
          if(dt<Math.min(life,tl)){const px=hx+vx*dt,py=hy+vy*dt+.5*G*dt*dt,age=dt/Math.min(life,tl);
            ctx.globalAlpha=1-age*.5;ctx.fillStyle=age<.25?'#fffbe0':age<.6?'#ffd040':'#ff8a20';ctx.fillRect(px,py,1,1);
            ctx.globalAlpha=.4*(1-age);ctx.fillRect(px-vx*.02,py-(vy+G*dt)*.02,1,1);}
          else if(tl<=life&&dt<tl+.55){const px=hx+vx*tl,q=(dt-tl)/.55;   // landed: sputters on the ground, then goes out
            if(LH(Math.floor(dt*24)+i*5+e)>q*.9){ctx.globalAlpha=1-q;ctx.fillStyle=q<.3?'#ffd040':'#ff6a20';ctx.fillRect(px,gy-1,1,1);}}}
        ctx.globalAlpha=1;}}
    if(k==='broken'){if(flash>0){ctx.globalAlpha=flash*.8;ctx.fillStyle='#d8f0ff';ctx.fillRect(hx-1,hy-2,2,2);ctx.globalAlpha=flash*.35;ctx.drawImage(H,hx-12*s,hy-8*s,24*s,30*s);ctx.globalAlpha=1;}continue;}
    const b=Math.min(1,lampLevel(k,t,sd)+flash);if(b<=.02)continue;
    ctx.globalAlpha=b;ctx.drawImage(H,hx-29.5*s,hy-11*s,60*s,80*s);
    ctx.fillStyle='#ffd682';ctx.fillRect(hx-2.5*s,hy-1*s,6*s,2*s);ctx.fillStyle='#fff0c8';ctx.fillRect(hx-.5*s,hy+.5*s,2*s,1*s);ctx.globalAlpha=1;}}
function drawBG(ctx,g,W,oy){
  // layered parallax backdrops (Ansimuz packs): each layer scrolls at its own speed, the walking path at full speed
  const b=BGA[g.st.biome.id]||BGA.grave;const d=g.dist+(g.bgD||0)+(g.demo?g.t*8:0);   /* 0.12.387: g.bgD = where the street starts this stage */
  // tall night sky above the (smaller) backdrop art: a gradient up to darker, with a few stars
  {const gr=ctx.createLinearGradient(0,-oy,0,(b.artTop||0)-oy+20);gr.addColorStop(0,b.top||b.fill);gr.addColorStop(1,b.fill);ctx.fillStyle=gr;ctx.fillRect(0,0,W,CFG.H);
   ctx.fillStyle='rgba(255,255,255,.55)';for(let i=0;i<40;i++){const sx=((i*97+13)%W),sy=((i*53)%Math.max(8,(b.artTop||60)-6))-oy;if(sy>0&&(i+Math.floor(g.t*1.5))%7)ctx.fillRect(Math.round(sx-((d*.01)%W+W)%W+W)%W,sy,1,1);}}
  for(const L of b.layers){const y=L.y-oy;const r=L.r;const BI=L.img?XIMG[L.img]:BGI;   /* 0.12.387: a layer can live in its own image */
    if(L.tile){const off=((d*L.sp)%L.tile+L.tile)%L.tile;for(let x=-off;x<W;x+=L.tile){ctx.drawImage(BI,r[0],r[1],r[2],r[3],Math.round(x*RES)/RES,y,L.w,L.h);if(L.lamps)drawLamps(ctx,L,Math.round(x*RES)/RES,y,W,g.t);}}
    else{const o=L.once;let x=o.x-d*L.sp;if(o.period){const P=o.period+L.w;x=((x%P)+P)%P-L.w;}if(x<W&&x+L.w>0)ctx.drawImage(BI,r[0],r[1],r[2],r[3],Math.round(x*RES)/RES,y,L.w,L.h);}}
}
// projectiles: larger, readable shapes with a soft glow and a short trail
function glow(ctx,x,y,r,c,a){ctx.globalAlpha=a;ctx.fillStyle=c;ctx.beginPath();ctx.arc(x,y,r,0,7);ctx.fill();ctx.globalAlpha=1;}
function drawProj(ctx,p,x,y,c,t){const k=p.kind;
  if(k==='shard'||k==='frost'){glow(ctx,x,y,6,c,.18);ctx.fillStyle=c;ctx.beginPath();ctx.moveTo(x+5,y);ctx.lineTo(x,y-3);ctx.lineTo(x-6,y);ctx.lineTo(x,y+3);ctx.fill();ctx.fillStyle='#ffffff';ctx.fillRect(x,y-1,3,1);return;}
  if(k==='plasma'){glow(ctx,x,y,6,c,.2);ctx.fillStyle=c;ctx.fillRect(x-6,y-2,9,4);ctx.fillStyle='#e8ffff';ctx.fillRect(x-3,y-1,6,2);return;}
  if(k==='shell'){ctx.fillStyle='#2a2a30';ctx.beginPath();ctx.arc(x,y,3,0,7);ctx.fill();ctx.fillStyle=(Math.floor(t*20)%2)?'#ffd23f':'#ff7a1a';ctx.fillRect(x-4,y-3,2,2);return;}
  if(k==='fire'){for(let i=0;i<3;i++)glow(ctx,x-i*4,y+(i%2),4-i,i?'#ff5a1a':'#ffb040',.7-i*.2);ctx.fillStyle='#fff4b0';ctx.fillRect(x-1,y-1,2,2);return;}
  if(k==='wisp'){glow(ctx,x,y,5,c,.25);ctx.fillStyle=c;ctx.beginPath();ctx.arc(x,y,3,0,7);ctx.fill();ctx.fillRect(x-7,y-1+Math.round(Math.sin(t*12)),5,2);ctx.fillStyle='#0c1a10';ctx.fillRect(x,y-1,1,1);ctx.fillRect(x+2,y-1,1,1);return;}
  if(k==='zap'){glow(ctx,x,y,6,c,.22);ctx.strokeStyle='#e8ffff';ctx.beginPath();ctx.moveTo(x-7,y);ctx.lineTo(x-4,y-2);ctx.lineTo(x-1,y+1);ctx.lineTo(x+3,y-1);ctx.stroke();ctx.fillStyle=c;ctx.fillRect(x+2,y-2,3,3);return;}
  // orbs: bolt, orb, blood, skull, hex and anything else
  glow(ctx,x,y,7,c,.16);glow(ctx,x-4,y,3,c,.35);ctx.fillStyle=c;ctx.beginPath();ctx.arc(x,y,3.2,0,7);ctx.fill();ctx.fillStyle='#ffffff';ctx.fillRect(x-1,y-1,2,2);
}
function shadow(ctx,x,y,w){ctx.fillStyle='rgba(0,0,0,.35)';ctx.beginPath();ctx.ellipse(Math.round(x),Math.round(y),w,2.5,0,0,7);ctx.fill();}

const HS=UNIT_SCALE;   // units, effects and projectiles are drawn at half size so the world reads bigger
function shrinkAt(ctx,x,y,s){ctx.translate(x,y);ctx.scale(s,s);ctx.translate(-x,-y);}
// 0.11 unit status plate: framed health bar (a tick every 10 HP), energy bar under it, and status pips above it
const PIPS=[['kitHits','#c8d0dc','shield'],['hunger','#ff9a40','food'],['thirst','#5ab8ff','drip'],['poulticeT','#9ae08a','drop'],['rageT','#ff3a2a','up'],['cozyT','#ffb040','up'],['poisonT','#6aff4a','rain'],['shoutT','#ff7a1a','up'],['bleedT','#d01830','drop'],['burnT','#ff8a1f','flame'],['slow','#9ae6ff','snow'],['stun','#ffffff','star'],['shield','#7fd8ff','shield'],['buffT','#ffd23f','up']];
function pip(ctx,x,y,c,k){ctx.fillStyle='#120a14';ctx.fillRect(x-1,y-1,5,5);ctx.fillStyle=c;
  if(k==='food'){ctx.fillRect(x,y,3,1);ctx.fillRect(x+1,y+1,1,2);ctx.fillStyle='#ffd8a0';ctx.fillRect(x,y,1,1);}   // 0.12.72 hunger: a little drumstick
  else if(k==='drip'){ctx.fillRect(x+1,y,1,1);ctx.fillRect(x,y+1,3,1);ctx.fillRect(x+1,y+2,1,1);ctx.fillStyle='#ff6a4a';ctx.fillRect(x+2,y+2,1,1);}   // thirst: a drop with a red fleck
  else if(k==='rain'){ctx.fillRect(x+1,y-1,1,2);ctx.fillRect(x,y+1,3,2);ctx.fillStyle='#d8ffd0';ctx.fillRect(x,y+1,1,1);}   // 0.12.70: poison = a little green raindrop
  else if(k==='drop'){ctx.fillRect(x+1,y,1,1);ctx.fillRect(x,y+1,3,2);}else if(k==='flame'){ctx.fillRect(x+1,y,1,1);ctx.fillRect(x,y+1,3,1);ctx.fillRect(x+1,y+2,1,1);}
  else if(k==='snow'){ctx.fillRect(x+1,y,1,3);ctx.fillRect(x,y+1,3,1);}else if(k==='star'){ctx.fillRect(x,y,1,1);ctx.fillRect(x+2,y,1,1);ctx.fillRect(x+1,y+1,1,1);ctx.fillRect(x,y+2,1,1);ctx.fillRect(x+2,y+2,1,1);}
  else if(k==='shield'){ctx.fillRect(x,y,3,2);ctx.fillRect(x+1,y+2,1,1);}else{ctx.fillRect(x+1,y,1,3);ctx.fillRect(x,y+1,3,1);}}
let PLATE_OFF=false;
/* 0.12.71 (Kyle): a cast/reload bar for anything that casts, channels or reloads: [progress 0..1, colour, still filling?]
   gold = casting, violet = channelling, grey = reloading, red = lazer charge/burn, green = smoking/repairs */
function castBar(h){const C=h.base&&h.base.char;if(!C||!h.alive)return null;const R=C.ranged;
  if(h.cast&&h.cast.T)return [h.cast.t/h.cast.T,'#ffd23f',1];
  if(h.building)return [h.building.t/h.building.T,'#ffb040',1];
  if(h.repairing&&h.repairing.tgt){const T=h.repairing.tgt;return [T.hp/T.max,'#7ee081',1];}
  if(h.lz&&R&&R.lazer){const L=R.lazer;return h.lz.t<L.charge?[h.lz.t/L.charge,'#ff4a3a',1]:[1-(h.lz.t-L.charge)/L.fire,'#ff8a6a',0];}
  if(h.lzReload>0&&R&&R.lazer)return [1-h.lzReload/R.lazer.reload,'#a8b0bc',1];
  if(h.syph)return [1-h.syph.t/((C.abilities||[]).find(a=>a.id==='syphon')||{dur:3}).dur,'#b070ff',0];
  if(h.prof)return [1-h.prof.t/((C.abilities||[]).find(a=>a.id==='profane')||{dur:4}).dur,'#b8ff5a',0];
  if(h.nano)return [h.nano.t/((C.abilities||[]).find(a=>a.id==='nano')||{dur:5}).dur,'#5af0d0',1];
  if(h.smoking)return [h.smoking.t/2,'#7ee081',1];
  if(h.camping>0)return [1-h.camping/(h.campT0||1.8),'#ffb040',1];
  if(h.summonT>0)return [1-h.summonT/(h.summonT0||.8),'#b070ff',1];
  if(h.casting>0)return [1-h.casting/(h.castT0||.5),'#7ee081',1];
  if(h.setting&&h.setting.T)return [h.setting.t/h.setting.T,'#ffd23f',1];
  if(h.tossing&&h.tossing.T)return [h.tossing.t/h.tossing.T,'#ffd23f',1];
  if(h.volley>0)return [1-h.volley/(h.volleyT0||.6),'#ffd23f',1];
  if(h.blowing>0)return [1-h.blowing/(h.blowT0||.7),'#ffd23f',1];
  if(h.calling&&h.calling.T)return [h.calling.t/h.calling.T,'#ffd23f',1];
  if(R&&R.clip>0&&h.ammo<=0&&R.reload)return [(h.reloadT||0)/R.reload,'#a8b0bc',1];
  if(h.search&&h.search.T)return [h.search.t/h.search.T,'#9ad0ff',1];
  return null;}   /* the camp scene draws its heroes without health plates */
function plate(ctx,u,x,y,w,hero,col){if(PLATE_OFF)return;x=Math.round(x-w/2);y=Math.round(y);const pct=Math.max(0,Math.min(1,u.hp/u.max));
  ctx.fillStyle='#120a14';ctx.fillRect(x-1,y-1,w+2,hero?6:4);ctx.fillStyle='#3a1a24';ctx.fillRect(x,y,w,2);
  ctx.fillStyle=col||(pct>.5?'#4fd46a':pct>.25?'#ffb020':'#e8303a');ctx.fillRect(x,y,Math.round(w*pct),2);
  if(u.max>=20){ctx.fillStyle='rgba(18,10,20,.55)';const n=Math.floor(u.max/10);for(let i=1;i<n;i++){const tx=x+Math.round(w*i*10/u.max);if(tx<x+w)ctx.fillRect(tx,y,1,1);}}
  if(hero){const e=u.enMax?Math.max(0,(u.en||0)/u.enMax):1;ctx.fillStyle='#2a2410';ctx.fillRect(x,y+3,w,1);ctx.fillStyle='#ffd23f';ctx.fillRect(x,y+3,Math.round(w*e),1);}
  let px=x;for(const [k,c,sh] of PIPS)if(u[k]>0){pip(ctx,px+1,y-6,c,sh);px+=5;}}
function drawGame(ctx,g,W,oy){
  const RR=ctx.canvas.width/W;ctx.setTransform(RR,0,0,RR,0,0);ctx.imageSmoothingEnabled=false;ctx.save();
  if(g.shake>0)ctx.translate(Math.round((Math.random()-.5)*4*g.shake),Math.round((Math.random()-.5)*3*g.shake));
  if(g.bgImg){ctx.imageSmoothingEnabled=true;ctx.drawImage(g.bgImg,0,0,W,ctx.canvas.height/RR);ctx.imageSmoothingEnabled=false;}else drawBG(ctx,g,W,oy);ctx.translate(0,-oy);const G=g.G;
  for(const l of g.loot||[]){const x=Math.round(l.x),y=(l.gy||G)-1;ctx.save();shrinkAt(ctx,x,y+1,HS);
    if(l.kind==='gold'){const n=l.big?7:4;ctx.fillStyle='#7a5a10';ctx.fillRect(x-n,y-2,n*2,2);ctx.fillStyle='#d9a836';for(let i=0;i<n;i++)ctx.fillRect(x-n+1+i*2,y-3-(i%2),2,2);ctx.fillStyle='#ffe27a';ctx.fillRect(x-1,y-5,2,2);
      if(Math.floor(g.t*4+l.x)%3===0){ctx.fillStyle='#ffffff';ctx.fillRect(x+2,y-7,1,1);}}
    else if(l.kind==='food'){ctx.fillStyle='#3a2a18';ctx.fillRect(x-3,y-7,6,7);ctx.fillStyle='#b07a3a';ctx.fillRect(x-2,y-6,4,5);ctx.fillStyle='#e8d0a0';ctx.fillRect(x-2,y-5,4,2);ctx.fillStyle='#d8d8d8';ctx.fillRect(x-3,y-8,6,1);}   /* a tin can */
    else if(l.kind==='water'){ctx.fillStyle='#1a2a38';ctx.fillRect(x-2,y-9,4,9);ctx.fillStyle='#7fd0ff';ctx.fillRect(x-1,y-7,2,6);ctx.fillStyle='#e8f6ff';ctx.fillRect(x-1,y-10,2,2);}   /* a bottle */
    else if(l.kind==='lucky'){const gl=.5+.5*Math.sin(l.t*6);ctx.fillStyle=`rgba(125,255,154,${.25+.25*gl})`;ctx.fillRect(x-6,y-11,12,12);ctx.fillStyle='#0c2410';ctx.fillRect(x-4,y-9,8,8);ctx.fillStyle='#7dff9a';ctx.fillRect(x-3,y-8,6,6);ctx.fillStyle='#ffd23f';ctx.fillRect(x-2,y-7,1,1);ctx.fillRect(x+1,y-4,1,1);ctx.fillRect(x-1,y-6+0,1,1);ctx.fillRect(x,y-5,1,1);}   /* 0.12.281 a glowing green-and-gold Lucky Die */
    else if(l.kind==='gear'){const D=gearDef(l.gear);if(D&&XIMG.gear.complete){const by=Math.round(Math.sin(g.t*4)*1.5);glow(ctx,x,y-7+by,8,GEAR_RAR[D.r].c,.35);ctx.drawImage(XIMG.gear,(D.id%16)*32,Math.floor(D.id/16)*32,32,32,x-6,y-13+by,12,12);}}
    else if(l.kind==='parts'){ctx.fillStyle='#2a2a2e';ctx.fillRect(x-4,y-4,8,4);ctx.fillStyle='#9aa0a8';ctx.fillRect(x-3,y-3,3,2);ctx.fillRect(x+1,y-4,2,3);ctx.fillStyle='#c87a3a';ctx.fillRect(x-1,y-5,2,2);}   /* a little pile of bolts and gears */
    else{const c=(CFG.rarity.find(r=>r.id===l.item.rar)||CFG.rarity[0]).col;const by=Math.round(Math.sin(g.t*4)*1.5);glow(ctx,x,y-6+by,7,c,.25);
      ctx.fillStyle='#5a3a1a';ctx.fillRect(x-4,y-8+by,8,6);ctx.fillStyle=c;ctx.fillRect(x-4,y-8+by,8,2);ctx.fillRect(x-1,y-6+by,2,2);ctx.fillStyle='#ffffff';ctx.fillRect(x+3,y-11+by,1,1);}ctx.restore();}
  for(const z of g.zones||[]){const k=Math.min(1,z.t/z.T);const pulse=.25+.25*Math.sin(g.t*18);ctx.save();
    ctx.fillStyle=z.c;ctx.globalAlpha=z.t>=z.T?.6*(1-(z.t-z.T)/.25):(.12+.25*k+pulse*.3*k);ctx.beginPath();ctx.ellipse(z.cx,G+2,z.hw,6,0,0,7);ctx.fill();
    ctx.globalAlpha=.9;ctx.strokeStyle=z.c;ctx.beginPath();ctx.ellipse(z.cx,G+2,z.hw*k,6*k,0,0,7);ctx.stroke();ctx.restore();}
  // heroes (back to front)
  const hs=g.heroes.concat((g.pets||[]).filter(p=>p.alive||(p.dog&&p.downed))).sort((a,b)=>a.x-b.x);   // a downed dog lies there until someone helps him up
  for(const h of hs)if(!h.alive&&h.downed){const gy=h.gy||G,k=Math.min(1,(h.revT||0)/(h.revNeed||5)),p=.5+.5*Math.sin(g.t*5);ctx.save();ctx.strokeStyle=`rgba(125,255,154,${.25+.2*p})`;ctx.lineWidth=1;ctx.beginPath();ctx.arc(h.x,gy-20,4,0,7);ctx.stroke();
    if(k>0){ctx.strokeStyle='#7dff9a';ctx.lineWidth=1.6;ctx.beginPath();ctx.arc(h.x,gy-20,4,-Math.PI/2,-Math.PI/2+k*6.283);ctx.stroke();}ctx.fillStyle='#7dff9a';ctx.fillRect(h.x-.5,gy-22,1,4);ctx.fillRect(h.x-2,gy-20.5,4,1);ctx.restore();}   // downed: a + to help them up, filling as an ally stands on them
  for(const h of hs)if(!h.alive){const gy=h.gy||G;ctx.save();shrinkAt(ctx,h.x,gy,HS*(h.sz||1));const U=UNITS[h.skin||h.key];if(U&&U.death)drawUnit(ctx,U.death,U.death.n-1,h.x,gy-(U.death.fall?2:0),U.death.pre?ART_SCALE/U.death.pre/HS:U.death.art?ART_SCALE/HS:1,.9,0,U.death.fall?((h.face||1)>0?1.45:-1.45):0,((h.face||1)>0)!==!!U.death.faceR);else spr(ctx,'h_'+h.key,10,h.x-32,gy-60,false,.85);ctx.restore();}
  /* 0.12.412 new talent abilities */
  for(const w of g.walls||[]){const k=Math.min(1,w.t/.6),top=LANES[0]-34,bot=LANES[LANES.length-1]+4;ctx.save();ctx.globalAlpha=.35*k+.1*Math.sin(g.t*6);const gr=ctx.createLinearGradient(w.x-4,0,w.x+4,0);gr.addColorStop(0,'rgba(80,140,255,0)');gr.addColorStop(.5,'rgba(130,190,255,.9)');gr.addColorStop(1,'rgba(80,140,255,0)');
    ctx.fillStyle=gr;ctx.fillRect(w.x-5,top,10,bot-top);ctx.globalAlpha=.8*k;ctx.strokeStyle='#cfe4ff';ctx.lineWidth=.6;for(let y=top;y<bot;y+=6){ctx.beginPath();ctx.moveTo(w.x-3,y+Math.sin(g.t*4+y)*1);ctx.lineTo(w.x+3,y+3);ctx.stroke();}ctx.restore();}
  for(const sp of g.spears||[]){const k=Math.min(1,sp.t/.35),x=sp.x0+(sp.x1-sp.x0)*k,y=sp.gy-14+(k>=1?8:0);ctx.save();ctx.strokeStyle='#ff3a4a';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x-10*Math.sign(sp.x1-sp.x0||1),y);ctx.lineTo(x+6*Math.sign(sp.x1-sp.x0||1),y);ctx.stroke();
    ctx.globalCompositeOperation='lighter';for(let i=0;i<3;i++)glow(ctx,x-i*4*Math.sign(sp.x1-sp.x0||1),y+(Math.random()-.5)*4,2.5,'#ff3a4a',.7);ctx.restore();}
  for(const c of g.cars||[]){const k=c.t/c.T,x=-40+(g.W+80)*k,y=LANES[LANES.length-1]+10;ctx.save();ctx.fillStyle='#2a1838';ctx.fillRect(x-22,y-9,44,8);ctx.fillRect(x-13,y-15,24,7);ctx.fillStyle='#9ad0ff';ctx.fillRect(x-11,y-14,9,5);ctx.fillRect(x+0,y-14,9,5);
    ctx.fillStyle='#111';ctx.beginPath();ctx.arc(x-13,y-1,3.5,0,7);ctx.arc(x+13,y-1,3.5,0,7);ctx.fill();if(Math.floor(g.t*20)%2)glow(ctx,x+2,y-18,4,'#ffd25a',.9);ctx.restore();}
  for(const h of g.heroes)if(h.knT>0&&h.alive){const hx=g.heroX(h),hy=(h.gy||G)-12;ctx.save();ctx.strokeStyle='#e8e8f0';ctx.lineWidth=1;for(let i=0;i<4;i++){const a=g.t*7+i*Math.PI/2,x=hx+Math.cos(a)*16,y=hy+Math.sin(a)*6;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+Math.cos(a+1.6)*5,y+Math.sin(a+1.6)*2);ctx.stroke();}ctx.restore();}
  for(const p of g.pets||[])if(p.hound&&p.alive){ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,g.heroX(p),(p.gy||G)-8,12,'#ff2a3a',.35+.2*Math.sin(g.t*12));ctx.restore();}
  for(const f of g.flasks||[]){const k=Math.min(1,f.t/f.T),x=f.x0+(f.x1-f.x0)*k,y=f.gy0+(f.gy1-f.gy0)*k-16-40*k*(1-k);ctx.save();ctx.translate(x,y);ctx.rotate(g.t*14);ctx.fillStyle={fire:'#ff7a20',acid:'#8aff3a',frost:'#8ad0ff',holy:'#fff2b0',boom:'#ffb040',stunf:'#f0f060',web:'#d8d8e8'}[f.e]||'#c080ff';ctx.beginPath();ctx.arc(0,1,2,0,7);ctx.fill();ctx.fillStyle='#e8f0f8';ctx.fillRect(-.6,-2.6,1.2,2);ctx.fillStyle='#8a5a2a';ctx.fillRect(-.7,-3.2,1.4,.8);ctx.restore();}   /* 0.12.427 thrown potions */
  for(const a of g.axes||[]){const k=Math.min(1,a.t/a.T),x=a.x0+(a.x1-a.x0)*k,y=a.gy0+(a.gy1-a.gy0)*k-14-a.H*4*k*(1-k);const dr=Math.sign(a.x1-a.x0||1);ctx.save();ctx.translate(x,y);ctx.scale(dr,1);ctx.rotate(g.t*18);   /* 0.12.413 (Kyle): blade leads the way it's thrown, spins faster */
    const AX=XIMG.axe;if(AX.complete&&AX.naturalWidth){ctx.imageSmoothingEnabled=false;ctx.drawImage(AX,-4.5,-8.8,9,17.6);}else{ctx.fillStyle='#6b4a2a';ctx.fillRect(-.6,-5,1.2,10);ctx.fillStyle='#c8ccd4';ctx.beginPath();ctx.moveTo(.6,-5);ctx.lineTo(5,-6);ctx.lineTo(5,-1);ctx.lineTo(.6,-2);ctx.fill();ctx.fillStyle='#c0302a';ctx.fillRect(-2.6,-5,2,2);}ctx.restore();}   /* 0.12.413 Kyle's fire-axe art (Vecteezy.com) */   /* 0.12.403 the Fireman's spinning axe */
  {const AX=XIMG.axe;if(AX&&AX.complete&&AX.naturalWidth)for(const f of g.fx)if(f.k==='axestuck'){const k=f.t/f.life;let al=1;if(f.t>.75)al=Math.floor(f.t*16)%2?.25:1;if(k>.9)al*=(1-k)*10;
    ctx.save();ctx.globalAlpha=al;ctx.translate(f.x,f.gy+3);ctx.scale(f.dir,1);ctx.rotate(2.45);ctx.imageSmoothingEnabled=false;ctx.drawImage(AX,-4.5,-3,9,17.6);ctx.restore();}}   /* 0.12.421 a missed axe sticks in the dirt, blinks, vanishes */
  for(const f of g.fx)if(f.k==='bile'){const k=f.t/f.life;ctx.save();for(let i=0;i<14;i++){const u=Math.min(1,k*1.6+i*.02),d=u*f.len*(.55+.45*((i*37)%10)/10),ang=-.35+((i*53)%13)/13*.5;
    const x=f.x+f.dir*Math.cos(ang)*d,y=f.y-Math.sin(ang)*d*.5+u*u*14*(1+(i%3)*.3);ctx.globalAlpha=Math.max(0,1-k)*(.9-(i%4)*.12);ctx.fillStyle=i%3?'#8fd43a':'#c8f25a';ctx.beginPath();ctx.ellipse(x,y,2.4-(i%3)*.5,1.6,0,0,7);ctx.fill();}
    ctx.globalAlpha=Math.max(0,.5-k*.6);ctx.fillStyle='#6fae2a';ctx.beginPath();ctx.ellipse(f.x+f.dir*f.len*.55,f.y+12,f.len*.45,3.5,0,0,7);ctx.fill();ctx.restore();}   /* 0.12.413 (Kyle): a real arc of bile with a splash puddle */
  for(const z of g.hz||[]){const k=Math.min(1,z.t/1.2);ctx.save();ctx.globalAlpha=.55*k;
    if(z.k==='gas'){for(let i=0;i<5;i++){const a=g.t*.8+i*1.3;ctx.fillStyle=i%2?'#7dcf3a':'#a6ff5a';ctx.beginPath();ctx.ellipse(z.x+Math.cos(a)*z.r*.45,z.gy-6+Math.sin(a*1.3)*3,z.r*.55,z.r*.22,0,0,7);ctx.fill();}}
    else{ctx.fillStyle='#3a1a0a';ctx.beginPath();ctx.ellipse(z.x,z.gy,z.r,z.r*.35,0,0,7);ctx.fill();ctx.globalCompositeOperation='lighter';for(let i=0;i<3;i++){const fl=Math.sin(g.t*14+i*2)*1.5;glow(ctx,z.x-5+i*5,z.gy-3+fl,3,i===1?'#ffd25a':'#ff7a2a',.8);}}
    ctx.restore();
    {const FX=XIMG.fxp;if(FX&&FX.complete&&FX.naturalWidth){ctx.save();ctx.imageSmoothingEnabled=true;
      if(z.k==='gas'){if(z.t<.9){const fr=Math.min(9,Math.floor(z.t/.9*10)),w=z.r*2.4;ctx.globalAlpha=Math.min(1,(.9-z.t)*4);ctx.drawImage(FX,fr*96,48,96,96,z.x-w/2,z.gy+4-w,w,w);}}
      else{const n=Math.max(2,Math.round(z.r/7));for(let i=0;i<n;i++){const fr=Math.floor(g.t*11+i*2.3)%6,s=19+((i*7)%3)*3,fx=z.x-z.r*.75+(i+.5)*(z.r*1.5/n);ctx.globalAlpha=.9*k;ctx.drawImage(FX,fr*48,0,48,48,fx-s/2,z.gy+1-s,s,s);}}
      ctx.restore();}}}   /* 0.12.418 (Kyle's packs): real flames on burn patches, a gas burst when the Hazmat breaches */
  if(UNITS.bloater)for(const f of g.fx)if(f.k==='gutsplat'){const k=f.t/f.life,gr=Math.min(1,f.t/.3);drawUnit(ctx,UNITS.bloater.splat,0,f.x,f.gy,HS*f.big*(.45+.55*gr),k>.6?.9*(1-k)/.4:.9,0,0,false);}   /* 0.12.383 Bloater: the gore splat soaks into the ground */
  for(const f of g.fx)if(f.k==='corpse'&&UNITS[f.skin||f.type]){ctx.save();shrinkAt(ctx,f.x,f.gy!=null?f.gy:G,HS);ctx.restore();const U=UNITS[f.skin||f.type],k=f.t/f.life;const fall=Math.min(1,k*3.2);
    if(U.die){const fr=Math.min(U.die.n-1,Math.floor(k/.7*U.die.n));const E2=CFG.enemies[f.type]||{};drawUnit(ctx,U.die,fr,f.x,f.gy!=null?f.gy:G,HS*(E2.scale||1)*(f.elite?1.1:1)*(U.die.pre?.88/U.die.pre:1),k>.75?(1-k)*4:1,0,0,!!U.die.faceR);continue;}
    drawUnit(ctx,U.walk,0,f.x+fall*3,f.gy!=null?f.gy:G+(f.lane||0),HS*(f.elite?1.1:1),Math.min(1,2.2*(1-k)),0,-fall*Math.PI/2*.96);}
  for(const f of g.fx)if(f.k==='corpse'&&f.type==='bat'&&ATLAS.bat&&ATLAS.bat.death){const k=f.t/f.life,gy=f.gy!=null?f.gy:G,y0=f.y!=null?f.y:gy-40,fall=Math.min(1,k*2.4),y=y0+(gy-2-y0)*fall*fall;drawUnit(ctx,ATLAS.bat.death,0,f.x,y,.7,k>.7?(1-k)/.3:1,0,fall*1.2,false);}   /* 0.12.302 (Kyle): a small bat tumbling down, not a giant death sprite */
  for(const f of g.fx)if(f.k==='corpse'){if(f.type==='bat'&&ATLAS.bat&&ATLAS.bat.death)continue;const n='e_'+f.type,a=SP[n];if(!a||UNITS[f.type])continue;const k=f.t/f.life;const big=FH(a)===64;
    const y=f.fly?Math.min(G-44,f.y-FH(a)/2+f.t*160):G-(big?60:44)+(f.lane||0);ctx.save();if(f.elite){ctx.translate(f.x,y+FH(a));ctx.scale(1.22,1.22);spr(ctx,n,10,-FW(a)/2,-FH(a),false,Math.min(1,2.2*(1-k)));}else spr(ctx,n,10,f.x-FW(a)/2,y,false,Math.min(1,2.2*(1-k)));ctx.restore();}
  const laser=()=>{for(const h of g.heroes){const K=h.cast;if(!h.alive||!K||!K.tgt||K.tgt.dead)continue;const T=K.tgt,mz=MUZZLE[h.key]||[10,30];
      const x0=g.heroX(h)+(h.face<0?-1:1)*mz[0],y0=(h.gy||g.G)-mz[1],tx=T.x,ty=(T.gy!=null&&!T.fly?T.gy:g.G)-(T.type==='werewolf'?18:38)*HS*((T.E&&T.E.scale)||1);
      const k=K.t/K.T;ctx.save();ctx.globalCompositeOperation='lighter';ctx.strokeStyle=`rgba(255,40,40,${.35+.45*k})`;ctx.lineWidth=.6+k*.6;ctx.setLineDash(k>.75?[]:[3,2]);
      ctx.beginPath();ctx.moveTo(x0,y0);ctx.lineTo(tx,ty);ctx.stroke();ctx.setLineDash([]);glow(ctx,tx,ty,3+3*k,'#ff2828',.35+.3*Math.sin(g.t*30));ctx.restore();}};
  const traps=()=>{const T0=UNITS.flannel&&UNITS.flannel.tripbomb,BB=UNITS.flannel&&UNITS.flannel.bombball;if(!T0)return;for(const T of g.traps||[]){
      if(T.how&&T.how!=='plant'&&BB){   /* 0.12.58 thrown/tossed Proximity_Bomb: just the ball, spinning through the air, rolling, then blinking once armed */
        const y=T.gy-(T.air||0);ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(Math.round(T.x-3+(T.air||0)*.05),T.gy-1,6,1.5);ctx.save();ctx.translate(T.x,y-3.5);ctx.rotate(T.spin||0);
        drawUnit(ctx,BB,0,0,3.5,.5*HS,1,0,0,false);ctx.restore();
        if(T.live){const p=.5+.5*Math.sin(g.t*6);ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,T.x,y-3,7+2*p,'#ff2a1a',.35+.25*p);ctx.restore();if(p>.5){ctx.fillStyle='#ff4030';ctx.fillRect(Math.round(T.x)-.5,Math.round(y-7.5),1,1);}}   /* 0.12.59: activated (6d4): the rust-mine red glow */
        continue;}
      if(T.live&&T.t>=T.A.arm){const p=.5+.5*Math.sin(g.t*6);ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,T.x-2,T.gy-4,8+2*p,'#ff2a1a',.3+.2*p);ctx.restore();}
      ctx.save();shrinkAt(ctx,T.x,T.gy,HS);
      drawUnit(ctx,T0,0,T.x,T.gy,.5,T.t<T.A.arm?.55+.45*Math.sin(g.t*20)**2:1,0,0,false);ctx.restore();}};
  // Wave Dash: a blue crescent of energy (about 1.5x his height) riding his sword, with fading afterimages
  // Wave Dash: Kyle's wave shape (tall front crescent he rides in, jagged tail along the ground), pixel art, with afterimages
  // Wave Dash: Kyle's wave (his pick of the three), riding ahead of the warrior, with afterimages and lightning crackling around it
  const zap=(x0,y0,len,ang)=>{ctx.beginPath();ctx.moveTo(x0,y0);let x=x0,y=y0;const n=4;for(let i=0;i<n;i++){x+=Math.cos(ang)*len/n+(Math.random()-.5)*3;y+=Math.sin(ang)*len/n+(Math.random()-.5)*3;ctx.lineTo(x,y);}ctx.stroke();};
  const waves=()=>{for(const h of g.alive()){const D=h.dash;if(!D)continue;const G0=h.gy||g.G,fl=(h.face||1)<0,s=fl?-1:1;
      D.trail.forEach((x,i)=>drawUnit(ctx,WAVE,0,x,G0,.5,.12+.1*i/D.trail.length,0,0,fl));
      ctx.save();ctx.globalCompositeOperation='lighter';drawUnit(ctx,WAVE,0,h.x,G0,.5,.5,0,0,fl);ctx.restore();drawUnit(ctx,WAVE,0,h.x,G0,.5,.88,0,0,fl);
      ctx.save();ctx.globalCompositeOperation='lighter';
      for(let k=0;k<4;k++){const t=Math.random();const cx=h.x+s*(9+14*Math.sin(t*Math.PI)+Math.random()*4),cy=G0-1-t*32;   // along the front crescent
        ctx.strokeStyle=k%2?'rgba(170,230,255,.9)':'rgba(255,255,255,.95)';ctx.lineWidth=.5;zap(cx,cy,4+Math.random()*6,Math.random()*6.28);}
      for(let k=0;k<2;k++){const tx=h.x-s*(4+Math.random()*24);ctx.strokeStyle='rgba(140,210,255,.8)';ctx.lineWidth=.5;zap(tx,G0-2-Math.random()*6,3+Math.random()*4,-Math.PI/2+(Math.random()-.5));}   // along the tail
      if(Math.random()<.5)glow(ctx,h.x+s*(14+Math.random()*8),G0-6-Math.random()*24,2.5,'#e8fbff',.6);ctx.restore();}};
  // Arrow_Rain: arrows falling out of the sky, and the ones stuck in the ground
  /* 0.12.69 Hatchet_Leap landing: a cracked-earth decal that lingers, dust clouds rolling out, pebbles thrown up, a short burst of energy */
  /* 0.12.70 Syphon_Life: two twisting strands (black and violet) from his chest to the target's middle, motes of life drifting back into him;
     a burrow puff where Call_of_Cthulhu pulls a tentacle under */
  const voidFx=()=>{for(const h of g.alive()){if(h.key!=='cultist')continue;const hx=g.heroX(h),gy=h.gy||G;
      if(h.syph&&h.syph.tg&&!h.syph.tg.dead){const T=h.syph.tg,x0=hx+(h.face||1)*3,y0=gy-12,x1=T.x,y1=(T.gy!=null?T.gy:G)-(T.boss?30:12),L=Math.hypot(x1-x0,y1-y0)||1,nx=-(y1-y0)/L,ny=(x1-x0)/L;
        ctx.save();for(const [w,c,ph,amp] of [[3.2,'rgba(10,0,16,.75)',0,2.2],[1.6,'rgba(150,60,255,.85)',Math.PI,2],[.7,'rgba(230,200,255,.9)',Math.PI*.5,1.2]]){ctx.strokeStyle=c;ctx.lineWidth=w;ctx.beginPath();
          for(let i=0;i<=24;i++){const k=i/24,sw=Math.sin(k*12-g.t*14+ph)*amp*Math.sin(k*Math.PI),x=x0+(x1-x0)*k+nx*sw,y=y0+(y1-y0)*k+ny*sw;i?ctx.lineTo(x,y):ctx.moveTo(x,y);}ctx.stroke();}
        ctx.globalCompositeOperation='lighter';for(let i=0;i<5;i++){const k=1-((g.t*1.3+i/5)%1);glow(ctx,x0+(x1-x0)*k,y0+(y1-y0)*k+Math.sin(g.t*9+i)*1.5,1.3,i%2?'#ff5a8a':'#b070ff',.8);}
        glow(ctx,x1,y1,5,'#6a20c0',.35);glow(ctx,x0,y0,3,'#b070ff',.4);ctx.restore();}
      /* 0.12.397 Profane_Restoration: the reverse of Syphon_Life. A braided healing beam (deep green, gold, white core) from his chest into the ally,
         pulsing with each tick, with motes of his blood-light running OUT to them and a soft green halo on whoever he's mending */
      if(h.prof&&h.prof.tg&&h.prof.tg.alive){const T=h.prof.tg,x0=hx+(h.face||1)*3,y0=gy-12,x1=g.heroX(T),y1=(T.gy||G)-14,L=Math.hypot(x1-x0,y1-y0)||1,nx=-(y1-y0)/L,ny=(x1-x0)/L;
        const pulse=.75+.25*Math.sin(g.t*10);ctx.save();
        for(const [w,c,ph,amp] of [[4.2,'rgba(30,90,20,.45)',0,1.6],[2,`rgba(120,255,90,${.85*pulse})`,Math.PI,1.8],[1.4,'rgba(255,215,90,.8)',Math.PI*.5,1.4],[.7,'rgba(255,255,235,.95)',0,.4]]){ctx.strokeStyle=c;ctx.lineWidth=w;ctx.beginPath();
          for(let i=0;i<=24;i++){const k=i/24,sw=Math.sin(k*10+g.t*12+ph)*amp*Math.sin(k*Math.PI),x=x0+(x1-x0)*k+nx*sw,y=y0+(y1-y0)*k+ny*sw;i?ctx.lineTo(x,y):ctx.moveTo(x,y);}ctx.stroke();}
        ctx.globalCompositeOperation='lighter';for(let i=0;i<6;i++){const k=(g.t*1.4+i/6)%1;glow(ctx,x0+(x1-x0)*k,y0+(y1-y0)*k+Math.sin(g.t*8+i)*1.4,1.3,i%3===0?'#ff5a6a':i%2?'#ffe07a':'#9dff6a',.85);}
        glow(ctx,x1,y1,7*pulse,'#7dff5a',.35);glow(ctx,x1,y1-6,4,'#fff2b0',.3);glow(ctx,x0,y0,3,'#c0102a',.45);ctx.restore();}
}
    for(const f of g.fx){if(f.k!=='burrow')continue;const k=f.t/f.life;for(let i=0;i<5;i++)puffAt(f.x+(i-2)*2.5,f.gy-1-k*5-(i%2),1.6+k*2,.6*(1-k),'#4a3a2c');}};
  const slamDraw=()=>{for(const f of g.fx){if(f.k!=='crack')continue;const k=f.t/f.life,a=k>.7?(1-k)/.3:1;let sd=Math.floor(f.x*13+f.gy*7);const R=()=>{sd=(sd*9301+49297)%233280;return sd/233280;};
      ctx.save();ctx.globalAlpha=a;ctx.fillStyle='rgba(20,12,8,.35)';ctx.beginPath();ctx.ellipse(f.x,f.gy,f.r*.55,f.r*.16,0,0,7);ctx.fill();
      for(let i=0;i<8;i++){let ang=i/8*6.283+R()*.5,x=f.x,y=f.gy,L=f.r*(.55+R()*.6);ctx.beginPath();ctx.moveTo(x,y);
        for(let j=1;j<=3;j++){ang+=(R()-.5)*.7;x=f.x+Math.cos(ang)*L*j/3;y=f.gy+Math.sin(ang)*L*j/3*.28;ctx.lineTo(x,y);}
        ctx.strokeStyle='#1a0e08';ctx.lineWidth=1.1-.0*i;ctx.stroke();ctx.strokeStyle='rgba(200,150,100,.35)';ctx.lineWidth=.4;ctx.beginPath();ctx.moveTo(f.x,f.gy+.6);ctx.lineTo(x,y+.6);ctx.stroke();}
      ctx.restore();}
    for(const f of g.fx){if(f.k!=='slam')continue;const k=f.t/f.life;ctx.save();
      if(k<.35){ctx.globalCompositeOperation='lighter';glow(ctx,f.x,f.gy-4,f.r*(.5+k*2),'#ffb040',.45*(1-k/.35));glow(ctx,f.x,f.gy-3,4,'#fff0c0',.7*(1-k/.35));ctx.globalCompositeOperation='source-over';
        ctx.strokeStyle=`rgba(255,200,110,${.8*(1-k/.35)})`;ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(f.x,f.gy-1,f.r*(.4+k*3.4),f.r*(.12+k*.9),0,0,7);ctx.stroke();}
      for(let i=0;i<6;i++){const s=i%2?1:-1,d=f.r*(.3+k*1.4)*(1+i%3*.25),r=(2.2+i%3)*(.6+k*1.2);puffAt(f.x+s*d,f.gy-2-k*4-(i%3),r,.55*(1-k),'#9a8670');}   // dust rolling out both ways
      for(let i=0;i<10;i++){const a=((f.seed+i*2.4)%3.1)+.02,sp=18+(i*7%11)*2,px=f.x+Math.cos(a)*sp*k*1.4*(i%2?1:-1),py=f.gy-2-(Math.sin(a)*40*k-60*k*k)-2;
        if(py<f.gy){ctx.fillStyle=i%3?'#6a5a48':'#a89880';ctx.globalAlpha=1-k*.6;ctx.fillRect(px,py,i%4?1:1.5,i%4?1:1.5);}}   // pebbles
      ctx.restore();}};
  const pinnedDraw=()=>{for(const f of g.fx){if(f.k!=='pinned')continue;const e=f.e;if(e&&!e.dead){f.x=e.x;f.gy=e.gy!=null?e.gy:G;}const k=f.t/f.life,a=k>.85?(1-k)/.15:1;
      const B=UNITS.archer&&UNITS.archer.arrow;const x=f.x-f.dir*1.5,y=f.gy-3.5;ctx.save();ctx.globalAlpha=a;ctx.translate(x,y);ctx.rotate(f.dir>0?.62:Math.PI-.62);   /* 0.12.68: the big arrow driven through the legs into the dirt */
      if(B)drawUnit(ctx,B,0,0,0,ART_SCALE/B.pre*2,a,0,0,false);else{ctx.fillStyle='#8a6a4a';ctx.fillRect(-9,-.5,12,1);}ctx.restore();
      ctx.fillStyle=`rgba(60,40,24,${.6*a})`;ctx.fillRect(Math.round(f.x+f.dir*1.5)-2,Math.round(f.gy)-.5,4,1.2);   // dirt kicked up where it bit in
      if(f.t<.25)for(let i=0;i<4;i++){ctx.fillStyle=`rgba(150,120,90,${1-f.t*4})`;ctx.fillRect(f.x+f.dir*2+(i-1.5)*1.6,f.gy-1-f.t*14*(1+i%2),1,1);}}};
  const bottleDraw=()=>{for(const B of g.bottles||[]){const y=B.gy-B.hgt*.5-6;ctx.save();ctx.translate(B.x,y);ctx.rotate(B.rot);   /* 0.12.68 Bottle_Distraction: a green glass bottle tumbling in a big arc */
      ctx.fillStyle='#1e4a2a';ctx.fillRect(-1.5,-3,3,5);ctx.fillRect(-.5,-5,1,2);ctx.fillStyle='#3c8a52';ctx.fillRect(-1,-2.5,1,4);ctx.fillStyle='#bfe8c8';ctx.fillRect(-1,-2.5,.6,2);ctx.fillStyle='#8a5a30';ctx.fillRect(-.5,-5.5,1,.8);ctx.restore();
      ctx.fillStyle='rgba(0,0,0,.25)';ctx.fillRect(B.x-1.5,B.gy-.5,3,1);}
    for(const f of g.fx){if(f.k!=='glass')continue;const k=f.t/f.life;ctx.save();ctx.globalAlpha=1-k;for(let i=0;i<9;i++){const a=i*.7+1,sp=10+((i*37)%7)*2.2,dx=Math.cos(a)*sp*Math.min(1,k*2.4),up=Math.sin(Math.min(1,k*2)*Math.PI)*(4+i%3*2);
        ctx.fillStyle=i%3?'#7fd49a':'#e8fff0';ctx.fillRect(f.x+dx,f.gy-1-up,1,1);}
      ctx.strokeStyle=`rgba(230,255,240,${.7*(1-k)})`;ctx.lineWidth=.6;ctx.beginPath();ctx.ellipse(f.x,f.gy-1,6+k*24,1.5+k*6,0,0,7);ctx.stroke();   // the noise rings out
      if(k<.5){ctx.fillStyle='#ffffff';ctx.font='bold 5px monospace';ctx.textAlign='center';ctx.fillText('CRASH!',f.x,f.gy-12-k*8);}ctx.restore();}};
  /* 0.12.105 Grenade_Launcher rounds: a stubby 40mm grenade. In the air it points the way it's flying (nose down on the way in,
     steeper from the tower); once it hits the ground it tumbles and rolls, and blinks red while the fuse runs. */
  const nadeDraw=()=>{for(const N of g.glNades||[]){const y=N.gy-N.z*.6-2;let ang;
      if(N.st==='fly'){const vy=-N.vz*.6;ang=Math.atan2(vy,N.vx);}else ang=N.rot;
      ctx.fillStyle='rgba(0,0,0,.28)';ctx.fillRect(N.x-1.5,N.gy-.5,3,1);
      ctx.save();ctx.translate(N.x,y);ctx.rotate(ang);ctx.scale(.7,.7);   /* 0.12.161 (Kyle): a little smaller */
      ctx.fillStyle='#3e4a2a';ctx.fillRect(-2.2,-1.2,3.2,2.4);   /* olive body */
      ctx.fillStyle='#c9a24a';ctx.fillRect(-2.6,-1.2,.8,2.4);   /* brass case base */
      ctx.fillStyle=N.st!=='fly'&&N.vx===0&&Math.floor(N.fuseT*12)%2?'#ff3a2a':'#8a9a5a';ctx.beginPath();ctx.moveTo(1,-1.2);ctx.lineTo(2.6,0);ctx.lineTo(1,1.2);ctx.closePath();ctx.fill();   /* ogive nose (blinks while the fuse runs) */
      ctx.fillStyle='#ffd23f';ctx.fillRect(-.6,-1.2,.5,2.4);   /* yellow HE band */
      ctx.restore();}};
  const rainDraw=()=>{for(const f of g.fx)if(f.k==='stuck'){const k=f.t/f.life;drawUnit(ctx,RAIN.s,0,f.x,f.gy+1,.5,k>.7?(1-k)/.3:1,0,0,false);}
    for(const R of g.rain||[]){if(R.t<0)continue;const k=Math.min(1,R.t/R.T);drawUnit(ctx,RAIN.f,0,R.x,R.gy-(1-k)*90,.5,1,0,0,false);}};
  // Druid effects: Mend sparkle, Bloom vine heart on the healed ally, Thorn Eruption spikes, Cyclone tornadoes
  // 0.12.17 Moss_Mech effects: arc blade glow and slashes, chain lightning, missiles and their smoke trails, grenades and smoke clouds
  const zig=(x0,y0,x1,y1,n,amp)=>{ctx.beginPath();ctx.moveTo(x0,y0);for(let i=1;i<n;i++){const k=i/n;ctx.lineTo(x0+(x1-x0)*k+(Math.random()*2-1)*amp*.4,y0+(y1-y0)*k+(Math.random()*2-1)*amp);}ctx.lineTo(x1,y1);ctx.stroke();};
  const puffAt=(x,y,r,a,shade)=>{ctx.globalAlpha=a;ctx.fillStyle=shade||'#c9d2da';ctx.beginPath();ctx.arc(x,y,r,0,7);ctx.fill();ctx.fillStyle='#eef3f6';ctx.beginPath();ctx.arc(x-r*.3,y-r*.35,r*.55,0,7);ctx.fill();ctx.globalAlpha=1;};
  const robotFx=()=>{
    /* 0.12.67 Warhound: pilot light on the flamethrower; the Targeted Lazer (lens charge, a thick pulsing red beam angled down from his hull to
       a target reticle on the ground, ground fire riding the tip, blue arcs when Arc Surge is on); the blue jetpack flames + shield; nano glow */
    for(const h of g.alive())if(h.key==='robot'){const d=(h.face||1)>0?1:-1,hx=g.heroX(h),gy=h.gy||g.G,lift=(h.leapH||0)*1.2*HS;ctx.save();ctx.globalCompositeOperation='lighter';
      if(!h.jet&&!h.nano){const px=hx+d*(h.animM>0||h.lz?17.7:14.1),py=gy-(h.animM>0||h.lz?22:13)-lift;glow(ctx,px,py,1.6+Math.random()*.4,'#ff9a30',.55);glow(ctx,px,py,.7,'#fff0b0',.9);}
      if(h.lz){const C2=h.base.char.ranged.lazer,L=h.lz,ex=hx+d*8.2,ey=gy-25.5-lift,tx=L.tx,ty=L.gy-1.5,S=h.surgeT>0;
        if(L.t<C2.charge){const k=L.t/C2.charge;glow(ctx,ex,ey,1.2+2.5*k,'#ff2a1a',.35+.4*k);ctx.strokeStyle=`rgba(255,60,40,${.35+.5*k})`;ctx.lineWidth=.6;ctx.beginPath();ctx.ellipse(tx,ty+1,6*(1-k)+2,2*(1-k)+1,0,0,7);ctx.stroke();
          ctx.setLineDash([1.5,2]);ctx.strokeStyle=`rgba(255,80,60,${.25*k})`;ctx.beginPath();ctx.moveTo(ex,ey);ctx.lineTo(tx,ty);ctx.stroke();ctx.setLineDash([]);}
        else{const fl=.75+.25*Math.sin(g.t*40);for(const [w,c] of [[S?4.4:3.4,`rgba(255,20,10,${.28*fl})`],[S?2.2:1.7,`rgba(255,70,40,${.7*fl})`],[.7,'rgba(255,235,225,.95)']]){ctx.strokeStyle=c;ctx.lineWidth=w;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(ex,ey);ctx.lineTo(tx,ty);ctx.stroke();}
          glow(ctx,ex,ey,3,'#ff3020',.6);glow(ctx,tx,ty,(S?8.3:6.7)*.9,'#ff4010',.22);glow(ctx,tx,ty,2.2,'#fff0d0',.85);
          if(S&&Math.random()<.8){ctx.strokeStyle='rgba(150,220,255,.9)';ctx.lineWidth=.5;const m=Math.random();zig(ex+(tx-ex)*m,ey+(ty-ey)*m,ex+(tx-ex)*(m+.15),ey+(ty-ey)*(m+.15)+(Math.random()-.5)*4,3,1.5);}
          ctx.restore();ctx.save();fireBit(tx-d*1.5,L.gy+1,.3,4+Math.floor(g.t*12)%4,.9);fireBit(tx-d*4.5,L.gy+1,.2,4+Math.floor(g.t*12+2)%4,.7);ctx.globalCompositeOperation='lighter';}}
      if(h.jet){const bx=hx-d*9,by=gy-9-lift;for(const o of[-1.3,1.3])blueFire(bx+o,by,.3+Math.random()*.06,4+Math.floor(g.t*14+(o>0?2:0))%4,.95,1);
        glow(ctx,bx,by+5,4.5,'#3a8cff',.35);ctx.strokeStyle=`rgba(120,200,255,${.5+.2*Math.sin(g.t*20)})`;ctx.lineWidth=.9;ctx.beginPath();ctx.ellipse(hx,gy-16-lift,14,19,0,0,7);ctx.stroke();glow(ctx,hx,gy-16-lift,16,'#4aa8ff',.1);}
      if(h.nano)glow(ctx,hx,gy-15,15,'#5af0d0',.08+.05*Math.sin(g.t*8));
      if(h.surgeT>0&&!h.lz&&Math.random()<.5){ctx.strokeStyle='rgba(150,220,255,.85)';ctx.lineWidth=.5;zig(hx+d*8,gy-26-lift,hx+d*(8+Math.random()*4),gy-21-lift,3,1.2);}
      ctx.restore();}
    for(const f of g.fx){const k=f.t/f.life;
      if(f.k==='arc'){const d=f.dir,cx=f.x+d*6,cy=f.gy-10,R=f.big?13:10;ctx.save();ctx.globalCompositeOperation='lighter';ctx.globalAlpha=1-k;ctx.lineCap='round';
        for(const [w,c] of [[3.2,'rgba(30,140,255,.6)'],[1.3,'rgba(200,245,255,.95)']]){ctx.strokeStyle=c;ctx.lineWidth=w;ctx.beginPath();const a0=d>0?-1.25:Math.PI+1.25,a1=d>0?1.1:Math.PI-1.1,s=a0+(a1-a0)*Math.min(1,k*2.2);ctx.arc(cx-d*4,cy,R,Math.min(a0,s),Math.max(a0,s));ctx.stroke();}
        ctx.strokeStyle='rgba(170,230,255,.9)';ctx.lineWidth=.6;zig(cx,cy-8,cx+d*6,cy+6,4,1.6);ctx.restore();continue;}
      if(f.k==='bolt'){ctx.save();ctx.globalCompositeOperation='lighter';ctx.globalAlpha=1-k;for(const [w,c] of (f.c==='y'?[[2.4,'rgba(255,220,60,.7)'],[.8,'rgba(255,255,220,1)']]:f.c==='v'?[[2.4,'rgba(140,50,255,.7)'],[.8,'rgba(230,200,255,1)']]:[[2.4,'rgba(40,150,255,.7)'],[.8,'rgba(230,250,255,1)']])){ctx.strokeStyle=c;ctx.lineWidth=w;for(let i=1;i<f.pts.length;i++){const [a,b]=f.pts[i-1],[x,y]=f.pts[i];zig(a,b,x,y,5,2.2);}}
        for(const [x,y] of f.pts)glow(ctx,x,y,3,'#6fd0ff',.4*(1-k));ctx.restore();continue;}
      if(f.k==='puff'){const r=(1.2+2.6*k)*f.s;puffAt(f.x-1.5*k,f.y-3*k,r,.55*(1-k),k<.15?'#ffb860':'#aab4bd');continue;}}
    for(const M of g.missiles||[]){const u=Math.min(1,M.t/M.T),du=.02;const nx=M.x0+(M.tx-M.x0)*Math.min(1,u+du),nh=(1-Math.min(1,u+du))*23+46*Math.sin(Math.PI*Math.min(1,u+du));
      const y=M.gyNow-M.hgt,ang=Math.atan2(-(nh-M.hgt),nx-M.x);ctx.save();ctx.translate(M.x,y);ctx.rotate(ang);
      ctx.fillStyle='#2f3a33';ctx.fillRect(-3.5,-1,6,2);ctx.fillStyle='#6f8a63';ctx.fillRect(-3,-1,4.5,1);ctx.fillStyle='#c84a2a';ctx.fillRect(2.5,-1,1.5,2);ctx.fillStyle='#1d2420';ctx.fillRect(-4.5,-1.8,1.5,3.6);   // body, stripe, red nose, fins
      ctx.globalCompositeOperation='lighter';glow(ctx,-5,0,2.2,'#ff9a30',.7);glow(ctx,-4.6,0,1,'#fff0b0',1);ctx.restore();}
    for(const N of g.nades||[]){const y=N.gyNow-N.hgt;ctx.save();ctx.translate(N.x,y);ctx.rotate(N.t*14);ctx.fillStyle='#3d4a40';ctx.fillRect(-1.5,-1.5,3,3);ctx.fillStyle='#9aa69a';ctx.fillRect(-1.5,-1.5,1,1);ctx.restore();
      if(Math.random()<.5)puffAt(N.x,y,.9,.5);}
    for(const S of g.clouds||[]){if(S.A&&S.A.sprite&&ATLAS.smoke){const M=ATLAS.smoke,k=S.t/S.life,sc=S.r*2.1/120,sd=S.seed||0;   /* 0.12.199 (Kyle): the pack's smoke: puffs up, then the full-cloud middle frames are reused as slow, drifting, mirrored variations so it hangs there, then it thins out */
        if(S.t<.9){drawUnit(ctx,M,Math.min(13,Math.floor(S.t/.9*14)),S.x,S.gy+3,sc,.9,0,0,false);continue;}
        if(k>=.86){const fr=Math.min(M.n-1,18+Math.floor((k-.86)/.14*4));drawUnit(ctx,M,fr,S.x,S.gy+3,sc,.9,0,0,(sd%2)===1);continue;}
        const L=[[0,0,1,.9,.35],[-.42,1.5,.72,.7,.5],[.4,1,.68,.65,.62]];ctx.save();
        for(let i=0;i<L.length;i++){const [ox,oy,ss,al,sp]=L[i];const ph=g.t*sp+sd*.37+i*1.7,a=Math.floor(ph),u=ph-a;const f1=13+(a+i)%5,f2=13+(a+i+1)%5,fl=((a+i+sd)%2)===1,dx=Math.sin(g.t*.4+i*2)*2;
          drawUnit(ctx,M,f1,S.x+ox*S.r+dx,S.gy+3+oy,sc*ss,al*(1-u),0,0,fl);drawUnit(ctx,M,f2,S.x+ox*S.r+dx,S.gy+3+oy,sc*ss,al*u,0,0,!fl);}
        ctx.restore();continue;}   /* 0.12.199 the Soldier's smoke: the pack's own cloud sprite, puffing up, hanging, then thinning out */
      const k=S.t/S.life,grow=Math.min(1,S.t/.45),fade=k>.8?(1-k)/.2:1;let sd=S.seed;const rnd=()=>{sd=(sd*9301+49297)%233280;return sd/233280;};
      for(let i=0;i<26;i++){const a=rnd()*6.28,rr=Math.sqrt(rnd())*S.r*grow,ox=Math.cos(a)*rr+Math.sin(g.t*.8+i)*2,oy=Math.sin(a)*rr*.32-6-rnd()*10*grow+Math.cos(g.t*.6+i)*1.2;
        const r=(4+rnd()*5)*grow*(k>.8?.7+.3*fade:1);if(k>.8&&rnd()<(1-fade))continue;puffAt(S.x+ox,S.gy+oy,r,.62*fade,i%3?'#b8c2ca':'#9aa6b0');}}};
  const darkFx=()=>{
    for(const f of g.fx){const k=f.t/f.life;
      if(f.k==='dread'){ctx.save();ctx.globalAlpha=(1-k)*.8;ctx.strokeStyle='#8a3cff';ctx.lineWidth=1.5;ctx.beginPath();ctx.ellipse(f.x,f.gy-2,f.r*k,f.r*k*.3,0,0,7);ctx.stroke();
        ctx.globalCompositeOperation='lighter';for(let i=0;i<6;i++){const a=i*1.05+k*2,rr=f.r*k*.8;ctx.fillStyle='rgba(170,90,255,.8)';ctx.fillRect(f.x+Math.cos(a)*rr,f.gy-8-Math.sin(a)*rr*.3-k*10,1.5,1.5);}ctx.restore();continue;}
      if(f.k==='soul'){const e=1-Math.pow(1-k,2),x=f.x+(f.tx-f.x)*e,y=f.y+(f.ty-f.y)*e-Math.sin(Math.PI*k)*10;ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,x,y,3,'#a060ff',.5*(1-k*.5));glow(ctx,x,y,1.2,'#f0d8ff',.9);ctx.restore();continue;}}
    for(const e of g.enemies){if(e.dead)continue;const y=(e.gy!=null?e.gy:g.G)-12;
      if(e.hexT>0){ctx.save();ctx.globalCompositeOperation='lighter';for(let i=0;i<3;i++){const a=g.t*4+i*2.1;ctx.fillStyle='rgba(150,60,255,.75)';ctx.fillRect(e.x+Math.cos(a)*5,y-4+Math.sin(a*1.3)*6,1.2,1.2);}glow(ctx,e.x,y,6,'#6a20c0',.12);ctx.restore();}
      if(e.fearT>0){ctx.fillStyle='#c080ff';ctx.fillRect(Math.round(e.x)-.5,Math.round(y-18),1,3);ctx.fillRect(Math.round(e.x)-.5,Math.round(y-14),1,1);}}
    for(const h of g.alive())if(h.key==='cultist'&&!(h.riseT>0)){const d=h.face||1,ey=(h.gy||g.G)-14.6;ctx.save();ctx.globalCompositeOperation='lighter';for(const ox of[-.1,1.7])glow(ctx,g.heroX(h)+d*(1.2+ox),ey,1.3,'#ff2a20',.32+.12*Math.sin(g.t*3+ox));ctx.restore();}   // his eyes glow red in the dark
    for(const h of g.alive())if(h.defib){const x=Math.round(g.heroX(h)+(h.medkit?12:6)),y=Math.round((h.gy||g.G)-31);ctx.fillStyle='#202020';ctx.fillRect(x-1,y-1,5,5);ctx.fillStyle='#f2d23a';ctx.fillRect(x,y,3,3);ctx.fillStyle='#202020';ctx.fillRect(x+1,y,1,2);ctx.fillRect(x,y+1,1,1);ctx.fillRect(x+2,y+1,1,1);}   /* carrying a Defibrillator: a little yellow pad with a bolt */
    for(const h of g.alive())if(h.sandbag&&!h.sbThrow){const x=Math.round(g.heroX(h)-7),y=Math.round((h.gy||g.G)-31);ctx.fillStyle='#3a2c18';ctx.fillRect(x-1,y-1,6,5);ctx.fillStyle='#b89c68';ctx.fillRect(x,y,4,3);ctx.fillStyle='#8a7048';ctx.fillRect(x,y+1,4,.6);}   /* 0.12.104 carrying the Sandbag Wall: a little burlap bag */
    for(const h of g.alive())if(h.medkit){const x=Math.round(g.heroX(h)+6),y=Math.round((h.gy||g.G)-31);ctx.fillStyle='#202020';ctx.fillRect(x-1,y-1,5,5);ctx.fillStyle='#f2f2f2';ctx.fillRect(x,y,3,3);ctx.fillStyle='#e02020';ctx.fillRect(x+1,y,1,3);ctx.fillRect(x,y+1,3,1);}   /* carrying an ambulance Medkit */
    for(const h of g.alive()){if(h.kit&&h.kit.length){const y=(h.gy||g.G)-30;h.kit.forEach((it,i)=>{const x=g.heroX(h)-3+i*3;if(it==='med'){ctx.fillStyle='#f0f0f0';ctx.fillRect(x,y-1,2,2);ctx.fillStyle='#e02020';ctx.fillRect(x+.5,y-.5,1,1);}else{ctx.fillStyle='#ffd23f';ctx.fillRect(x,y-1.5,1.5,2.5);ctx.fillStyle='#404040';ctx.fillRect(x+.2,y-2,1,.6);}});}
      if(h.herbs>0){const y=(h.gy||g.G)-30;for(let i=0;i<h.herbs;i++){const x=g.heroX(h)-3+i*3;ctx.fillStyle='#2e7a2a';ctx.fillRect(x,y,2,1.5);ctx.fillStyle='#8fe36a';ctx.fillRect(x,y-.6,1.2,1);}}   // Scavenger: herbs carried
      if(h.herbT>0&&Math.random()<.4){ctx.fillStyle='rgba(140,230,110,.8)';ctx.fillRect(g.heroX(h)-5+Math.random()*10,(h.gy||g.G)-6-Math.random()*16,1,1);}}
    for(const f of g.fx)if(f.k==='herbget'){const k=f.t/f.life;ctx.save();ctx.globalAlpha=1-k;ctx.fillStyle={med:'#f2f2f2',bat:'#7fe0ff',defib:'#f2d23a'}[f.kit]||'#8fe36a';ctx.fillRect(f.x-1,f.y-k*6,3,2);ctx.fillStyle='#2e7a2a';ctx.fillRect(f.x,f.y-k*6+1,1,2);ctx.restore();}
    for(const h of g.alive()){const A=h.search?[h.search.t,h.search.T||1.5,h.search.trap||h.search.disarm?'#9ad0ff':'#e8ecf2','#8a92a0']:h.setting?[h.setting.t,h.setting.T,'#ffc070','#a06030']:h.planting?[h.planting.t,h.planting.T,'#ffc070','#a06030']:null;if(!A)continue;   /* 0.12.55: one progress bar for every timed action: searching (silver), defusing / alarms (blue), planting (amber) */
      const k=Math.min(1,A[0]/A[1]),x=Math.round(g.heroX(h)+8),y0=Math.round((h.gy||g.G)-14),H=12;ctx.fillStyle='#000b';ctx.fillRect(x-1,y0-H-1,4,H+2);const f=Math.round(H*k);const gr=ctx.createLinearGradient(x,0,x+2,0);gr.addColorStop(0,A[2]);gr.addColorStop(1,A[3]);ctx.fillStyle=gr;ctx.fillRect(x,y0-f,2,f);}   // searching: a silver bar rising beside him
    for(const h of g.alive())if(h.shellT>0){ctx.save();ctx.globalAlpha=.55;ctx.fillStyle='#3e7a3a';ctx.beginPath();ctx.ellipse(g.heroX(h),(h.gy||g.G)-9,10,10,0,Math.PI,0);ctx.fill();ctx.strokeStyle='#9be07a';ctx.lineWidth=1;ctx.stroke();ctx.restore();}   // Shell Up
    for(const e of g.enemies)if(!e.dead&&e.webT>0){e.webT-=1/60;const y=(e.gy!=null?e.gy:g.G)-10;ctx.save();ctx.strokeStyle='rgba(235,240,255,.7)';ctx.lineWidth=.6;for(let i=0;i<4;i++){const a=i*.8;ctx.beginPath();ctx.moveTo(e.x-6*Math.cos(a),y-6*Math.sin(a));ctx.lineTo(e.x+6*Math.cos(a),y+6*Math.sin(a));ctx.stroke();}ctx.restore();}   // webbed
    for(const h of g.alive())if(h.pactT>0){const gy=h.gy||g.G,p=.5+.5*Math.sin(g.t*8);ctx.save();ctx.globalAlpha=Math.min(1,h.pactT)*(.45+.3*p);ctx.strokeStyle='#d0202a';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(g.heroX(h),gy,9,2.4,0,0,7);ctx.stroke();ctx.restore();}};
  if(g.nailFields)for(const F of g.nailFields){const al=Math.min(1,F.t/.6);ctx.save();ctx.globalAlpha=al;let r=F.seed;const n=Math.round((F.x1-F.x0)/3);for(let i=0;i<n;i++){r=(r*9301+49297)%233280;const q=r/233280;const x=F.x0+(F.x1-F.x0)*((i+q)/n),y=F.gy-1+(q-.5)*4;ctx.fillStyle='#9aa0aa';ctx.fillRect(Math.round(x),Math.round(y),2,1);ctx.fillStyle='#e8ecf2';ctx.fillRect(Math.round(x),Math.round(y),1,1);}ctx.restore();}   /* 0.12.211 nails on the ground */
  for(const h of g.alive())if(h.wallT>0){const fw=h.face||1,x=g.heroX(h)+fw*9,gy=h.gy||g.G,p=.6+.4*Math.sin(g.t*6);ctx.save();ctx.globalAlpha=.22*p;ctx.fillStyle='#c0303a';ctx.beginPath();ctx.ellipse(x,gy-16,4,17,0,0,7);ctx.fill();ctx.globalAlpha=.55*p;ctx.strokeStyle='#ff6a6a';ctx.lineWidth=.8;ctx.beginPath();ctx.ellipse(x,gy-16,4,17,0,fw>0?-1.4:1.7,fw>0?1.4:4.6);ctx.stroke();   /* 0.12.214 Shield_Wall: a crimson wall of force in front of the shield */
      if(h.wallDrag>0){for(let i=0;i<3;i++){ctx.globalAlpha=.7;ctx.fillStyle=Math.random()<.5?'#ffd27a':'#fff2c0';ctx.fillRect(x-fw*(2+Math.random()*4),gy-1-Math.random()*2,1,1);}ctx.globalAlpha=.35;ctx.fillStyle='#8a7a6a';ctx.beginPath();ctx.ellipse(g.heroX(h)-fw*4,gy-1,5+Math.random()*2,1.5,0,0,7);ctx.fill();}   // shield scraping the ground + dust at his feet while he drags forward
      ctx.restore();}
  for(const P of g.pools||[]){const cx=(P.x0+P.x1)/2,w=(P.x1-P.x0)/2;ctx.save();ctx.globalAlpha=P.fire>0?.9:Math.min(.85,(P.t||1)/2);ctx.fillStyle='#120e10';ctx.beginPath();ctx.ellipse(cx,P.gy,w,P.dz*.7,0,0,7);ctx.fill();ctx.fillStyle='rgba(120,90,160,.35)';ctx.beginPath();ctx.ellipse(cx-w*.3,P.gy-.6,w*.35,P.dz*.25,0,0,7);ctx.fill();   /* 0.12.216 oil pool: black and glossy, with a purple sheen */
      if(P.fire>0){ctx.globalAlpha=1;fireGlow(ctx,cx,P.gy-6,w+18,.35);
        if(ATLAS.smoke){const M=ATLAS.smoke,sk=(g.t*.25+P.seed)%1;drawUnit(ctx,M,14+Math.floor(sk*4),cx+Math.sin(g.t*.5+P.seed)*4,P.gy-18-sk*14,(w+10)/90,.28*(1-sk*.6),0,0,(Math.floor(P.seed)%2)===1);}
        const n=Math.max(2,Math.round(w*2/8));for(let i=0;i<n;i++){const x=P.x0+(P.x1-P.x0)*((i+.5)/n)+Math.sin(i*7.3+P.seed)*2,ph=g.t*1.25+i*.37+P.seed,hh=13+7*Math.abs(Math.sin(i*2.1+P.seed))+3*Math.sin(g.t*6+i);fireTongue(ctx,x,P.gy+1,hh,ph,(i+Math.floor(P.seed))%2===1);}
        for(let i=0;i<n-1;i++){const x=P.x0+(P.x1-P.x0)*((i+1)/n),ph=g.t*1.6+i*.51+P.seed*2;fireTongue(ctx,x,P.gy+2,8+3*Math.sin(g.t*7+i*3),ph,i%2===0,.85);}
        embers(ctx,g.t,cx,P.gy-10,w,Math.round(4+w/3),P.seed,40);}
      ctx.restore();}
  for(const B of g.barrels||[]){const x=Math.round(B.x+(B.wob>0?Math.sin(g.t*60)*.7:0)),y=Math.round(B.gy);ctx.save();ctx.fillStyle='rgba(0,0,0,.35)';ctx.beginPath();ctx.ellipse(x,y,5,1.5,0,0,7);ctx.fill();   /* 0.12.216 a rusty red oil drum with a hazard band, dented as it takes hits */
      ctx.fillStyle='#1a0c0a';ctx.fillRect(x-5,y-14,10,14);ctx.fillStyle='#8a2a1e';ctx.fillRect(x-4,y-13,8,12);ctx.fillStyle='#b8402a';ctx.fillRect(x-4,y-13,2,12);ctx.fillStyle='#5a1a12';ctx.fillRect(x+2,y-13,2,12);
      ctx.fillStyle='#e8c030';ctx.fillRect(x-4,y-9,8,2);ctx.fillStyle='#1a0c0a';for(let i=0;i<4;i++)ctx.fillRect(x-4+i*2+(i%2),y-9,1,2);ctx.fillStyle='#3a1410';ctx.fillRect(x-5,y-14,10,1);ctx.fillRect(x-5,y-5,10,1);ctx.fillStyle='#c8c0b0';ctx.fillRect(x+1,y-14,2,1);
      if(B.dmg>0&&!B.gone){const fr=Math.min(1,B.dmg/B.hp);ctx.fillStyle='#120e10';const sx=x+(B.side||1)*5;for(let i=0;i<1+Math.round(fr*3);i++){const q=(g.t*(2+fr*6)+i*.37)%1;ctx.fillRect(Math.round(sx+(B.side||1)*q*(3+fr*6)),Math.round(y-10+q*q*9),1,1+(fr>.6?1:0));}}   /* oil streaming out, a gush when it's about to go */
      if(B.dmg>0){ctx.fillStyle='#120e10';ctx.fillRect(x-1,y-11,1,1);if(B.dmg>12)ctx.fillRect(x+1,y-6,1,1);if(B.dmg>20){ctx.fillStyle='#ff9a40';ctx.fillRect(x-2,y-12,1,1);}}ctx.restore();}
  if(g.radio&&g.radio.x>-12){const R=g.radio,x=Math.round(R.x),y=Math.round(R.gy),live=R.state==='idle'||R.state==='playing';ctx.save();   /* 0.12.217 the hidden radio: a small dented boombox, antenna up; it glows while it talks, then sparks and goes dark */
      ctx.globalAlpha=R.state==='dead'?.7:R.state==='idle'?.72:.95;ctx.fillStyle='#1a1614';ctx.fillRect(x-5,y-6,10,6);   /* 0.12.394: a little dimmer */ctx.fillStyle=R.state==='dead'?'#3a3430':'#4a4038';ctx.fillRect(x-4,y-5,8,4);ctx.fillStyle='#22201c';ctx.fillRect(x-3,y-4,2,2);ctx.fillRect(x+1,y-4,2,2);
      ctx.fillStyle='#8a8070';ctx.fillRect(x-4,y-9,1,3);ctx.fillRect(x-5,y-11,1,2);
      if(R.state==='playing'){const p=.5+.5*Math.sin(g.t*20);ctx.fillStyle=`rgba(120,255,140,${.6+.4*p})`;ctx.fillRect(x-1,y-5,2,1);ctx.globalAlpha=.25*p;ctx.fillStyle='#9affb0';ctx.beginPath();ctx.arc(x,y-3,7,0,7);ctx.fill();}
      else if(R.state==='idle'&&Math.floor(g.t*1.3)%5===0){ctx.fillStyle='#7aff9a';ctx.fillRect(x-1,y-5,1,1);}   // a faint blink now and then: the clue
      if(R.state!=='dead'){ctx.globalAlpha=1;const gc=g.st.biome.id==='city'?['#2a3442','#3a4656']:['#2c4a2a','#3e5e34','#55703c'];for(let i=0;i<9;i++){const bx=x-6+i*1.5,h=2+((i*7)%4);ctx.fillStyle=gc[i%gc.length];ctx.fillRect(bx,y-h,1,h);}}   /* 0.12.394 (Kyle): tucked behind a weed tuft (a rubble/trash pile downtown) */
      else if(R.state==='dying'&&Math.random()<.5){ctx.fillStyle=Math.random()<.5?'#ffe08a':'#fff';ctx.fillRect(x-4+Math.random()*8,y-8+Math.random()*6,1,1);}
      ctx.restore();}
  const iaiWaves=()=>{for(const W of (g.waves||[])){const x=W.x,y=W.gy-14,d=W.dir,fade=Math.min(1,W.left/20+.25);ctx.save();   /* 0.12.236 Cheez: the Iaijutsu wave, a cyan crescent with a trail */
      for(let k=0;k<3;k++){const tx=x-d*k*7;ctx.globalAlpha=fade*(.18-.05*k);ctx.fillStyle='#3af0ff';ctx.beginPath();ctx.ellipse(tx,y,5,15-k*2,0,d>0?-Math.PI/2:Math.PI/2,d>0?Math.PI/2:Math.PI*1.5);ctx.fill();}
      ctx.globalAlpha=fade*.9;ctx.strokeStyle='#3af0ff';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(x,y,5,14,0,d>0?-Math.PI/2:Math.PI/2,d>0?Math.PI/2:Math.PI*1.5);ctx.stroke();
      ctx.strokeStyle='#e8ffff';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(x+d,y,4,12,0,d>0?-Math.PI/2:Math.PI/2,d>0?Math.PI/2:Math.PI*1.5);ctx.stroke();ctx.restore();}};
  const banners=()=>{for(const B of (g.banners||[])){const x=Math.round(B.x),y=Math.round(B.gy),fade=Math.min(1,B.t/.6,(B.T-B.t)/.3+.2);ctx.save();ctx.globalAlpha=fade;   /* 0.12.234 Cheez: Host_With_The_Most neon DICE BOYS banner: a still pole, the cloth waves */
      ctx.globalAlpha=fade*.1;ctx.fillStyle='#8cff46';ctx.beginPath();ctx.ellipse(x,y-1,B.r,6,0,0,Math.PI*2);ctx.fill();ctx.globalAlpha=fade;
      ctx.fillStyle='#2a2a36';ctx.fillRect(x,y-44,2,44);ctx.fillStyle='#3af0ff';ctx.fillRect(x,y-45,2,1);ctx.fillRect(x-1,y-46,4,1);
      const W=26,Hh=12;for(let i=0;i<W;i++){const o=Math.round(Math.sin(g.t*5-i*.35)*1.5*(i/W));ctx.fillStyle=i%2?'#0c2410':'#102c14';ctx.fillRect(x+2+i,y-43+o,1,Hh);ctx.fillStyle='#8cff46';ctx.fillRect(x+2+i,y-43+o,1,1);ctx.fillRect(x+2+i,y-44+Hh+o,1,1);}
      ctx.fillStyle='#3af0ff';ctx.font='bold 5px monospace';ctx.textBaseline='middle';const txt=['DICE','BOYS'];txt.forEach((t,j)=>{for(let c=0;c<t.length;c++){const cx=x+5+c*5,o=Math.round(Math.sin(g.t*5-(cx-x)*.35)*1.5*((cx-x)/W));ctx.fillText(t[c],cx,y-40+j*6+o);}});
      ctx.restore();}};
  const druidFx=()=>{for(const f of g.fx){const k=f.t/f.life;
      if(f.k==='smash'){const R=f.r*Math.min(1,k/.35),a=1-k;ctx.save();   /* 0.12.236 Warhound jetpack landing: a dust-and-rock ground smash */
        ctx.globalAlpha=a*.55;ctx.strokeStyle='#d9c7a0';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(f.x,f.gy,R,R*.22,0,0,Math.PI*2);ctx.stroke();
        ctx.globalAlpha=a*.25;ctx.fillStyle='#8a7a5c';ctx.beginPath();ctx.ellipse(f.x,f.gy,R*.85,R*.18,0,0,Math.PI*2);ctx.fill();ctx.restore();
        for(let i=0;i<14;i++){const ang=i/14*Math.PI*2+f.x,d=R*(.35+.6*((i*37%10)/10)),px=f.x+Math.cos(ang)*d,py=f.gy+Math.sin(ang)*d*.22-Math.sin(Math.min(1,k*1.4)*Math.PI)*(4+i%4*2);puffAt(px,py-2,(1.6+2.4*k)*(1+(i%3)*.3),.5*(1-k),i%2?'#b9a27a':'#9c8a68');}
        ctx.globalAlpha=Math.max(0,1-k*1.6);ctx.fillStyle='#5a4a36';for(let i=0;i<10;i++){const dir=i%2?1:-1,px=f.x+dir*R*k*(.4+(i%5)*.15),py=f.gy-6-Math.sin(k*Math.PI)*(8+i%4*3);ctx.fillRect(Math.round(px),Math.round(py),1+(i%2),1+(i%2));}ctx.globalAlpha=1;continue;}
      if(f.k==='iaicut'){const a=1-k;ctx.save();ctx.globalAlpha=a;ctx.fillStyle='#3af0ff';const x0=Math.min(f.x0,f.x1),w=Math.abs(f.x1-f.x0);ctx.fillRect(x0,f.gy,w,1);ctx.globalAlpha=a*.4;ctx.fillRect(x0,f.gy-1,w,3);ctx.globalAlpha=a*.8;ctx.fillStyle='#fff';ctx.fillRect(x0+w*k,f.gy,Math.max(2,w*.2*(1-k)),1);ctx.restore();continue;}   /* 0.12.234 Iaijutsu: a thin cyan cut line through the lane */
      if(f.k==='chopwave'){const d=f.dir,front=Math.min(1,k/.55)*f.len,gy=f.gy;ctx.save();   /* 0.12.222 Ground_Chop: a tall wave of torn earth racing ahead: jagged rock spikes erupt at the front and crumble behind it, dust and chunks fly */
        const N=Math.ceil(f.len/3);for(let i=0;i<N;i++){const px=i*3;if(px>front)break;const age=(front-px)/f.len,life=Math.max(0,1-age*2.2-(k>.7?(k-.7)/.3:0));if(life<=0)continue;
          const hgt=(11+((i*7+f.seed)%5)*3.6)*life*(px>front-6?1.3:1),x=f.x0+d*px;ctx.globalAlpha=Math.min(1,life*1.4);
          ctx.fillStyle='#1a0e08';ctx.beginPath();ctx.moveTo(x-2.8,gy);ctx.lineTo(x+d*.8,gy-hgt);ctx.lineTo(x+2.8,gy);ctx.fill();ctx.fillStyle='#c8925a';ctx.beginPath();ctx.moveTo(x-1.6,gy);ctx.lineTo(x+d*.8,gy-hgt+1.5);ctx.lineTo(x+.6,gy);ctx.fill();ctx.fillStyle='#ffe0b0';ctx.fillRect(Math.round(x+d*.4),Math.round(gy-hgt+1),1,1);}
        const fx=f.x0+d*front;if(k<.6){glow(ctx,fx,gy-10,14,'#ffb060',.35*(1-k/.6));ctx.globalAlpha=.55*(1-k/.6);ctx.fillStyle='#c8a878';ctx.beginPath();ctx.ellipse(fx,gy-3,7,5,0,0,7);ctx.fill();ctx.globalAlpha=.35;ctx.strokeStyle='#ffe0a0';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(fx,gy-8,3,10,0,0,7);ctx.stroke();
          for(let j=0;j<5;j++){const r=((j*53+f.seed*7)%97)/97,q=(k*3+r)%1;ctx.globalAlpha=1-q;ctx.fillStyle=j%2?'#6a4a30':'#b08860';ctx.fillRect(Math.round(fx-d*q*6+(r-.5)*8),Math.round(gy-4-q*16*(.6+r)),2,2);}}
        ctx.restore();continue;}
      if(f.k==='toolbox'){const u=Math.min(1,k),x=f.x0+(f.x1-f.x0)*u,y=(f.gy0+(f.gy1-f.gy0)*u)-16-Math.sin(Math.PI*u)*22;ctx.save();ctx.translate(x,y);ctx.rotate(u*9*(f.x1>=f.x0?1:-1));   /* 0.12.207 Edward's Toolbox_Toss: a red toolbox tumbling end over end */
        ctx.fillStyle='#1a0c0c';ctx.fillRect(-4.5,-3,9,6);ctx.fillStyle='#c0302a';ctx.fillRect(-4,-2.5,8,5);ctx.fillStyle='#e85a4a';ctx.fillRect(-4,-2.5,8,1);ctx.fillStyle='#9aa0a8';ctx.fillRect(-1.5,-4,3,1.2);ctx.fillRect(-.5,-.5,1,1);ctx.restore();continue;}
      if(f.k==='fswipe'){const d=f.dir,e=1-Math.pow(1-Math.min(1,k/.5),3),al=k<.55?1:Math.max(0,1-(k-.55)/.45),cx=f.x,cy=f.gy-13,R=f.r;   /* 0.12.201 Fireman cleave: a big vicious crescent with gore streaks */
        ctx.save();ctx.globalAlpha=al;const a0=-1.25,a1=a0+2.5*e;const A0=d>0?a0:Math.PI-a0,A1=d>0?a1:Math.PI-a1;
        for(const [w,col,rr] of [[6,'rgba(90,10,10,.55)',R],[3.6,'rgba(220,60,30,.8)',R-1],[1.4,'rgba(255,220,180,.95)',R-1.5],[1,'rgba(160,20,20,.8)',R*.72]]){ctx.strokeStyle=col;ctx.lineWidth=w;ctx.lineCap='round';ctx.beginPath();ctx.ellipse(cx,cy,rr,rr*.62,0,Math.min(A0,A1),Math.max(A0,A1));ctx.stroke();}
        if(k>.25){ctx.fillStyle='rgba(170,10,20,'+(.9*al)+')';for(let i=0;i<7;i++){const q=(i*37%11)/11,aa=a0+2.5*q,ex=cx+d*Math.cos(aa)*R*(1+.25*k),ey=cy+Math.sin(aa)*R*.62+k*6;ctx.fillRect(ex,ey,1.3,1.3);}}
        ctx.restore();continue;}
      if(f.k==='claw'){const d=f.dir,e=1-Math.pow(1-Math.min(1,k/.55),3);const span=Math.max(6,Math.abs(f.tx-f.x));const cx=f.x+d*(span*e),cy=f.gy-11-2*Math.sin(Math.PI*e);
        const s=(.55+.55*e)*(k>.7?1-(k-.7)/.3*.3:1),al=k<.7?1:Math.max(0,1-(k-.7)/.3);ctx.save();ctx.globalAlpha=al;ctx.globalCompositeOperation='lighter';
        glow(ctx,cx,cy,9*s,'#4dff7a',.28);
        ctx.lineCap='round';
        for(const [w,col] of [[2.4*s,'rgba(60,220,110,.55)'],[1.1*s,'rgba(200,255,200,.95)']]){ctx.strokeStyle=col;ctx.lineWidth=w;
          ctx.beginPath();ctx.ellipse(cx-d*2*s,cy,2.6*s,3.2*s,0,0,7);ctx.stroke();   // palm
          for(let i=0;i<4;i++){const oy=(i-1.5)*2.3*s;ctx.beginPath();ctx.moveTo(cx,cy+oy*.7);ctx.quadraticCurveTo(cx+d*4.5*s,cy+oy-1.2*s,cx+d*6.5*s,cy+oy+1.6*s);ctx.stroke();}}   // four hooked talons
        if(k>.45){const q=(k-.45)/.55;ctx.strokeStyle=`rgba(170,255,170,${.9*(1-q)})`;ctx.lineWidth=.9;for(let i=0;i<3;i++){const ox=f.tx+(i-1)*2.2;ctx.beginPath();ctx.moveTo(ox-d*2,f.gy-17+i);ctx.lineTo(ox+d*3,f.gy-6+i);ctx.stroke();}}   // three claw rakes on the target
        ctx.restore();continue;}
      if(f.k==='mend'){ctx.save();ctx.globalCompositeOperation='lighter';const y=f.gy-14-k*10;glow(ctx,f.x,y,8*(1-k)+3,'#5dff6a',.4*(1-k));ctx.fillStyle=`rgba(150,255,140,${1-k})`;ctx.fillRect(f.x-1,y-4,2,8);ctx.fillRect(f.x-4,y-1,8,2);ctx.fillStyle=`rgba(235,255,230,${1-k})`;ctx.fillRect(f.x-.5,y-.5,1,1);
        for(let i=0;i<5;i++){const a=i*1.26+f.t*3;ctx.fillStyle=`rgba(120,230,110,${.8*(1-k)})`;ctx.fillRect(f.x+Math.cos(a)*(6+k*6),f.gy-6-k*16-i*2,1,1);}ctx.restore();}
      if(f.k==='thorn'&&f.t>=0){const T=THORNS[f.v%4];const up=Math.min(1,f.t/.15),dn=k>.75?(1-k)/.25:1;const sc=.17*up;ctx.save();ctx.globalAlpha=dn;drawUnit(ctx,T,0,f.x,f.gy+1+(1-dn)*6,sc,null,0,0,false);ctx.restore();}}
    for(const h of g.alive())if(h.hotT>0){const el=8-h.hotT;const fr=el<1.2?Math.min(6,Math.floor(el/1.2*7)):4+Math.floor(g.t*5)%3;ctx.save();ctx.globalCompositeOperation='lighter';
      drawUnit(ctx,VINE,fr,g.heroX(h),(h.gy||g.G)+2,.11,h.hotT<.6?h.hotT/.6:.9,0,0,false);ctx.restore();}
    for(const T of g.cyclones||[]){const A=T.A,fr=T.t<A.dur?Math.floor(T.t*10)%10:Math.min(15,10+Math.floor((T.t-A.dur)/.35*6));ctx.save();ctx.globalCompositeOperation='lighter';
      drawUnit(ctx,TORN,fr,T.x,T.gy+2,.36,1,0,0,false);ctx.restore();}};
  const poultices=()=>{for(const h of g.alive())if(h.poulticeT>0){ctx.save();ctx.globalCompositeOperation='lighter';for(let i=0;i<4;i++){const ph=((g.t*.8+i*.25)%1);ctx.fillStyle=`rgba(150,235,130,${.8*(1-ph)})`;ctx.fillRect(g.heroX(h)-5+i*3,(h.gy||g.G)-8-ph*16,1.5,1.5);}ctx.restore();}};
  /* 0.12.62 Warhound flamethrower: campfire flames (Kyle's fire art, logs cut off) pouring out in a widening cone, with a hot glow; burning enemies carry small flames */
  const blueFire=(x,gy,s,fr,a,down)=>{const IM=XIMG.camp;if(!IM||!IM.complete)return;if(!XIMG._blueCamp){try{const c=document.createElement('canvas');c.width=IM.width;c.height=IM.height;const cx=c.getContext('2d');cx.drawImage(IM,0,0);const D=cx.getImageData(0,0,c.width,c.height),p=D.data;
      for(let i=0;i<p.length;i+=4){const r=p[i],gg=p[i+1],b=p[i+2];p[i]=b*.6;p[i+1]=gg*.85;p[i+2]=Math.min(255,r*1.1+30);}cx.putImageData(D,0,0);XIMG._blueCamp=c;}catch(e){XIMG._blueCamp=IM;}}   /* 0.12.67: Kyle's campfire flames, recoloured blue for the jetpack */
    ctx.save();ctx.globalAlpha=a;if(down){ctx.translate(x,gy);ctx.scale(1,-1);ctx.translate(-x,-gy);}ctx.drawImage(XIMG._blueCamp,fr*34+3,0,28,27,x-14*s,gy-27*s,28*s,27*s);ctx.restore();};   // down: the flame points down (jet exhaust)
  const fireBit=(x,gy,s,fr,a)=>{const IM=XIMG.camp;if(!IM||!IM.complete)return;ctx.save();ctx.globalAlpha=a;ctx.drawImage(IM,fr*34+3,0,28,27,x-14*s,gy-27*s,28*s,27*s);ctx.restore();};
  /* 0.12.77 (Kyle's flamethrower sheet, crawl_flame.png): 15 frames, 290x200 each, nozzle at (22,156): 5 ignite, 5 full burst, 5 dying off.
     Scaled so the burst reaches the flame's length, anchored on the nozzle (the Warhound's) or in front of the Fireman_Zombie, mirrored when facing left */
  const flames=()=>{const IM=XIMG.flame;for(const f of g.fx){if(f.k!=='flame')continue;const k=Math.min(.999,f.t/f.life),src=f.src;
      let x0,y0;if(src&&src.alive&&src.key==='robot'){x0=g.heroX(src)+f.dir*13;y0=(src.gy||G)-13.5;}else{x0=src&&!src.dead&&src.x!=null?src.x+f.dir*12:f.x;y0=f.gy-12;}f.x=x0;
      const fi=k<.2?Math.floor(k/.2*5):k<.72?5+Math.floor((k-.2)/.52*10)%5:10+Math.min(4,Math.floor((k-.72)/.28*5));
      if(IM&&IM.complete&&IM.naturalWidth){const s=f.len/205;ctx.save();ctx.translate(x0,y0);const dn=Math.max(0,(f.gy-y0));const ang=Math.min(.45,.216*dn/13.5);ctx.rotate(f.dir*ang);ctx.scale(f.dir*s,s*.62);ctx.drawImage(IM,fi*290,0,290,200,-22,-156,290,200);ctx.restore();}}   // 0.12.78: from the barrel, angled so the bottom of the burst just touches the ground of his lane
    for(const e of g.enemies)if(e.fb&&!e.dead){const fr=4+Math.floor(g.t*10+e.phase*3)%4;fireBit(e.x+Math.sin(g.t*7+e.phase)*2,(e.gy!=null?e.gy:G)-14,.32,fr,.85);fireBit(e.x-3,(e.gy!=null?e.gy:G)-4,.22,(fr+2)%4+4,.7);}};
  /* 0.12.66 JP: the doobie (a little white joint at his mouth burning down over the 2s, glowing ember), smoke puffs drifting off him,
     a green haze while he's HIGH, a dust trail while he rushes to family, and his shield glinting during Trash_Talk */
  const jpFx=()=>{for(const h of g.heroes){if(h.key!=='jp'||!h.alive)continue;const gy=h.gy||G,dir=(h.face||1)>0?1:-1,mx=h.x+dir*2.2,my=gy-16.4;
      if(h.smoking){const k=Math.min(1,h.smoking.t/2),L=3.4*(1-k*.6);ctx.fillStyle='#f4efe4';ctx.fillRect(Math.min(mx,mx+dir*L),my,Math.abs(dir*L),.9);
        const fl=.6+.4*Math.sin(g.t*23);ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,mx+dir*L,my+.4,2.2,'#ff6a20',.5*fl);ctx.restore();ctx.fillStyle=fl>.7?'#ffd060':'#ff4a10';ctx.fillRect(mx+dir*L-.5,my,1,1);
        for(let i=0;i<5;i++){const p=((g.t*.7+i*.2)%1);ctx.globalAlpha=(1-p)*.55;ctx.fillStyle='#c8c8c0';const r=.8+p*2.6;ctx.beginPath();ctx.arc(mx+dir*(L+1)+Math.sin(g.t*2+i)*2+p*4*dir,my-1-p*14,r,0,7);ctx.fill();}ctx.globalAlpha=1;}
      if(h.highT>0){const p=.5+.5*Math.sin(g.t*1.7);ctx.globalAlpha=.18+.1*p;ctx.fillStyle='#9ad06a';for(let i=0;i<3;i++){const q=((g.t*.25+i/3)%1);ctx.beginPath();ctx.arc(h.x-3+i*3+Math.sin(g.t+i)*2,gy-22-q*10,1.4+q*2,0,7);ctx.fill();}ctx.globalAlpha=1;}
      if(h.rush){ctx.fillStyle='rgba(180,150,110,.5)';for(let i=0;i<4;i++)ctx.fillRect(h.x-dir*(4+i*3)+Math.sin(g.t*30+i)*1,gy-1-(i%2),2,1.5);}
      if(h.trashT>0){ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,h.x+dir*3,gy-14,6,'#ffb040',.25+.15*Math.sin(g.t*8));ctx.restore();}}};
  const logs=()=>{for(const L of g.logs||[]){const x=Math.round(L.x),y=L.gy,a=(L.x-L.x0)/5;ctx.save();ctx.translate(x,y-4);   /* 0.12.58 Log_Roll: a rolling log with dust behind it */
      ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(-7,3,14,2);ctx.fillStyle='#6b4423';ctx.fillRect(-7,-3,14,7);ctx.fillStyle='#8a5a30';ctx.fillRect(-7,-3,14,2);
      ctx.fillStyle='#c8a070';ctx.beginPath();ctx.ellipse(7,0.5,2,3.5,0,0,7);ctx.fill();ctx.strokeStyle='#7a4a20';ctx.lineWidth=.6;ctx.beginPath();ctx.ellipse(7,.5,1,2,0,0,7);ctx.stroke();
      ctx.fillStyle='#4a2c14';for(let i=0;i<3;i++){const px=((i*5-a*3)%14+14)%14-7;ctx.fillRect(px,-3,1,7);}ctx.restore();
      ctx.fillStyle='rgba(170,140,100,.5)';for(let i=0;i<4;i++){const ph=(g.t*3+i*.25)%1;ctx.fillRect(x-9-ph*10,y-2-ph*4,1.5,1.5);}}};
  const quakes=()=>{for(const f of g.fx)if(f.k==='quake'){if(f.chop){const k0=Math.min(1,f.t/(f.life*.7)),n=7;ctx.save();   /* 0.12.58 Ground_Chop: rock spikes burst up along the ground, running outward from the axe */
      for(let i=0;i<n;i++){const p=i/(n-1);if(p>k0)break;const life=1-Math.min(1,(k0-p)*2.2+f.t/f.life*.5);if(life<=0)continue;const sx=f.x-f.chop*f.w/2+f.chop*p*f.w,hh=(3+4*(1-p*.4))*life;ctx.fillStyle='#5a4228';ctx.beginPath();ctx.moveTo(sx-2.5,f.gy);ctx.lineTo(sx-.5,f.gy-hh);ctx.lineTo(sx+.6,f.gy-hh*.7);ctx.lineTo(sx+2.5,f.gy);ctx.fill();ctx.fillStyle='#b89060';ctx.fillRect(sx-.5,f.gy-hh,1,1.2);
        ctx.fillStyle=`rgba(190,160,110,${.6*life})`;ctx.fillRect(sx-3+((i*7)%5),f.gy-hh-2-(1-life)*4,1.5,1.5);ctx.fillRect(sx+1,f.gy-hh-4-(1-life)*6,1,1);}ctx.restore();}const k=f.t/f.life;ctx.save();ctx.globalAlpha=1-k;ctx.fillStyle='#8a6a40';
      for(let i=0;i<8;i++){const x=f.x-f.w/2+(i+.5)*f.w/8;ctx.fillRect(x-1,f.gy-1-Math.sin((k+i*.13)*Math.PI)*4,2,2);}ctx.strokeStyle='#c8a060';ctx.beginPath();ctx.moveTo(f.x-f.w/2,f.gy);ctx.lineTo(f.x+f.w/2,f.gy);ctx.stroke();ctx.restore();}};
  const booms=()=>{for(const f of g.fx){if(f.k==='strike'&&ATLAS.strike){const S=ATLAS.strike,k=f.t/f.life,fr=Math.min(S.n-1,Math.floor(k*S.n));ctx.save();ctx.globalCompositeOperation='lighter';ctx.filter='hue-rotate(180deg) saturate(1.6)';drawUnit(ctx,S,fr,f.x,f.gy+1,.6,k>.8?(1-k)/.2:1,0,0,false);ctx.restore();glow(ctx,f.x,f.gy-4,14,'#fff08a',.5*(1-k));continue;}   /* 0.12.178 Thunderclap: the pack's lightning strike, tinted yellow */
    if(f.k==='frag'&&ATLAS.frag){const F=ATLAS.frag,k=f.t/f.life,fr=Math.min(F.n-1,4+Math.floor(k*(F.n-4)));drawUnit(ctx,F,fr,f.x,f.gy+2,.52,k>.8?(1-k)/.2:1,0,0,false);continue;}   /* 0.12.175 frag blast: the pack's explosion */
    if(f.k!=='boom')continue;const k=f.t/f.life,fr=Math.min(BOOM.n-1,Math.floor(k*BOOM.n));drawUnit(ctx,BOOM,fr,f.x,f.gy+2,f.small?.17:.32,k>.85?(1-k)/.15:1,0,0,false);}};
  /* 0.12.107 Shadow_Clone: a see-through copy of Chibi with a faint purple glow, moving and swinging on its own */
  const drawClone=(c)=>{const h=c.owner;if(!h)return;const fade=Math.min(1,(c.life-c.t)/.4,c.t/.25);
    ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,c.x,c.gy-12,7,'#b066ff',.13*fade);glow(ctx,c.x,c.gy-12,3.5,'#d9a6ff',.08*fade);ctx.restore();
    const ghost=Object.assign({},h,{x:c.x,gy:c.gy,face:c.face,ghost:1,moving:c.moving,walkT:c.walkT,animM:c.animM,animT:c.animM>0?.35-c.animM:0,swingAnim:h.swingAnim||'attack1',leapH:0,bleedT:0,shield:0,shieldT:0,hotT:0,cozyT:0,stealthT:0,cloneT:0,smoking:null,dash:null,whirl:null,perch:null,sbThrow:null,climb:null,sandbag:0,medkit:0,defib:0,herbs:0,kit:[],hitFlash:0,downed:0,riseT:0,shoutT:0,rageT:0,courage:0});
    GHOST_A=.5*fade;try{drawHero(ghost);}finally{GHOST_A=1;}};
  /* 0.12.337 (Kyle: units look jaggy): the sprite only turns around once the unit has wanted the new direction for 0.18s, so split-second
     back-and-forth facing (aim checks, tiny steps around its spot) doesn't strobe the picture. Visual only. */
  const visFace=u=>{const f=(u.face||1)<0?-1:1;if(u.vFace==null)u.vFace=f;if(f!==u.vFace){if(u.vfS==null||u.vfS>g.t)u.vfS=g.t;if(g.t-u.vfS>=.18){u.vFace=f;u.vfS=null;}}else u.vfS=null;return u.vFace;};
  const drawHero=(h)=>{const G0=h.gy||g.G;ctx.save();shrinkAt(ctx,h.x,G0,HS*(h.sz||1));   /* 0.12.431 large dog breeds draw 22% bigger */const F0=h.face;h.face=visFace(h);try{drawHero0(h);}finally{h.face=F0;}ctx.restore();};
  const drawHero0=(h)=>{const G=h.gy||g.G;if(!h.alive){return;}
    if(h.bleedT>0){const p=.5+.5*Math.sin(g.t*10);ctx.save();ctx.globalCompositeOperation='lighter';
      for(let r=0;r<3;r++){const rr=((g.t*1.4+r/3)%1);ctx.strokeStyle=`rgba(220,20,40,${.55*(1-rr)})`;ctx.beginPath();ctx.ellipse(h.x,G-26,8+rr*14,(8+rr*14)*1.25,0,0,7);ctx.stroke();}
      glow(ctx,h.x,G-26,10+2*p,'#c0102a',.18);ctx.restore();
      for(let i=0;i<5;i++){const u2=((g.t*1.6+i*.21)%1);const dx=Math.round(h.x-7+((i*37)%15));const dy=Math.round(G-44+u2*42);ctx.fillStyle=u2<.15?'#ff3a4a':'#c0102a';ctx.fillRect(dx,dy,2,2);if(u2>.92){ctx.fillStyle='#7a0a16';ctx.fillRect(dx-1,G-1,3,1);}}}
    if(h.rageT>0){const p=.5+.5*Math.sin(g.t*9);ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,h.x,G-24,15+3*p,'#a0541c',.32);glow(ctx,h.x,G-24,8,'#ff8a30',.12+.08*p);   /* 0.12.58 Timber_Rage: a pulsing brown-orange glow and wood chips flying off him */
      for(let i=0;i<5;i++){const u2=((g.t*1.3+i*.2)%1);ctx.fillStyle=u2<.3?'#e0a060':'#8a5a2a';ctx.fillRect(Math.round(h.x-8+((i*29)%17)),Math.round(G-10-u2*40),1.5,1);}ctx.restore();}
    let fr=11;if(h.animT>0)fr=6+Math.min(2,Math.floor((.32-h.animT)/.107));else if(h.hitFlash>0)fr=9;else if(g.scroll)fr=Math.floor(h.walkT*9)%6;
    const ph=h.key.length*1.7;const wob=h.wanderX||0;const ly=Math.round(2+Math.sin(g.t*.7+ph)*2.5);
    const lx=(h.animT>0&&h.lunge?h.lunge*Math.sin(Math.PI*(1-h.animT/.32))*.9:0)+(h.dodgeX||0)+wob;if(h.dodging&&fr===11)fr=Math.floor(g.t*12)%6;
    ctx.save();ctx.translate(0,ly);
    if(SP['h_'+h.key+'_a']){   // partner pair: two fighters, each with its own animation
      const fa=h.animT>0?6+Math.min(2,Math.floor((.32-h.animT)/.107)):h.hitFlash>0?9:g.scroll?Math.floor(h.walkT*9)%6:11;
      const fb=h.animT2>0?6+Math.min(2,Math.floor((.32-h.animT2)/.107)):h.hitFlash>0?9:g.scroll?Math.floor(h.walkT*9+3)%6:11;
      const lb=h.animT2>0&&h.lunge2?h.lunge2*Math.sin(Math.PI*(1-h.animT2/.32))*.9:0;
      if(!h.style.companion){shadow(ctx,h.x-9+lx,G,8);spr(ctx,'h_'+h.key+'_a',fa,h.x-9+lx-32,G-60,false,null,h.hitFlash);}
      shadow(ctx,h.x+9+lb,G,8);spr(ctx,'h_'+h.key+'_b',fb,h.x+9+lb-32,G-60,false,null,h.hitFlash);
      if(h.style.companion){const cx=h.x+(h.compX||-12),cy=h.compY||0;const pf=h.pounce?7:(g.scroll||Math.abs(h.compV||0)>4?Math.floor(g.t*10)%6:fa);
        shadow(ctx,cx,G+4,7);spr(ctx,'h_'+h.key+'_a',h.animT>0?fa:pf,cx-32,G-60+4-cy,(h.compV||0)<-4&&!h.animT,null,0);}
    }else if(UNITS[h.skin||h.key]&&UNITS[h.skin||h.key].idle){shadow(ctx,h.x+lx,G,9);const U=UNITS[h.skin||h.key],C=h.base.char;let A=U.idle,f=Math.floor(g.t*(h.key==='druid'?5:6))%A.n;
      const mov=h.moving||g.scroll;
      let riseRot=0,rum=null,runLean=0,runBob=0;
      // 0.12.22 getting back up: his last death frame, then the death frames played backwards (falling ones rotate back upright), then idle
      if(h.riseT>0&&U.death){const D=U.death,k=1-h.riseT/(h.riseT0||1.1);
        if(k>.86){A=U.idle;f=0;}
        else{A=D;const q=Math.max(0,(k-.18)/.68);f=Math.max(0,D.n-1-Math.floor(q*D.n));if(D.fall)riseRot=((h.face||1)>0?1.45:-1.45)*Math.pow(1-Math.min(1,q*1.15),1.4);}}
      else if(h.summonT>0&&U.summon){A=U.summon;f=Math.min(A.n-1,Math.floor((1-h.summonT/(h.summonT0||.8))*A.n));}   // Void_Cultist: arms raised, both hands glowing
      else if((h.building||h.repairing)&&U.kneel){A=U.kneel;f=Math.min(A.n-1,2+Math.floor(g.t*6)%Math.max(1,A.n-2));}   // 0.12.75 Engineer: kneeling, working
      else if(h.jet&&U.jet){A=U.jet;f=Math.floor(g.t*10)%A.n;}   // 0.12.67 Warhound: Tactical_Retreat (legs tucked, jets lit)
      else if(h.nano&&U.use){A=U.use;f=Math.floor(g.t*6)%A.n;}
      else if(h.useT>0&&h.key==='shoshi'&&U.use){A=U.use;f=Math.floor(g.t*8)%A.n;}   // 0.12.110 Shoshi on his phone   // Nano-Tech Repair Bots: kneeling, bots swirling
      else if(h.lz&&U.ranged){const C2=h.base.char.ranged.lazer;A=U.ranged;f=h.lz.t<C2.charge?(h.lz.t<C2.charge/2?0:1):2+Math.floor(g.t*10)%2;}   // Targeted Lazer: lens charges, then burns
      else if(h.gat&&U.ranged){A=U.ranged;f=Math.floor(g.t*24)%A.n;}   // Moss_Mech's gatling: barrels spinning, muzzle flashing
      else if(h.launchT>0&&U.missile){A=U.missile;f=Math.min(A.n-1,1+Math.floor(g.t*8)%3);}
      else if(h.wallT>0&&U.defend){A=U.defend;f=h.wallDrag>0?A.n-1-(Math.floor(g.t*8)%2):Math.min(A.n-1,2+Math.floor(g.t*4)%Math.max(1,A.n-2));}   /* 0.12.180 Crimson_Knight: Shield_Wall */
      else if(h.charge&&U.runatk){A=U.runatk;f=Math.floor(g.t*14)%A.n;}   /* Crimson_Charge */
      else if(h.kleap&&U.jump){A=U.jump;f=Math.min(A.n-1,Math.floor(h.kleap.t/.6*A.n));}   /* Leap_Strike */
      else if(h.key==='soldier'&&h.cast&&U.reload){A=U.reload;f=Math.min(A.n-1,Math.floor(h.cast.t/h.cast.T*A.n));}   /* 0.12.200 Ammo_Drop: his Recharge animation while he sets the crate down */
      else if(h.nstrip&&U.shot2){A=U.shot2;f=Math.floor(g.t*16)%A.n;}   /* 0.12.211 Edward's Nail_Strip */
      else if(h.supp&&U.shot2){A=U.shot2;f=Math.floor(g.t*16)%A.n;}   /* 0.12.199 Soldier: Suppressing_Fire (sighted-in stance, muzzle flashing) */
      else if(h.cast&&h.cast.anim&&U[h.cast.anim]){A=U[h.cast.anim];f=Math.min(A.n-1,Math.floor(h.cast.t/h.cast.T*A.n));}   /* casting animations */
      else if(h.iaiA&&U.iai){const I=h.iaiA,H=.25;if(I.t<H){A=U.iai;f=Math.min(A.n-1,Math.floor(I.t/H*A.n));}else{A=U.draw||U.melee;f=Math.min(A.n-1,3+Math.floor((I.t-H)/.2*2));}}   /* 0.12.234 Cheez: Iaijutsu sheathe-hold then the draw */
      else if(h.sipT>0&&U.sake){A=U.sake;f=Math.floor(g.t*6)%A.n;}   /* Cheez: Sake_Break swig */
      else if(h.throwT>0&&U.throw){A=U.throw;f=Math.min(A.n-1,Math.floor((1-h.throwT/(h.throwT0||.45))*A.n));}
      else if(h.dash&&U.runatk){A=U.runatk;f=Math.min(A.n-1,3+Math.floor(h.dash.t/h.dash.T*2));}
      else if(h.animM>0){A=(h.swingAnim&&U[h.swingAnim])||U.melee;const D=h.swingAnim==='attack2'?.36:.45;f=Math.min(A.n-1,Math.floor((1-h.animM/D)*A.n));}
      else if(h.aimHold>0&&U.ranged){A=rTilt(h,U);f=0;}   /* 0.12.163 holding the aim before the shot */
      else if(h.animR>0&&h.firedMoving&&!U.walkfire&&h.key==='edward'&&mov){A=(h.running&&U.run)||U.walk;f=Math.floor(g.t*(h.running?12:8))%A.n;}   /* 0.12.223 (Kyle): Edward fires on the move (no accuracy loss), so he keeps his walk/run legs going instead of sliding in the firing pose */
      else if(h.animR>0){A=(h.firedMoving&&!h.aimTilt&&U.walkfire)||rTilt(h,U);f=Math.min(A.n-1,Math.floor((1-h.animR/(h.animRT||.5))*A.n));}
      else if((h.casting>0||h.animC>0)&&h.key==='druid'){A=U.ranged;f=1;}   // staff raised, tip glowing
      else if(h.volley>0&&U.ranged){A=U.ranged;f=Math.min(2,Math.floor((1-h.volley/(h.volleyT0||.6))*3));}   // draws and looses high
      else if(h.blowing>0&&U.blowgun){A=U.blowgun;f=Math.min(A.n-1,Math.floor((1-h.blowing/(h.blowT0||.7))*A.n));}
      else if(h.whirl&&U.spin){A=U.spin;f=Math.floor(g.t*16)%A.n;}
      else if(h.leap&&U.leap){A=U.leap;const k=h.leap.t/.6;f=Math.min(A.n-1,k<.18?0:k<.82?2:3);}   /* 0.12.302 (Kyle): one clean jump: crouch, fly, slam (the spin-blur frame read like a double jump) */
      else if(h.rolling&&U.roll){A=U.roll;f=Math.min(A.n-1,Math.floor(h.rolling.t/.6*A.n));}
      else if(h.chopping>0&&U.chop){A=U.chop;f=Math.min(A.n-1,Math.floor((1-h.chopping/(h.chopT0||.5))*A.n));}
      else if(h.rageAnim>0&&U.rage){h.rageAnim-=1/60;A=U.rage;f=Math.min(A.n-1,Math.floor((1-h.rageAnim/.7)*A.n));}
      else if(h.camping>0&&U.kneel){A=U.kneel;f=Math.min(A.n-1,Math.floor((1-h.camping/(h.campT0||1.8))/.78*A.n));}   // kneel, flick the lighter
      else if(h.cast){A=U.ranged;f=0;}
      else if(h.tossing&&U[h.tossing.kind]){A=U[h.tossing.kind];f=Math.min(A.n-1,Math.floor(h.tossing.t/h.tossing.T*A.n));}   // 0.12.58 Proximity_Bomb toss / throw
      else if(h.setting){A=U.reload;f=Math.min(A.n-1,Math.floor(h.setting.t/h.setting.T*A.n));}   // kneels to set the Trip Bomb   // holding the aim during Aimed Shot's cast
      else if((h.search||h.planting)&&U.idle&&!(h.setting&&U.reload)){A=U.idle;f=Math.floor(g.t*3)%A.n;rum=h.search||{o:{x:h.planting.x},t:0};}   /* 0.12.37: rummaging (built from his idle frames, bent over and digging) */
      else if(h.hitFlash>0){A=U.hurt;f=Math.min(A.n-1,Math.floor((1-h.hitFlash/.12)*A.n));}
      else if(C&&C.ranged&&U.reload&&h.ammo<=0&&!mov){A=U.reload;f=Math.min(A.n-1,Math.floor((h.reloadT||0)/C.ranged.reload*A.n));}
      else if(mov){A=(h.running&&U.run)||U.walk;f=Math.floor(g.t*(h.running?12:h.key==='lumberjack'?9:8))%A.n;
        if(h.running&&!U.run&&A.n>1){f=Math.floor(g.t*15)%A.n;runLean=((h.face||1)>0?1:-1)*.06;runBob=-Math.abs(Math.sin(g.t*15*Math.PI*2/A.n))*.7;}}   /* 0.12.38: no run row (druid): her walk played fast, leaning into it with a bounce */
      const bob=(mov&&A.n===1?-Math.abs(Math.sin(g.t*11))*1.6:0)+runBob;if(runLean&&!riseRot)riseRot=runLean;   // one-frame walk (companion art has no walk row): a little hop
      if(h.whirl){ctx.save();const sp=g.t*16;   // 0.12.26: a wider slashing wave whips round him while he spins, so the reach reads
        ctx.globalCompositeOperation='lighter';
        for(let i=0;i<3;i++){const a0=sp+i*2.09;ctx.lineCap='round';
          ctx.strokeStyle='rgba(200,220,255,.30)';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(h.x+lx,G-11,26-i*2,7-i*.5,0,a0,a0+1.3);ctx.stroke();
          ctx.strokeStyle='rgba(255,255,255,.75)';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(h.x+lx,G-11,27-i*2,7.5-i*.5,0,a0+.2,a0+1.15);ctx.stroke();}
        ctx.strokeStyle='rgba(232,240,255,.45)';ctx.lineWidth=1.2;for(let i=0;i<2;i++){ctx.beginPath();ctx.ellipse(h.x+lx,G-10,16-i*3,5-i,0,sp*1.1+i*2,sp*1.1+i*2+2.2);ctx.stroke();}ctx.restore();}   // inner spin trail
      /* 0.12.107: the Shadow_Clone is drawn on its own now (drawClone) */
      if(rum){   /* rummage: dips down and digs (squash + lean toward the wreck), pops up, repeats; bits fly out where he digs */
        const ox=rum.o?rum.o.x+((OBST[rum.o.k]||{}).w||0)*.0:h.x+10;const dir=(rum.o&&rum.o.x<h.x-2)?-1:1;const ph=(g.t*2.3+(h.key.length*.37))%1;
        const dip=ph<.55?Math.sin(ph/.55*Math.PI):0;const jig=Math.sin(g.t*23)*.02*dip;const fx=h.x+lx;
        ctx.save();ctx.translate(fx,G);ctx.rotate(dir*(.1+.2*dip)+jig);ctx.scale(1+.03*dip,1-.13*dip);ctx.translate(-fx,-G);
        drawUnit(ctx,A,f,fx,G,(A.pre?ART_SCALE/A.pre/HS:A.art?ART_SCALE/HS:(A.sc||1))*rgGrow(h),null,h.hitFlash,0,(dir>0)!==!!A.faceR);ctx.restore();
        const seed=Math.floor(g.t*2.3+(h.key.length*.37));for(let i=0;i<4;i++){const q=((ph*1.6)+i*.17)%1;if(q>.8)continue;const r=Math.sin(seed*12.9+i*78.2)*43758.5%1;const rr=Math.abs(r);
          const bx=fx+dir*(9+q*10*(.6+rr)),by=G-4-Math.sin(q*Math.PI)*(8+6*rr);ctx.fillStyle=rum.disarm?(i%2?'#9ad0ff':'#e8e8e8'):(i%2?'#8a7a64':'#b8b8b8');ctx.globalAlpha=1-q;ctx.fillRect(Math.round(bx),Math.round(by),1.5,1.5);}ctx.globalAlpha=1;}
      else drawUnit(ctx,A,f,h.x+lx,G+bob-(h.leapH||0)*1.2-(A.fall&&riseRot?2*Math.abs(riseRot)/1.45:0),(A.pre?ART_SCALE/A.pre/HS:A.art?ART_SCALE/HS:(A.sc||1))*rgGrow(h),h.stealthT>0?.4+.08*Math.sin(g.t*5):null,h.hitFlash,riseRot,((h.face||1)>0)!==!!A.faceR);}   /* 0.12.128: Shoshi's sheet faces right, the others face left */   /* 0.12.67: stealthed = see-through, a faint shimmer */
    else{shadow(ctx,h.x+lx,G,9);spr(ctx,'h_'+h.key,fr,h.x+lx-32,G-60,h.face<0,null,h.hitFlash);}
    ctx.restore();
    if(h.gritT>0){const p=.5+.5*Math.sin(g.t*9),fa=Math.min(1,h.gritT/.5);ctx.save();ctx.globalCompositeOperation='lighter';ctx.strokeStyle=`rgba(230,175,90,${(.35+.3*p)*fa})`;ctx.lineWidth=1.5;ctx.beginPath();ctx.ellipse(Math.round(h.x+lx),G-24,13+p,26+p,0,0,7);ctx.stroke();
      ctx.fillStyle=`rgba(255,215,140,${.8*fa})`;for(let i=0;i<4;i++){const an=g.t*3+i*1.57;ctx.fillRect(Math.round(h.x+lx+Math.cos(an)*13),Math.round(G-24+Math.sin(an)*24),1.5,1.5);}ctx.restore();}   // Grit_Teeth: a steady amber brace around him
    if(h.shield>0){ctx.strokeStyle='rgba(154,230,255,.7)';ctx.beginPath();ctx.ellipse(Math.round(h.x+lx),G-24,15,27,0,0,7);ctx.stroke();}
    const bx=h.x+(h.dodgeX||0)+(h.wanderX||0),G0=G;{const G=G0-(h.leapH||0)*1.2*HS;if(!h.ghost)plate(ctx,h,bx,G-(hbOf(h).h+17),22,true);   /* 0.12.75: the plate rides up with a hero on the lookout or a jetpack */
    {const cb=castBar(h);if(cb&&!PLATE_OFF){const w=18,x=Math.round(bx-w/2),y=Math.round(G-(hbOf(h).h+17))+6;const k=Math.max(0,Math.min(1,cb[0]));   /* 0.12.71: cast / channel / reload bar under the plate */
      ctx.fillStyle='#120a14';ctx.fillRect(x-1,y-1,w+2,3);ctx.fillStyle='#2a2430';ctx.fillRect(x,y,w,1);ctx.fillStyle=cb[1];ctx.fillRect(x,y,Math.max(1,Math.round(w*k)),1);
      if(cb[2]){ctx.fillStyle='#ffffff';ctx.globalAlpha=.55+.45*Math.sin(g.t*12);ctx.fillRect(x+Math.round(w*k)-1,y,1,1);ctx.globalAlpha=1;}}}}};
  // enemies
  // depth lanes: each enemy stands a few px nearer/farther; small creatures take the front lanes; back lanes draw first
  for(const e of g.enemies)if(e.lane==null){const a=SP['e_'+e.type];e.lane=e.boss||e.fly?0:UNITS[e.type]?Math.floor(Math.random()*6):(a&&FH(a)<64?5+Math.floor(Math.random()*4):Math.floor(Math.random()*5));}
  const es=g.enemies.filter(e=>!e.dead).sort((a,b)=>a.lane-b.lane||b.x-a.x);
  const drawEnemy=(e)=>{if(e.inside!=null)return;const G0=(e.gy!=null&&!e.fly&&!e.boss)?e.gy:g.G;ctx.save();if(e.emergeT>0){const k=1-e.emergeT/.5;ctx.filter=`brightness(${(.12+.88*k).toFixed(2)})`;ctx.globalAlpha=.45+.55*k;}shrinkAt(ctx,e.x,G0,HS);drawEnemy0(e);ctx.restore();};   /* 0.12.130: out of a dark doorway: starts as a shadow, brightens to normal */
  const drawEnemy0=(e)=>{const G=(e.gy!=null&&!e.fly&&!e.boss)?e.gy:g.G;let fr=e.animT>0?6+Math.min(2,Math.floor((.3-e.animT)/.1)):e.hitFlash>0&&!e.boss?9:Math.floor(e.walkT*8)%6;
    if(e.type==='bat'&&ATLAS.bat){const B=ATLAS.bat;const a=e.swoop?B.swoop:e.hitFlash>0?B.hurt:B.fly;const f=a===B.fly?Math.floor(g.t*12+e.phase)%a.n:0;shadow(ctx,e.x,e.gy||g.G,6);drawUnit(ctx,a,f,e.x,e.y,.8,null,e.hitFlash,0,(e.face||-1)>0);if(e.hp<e.max)plate(ctx,e,e.x,e.y-13,12,false,'#e8303a');return;}   /* 0.12.206 Giant_Bat */
    if(e.boss){const bf=e.animT>0?2:Math.floor(g.t*2)%2;const y=e.fly?e.y-90:G-124;shadow(ctx,e.x,G,26);spr(ctx,'b_'+e.type,bf,e.x-64,y,false,null,e.hitFlash);return;}
    if(UNITS[e.skin||e.type]){const U=UNITS[e.skin||e.type];const [A,uf]=unitFrame(e,U);const gy=e.gy!=null?G:G+e.lane;const sc=(e.E.scale||1)*(e.elite?1.1:1)*(e.nem?1+.08*Math.max(0,e.nem.rank-1):1)*(e.swell||1);shadow(ctx,e.x,gy,8);if(e.fuseT>0){const k=1-e.fuseT/e.fuse0;glow(ctx,e.x,gy-30*sc/.88,22*sc/.88,'#ff2a1a',.1+.2*k+(e.blinkOnT>0?.25:0));}   /* 0.12.385 a swelling Bloater glows red */if(e.nem){glow(ctx,e.x,gy-10,10+e.nem.rank*2,e.nem.col||'#ff2a1a',.16+.04*Math.sin(g.t*4));}   /* 0.12.136 Nemesis: bigger with a red glow */
      const dsc=A.pre?sc/A.pre:sc;drawUnit(ctx,A,uf,e.x,gy,dsc,null,Math.max(e.hitFlash||0,e.blinkOnT>0?.16:0),0,(visFace(e)>0)!==!!A.faceR);if(e.needleT>0&&Math.floor(g.t*8)%2===0){ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,e.x,gy-16,14,'#5aff4a',.55);ctx.restore();}const y=gy-U.walk.ay*(U.walk.pre?sc/U.walk.pre:sc);   /* pre-shrunk art (zombies) is drawn 1:1 */
      if(e.slow>0){ctx.fillStyle='rgba(154,230,255,.8)';for(let i=0;i<3;i++)ctx.fillRect(Math.round(e.x-6+i*5),Math.round(y+8+((g.t*20+i*7)%20)),1,1);}
      if(e.burnT>0){const by=gy-2,bh=Math.max(10,(gy-y)*.55),sd=(e.id||e.x)*.13;fireGlow(ctx,e.x,by-bh*.5,bh*.9,.22);fireTongue(ctx,e.x-2,by,bh,g.t*1.4+sd,false,.8);fireTongue(ctx,e.x+3,by-2,bh*.7,g.t*1.7+sd+.4,true,.7);embers(ctx,g.t,e.x,by-bh*.6,4,4,sd,22);}   /* 0.12.301 burning zombies actually burn */
      if(e.bossForm||e.nem||e.hp<e.max||e.bleedT>0||e.burnT>0||e.slow>0||e.stun>0)plate(ctx,e,e.x,y-2,e.bossForm?28:e.nem?24:e.elite?20:14,false,e.bossForm?'#ff8a1f':e.nem?'#ff4a3a':e.elite?'#ffb020':'#e8303a');
      if(e.bossForm){ctx.save();ctx.font='bold 7px monospace';ctx.textAlign='center';const nm='ALPHA '+(e.bfName||'')+(e.alphaTr?' · '+TRAIT_NAME[e.alphaTr]:'');ctx.fillStyle='#000';ctx.fillText(nm,e.x+.8,y-7.2);ctx.fillStyle='#ffb040';ctx.fillText(nm,e.x,y-8);ctx.restore();}   /* 0.12.303 boss form */
      if(e.nem){ctx.save();ctx.font='bold 7px monospace';ctx.textAlign='center';const nm=e.nem.name+' '+'★'.repeat(e.nem.rank);ctx.fillStyle='#000';ctx.fillText(nm,e.x+.8,y-7.2);ctx.fillStyle=e.nem.col||'#ff6a4a';ctx.fillText(nm,e.x,y-8);ctx.restore();}
      if(e.distractT>0){ctx.fillStyle='#e8fff0';ctx.font='bold 6px monospace';ctx.textAlign='center';ctx.fillText('?',Math.round(e.x),Math.round(y-12-Math.abs(Math.sin(g.t*6))*1.5));}   // 0.12.68: off to check the noise
      if(e.rootT>0&&!e.boss){const fx0=Math.round(e.x),fy0=Math.round(gy);ctx.strokeStyle='#4a7a2a';ctx.lineWidth=1;for(let i=0;i<4;i++){const sx=fx0-5+i*3.3;ctx.beginPath();ctx.moveTo(sx,fy0+1);ctx.quadraticCurveTo(sx+(i%2?3:-3),fy0-4-i%2*2,sx+(i%2?-1:1),fy0-7);ctx.stroke();}ctx.fillStyle='#8a6a40';ctx.fillRect(fx0-1,fy0-6,2,6);ctx.fillStyle='#e8e0c8';ctx.fillRect(fx0-1,fy0-7,2,1);}   /* 0.12.195 Snare_Arrow: the arrow pinned at his feet, vines tangled round his legs */
      if(e.markT>0){const my=y-9,p=.5+.5*Math.sin(g.t*10);ctx.strokeStyle=`rgba(255,70,60,${.6+.4*p})`;ctx.lineWidth=1;ctx.strokeRect(Math.round(e.x)-3.5,Math.round(my)-3.5,7,7);ctx.fillStyle='#ff4a3a';ctx.fillRect(Math.round(e.x)-.5,Math.round(my)-.5,1,1);}   // Pinning_Shot mark
      return;}
    const n='e_'+e.type,a=SP[n];const big=FH(a)===64;
    const y=e.fly?e.y-FH(a)/2:G-(big?60:44)+e.lane;if(!e.fly)shadow(ctx,e.x,G+e.lane,big?8:7);
    if(e.elite){ctx.save();ctx.translate(e.x,y+FH(a));ctx.scale(1.22,1.22);spr(ctx,n,fr,-FW(a)/2,-FH(a),false,null,e.hitFlash);ctx.restore();}
    else spr(ctx,n,fr,e.x-FW(a)/2,y,false,null,e.hitFlash);
    if(e.slow>0){ctx.fillStyle='rgba(154,230,255,.8)';for(let i=0;i<3;i++)ctx.fillRect(Math.round(e.x-6+i*5),Math.round(y+8+((g.t*20+i*7)%20)),1,1);}
    if(e.burnT>0){const bh=14,by=y+30,sd=(e.id||e.x)*.13;fireGlow(ctx,e.x,by-7,13,.22);fireTongue(ctx,e.x,by,bh,g.t*1.4+sd,false,.8);embers(ctx,g.t,e.x,by-8,4,4,sd,22);}
    if(e.hp<e.max||e.bleedT>0||e.burnT>0||e.slow>0||e.stun>0)plate(ctx,e,e.x,y-2,e.elite?20:14,false,e.elite?'#ffb020':'#e8303a');};
  // draw heroes and enemies back-to-front by lane so units in the far lane sit behind the near ones
  /* 0.12.119 (Kyle) lootable storefronts, drawn over their building's own shop front. Lootable: a gold glint at the door and an alarm
     bell box over it. Looted: the door kicked in, glass and stock spilled on the sidewalk. Ringing: NOT the car's flashing lights but a
     rotating red beacon on the bell throwing a sweeping beam, the window strobing white in double flashes, and the bell shaking. */
  /* 0.12.121 (Kyle) lootable storefronts: a full shop front laid over its building's ground floor (same height as before): a lit sign
     naming the shop, two big display windows with stock on the shelves, a centre door, an alarm bell. Units walk through it; only the two
     pillars out front (their own obstacles, drawn in front of lane-0 units) block. Looted: dark, glass smashed, door kicked in, stock spilled.
     Ringing: a rotating red beacon on the bell sweeping the street, the windows strobing white in double flashes, the bell shaking. */
  const SIGNF={D:'110101101101110',I:'111010010010111',L:'100100100100111',Q:'010101101111011',T:'111010010010010',U:'101101101101111',A:'010101111101101',B:'110101110101110',C:'011100100100011',E:'111100110100111',G:'011100101101011',H:'101101111101101',K:'101101110101101',M:'101111111101101',N:'110101101101101',O:'010101101101010',P:'110101110100100',R:'110101110101101',W:'101101101111101',Y:'101101010010010',' ':'000000000000000'};
  const SHOPS={grocery:{t:'GROCERY',c:'#ffb84a',goods:['#a83c32','#c8a046','#46708c','#7a7a86','#5a9a46']},pharmacy:{t:'PHARMACY',c:'#5ae08a',goods:['#e0e0e0','#c89a46','#5a8cb0','#e0e0e0']},
    pawn:{t:'PAWN',c:'#7fb8ff',goods:['#c8c8d0','#b08a40','#8a5a3a','#5a6a7a']},hardware:{t:'HARDWARE',c:'#ff8a3a',goods:['#c86a2a','#8a8a96','#c8c040','#5a6a7a']},deli:{t:'DELI',c:'#ff7a9a',goods:['#c86a6a','#e8d0a0','#a0c060','#c8a046']},liquor:{t:'LIQUOR',c:'#b88aff',goods:['#5a8a5a','#a87a40','#c8c8d0','#7a4a8a']},bank:{t:'BANK',c:'#ffd23f',goods:['#ffd23f','#c8b060']}};
  const hsh=n=>{const v=Math.sin(n*12.9898)*43758.5453;return v-Math.floor(v);};
  const drawFront=o=>{const L=(BGA.city&&BGA.city.layers.find(l=>l.shops));if(!L)return;const s=L.w/L.r[2];const fy=L.y+L.front*s,gy=L.y+L.ground*s,x=Math.round(o.x*2)/2;
    const S=SHOPS[o.shop]||SHOPS.grocery,hw=Math.max(14,(o.bw||36)/2-1),top=fy-7,lt=!o.looted,ring=o.alarmT>0,pu=.5+.5*Math.sin(g.t*3.2+o.x*.05);ctx.save();
    // wall + cornice + sign board
    ctx.fillStyle='#1a2332';ctx.fillRect(x-hw,top,hw*2,gy-top);ctx.fillStyle='#34445c';ctx.fillRect(x-hw,top,hw*2,.8);ctx.fillRect(x-hw,top+6.2,hw*2,1);
    ctx.fillStyle='#0b1018';ctx.fillRect(x-hw+2,top+1.2,hw*2-4,4.6);
    const tx=S.t,sc=.8,tw=tx.length*4*sc-sc;let sx=x-tw/2;ctx.fillStyle=lt?S.c:'#3a4656';
    for(const ch of tx){const gl=SIGNF[ch]||SIGNF[' '];for(let k=0;k<15;k++)if(gl[k]==='1'&&!(o.looted&&hsh(o.x+k+ch.charCodeAt(0))<.3))ctx.fillRect(sx+(k%3)*sc,top+1.6+Math.floor(k/3)*sc,sc,sc);sx+=4*sc;}
    if(lt)glow(ctx,x,top+3.5,Math.min(hw,tw/2+4),S.c,.12+.08*pu);
    // two big display windows either side of the door
    const wy0=top+8,wy1=gy-2.5;
    for(const sd of [-1,1]){const x0=sd<0?x-hw+2.5:x+4.5,x1=sd<0?x-4.5:x+hw-2.5,ww=x1-x0;
      ctx.fillStyle='#3e4e66';ctx.fillRect(x0-.6,wy0-.6,ww+1.2,wy1-wy0+1.2);
      if(lt){const gr=ctx.createLinearGradient(0,wy0,0,wy1);gr.addColorStop(0,'#3a2c1c');gr.addColorStop(1,'#7a5a30');ctx.fillStyle=gr;}else ctx.fillStyle='#06090e';ctx.fillRect(x0,wy0,ww,wy1-wy0);
      for(let sh=wy0+3.5;sh<wy1;sh+=3.5){ctx.fillStyle=lt?'#2a2016':'#141a22';ctx.fillRect(x0,sh,ww,.5);   // shelves and stock
        for(let gx=x0+.5;gx<x1-.5;gx+=1.2){const h=hsh(o.x*7+gx*3+sh);if(h<(lt?.75:.25)){ctx.fillStyle=S.goods[Math.floor(h*97)%S.goods.length];ctx.globalAlpha=lt?1:.5;ctx.fillRect(gx,sh-1.4,.8,1.4);ctx.globalAlpha=1;}}}
      if(lt){ctx.globalAlpha=.22;ctx.fillStyle='#e8f4ff';ctx.beginPath();ctx.moveTo(x0+ww*.15,wy0);ctx.lineTo(x0+ww*.35,wy0);ctx.lineTo(x0+ww*.1,wy1);ctx.lineTo(x0-.01,wy1);ctx.fill();ctx.fillRect(x0+ww*.55,wy0,.6,wy1-wy0);ctx.globalAlpha=1;}
      else{ctx.fillStyle='#7aa8d0';for(let k=0;k<6;k++){const h=hsh(o.x+k*5+sd);ctx.fillRect(x0+h*ww,k%2?wy0:wy1-.8,.6,.8);}}
      ctx.fillStyle='#3e4e66';ctx.fillRect(x0+ww/2-.3,wy0,.6,wy1-wy0);}
    // door
    ctx.fillStyle='#3e4e66';ctx.fillRect(x-4,wy0-1,8,gy-wy0+1);
    if(lt){ctx.fillStyle='#ffcf7a';ctx.fillRect(x-3,wy0,6,gy-wy0);ctx.fillStyle='#ffe8b8';ctx.fillRect(x-1.5,wy0+1,3,gy-wy0-2);ctx.fillStyle='#3e4e66';ctx.fillRect(x-.25,wy0,.5,gy-wy0);
      ctx.globalCompositeOperation='lighter';ctx.globalAlpha=.5;const lg=ctx.createRadialGradient(x,gy,1,x,gy,24);lg.addColorStop(0,'rgba(255,200,110,.7)');lg.addColorStop(1,'rgba(255,200,110,0)');ctx.fillStyle=lg;ctx.fillRect(x-26,gy-12,52,20);ctx.globalCompositeOperation='source-over';ctx.globalAlpha=1;}
    else{ctx.fillStyle='#04070b';ctx.fillRect(x-3,wy0,6,gy-wy0);ctx.fillStyle='#2a3a4c';ctx.beginPath();ctx.moveTo(x-3,wy0);ctx.lineTo(x-7,wy0+2);ctx.lineTo(x-7,gy+1);ctx.lineTo(x-3,gy);ctx.fill();
      for(let i=0;i<12;i++){ctx.fillStyle=S.goods[i%S.goods.length];ctx.fillRect(x-hw+2+hsh(o.x+i)*(hw*2-4),gy+.5+hsh(o.x*3+i)*2,i%3?.6:1,.6);}}
    // 0.12.122 rooftop: a parapet slab across the top, a ladder up the right side, maybe a crate up there
    if(o.roof){const R=o.roof,ry=R.y;ctx.fillStyle='#2c3a50';ctx.fillRect(x-hw-1,ry-1.5,hw*2+2,2.2);ctx.fillStyle='#5e7090';ctx.fillRect(x-hw-1,ry-1.5,hw*2+2,.6);
      // 0.12.127 (Kyle): the roof door: a dark recessed doorway in the middle of the wall above the roof, where zombies step out
      ctx.fillStyle='#3e4e66';ctx.fillRect(x-4,ry-15,8,14);ctx.fillStyle='#26324a';ctx.fillRect(x-3.4,ry-14.4,6.8,13.4);ctx.fillStyle='#020304';ctx.fillRect(x-2.6,ry-13.6,5.2,12.6);
      ctx.fillStyle='#5e7090';ctx.fillRect(x-4.4,ry-15.6,8.8,.8);if(R.doorT>0){ctx.globalAlpha=Math.min(1,R.doorT*2);ctx.fillStyle='#ff4030';ctx.fillRect(x-1.2,ry-10,.6,.6);ctx.fillRect(x+.6,ry-10,.6,.6);ctx.globalAlpha=1;}
      const lx=x+hw+1.5,ly=LANES[0]+1;ctx.fillStyle='#6a5a48';ctx.fillRect(lx-1.6,ry-3,.6,ly-ry+3);ctx.fillRect(lx+1,ry-3,.6,ly-ry+3);for(let y=ry-1;y<ly;y+=2.4)ctx.fillRect(lx-1.6,y,3.2,.5);
      if(R.crate||R.crateDone){const D=OBST.city_crate;drawUnit(ctx,{fw:D.fw,fh:D.fh,n:1,ax:D.fw/2,ay:D.fh-1,x:D.x,y:D.y,img:'cityob'},R.crateDone?1:0,x-hw*.55,ry-1,.45,null,0,0,false);
        if(R.crate&&(g.t*.9+o.x*.02)%2<.2){const f=((g.t*.9+o.x*.02)%2)/.2;ctx.globalAlpha=Math.sin(f*3.14);ctx.fillStyle='#fff6c0';const sx=x-hw*.55+2,sy=ry-9;ctx.fillRect(sx-1.5,sy,3,.5);ctx.fillRect(sx-.25,sy-1.25,.5,3);ctx.globalAlpha=1;}}}
    // loot bag over the door while it's still lootable
    if(lt){const iy=top-6+Math.sin(g.t*3+o.x)*1.2;ctx.fillStyle='#1a1208';ctx.beginPath();ctx.arc(x,iy+1.6,3.2,0,7);ctx.fill();ctx.fillStyle=S.c;ctx.beginPath();ctx.arc(x,iy+1.6,2.5,0,7);ctx.fill();ctx.fillRect(x-1,iy-2.2,2,1.6);
      ctx.fillStyle='#1a1208';ctx.fillRect(x-1.5,iy-.8,3,.6);ctx.fillStyle='#fff6d0';ctx.fillRect(x-1.4,iy+.6,.8,.8);glow(ctx,x,iy+1.6,6,S.c,.18*(.6+.4*pu));}
    // alarm bell on the sign's corner
    const bx=x+hw-3,by=top+1,sh=ring?Math.sin(g.t*70)*.35:0;
    ctx.fillStyle='#1c1c22';ctx.fillRect(bx-2+sh,by-1,4,2.5);ctx.fillStyle=ring?'#ff3a2e':'#8a2420';ctx.beginPath();ctx.arc(bx+sh,by-1,1.6,Math.PI,0);ctx.fill();
    if(ring){const a=g.t*5.5;ctx.globalCompositeOperation='lighter';const dx=Math.cos(a),vis=Math.max(0,Math.sin(a)*.5+.5),len=70;ctx.globalAlpha=.32*vis+.06;
      const gr=ctx.createLinearGradient(bx,by,bx+dx*len,by+18);gr.addColorStop(0,'rgba(255,40,30,.9)');gr.addColorStop(1,'rgba(255,40,30,0)');ctx.fillStyle=gr;ctx.beginPath();ctx.moveTo(bx,by-1);ctx.lineTo(bx+dx*len,by+6);ctx.lineTo(bx+dx*len,by+26);ctx.closePath();ctx.fill();
      ctx.globalAlpha=.55+.45*vis;glow(ctx,bx,by-1,4.5,'#ff2a1a',.5);glow(ctx,bx,by-1,1.4,'#ffd0c0',.9);
      const ph=(g.t*1.3+o.x*.01)%1;if(ph<.05||(ph>.1&&ph<.15)){ctx.globalAlpha=.5;ctx.fillStyle='#e8f4ff';ctx.fillRect(x-hw+2.5,wy0,hw*2-5,wy1-wy0);ctx.globalAlpha=.25;glow(ctx,x,wy0+6,hw+6,'#d8ecff',.25);}
      ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';}
    ctx.restore();};
  // the storefront's two pillars: stone columns from the sidewalk up to the cornice, in front of lane-0 units
  const drawPillar=o=>{const L=(BGA.city&&BGA.city.layers.find(l=>l.shops));if(!L)return;const s=L.w/L.r[2];const top=L.y+L.front*s-7,gy=LANES[0]+1,x=Math.round(o.x*2)/2;ctx.save();
    /* 0.12.122 (Kyle): a waist-high wall along the front edge of the roof, drawn in front of whoever is up there (low enough that the crate shows over it) */
    if(o.sd>0&&o.F&&o.F.roof){const F=o.F,R=F.roof,fx=Math.round(F.x*2)/2,hw=Math.max(14,(F.bw||36)/2-1),ry=R.y;ctx.fillStyle='#2c3a50';ctx.fillRect(fx-hw-1,ry-6.5,hw*2+2,7.2);
      ctx.fillStyle='#5e7090';ctx.fillRect(fx-hw-1.4,ry-7,hw*2+2.8,1);ctx.fillStyle='#202a3a';for(let yy=ry-4.5;yy<ry;yy+=2.2)ctx.fillRect(fx-hw-1,yy,hw*2+2,.4);
      for(let k=fx-hw;k<fx+hw;k+=4)ctx.fillRect(k+((Math.round(k)%8)?2:0),ry-6,.4,6);ctx.fillStyle='#3a4a62';ctx.fillRect(fx-hw-1,ry-6,.6,6.6);}
    shadow(ctx,x,gy,3);ctx.fillStyle='#2a3444';ctx.fillRect(x-2.6,top-1,5.2,2.2);ctx.fillRect(x-2.6,gy-2.2,5.2,2.2);
    ctx.fillStyle='#4a5a72';ctx.fillRect(x-1.7,top+1,3.4,gy-top-3);ctx.fillStyle='#7a8ca6';ctx.fillRect(x-1.7,top+1,.8,gy-top-3);ctx.fillStyle='#26303f';ctx.fillRect(x+1,top+1,.7,gy-top-3);
    ctx.fillStyle='#5e7090';ctx.fillRect(x-2.6,top-1,5.2,.6);ctx.fillStyle='#1e2632';for(let y=top+5;y<gy-4;y+=5)ctx.fillRect(x-1.7,y,3.4,.4);ctx.restore();};
  /* 0.12.387 (Kyle) Maple Hollow: Kyle's / Cheez's place as a lootable house */
  const drawHoodFront=o=>{const s=o.s,D=o.door,x0=o.x+(D[0]-o.hx)*s,y0=o.ly+D[1]*s,w=D[2]*s,h=D[3]*s,pu=.5+.5*Math.sin(g.t*3.2+o.x*.05);ctx.save();
    if(!o.looted){ctx.globalCompositeOperation='lighter';glow(ctx,x0+w/2,y0+h*.35,11,'#ffb860',.1+.05*pu);ctx.globalCompositeOperation='source-over';
      ctx.fillStyle='#ffcf7a';ctx.fillRect(x0+w*.2,y0+h*.1,w*.6,h*.2);ctx.fillStyle='#ffe8b8';ctx.fillRect(x0+w*.35,y0+h*.13,w*.3,h*.1);
      const c=o.shop==='kyle'?'#b07af0':'#ffd23f',ix=x0+w/2,iy=y0-8+Math.sin(g.t*3+o.x)*1.2;ctx.fillStyle='#1a1208';ctx.beginPath();ctx.arc(ix,iy+1.6,3.2,0,7);ctx.fill();ctx.fillStyle=c;ctx.beginPath();ctx.arc(ix,iy+1.6,2.5,0,7);ctx.fill();ctx.fillRect(ix-1,iy-2.2,2,1.6);
      ctx.fillStyle='#1a1208';ctx.fillRect(ix-1.5,iy-.8,3,.6);ctx.fillStyle='#fff6d0';ctx.fillRect(ix-1.4,iy+.6,.8,.8);glow(ctx,ix,iy+1.6,6,c,.18*(.6+.4*pu));}
    else{ctx.fillStyle='#050308';ctx.fillRect(x0,y0,w,h);ctx.fillStyle='#3a3040';ctx.beginPath();ctx.moveTo(x0,y0);ctx.lineTo(x0-2.2,y0+1);ctx.lineTo(x0-2.2,y0+h+.5);ctx.lineTo(x0,y0+h);ctx.fill();}
    ctx.restore();};
  const drawOb=o=>{const D=OBST[o.k];if(D.front)return o.k==='hood_front'?drawHoodFront(o):drawFront(o);if(D.pillar)return drawPillar(o);if(o.gone)return;if(o.max&&o.hp<o.max&&g.t-(o.hitT||0)<4){const gy0=LANES[Math.max(...o.lanes)],w=Math.max(10,D.fw*.25),y0=gy0-(D.blk||20)*.55-6;ctx.fillStyle='#000a';ctx.fillRect(o.x-w/2-.5,y0-.5,w+1,2.5);ctx.fillStyle='#d8b070';ctx.fillRect(o.x-w/2,y0,w*Math.max(0,o.hp/o.max),1.5);}   /* 0.12.348 breakable: a little HP bar for a few seconds after a hit */const gy=LANES[Math.max(...o.lanes)];ctx.save();if(!D.flat)shadow(ctx,o.x,gy,Math.max(5,D.fw*.22));drawUnit(ctx,{fw:D.fw,fh:D.fh,n:1,ax:D.fw/2,ay:D.fh-(D.flat?6:1),x:D.x,y:D.y,img:D.img||'obst'},D.open&&o.looted?1:0,o.x,gy+1,.5,null,0,0,!!o.flip);if(o.k==='city_lootbox'&&!o.looted&&(g.t*.7+o.x*.01)%2<.18){const f=((g.t*.7+o.x*.01)%2)/.18;ctx.globalAlpha=Math.sin(f*3.14);ctx.fillStyle='#fff6c0';const sx=o.x-3+(o.x%5),sy=gy-8;ctx.fillRect(sx-1.5,sy,3,.5);ctx.fillRect(sx-.25,sy-1.25,.5,3);ctx.globalAlpha=1;}
    if(o.alarmT>0&&D.lights){const on=Math.floor(o.alarmT*6)%2===0,fl=o.flip?-1:1;ctx.globalCompositeOperation='lighter';   /* 0.12.74 (Kyle): the car's own head- and taillights flash, throwing light rays */
      const P=([lx,ly])=>[o.x+(lx-D.fw/2)*.5*fl,gy+1+(ly-(D.fh-1))*.5];
      if(D.lights.head){const [x,y]=P(D.lights.head),d=-fl;if(on){glow(ctx,x,y,2.6,'#fff4c0',.85);glow(ctx,x,y,1,'#ffffff',1);
          const gr=ctx.createLinearGradient(x,y,x+d*46,y);gr.addColorStop(0,'rgba(255,240,180,.45)');gr.addColorStop(1,'rgba(255,240,180,0)');ctx.fillStyle=gr;ctx.beginPath();ctx.moveTo(x,y-.8);ctx.lineTo(x+d*46,y-9);ctx.lineTo(x+d*46,y+5);ctx.lineTo(x,y+.8);ctx.fill();
          for(let i=-2;i<=2;i++){ctx.strokeStyle='rgba(255,250,220,.35)';ctx.lineWidth=.4;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+d*(14+Math.abs(i)*2),y+i*3);ctx.stroke();}}}
      if(D.lights.tail){const [x,y]=P(D.lights.tail),d=fl;const k=on?1:.25;glow(ctx,x,y,3*k+.6,'#ff2a1a',.7*k);glow(ctx,x,y,.9,'#ffb0a0',k);
        if(on)for(let i=-2;i<=2;i++){ctx.strokeStyle='rgba(255,60,40,.4)';ctx.lineWidth=.45;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+d*(10+Math.abs(i)*2),y+i*2.6);ctx.stroke();}}
      ctx.globalCompositeOperation='source-over';}/* car alarm: flashing lights */ctx.restore();};
  /* 0.12.75 Engineer's buildings, drawn from shapes: the watchtower (steel legs, X braces, chain-link panels, plank floors with low walls,
     a ladder up the whole thing and a sign per tier), the concrete barrier, the tesla coil and the car turret */
  /* 0.12.265 (Kyle): a metal guard railing on every tower floor, drawn IN FRONT of whoever is standing up there (like the shop pillars) */
  const drawTowerRail=b=>{const x=Math.round(b.x),gy=b.gy,W=8,TH=35,n=b.floors.length;ctx.save();if(b.hitT>0)ctx.globalAlpha=.75;
    for(let i=0;i<n;i++){const fy=gy-TH*(i+1),L=x-W-3,Rr=x+W+3;
      ctx.fillStyle='#5c6470';for(let px=L;px<=Rr;px+=3.2)ctx.fillRect(Math.round(px*2)/2,fy-8,.8,8);   // balusters
      ctx.fillStyle='#7d8794';ctx.fillRect(L-.5,fy-8.5,Rr-L+1.5,1.4);ctx.fillStyle='#b8c2ce';ctx.fillRect(L-.5,fy-8.5,Rr-L+1.5,.5);   // top rail with a shine
      ctx.fillStyle='#6a7380';ctx.fillRect(L,fy-4.4,Rr-L+.8,.9);   // mid rail
      ctx.fillStyle='#4a515c';ctx.fillRect(L-1,fy-9,1.6,9);ctx.fillRect(Rr-.6,fy-9,1.6,9);}   // corner posts
    for(const q of b.tur||[])if(q.hp>0)drawTurret(q);   /* 0.12.326 tower turrets sit on the floor corners, in front of the rail */
    ctx.restore();};
  /* 0.12.326 (Kyle's drawing, tidied): a round grey dome with a yellow X, on a short post, with a barrel that turns toward its target and an orange muzzle flash */
  /* 0.12.429 (Kyle): find the real roof of the car sprite under the turret (each car has a roof-height profile, 2 sprite px per entry, drawn at half scale) */
  /* 0.12.429 (Kyle marked the tops): the turret sits in the middle of the car's flat roof. Each car has a roof-height profile (2 sprite px per entry, drawn at half scale). */
  const carRoof=q=>{const o=q.car,D=o&&OBST[o.k];if(!D||!D.prof)return {x:q.x,y:q.gy-24};if(o._roof&&o._roofX===o.x)return o._roof;const fl=o.flip?-1:1,gy=LANES[Math.max(...o.lanes)],P=D.prof,step=D.fw/P.length;
    const mx=Math.max(...P);const idx=P.map((v,i)=>v>=mx-1.5?i:-1).filter(i=>i>=0);const c=(idx[0]+idx[idx.length-1])/2;const px=c*step+step/2;
    const r={x:o.x+(px-D.fw/2)*.5*fl,y:gy+1-mx*.5+3};o._roof=r;o._roofX=o.x;return r;};
  const drawTurret=q=>{const car=!!q.car,RF=car?carRoof(q):null,x=car?RF.x:q.x,y=q.tower?q.gy-30*(q.fl+1)+3:car?RF.y-5.5:q.gy-24,r=car?3.6:2.8,ang=q.ang!=null?q.ang:(q.tower?(q.side>0?.35:Math.PI-.35):(q.face>0?0:Math.PI));
    ctx.save();if(car){const ry=RF.y;   /* 0.12.431 (Kyle): a real mount: roof clamps, a bolted base plate and a pedestal up to the gun */
      ctx.fillStyle='#1a1d22';ctx.fillRect(x-7,ry-.6,2,1.6);ctx.fillRect(x+5,ry-.6,2,1.6);ctx.fillStyle='#3a3f46';ctx.fillRect(x-6,ry-1.4,12,1.2);ctx.fillStyle='#565c65';ctx.fillRect(x-6,ry-1.4,12,.4);
      ctx.fillStyle='#c4cad2';for(const bx of [-4.6,4])ctx.fillRect(x+bx,ry-1.2,.7,.7);
      ctx.fillStyle='#2e3238';ctx.beginPath();ctx.moveTo(x-3.4,ry-1.4);ctx.lineTo(x+3.4,ry-1.4);ctx.lineTo(x+1.8,y+1.5);ctx.lineTo(x-1.8,y+1.5);ctx.closePath();ctx.fill();ctx.fillStyle='#4a5058';ctx.fillRect(x-.5,y+1.5,1,ry-y-3);}
    ctx.fillStyle='#2a2e34';ctx.fillRect(x-1,y,2,car?3:2.4);if(false){ctx.fillStyle="#3a3f46";ctx.fillRect(x-4.5,y+1.2,9,1.4);ctx.fillStyle="#22262c";ctx.fillRect(x-4.5,y+2.4,9,.6);}
    ctx.save();ctx.translate(x,y);ctx.rotate(ang);ctx.fillStyle='#1c1f24';ctx.fillRect(0,-.75,r+(car?5:4),1.5);ctx.fillStyle='#4a5058';ctx.fillRect(r,-.75,1.2,1.5);
      if(q.flT>0){ctx.globalCompositeOperation='lighter';ctx.fillStyle='#ffb040';ctx.beginPath();ctx.moveTo(r+(car?5:4),-1.6);ctx.lineTo(r+(car?9:7),0);ctx.lineTo(r+(car?5:4),1.6);ctx.fill();ctx.fillStyle='#fff2b0';ctx.fillRect(r+(car?5:4),-.5,1.6,1);}ctx.restore();
    ctx.fillStyle='#6e757e';ctx.beginPath();ctx.arc(x,y,r,0,7);ctx.fill();ctx.fillStyle='#c4cad2';ctx.beginPath();ctx.arc(x-r*.25,y-r*.25,r*.72,0,7);ctx.fill();
    ctx.strokeStyle='#e8c020';ctx.lineWidth=.55;ctx.beginPath();ctx.moveTo(x-r*.5,y-r*.5);ctx.lineTo(x+r*.5,y+r*.5);ctx.moveTo(x+r*.5,y-r*.5);ctx.lineTo(x-r*.5,y+r*.5);ctx.stroke();
    ctx.strokeStyle='#3a3f46';ctx.lineWidth=.4;ctx.beginPath();ctx.arc(x,y,r,0,7);ctx.stroke();
    if(car&&q.hp<q.max){ctx.fillStyle='#000a';ctx.fillRect(x-6,y-8,12,2.5);ctx.fillStyle='#ffd23f';ctx.fillRect(x-5,y-7.5,10*Math.max(0,q.hp/q.max),1);}ctx.restore();};
  /* 0.12.424 (Kyle) a foundation: a ghost of the finished building, the real thing rising out of the ground in 4 stages, scaffold poles and a progress bar */
  /* 0.12.425 the MG Nest's camo net: an arch from the back of the pile over the gunner, see-through mesh with leaf scraps */
  /* 0.12.425 (Kyle's sketch, detailed): the MG Nest's front layers, drawn in front of the gunner: the gun (level when manned, drooping when not),
     the sandbag mound covering his legs, then the camo net canopy you can see him through */
  const drawNestFront=(b,noNet)=>{const IM=XIMG.nest;if(!IM||!IM.complete||!IM.naturalWidth)return;const x=Math.round(b.x),gy=b.gy;ctx.save();ctx.imageSmoothingEnabled=false;
    ctx.drawImage(IM,0,0,80,60,x-20,gy-29.5,40,30);
    const man=!!b.man,ang=man?-.05:.5;ctx.save();ctx.translate(x+1,gy-16.5);ctx.rotate(ang);ctx.drawImage(IM,80,0,80,60,-12,-15,40,30);
    if(b.flashT>0&&man){glow(ctx,17.5,-1,1.4,'#ffb02a',.5);ctx.fillStyle='#fff2b0';ctx.beginPath();ctx.moveTo(16.8,-1.7);ctx.lineTo(19.6,-1);ctx.lineTo(16.8,-.3);ctx.fill();}ctx.restore();
    if(!noNet){ctx.globalAlpha=.92;ctx.drawImage(IM,160,0,80,60,x-22,gy-29.5,40,30);ctx.globalAlpha=1;}
    if(b.rl>0){ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillRect(x-8,gy-33,16,2);ctx.fillStyle='#d8c08a';ctx.fillRect(x-8,gy-33,16*(1-b.rl/7),2);}
    ctx.restore();};
  const drawFound=f=>{const b=f.k==='tower'?{k:'tower',x:f.x,gy:f.gy,floors:[f.kind||'med'],hp:1,max:1,occ:[],tur:[]}:f.k==='mgnest'?{k:'mgnest',x:f.x,gy:f.gy,hp:1,max:1,A:{},ammo:0}:f.k==='fema'?{k:'fema',x:f.x,gy:f.gy,hp:1,max:1,A:{r:60}}:{k:'barrier',x:f.x,gy:f.gy,hp:1,max:1,A:{hp:1}};const H=f.k==='tower'?42:f.k==='mgnest'?28:f.k==='fema'?18:14,st=Math.min(4,Math.floor(f.pct/25)+1),fr=st/4*.92;
    const dr=()=>{drawBld(b);if(b.k==='mgnest')drawNestFront(b,f.pct<75);};ctx.save();ctx.globalAlpha=.18;dr();ctx.restore();
    ctx.save();ctx.beginPath();ctx.rect(f.x-24,f.gy-H*fr-1,48,H*fr+4);ctx.clip();dr();ctx.restore();
    ctx.save();ctx.strokeStyle='#c89a4a';ctx.lineWidth=.8;const top=f.gy-H*fr-3;for(const dx of [-10,10]){ctx.beginPath();ctx.moveTo(f.x+dx,f.gy);ctx.lineTo(f.x+dx,top);ctx.stroke();}ctx.beginPath();ctx.moveTo(f.x-11,top+1);ctx.lineTo(f.x+11,top+1);ctx.stroke();
    ctx.fillStyle='#ffb43a';ctx.fillRect(f.x-11,f.gy+1.5,22,1.2);
    const by=f.gy-H-8;ctx.fillStyle='rgba(0,0,0,.7)';ctx.fillRect(f.x-11,by,22,3);ctx.fillStyle='#ffb43a';ctx.fillRect(f.x-10.5,by+.5,21*Math.min(1,f.pct/100),2);
    ctx.font='bold 3.6px monospace';ctx.textAlign='center';ctx.fillStyle='#fff';ctx.fillText(Math.floor(f.pct)+'%',f.x,by-1);ctx.restore();};
  const drawBld=b=>{const x=Math.round(b.x),gy=b.gy;ctx.save();if(b.hitT>0){ctx.globalAlpha=.75;}
    if(b.k==='tower'){const W=8,TH=35,n=b.floors.length;const top=gy-TH*n;
      shadow(ctx,x,gy,11);
      for(let i=0;i<n;i++){const y0=gy-TH*i,y1=y0-TH,kind=b.floors[i];
        ctx.strokeStyle='rgba(170,180,190,.35)';ctx.lineWidth=.4;   // chain-link: diamond lattice on the lower part of each floor
        ctx.save();ctx.beginPath();ctx.rect(x-W,y0-14,2*W,14);ctx.clip();for(let k=-W-12;k<=W+12;k+=2.5){ctx.beginPath();ctx.moveTo(x+k,y0-1);ctx.lineTo(x+k+12,y0-13);ctx.stroke();ctx.beginPath();ctx.moveTo(x+k,y0-1);ctx.lineTo(x+k-12,y0-13);ctx.stroke();}ctx.restore();
        ctx.fillStyle='#4a5058';ctx.fillRect(x-W-1,y0-14,2*W+2,1);
        ctx.strokeStyle='#6a7280';ctx.lineWidth=1.1;ctx.beginPath();ctx.moveTo(x-W+2,y0);ctx.lineTo(x+W-2,y1+2);ctx.moveTo(x+W-2,y0);ctx.lineTo(x-W+2,y1+2);ctx.stroke();   // X brace
        ctx.fillStyle='#6a4a2a';ctx.fillRect(x-W-3,y1,2*W+6,2.5);ctx.fillStyle='#8a6438';ctx.fillRect(x-W-3,y1,2*W+6,1);   // plank floor (units stand right on this)
        ctx.save();ctx.translate(x-4.2,y0-23);ctx.scale(.7,.7);ctx.translate(-(x-6),-(y0-24));const sx=x-6,sy=y0-24;ctx.fillStyle='#1a1410';ctx.fillRect(sx-1,sy-1,14,10);   // the floor's sign shows what it does
        if(kind==='med'){ctx.fillStyle='#f2f2ea';ctx.fillRect(sx,sy,12,8);ctx.fillStyle='#d0202a';ctx.fillRect(sx+5,sy+1,2,6);ctx.fillRect(sx+3,sy+3,6,2);}
        else if(kind==='ammo'){ctx.fillStyle='#4a5a2a';ctx.fillRect(sx,sy,12,8);ctx.fillStyle='#d8b040';for(let q=0;q<3;q++){ctx.fillRect(sx+2+q*3,sy+2,2,5);ctx.fillStyle='#b08020';ctx.fillRect(sx+2+q*3,sy+2,2,1);ctx.fillStyle='#d8b040';}}
        else{ctx.fillStyle='#2a3a5a';ctx.fillRect(sx,sy,12,8);ctx.fillStyle='#9ad0ff';ctx.beginPath();ctx.arc(sx+4,sy+4,2,0,7);ctx.arc(sx+8,sy+4,2,0,7);ctx.fill();ctx.fillStyle='#1a1410';ctx.fillRect(sx+5.5,sy+3,1,2);}ctx.restore();}
      ctx.fillStyle='#5a626e';ctx.fillRect(x-W,top,2.2,gy-top);ctx.fillRect(x+W-2.2,top,2.2,gy-top);ctx.fillStyle='#8a94a2';ctx.fillRect(x-W,top,.8,gy-top);ctx.fillRect(x+W-2.2,top,.8,gy-top);   // steel legs
      ctx.fillStyle='#7a5a34';ctx.fillRect(x+W+3,top-2,1,gy-top+2);ctx.fillRect(x+W+7,top-2,1,gy-top+2);for(let y=gy-2;y>top;y-=3)ctx.fillRect(x+W+3,y,5,.8);   // ladder all the way up (the only way on or off)
      if(n>=3){ctx.fillStyle='#3a3f48';ctx.fillRect(x-W-3,top-14,2,9);ctx.fillRect(x+W+1,top-14,2,9);ctx.fillStyle='#6a4a2a';ctx.fillRect(x-W-4,top-15,2*W+8,2);}   // lookout roof
      {const m=b.max,w=Math.min(26,m*3+2);ctx.fillStyle='#000a';ctx.fillRect(x-w/2-1,top-20,w+2,3);for(let k=0;k<m;k++){ctx.fillStyle=k<b.hp?'#ffd23f':'#4a4030';ctx.fillRect(x-w/2+k*(w/m)+.3,top-19,w/m-.6,1);}
        if(b.life!=null&&b.lifeMax){const f=Math.max(0,b.life/b.lifeMax);ctx.fillStyle='#000a';ctx.fillRect(x-w/2-1,top-16,w+2,2);ctx.fillStyle=f<.25?'#ff6a4a':'#7fd8ff';ctx.fillRect(x-w/2,top-15.5,w*f,1);}}}   /* hits left, one pip per hit; 0.12.399 the blue bar under it is the time it has left */
    else if(b.k==='fema'){shadow(ctx,x,gy,14);   /* 0.12.426 FEMA station: a pallet of supply crates under a blue tarp, water jugs and a first aid case, with a soft green aura */
      if(b.life!=null){const pu=.5+.5*Math.sin((b.t||0)*3);ctx.strokeStyle=`rgba(120,230,140,${.18+.12*pu})`;ctx.lineWidth=.8;ctx.beginPath();ctx.ellipse(x,gy,b.A.r,b.A.r*.18,0,0,7);ctx.stroke();}
      ctx.fillStyle='#6a4a28';ctx.fillRect(x-12,gy-2,24,2);ctx.fillStyle='#8a6438';for(let i=-11;i<12;i+=5)ctx.fillRect(x+i,gy-2,3,.8);
      const crate=(cx,cy,w,h)=>{ctx.fillStyle='#9a7444';ctx.fillRect(cx,cy,w,h);ctx.fillStyle='#b88e56';ctx.fillRect(cx,cy,w,.8);ctx.strokeStyle='#5a3e1e';ctx.lineWidth=.4;ctx.strokeRect(cx+.2,cy+.2,w-.4,h-.4);ctx.beginPath();ctx.moveTo(cx,cy);ctx.lineTo(cx+w,cy+h);ctx.stroke();};
      crate(x-11,gy-9,8,7);crate(x-3,gy-9,8,7);crate(x-7,gy-15,8,6);
      ctx.fillStyle='#2a5aa8';ctx.beginPath();ctx.moveTo(x-12,gy-9);ctx.lineTo(x-8,gy-17);ctx.lineTo(x+2,gy-17);ctx.lineTo(x+6,gy-9);ctx.lineTo(x+5,gy-7);ctx.lineTo(x-11,gy-7);ctx.fill();
      ctx.fillStyle='#3a74c8';ctx.fillRect(x-8,gy-17,10,1);ctx.fillStyle='#fff';ctx.font='bold 3.4px monospace';ctx.textAlign='center';ctx.fillText('FEMA',x-3,gy-11.5);
      for(const j of [0,3.2])ctx.fillStyle='#9ad0e8',ctx.fillRect(x+6+j,gy-7,2.6,5),ctx.fillStyle='#d8f0ff',ctx.fillRect(x+6.4+j,gy-6.6,.6,4),ctx.fillStyle='#2a6aa8',ctx.fillRect(x+6.6+j,gy-8,1.4,1);
      ctx.fillStyle='#f0f0e8';ctx.fillRect(x+6,gy-12,6,4.6);ctx.fillStyle='#d0202a';ctx.fillRect(x+8.4,gy-11.6,1.2,3.8);ctx.fillRect(x+7.1,gy-10.3,3.8,1.2);
      if(b.life!=null){ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillRect(x-8,gy-21,16,1.6);ctx.fillStyle='#7ab8ff';ctx.fillRect(x-8,gy-21,16*Math.max(0,b.life/30),1.6);}}
    else if(b.k==='mgnest'){shadow(ctx,x,gy,16);ctx.strokeStyle='#26262a';ctx.lineWidth=.7;ctx.beginPath();ctx.moveTo(x+1,gy-16);ctx.lineTo(x-3,gy-9);ctx.moveTo(x+1,gy-16);ctx.lineTo(x+5,gy-9);ctx.stroke();}   /* 0.12.425 MG Nest back layer: shadow and tripod (the rest draws in front of the gunner) */
    else if(b.k==='sandbag'){shadow(ctx,x,gy,12);   /* 0.12.104 Sandbag Wall: a low, wide pile of burlap bags, staggered like bricks (shorter and wider than a HESCO cell) */
      const rows=[[-9,-3,3,9],[-6,0,6],[-3,3]];const bw=6.4,bh=3.6;
      rows.forEach((r,ri)=>{const yy=gy-bh*(ri+1)+ri*.6;for(const dx of r){const cx=x+dx;ctx.fillStyle=ri%2?'#b89c68':'#a88c5a';ctx.beginPath();ctx.ellipse(cx,yy+bh/2,bw/2,bh/2,0,0,Math.PI*2);ctx.fill();
        ctx.fillStyle='rgba(255,240,200,.25)';ctx.fillRect(cx-bw/2+1,yy+.5,bw-3,.7);ctx.fillStyle='rgba(60,40,20,.45)';ctx.fillRect(cx+bw/2-1.2,yy+1,.6,bh-1.5);   /* lit top edge, tied-off end */
        if(b.A&&b.A.barb){ctx.strokeStyle='rgba(70,70,74,.9)';ctx.lineWidth=.4;}}});
      if(b.A&&b.A.barb){const T=gy-bh*3+1;ctx.strokeStyle='#5b5f63';ctx.lineWidth=.45;ctx.beginPath();for(let k=0;k<=12;k++){const px=x-10+k*1.7,py=T-1.2+Math.sin(k*1.9)*1.1;k?ctx.lineTo(px,py):ctx.moveTo(px,py);}ctx.stroke();ctx.fillStyle='#8a8f94';for(let k=0;k<12;k+=2)ctx.fillRect(x-10+k*1.7,T-1.6+Math.sin(k*1.9)*1.1,.8,.8);}   /* barbed wire along the top (tier III) */
      if(b.hp<b.max*.5){ctx.fillStyle='#c8b080';for(let k=0;k<5;k++)ctx.fillRect(x-6+k*3,gy-.8,1.4,.8);}   /* split bags, sand spilling */
      if(b.hp<b.max){ctx.fillStyle='#000a';ctx.fillRect(x-8,gy-17,16,3);ctx.fillStyle='#ffd23f';ctx.fillRect(x-7,gy-16,14*Math.max(0,b.hp/b.max),1);}}
    else if(b.k==='barrier'){const w=7,h=17,L=x-w,R=x+w,T=gy-h;shadow(ctx,x,gy,10);   /* 0.12.76 (Kyle): one HESCO_Barrier cell, like his photos */
      ctx.fillStyle='#a8946c';ctx.fillRect(L,T,2*w,h);ctx.fillStyle='#c2ad84';ctx.fillRect(L+1,T+1,w-1,h-2);ctx.fillStyle='#8e7a56';ctx.fillRect(x+3,T+1,w-3,h-2);   // geotextile, lit from the left
      for(let yy=T+2;yy<gy;yy+=2.6){ctx.fillStyle='rgba(120,100,70,.35)';ctx.fillRect(L,yy,2*w,.5);}   // fabric bulging between the wires
      ctx.strokeStyle='rgba(70,72,74,.85)';ctx.lineWidth=.35;for(let xx=L+1.6;xx<R;xx+=2.4){ctx.beginPath();ctx.moveTo(xx,T);ctx.lineTo(xx,gy);ctx.stroke();}for(let yy=T+1.3;yy<gy;yy+=2.4){ctx.beginPath();ctx.moveTo(L,yy);ctx.lineTo(R,yy);ctx.stroke();}   // welded wire mesh
      ctx.fillStyle='#3e4246';for(const cx of[L,x,R-1])ctx.fillRect(cx,T-1,1,h+1);ctx.fillStyle='#7a8086';for(let yy=T;yy<gy;yy+=1.6)for(const cx of[L,x,R-1])ctx.fillRect(cx,yy,1,.6);   // coil-joint rods
      ctx.fillStyle='#5a4228';ctx.beginPath();ctx.moveTo(L-.5,T+.5);ctx.quadraticCurveTo(x-3,T-4,x,T-2.6);ctx.quadraticCurveTo(x+4,T-4.5,R+.5,T+.5);ctx.closePath();ctx.fill();ctx.fillStyle='#7a5c38';ctx.fillRect(x-4,T-2.6,3,1);   // dirt heaped over the top
      ctx.fillStyle='#c8b48a';ctx.fillRect(L,T,2*w,1);   // the fabric lip folded over the rim
      if(b.hp<b.max*.6){ctx.strokeStyle='#4a3a22';ctx.lineWidth=.5;ctx.beginPath();ctx.moveTo(x-3,T+4);ctx.lineTo(x-1,T+8);ctx.lineTo(x-3,T+11);ctx.stroke();ctx.fillStyle='#6a5030';ctx.fillRect(x-2,gy-1,4,1);}   // torn, dirt spilling
      if(b.hp<b.max){ctx.fillStyle='#000a';ctx.fillRect(x-8,T-8,16,3);ctx.fillStyle='#ffd23f';ctx.fillRect(x-7,T-7,14*Math.max(0,b.hp/b.max),1);};{const nx=x+1,ny=gy-17;const pu=(Math.sin((g.t||0)*7+b.x)+1)/2;   /* 0.12.429 (Kyle): a little battery noise maker strapped on top. Zombies love noise */
      ctx.fillStyle='#2a2a30';ctx.fillRect(nx-3.2,ny-4.2,6.4,4.4);ctx.fillStyle='#45454e';ctx.fillRect(nx-3.2,ny-4.2,6.4,.8);ctx.fillStyle='#14141a';ctx.beginPath();ctx.arc(nx-.6,ny-2,1.5,0,7);ctx.fill();ctx.fillStyle='#5a5a64';ctx.beginPath();ctx.arc(nx-.6,ny-2,.6,0,7);ctx.fill();
      ctx.fillStyle=pu>.5?'#ff3a2a':'#5a1a14';ctx.fillRect(nx+1.6,ny-3.6,1,1);ctx.strokeStyle='#8a8a92';ctx.lineWidth=.4;ctx.beginPath();ctx.moveTo(nx+2.2,ny-4.2);ctx.lineTo(nx+3,ny-6.4);ctx.stroke();ctx.fillStyle='#c8a040';ctx.fillRect(nx-3.6,ny-1.4,.8,1.4);
      for(let r=0;r<3;r++){const ph=((g.t||0)*1.6+r/3)%1;ctx.strokeStyle=`rgba(255,220,120,${.5*(1-ph)})`;ctx.lineWidth=.5;ctx.beginPath();ctx.arc(nx+1,ny-2,2.5+ph*9,-.9,.9);ctx.stroke();}}}
    else if(b.k==='tesla'){shadow(ctx,x,gy,6);ctx.fillStyle='#3a3f48';ctx.fillRect(x-4,gy-4,8,4);ctx.fillStyle='#22262c';ctx.fillRect(x-1,gy-16,2,12);
      for(let y=gy-15;y<gy-5;y+=2){ctx.fillStyle='#c87a3a';ctx.fillRect(x-2.5,y,5,1);}ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,x,gy-19,3+Math.sin(g.t*12),'#6ad0ff',.5);glow(ctx,x,gy-19,1.4,'#e8fbff',1);
      if(Math.random()<.5){ctx.strokeStyle='rgba(160,230,255,.8)';ctx.lineWidth=.5;zig(x,gy-19,x+(Math.random()-.5)*12,gy-19+(Math.random()-.5)*10,3,1.5);}ctx.restore();
      ctx.fillStyle='#000a';ctx.fillRect(x-6,gy-25,12,2.5);ctx.fillStyle='#6ad0ff';ctx.fillRect(x-5,gy-24.5,10*Math.max(0,b.hp/b.max),1);}
    else if(b.k==='turret'&&b.tower){}
    else if(b.k==='turret'&&false){const d=b.face||-1,ty=gy-22;ctx.fillStyle='#2a2e34';ctx.fillRect(x-3,ty,6,4);ctx.fillStyle='#4a525c';ctx.fillRect(x-2,ty-3,5,3);ctx.fillStyle='#1a1c20';ctx.fillRect(d>0?x+2:x-9,ty-2,7,1.5);
      ctx.fillStyle='#e8c020';ctx.fillRect(x-3,ty+3,6,.8);if(b.hp<b.max){ctx.fillStyle='#000a';ctx.fillRect(x-6,ty-7,12,2.5);ctx.fillStyle='#ffd23f';ctx.fillRect(x-5,ty-6.5,10*Math.max(0,b.hp/b.max),1);}}
    if(b.k==='turret'&&b.car)drawTurret(b);
    ctx.restore();};
  const engFx=()=>{for(const S of g.satchels||[]){const y=S.gy-(S.hgt||0)*.5-2;ctx.fillStyle='#3a2a18';ctx.fillRect(S.x-3,y-3,6,4);ctx.fillStyle='#6a4a28';ctx.fillRect(S.x-3,y-3,6,1);ctx.fillStyle='#2a1c10';ctx.fillRect(S.x-1,y-5,2,2);   /* 0.12.75 satchel: canvas pouch, strap, blinking red light */
      if(Math.floor(g.t*3)%2){ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,S.x+2,y-2,1.6,'#ff2a1a',.9);ctx.restore();}}
    for(const f of g.fx){const k=f.t/f.life;if(f.k==='spark'){ctx.fillStyle=k<.4?'#fff6c0':'#ffb040';for(let i=0;i<3;i++)ctx.fillRect(f.x+Math.cos(i*2.1+f.x)*k*6,f.gy-4-Math.sin(i*2.1+f.x)*k*5+k*k*6,1,1);}
      else if(f.k==='flare'){const u=Math.min(1,k),px=f.x0+(f.x1-f.x0)*u,py=f.y0+(f.y1-f.y0)*u-Math.sin(u*Math.PI)*70;ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle='#7dff7d';ctx.beginPath();ctx.arc(px,py,1.6,0,7);ctx.fill();ctx.fillStyle='rgba(120,255,120,.35)';ctx.beginPath();ctx.arc(px,py,4,0,7);ctx.fill();ctx.restore();}   /* 0.12.331 green flare */
      else if(f.k==='plate'){const u=Math.min(1,k),px=f.x0+(f.x1-f.x0)*u,py=f.y0+(f.y1-f.y0)*u-Math.sin(u*Math.PI)*10;ctx.fillStyle='#f2f2ea';ctx.fillRect(px-2,py,4,1);ctx.fillStyle='#c86a2a';ctx.fillRect(px-1,py-1,2,1);}
      else if(f.k==='pellet'){const u=Math.min(1,k*1.1),px=f.x0+(f.x1-f.x0)*u,py=f.y0+(f.y1-f.y0)*u,L=f.small?1.6:2.4,dx=f.x1-f.x0,dy=f.y1-f.y0,dl=Math.hypot(dx,dy)||1;ctx.save();ctx.globalCompositeOperation='lighter';ctx.strokeStyle=f.small?'rgba(255,214,140,.9)':'rgba(255,236,170,.95)';ctx.lineWidth=f.small?.45:.6;ctx.beginPath();ctx.moveTo(px-dx/dl*L,py-dy/dl*L);ctx.lineTo(px,py);ctx.stroke();ctx.restore();}   /* 0.12.326 turret rounds: small fast slugs, like the nail gun */
      else if(f.k==='tracer'){ctx.save();ctx.globalCompositeOperation='lighter';ctx.strokeStyle=`rgba(255,220,140,${1-k})`;ctx.lineWidth=.6;ctx.beginPath();ctx.moveTo(f.x0,f.y0);ctx.lineTo(f.x1,f.y1);ctx.stroke();glow(ctx,f.x0,f.y0,1.6,'#ffd080',.8*(1-k));ctx.restore();}}
    for(const h of g.alive())if(h.kitHits>0){ctx.fillStyle='rgba(200,208,220,.55)';ctx.fillRect(Math.round(g.heroX(h))-3,(h.gy||G)-14,6,1);}};
  /* 0.12.331 SeeKyle: his boys, the meetup circle and the camp stove */
  const drawKid=K=>{const U=UNITS['kid_'+K.who];if(!U)return;const A=U[K.anim]||U.run;const fr=Math.floor(K.at*(K.anim==='howl'?7:K.anim==='run'||K.anim==='naruto'?12:8))%A.n;
    ctx.save();shrinkAt(ctx,K.x,K.gy,HS);drawUnit(ctx,A,fr,K.x,K.gy,ART_SCALE/A.pre/HS*(K.who==='leif'?1.17:1),   /* 0.12.394 (Kyle): Leif is big for 4, Leon small for 7: Leif just a hair shorter than his brother */null,0,0,(K.face||1)<0);ctx.restore();
    if(K.st==='howl'||K.t<1.2){ctx.save();ctx.font='bold 6px monospace';ctx.textAlign='center';ctx.fillStyle='#000a';ctx.fillText('WOLF OUT!!!',K.x+.5,K.gy-30.5);ctx.fillStyle=K.who==='leif'?'#ff6b6b':'#7dff7d';ctx.fillText('WOLF OUT!!!',K.x,K.gy-31);ctx.restore();}};
  const drawZone=Z=>{const A=Z.A,a=Math.min(1,Z.t*3)*(Z.t>A.dur-1?Math.max(0,A.dur-Z.t):1);ctx.save();ctx.globalAlpha=.85*a;
    const rx=A.rx,ry=Math.max(14,rx*.38);ctx.fillStyle='rgba(80,255,120,.10)';ctx.beginPath();ctx.ellipse(Z.x,Z.gy-2,rx,ry,0,0,7);ctx.fill();
    ctx.strokeStyle='rgba(120,255,140,.8)';ctx.lineWidth=1;ctx.setLineDash([3,2]);ctx.lineDashOffset=-g.t*6;ctx.beginPath();ctx.ellipse(Z.x,Z.gy-2,rx,ry,0,0,7);ctx.stroke();ctx.setLineDash([]);
    ctx.font='bold 5px monospace';ctx.textAlign='center';ctx.fillStyle='#bfffc8';ctx.fillText('EVERYONE, COME TOGETHER  +'+Math.round((Z.n||0)*A.per*100)+'%',Math.max(62,Z.x),Z.gy-ry-4);ctx.restore();};
  const drawStove=S=>{const x=S.x,gy=S.gy;ctx.save();ctx.fillStyle='#2a2a30';ctx.fillRect(x-5,gy-6,10,6);ctx.fillStyle='#4a4a52';ctx.fillRect(x-6,gy-7,12,1.5);ctx.fillStyle='#1a1a1e';ctx.fillRect(x-4,gy-1,1,1);ctx.fillRect(x+3,gy-1,1,1);
    const f=Math.sin(g.t*20)*.6;ctx.fillStyle='#ff8a2a';ctx.fillRect(x-3,gy-8.5+f*.4,6,1.5);ctx.fillStyle='#ffd24a';ctx.fillRect(x-2,gy-9+f*.3,4,1);
    ctx.fillStyle='#7a7a82';ctx.fillRect(x-3.5,gy-11,7,2.4);ctx.fillStyle='rgba(230,230,230,.35)';for(let i=0;i<3;i++){const k=(g.t*.8+i/3)%1;ctx.fillRect(x-2+i*2+Math.sin(g.t*3+i)*1.2,gy-13-k*10,1.2,1.2);}ctx.restore();};
  const drawTent=T=>{const U=UNITS.tentacle;if(!U)return;const A=U[T.anim]||U.idle;let fr;const n=A.n;
    if(T.anim==='idle')fr=Math.floor(g.t*9+T.x)%n;else if(T.anim==='emerge')fr=Math.min(n-1,Math.floor(T.aT/.5*n));else if(T.anim==='attack')fr=Math.min(n-1,Math.floor(T.aT/.6*n));else if(T.anim==='hit')fr=Math.min(n-1,Math.floor(T.aT/.25*n));else fr=Math.min(n-1,Math.floor(T.aT/.8*n));
    ctx.save();shrinkAt(ctx,T.x,T.gy,HS);shadow(ctx,T.x,T.gy,9);drawUnit(ctx,A,fr,T.x,T.gy+1,T.big||1,null,T.hitT>0?(T.hitT-=1/60):0,0,T.face>0);ctx.restore();   // 0.12.70: Call_of_Cthulhu makes them 25% bigger
    if(T.hp<T.max&&T.anim!=='death'){const w=12,y=T.gy-36;ctx.fillStyle='#000a';ctx.fillRect(Math.round(T.x-w/2)-1,y-1,w+2,3);ctx.fillStyle='#9a50e8';ctx.fillRect(Math.round(T.x-w/2),y,Math.max(0,w*T.hp/T.max),1);}};
  /* 0.12.357 Ominous Trails / doors & windows: drawn right over the backdrop, BEHIND every unit and object, sitting 5px up the back edge */
  /* 0.12.387 (Kyle) Maple Hollow openings, drawn right on the building: Kyle's garage door rolled most of the way up (shut it to stop them),
     Cheez's doorway hanging open on a black hall (check it or board it up). Faint until someone notices, like the others. */
  const drawHoodPortal=p=>{const s=p.s,R=p.rect,w=R[2]*s,h=R[3]*s,x0=p.x-w/2,y0=p.ly+R[1]*s,st=p.state;ctx.save();ctx.globalAlpha=(p.seen||st!=='unk')?1:.4;
    if(p.art==='garage'){const shut=st==='blocked'||st==='safe',dh=h*(shut?1:.38);ctx.fillStyle='#040207';ctx.fillRect(x0,y0,w,h);
      ctx.fillStyle='#82829a';ctx.fillRect(x0,y0,w,dh);ctx.fillStyle='#5e5e72';for(let yy=y0+3*s;yy<y0+dh-.3;yy+=3*s)ctx.fillRect(x0,yy,w,.6);ctx.fillRect(x0,y0+dh-.7,w,.7);
      if(!shut){ctx.fillStyle='#14101c';ctx.fillRect(x0,y0+dh,w,1.2);}
      if(st==='blocked'){ctx.fillStyle='#2a2a34';ctx.fillRect(x0+w/2-1.6,y0+h-3.2,3.2,1.2);ctx.fillStyle='#d8c070';ctx.fillRect(x0+w/2-.9,y0+h-2.6,1.8,1.8);ctx.fillStyle='#6a5a28';ctx.fillRect(x0+w/2-.3,y0+h-1.9,.6,.6);}}
    else if(st!=='safe'){ctx.fillStyle='#020104';ctx.fillRect(x0,y0,w,h);ctx.fillStyle='#3a2a30';ctx.beginPath();ctx.moveTo(x0,y0);ctx.lineTo(x0-2.4,y0+1);ctx.lineTo(x0-2.4,y0+h+.5);ctx.lineTo(x0,y0+h);ctx.fill();
      if(st==='blocked'){for(let i=0;i<3;i++){ctx.save();ctx.translate(x0+w/2,y0+h*(.22+.28*i));ctx.rotate((i%2?-1:1)*.22);ctx.fillStyle='#6b4a2c';ctx.fillRect(-w/2-1.5,-1.2,w+3,2.4);ctx.fillStyle='#8a6440';ctx.fillRect(-w/2-1.5,-1.2,w+3,.8);ctx.fillStyle='#c8c8c8';ctx.fillRect(-w/2-.8,-.4,.7,.7);ctx.fillRect(w/2+.1,-.4,.7,.7);ctx.restore();}}}
    ctx.globalAlpha=1;const my=y0+h*(p.art==='garage'?.72:.38);
    if(st==='spawn'&&(p.eyesT>0||(g.t*1.3+p.x*.07)%3<.9)){if(p.eyesT>0)p.eyesT-=1/60;ctx.fillStyle='#ff3c28';ctx.globalAlpha=.85;ctx.fillRect(p.x-2,my,1,1);ctx.fillRect(p.x+1,my,1,1);if(p.art==='garage'){ctx.fillRect(p.x+5,my+1,1,1);ctx.fillRect(p.x+8,my+1,1,1);}ctx.globalAlpha=1;}
    if(p.seen&&st==='unk'){const b=Math.round(Math.sin(g.t*5+p.x)*1);ptext(ctx,'!',p.x,y0-6+b,'#ff5a3a',1);}
    const wk=g.alive().find(h2=>h2.ptWork&&h2.ptWork.portal===p);if(wk){const k=Math.min(1,wk.ptWork.t/wk.ptWork.T);ctx.fillStyle='#000a';ctx.fillRect(p.x-8,y0-4,16,2.5);ctx.fillStyle=wk.ptWork.job==='check'?'#9ad8ff':'#d8b070';ctx.fillRect(p.x-8,y0-4,16*k,2.5);}
    ctx.restore();};
  for(const p of g.portals||[]){if(p.kind==='hood'){drawHoodPortal(p);continue;}const A=PORTAL_ART[p.art||p.kind];if(!XIMG.portals.complete)break;const bx=Math.round(p.x-A.mx),by=Math.round(LANES[0]-5-A.lift-A.h);
    ctx.globalAlpha=(p.seen||p.state!=='unk')?1:.4;ctx.drawImage(XIMG.portals,A.sx,A.sy,A.w,A.h,bx,by,A.w,A.h);ctx.globalAlpha=1;   /* 0.12.366: faint until someone notices it, like hidden traps */
    if(p.seen&&p.state==='unk'){const b=Math.round(Math.sin(g.t*5+p.x)*1);ptext(ctx,'!',p.x,(p.kind==='trail'?by+48:p.kind==='hoodgrass'?by-3:by-7)+b,'#ff5a3a',1);}   /* 0.12.368 (Kyle): once noticed, a red ! sits in the trail's dark mouth or right above the door/window */const mx=p.x,my=LANES[0]-5-A.lift-(A.eye||9);
    if(p.state==='spawn'&&(p.eyesT>0||(g.t*1.3+p.x*.07)%3<.9)){if(p.eyesT>0)p.eyesT-=1/60;ctx.fillStyle='#ff3c28';ctx.globalAlpha=.85;ctx.fillRect(mx-2,my,1,1);ctx.fillRect(mx+1,my,1,1);ctx.globalAlpha=1;}
    if(p.state==='blocked'&&p.kind==='hoodgrass'){ctx.save();ctx.translate(bx+A.w/2,by+A.h-5);ctx.rotate(-.12);const w=A.w-10;   /* 0.12.393: a busted section of picket fence dragged across the path */
      ctx.fillStyle='#3a3646';ctx.fillRect(-w/2,-5,w,1);ctx.fillRect(-w/2,-2,w,1);for(let i=0;i<w;i+=2.4){if(((i*13)%7)<1)continue;const hh=6+((i*7)%3);ctx.fillStyle=(Math.floor(i/2.4)%3)?'#686474':'#55515f';ctx.fillRect(-w/2+i,1-hh,1.5,hh);ctx.fillStyle='#8e8a9c';ctx.fillRect(-w/2+i,1-hh,1.5,.6);}ctx.restore();}
    else if(p.state==='blocked'){if(p.kind==='trail'){const D=OBST.log_big;ctx.save();drawUnit(ctx,{fw:D.fw,fh:D.fh,n:1,ax:D.fw/2,ay:D.fh-1,x:D.x,y:D.y,img:D.img||'obst'},0,mx,LANES[0]-4,.36,null,0,0,false);ctx.restore();}
      else{const w=A.w-6,h=A.h-6,x0=bx+3,y0=by+3;ctx.fillStyle='#6b4a2c';for(let i=0;i<3;i++){ctx.save();ctx.translate(x0+w/2,y0+h*(.25+.25*i));ctx.rotate((i%2?-1:1)*.18);ctx.fillRect(-w/2-1,-1.5,w+2,3);ctx.fillStyle='#8a6440';ctx.fillRect(-w/2-1,-1.5,w+2,1);ctx.fillStyle='#6b4a2c';ctx.restore();}
        ctx.fillStyle='#c8c8c8';for(let i=0;i<3;i++){ctx.fillRect(x0,y0+h*(.25+.25*i)-.5,1,1);ctx.fillRect(x0+w-1,y0+h*(.25+.25*i)-.5,1,1);}}}
    const wk=g.alive().find(h=>h.ptWork&&h.ptWork.portal===p);if(wk){const k=Math.min(1,wk.ptWork.t/wk.ptWork.T);ctx.fillStyle='#000a';ctx.fillRect(mx-8,by-4,16,2.5);ctx.fillStyle=wk.ptWork.job==='check'?'#9ad8ff':'#d8b070';ctx.fillRect(mx-8,by-4,16*k,2.5);}}
  const items=[...(g.blds||[]).map(b=>[b.k==='turret'&&b.car?LANES[Math.max(...b.car.lanes)]+.25:b.gy-.3,-1,b.x,()=>drawBld(b)]),...(g.blds||[]).filter(b=>b.k==='mgnest'&&b.hp>0).map(b=>[b.gy+.08,1,b.x,()=>drawNestFront(b)]),...(g.founds||[]).map(f=>[f.gy-.3,-1,f.x,()=>drawFound(f)]),...(g.blds||[]).filter(b=>b.k==='tower'&&b.hp>0&&b.floors).map(b=>[Math.max(b.gy,...(b.occ||[]).filter(Boolean).map(o=>o.gy||G))+.05,1,b.x,()=>drawTowerRail(b)]),...(g.tentacles||[]).map(T=>[T.gy+.1,0,T.x,()=>drawTent(T)]),...(g.kids||[]).map(K=>[K.gy+.05,0,K.x,()=>drawKid(K)]),...(g.stoves||[]).map(S=>[S.gy-.2,-1,S.x,()=>drawStove(S)]),...(g.meet?[[-998,-1,0,()=>drawZone(g.meet)]]:[]),...(g.obst||[]).map(o=>[OBST[o.k].flat?-999:LANES[Math.max(...o.lanes)]+.2,-1,o.x,()=>drawOb(o)]),...hs.filter(h=>h.alive).map(h=>[h.gy||G,0,h.x,()=>drawHero(h)]),...(g.clones||[]).map(c=>[c.gy,0,c.x,()=>drawClone(c)]),...es.map(e=>[e.boss?G-.5:(e.gy!=null&&!e.fly?e.gy:G+e.lane-5),1,-e.x,()=>drawEnemy(e)])]
    .sort((a,b)=>a[0]-b[0]||a[1]-b[1]||a[2]-b[2]);
  // campfire (drawn behind the units) with sparks drifting up while it burns
  if(g.camp){const F=g.camp;let fr=0;if(F.state==='start')fr=1+Math.min(2,Math.floor(F.t/.3));else if(F.state==='burn')fr=4+Math.floor(g.t*8)%4;else if(F.state==='dying')fr=8+Math.min(2,Math.floor((F.dT||0)/.4));else fr=11;
    const A=Object.assign({},CAMPF,{x:fr*34,n:1});const fade=F.state==='dead'&&F.deadT>4?(5-F.deadT):1;drawUnit(ctx,A,0,F.x,F.gy+1,.5,fade,0,0,false);
    if(F.state==='burn'){ctx.save();ctx.globalCompositeOperation='lighter';glow(ctx,F.x,F.gy-6,14,'#ff9a30',.12+.04*Math.sin(g.t*9));
      for(let i=0;i<7;i++){const ph=((g.t*.7+i*.143)%1);const sx=F.x+Math.sin(i*2.3+g.t*2)*3+Math.sin(ph*9+i)*2,sy=F.gy-10-ph*28;ctx.fillStyle=ph<.6?'rgba(255,200,90,.95)':'rgba(255,120,40,'+(1-ph)*1.6+')';ctx.fillRect(sx,sy,ph<.3?1:.6,ph<.3?1:.6);}
      ctx.restore();}
    if(F.state==='dying'||F.state==='dead'){ctx.fillStyle='rgba(150,150,160,.25)';for(let i=0;i<3;i++){const ph=((g.t*.4+i*.33)%1);ctx.beginPath();ctx.arc(F.x+Math.sin(ph*6+i)*2,F.gy-6-ph*20,1.5+ph*3,0,7);ctx.fill();}}}
  traps();rainDraw();
  /* 0.12.51 enemy scrap mines: a rusted Trip Bomb cousin, dark red casing, spikes, a blinking red light and a taut wire. Unspotted ones are faint. */
  for(const M of g.mines||[]){if(!M.armed)continue;const x=Math.round(M.x),y=M.gy;ctx.save();
    if(M.shotgun&&!M.owner){const city=g.st.biome&&g.st.biome.id==='city';   /* 0.12.158 tripwire shotgun: a bush (trash bags downtown), a barrel peeking out pointing left, a wire across the lane */
      ctx.globalAlpha=M.spotted?1:.55;ctx.strokeStyle='rgba(210,210,200,.6)';ctx.lineWidth=.4;ctx.beginPath();ctx.moveTo(x-10,y-5);ctx.lineTo(x-10,y+1.5);ctx.moveTo(x-10,y-4.5);ctx.lineTo(x-2,y-3.2);ctx.stroke();ctx.fillStyle='#3a2a24';ctx.fillRect(x-10.5,y-5.5,1,1);
      ctx.globalAlpha=1;ctx.fillStyle='#2a2a2e';ctx.fillRect(x-6,y-4,5,1);ctx.fillStyle='#55555c';ctx.fillRect(x-6,y-4,5,.4);ctx.fillStyle='#000';ctx.fillRect(x-6.4,y-4,.5,1);   /* twin barrels */
      if(city){ctx.fillStyle='#1c1f26';ctx.beginPath();ctx.ellipse(x+1.5,y-2.6,4.2,3,0,0,7);ctx.fill();ctx.fillStyle='#262a33';ctx.beginPath();ctx.ellipse(x+4.5,y-2,3.2,2.4,0,0,7);ctx.fill();ctx.fillStyle='#3a404c';ctx.fillRect(x+.5,y-5,1.4,.6);}
      else{for(const [bx,by,r,c] of [[x+1,y-3,3.6,'#1e3a1a'],[x+3.6,y-2.4,3,'#244a20'],[x-.6,y-1.6,2.6,'#2c5a26'],[x+2.4,y-4.6,2.4,'#30642a']]){ctx.fillStyle=c;ctx.beginPath();ctx.arc(bx,by,r,0,7);ctx.fill();}}
      if(M.spotted){const b=Math.round(Math.sin(g.t*5)*1);ptext(ctx,'!',x-4,y-12+b,'#ff5a3a',1);}ctx.restore();continue;}
    ctx.globalAlpha=M.spotted?1:.38;
    ctx.strokeStyle='rgba(200,200,190,.55)';ctx.lineWidth=.5;ctx.beginPath();ctx.moveTo(x-7,y-1.5);ctx.lineTo(x+7,y-1.5);ctx.stroke();ctx.fillStyle='#3a2a24';ctx.fillRect(x-7.5,y-2.5,1,2);ctx.fillRect(x+6.5,y-2.5,1,2);   /* wire + stakes */
    ctx.fillStyle='#1c1412';ctx.fillRect(x-3,y-3,6,3);ctx.fillStyle='#6a2a1e';ctx.fillRect(x-2.5,y-2.5,5,2);ctx.fillStyle='#8a4a2a';ctx.fillRect(x-2,y-2.5,2,1);   /* rusted casing */
    if(M.cluster){ctx.fillStyle='#4a3a30';for(const sx of [-2.5,-.5,1.5]){ctx.beginPath();ctx.arc(x+sx+.5,y-3.6,.9,0,7);ctx.fill();}ctx.fillStyle='#c8a030';ctx.fillRect(x-2.5,y-1.2,5,.5);}   /* 0.12.157 cluster mine: little bomblets packed on top and a faded yellow band */
    else{ctx.fillStyle='#9a9a90';for(const sx of [-2.5,-.5,1.5])ctx.fillRect(x+sx,y-4,1,1);}   /* nail spikes */
    if(Math.floor(g.t*3)%2===0){const lc=M.owner?'#5aff6a':'#ff3a2a';ctx.fillStyle=lc;ctx.fillRect(x-.5,y-3.5,1,1);glow(ctx,x,y-3,1.6,lc,M.spotted?.3:.12);}   /* ours blink green */
    ctx.globalAlpha=1;if(M.spotted&&!M.owner){const b=Math.round(Math.sin(g.t*5)*1);ptext(ctx,'!',x,y-12+b,'#ff5a3a',1);}ctx.restore();}
  for(const K of g.crates||[]){const x=Math.round(K.x),y=Math.round(K.gy),k=K.t/K.A.dur,bl=k>.8&&Math.floor(g.t*6)%2;if(bl)continue;   /* 0.12.200 Ammo_Drop crate: olive box, yellow stencil band, a faint gold ring for its reach */
    ctx.save();ctx.globalAlpha=.25;ctx.strokeStyle='#ffd27a';ctx.lineWidth=.6;ctx.beginPath();ctx.ellipse(x,y,K.A.r,K.A.r*.25,0,0,7);ctx.stroke();ctx.restore();shadow(ctx,x,y,5);
    ctx.fillStyle='#1c2016';ctx.fillRect(x-5,y-5,10,5);ctx.fillStyle='#4a5a32';ctx.fillRect(x-4.5,y-4.5,9,4);ctx.fillStyle='#5f7240';ctx.fillRect(x-4.5,y-4.5,9,1);ctx.fillStyle='#d8b030';ctx.fillRect(x-4.5,y-3,9,1);ctx.fillStyle='#1c2016';ctx.fillRect(x-.5,y-4.5,1,4);
    for(const o of g.alive())if(!K.taken.has(o)&&o.plan&&o.plan.intent==='crate'){ctx.fillStyle='#ffd27a';ctx.fillRect(x-.5,y-9-Math.abs(Math.sin(g.t*5))*1.5,1,2);break;}}
  for(const b of g.bomblets||[]){let x,y;if(b.fuse<0){const u=Math.min(1,b.t/b.T);x=b.x0+(b.x1-b.x0)*u;y=b.gy0+(b.gy1-b.gy0)*u-Math.sin(u*Math.PI)*(b.H||14)-2;}else{x=b.x1;y=b.gy1-1.5;}   /* bomblets: arc, land, blink, pop */
    if(b.frag&&ATLAS.frag){const F=ATLAS.frag;shadow(ctx,b.fuse<0?b.x0+(b.x1-b.x0)*Math.min(1,b.t/b.T):b.x1,b.fuse<0?b.gy0+(b.gy1-b.gy0)*Math.min(1,b.t/b.T):b.gy1,1.4);drawUnit(ctx,F,b.fuse<0?0:2+Math.floor(g.t*10)%2,x,y+1.5,.42,null,0,b.fuse<0?b.t*14:0,false);continue;}   /* 0.12.175 the Soldier's frag: the pack's grenade, spinning in the air, then ticking on the ground */
    shadow(ctx,b.fuse<0?b.x0+(b.x1-b.x0)*Math.min(1,b.t/b.T):b.x1,b.fuse<0?b.gy0+(b.gy1-b.gy0)*Math.min(1,b.t/b.T):b.gy1,1.6);ctx.fillStyle='#2a201a';ctx.beginPath();ctx.arc(x,y,1.4,0,7);ctx.fill();ctx.fillStyle='#6a4a30';ctx.fillRect(x-.5+Math.cos(b.spin)*.6,y-.9,.8,.6);
    const blink=b.fuse<0?Math.floor(g.t*8)%2===0:Math.floor(g.t*24)%2===0;if(blink){ctx.fillStyle='#ff3a2a';ctx.fillRect(x-.4,y-1.6,.8,.8);glow(ctx,x,y-1.2,2,'#ff3a2a',.35);}}
  for(const h of g.alive())if(h.mine>0){const x=Math.round(g.heroX(h)-8),y=Math.round((h.gy||g.G)-31);ctx.fillStyle='#1c1412';ctx.fillRect(x-1,y,5,3);ctx.fillStyle='#6a2a1e';ctx.fillRect(x,y+1,3,1);ctx.fillStyle='#ff3a2a';ctx.fillRect(x+1,y,1,1);}   /* carrying a defused mine */
  for(const it of items)it[3]();
  engFx();voidFx();slamDraw();pinnedDraw();bottleDraw();nadeDraw();laser();waves();banners();iaiWaves();druidFx();robotFx();darkFx();quakes();logs();flames();jpFx();poultices();booms();
  // projectiles
  for(const p of g.proj){const x=Math.round(p.x),y=p.aimed?Math.round(p.y):Math.round(G+(p.y-G)*HS);const c=PCOL[p.kind]||'#ff3a3a';ctx.save();shrinkAt(ctx,x,y,HS);
    /* 0.12.94 (Kyle): projectiles turn to match the way they're flying (arrows from the tower point down at the target) */
    {const fx=p.x,fy=p.aimed?p.y:G+(p.y-G)*HS;if(p._sx!=null){const dx=fx-p._sx,dy=fy-p._sy;if(dx*dx+dy*dy>.01)p._ang=Math.atan2(dy,dx);}p._sx=fx;p._sy=fy;
      if(p._ang!=null&&p.kind!=='buck'){const d=(p.kind==='arrow'||p.kind==='quarrel')?(p.enemy?-1:1):(p.dir||1);let r=d<0?p._ang-Math.PI:p._ang;while(r>Math.PI)r-=2*Math.PI;while(r<-Math.PI)r+=2*Math.PI;if(Math.abs(r)>.02){ctx.translate(x,y);ctx.rotate(r);ctx.translate(-x,-y);}}}
    if(p.kind==='void'){const d=(p.dir||1);ctx.save();ctx.globalCompositeOperation='lighter';for(let i=1;i<=5;i++){ctx.fillStyle=`rgba(150,60,255,${.4-.07*i})`;ctx.fillRect(x-d*i*2.8-1,y-1+Math.sin(g.t*25+i)*.8,2,2);}glow(ctx,x,y,6,'#7a30e0',.35);ctx.restore();ctx.fillStyle='#12061e';ctx.beginPath();ctx.arc(x,y,2.4,0,7);ctx.fill();ctx.strokeStyle='#c090ff';ctx.lineWidth=.8;ctx.stroke();}   // void bolt: a black core in a violet halo
    else if(p.kind==='buck'){const d=(p.dir||1);ctx.save();ctx.globalCompositeOperation='lighter';   /* one buckshot pellet: a hot slug with a short streak */
      ctx.strokeStyle='rgba(255,200,120,.55)';ctx.lineWidth=.8;ctx.beginPath();ctx.moveTo(x-d*6,y);ctx.lineTo(x,y);ctx.stroke();ctx.fillStyle='#fff0c0';ctx.fillRect(x-.75,y-.75,1.5,1.5);ctx.restore();}
    else if(p.kind==='gat'){const d=(p.dir||1);ctx.save();ctx.globalCompositeOperation='lighter';ctx.strokeStyle='rgba(255,210,120,.85)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x-d*8,y);ctx.lineTo(x,y);ctx.stroke();ctx.fillStyle='#fff4c8';ctx.fillRect(x-1,y-.5,2,1);ctx.restore();}   // gatling tracer
    else if(p.kind==='flask'){ctx.save();ctx.translate(p.x,p.y);ctx.rotate((g.t*16)%6.283);ctx.fillStyle='#7dd87a';ctx.beginPath();ctx.arc(0,.8,1.6,0,7);ctx.fill();ctx.fillStyle='#e8f4f0';ctx.fillRect(-.5,-2,1,1.6);ctx.fillStyle='#8a5a2a';ctx.fillRect(-.6,-2.6,1.2,.7);ctx.restore();}   /* 0.12.437 the Alchemist's little flasks */
    else if(p.kind==='leaf'){const d=(p.dir||1);ctx.save();ctx.globalCompositeOperation='lighter';   // 0.12.15 nature bolt: a glowing seed with leaves spinning round it and a fading green trail
      for(let i=1;i<=5;i++){ctx.fillStyle=`rgba(90,255,120,${.38-.065*i})`;const s=1.6-.22*i;ctx.fillRect(x-d*i*2.6-s/2,y-s/2+Math.sin(g.t*20+i)*.5,s,s);}
      glow(ctx,x,y,6,'#5dff6a',.32);glow(ctx,x,y,2.6,'#c8ffb0',.55);ctx.restore();
      ctx.fillStyle='#e8ffd8';ctx.fillRect(x-.75,y-.75,1.5,1.5);
      for(let i=0;i<3;i++){const an=g.t*14*d+i*2.09,lx=x+Math.cos(an)*2.6,ly=y+Math.sin(an)*1.6;ctx.fillStyle=i%2?'#3cc84a':'#7ee081';ctx.fillRect(lx-.6,ly-.4,1.2,.8);}}
    else if(p.kind==='dart'){const d=(p.dir||1),X=k=>d>0?x+k:x-k-1;   /* 0.12.68: a nicer tiny dart: steel needle, dark shaft, red and cream tuft, a drop of green poison */
      ctx.fillStyle='rgba(200,255,190,.18)';ctx.fillRect(d>0?x-11:x+2,y,9,1);ctx.fillStyle='#d8dde8';ctx.fillRect(X(1),y,2,1);ctx.fillStyle='#5fe04a';ctx.fillRect(X(0),y,1,1);ctx.fillStyle='#2a1e14';ctx.fillRect(d>0?x-4:x+1,y,4,1);
      ctx.fillStyle='#c8302a';ctx.fillRect(X(-5),y-1,1,3);ctx.fillStyle='#f0e6d0';ctx.fillRect(X(-6),y-1,1,1);ctx.fillRect(X(-6),y+1,1,1);ctx.fillStyle='#e04838';ctx.fillRect(X(-6),y,1,1);}   // poison dart: shaft, green-tipped point, little fletch
    else if(p.kind==='kunai'){const d=(p.dir||1);ctx.fillStyle='#2e3040';ctx.fillRect(x-d*6-(d<0?1:0),y,6,1);ctx.fillStyle='#5c3424';for(let i=1;i<5;i+=2)ctx.fillRect(x-d*(1+i),y,1,1);ctx.fillStyle='#a8aec4';ctx.fillRect(d>0?x:x-4,y-1,4,3);ctx.fillStyle='#e0e6f2';ctx.fillRect(d>0?x+3:x-4,y,2,1);ctx.fillStyle='#b0965a';ctx.fillRect(x-d*7,y-1,1,3);}   // spinning-free kunai, pixel drawn
    else if(p.kind==='yarrow'&&UNITS.archer&&UNITS.archer.arrow){const B=UNITS.archer.arrow,d=(p.dir||1);ctx.save();ctx.globalCompositeOperation='lighter';if(p.pin){for(let i=0;i<5;i++){ctx.strokeStyle=`rgba(255,${200-i*25},${120-i*20},${.5-i*.09})`;ctx.lineWidth=3-i*.45;ctx.beginPath();ctx.moveTo(x-d*(10+i*9),y+i*.15);ctx.lineTo(x-d*(4+i*9),y);ctx.stroke();}glow(ctx,x,y,4,'#ffb050',.3);}   /* 0.12.68 Pinning_Shot: a hot motion trail */
      else{ctx.strokeStyle='rgba(255,240,200,.35)';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(x-d*26,y);ctx.lineTo(x-d*4,y);ctx.stroke();}ctx.restore();   // faint streak behind it
      drawUnit(ctx,B,0,x,y,ART_SCALE/B.pre/HS*(p.pin?2.4:1.7),null,0,0,d<0);}   // his own arrow, cut from his Ranged frames
    else if(p.kind==='bullet'&&UNITS.flannel&&UNITS.flannel.bullet){const B=UNITS.flannel.bullet;drawUnit(ctx,B,0,x,y+B.ay*ART_SCALE/HS,ART_SCALE/HS,null,0,0,(p.dir||1)<0);}   // sprite bullet from the character's own sheet
    else if(p.kind==='zap'){const d=(p.dir||1);ctx.save();ctx.globalCompositeOperation='lighter';ctx.strokeStyle='rgba(255,230,90,.75)';ctx.lineWidth=.9;ctx.beginPath();ctx.moveTo(x-d*9,y+Math.sin(g.t*40)*1.2);ctx.lineTo(x-d*6,y-1.2);ctx.lineTo(x-d*3,y+1.2);ctx.lineTo(x,y);ctx.stroke();glow(ctx,x,y,4,'#ffe04a',.5);ctx.fillStyle='#fffbe0';ctx.fillRect(x-1,y-1,2,2);ctx.restore();}   /* 0.12.178 the Sorcerer's spark */
    else if(p.kind==='arrow'||p.kind==='quarrel'){const d=p.enemy?-1:1;ctx.fillStyle='#8a6a4a';ctx.fillRect(d>0?x-8:x-1,y,9,1);
      ctx.fillStyle='#d8d0c0';ctx.fillRect(x-d*9,y-1,2,1);ctx.fillRect(x-d*9,y+1,2,1);ctx.fillStyle='#c8ccd6';ctx.fillRect(x+(d>0?1:-3),y-1,2,3);ctx.fillRect(x+(d>0?3:-4),y,1,1);}
    else if(p.kind==='brick'){ctx.save();ctx.translate(x,y);ctx.rotate(p.rot||0);   /* 0.12.68: a real-looking brick (long and flat), tumbling */
      ctx.fillStyle='#4a1a10';ctx.fillRect(-4.5,-2,9,4);ctx.fillStyle='#a8442a';ctx.fillRect(-4,-1.5,8,3);ctx.fillStyle='#c9663e';ctx.fillRect(-4,-1.5,8,1);ctx.fillStyle='#8a3220';ctx.fillRect(-4,.5,8,1);
      ctx.fillStyle='#d8c8b0';ctx.globalAlpha=.55;ctx.fillRect(-4,-1.5,1,3);ctx.fillRect(3,-1.5,1,1);ctx.globalAlpha=1;ctx.fillStyle='#5a2214';ctx.fillRect(-2,-.5,1,1);ctx.fillRect(1,-.5,1,1);ctx.restore();}
    else if(p.kind==='beam'){ctx.fillStyle='#ff2a3a';ctx.fillRect(x,y,8,1);}
    else if(p.kind==='batswarm'){ctx.fillStyle='#1a0a14';ctx.fillRect(x-3,y,7,2);ctx.fillRect(x-1,y-1,3,1);ctx.fillStyle='#ff2a2a';ctx.fillRect(x,y,1,1);}
    else drawProj(ctx,p,x,y,c,g.t);ctx.restore();}
  /* 0.12.383 Bloater: the gut ball (spinning, a shadow on the ground under it that darkens as it drops), the burst, the chunks */
  if(UNITS.bloater){const BU=UNITS.bloater;
    for(const B of (g.lobs||[])){const k=Math.min(1,B.t/B.T);ctx.save();ctx.globalAlpha=.18+.4*k;ctx.fillStyle='#000';ctx.beginPath();ctx.ellipse(Math.round(B.x),Math.round(B.gy),(2+4*k)*B.big,(.8+1.2*k)*B.big,0,0,7);ctx.fill();ctx.restore();
      drawUnit(ctx,BU.ball,Math.floor(B.spin)%4,B.x,B.gy-B.h*UNIT_SCALE,HS*B.big,null,0,0,false);}
    for(const b of (g.gutGibs||[])){const u=Math.min(1,b.t/b.T),x=b.x0+(b.x1-b.x0)*u,gy=b.gy0+(b.gy1-b.gy0)*u;ctx.save();ctx.globalAlpha=.3;ctx.fillStyle='#000';ctx.beginPath();ctx.ellipse(Math.round(x),Math.round(gy),1.5+u,.8,0,0,7);ctx.fill();ctx.restore();   /* 0.12.384 the gibs flying out */
      drawUnit(ctx,BU.ball,Math.floor(b.spin)%4,x,gy-Math.sin(u*Math.PI)*b.H-2,HS*.55*b.big,null,0,0,false);}
    for(const f of g.fx)if(f.k==='gutboom'){const k=f.t/f.life;drawUnit(ctx,BU.burst,Math.min(5,Math.floor(k*6)),f.x,f.gy,HS*f.big,k>.8?(1-k)*5:1,0,0,false);}
    for(const f of g.fx)if(f.k==='gutgibs'){const tt=f.t,a=tt>1.8?Math.max(0,1-(tt-1.8)/.8):1;ctx.save();ctx.globalAlpha=a;
      for(const q of f.P){const T=Math.min(tt,2.2),tl=(q.vh+Math.sqrt(q.vh*q.vh+560*q.h))/280;let hh=q.h+q.vh*T-140*T*T;if(hh<0)hh=0;const x=f.x+q.dx+q.vx*Math.min(T,tl);
        ctx.fillStyle=q.c;const s2=q.s;ctx.fillRect(Math.round(x*2)/2-s2/2,Math.round((f.gy-hh)*2)/2-s2/2,s2,s2*(hh>0?1:.6));}ctx.restore();}}
  // fx
  for(const f of g.fx){const k=f.t/.6;ctx.save();if(f.x!=null&&!f.raw)shrinkAt(ctx,f.x,G,HS);
    if(f.k==='plus'){const k2=f.t/f.life;ctx.restore();ctx.save();ctx.globalAlpha=1-k2;ctx.fillStyle='#062a0a';const px=Math.round(f.x),py=Math.round(f.y-k2*12);ctx.fillRect(px-2,py-.5,5,2);ctx.fillRect(px-.5,py-2,2,5);ctx.fillStyle='#7dff7d';ctx.fillRect(px-1.5,py,4,1);ctx.fillRect(px,py-1.5,1,4);}   /* 0.12.394 (Kyle): little green + floating up off whoever Leon heals */
    if(f.k==='gibs'){const tt=f.t,a=tt>1.8?Math.max(0,1-(tt-1.8)/.8):1;ctx.save();ctx.globalAlpha=a;   /* 0.12.40 zombie gibs: chunks fly, bounce once, settle, fade */
      for(const q of f.P){const T=Math.min(tt,2.2);let hh=q.h+q.vh*T-140*T*T,x=q.x+q.vx*Math.min(T,(q.vh+Math.sqrt(q.vh*q.vh+560*q.h))/280);if(hh<0)hh=0;
        ctx.fillStyle=q.c;const s=q.s;ctx.fillRect(Math.round(x*2)/2-s/2,Math.round((f.gy-hh)*2)/2-s/2,s,s*(hh>0?1:.6));}ctx.restore();}
    if(f.k==='blood'){const L=f.life,tt=f.t;let sd=f.seed;const rnd=()=>{sd=(sd*9301+49297)%233280;return sd/233280;};
      for(let i=0;i<f.n;i++){const a=(rnd()-.5)*1.6-(.35);const sp=(f.big?34:24)*(.4+rnd());const vx=Math.cos(a)*sp*f.dir,vy=Math.sin(a)*sp-10*rnd();
        const gy=f.gy+(rnd()*4-2);let x=f.x+vx*tt,y=f.y+vy*tt+60*tt*tt;
        if(y>=gy){const tl=(-vy+Math.sqrt(Math.max(0,vy*vy+240*(gy-f.y))))/120;x=f.x+vx*tl;y=gy;   // landed: a spot on the ground
          ctx.globalAlpha=Math.max(0,1-tt/L);ctx.fillStyle=i%3?'#5a0a12':'#7a1018';ctx.fillRect(Math.round(x),Math.round(y),i%4?1:2,1);}
        else{ctx.globalAlpha=1;ctx.fillStyle=tt<.08?'#ff5050':i%2?'#c0141e':'#8a0c16';const s2=i%3===0?2:1;ctx.fillRect(Math.round(x),Math.round(y),s2,s2);}}
      if(tt<.1){ctx.globalAlpha=1-tt*10;ctx.fillStyle='#ff3a3a';ctx.fillRect(Math.round(f.x)-1,Math.round(f.y)-1,f.big?3:2,f.big?3:2);}   // impact burst
      ctx.globalAlpha=1;}
    if(f.k==='pellets'){const k2=f.t/f.life;glow(ctx,f.x,f.gy-3.5,6*(1-k2),'#ffd080',.8*(1-k2));   /* 0.12.158 shotgun pellets: 7 streaks along their real paths */
      ctx.strokeStyle=`rgba(255,220,150,${(1-k2).toFixed(2)})`;ctx.lineWidth=.6;for(const o of f.offs||[]){const d0=k2*f.R,a=o/f.R;ctx.beginPath();ctx.moveTo(f.x-d0,f.gy-3.5+a*d0);ctx.lineTo(f.x-d0-7,f.gy-3.5+a*(d0+7));ctx.stroke();}continue;}
    if(f.k==='poof'){ctx.fillStyle=`rgba(180,170,190,${1-k})`;for(let i=0;i<(f.big?10:6);i++){const a=i*1.1;const r=4+k*(f.big?22:12);ctx.fillRect(Math.round(f.x+Math.cos(a)*r),Math.round(f.y+Math.sin(a)*r*.6),2,2);}}
    if(f.k==='ring'){ctx.strokeStyle=f.c;ctx.globalAlpha=1-k;ctx.beginPath();ctx.ellipse(Math.round(f.x),Math.round(f.y),f.r*(.3+k),f.r*(.3+k)*.45,0,0,7);ctx.stroke();ctx.globalAlpha=1;}
    if(f.k==='slash'){const al=Math.max(0,1-k*1.6);for(let i=0;i<14;i++){const a2=-1.2+i*.18;const r=13+k*3;ctx.fillStyle=`rgba(240,232,214,${al*(i<3||i>11?.5:1)})`;ctx.fillRect(Math.round(f.x-6+Math.cos(a2)*r),Math.round(f.y+Math.sin(a2)*r*.9),2,i>3&&i<10?2:1);}}
    if(f.k==='spark'){ctx.fillStyle=f.c;for(let i=0;i<4;i++){const a=i*1.57+.7;ctx.fillRect(Math.round(f.x+Math.cos(a)*k*8),Math.round(f.y+Math.sin(a)*k*8),1,1);}}
    if(f.k==='beam'){ctx.fillStyle=f.c;ctx.globalAlpha=1-k;ctx.fillRect(Math.round(f.x)-2,0,5,Math.round(f.y));ctx.fillStyle='#fff';ctx.fillRect(Math.round(f.x),0,1,Math.round(f.y));ctx.globalAlpha=1;}
    if(f.k==='drain'){ctx.fillStyle=f.c;for(let i=0;i<8;i++){const u=(i/8+k)%1;ctx.fillRect(Math.round(f.x+(f.tx-f.x)*u),Math.round(f.y+(G-30-f.y)*u-Math.sin(u*3.14)*10),2,2);}}
    if(f.k==='frost'){ctx.fillStyle=`rgba(200,240,255,${1-k})`;for(let i=0;i<40;i++)ctx.fillRect((i*37+Math.round(k*30))%W,(i*53+Math.round(k*80))%G,1,1);}
    if(f.k==='tentacle'){ctx.fillStyle='#4a2a52';const h=Math.sin(k*3.14)*60;ctx.fillRect(Math.round(f.x)-3,Math.round(G-h),6,Math.round(h));ctx.fillStyle='#c050a0';ctx.fillRect(Math.round(f.x)-1,Math.round(G-h),2,2);}
    if(f.k==='zap'){ctx.strokeStyle=`rgba(190,240,255,${1-k})`;ctx.beginPath();ctx.moveTo(f.x,f.y);for(let i=1;i<=5;i++){const u2=i/5;ctx.lineTo(f.x+(f.tx-f.x)*u2+(i<5?(Math.random()-.5)*6:0),f.y+(f.ty-f.y)*u2+(i<5?(Math.random()-.5)*6:0));}ctx.stroke();}
    if(f.k==='nstrace'){const y2=f.y2!=null?f.y2:f.y,dx=f.x2-f.x1,ex=f.x2+Math.sign(dx||1)*8,ey=y2+(y2-f.y)*8/Math.max(4,Math.abs(dx));ctx.globalAlpha=Math.max(0,.9*(1-k));ctx.lineCap='round';ctx.strokeStyle=f.c;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(f.x1,f.y);ctx.lineTo(ex,ey);ctx.stroke();ctx.strokeStyle='#fff';ctx.lineWidth=.8;ctx.beginPath();ctx.moveTo(f.x1,f.y);ctx.lineTo(ex,ey);ctx.stroke();glow(ctx,f.x1,f.y,3,'#ffe08a',.6*(1-k));ctx.globalAlpha=1;}   /* 0.12.155 No_Scope tracer: hip to target, angled across lanes */   /* 0.12.93 No_Scope tracer */
    if(f.k==='beamline'){ctx.fillStyle=f.c;ctx.globalAlpha=.8*(1-k);ctx.fillRect(Math.round(f.x),Math.round(f.y)-2,W,5);ctx.fillStyle='#fff';ctx.fillRect(Math.round(f.x),Math.round(f.y),W,1);ctx.globalAlpha=1;}
    if(f.k==='beamall'){ctx.fillStyle=`rgba(255,40,60,${.8*(1-k)})`;ctx.fillRect(0,G-34,f.x,6);ctx.fillStyle=`rgba(255,220,220,${1-k})`;ctx.fillRect(0,G-32,f.x,2);}
    if(f.k==='drainall'){ctx.strokeStyle=`rgba(255,40,60,${1-k})`;for(const h of g.alive()){ctx.beginPath();ctx.moveTo(h.x,G-30);ctx.lineTo(f.x-30,f.y);ctx.stroke();}}ctx.restore();}
  if(CC.brain&&!g.demo){ctx.save();ctx.font='5px monospace';ctx.textAlign='center';
    const tag=(u,x,y,lines,c)=>{lines=lines.filter(Boolean);const w=Math.max(...lines.map(l=>ctx.measureText(l).width))+4;ctx.fillStyle='rgba(0,0,0,.65)';ctx.fillRect(Math.round(x-w/2),Math.round(y-6*lines.length-1),Math.round(w),6*lines.length+2);
      ctx.fillStyle=c;lines.forEach((l,i)=>ctx.fillText(l,Math.round(x),Math.round(y-6*(lines.length-1-i))));};
    const nm=t=>!t?'nobody':t.key?(heroDef(t.key)||{name:t.key}).name.split(' ').slice(-1)[0]:(t.type||'foe');
    for(const h of g.alive()){const P=h.plan;if(!P)continue;tag(h,g.heroX(h),(h.gy||G)-Math.max(60,hbOf(h).h*UNIT_SCALE+14),[`${(heroDef(h.key)||{name:h.key}).name} · ${personaTitle(h)}`,`${P.intent.toUpperCase()} → ${nm(P.tgt)}`,P.why,...(h.dangerT>g.t?[h.dangerWhy]:[]),...(h.abWhyT>g.t?[h.abWhy]:[]),h.pauseT>0?'(thinking...)':h.burst>0?'BURST!':''],'#b6ff00');}
    for(const e of g.enemies){if(e.dead||!e.plan)continue;tag(e,e.x,(e.gy||G)-(e.type==='werewolf'?40:52),[`${e.retreatT>0?'BACK OFF':'HUNT'} → ${nm(e.plan.tgt)}`,e.plan.why,e.pauseT>0?'(shambling...)':''],'#ff9a9a');}
    ctx.restore();}
  // 0.12.13 callouts: short shouts above the speaker's head, in that hero's colour
  if(g.calls&&g.calls.length){ctx.save();const cfs=ctx.canvas.clientWidth&&ctx.canvas.clientWidth<700?4:3.4;ctx.font='bold '+cfs+'px monospace';   /* 0.12.201 (Kyle): chatter 15% smaller on desktop, unchanged on phones */ctx.textAlign='center';ctx.textBaseline='bottom';const seen=new Set();
    for(let i=g.calls.length-1;i>=0;i--){const c=g.calls[i];if(seen.has(c.u))continue;seen.add(c.u);const u=c.u;if(!u.alive)continue;
      const x=Math.max(30,Math.min(g.W-30,g.heroX(u))),y=(u.gy||G)-Math.max(56,hbOf(u).h*UNIT_SCALE+10)-(CC.brain?32:0)-Math.min(3,c.t*8);
      const k=c.t<.12?c.t/.12:c.t>c.life-.35?Math.max(0,(c.life-c.t)/.35):1;ctx.globalAlpha=k;const w=ctx.measureText(c.s).width+4;
      ctx.fillStyle='rgba(8,6,14,.78)';ctx.fillRect(Math.round(x-w/2),Math.round(y-cfs-1.5),Math.round(w),cfs+2);ctx.fillStyle=c.c;ctx.fillRect(Math.round(x-w/2),Math.round(y),Math.round(w),1);
      ctx.beginPath();ctx.moveTo(x-2,y+1);ctx.lineTo(x+2,y+1);ctx.lineTo(x,y+3);ctx.fill();ctx.fillText(c.s,Math.round(x),Math.round(y));}
    ctx.restore();ctx.globalAlpha=1;}
  {const small=ctx.canvas.clientWidth&&ctx.canvas.clientWidth<700,wm=small?.65:.5;   /* 0.12.201 (Kyle): pop-up words half size (a bit bigger on phones so they stay readable); numbers unchanged */
  for(const t of g.texts){const a=1-t.t/.9;ctx.globalAlpha=Math.max(0,a);const sc=t.sc||(t.big?2:1),word=/[A-Za-z]{2}/.test(t.s);ptext(ctx,t.s,t.x,Math.round(G+(t.y-G)*HS),t.c,word?Math.max(.5,Math.round(sc*wm*RES)/RES):sc);ctx.globalAlpha=1;}}
  ctx.restore();
  // boss bar / stage progress
  if(!g.demo){const p=g.boss&&!g.boss.dead?null:Math.min(1,g.dist/g.st.len);
    if(p!=null){ctx.fillStyle='#120a14';ctx.fillRect(6,4,W-12,4);ctx.fillStyle='#a6ff2e';ctx.fillRect(7,5,Math.round((W-14)*p),2);if(g.st.boss){ctx.fillStyle='#ff3a3a';ctx.fillRect(W-10,3,4,6);}}
    else{ctx.fillStyle='#120a14';ctx.fillRect(40,4,W-80,6);ctx.fillStyle='#c8102e';ctx.fillRect(41,5,Math.round((W-82)*Math.max(0,g.boss.hp/g.boss.max)),4);}}
}
// ---------------------------------------------------------------- portraits
// 0.12.13 one floating tooltip for the whole game: follows what you hover, always fits on screen.
//   Any element with data-tiph (html) gets a rich tip; any plain title="" is taken over so it looks the same.
/* 0.12.213 (Kyle: cleaner ability tooltips) one layout for every ability: a small cost/cooldown line, then one short line per sentence */
function fmtAbil(txt){txt=String(txt||'');let meta=[],body=txt;const P=txt.split(' · ');
  if(P.length>1){P.shift();const m=[];while(P.length){const p=P[0];const dot=p.search(/\.\s/);const head=dot>=0?p.slice(0,dot):p;
      if(/energy|^\d|life|passive|basic attack|\(passive\)|^Passive/i.test(head)&&head.length<48){m.push(head.replace(/^\(|\)$/g,''));if(dot>=0){P[0]=p.slice(dot+2);break;}P.shift();}else break;}
    meta=m;body=P.join(' · ');}
  const S=body.split(/(?<=[.!?])\s+(?=[A-Z(])/).filter(Boolean);
  return (meta.length?`<div class="tt-m">${meta.map(esc).join(' · ')}</div>`:'')+S.map(s=>`<div class="tt-l">${esc(s)}</div>`).join('');}
function howTip(k,insp){const D=heroDef(k)||{name:k},C=CHAR[k]||{};const p=personaOf({key:k,insp});
  return `<div class="tt-h">${esc(D.name)}</div><div class="tt-r">${esc(C.role||'')} · ${esc(personaTitle({key:k,insp}))}</div><div class="tt-b">${esc(BEHAVIOR[k]||D.blurb||'')}</div>`+
    `<div class="tt-s">${SLIDERS.map(([sk,l,r])=>{const v=p[sk]??5,s=Math.abs(v-5)/5;   // 0.12.24: the harder it leans, the brighter and bolder that side's word
      const mix=(a,b)=>Math.round(a+(b-a)*s),col=`rgb(${mix(150,190)},${mix(160,255)},${mix(150,40)})`,st=s>0?`style="opacity:${(.6+.4*s).toFixed(2)};color:${col};font-weight:${s>=.6?800:s>=.3?700:500}${s>=.8?';text-shadow:0 0 6px rgba(166,255,46,.55)':''}"`:'';
      return `<span class="l" ${v<5?st:''}>${esc(l)}</span><i><b style="left:${v*10}%;background:${s>0?col:'#ffd23f'}"></b></i><span class="r" ${v>5?st:''}>${esc(r)}</span>`;}).join('')}</div>`+
    `<div style="margin-top:5px;font-size:9px;opacity:.75">Key: <span style="color:rgb(158,179,128);opacity:.7">slight lean</span> · <span style="color:rgb(174,217,84);font-weight:700">strong</span> · <span style="color:rgb(190,255,40);font-weight:800;text-shadow:0 0 6px rgba(166,255,46,.55)">extreme</span></div>`+
    (insp&&INSP[insp]?`<div style="margin-top:5px;font-size:10px;opacity:.8">✨ ${esc(insp)}: ${esc(inspText(insp))}</div>`:'');}
let FTIP=null;function installTips(){if(FTIP)return;FTIP=document.createElement('div');FTIP.id='cc-ftip';document.body.appendChild(FTIP);let cur=null;
  const place=el=>{const r=el.getBoundingClientRect(),W=innerWidth,H=innerHeight;const tw=FTIP.offsetWidth,th=FTIP.offsetHeight;
    let x=r.left+r.width/2-tw/2;x=Math.max(8,Math.min(W-tw-8,x));let y=r.top-th-8;if(y<8)y=r.bottom+8;if(y+th>H-8)y=Math.max(8,H-th-8);FTIP.style.left=x+'px';FTIP.style.top=y+'px';};
  const show=el=>{if(el.title){el.dataset.tipt=el.title;el.removeAttribute('title');}const h=el.dataset.tiph;FTIP.innerHTML=h!=null?h:esc(el.dataset.tipt||'').replace(/\n/g,'<br>');
    if(!FTIP.innerHTML){hide();return;}FTIP.style.display='block';cur=el;const rr=el.closest('.rot-side');if(rr){if(FTIP.parentNode!==rr)rr.appendChild(FTIP);FTIP.classList.add('inrot');FTIP.style.left='';FTIP.style.top='';}else{if(FTIP.parentNode!==document.body)document.body.appendChild(FTIP);FTIP.classList.remove('inrot');place(el);}};
  const hide=()=>{FTIP.style.display='none';cur=null;};
  document.addEventListener('mouseover',e=>{if(Date.now()-lastT<800)return;const el=e.target.closest&&e.target.closest('[data-tiph],[title],[data-tipt]');if(el===cur)return;if(!el){hide();return;}show(el);},true);
  document.addEventListener('focusin',e=>{if(Date.now()-lastT<800||(e.target.matches&&e.target.matches(':focus-visible')===false))return;const el=e.target.closest&&e.target.closest('[data-tiph],[title],[data-tipt]');if(el)show(el);});
  document.addEventListener('scroll',()=>{if(cur&&cur.isConnected){if(!FTIP.classList.contains('inrot'))place(cur);}else hide();},true);document.addEventListener('mousedown',()=>{if(Date.now()-lastT>800)hide();},true);
  // 0.12.81 phones: tap (or long-press) anything with a tip to view it; tap again or tap elsewhere to close. No text selection.
  let lastT=0;const TSEL='[data-tiph],[title],[data-tipt]';document.addEventListener('pointerdown',e=>{if(e.pointerType==='touch')lastT=Date.now();},true);
  document.addEventListener('pointerup',e=>{if(e.pointerType!=='touch')return;lastT=Date.now();const el=e.target.closest&&e.target.closest(TSEL);
    if(e.target.closest&&e.target.closest('#cc-ftip')){hide();return;}if(!el){hide();return;}if(el.closest('button,a,input,select,label')){hide();return;}if(cur===el){hide();return;}show(el);},true);   // buttons act on tap; long-press them to read the tip
  document.addEventListener('contextmenu',e=>{const el=e.target.closest&&e.target.closest(TSEL);if(el&&el.closest('#cc')){e.preventDefault();show(el);}},true);
  }
/* 0.12.400 (Kyle): Timber_Rage makes the Lumber_Jack 25% bigger, growing in over 2s */
function rgGrow(h){if(h&&h.hound)return 1.35;return h&&h.rageT>0&&h.key==='lumberjack'?1+.25*Math.min(1,((h.rage0||8)-h.rageT)/2,h.rageT/.4):1;}
function portrait(key,size){const U=UNITS[key];if(U&&U.idle&&!SP['h_'+key]){const c=document.createElement('canvas');const A=U.idle;c.width=A.fw;c.height=A.fh;c.className='cc-por';
    const go=()=>{const x=c.getContext('2d');x.imageSmoothingEnabled=false;const k=A.pk||(A.art?3.4:A.pre?3.4*A.pre:1),w=30*k,hh=46*k,z=A.art?1:2,sx=A.x+A.ax-w/2,sy=A.y+A.ay-hh;c.width=w*z;c.height=hh*z;x.imageSmoothingEnabled=!!A.art;if(key==='jp')x.scale(z,z);else{x.translate(c.width,0);x.scale(-z,z);}   /* 0.12.143 (Kyle): JP faces the other way in character select */x.drawImage(A.img?XIMG[A.img]:UIMG,sx,sy,w,hh,0,0,w,hh);};
    const IM0=A.img?XIMG[A.img]:UIMG;if(IM0.complete)go();else IM0.addEventListener('load',go,{once:true});if(size)c.style.width=size+'px';
    if(A.n>1){let f=0;const tick=()=>{if(!c.isConnected&&f>2)return;f++;const x=c.getContext('2d'),k=A.pk||(A.art?3.4:A.pre?3.4*A.pre:1),w=30*k,hh=46*k,z=A.art?1:2,fi=f%A.n,sx=A.x+fi*A.fw+A.ax-w/2,sy=A.y+A.ay-hh;
      if(IM0.complete){x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,c.width,c.height);x.imageSmoothingEnabled=!!A.art;if(key==='jp')x.scale(z,z);else{x.translate(c.width,0);x.scale(-z,z);}x.drawImage(IM0,sx,sy,w,hh,0,0,w,hh);}
      setTimeout(tick,key==='edward'?(fi>=5&&fi<12?150:220):260);};setTimeout(tick,300+Math.random()*400);}   /* 0.12.217 (Kyle): every hero card breathes with its idle; Edward's idle is his own (he tinkers with the nail gun and pushes his glasses up) */
    return c;}
  const c=document.createElement('canvas');const a=SP['h_'+key];c.width=a[2];c.height=a[3];c.className='cc-por';
  const go=()=>{const x=c.getContext('2d');x.imageSmoothingEnabled=false;x.clearRect(0,0,c.width,c.height);x.drawImage(IMG,a[0],a[1],a[2],a[3],0,0,a[2],a[3]);};
  if(IMG.complete)go();else IMG.addEventListener('load',go,{once:true});if(size)c.style.width=size+'px';return c;}

// ---------------------------------------------------------------- styles
const CSS=`
#cc{position:fixed;inset:0;z-index:9000;overscroll-behavior:contain;overflow-anchor:none;background:#07040a;color:#e9e3f2;display:flex;flex-direction:column;font-size:14px;-webkit-tap-highlight-color:transparent;user-select:none}
#cc[hidden]{display:none}
#cc .px{font-family:var(--px,'Press Start 2P',monospace);letter-spacing:.5px}
#cc button{font:inherit;color:inherit;cursor:pointer}
.cc-top{display:flex;align-items:center;gap:6px;padding:6px 8px;background:#120a18;border-bottom:2px solid #2a1838;flex:0 0 auto}
.cc-top .t{font-family:var(--px,monospace);font-size:11px;color:#a6ff2e;margin-right:auto;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cc-ib{background:#1e1228;border:2px solid #3a2450;border-radius:6px;min-width:34px;height:32px;padding:0 8px;font-size:13px}
.cc-vol{width:80px;accent-color:#a6ff2e;vertical-align:middle;margin:0 4px}
.cc-ib[aria-pressed=true]{border-color:#a6ff2e;color:#a6ff2e}
.cc-main{position:relative;flex:1;display:flex;flex-direction:column;min-height:0;align-items:center}
.cc-info{display:flex;gap:10px;align-items:center;width:100%;padding:4px 10px;font-size:12px;flex-wrap:wrap;box-sizing:border-box}
.cc-info b{color:#ffd23f;font-weight:600}.cc-xp{flex:1;min-width:90px;height:6px;background:#1e1228;border:1px solid #3a2450;border-radius:3px;overflow:hidden}.cc-xp i{display:block;height:100%;background:#a6ff2e}
@keyframes ccTentPulse{0%,100%{box-shadow:0 0 0 #a6ff2e00}50%{box-shadow:0 0 10px #a6ff2e88}}
.cc-help{background:#140c1c;border:1px solid #a6ff2e66;border-radius:10px;padding:8px 12px;margin:6px 0 10px;font-size:12px;line-height:1.45;color:#e8dff5}
.cc-help b{color:#a6ff2e}
canvas.cc-fire{display:block;width:100%;image-rendering:pixelated;image-rendering:crisp-edges;border-radius:10px;border:1px solid #3a2a1a;box-shadow:0 0 30px rgba(255,120,40,.18);margin:6px 0 10px}
#cc-cv{image-rendering:pixelated;image-rendering:crisp-edges;background:#000;display:block;flex:0 0 auto}
.cc-cvw{position:relative;overflow:hidden;flex:0 0 auto;max-width:100%}
.cc-cvw.cam #cc-cv{position:absolute;left:0;top:0}
.cc-boss{position:absolute;left:0;right:0;text-align:center;font-family:var(--px,monospace);font-size:10px;color:#ff6a6a;text-shadow:0 1px 0 #000;pointer-events:none}
.cc-hud{display:grid;gap:6px;width:100%;padding:6px 8px;box-sizing:border-box;flex:0 0 auto}
.cc-hc{display:flex;gap:6px;align-items:center;background:#120a18;border:2px solid #2a1838;border-radius:8px;padding:3px 6px;min-width:0}
.cc-hc .cc-por{width:30px;height:30px;object-fit:cover;object-position:center top}
.cc-hc .n{font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.cc-hc .bar{height:6px;background:#2a1018;border-radius:3px;overflow:hidden;margin-top:2px}.cc-hc .bar i{display:block;height:100%;background:#4fd46a}
.cc-hc.dead{opacity:.4}
.cc-panel{position:absolute;inset:0;overflow:auto;overscroll-behavior:contain;overflow-anchor:none;background:rgba(7,4,10,.96);padding:14px 12px 40px;box-sizing:border-box;-webkit-overflow-scrolling:touch}
.cc-panel[hidden]{display:none}
.cc-wrap{max-width:760px;margin:0 auto}
.cc-role{display:inline-block;border:1px solid var(--rc);color:var(--rc);background:color-mix(in srgb,var(--rc) 14%,transparent);border-radius:9px;padding:0 6px;font-size:10.5px;font-weight:700;margin:1px 2px;white-space:nowrap}
.cc-rchips{margin:1px 0 2px}
.cc-hero .nm{display:flex;align-items:center;gap:4px;flex-wrap:nowrap;min-width:0}.cc-hero .nm .ic{flex:0 0 auto;line-height:1}.cc-hero .nm .tx{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}   /* 0.12.429 (Kyle): icon and name always side by side */
.cc-rbar{display:flex;flex-wrap:wrap;gap:5px;margin:4px 0 8px}
.cc-rb{border:1px solid #3a2e4a;border-radius:9px;padding:3px 7px;font-size:11px;opacity:.45;background:#140c1c;max-width:250px}
.cc-rb.on{opacity:1;border-color:var(--rc);box-shadow:0 0 8px color-mix(in srgb,var(--rc) 45%,transparent)}
.cc-rb b{color:var(--rc)}.cc-rb .rt{display:block;font-size:10.5px;color:#e8dff5}
.cc-rb .pips i{display:inline-block;width:6px;height:6px;border-radius:50%;border:1px solid var(--rc);margin-left:2px}.cc-rb .pips i.f{background:var(--rc)}
.cc-hudroles{display:flex;flex-direction:column;gap:2px;justify-content:center;margin-right:2px}.cc-hudroles .cc-role{font-size:10px;padding:0 3px;margin:0}
.cc-h{font-family:var(--px,monospace);color:#a6ff2e;font-size:16px;margin:6px 0 4px;line-height:1.5}
.cc-h2{font-family:var(--gothic,serif);font-size:24px;color:#ff8a1f;margin:4px 0 8px}
.cc-sub{color:#b8aecb;font-size:13px;margin:0 0 12px}
.cc-row{display:flex;gap:8px;flex-wrap:wrap}
.cc-card{background:#120a18;border:2px solid #2a1838;border-radius:10px;padding:10px;box-sizing:border-box}
.cc-btn{background:#2a1430;border:2px solid #6a2a8a;border-radius:8px;padding:10px 14px;font-weight:600}
.cc-btn.go{background:#1f3a12;border-color:#a6ff2e;color:#d8ffb0;font-family:var(--px,monospace);font-size:12px;padding:14px 18px}
.cc-btn.warn{border-color:#c8102e;background:#2a0a10}
.cc-btn:disabled{opacity:.4}
.cc-who{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}
.cc-who button{background:#120a18;border:2px solid #3a2450;border-radius:12px;padding:14px;text-align:left}
.cc-who .e{font-size:28px}.cc-who .nm{font-family:var(--px,monospace);font-size:12px;margin:6px 0}
.cc-pin{display:grid;grid-template-columns:repeat(3,74px);gap:10px;justify-content:center;margin:12px 0}
.cc-pin button{height:58px;font-size:22px;background:#1e1228;border:2px solid #3a2450;border-radius:10px}
.cc-dots{display:flex;gap:12px;justify-content:center;margin:10px 0}.cc-dots i{width:16px;height:16px;border-radius:50%;border:2px solid #a6ff2e}.cc-dots i.on{background:#a6ff2e}
.cc-dots.bad{animation:ccshake .3s}@keyframes ccshake{25%{transform:translateX(-6px)}75%{transform:translateX(6px)}}
.cc-heroes{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:8px;align-items:start}
.cc-hero{background:#120a18;border:2px solid #2a1838;border-radius:10px;padding:8px;text-align:left;position:relative}
[data-tiph],[data-tipt]{-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}
#cc-ftip.inrot{position:absolute!important;left:50%!important;top:50%!important;transform:translate(-50%,-50%);max-height:85%;overflow:auto;pointer-events:auto}
#cc .cc-radiosub{position:absolute;left:50%;bottom:6%;transform:translateX(-50%);max-width:80%;padding:5px 10px;background:rgba(8,10,8,.82);border:1px solid #6aff8a66;border-radius:6px;color:#b8ffc8;font:600 clamp(10px,1.3vw,14px)/1.3 system-ui,sans-serif;text-align:center;opacity:0;transition:opacity .3s;pointer-events:none;z-index:4;text-shadow:0 0 6px #3aff6a55}
#cc-ftip .tt-m{color:#ffd23f;font-size:10px;margin:1px 0 3px;opacity:.9}#cc-ftip .tt-l{margin:0 0 2px;padding-left:8px;text-indent:-8px}#cc-ftip .tt-l:before{content:'· ';color:#a6ff2e}
#cc-ftip{position:fixed;z-index:9999;display:none;pointer-events:none;max-width:min(340px,calc(100vw - 16px));background:#0d0712;border:1px solid #a6ff2e;border-radius:8px;padding:8px 10px;color:#e8dff5;font:11px/1.4 system-ui,sans-serif;box-shadow:0 8px 22px #000c;text-align:left;white-space:normal}#cc-ftip .tt-h{font-weight:700;color:#ffd23f;font-size:12px}#cc-ftip .tt-r{opacity:.7;font-size:10px;margin-bottom:5px}#cc-ftip .tt-b{margin-bottom:6px}#cc-ftip .tt-s{display:grid;grid-template-columns:1fr 64px 1fr;gap:2px 6px;align-items:center;font-size:9.5px}#cc-ftip .tt-s .l{text-align:right;opacity:.55}#cc-ftip .tt-s .r{opacity:.55}#cc-ftip .tt-s .on{opacity:1;color:#a6ff2e;font-weight:700}#cc-ftip .tt-s i{position:relative;height:5px;background:#2a1838;border-radius:3px}#cc-ftip .tt-s i b{position:absolute;top:-2px;width:5px;height:9px;margin-left:-2.5px;background:#ffd23f;border-radius:2px}.cc-ab .cc-tip{display:none!important}.cc-ab.pas{color:#9ad8ff;border-color:#2a4a60;background:#121c28}.cc-hw{display:flex;flex-direction:column;align-self:start}.cc-abl{display:flex;flex-direction:column;align-items:flex-start;gap:4px;margin-top:6px}.cc-ab{position:relative;font-size:10.5px;background:#1e1228;border:1px solid #3a2850;border-radius:6px;padding:2px 6px;color:#ffd23f;cursor:help}.cc-ab .cc-tip{display:none;position:absolute;left:0;bottom:calc(100% + 6px);z-index:20;width:220px;background:#0d0712;border:1px solid #a6ff2e;border-radius:8px;padding:7px 9px;color:#e8dff5;font-size:11px;line-height:1.4;box-shadow:0 6px 18px #000a;white-space:normal}.cc-ab:hover .cc-tip,.cc-ab:focus .cc-tip{display:block}.cc-hw .cc-hero{height:auto}.cc-insp{background:#0d0712;border:1px solid #2a1838;border-top:0;border-radius:0 0 10px 10px;padding:4px 8px 8px}.cc-insp select{width:100%;margin-top:3px;background:#120a18;color:#e8dff5;border:1px solid #3a2850;border-radius:6px;font-size:11px;padding:3px}.cc-insp select:disabled{opacity:.45}.cc-ibx{font-size:10.5px;color:#b8aecb;margin-top:4px;line-height:1.35}
.cc-hero[aria-pressed=true]{border-color:#a6ff2e;box-shadow:0 0 0 2px #a6ff2e44}
.cc-hero .cc-por{width:64px;height:64px;float:left;margin-right:6px}
.cc-hero .nm{font-weight:700;font-size:13px}.cc-hero .dk{font-size:11px;color:#b8aecb}.cc-hero .lv{font-family:var(--px,monospace);font-size:9px;color:#ffd23f;margin-top:4px}
.cc-hero .ord{position:absolute;top:6px;right:8px;font-family:var(--px,monospace);font-size:12px;color:#a6ff2e}
.cc-stat{clear:both;display:grid;grid-template-columns:28px 1fr;gap:2px 6px;font-size:10px;padding-top:6px;color:#b8aecb}.cc-stat i{display:block;height:5px;margin-top:3px;background:#3a2450;border-radius:3px}.cc-stat i b{display:block;height:100%;border-radius:3px;background:#ff8a1f}.cc-stat3{grid-template-columns:44px 1fr 14px;align-items:center;gap:3px 6px}.cc-stat3 span{font-size:9px;white-space:nowrap;cursor:help}.cc-stat3 em{font-style:normal;font-size:10px;font-weight:700;color:#f2ecff;text-align:right}.cc-stat .cc-pips{display:grid;grid-template-columns:repeat(10,1fr);gap:2px;height:7px;margin:0;background:none}.cc-stat .cc-pips b{height:7px;border-radius:1px;background:#2a1c3a}
.cc-load{display:grid;gap:8px}
.cc-lh{display:flex;gap:8px;align-items:flex-start}
.cc-chips{display:flex;flex-wrap:wrap;gap:4px;margin-top:4px}
.cc-chip{font-size:11px;padding:3px 6px;border-radius:6px;background:#1e1228;border:1px solid #3a2450}
.cc-chip.it{border-style:dashed}
.cc-chipw{display:inline-flex;gap:2px;align-items:center}.cc-mini{font-size:11px;padding:3px 7px;border-radius:6px;background:#2a1430;border:1px solid #6a2a8a}.cc-mini:disabled{opacity:.35;filter:grayscale(1);cursor:not-allowed}.cc-slotrow{margin-top:5px}.cc-chip b{font-weight:600}
.cc-offers{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px}
.cc-offer{background:#120a18;border:2px solid var(--rc);border-radius:12px;padding:10px;text-align:left;display:flex;flex-direction:column;gap:4px}
.cc-offer .rar{font-family:var(--px,monospace);font-size:9px;color:var(--rc)}
.cc-offer .kind{font-size:11px;color:#b8aecb;text-transform:uppercase;letter-spacing:.6px}
.cc-offer .cn{font-weight:700;font-size:14px}.cc-offer .tx{font-size:12px;color:#d8d0e6}
.cc-offer .who{display:flex;gap:6px;align-items:center;font-size:11px;color:#b8aecb}.cc-offer .who .cc-por{width:28px;height:28px;object-fit:cover;object-position:center top}
.cc-stars{color:#ffd23f;font-size:11px;letter-spacing:1px}
.cc-asc{color:#ffb020;font-family:var(--gothic,serif);font-size:16px}
.cc-lb{width:100%;border-collapse:collapse;font-size:12px}.cc-lb td,.cc-lb th{padding:5px 6px;border-bottom:1px solid #2a1838;text-align:left}.cc-lb th{color:#b8aecb;font-weight:500}
.cc-banner{position:absolute;left:0;right:0;top:38%;text-align:center;font-family:var(--px,monospace);font-size:18px;color:#ffd23f;text-shadow:0 2px 0 #000,0 0 12px #000;pointer-events:none;transition:opacity .4s}
.cc-hud.tall{grid-template-columns:1fr!important}.cc-hud.tall .cc-hc .cc-por{width:44px;height:44px}.cc-hud.tall .n{font-size:13px}
#cc .cc-hud{display:none!important}
#cc .cc-uf{display:flex;flex-direction:column;gap:4px;position:absolute;left:1.6%;top:9%;z-index:3;pointer-events:auto}   /* 0.12.204 (Kyle): life bars top-left over the sky, for every screen */
#cc.land .cc-uf{top:calc(9% + 20px)}
#cc .uf{display:block;width:clamp(104px,19vw,170px);cursor:help;text-shadow:0 1px 0 #000,1px 0 0 #000,-1px 0 0 #000,0 -1px 0 #000}
#cc .uf .cc-por{display:none}
#cc .uf .ufn{font:700 clamp(9px,1.25vw,12px)/1.15 system-ui,sans-serif;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#cc .uf .ufn span.lv{color:#ffd23f;font-weight:600}
#cc .uf .ufs{font-weight:600;font-size:.9em;margin-left:4px}
#cc .uf .ufh{height:clamp(4px,.55vw,7px);background:rgba(30,10,20,.8);border:1px solid rgba(0,0,0,.7);border-radius:2px;margin-top:2px;overflow:hidden}
#cc .uf .ufe{height:2px;background:rgba(16,26,42,.8);margin-top:1px;overflow:hidden;border-radius:1px}
#cc .uf .ufh i,#cc .uf .ufe i{display:block;height:100%;width:100%}#cc .uf .ufe i{background:#3fb6ff}
#cc .uf.dead{opacity:.5;filter:grayscale(1)}
#cc.land .cc-info{position:absolute;top:0;left:0;z-index:2;background:rgba(7,4,10,.6);padding:3px 8px}
#cc.land .cc-hud{position:absolute;bottom:0;left:0;z-index:2;background:rgba(7,4,10,.55);grid-auto-flow:column;padding:3px 6px}
#cc.land .cc-hc{padding:1px 4px;border-width:1px}
#crawl-strip{position:relative;margin:10px 0 0;border:2px solid #2a1838;border-radius:10px;overflow:hidden;height:clamp(70px,11vw,118px);background:#07040a;cursor:pointer}
#crawl-strip canvas{width:100%;height:100%;display:block;image-rendering:pixelated;image-rendering:crisp-edges}
#crawl-strip .cs-play{position:absolute;left:10px;top:8px;font-family:var(--px,monospace);font-size:11px;color:#a6ff2e;background:rgba(7,4,10,.78);border:2px solid #a6ff2e;border-radius:8px;padding:7px 10px;cursor:pointer}
#crawl-strip .cs-top{position:absolute;right:10px;top:10px;font-size:11px;color:#e9e3f2;background:rgba(7,4,10,.7);padding:3px 7px;border-radius:6px;max-width:55%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
@media (max-width:520px){#crawl-strip .cs-play{font-size:9px;padding:5px 7px}#crawl-strip .cs-top{font-size:10px;top:auto;bottom:6px}}
`;

// ---------------------------------------------------------------- state
const CC={data:Save.load(),player:null,unlocked:{},slotIdx:-1,game:null,speed:1,paused:false,raf:0};
const PL=()=>{const p=CC.data.players[CC.player]=CC.data.players[CC.player]||{pin:null,slots:[null,null,null,null,null]};while(p.slots.length<5)p.slots.push(null);return p;};   /* 0.12.86 (Kyle): 5 save files, no PIN */
const SLOT=()=>PL().slots[CC.slotIdx];
function persist(){Save.write(CC.data);updateStripTop();}
function migrate(slot,player){migrateSlot(slot,player);}
function bestOf(player){const p=CC.data.players[player];let b={score:0,stage:0,prestige:0};if(!p)return b;
  for(const s of p.slots)if(s&&(s.best.prestige*100+s.best.stage>b.prestige*100+b.stage||(s.best.score>b.score&&s.best.stage>=b.stage)))b=Object.assign({},s.best);
  for(const s of p.slots)if(s)b.score=Math.max(b.score,s.best.score);return b;}

// ---------------------------------------------------------------- overlay shell
let root,cv,ctx,panel,hud,info,bossEl,banner;
function build(){
  if(root)return;if(!document.getElementById('cc-style')){const st=document.createElement('style');st.id='cc-style';st.textContent=CSS;document.head.appendChild(st);}
  root=document.createElement('div');root.id='cc';root.hidden=true;root.setAttribute('role','dialog');root.setAttribute('aria-label','Crypt Crawl');
  root.innerHTML=`<div class="cc-top"><span class="t">⚰️ CRYPT CRAWL <span style="color:#6a5a7a;font-size:8px">v0.12.448</span></span>
    <button class="cc-ib" data-a="restart" title="Restart this stage from its save point" hidden>↺</button><button class="cc-ib" data-a="pause" title="Pause">⏸</button><button class="cc-ib" data-a="speed" title="Game speed">1×</button>
    <button class="cc-ib" data-a="brain" title="Show what every unit is thinking">🧠</button><button class="cc-ib" data-a="mute" title="Sound effects">${muted?'🔇':'🔊'}</button><button class="cc-ib" data-a="music" title="Music on/off">${musicMuted?'🎵̸':'🎵'}</button><button class="cc-ib" data-a="track" title="Next track (now: ${TRACKS[trackI].name})">⏭</button><input class="cc-vol" data-vol type="range" min="0" max="100" value="${Math.round(musicVol*100)}" title="Music volume"><button class="cc-ib" data-a="zoom" title="Zoom (Auto: closer camera on phones)">🔍</button><button class="cc-ib" data-a="side" title="Turn sideways (phones held upright)">⟳</button><button class="cc-ib" data-a="fs" title="Full screen">⛶</button><button class="cc-ib" data-a="close" title="Close">✕</button></div>
    <div class="cc-main"><div class="cc-info"></div><div class="cc-cvw"><div class="cc-uf"></div><canvas id="cc-cv" width="${384*RES*GQ}" height="${216*RES*GQ}"></canvas></div><div class="cc-boss"></div><div class="cc-banner"></div><div class="cc-hud"></div><div class="cc-panel"></div></div>`;
  document.body.appendChild(root);
  cv=$('#cc-cv',root);ctx=cv.getContext('2d');cv.addEventListener('pointerdown',radioClick);panel=$('.cc-panel',root);hud=$('.cc-hud',root);info=$('.cc-info',root);bossEl=$('.cc-boss',root);banner=$('.cc-banner',root);
  root.addEventListener('click',e=>{const b=e.target.closest('[data-a]');if(!b)return;const a=b.dataset.a;
    if(a==='close')closeCrawl();
    if(a==='restart'&&CC.game){if(!confirmInline(b,'↺?'))return;CC.game=null;cancelAnimationFrame(CC.raf);persist();beginStage();}
    if(a==='pause'){CC.paused=!CC.paused;b.textContent=CC.paused?'▶':'⏸';}
    if(a==='speed'){CC.speed=CC.speed%3+1;b.textContent=CC.speed+'×';}
    if(a==='brain'){CC.brain=!CC.brain;b.classList.toggle('on',CC.brain);b.style.outline=CC.brain?'2px solid #b6ff00':'';}
    if(a==='music'){musicMuted=!musicMuted;b.textContent=musicMuted?'🎵̸':'🎵';b.style.opacity=musicMuted?.5:1;try{localStorage.setItem('podrundown-crawl-music-mute',musicMuted?'1':'0');}catch(_){}musicStart();}
    if(a==='track'){const T=musicNext();b.title=`Next track (now: ${T.name})`;flash('♫ '+T.name+' · '+T.info+' · '+T.by,2400);}
    if(a==='mute'){muted=!muted;b.textContent=muted?'🔇':'🔊';try{localStorage.setItem('podrundown-crawl-mute',muted?'1':'0');}catch(_){}}
    if(a==='fs'){if(window.PodSideways)PodSideways.goBig(root);setTimeout(layout,120);}
    if(a==='zoom'){const L=[0,1,1.5,2];CAMZ=L[(L.indexOf(CAMZ)+1)%L.length];try{localStorage.setItem('cc-zoom',String(CAMZ));}catch(e){}b.title='Zoom: '+(CAMZ?CAMZ+'×':'Auto');b.textContent=CAMZ?CAMZ+'×':'🔍';layout();}
    if(a==='side'){flipPref(root.classList.contains('rot-side')?'0':'1');flipFit();setTimeout(layout,60);}});
  {const vs=root.querySelector('[data-vol]');if(vs)vs.oninput=()=>{musicVol=vs.value/100;try{localStorage.setItem('podrundown-crawl-music-vol',musicVol);}catch(_){}if(BGM)BGM.volume=musicVol;if(musicVol>0&&!musicMuted)musicStart();else if(BGM)BGM.pause();};}
  document.addEventListener('keydown',e=>{if(root.hidden)return;if(e.key==='Escape'&&!document.fullscreenElement)closeCrawl();if(e.key===' '&&CC.game){e.preventDefault();CC.paused=!CC.paused;}});
  window.addEventListener('resize',()=>{if(root&&!root.hidden)flipFit();layout();});root.addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('[data-flip]');if(!b)return;flipPref(root.classList.contains('rot-side')?'0':'1');flipFit();setTimeout(layout,60);if(SLOT()&&SLOT().run)showCamp();});window.addEventListener('scroll',()=>{if(root&&!root.hidden&&CC.lockY!=null&&(window.scrollY||window.scrollX))window.scrollTo(0,0);},{passive:true});document.addEventListener('fullscreenchange',()=>setTimeout(layout,60));
}
/* 0.12.56 (Kyle): phones get a closer camera. The fight happens in the bottom fifth of the picture, so on a phone we
   blow the picture up and crop: sideways phones fill the width and lose some sky; upright phones zoom 2x and the camera follows the party.
   Desktop is unchanged (Auto = whole field). The 🔍 button cycles Auto / 1x / 1.5x / 2x. */
let CAMZ=(()=>{try{return +(localStorage.getItem('cc-zoom')||0)||0;}catch(e){return 0;}})(),CAM={sc:1,vw:0,vh:0,cw:0,ch:0,on:false,x:null};
const handset=()=>!!(window.PodSideways&&PodSideways.isPhone())||!!(root&&root.classList.contains('rot-side'));
/* 0.12.417 (Kyle): a Flip switch that works on any phone. '1' = always sideways, '0' = never, unset = the old automatic check */
const flipPref=v=>{try{if(v!=null)localStorage.setItem('cc-flip',v);return localStorage.getItem('cc-flip');}catch(e){return null;}};
function flipFit(){if(!root)return;const f=flipPref();if(f==='1')root.classList.add('rot-side');else if(f==='0')root.classList.remove('rot-side');else if(window.PodSideways)PodSideways.fitSideways(root);}
const ovHost=()=>root&&root.classList.contains('rot-side')?root:document.body;   /* pop-up screens go inside the turned game */
function layout(){if(!root||root.hidden)return;root.classList.toggle('phone',handset());const main=$('.cc-main',root);const W=main.clientWidth,H=main.clientHeight;const wrap=$('.cc-cvw',root);
  const land=W>H*1.25&&H<620;root.classList.toggle('land',land);
  hud.classList.toggle('tall',!land&&H>W*1.2);
  const reserved=land?0:(info.offsetHeight+hud.offsetHeight+4);const avH=Math.max(120,H-reserved);let w=Math.min(W,avH*16/9);
  const k=Math.floor(w/384);if(k>=2&&k*384>=w*.82)w=k*384;
  let z=CAMZ||(handset()?(land?'fill':2):1);
  let cw=w,ch=w*9/16,vw=w,vh=ch;
  if(z==='fill'){cw=W;ch=W*9/16;vw=W;vh=Math.min(ch,avH);}
  else if(z>1){cw=w*z;ch=cw*9/16;vw=Math.min(W,cw);vh=Math.min(avH,ch);}
  cw=Math.floor(cw);ch=Math.floor(ch);vw=Math.floor(vw);vh=Math.floor(vh);
  CAM.on=cw>vw+1||ch>vh+1;CAM.sc=cw/384;CAM.vw=vw;CAM.vh=vh;CAM.cw=cw;CAM.ch=ch;if(!CAM.on)CAM.x=null;
  wrap.classList.toggle('cam',CAM.on);wrap.style.width=vw+'px';wrap.style.height=vh+'px';
  cv.style.width=cw+'px';cv.style.height=ch+'px';panCam();
  bossEl.style.top=(wrap.offsetTop+vh*.06)+'px';banner.style.top=(wrap.offsetTop+vh*.38)+'px';}
/* keep the party (and a bit of what's ahead of them) in view; always keep the ground at the bottom */
function panCam(){if(!CAM.on){cv.style.left='0px';cv.style.top='0px';return;}const g=CC.game;const sc=CAM.sc;
  let fx=192;if(g&&g.heroes){const al=g.heroes.filter(h=>h.alive);if(al.length){const xs=al.map(h=>h.x);fx=(Math.min(...xs)+Math.max(...xs))/2+55;}}
  CAM.x=CAM.x==null?fx:CAM.x+(fx-CAM.x)*.08;
  const L=Math.max(CAM.vw-CAM.cw,Math.min(0,CAM.vw/2-CAM.x*sc)),T=CAM.vh-CAM.ch;
  cv.style.left=Math.round(L)+'px';cv.style.top=Math.round(T)+'px';}
/* 0.12.376 (Kyle): while the game is open the site page underneath is pinned in place, so taps, buttons and re-drawn screens can never
   scroll it; closing the game puts the page back exactly where it was. Only the person scrolls the site. */
function lockPage(){if(CC.lockY!=null)return;CC.lockY=window.scrollY;CC.lockX=window.scrollX;const b=document.body.style;CC.lockSt={position:b.position,top:b.top,left:b.left,right:b.right,width:b.width,overflow:b.overflow};
  Object.assign(b,{position:'fixed',top:-CC.lockY+'px',left:-CC.lockX+'px',right:'0',width:'100%',overflow:'hidden'});document.documentElement.style.overscrollBehavior='none';}
function unlockPage(){if(CC.lockY==null)return;Object.assign(document.body.style,CC.lockSt||{});document.documentElement.style.overscrollBehavior='';const y=CC.lockY,x=CC.lockX;CC.lockY=null;window.scrollTo(x,y);}
function openCrawl(){build();root.hidden=false;musicStart();lockPage();stopStrip();flipFit();CC.data=Save.load();for(const p in CC.data.players)for(const s of CC.data.players[p].slots||[])if(s)migrateSlot(s,p);Save.write(CC.data);showWho();layout();}
function closeCrawl(){musicStop();if(CC.game&&!CC.game.over)quitToCamp(true);CC.game=null;cancelAnimationFrame(CC.raf);root.hidden=true;unlockPage();try{if(document.fullscreenElement)document.exitFullscreen();}catch(e){}startStrip();}
function showPanel(html){installTips();const wy=window.scrollY,wx=window.scrollX,key=html.replace(/\d+(\.\d+)?/g,'#').slice(0,200),same=!panel.hidden&&panel._k===key,pt=panel.scrollTop,pl=panel.scrollLeft;panel._k=key;
  /* 0.12.376 (Kyle): pressing a button that redraws the same screen keeps every scroll where you left it (the panel AND any scrolling box
     inside it, like the talent trees); changing numbers no longer count as a new screen. Only a different screen starts at the top. */
  const inner=same?[...panel.querySelectorAll('div')].map((d,i)=>[i,d.scrollTop,d.scrollLeft]).filter(r=>r[1]||r[2]):[];
  panel.hidden=false;const rb=root.querySelector('[data-a=restart]');if(rb)rb.hidden=true;panel.innerHTML=`<div class="cc-wrap">${html}</div>`;panel.scrollTop=same?pt:0;panel.scrollLeft=same?pl:0;{const T=same?pt:0,Lf=same?pl:0,keep=()=>{if(Math.abs(panel.scrollTop-T)>1)panel.scrollTop=T;if(Math.abs(panel.scrollLeft-Lf)>1)panel.scrollLeft=Lf;};requestAnimationFrame(()=>{keep();requestAnimationFrame(keep);});}   /* 0.12.378: the browser's own scroll-anchoring can't shove it afterwards either */
  if(inner.length){const D=panel.querySelectorAll('div');for(const [i,t,l] of inner)if(D[i]){D[i].scrollTop=t;D[i].scrollLeft=l;}}if(CC.lockY==null){window.scrollTo(wx,wy);requestAnimationFrame(()=>{if(Math.abs(window.scrollY-wy)>2)window.scrollTo(wx,wy);});}   // 0.12.80: re-rendering a screen (feeding, buttons) no longer jumps the page scroll
  hud.innerHTML='';info.innerHTML='';bossEl.textContent='';drawIdle();return panel;}
function drawIdle(){const g=CC.idle||(CC.idle=demoGame(384));ctx.imageSmoothingEnabled=false;if(IMG.complete&&BGI.complete)drawGame(ctx,g,384,0);}
// ---------------------------------------------------------------- screens
/* 0.12.330 (Kyle): no player names on the first screen (people who aren't in the pod got confused). One profile per device: a New game button
   that goes straight to the 5 save files, plus this device's best runs. Older saves made under a name are kept: the profile is whichever
   name on this device has the most progress (Kyle's own saves stay where they are). */
function devProfile(){const ps=Object.keys(OWNERS);let best=ps[0],bs=-1;for(const p of ps){const b=bestOf(p),v=(b.prestige||0)*1000+(b.stage||0)*10+((CC.data.players[p]&&CC.data.players[p].slots||[]).some(Boolean)?1:0);if(v>bs){bs=v;best=p;}}return best;}
function showWho(){const p=devProfile();CC.player=p;CC.unlocked[p]=1;const slots=((CC.data.players[p]||{}).slots||[]).map((s,i)=>s&&{i,s}).filter(Boolean);
  const P=showPanel(`<div class="cc-h">⚰️ CRYPT CRAWL</div><p class="cc-sub">Your heroes march through the dead lands on their own. You pick the team, the upgrades and when to push on. Fall and you keep your heroes and gear, so you can always grind your way past a tough stage.</p>
  <div class="cc-row" style="margin:14px 0"><button class="cc-btn go" data-go style="font-size:16px;padding:12px 26px">▶ NEW GAME / CONTINUE</button></div>
  <div class="cc-h" style="margin-top:18px;font-size:12px">🏆 YOUR RUNS</div>
  ${slots.length?`<table class="cc-lb"><tr><th>Save</th><th>Furthest</th><th>Best score</th><th>Now</th></tr>${slots.map(({i,s})=>`<tr><td>Save ${i+1}</td><td>${s.best&&s.best.stage?`Stage ${Math.min(s.best.stage,CFG.maxStage)}${s.best.prestige?' · ★'+s.best.prestige:''}`:'—'}</td><td>${s.best&&s.best.score?fmt(s.best.score):'—'}</td><td>${s.run?`Stage ${s.run.stage} · ${fmt(s.run.score||0)}`:'—'}</td></tr>`).join('')}</table>`:'<p class="cc-sub">No runs yet.</p>'}
  <details style="margin-top:14px"><summary class="cc-sub" style="cursor:pointer">How it works</summary><p class="cc-sub">There are 5 save files on this device. Hero levels, gold and items stay with the save, and nothing is lost when the party falls. Lower-level heroes earn catch-up XP. Between stages you camp: spend level-ups, then press Begin. Beat stage ${CFG.maxStage} to Prestige and loop with tougher monsters.</p></details>`);
  P.querySelector('[data-go]').onclick=()=>showSlots();
}
function showPin(){
  const p=PL();const setting=!p.pin;let entry='',first=null;
  const draw=()=>{const P=showPanel(`<div class="cc-h">${OWNERS[CC.player]} ${CC.player.toUpperCase()}</div><p class="cc-sub">${setting?(first?'Type it again to confirm.':'Pick a 4-digit PIN. It keeps your saves yours.'):'Enter your PIN.'}</p>
    <div class="cc-dots">${[0,1,2,3].map(i=>`<i class="${i<entry.length?'on':''}"></i>`).join('')}</div>
    <div class="cc-pin">${[1,2,3,4,5,6,7,8,9,'⌫',0,'↩'].map(k=>`<button data-k="${k}">${k}</button>`).join('')}</div>
    <p class="cc-sub" style="text-align:center">PINs are saved on this device only. Forgot yours? Kyle can reset it from his saves screen.</p>`);
    P.querySelectorAll('[data-k]').forEach(b=>b.onclick=()=>key(b.dataset.k));};
  const bad=()=>{const d=$('.cc-dots',panel);d.classList.remove('bad');void d.offsetWidth;d.classList.add('bad');};
  const key=k=>{if(k==='↩')return showWho();if(k==='⌫'){entry=entry.slice(0,-1);return draw();}if(entry.length<4)entry+=k;draw();
    if(entry.length===4)setTimeout(()=>{if(setting){if(!first){first=entry;entry='';draw();}else if(first===entry){p.pin=Save.pinHash(CC.player,entry);persist();CC.unlocked[CC.player]=1;showSlots();}else{first=null;entry='';draw();bad();}}
      else if(Save.pinHash(CC.player,entry)===p.pin){CC.unlocked[CC.player]=1;showSlots();}else{entry='';draw();bad();}},120);};
  draw();
}
function showSlots(){
  const p=PL();
  const P=showPanel(`<div class="cc-h">💾 SAVES</div><p class="cc-sub">Five separate games. Try different hero combos in each.</p>
  <div class="cc-load">${p.slots.map((s,i)=>{if(!s)return `<div class="cc-card"><b>Save ${i+1}</b> · empty<div class="cc-row" style="margin-top:8px"><button class="cc-btn go" data-new="${i}">NEW SAVE</button></div></div>`;
    migrate(s,CC.player);if(!s.team&&s.run)s.team=s.run.team.slice();const top=Object.entries(s.heroes).sort((a,b)=>b[1].lvl-a[1].lvl).slice(0,4).map(([k,v])=>`${heroDef(k).icon} ${esc(heroDef(k).name)} <b>Lv ${v.lvl}</b>`).join(' · ');
    return `<div class="cc-card"><b>Save ${i+1}</b> · 💰 ${fmt(s.gold||0)} · best stage ${s.best.stage||0}${s.best.prestige?' ★'+s.best.prestige:''} · best score ${fmt(s.best.score)} · ${s.runs} runs
      ${s.run?`<div class="cc-sub" style="margin:0 0 6px">Run in progress: stage ${s.run.stage}${s.run.prestige?' ★'+s.run.prestige:''} with ${s.run.team.map(k=>esc(heroDef(k).name)).join(', ')}</div>`:''}
      <div class="cc-row">${s.run||(s.team&&s.team.length)?`<button class="cc-btn go" data-cont="${i}">CONTINUE</button>`:`<button class="cc-btn go" data-team="${i}">BEGIN</button>`}${s.run||(s.team&&s.team.length)||s.runs?`<button class="cc-btn warn" data-del="${i}">Delete</button>`:''}</div></div>`;}).join('')}</div>
  <div class="cc-row" style="margin-top:12px"><button class="cc-btn" data-back>← Players</button></div>`);
  P.querySelector('[data-back]').onclick=showWho;
  P.querySelectorAll('[data-reset]').forEach(b=>b.onclick=()=>{const who=b.dataset.reset;if(!confirmInline(b,`Reset ${who}'s PIN?`))return;CC.data.players[who].pin=null;delete CC.unlocked[who];persist();
    if(who==='Kyle'){CC.unlocked.Kyle=0;return showPin();}showSlots();});
  P.querySelectorAll('[data-new]').forEach(b=>b.onclick=()=>{p.slots[+b.dataset.new]=newSlot(CC.player);persist();CC.slotIdx=+b.dataset.new;showTeam();});
  P.querySelectorAll('[data-cont]').forEach(b=>b.onclick=()=>{const i=+b.dataset.cont,S=p.slots[i];CC.slotIdx=i;if(S.run)showCamp();else restartSameTeam(S,S.team);});   /* 0.12.171: Continue picks the run back up, or starts the next run with the save's team */
  P.querySelectorAll('[data-team]').forEach(b=>b.onclick=()=>{const i=+b.dataset.team,S=p.slots[i];CC.slotIdx=i;if(S.run)return;if(S.team&&S.team.length)restartSameTeam(S,S.team);else showTeam();});
  P.querySelectorAll('[data-del]').forEach(b=>b.onclick=()=>{if(!confirmInline(b,'Delete forever?'))return;p.slots[+b.dataset.del]=null;persist();showSlots();});
}
function confirmInline(b,msg){if(b.dataset.armed)return true;b.dataset.armed=1;const t=b.textContent;b.textContent=msg+' Tap again';setTimeout(()=>{if(b.isConnected){delete b.dataset.armed;b.textContent=t;}},2600);return false;}
/* 0.12.57 (Kyle): PWR and SPD used the old flat atk/aspd numbers, which are the same for every hero now that damage comes from dice.
   PWR is now his best basic attack's damage per second (dice, flat bonus, pellets, crit), SPD how many basic attacks he gets off per second.
   Both are scaled against the best in the roster so the bars spread out. */
function atkProfile(k){const C=CHAR[k]||{};let best={dps:0,rate:0};
  for(const [nm,A] of Object.entries(C)){if(!A||typeof A!=='object'||!Array.isArray(A.dice)||!(A.every>0))continue;
    const avg=(A.dice[0]*(A.dice[1]+1)/2+(A.flat||0))*(1+((A.pellets||1)-1)*.5);/* pellets spread wide: count about half of the extras as landing */const clip=A.clip||1,cyc=clip>1?((clip-1)*A.every+(A.reload||A.every))/clip:A.every;
    const dps=avg/cyc*(1+(C.crit||0)*((C.critMul||1.75)-1));const r=best.rate;if(dps>best.dps)best={dps,rate:r,nm,avg};best.rate=Math.max(best.rate,1/cyc);}
  return best;}
/* 0.12.293 (Kyle): hero card bars are now OFFENSE / DEFENSE / UTILITY, each rated 1-10 against the roster.
   How they were worked out: OFFENSE comes from simulated stages (average damage dealt per second, 16 heroes, mixed teams, stages 3 and 6),
   nudged by kit; DEFENSE from HP, armor, damage reduction, shields, self-heals and escapes; UTILITY from what the hero does for the team
   (heals and shields measured in the same sims, plus buffs, crowd control, summons and builds). Re-run the sim and update this table after big rebalances. */
const HERO_RATING={
  cheez:[10,5,7],chibi:[9,6,6],jp:[8,5,7],edward:[7,6,7],soldier:[7,6,6],cultist:[7,6,5],archer:[7,3,4],
  shoshi:[6,5,9],teeg:[8,6,5],seekyle:[5,6,10],flannel:[6,7,3],alchemist:[5,4,9],robot:[6,9,5],knight:[6,10,4],lumberjack:[6,8,3],eng:[5,5,9],druid:[4,4,10]};
function heroRatings(k){const r=HERO_RATING[k]||[5,5,5];return {o:r[0],d:r[1],u:r[2]};}
function pipBar(n,col){let h='';for(let i=0;i<10;i++)h+=`<b style="${i<n?`background:${col};box-shadow:0 0 4px ${col}`:''}"></b>`;return `<i class="cc-pips">${h}</i>`;}
function statBars(k,lvl){const R=heroRatings(k),b=heroBase(k,lvl,3),P=atkProfile(k);
  return `<div class="cc-stat cc-stat3">
    <span title="Offense ${R.o}/10: how much damage he puts out (basic attack about ${P.dps.toFixed(1)} a second with ${P.nm||'basic'}, plus his damaging abilities).">⚔️ OFF</span>${pipBar(R.o,'#ff5a3a')}<em>${R.o}</em>
    <span title="Defense ${R.d}/10: ${b.hp} HP${b.armorPts?`, ${b.armorPts} armor`:''}, plus damage reduction, shields, self-heals and escapes.">🛡️ DEF</span>${pipBar(R.d,'#4cb8ff')}<em>${R.d}</em>
    <span title="Utility ${R.u}/10: what he does for the team: heals, shields, buffs, crowd control (stuns, roots, slows, fear), summons and builds.">✨ UTL</span>${pipBar(R.u,'#7dff5a')}<em>${R.u}</em></div>`;}
const ROLE={melee:'Melee',ranged:'Ranged',caster:'Caster',duo:'Duo',gunner:'Rifle + Melee',blade:'Sword'};
/* 0.12.170 (Kyle): a save keeps one team for good. The party is picked once, when the save is made; later runs restart with that same team. */
function restartSameTeam(s,team){for(const k of team){const H=s.heroes[k];if(H){H.lvl=1;H.xp=0;H.pts={};H.tal=[];H.offer=null;H.tree={};H.treeV=5;H.tk=k;}}const wasU=!!(s.run&&s.run.uncensored);s.run=newRun(team,s);const M=s.lastModes||{};s.run.hardcore=!!M.hardcore;s.run.dnd=!!M.dnd;s.run.uncensored=wasU;if(s.run.dnd)s.run.rolls=rollPersonas(team);s.runs++;persist();showCamp();}
/* 0.12.424 (Kyle) role chips and the team-role bar */
function roleChips(k,sm){return (ROLE_OF[k]||[]).map(r=>{const R=ROLES[r];return `<span class="cc-role" style="--rc:${R.c};${sm?'font-size:9px;padding:0 4px':''}" title="${esc(R.name)}: ${esc(R.tiers.map((t,i)=>(i+1)+': '+R.txt(t)).join(' · '))}">${R.icon} ${R.name}</span>`;}).join('');}
function roleBar(keys,full){const T=teamRoles(keys);return `<div class="cc-rbar">${Object.keys(ROLES).filter(r=>full||T[r]).map(r=>{const R=ROLES[r],on=T[r],n=on?on.n:0;
  return `<div class="cc-rb${on?' on':''}" style="--rc:${R.c}" title="${esc(R.name)} (team bonus): ${esc(R.tiers.map((t,i)=>(i+1)+' hero'+(i?'es':'')+': '+R.txt(t)).join(' · '))}"><b>${R.icon} ${R.name}</b> <span class="pips">${[0,1,2].map(i=>`<i class="${i<n?'f':''}"></i>`).join('')}</span><span class="rt">${on?esc(R.txt(on.t)):'1 hero: '+esc(R.txt(R.tiers[0]))}</span></div>`;}).join('')||'<span class="cc-sub" style="font-size:11px">No team roles yet.</span>'}</div>`;}
function showTeam(){
  setRunModes(null);  const s=SLOT();migrate(s,CC.player);s.partySize=3;const pick=[];   /* 0.12.33: back to a 3-hero party */
  const mine=DATA.heroes.slice();   /* 0.12.92: every player uses the shared roster */
  const P=showPanel(`<div class="cc-h">PICK YOUR PARTY</div><p class="cc-sub">Up to 3 heroes from your decks. Fewer heroes = each one is stronger. Lower-level heroes earn catch-up XP.</p><div class="cc-sub" style="font-size:11px;margin:2px 0">TEAM ROLES: every hero brings a role; the whole team gets its bonus, a little more for each hero who shares it.</div><div data-roles>${roleBar([],true)}</div>
    <div class="cc-heroes">${mine.map(h=>{const st=STYLE[h.key];const H=s.heroes[h.key],L=H.lvl;const tip=[h.name,'',BEHAVIOR[h.key]||h.blurb||'','',...personaLines({key:h.key,insp:H.insp})].join('\n');
      return `<div class="cc-hw"><button class="cc-hero" data-k="${h.key}" aria-pressed="false" data-tiph="${esc(howTip(h.key,H.insp))}"><span class="ord"></span><span class="por" data-por="${h.key}"></span><div class="nm"><span class="ic">${h.icon}</span><span class="tx" style="${h.name.length>12?'font-size:.86em':''}">${esc(h.name)}</span></div><div class="cc-rchips">${roleChips(h.key)}${h.key==='robot'?'<span class="cc-role" style="--rc:#9aa4b0" title="A machine: healing, potions and healing magic do nothing for it. Its own repair bots and the Builders\' Tinker (Engineer, Eddie, Shoshi) fix it.">⚙ Machine</span>':''}</div>${h.deck?`<div class="dk">Built from deck: <b>${esc(h.deck)}</b></div>`:''}<div class="dk">${(CHAR[h.key]&&CHAR[h.key].role)||ROLE[st.atk]}${st.tank?' · Tank':''}${st.companion?' · with companion':''}</div>
      <div class="lv">LV ${L}</div><div class="dk">🧠 Personality: <b>${esc(personaTitle({key:h.key,insp:H.insp}))}</b> <span style="opacity:.7">(hover the card for how it fights)</span></div>${statBars(h.key,L)}<div class="cc-abl">${abOrder((CHAR[h.key]||{}).abilities).map(a=>`<span class="cc-ab${a.passive?' pas':''}" tabindex="0" data-tiph="${esc('<div class=tt-h>'+(a.passive?'✦ ':'⚡ ')+esc(a.name.replace(/_/g,' '))+(a.passive?' <span style=opacity:.7>(passive)</span>':'')+'</div>'+fmtAbil(abilDesc(h.key,H,a.id)||a.name))}">${a.passive?'✦':'⚡'} ${esc(a.name)}</span>`).join('')||'<span class="dk" style="opacity:.6">No abilities yet</span>'}</div></button>
      <div class="cc-insp" data-ik="${h.key}"><div class="cc-sub" style="margin:4px 0 2px;font-size:10px">✨ INSPIRATION DECK</div>
        <select data-ip><option value="">Pick a player…</option>${Object.keys(PLAYER_ICON).map(p=>`<option value="${p}"${H.insp&&INSP[H.insp]&&INSP[H.insp].o===p?' selected':''}>${PLAYER_ICON[p]} ${p}</option>`).join('')}</select>
        <select data-id ${H.insp?'':'disabled'}></select><div class="cc-ibx"></div></div></div>`;}).join('')}</div>
    <div class="cc-row" style="margin-top:12px"><label class="cc-sub" style="margin:0 8px 0 0;font-size:12px;cursor:pointer" data-tipt="Friendly fire: your heroes' shots can hit allies in the way, and your own explosions (Trip Bomb, its shockwave, missiles, planted mines) hurt your units too."><input type="checkbox" data-hc ${s.lastModes&&s.lastModes.hardcore?'checked':''}> ☠ Hardcore</label><label class="cc-sub" style="margin:0 10px 0 0;font-size:12px;cursor:pointer" data-tipt="Every hero's 20 personality sliders are rolled (2d6-2 each) when the run starts instead of using their fixed values. Deck nudges still apply on top."><input type="checkbox" data-dnd ${s.lastModes&&s.lastModes.dnd?'checked':''}> 🎲 D&amp;D mode</label><label class="cc-sub" style="margin:0 10px 0 0;font-size:12px;cursor:pointer" data-tipt="Lets the crew swear: JP's full mouth, Tee's trash talk and the salty radio. Off by default; with it off every line stays PG and anything that slips through gets bleeped."><input type="checkbox" data-unf> 🤬 Unfiltered</label><button class="cc-btn go" data-go disabled>START RUN</button><button class="cc-btn" data-back>← Saves</button></div>`);
  P.querySelectorAll('[data-por]').forEach(e=>{try{e.replaceWith(portrait(e.dataset.por));}catch(err){console.warn('portrait',e.dataset.por,err);}});   /* 0.12.428: one bad portrait can't break the pick screen */
  // Inspiration: player first, then that player's decks (each option shows its bonus). Saved per hero on this save slot.
  P.querySelectorAll('.cc-insp').forEach(box=>{try{const k=box.dataset.ik,H=s.heroes[k];const ip=box.querySelector('[data-ip]'),id=box.querySelector('[data-id]'),ib=box.querySelector('.cc-ibx');
    const fill=()=>{const p=ip.value;id.disabled=!p;id.innerHTML=p?`<option value="">Pick a deck…</option>`+Object.keys(INSP).filter(d=>INSP[d].o===p).map(d=>`<option value="${esc(d)}"${H.insp===d?' selected':''}>${esc(d)}: ${esc(inspText(d))}</option>`).join(''):'<option>Pick a player first</option>';show();};
    const show=()=>{const d=H.insp;ib.innerHTML=d&&INSP[d]?`<b>${esc(d)}</b>: ${esc(inspText(d))}<br><span style="opacity:.7">${esc(INSP[d].why)}</span><ul style="margin:4px 0 0;padding-left:14px">${inspHelp(d).map(t=>`<li style="margin-top:2px">${esc(t)}</li>`).join('')}</ul>${cdrTable(k,d)}`:'<span style="opacity:.6">No inspiration yet</span>';
      const b=box.parentNode.querySelector('.cc-hero');if(b){b.dataset.tiph=howTip(k,H.insp);const pt=b.querySelector('.dk b');if(pt)pt.textContent=personaTitle({key:k,insp:H.insp});const t=b.querySelector('.dk b');}};
    ip.onchange=()=>{if(!ip.value||(H.insp&&INSP[H.insp]&&INSP[H.insp].o!==ip.value)){H.insp=null;persist();}fill();};
    id.onchange=()=>{H.insp=id.value||null;persist();show();};fill();}catch(err){console.warn('insp',err);}});
  const upd=()=>{P.querySelectorAll('.cc-hero').forEach(b=>{const i=pick.indexOf(b.dataset.k);b.setAttribute('aria-pressed',i>=0);b.querySelector('.ord').textContent=i>=0?i+1:'';});
    {const rb=P.querySelector('[data-roles]');if(rb)rb.innerHTML=roleBar(pick,true);}
    const g=P.querySelector('[data-go]');g.disabled=!pick.length;delete g.dataset.sure;g.textContent=`START RUN (${pick.length}/${s.partySize||2})`;};
  P.querySelectorAll('.cc-hero').forEach(b=>b.onclick=()=>{const k=b.dataset.k,i=pick.indexOf(k);if(i>=0)pick.splice(i,1);else if(pick.length<(s.partySize||3))pick.push(k);upd();});
  P.querySelector('[data-back]').onclick=showSlots;
  P.querySelector('[data-go]').onclick=()=>{const g0=P.querySelector('[data-go]');const noI=pick.filter(k=>!(s.heroes[k]&&s.heroes[k].insp&&INSP[s.heroes[k].insp]));   /* 0.12.342 (Kyle): are-you-sure if a hero has no Inspiration */
    if(noI.length&&!g0.dataset.sure){g0.dataset.sure=1;g0.textContent='No Inspiration for '+noI.map(k=>heroDef(k).name).join(', ')+'. Start anyway? ▶';return;}
    s.team=pick.slice();s.run=newRun(pick,s);s.lastModes={hardcore:!!P.querySelector('[data-hc]').checked,dnd:!!P.querySelector('[data-dnd]').checked};s.run.hardcore=s.lastModes.hardcore;s.run.dnd=s.lastModes.dnd;s.run.uncensored=!!P.querySelector('[data-unf]').checked;if(s.run.dnd)s.run.rolls=rollPersonas(pick);s.runs++;persist();showCamp();};upd();P.addEventListener('change',e=>{if(e.target.closest&&e.target.closest('.cc-insp'))upd();});
}
/* camp panel: supplies, what the camp did on arrival, upgrades (pick 1 of the offers per camp), Triage builds */
function campPanel(s,run,btn){const gold=s.gold||0,parts=s.parts||0;const food=run.food||0;run.haggle=haggleOf(s,run);run.resource=resourcefulOf(s,run);
  const owned=Object.keys(run.upg||{}).filter(id=>run.upg[id]);
  const tent=`<span class="cc-tent" style="cursor:help;font-size:36px;margin-left:8px;display:inline-flex;align-items:center;gap:6px;padding:2px 12px;border:1px dashed #a6ff2e88;border-radius:10px;animation:ccTentPulse 2.2s ease-in-out infinite" data-tiph="${esc('<b>⛺ Every camp upgrade</b><br>'+Object.keys(CAMP_UPG).map(id=>{const U=CAMP_UPG[id],t=upgT(run,id);const mx=U.needs?(Object.keys(U.needs).every(k=>upgT(run,U.needs[k])>0)?U.tiers.length:U.tiers.length-1):U.tiers.length;return `${U.icon} ${U.name}: <b style="color:${t?'#a6ff2e':'#9a90a8'}">${t}/${mx}</b> <span style="opacity:.6">(${U.tiers.map(g=>Math.max(25,Math.round(g*(1-(run.haggle||0))*.75/25)*25)+'g').join(' / ')})</span>`;}).join('<br>')+(run.haggle?`<br><br>🤝 Haggler: upgrades ${Math.round(run.haggle*100)}% off`:'')+(run.resource?`<br>🧰 Resourceful: you can pay in spare parts`:''))}">⛺<span style="font-size:10px;color:#a6ff2e">ⓘ</span></span>`;
  const sup=`<div class="cc-card"><b>🏕️ Camp</b>${tent} <span class="cc-sub" style="font-size:12px">💰 <b style="color:#ffd23f">${fmt(gold)}</b> gold · ⚙️ <b>${parts}</b> spare parts · 🥫 <b>${Number.isInteger(food)?food:Math.floor(food)+'½'}</b> food · 💧 <b>${run.water||0}</b> water${Object.keys(MEDS).some(m=>(run.med||{})[m])?' · '+Object.keys(MEDS).filter(m=>(run.med||{})[m]).map(m=>`<span title="${esc(MEDS[m].name+': '+MEDS[m].txt)}" style="cursor:help">${MEDS[m].icon} <b>${run.med[m]}</b></span>`).join(' '):''} · <span title="Reroll dice (max 3): swap the camp upgrade offers or a hero's ⬆ Upgrade picks. Every stage you finish, won or lost, charges 25% of a die." style="cursor:help">${diceStr(run)}</span>${(s.lucky||0)?` · <span title="Lucky Dice: very rare loot. Spend one on a hero (button on their card) to gamble a basic attack's die size." style="cursor:help">${luckyStr(s)}</span>`:''}</span>${run.team.some(k=>missingOf(run,k)&&run.heroes[k]&&!run.heroes[k].dead)?` <button class="cc-btn" data-feedall style="padding:6px 16px;font-size:24px;vertical-align:middle" title="Feed and water everyone who needs it: most-needy and lowest HP first, never wastes supplies"><svg width="32" height="28" viewBox="0 0 16 14" style="vertical-align:-2px;image-rendering:pixelated"><rect x="1" y="5" width="7" height="8" fill="#b8642a"/><rect x="1" y="5" width="7" height="2" fill="#e8d0a0"/><rect x="2" y="8" width="5" height="3" fill="#e8302a"/><rect x="1" y="12" width="7" height="1" fill="#6a3a18"/><path d="M12 2 L14.5 7 A2.6 2.6 0 1 1 9.5 7 Z" fill="#4ab8ff"/><rect x="10.5" y="7" width="1" height="2" fill="#d8f4ff"/></svg> Feed all</button>`:''}
    ${(run.campLog||[]).length?`<div class="cc-sub" style="font-size:11px;margin:4px 0 0">${run.campLog.map(esc).join(' · ')}</div>`:''}
    ${run.eventLog?`<div class="cc-sub" style="font-size:12px;margin:6px 0 0;color:#ffd27a">${run.eventLog}</div>`:''}${run.evNext&&run.evNext.why&&run.evNext.why.length?`<div class="cc-sub" style="font-size:11px;margin:4px 0 0;color:#9ad0ff">⏭ Next stage: ${run.evNext.why.map(esc).join(' · ')}</div>`:''}${run.evPerm&&run.evPerm.why&&run.evPerm.why.length?`<div class="cc-sub" style="font-size:11px;margin:4px 0 0;color:#c8a0ff">♾ This run: ${run.evPerm.why.map(esc).join(' · ')}</div>`:''}
    ${owned.length?`<div class="cc-chips" style="margin-top:6px">${owned.map(id=>{const U=CAMP_UPG[id],t=run.upg[id];return `<span class="cc-chip" title="${esc(U.txt(t))}">${U.icon} ${esc(U.name)} ${['','I','II','III','IV'][t]}</span>`;}).join('')}</div>`:''}</div>`;
  const picked=run.picked||[];const offers=(run.offers||[]).filter(id=>picked.includes(id)||upgT(run,id)<CAMP_UPG[id].tiers.length);   /* 0.12.190 (Kyle): buy any or all of the 3 picks you can afford (each once per camp) */
  const up=`<div class="cc-card"><b>🔨 Camp upgrades</b> <span class="cc-sub" style="font-size:11px">${run.upgBought?`Buy any of the others you can still afford. New offers next camp.`:'Buy any or all of them you can afford, at the pick price.'} They last for this run.</span>${offers.length?(run.rerolls>=1?` <button class="cc-btn" data-reroll style="margin-left:6px;padding:2px 8px;font-size:11px" data-tipt="Spend 1 die: swap these 3 picks for 3 new ones. What you built stays built.">🎲 Reroll · ${diceStr(run)}</button>`:` <span class="cc-sub" style="font-size:11px;opacity:.7">${diceStr(run)}</span>`):''}
    <div class="cc-offers" style="margin-top:8px">${offers.map(id=>{const U=CAMP_UPG[id],t=upgT(run,id)+(picked.includes(id)?0:1),pr=upgPrice(run,id);return `<div class="cc-offer" style="--rc:${t>1?'#7fd0ff':'#a6ff2e'}"><span class="rar">${t>1?'TIER '+t:'NEW'}</span><span class="cn">${U.icon} ${esc(U.name)}${U.tiers.length>1?' '+['','I','II','III','IV'][t]:''}</span><span class="tx">${esc(U.txt(t))}</span>
      ${picked.includes(id)?`<button class="cc-btn" disabled>✓ Built</button>`:`<button class="cc-btn" data-upg="${id}" ${gold<pr?'disabled':''}>Build · ${fmt(pr)}g</button>${run.resource?`<button class="cc-btn" data-upgp="${id}" style="margin-top:4px" ${parts<upgParts(run,id)?'disabled':''}>Build · ⚙️ ${upgParts(run,id)} parts</button>`:''}`}</div>`;}).join('')||'<span class="cc-sub">Everything is fully built!</span>'}</div></div>`;
  const cl=conList(run);const con=`<div class="cc-card" style="border-color:#ffb020;box-shadow:0 0 0 1px #ffb02055,0 0 14px #ffb02033"><b>🏗️ Construction</b> <span class="cc-sub" style="font-size:11px">Build anything, as many as you like this camp, at <b>double</b> the pick price.</span>
    <button class="cc-btn" data-con style="margin-left:8px;background:#ffb020;color:#1a1000;font-weight:800">${run.conOpen?'▲ HIDE':'🏗️ OPEN CONSTRUCTION'}</button>
    ${run.conOpen?`<div class="cc-offers" style="margin-top:8px">${cl.map(id=>{const U=CAMP_UPG[id],t=upgT(run,id)+1,pr=conPrice(run,id);return `<div class="cc-offer" style="--rc:#ffb020"><span class="rar">${t>1?'TIER '+t:'NEW'}</span><span class="cn">${U.icon} ${esc(U.name)}${U.tiers.length>1?' '+['','I','II','III','IV'][t]:''}</span><span class="tx">${esc(U.txt(t))}</span>
      <button class="cc-btn" data-conb="${id}" ${gold<pr?'disabled':''}>Build · ${fmt(pr)}g</button>${run.resource?`<button class="cc-btn" data-conp="${id}" style="margin-top:4px" ${parts<conParts(run,id)?'disabled':''}>Build · ⚙️ ${conParts(run,id)} parts</button>`:''}</div>`;}).join('')||'<span class="cc-sub">Everything is fully built!</span>'}</div>`:''}</div>`;
  const tt=upgT(run,'triage');const tri=tt?`<div class="cc-card"><b>🩺 Triage Station ${['','I','II','III','IV'][tt]}</b> <span class="cc-sub" style="font-size:11px">${(run.triageN||0)}/${TRIAGE.max[tt-1]} built this camp · whoever you pick carries it into the next stage</span>
    ${[['med','Medkit','heals an ally under 50% for 35%'],['defib','Defibrillator','instantly revives a downed ally']].concat(run.team.includes('robot')?[['bat','Battery','+30 energy for the Warhound when he runs low']]:[]).map(([w,n,d])=>`<div class="cc-chips" style="align-items:center;margin-top:4px"><span class="cc-sub" style="font-size:11px;margin:0;min-width:180px"><b>${n}</b> · ⚙️ ${TRIAGE[w][tt-1]} · ${d}</span>${run.team.map(k=>btn(`data-tri="${w}|${k}" ${parts<TRIAGE[w][tt-1]||(run.triageN||0)>=TRIAGE.max[tt-1]?'disabled':''}`,'→ '+esc(heroDef(k).name.split(/[ _]/)[0]),'Build it for '+heroDef(k).name)).join(' ')}</div>`).join('')}
    <div class="cc-chips" style="align-items:center;margin-top:6px"><span class="cc-sub" style="font-size:11px;margin:0;min-width:180px"><b>Medical supplies</b> · go in the stash, no build limit</span>${Object.entries(MEDS).map(([m,M])=>btn(`data-medb="${m}" ${parts<M.parts?'disabled':''}`,`${M.icon} ${M.name} · ⚙️ ${M.parts}`,M.name+': '+M.txt)).join(' ')}</div></div>`:'';
  const tw=upgT(run,'tower');if(tw&&!run.scoutOffers)run.scoutOffers=scoutRoll(run);
  const tower=tw?`<div class="cc-card"><b>🗼 Watchtower ${['','I','II','III','IV'][tw]}</b> <span class="cc-sub" style="font-size:11px">Scouts report on the road ahead. ${tw>=4?'MAP TABLE: pick up to TWO roads for the next stage.':'Pick one for the next stage.'}</span>
    <div class="cc-offers" style="margin-top:8px">${(run.scoutOffers||[]).map(id=>{const S=SCOUT[id],on=[].concat(run.scoutPick||[]).includes(id);return `<div class="cc-offer" style="--rc:${on?'#a6ff2e':'#7fd0ff'}"><span class="cn">${S.icon} ${esc(S.name)}</span><span class="tx">${esc(S.txt(tw>=3?1.5:1))}</span><button class="cc-btn" data-scout="${id}" ${on&&tw<4?'disabled':''}>${on?(tw>=4?'Chosen ✓ (tap to drop)':'Chosen ✓'):'Take this road'}</button></div>`;}).join('')}</div></div>`:'';
  const rd=upgT(run,'radio');const radio=rd?(()=>{const F=radioForecast(run);return `<div class="cc-card"><b>📻 Radio Shack ${['','I','II'][rd]}</b> <span class="cc-sub" style="font-size:11px">Chatter about stage ${run.stage}: about <b>${F.foes}</b> undead in <b>${F.waves}</b> waves${F.wolves?' · 🐺 werewolves':''}${F.firemen?' · 🧑‍🚒 firemen':''}<br>🔋 Everyone starts the stage at full energy · first wave: ALERT (+10 accuracy)${rd>=2?' · ALERT on every wave · 📦 a supply drop halfway (food, water, 2 parts)':''}</span></div>`;})():'';   /* 0.12.105 */
  const stl=upgT(run,'still');const sF=[2,1.5,1,1][stl-1];const still=stl?`<div class="cc-card"><b>🫙 Moonshine Still ${['','I','II','III','IV'][stl]}</b> <span class="cc-sub" style="font-size:11px">A jar costs 🥫 ${sF} food + 💧 1 water, one for anyone you can afford · +20% damage, +10% attack speed, ${stl>=4?'15%':'10%'} less damage taken, ${stl>=4?'-15%':'-20%'} accuracy, steadier nerves until ${stl>=4?'the stage ends (going down no longer clears it)':stl===3?'they go down (50% chance it survives that) or the stage ends':'they go down or the stage ends'} (then pour another)</span>
    <div class="cc-chips" style="align-items:center;margin-top:4px">${run.team.filter(k=>k!=='robot').map(k=>(run.heroes[k].carry&&run.heroes[k].carry.courage)?`<span class="cc-chip" style="color:#ffd27a">🫙 ${esc(heroDef(k).name.split(/[ _]/)[0])} ✓ jar packed</span>`:btn(`data-brew="${k}" ${(run.food||0)<sF-1e-9||(run.water||0)<1?'disabled':''}`,'🫙 → '+esc(heroDef(k).name.split(/[ _]/)[0]),'Pour '+heroDef(k).name+' a jar: +20% damage, +10% attack speed, 10% less damage taken, -20% accuracy for the next stage')).join(' ')}</div></div>`:'';
  return radio+sup+con+up+tri+tower+still;}
/* 0.12.57 (Kyle): the camp screen opens on the party resting around a roaring fire at night (Diablo-style),
   idling with their normal animations, the fire flickering light over them. Everything else on the camp screen stays below it. */
const CAMPBG=new Image();CAMPBG.src='crawl_campbg.png';   /* 0.12.63 (Kyle): his cabin-at-night painting is the camp backdrop */
/* 0.12.446 (Kyle) the camp kennel: a little red-roofed doghouse beside the fire. Tap it for the breed book. */
function drawDoghouse(x,cx,gy,T,built){x.save();x.imageSmoothingEnabled=false;const P=(c,X,Y,w=1,h=1)=>{x.fillStyle=c;x.fillRect(X,Y,w,h);};   /* 0.12.447 (Kyle): weathered and grimy to fit the night camp */
  const L=cx-11,R=cx+11,top=gy-13;
  P('rgba(0,0,0,.45)',L-2,gy,27,2);
  for(let yy=top;yy<gy;yy++){const row=(yy-top)%3;P(row===0?'#1a120d':(row===1?'#3a2a20':'#30231b'),L,yy,22,1);}   // dark warped planks
  P('#1a120d',L+7,top,1,13);P('#1a120d',L+15,top+3,1,10);P('#4a3424',L+3,top+4,2,1);P('#4a3424',L+17,top+8,3,1);   // seams, knots
  P('#2a3a1e',L,gy-3,4,3);P('#33461f',L+1,gy-2,2,2);P('#2a3a1e',R-3,gy-2,3,2);   // moss creeping up the corners
  P('#070405',cx-4,gy-9,8,9);P('#070405',cx-3,gy-10,6,1);P('#2a1d16',cx-5,gy-10,1,10);P('#2a1d16',cx+4,gy-10,1,10);   // dark doorway
  P('#c8a050',cx-2,gy-6,1,1);P('#c8a050',cx+1,gy-6,1,1);   // two eyes glinting in the dark
  for(let k=0;k<8;k++){P(k%2?'#2b2628':'#36302f',L-3+k,top-k,28-2*k,1);}   // sagging slate roof
  P('#1a1618',L-3,top,28,1);P('#0d0a0b',L+4,top-3,2,1);P('#0d0a0b',R-6,top-5,2,1);P('#3d4a2a',R-4,top-1,3,1);   // missing shingles, moss
  P('#4a3c2c',cx-3,top-4,6,3);P('#2a2018',cx-2,top-3,1,1);P('#2a2018',cx+1,top-3,1,1);P('#5a2a1a',cx-1,top-2,2,1);   // scratched old plate, rusty nail
  P('#5a3a22',cx+4,gy-4,1,1);for(let k=0;k<5;k++)P(k%2?'#6a4a30':'#4a3020',cx+5+k,gy-3+(k>2?1:0),1,1);P('#3a2a20',R+4,gy-2,1,2);   // rusty chain to a stake
  P('#3a3a40',R+6,gy-2,5,2);P('#55555c',R+6,gy-2,5,1);P('#2a1f18',R+7,gy-2,3,1);   // dented food bowl
  P('#b8ac94',L-6,gy-1,4,1);P('#b8ac94',L-7,gy-2,1,1);P('#b8ac94',L-2,gy-2,1,1);   // an old bone
  const fl=.25+.08*Math.sin(T*11);x.globalAlpha=fl;P('#ff9a40',L,top,1,13);P('#ff9a40',L-3,top,6,1);x.globalAlpha=1;   // firelight on the side facing the fire
  if(!built){x.globalAlpha=.55;P('#000',L-3,top-8,28,22);x.globalAlpha=1;}
  const a=.35+.35*Math.sin(T*3);x.globalAlpha=a;const px=R+1,py=top-9;P('#ffd9a0',px,py+2,3,2);P('#ffd9a0',px-1,py,1,1);P('#ffd9a0',px+1,py-1,1,1);P('#ffd9a0',px+3,py,1,1);x.globalAlpha=1;x.restore();}
function showKennelBook(run){let ov=document.getElementById('cc-kbook');if(ov)ov.remove();const kt=upgT(run,'kennel');
  ov=document.createElement('div');ov.id='cc-kbook';ov.style.cssText='position:fixed;inset:0;z-index:9000;background:rgba(4,2,8,.88);display:flex;align-items:center;justify-content:center;padding:8px';
  const pc=v=>(v>0?'+':'')+Math.round(v*1000)/10+'%';
  const card=(B,big)=>{const st=[];const bite=100*(1+(B.bite||0));st.push('🦷 Bite '+Math.round(bite)+'%');st.push('❤️ '+(big?7+(B.hitsX||0):5)+' hits');if(B.dodge)st.push('💨 Dodge '+pc(B.dodge));if(B.spd)st.push('⚡ Bites '+Math.round(B.spd*100)+'% faster');if(B.regen)st.push('🔁 Gets hits back '+Math.round(B.regen*100)+'% faster');if(B.crit)st.push('🎯 '+Math.round(B.crit*100)+'% crit at '+B.critMul+'x');if(B.nudge)st.push('🛡️ Shrugs off '+Math.round(B.nudge*100)+'% of hits');if(B.medic)st.push('🍶 Heals an ally 8% every 6s');if(B.taunt)st.push('📣 Booming bark every 8s: zombies within 70 attack it for 3s');if(big)st.push('📏 '+Math.round(((B.sz||1.22)-1)*100)+'% bigger · bite range 20');else st.push('📏 Bite range 15');
    const mood=Object.entries(B.mood||{}).map(([k,v])=>{const w=TRAIT_WORDS[k];return w?`<span class="kb-tr ${v>0?'up':'dn'}">${w[v>0?1:0]} ${v>0?'+':''}${v}</span>`:'';}).join('');
    return `<div class="kb-card${big?' big':''}"><canvas data-dogskin="${B.skin}" width="124" height="68"></canvas><div class="kb-tx"><div class="kb-nm">${esc(B.name.replace(/_/g,' '))}${big?' <span class="kb-lg">LARGE BREED</span>':''}</div><div class="kb-ab">${esc(B.about||'')}</div><div class="kb-st">${st.join(' · ')}</div><div class="kb-mood">${mood||'<span class="kb-tr">Even temperament</span>'}</div>${pickBtn(B,big)}</div></div>`;};
  const DP=run.dogPick||{};const pickBtn=(B,big)=>{const on=DP[big?'big':'reg']===B.name;if(big&&kt<5)return '<div class="kb-pk off">Unlocks at Kennel V</div>';if(!kt)return '';return `<button class="kb-pk${on?' on':''}" data-kpick="${big?'big':'reg'}|${B.name}">${on?'★ Your pick (tap for random)':'Pick this breed'}</button>`;};
  const tierTxt=kt?`<b>Your Kennel: tier ${['I','II','III','IV','V','VI'][kt-1]}</b> · ${esc(CAMP_UPG.kennel.txt(kt))}`:'You haven\'t built the Kennel yet. Build it in the camp upgrades and a random breed joins you every stage.';
  ov.innerHTML=`<div class="kb-box"><style>
    .kb-box{background:#1a1210;border:2px solid #6a4426;border-radius:12px;max-width:680px;width:100%;max-height:92vh;overflow:auto;padding:14px;color:#f2e6d0;box-shadow:0 0 40px rgba(255,140,60,.2);-webkit-overflow-scrolling:touch}
    .kb-h{font-size:20px;font-weight:800;margin:0 0 4px}.kb-sub{font-size:13px;color:#d8c4a0;margin:0 0 10px;line-height:1.35}
    .kb-sec{font-weight:800;color:#ffb45a;margin:12px 0 6px;font-size:14px}
    .kb-card{display:flex;gap:10px;align-items:center;background:#241914;border:1px solid #4a3020;border-radius:9px;padding:8px;margin:0 0 8px}.kb-card.big{border-color:#a0662a;background:#2c1c12}
    .kb-card canvas{width:124px;height:68px;image-rendering:pixelated;flex:none;background:#2a3040;border-radius:6px}
    .kb-tx{min-width:0}.kb-nm{font-weight:800;font-size:15px}.kb-lg{font-size:10px;background:#a0662a;color:#fff;border-radius:4px;padding:1px 5px;margin-left:4px;vertical-align:middle}
    .kb-ab{font-size:12.5px;color:#e0d0b4;margin:3px 0;line-height:1.3}.kb-st{font-size:12px;color:#ffe0a0;line-height:1.4}
    .kb-mood{margin-top:4px;display:flex;flex-wrap:wrap;gap:4px}.kb-tr{font-size:11px;border-radius:10px;padding:1px 7px;background:#3a2c24;color:#e8d8c0}.kb-tr.up{background:#4a2a1a;color:#ffb08a}.kb-tr.dn{background:#1e3040;color:#9ad0ff}
    .kb-pk{margin-top:6px;background:#3a2418;color:#ffd9a0;border:1px solid #6a4426;border-radius:8px;font-size:12px;padding:3px 10px;cursor:pointer}.kb-pk.on{background:#a0662a;color:#fff;border-color:#ffb45a}.kb-pk.off{display:inline-block;opacity:.6;cursor:default}
    .kb-x{float:right;background:#3a2418;color:#fff;border:1px solid #6a4426;border-radius:8px;font-size:16px;padding:2px 10px;cursor:pointer}
    @media(max-width:480px){.kb-card canvas{width:93px;height:51px}}
  </style><button class="kb-x" data-kbx>✕</button><p class="kb-h">🐕 The Kennel · Breed Book</p><p class="kb-sub">${tierTxt}</p>
  <p class="kb-sub">Every dog's stats come from your Kennel tier. Each breed then changes them and has its own temperament (sliders), which changes how it behaves in a fight. New dogs are a random breed, or <b>pick a favorite</b> and the Kennel always sends that one (large breeds still only show up at their 30%/50% chance).</p>
  <div class="kb-sec">Regular breeds</div>${DOG_BREEDS.map(B=>card(B,0)).join('')}
  <div class="kb-sec">Large breeds (Kennel V: 30% of new dogs · Kennel VI: 50%)</div>${DOG_LARGE.map(B=>card(B,1)).join('')}</div>`;
  document.body.appendChild(ov);ov.onclick=e=>{if(e.target===ov||e.target.closest('[data-kbx]'))ov.remove();};
  ov.querySelectorAll('[data-kpick]').forEach(b=>b.onclick=()=>{const [c,n]=b.dataset.kpick.split('|');run.dogPick=run.dogPick||{};run.dogPick[c]=run.dogPick[c]===n?null:n;try{persist();}catch(e){}showKennelBook(run);});
  ov.querySelectorAll('[data-dogskin]').forEach(cv=>{const A=(UNITS[cv.dataset.dogskin]||{}).idle;if(!A)return;const draw=()=>{const x=cv.getContext('2d');x.imageSmoothingEnabled=false;x.clearRect(0,0,124,68);x.drawImage(XIMG.dog,A.x,A.y,A.fw,A.fh,0,0,124,68);};if(XIMG.dog.complete)draw();else XIMG.dog.addEventListener('load',draw,{once:true});});}
function campScene(host,run){const W=171,H=96;const c=document.createElement('canvas');c.className='cc-fire';c.width=W*RES;c.height=H*RES;host.appendChild(c);
  const x=c.getContext('2d');let g;try{const r2=newRun(run.team.slice(),null);r2.stage=run.stage;r2.prestige=run.prestige||0;g=new Game({run:r2,slot:null,demo:true,W});}catch(e){c.remove();return;}
  g.enemies=[];g.obst=[];g.mines=[];g.bomblets=[];g.crates=[];g.loot=[];g.proj=[];g.fx=[];g.texts=[];
  const fx=90,fgy=CFG.H-H+80;g.camp={x:fx,gy:fgy,t:1,life:99,state:'burn',A:{}};g.bgImg=CAMPBG;   // the painting's fire pit
  const spots=[[fx-30,fgy+7,1],[fx+30,fgy+7,-1],[fx-14,fgy-6,1]];
  g.heroes.forEach((h,i)=>{const s=spots[i]||spots[0];h.x=s[0];h.gy=s[1];h.face=s[2];h.alive=true;h.moving=false;h.hp=h.max;h.en=h.enMax||100;h.wanderX=0;h.dodgeX=0;h.plan=null;});
  {const kt=upgT(run,'kennel');if(kt){try{g.pets=[];const n=kt>=4?2:1;const ds=[[fx+16,fgy+10,-1],[fx-46,fgy+10,1]];for(let i=0;i<n;i++){const d=g.spawnDog(kt,i,1);if(d){d.x=ds[i][0];d.gy=ds[i][1];d.face=ds[i][2];d.moving=false;d.plan=null;d.alive=true;}}}catch(e){}}}   /* 0.12.308 (Kyle): the doggos hang out at the campfire once the Kennel is built */
  const KX=150,KY=fgy-(CFG.H-H)+7;c.style.cursor='default';
  const inK=e=>{const r=c.getBoundingClientRect(),px=(e.clientX-r.left)/r.width*W,py=(e.clientY-r.top)/r.height*H;return px>KX-15&&px<KX+15&&py>KY-22&&py<KY+4;};
  c.addEventListener('mousemove',e=>{c.style.cursor=inK(e)?'pointer':'default';});c.addEventListener('click',e=>{if(inK(e))showKennelBook(run);});
  const stars=[...Array(34)].map(()=>[60+Math.random()*60,30+Math.random()*50,Math.random()]);   // embers drifting up from the fire
  let last=performance.now();
  const frame=now=>{if(!c.isConnected)return;requestAnimationFrame(frame);const dt=Math.min(.05,(now-last)/1000);if(dt<1/31)return;last=now;
    g.t+=dt;g.camp.t+=dt;for(const h of g.heroes){h.walkT=(h.walkT||0);h.animT=0;h.hitFlash=0;}
    if(!(IMG.complete&&CAMPBG.complete))return;PLATE_OFF=true;try{drawGame(x,g,W,CFG.H-H);}catch(e){PLATE_OFF=false;return;}PLATE_OFF=false;
    const RR=c.width/W;x.setTransform(RR,0,0,RR,0,0);
    {const RR0=c.width/W;x.setTransform(RR0,0,0,RR0,0,0);drawDoghouse(x,KX,KY,g.t,!!upgT(run,'kennel'));}   /* 0.12.446 (Kyle): the kennel beside the fire, under the night shade */
    x.globalCompositeOperation='source-over';x.fillStyle='rgba(4,2,14,.18)';x.fillRect(0,0,W,H);   // the painting is already night: only a light shade
    for(const s of stars){const life=(g.t*.35+s[2])%1;const ex=fx+(s[0]-90)*.35*life+Math.sin(g.t*3+s[2]*20)*2,ey=(fgy-(CFG.H-H))-6-life*55;x.globalAlpha=(1-life)*(.5+.5*Math.sin(g.t*14+s[2]*30));x.fillStyle=life<.3?'#fff2b0':'#ff9a40';x.fillRect(ex,ey,.8,.8);}x.globalAlpha=1;   // sparkling embers
    const fy=fgy-(CFG.H-H)-6,fl=1+.07*Math.sin(g.t*11)+.05*Math.sin(g.t*17.3);
    x.globalCompositeOperation='lighter';
    let gr=x.createRadialGradient(fx,fy,1,fx,fy,78*fl);gr.addColorStop(0,'rgba(255,160,60,.6)');gr.addColorStop(.35,'rgba(255,110,30,.22)');gr.addColorStop(1,'rgba(255,80,20,0)');x.fillStyle=gr;x.fillRect(0,0,W,H);
    gr=x.createRadialGradient(fx,fy+2,0,fx,fy+2,14*fl);gr.addColorStop(0,'rgba(255,230,150,.7)');gr.addColorStop(1,'rgba(255,140,40,0)');x.fillStyle=gr;x.fillRect(fx-20,fy-20,40,40);
    x.globalCompositeOperation='source-over';
    gr=x.createLinearGradient(0,0,W,0);gr.addColorStop(0,'rgba(4,2,10,.75)');gr.addColorStop(.25,'rgba(4,2,10,0)');gr.addColorStop(.75,'rgba(4,2,10,0)');gr.addColorStop(1,'rgba(4,2,10,.75)');x.fillStyle=gr;x.fillRect(0,0,W,H);   // vignette
  };requestAnimationFrame(frame);}
/* 0.12.335 talent tree v2 overlay. Tap a talent to see everything about it (per-rank numbers, your current rank lit up, why it's locked);
   tap it again or hit + to put a point in. Lines show how the tiers link: capstones pull from the two talents above them, and a red dashed line
   shows the far-side T4 talent a T3 capstone locks. On narrow screens the 3 branches become tabs. Spending, taking back and resetting is free. */
function treeHL(t){return esc(t).replace(/⟦([^⟧]*)⟧/g,'<b class="tq-on">$1</b>');}
/* 0.12.395 (Kyle) TALENTS v3: laid out like the old WoW talent calculator. Three trees side by side, each on its own painted backdrop,
   7 tiers x 4 columns of square talent buttons with a rank badge (0/5). Gold arrows show which talent unlocks which. */
function showTree(k){const s=SLOT(),L=s&&s.heroes[k];if(!L)return;L.tk=k;treeInit(L);const T=treeOf(k);if(!T)return;let ov=document.getElementById('cc-tree');if(ov)ov.remove();
  ov=document.createElement('div');ov.id='cc-tree';ov.style.cssText='position:fixed;inset:0;z-index:9000;background:radial-gradient(ellipse at 50% 20%,rgba(60,20,90,.55),rgba(4,2,8,.94));display:flex;align-items:center;justify-content:center;padding:6px';
  if(!document.getElementById('cc-tree-css3')){const st=document.createElement('style');st.id='cc-tree-css3';st.textContent=`
    #cc-tree .tq-on{color:#fff;background:#a6ff2e33;border-radius:3px;padding:0 2px;text-shadow:0 0 6px #a6ff2e}
    #cc-tree .tg{display:grid;grid-template-columns:repeat(4,1fr);grid-template-rows:repeat(7,auto);gap:12px 8px;position:relative;z-index:1;padding:6px 6px 4px}
    #cc-tree .tt{position:relative;width:46px;height:46px;justify-self:center;border-radius:7px;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:23px;
      background:linear-gradient(160deg,#2a2234,#0d0912);border:2px solid #4a3e58;box-shadow:inset 0 0 8px #000,0 2px 4px #000a;user-select:none;-webkit-tap-highlight-color:transparent;transition:transform .1s}
    #cc-tree .tt:active{transform:scale(.93)}
    #cc-tree .tt.off{filter:grayscale(1) brightness(.55)}
    #cc-tree .tt.can{border-color:#a6ff2e;box-shadow:inset 0 0 8px #000,0 0 8px #a6ff2e88}
    #cc-tree .tt.got{border-color:#ffd23f;background:linear-gradient(160deg,#4a3a12,#140e04)}
    #cc-tree .tt.full{border-color:#ffd23f;box-shadow:inset 0 0 10px #ffd23f55,0 0 10px #ffd23f99}
    #cc-tree .tt.maj{border-radius:50%}
    #cc-tree .tt.maj2{width:52px;height:52px;border-radius:50%;font-size:27px}
    #cc-tree .tt.maj2.full{animation:tqCap3 2.4s ease-in-out infinite}
    #cc-tree .tt.sel{outline:2px solid #fff;outline-offset:2px}
    @keyframes tqCap3{0%,100%{box-shadow:0 0 10px #ffd23f88}50%{box-shadow:0 0 24px #ffd23fdd}}
    #cc-tree .trk{position:absolute;right:-7px;bottom:-7px;font:700 10px/1 monospace;padding:2px 3px;border-radius:4px;background:#0a070d;border:1px solid #4a3e58;color:#9d8fb0}
    #cc-tree .tt.can .trk{color:#a6ff2e;border-color:#a6ff2e88}
    #cc-tree .tt.got .trk{color:#ffd23f;border-color:#ffd23f88}
    #cc-tree .ttab{flex:1;padding:6px;border-radius:8px;border:1px solid #3a2e48;background:#120a18;color:#e8dff5;font-weight:700;cursor:pointer}
    #cc-tree .ttab.on{border-color:#a6ff2e;color:#a6ff2e;box-shadow:0 0 10px #a6ff2e55}`;document.head.appendChild(st);}
  let sel=null,tab=0;
  const draw=()=>{const fr=talFree(L),tot=treePts(L);const nm=(CHAR[k]||{}).name||k;const narrow=window.innerWidth<620;const tr=L.tree||{};
    const tile=n=>{const rk=tr[n.id]||0,can=rk<n.max&&treeCan(k,L,n.id);const off=!rk&&!can;
      const cls=['tt',n.maj===2?'maj2':n.maj?'maj':'',rk?'got':'',rk>=n.max?'full':'',can&&fr?'can':'',off?'off':'',sel===n.id?'sel':''].filter(Boolean).join(' ');
      return `<div class="${cls}" data-n="${n.id}" title="${esc(n.name)}" style="grid-row:${n.row};grid-column:${'abcd'.indexOf(n.col)+1}">${n.icon}<span class="trk">${rk}/${n.max}</span></div>`;};
    const col=(B,bi)=>{const bp=treeBranchPts(k,L,bi);const nxt=TREE_REQ.find(q=>q>bp);
      return `<div class="tbr" data-bi="${bi}" style="flex:1;min-width:236px;max-width:300px;position:relative;border:2px solid #3a2e4a;border-radius:12px;overflow:hidden;box-shadow:0 0 18px #000c;
          background:linear-gradient(180deg,#0006,#000a 70%),url(crawl_talbg.png?v=__VER__) ${-(B.bg||0)*100}% 0/900% 100%;image-rendering:pixelated">
        <svg class="tlines" style="position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:0"></svg>
        <div style="position:relative;z-index:1;text-align:center;font-weight:800;color:#ffe9a8;letter-spacing:.5px;padding-top:6px;text-shadow:0 1px 3px #000">${B.icon} ${esc(B.name)}</div>
        <div style="position:relative;z-index:1;font-size:9.5px;text-align:center;color:#c9b8e0;text-shadow:0 1px 2px #000">${bp} point${bp===1?'':'s'} · ${nxt!=null?`next tier at ${nxt}`:'every tier open'}</div>
        <div class="tg">${B.nodes.map(tile).join('')}</div></div>`;};
    const N=sel&&treeNode(k,sel);let info='<div class="cc-sub" style="font-size:12px;text-align:center;padding:6px">Tap a talent to read it. Tap it again (or +) to put a point in. Every 3 points in a tree opens the next row.</div>';
    if(N){const rk=tr[N.id]||0,why=rk>=N.max?'':treeCanWhy(k,L,N.id),cr=treeCanRemove(k,L,N.id);const q=N.req&&treeNode(k,N.req);
      const kind=N.maj===2?'Ultimate talent':N.maj?'Major talent':'Talent';
      const now=rk?`<div style="font-size:12px;line-height:1.4"><b style="color:#ffd23f">Now:</b> ${treeHL(treeTxt(k,N,rk))}</div>`:'';
      const next=rk<N.max?`<div style="font-size:12px;line-height:1.4;margin-top:2px"><b style="color:#a6ff2e">${rk?'Next rank:':'Rank 1:'}</b> ${treeHL(treeTxt(k,N,rk+1))}</div>`:'';
      info=`<div style="display:flex;gap:10px;align-items:flex-start"><div style="font-size:30px;line-height:1">${N.icon}</div><div style="flex:1;min-width:0">
        <div style="font-weight:800;color:${N.maj?'#ffd23f':'#e8dff5'}">${esc(N.name)} <span style="font:700 11px monospace;color:#9d8fb0">Rank ${rk}/${N.max}</span> <span class="cc-sub" style="font-size:10.5px">${kind} · Tier ${N.row}</span></div>
        <div style="font-size:12.5px;line-height:1.4;margin-top:2px">${treeHL(treeTxt(k,N,rk))}</div>${N.max>1?`<div class="cc-sub" style="font-size:10.5px">Each rank adds the next number; your current rank is lit.</div>`:''}
        ${q?`<div style="font-size:11px;color:#c9b8e0;margin-top:3px">➜ Needs ${q.max}/${q.max} in ${esc(q.name)}</div>`:''}
        ${why?`<div style="font-size:11px;color:#ff9ab8;margin-top:3px">⚠ ${esc(why)}</div>`:''}</div>
        <div style="display:flex;flex-direction:column;gap:4px"><button class="cc-btn go" data-add ${rk<N.max&&!why?'':'disabled'} style="min-width:46px;font-size:16px">+</button><button class="cc-btn" data-rm ${cr?'':'disabled'} style="min-width:46px;font-size:16px">−</button></div></div>`;}
    ov.innerHTML=`<div style="background:linear-gradient(180deg,#1a0f24,#0f0915);border:2px solid #a6ff2e44;border-radius:16px;max-width:980px;width:100%;max-height:97vh;display:flex;flex-direction:column;color:#e8dff5;box-shadow:0 0 40px #6a2fa055">
      <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:10px 12px 6px"><b style="font-size:17px;text-shadow:0 0 10px #a6ff2e66">🌳 ${esc(nm)} · Talents</b><span class="cc-sub">LV ${L.lvl||1} · <b style="color:#a6ff2e">${fr}</b> of ${tot} points free · ${T.map((B,bi)=>treeBranchPts(k,L,bi)).join(' / ')}</span>
        <span style="flex:1"></span><button class="cc-btn" data-treset ${treeSpent(L)?'':'disabled'}>↺ Reset (free)</button><button class="cc-btn go" data-tclose>Done</button></div>
      ${narrow?`<div style="display:flex;gap:6px;padding:0 10px 6px">${T.map((B,bi)=>`<button class="ttab${bi===tab?' on':''}" data-tab="${bi}">${B.icon} ${esc(B.name)} ${treeBranchPts(k,L,bi)}</button>`).join('')}</div>`:''}
      <div style="overflow:auto;padding:0 10px 8px;flex:1"><div style="display:flex;gap:8px;justify-content:center;align-items:stretch">${T.map((B,bi)=>!narrow||bi===tab?col(B,bi):'').join('')}</div></div>
      <div style="border-top:1px solid #33264a;background:#0c0711;padding:8px 12px;border-radius:0 0 14px 14px;min-height:72px">${info}</div></div>`;
    ov.querySelectorAll('[data-n]').forEach(e=>{e.onclick=()=>{const id=e.dataset.n;if(sel===id){if(treeAdd(k,L,id)){sfx('level');persist();}}sel=id;draw();};e.oncontextmenu=ev=>{ev.preventDefault();sel=e.dataset.n;if(treeRemove(k,L,sel))persist();draw();};});
    ov.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{tab=+b.dataset.tab;draw();});
    const ad=ov.querySelector('[data-add]');if(ad)ad.onclick=()=>{if(treeAdd(k,L,sel)){sfx('level');persist();}draw();};
    const rm=ov.querySelector('[data-rm]');if(rm)rm.onclick=()=>{if(treeRemove(k,L,sel))persist();draw();};
    ov.querySelector('[data-treset]').onclick=()=>{treeReset(L);persist();draw();};
    ov.querySelector('[data-tclose]').onclick=()=>{ov.remove();window.removeEventListener('resize',onRs);showCamp();};
    requestAnimationFrame(lines);};
  /* prerequisite arrows, measured off the laid-out tiles */
  const lines=()=>{const tr=L.tree||{};ov.querySelectorAll('.tbr').forEach(br=>{const bi=+br.dataset.bi;const svg=br.querySelector('.tlines');const R0=br.getBoundingClientRect();
    const P=id=>{const e=br.querySelector(`[data-n="${id}"]`);if(!e)return null;const r=e.getBoundingClientRect();return {x:r.left-R0.left+r.width/2,y:r.top-R0.top+r.height/2,t:r.top-R0.top,b:r.bottom-R0.top,l:r.left-R0.left,r:r.right-R0.left};};
    let h='';for(const n of T[bi].nodes){if(!n.req)continue;const a=P(n.req),b=P(n.id);if(!a||!b)continue;const q=treeNode(k,n.req);const on=(tr[n.req]||0)>=q.max;const c=on?'#ffd23f':'#8a7a9c';
      let d;if(Math.abs(a.x-b.x)<4)d=`M${a.x},${a.b+2} L${b.x},${b.t-7}`;else d=`M${a.x},${a.b+2} L${a.x},${b.y} L${b.x>a.x?b.l-7:b.r+7},${b.y}`;
      const tip=Math.abs(a.x-b.x)<4?`${b.x-5},${b.t-8} ${b.x+5},${b.t-8} ${b.x},${b.t-2}`:(b.x>a.x?`${b.l-8},${b.y-5} ${b.l-8},${b.y+5} ${b.l-2},${b.y}`:`${b.r+8},${b.y-5} ${b.r+8},${b.y+5} ${b.r+2},${b.y}`);
      h+=`<path d="${d}" stroke="#000" stroke-width="6" fill="none" opacity=".6"/><path d="${d}" stroke="${c}" stroke-width="3" fill="none"/><polygon points="${tip}" fill="${c}"/>`;}
    svg.innerHTML=h;});};
  const onRs=()=>draw();window.addEventListener('resize',onRs);
  ov.onclick=e=>{if(e.target===ov){ov.remove();window.removeEventListener('resize',onRs);showCamp();}};ovHost().appendChild(ov);draw();}
/* 0.12.338 (Kyle) GEAR screen: 3 slots per hero (Weapon / Armor / Trinket), a stash, free swaps. Tap anything to see it in full
   (no hover needed). Spare parts raise an item a quality tier (Rusted -> plain -> Fine -> Masterwork); scrapping gives parts back. */
function gearIcon(it,sz){const D=gearDef(it);if(!D)return '';sz=sz||32;const k=sz/32;const R=GEAR_RAR[D.r];
  return `<span style="display:inline-block;width:${sz}px;height:${sz}px;background:url(crawl_gear.png?v=__VER__) ${-(D.id%16)*sz}px ${-Math.floor(D.id/16)*sz}px/${512*k}px auto;image-rendering:pixelated;filter:drop-shadow(0 0 3px ${R.c}aa)${it.q===0?' sepia(.7) saturate(.6)':''}"></span>`;}
function showGear(k0){const s=SLOT();if(!s)return;const run=s.run;const team=(run&&run.team)||[k0];let k=k0;let sel=null,filt='all';gearSlot(s);
  let ov=document.getElementById('cc-gear');if(ov)ov.remove();ov=document.createElement('div');ov.id='cc-gear';
  ov.style.cssText='position:fixed;inset:0;z-index:9000;background:radial-gradient(ellipse at 50% 20%,rgba(40,30,70,.6),rgba(4,2,8,.94));display:flex;align-items:center;justify-content:center;padding:8px';
  const close=()=>{ov.remove();showCamp();};let note='';if(!s.sellTiers)s.sellTiers=[0,1];
  const draw=()=>{const G=gearSlot(s),E=gearOn(s,k);const nm=k=>(CHAR[k]||{}).name||k;
    const slotBox=([sl,lab,ic])=>{const it=E[sl];const D=gearDef(it);const on=sel&&sel.where==='eq'&&sel.sl===sl;
      return `<div data-eqs="${sl}" style="flex:1;min-width:0;cursor:pointer;background:${D?'linear-gradient(160deg,'+GEAR_RAR[D.r].c+'22,#120a18)':'#0f0915'};border:2px solid ${D?GEAR_RAR[D.r].c:'#33284a'};${on?'outline:2px solid #fff;outline-offset:2px;':''}border-radius:12px;padding:8px;text-align:center">
        <div class="cc-sub" style="font-size:10px;margin:0">${ic} ${lab}</div><div style="height:44px;display:flex;align-items:center;justify-content:center">${D?gearIcon(it,40):'<span style="opacity:.3;font-size:26px">'+ic+'</span>'}</div>
        <div style="font-size:11px;font-weight:700;color:${D?GEAR_RAR[D.r].c:'#6d6080'};line-height:1.2">${D?esc(gearName(it)):'empty'}</div></div>`;};
    const list=G.stash.map((it,i)=>({it,i})).filter(({it})=>{const D=gearDef(it);return D&&(filt==='all'||D.s===filt);}).sort((a,b)=>{const A=gearDef(a.it),B=gearDef(b.it);return 'WATP'.indexOf(A.s)-'WATP'.indexOf(B.s)||B.r-A.r||b.it.q-a.it.q;});
    const cell=({it,i})=>{const D=gearDef(it);const on=sel&&sel.where==='stash'&&sel.i===i;return `<div data-st="${i}" title="" style="width:52px;height:52px;display:flex;align-items:center;justify-content:center;cursor:pointer;border-radius:9px;background:#140c1c;border:2px solid ${GEAR_RAR[D.r].c}${on?'':'88'};${on?'box-shadow:0 0 10px '+GEAR_RAR[D.r].c+';':''}position:relative">${gearIcon(it,36)}${it.q===3?'<span style="position:absolute;top:1px;right:3px;font-size:9px">★</span>':it.q===2?'<span style="position:absolute;top:1px;right:3px;font-size:9px;color:#9ad8ff">✦</span>':''}</div>`;};
    let info='<div class="cc-sub" style="font-size:12px;text-align:center;padding:6px">Tap an item to see what it does. Equipping and swapping is free.</div>';
    const it=sel?(sel.where==='eq'?E[sel.sl]:G.stash[sel.i]):null;const D=gearDef(it);
    if(D){const T=gearTxt(it);const R=GEAR_RAR[D.r];const up=it.q<3?GEAR_UPG[it.q]:null;const canUp=up&&(s.parts||0)>=up.p&&(s.gold||0)>=up.g;const slotLab=GEAR_SLOTS.find(x=>x[0]===D.s)||GEAR_SLOTS[3];const cur=E[D.s];
      info=`<div style="display:flex;gap:12px;align-items:flex-start;flex-wrap:wrap"><div>${gearIcon(it,48)}</div><div style="flex:1;min-width:200px">
        <div style="font-weight:800;color:${R.c};font-size:15px">${esc(gearName(it))}</div>
        <div class="cc-sub" style="font-size:11px;margin:0">${R.n} ${slotLab[1]}${it.q===0?' · <span style="color:#d0a070">Rusted: −25% stats and chance</span>':it.q===2?' · <span style="color:#9ad8ff">Fine: +15%</span>':it.q===3?' · <span style="color:#ffd23f">Masterwork: +30%</span>':''}</div>
        <div style="font-size:12.5px;margin-top:4px;color:#e8dff5">${T.stats.map(esc).join(' · ')}</div>
        ${T.procs.map(p=>`<div style="font-size:12.5px;margin-top:3px;color:#ffe9a8">✦ ${esc(p)}</div>`).join('')}
        ${sel.where==='stash'&&cur&&gearDef(cur)?`<div class="cc-sub" style="font-size:11px;margin-top:5px">Replaces ${esc(gearName(cur))} on ${esc(nm(k))}</div>`:''}</div>
        <div style="display:flex;flex-direction:column;gap:5px;min-width:140px">
          ${sel.where==='stash'?`<button class="cc-btn go" data-do="eq">Equip on ${esc(nm(k))}</button>`:`<button class="cc-btn" data-do="un" ${G.stash.length>=GEAR_STASH?'disabled':''}>Take off</button>`}
          <button class="cc-btn" data-do="up" ${canUp?'':'disabled'}>${up?`⬆ ${['Clean up','Make Fine','Make Masterwork'][it.q]} (${up.p} 🔩 + ${up.g} 🪙)`:'★ Masterwork'}</button>
          ${sel.where==='stash'?`<button class="cc-btn" data-do="sell">💰 Sell (+${gearPrice(it)} 🪙)</button>`:''}
          ${sel.where==='stash'?`<button class="cc-btn" data-do="scrap">♻ Scrap (+${1+Math.max(0,D.r-1)+Math.max(0,it.q-1)} 🔩)</button>`:''}</div></div>`;}
    ov.innerHTML=`<div style="background:linear-gradient(180deg,#1a1024,#0f0915);border:2px solid #4aa8ff55;border-radius:16px;max-width:900px;width:100%;max-height:96vh;overflow-y:auto;-webkit-overflow-scrolling:touch;overscroll-behavior:contain;color:#e8dff5;box-shadow:0 0 40px #2f5fa055">
      <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:10px 12px 6px"><b style="font-size:17px">⚔️ Gear</b><span class="cc-sub">🔩 ${s.parts||0} parts · 🪙 ${s.gold||0} gold · stash ${G.stash.length}/${GEAR_STASH}</span><span style="flex:1"></span><button class="cc-btn go" data-gclose>Done</button></div>
      <div style="display:flex;gap:6px;padding:0 12px 8px;flex-wrap:wrap">${team.map(t=>`<button class="cc-btn${t===k?' go':''}" data-hero="${t}">${(heroDef(t)||{}).icon||''} ${esc(nm(t))}</button>`).join('')}</div>
      <div style="padding:0 12px">
        <div style="display:flex;gap:8px;margin-bottom:10px;flex-wrap:wrap">${gearSlotsOf(k).map(slotBox).join('')}</div>
        <div style="display:flex;gap:6px;margin-bottom:6px;align-items:center"><b style="font-size:13px">🎒 Stash</b>${[['all','All'],['W','Weapons'],['A','Armor'],['T','Trinkets'],['P','Potions']].map(([f,l])=>`<button class="cc-btn${filt===f?' go':''}" data-f="${f}" style="padding:2px 9px;font-size:12px">${l}</button>`).join('')}</div>
        <div style="display:flex;gap:6px;margin-bottom:8px;align-items:center;flex-wrap:wrap"><button class="cc-btn" data-sellall style="padding:3px 10px;font-size:12px">💰 Sell all checked</button>${GEAR_RAR.map((R,ri)=>`<label style="font-size:11.5px;color:${R.c};display:inline-flex;align-items:center;gap:2px;cursor:pointer"><input type="checkbox" data-tier="${ri}" ${s.sellTiers.includes(ri)?'checked':''}>${R.n}</label>`).join('')}${note?`<span class="cc-sub" style="font-size:11.5px;color:#ffd23f">${note}</span>`:''}</div>
        <div style="display:flex;flex-wrap:wrap;gap:6px;padding-bottom:10px">${list.length?list.map(cell).join(''):'<div class="cc-sub" style="font-size:12px">Nothing yet. Plain gear can turn up from stage 3, the good stuff from around stage 8: rarely off kills, more often from searched crates and wrecks, best from loot boxes. Luck helps.</div>'}</div></div>
      <div style="border-top:1px solid #33264a;background:#0c0711;padding:10px 12px;border-radius:0 0 14px 14px;min-height:70px" data-info>${info}</div></div>`;
    ov.querySelectorAll('[data-hero]').forEach(b=>b.onclick=()=>{k=b.dataset.hero;sel=null;draw();});
    ov.querySelectorAll('[data-f]').forEach(b=>b.onclick=()=>{filt=b.dataset.f;draw();});
    ov.querySelectorAll('[data-eqs]').forEach(b=>b.onclick=()=>{sel=E[b.dataset.eqs]?{where:'eq',sl:b.dataset.eqs}:null;if(!sel)filt=b.dataset.eqs.replace(/\d$/,'');draw();});
    ov.querySelectorAll('[data-st]').forEach(b=>b.onclick=()=>{const i=+b.dataset.st;if(sel&&sel.where==='stash'&&sel.i===i){if(gearEquip(s,k,i)){sfx('level');persist();sel=null;}}else sel={where:'stash',i};draw();});
    const act=ov.querySelector('[data-do="eq"]');if(act)act.onclick=()=>{if(gearEquip(s,k,sel.i)){sfx('level');persist();}sel=null;draw();};
    const un=ov.querySelector('[data-do="un"]');if(un)un.onclick=()=>{if(gearUnequip(s,k,sel.sl))persist();sel=null;draw();};
    const upb=ov.querySelector('[data-do="up"]');if(upb)upb.onclick=()=>{const it2=sel.where==='eq'?E[sel.sl]:G.stash[sel.i];if(gearUpgrade(s,it2)==='ok'){sfx('level');persist();}draw();};
    const sl1=ov.querySelector('[data-do="sell"]');if(sl1)sl1.onclick=()=>{const v=gearSell(s,sel.i);sfx('heal');persist();note='Sold for '+v+' 🪙';sel=null;draw();};
    ov.querySelectorAll('[data-tier]').forEach(c=>c.onchange=()=>{const ri=+c.dataset.tier;s.sellTiers=s.sellTiers.filter(x=>x!==ri);if(c.checked)s.sellTiers.push(ri);persist();});
    {const sa=ov.querySelector('[data-sellall]');if(sa)sa.onclick=()=>{const R=gearSellTiers(s,s.sellTiers);if(R.n){sfx('heal');persist();}note=R.n?'Sold '+R.n+' item'+(R.n>1?'s':'')+' for '+R.gold+' 🪙':'Nothing to sell in those tiers';sel=null;draw();};}
    if(sel){const inf=ov.querySelector('[data-info]');if(inf&&inf.scrollIntoView)setTimeout(()=>inf.scrollIntoView({block:'nearest',behavior:'smooth'}),30);}   /* 0.12.414 (Kyle): tapping an item brings its buttons into view on phones */
    const sc=ov.querySelector('[data-do="scrap"]');if(sc)sc.onclick=()=>{gearScrap(s,sel.i);persist();sel=null;draw();};
    ov.querySelector('[data-gclose]').onclick=close;};
  ov.onclick=e=>{if(e.target===ov)close();};ovHost().appendChild(ov);draw();}
/* 0.12.338 (Kyle) TAP FOR INFO everywhere in the game: anything with an info tip shows it in a bubble when you tap it (no hover needed).
   Buttons keep doing their job on a tap; press and hold a button (0.45s) to read its tip instead. */
(function(){let tipEl=null,holdT=null,held=false;const kill=()=>{if(tipEl){tipEl.remove();tipEl=null;}};
  const show=(el)=>{const t=el.getAttribute('title')||el.dataset.tip;if(!t)return false;kill();tipEl=document.createElement('div');
    tipEl.style.cssText='position:fixed;z-index:10050;max-width:min(320px,86vw);background:#1b1226;border:1px solid #a6ff2e88;color:#efe6ff;border-radius:9px;padding:7px 10px;font:12.5px/1.35 system-ui,sans-serif;box-shadow:0 6px 20px #000a;pointer-events:none';
    tipEl.textContent=t;document.body.appendChild(tipEl);const r=el.getBoundingClientRect(),w=tipEl.offsetWidth,h=tipEl.offsetHeight;
    let x=Math.min(window.innerWidth-w-6,Math.max(6,r.left+r.width/2-w/2)),y=r.top-h-8;if(y<6)y=r.bottom+8;tipEl.style.left=x+'px';tipEl.style.top=y+'px';clearTimeout(show._t);show._t=setTimeout(kill,4500);return true;};
  const inGame=el=>el&&el.closest&&el.closest('#cc-root,#cc-tree,#cc-gear,.cc-card,.cc-ov,[id^="cc-"]');
  const isAct=el=>el.closest('button,a,input,select,[data-n],[data-st],[data-eqs],[data-hero],[data-f]');
  document.addEventListener('click',e=>{if(held){held=false;e.preventDefault();e.stopPropagation();return;}const el=e.target.closest&&e.target.closest('[title]');kill();
    if(!el||!inGame(el)||isAct(e.target))return;if(show(el)){}},true);
  document.addEventListener('pointerdown',e=>{const el=e.target.closest&&e.target.closest('[title]');if(!el||!inGame(el)||!isAct(e.target))return;clearTimeout(holdT);holdT=setTimeout(()=>{held=show(el);},450);},true);
  for(const ev of ['pointerup','pointercancel','pointerleave'])document.addEventListener(ev,()=>clearTimeout(holdT),true);
  document.addEventListener('scroll',kill,true);})();
/* 0.12.325 (Kyle) EVENTS: a multiple-choice window after every 3rd stage (major one every 10th). Choices that can't be afforded are
   greyed out with the reason. The result shows at the top of camp. */
function showEvent(){const s=SLOT(),run=s.run;const kind=run.eventPending;let E=run.eventId&&EVENTS.find(x=>x.id===run.eventId);
  if(!E){E=pickEvent(s,run,kind);run.eventId=E.id;persist();}
  const c=evCtx(s,run);const major=kind==='major';
  const P=showPanel(`<div class="cc-h" style="${major?'color:#ff9a3c':''}">${major?'★ MAJOR EVENT ★':'EVENT'}</div>
    <div class="cc-card" style="text-align:left;max-width:560px;margin:8px auto;border-color:${major?'#ff9a3c':'#4a6a8a'}">
      <div style="display:flex;gap:12px;align-items:center"><div style="font-size:42px;line-height:1">${E.icon}</div><div><b style="font-size:16px">${esc(E.title)}</b><p class="cc-sub" style="margin:4px 0 0">${esc(E.text(c))}</p></div></div>
      <div style="display:flex;flex-direction:column;gap:8px;margin-top:12px">${E.ch.map((C,i)=>{const no=C.need&&C.need(c);return `<button class="cc-btn" data-evc="${i}" ${no?'disabled':''} style="text-align:left;padding:8px 10px;${no?'opacity:.45':''}"><b>${esc(C.t)}</b><br><span style="font-size:12px;opacity:.85">${esc(C.d)}${no?` <i style="color:#ff8a8a">(${esc(no)})</i>`:''}</span></button>`;}).join('')}</div>
    </div><p class="cc-sub" style="font-size:11px">💰 ${fmt(s.gold||0)} gold · ⚙️ ${s.parts||0} parts · 🥫 ${run.food||0} food · 💧 ${run.water||0} water · 🎲 ${s.lucky||0} Lucky Dice</p>`);
  P.querySelectorAll('[data-evc]').forEach(b=>b.onclick=()=>{if(b.disabled)return;const C=E.ch[+b.dataset.evc];if(C.need&&C.need(evCtx(s,run)))return;
    let log='';try{log=C.fx(evCtx(s,run))||'';}catch(err){console.error(err);}
    run.eventLog=`${E.icon} <b>${esc(E.title)}</b>: ${esc(C.t)}${log?' → '+esc(log):''}`;run.lastEvent=E.id;delete run.eventPending;delete run.eventId;persist();showCamp();});}
function showCamp(){
  {const s0=SLOT(),r0=s0&&s0.run;if(r0&&r0.eventPending)return showEvent();}   /* 0.12.325 an event comes first */
  const s=SLOT();const run=s.run;migrate(s,CC.player);run.pending=0;run.bag=[];   /* 0.12.354: the old deck-card skills/items/backpack system is gone */const st=CFG.stage(run.stage,run.prestige);
  setRunModes(run);{const lg=campArrive(s,run);if(lg.length)run.campLog=lg;else if(run.campAt!==run.stage)run.campLog=[];}const hungry=new Set(run.needFeed||[]);
  const btn=(attrs,label,title)=>`<button class="cc-mini" ${attrs} ${title?`title="${esc(title)}"`:''}>${label}</button>`;
  const P=showPanel(`<div style="text-align:right;margin:-4px 0 2px"><button class="cc-mini" data-flip title="Turn the whole game sideways, for phones that won't rotate">🔄 ${root.classList.contains('rot-side')?'Normal view':'Flip sideways'}</button></div><div class="cc-h">STAGE ${run.stage}${run.prestige?' · ★'+run.prestige:''}${run.hardcore?' <span style="color:#ff5a5a;font-size:12px">☠ HARDCORE</span>':''}${run.dnd?' <span style="color:#c8a0ff;font-size:12px">🎲 D&amp;D</span>':''}${run.uncensored?' <span style="color:#ff8a5a;font-size:12px">🤬 UNFILTERED</span>':''}</div><div class="cc-h2">${esc(st.biome.name)}${st.boss?` — ${esc(CFG.bosses[st.boss].name)} awaits`:''}</div>
    <div class="cc-firehost"></div>${roleBar(run.team,false)}
    ${(()=>{try{if(localStorage.getItem('cc-camphelp')==='off')return '';}catch(e){}return `<div class="cc-help" data-camphelp>🏕️ <b>Camp tips</b> · Tap the pulsing <b>⛺ ⓘ</b> next to the title to see every camp upgrade, its tiers and prices. Tap ability and deck chips under 📜 <b>Skills</b> for details. Feed and water everyone before you leave, or they start the next stage weaker. Anything with a dotted underline or ⓘ shows more info when you tap it.
      <div style="margin-top:6px;display:flex;gap:8px"><button class="cc-btn" data-helpx="once" style="padding:2px 10px">Got it</button><button class="cc-btn" data-helpx="off" style="padding:2px 10px;opacity:.75">Don't show again</button></div></div>`;})()}
    <p class="cc-sub">Score ${fmt(run.score)} · save point.${run.ff?` <b style="color:#7dff9a">🌱 Fall Forward ${run.ff}/3: +${FF.dmg[run.ff]} basic attack damage, +${Math.round(FF.xp[run.ff]*100)}% XP, +${Math.round(FF.gold[run.ff]*100)}% gold piles, −${Math.round(FF.keep[run.ff]*100)}% score lost on a fall.</b>`:''}</p>
    <div class="cc-load">${run.team.map(k=>{const d=heroDef(k),hv=run.heroes[k],L=s.heroes[k];
      return `<div class="cc-card cc-lh"><span data-por="${k}"></span><div style="flex:1;min-width:0"><b>${d.icon} ${esc(d.name)}</b> <span class="cc-sub" style="font-size:11px">LV ${L.lvl} · Gear ${['W','A','T'].filter(x=>((s.gear&&s.gear.eq&&s.gear.eq[k])||{})[x]).length}/3 · ${hv.dead?'fallen (revives at 25%)':Math.round((hv.hpf==null?1:hv.hpf)*100)+'% HP'}</span>
        ${''}
        ${(()=>{const C=CHAR[k]||{};const ab=abOrder(C.abilities).map(A=>[A.passive?'✦':'⚔',A.name||A.id,abilDesc(k,L,A.id)||'']);const dk=L.insp?deckSkills(L.insp):[];   /* 0.12.56 (Kyle): Skills tab: his own abilities plus what his deck gives him; hover any for the details */
          const chip=([ic,n,d],col)=>`<span class="cc-chip" style="cursor:help;border-color:${col}" data-tiph="${esc('<div class="tt-h">'+esc(n.replace(/_/g,' '))+'</div>'+fmtAbil(d))}">${ic} ${esc(n.replace(/_/g,' '))}</span>`;
          return `<details class="cc-skills" style="margin-top:4px"><summary class="cc-sub" style="font-size:11px;margin:0;cursor:pointer">📜 Skills</summary><div class="cc-chips" style="margin-top:4px">${ab.map(x=>chip(x,'#7fd0ff')).join('')}${dk.map(x=>chip(x,'#c8a0ff')).join('')||(L.insp?'':'<span class="cc-sub" style="font-size:11px;margin:0">No deck inspiration</span>')}</div>${L.insp?`<div class="cc-sub" style="font-size:10px;margin:3px 0 0;opacity:.75">✨ ${esc(L.insp)}${inspText(L.insp)?': '+esc(inspText(L.insp)):''}</div>`:''}</details>`;})()}
        ${k==='robot'&&!run.heroes[k].dead?(()=>{const n=needsOf(run,k);const c=['#7ee081','#ffd060','#ff9040','#ff4a3a'][n.h];   /* 0.12.342 Warhound upkeep */
          const tip=n.h?`Next stage, the full penalties of tier ${n.h}: heals on him ${Math.round(HUNGER.heal[n.h]*100)}% weaker, ${Math.round(HUNGER.spd[n.h]*100)}% slower, -${HUNGER.acc[n.h]} accuracy, starts with ${Math.round(HUNGER.hp[n.h]*100)}% less HP, foggy targeting and a slow power drain. 1 spare part fixes one tier.`:'Tuned up and ready.';
          return `<div class="cc-sub" style="font-size:11px;margin:4px 0 0">🔧 <b style="color:${c};cursor:help" title="${esc(tip)}">${BOT_WEAR[n.h]}</b> ${n.h?btn(`data-botfix="1" ${(s.parts||0)>=1?'':'disabled'}`,'🔩 Maintain (1 part)','Spend 1 spare part: wear -1'):''}${n.h?'<span style="opacity:.75"> · it only gets worse if ignored</span>':''}</div>`;})():''}
        ${k!=='robot'&&!run.heroes[k].dead?(()=>{const n=needsOf(run,k);const fc=upgT(run,'smoker')?.5:1;   /* 0.12.72 Hunger & Thirst tiers */
          const hc=['#7ee081','#ffd060','#ff9040','#ff4a3a'][n.h],tc=['#7fd0ff','#ffd060','#ff9040','#ff4a3a'][n.t];
          const hT=n.h?`Next stage: heals on them ${Math.round(HUNGER.heal[n.h]*100)}% weaker, ${Math.round(HUNGER.spd[n.h]*100)}% slower moving and attacking, -${HUNGER.acc[n.h]} accuracy, and they start with ${Math.round(HUNGER.hp[n.h]*100)}% less HP.`:'Well fed.';
          const tT=n.t?`Next stage: foggy head (Perception -${THIRST.perc[n.t]}, plans and focus -${THIRST.think[n.t]}, decisions ${Math.round((THIRST.slow[n.t]-1)*100)}% slower) and a slow life drain (${(THIRST.drain[n.t]*100).toFixed(2)}% of max HP a second).`:'Well watered.';
          return `<div class="cc-sub" style="font-size:11px;margin:4px 0 0">🍖 <b style="color:${hc};cursor:help" title="${esc(hT)}">${HUNGER.names[n.h]}</b> ${n.h?btn(`data-feed="${k}|food" ${run.food>=fc?'':'disabled'}`,'🥫 Eat','Use '+(fc<1?'half a ration (smoked)':'1 food')+': Hunger -'+(upgT(run,'kitchen')?2:1)):''} · 💧 <b style="color:${tc};cursor:help" title="${esc(tT)}">${THIRST.names[n.t]}</b> ${n.t?btn(`data-feed="${k}|water" ${run.water>=1?'':'disabled'}`,'💧 Drink','Use 1 water: Thirst -'+(upgT(run,'purifier')?2:1)):''}${n.h||n.t?'<span style="opacity:.75"> · it only gets worse if ignored</span>':''}</div>`;})()
          :(k==='robot'?``:'')}
        ${(()=>{L.tk=k;treeInit(L);const fr=talFree(L);const T=treeOf(k);if(!T)return '';   /* 0.12.311 TALENT TREES: one button, the tree opens over the camp */
          const got=T.map((B,bi)=>{const p=treeBranchPts(k,L,bi);return p?`<span class="cc-chip" title="${esc(B.name)}">${B.icon} ${esc(B.name)} ${p}</span>`:'';}).join('');
          return `<div class="cc-sub" style="font-size:11px;margin:4px 0 0;display:flex;flex-wrap:wrap;gap:4px;align-items:center"><button class="cc-btn" data-tree="${k}" style="padding:4px 12px;font-size:13px;${fr?'border-color:#a6ff2e;color:#a6ff2e;animation:ccTentPulse 2.2s ease-in-out infinite':''}" title="Open this hero's talent tree. Spending, taking back and resetting points is free.">🌳 Talents${fr?` (${fr} to spend)`:''}</button><button class="cc-btn" data-gear="${k}" style="padding:4px 12px;font-size:13px" title="Weapon, Armor and Trinket. Swapping is free.">⚔️ Gear${(()=>{const E=(s.gear&&s.gear.eq&&s.gear.eq[k])||{};const n=['W','A','T'].filter(x=>E[x]).length;return n?' '+n+'/3':'';})()}</button>${got}</div>`;})()}
        ${(()=>{const H=run.heroes[k];const I=(H&&H.inj)||[];if(!I.length)return '';const md=run.med||{};   /* 0.12.296 injuries + treatment */
          return `<div class="cc-sub" style="font-size:11px;margin:4px 0 0;color:#ffb070">🩺 ${I.map(x=>{const D=INJURY[x.id];return `<b title="${esc(D.txt)}" style="cursor:help">${D.icon} ${D.name}</b> <span style="opacity:.75">(${x.st} stage${x.st>1?'s':''}${x.fresh?', fresh':''})</span>`;}).join(' · ')}${H.numb?' <span style="color:#9ae6ff">💊 numbed next stage</span>':''}
            ${[...new Set(I.map(x=>INJURY[x.id].fix))].filter(m=>m!=='parts').concat(k!=='robot'&&I.some(x=>x.id!=='concuss')&&!H.numb?['pills']:[]).filter((v,i,a)=>a.indexOf(v)===i).map(m=>btn(`data-treat="${k}|${m}" ${md[m]>0?'':'disabled'}`,`${MEDS[m].icon} ${MEDS[m].name} (${md[m]||0})`,MEDS[m].txt)).join(' ')}${I.filter(x=>INJURY[x.id].fix==='parts').map(x=>{const c=repairCost(run,x.id);return btn(`data-repair="${k}|${x.id}" ${(s.parts||0)<c?'disabled':''}`,`🔧 Fix ${INJURY[x.id].name} · ⚙️ ${c}`,'Repair it with spare parts'+(run.team.includes('eng')?' (half price: the Engineer is here)':''));}).join(' ')}</div>`;})()}
        ${(()=>{lkMigrate(L);const C=talChar(k,L)||{};const T=luckyTargets(C);const lu=L.ld||{};   /* 0.12.340 basic attack dice + Lucky Dice v2 (changed values in their tier color) */
          const d=w=>{const D=C[w].dice;const x=lu[w];const col=x?LK_TIER[x.t].c:null;const base=(CHAR[k][w]||{});return `${w==='melee'?'⚔️':'🏹'} <span ${x?`style="color:${col};font-weight:700" title="Changed by a Lucky Die (${LK_TIER[x.t].n}). Base ${base.dice?base.dice[0]+'d'+base.dice[1]+(base.flat?'+'+base.flat:''):'?'}"`:''}>${D[0]}d${D[1]}${C[w].flat?'+'+C[w].flat:''}</span>`;};
          const ll=L.luckyLast;const llT=ll&&ll.tier!=null?` <b style="color:${LK_TIER[ll.tier].c}">🎲 ${LK_TIER[ll.tier].n}${ll.tier===9?' — JACKPOT!':ll.tier===0?' — unlucky':''}: ${ll.kind==='stat'?`${ll.icon} ${ll.name} ${ll.from} → ${ll.to}`:`${ll.w==='melee'?'⚔️':'🏹'} ${ll.from} → ${ll.to}`}</b>`:'';
          const lsT=L.ls?Object.entries(L.ls).filter(([x,r])=>LK_STAT[x]).map(([x,r])=>{const S=LK_STAT[x],v=S.v[r.t],c=LK_TIER[r.t].c;return `<span class="cc-chip" style="border-color:${c};color:${c}" title="Lucky Die (${LK_TIER[r.t].n})">🎲 ${S.icon} ${S.f(v)}</span>`;}).join(''):'';
          const pick=CC.lkPick===k;const nL=s.lucky||0;
          const rollUI=nL>0?(pick?` <span style="display:inline-flex;gap:4px;margin-left:6px">${Object.entries(LK_CAT).map(([c,V])=>`<button class="cc-btn" data-lkc="${k}|${c}" style="padding:2px 8px;font-size:11px;border-color:#7dff9a;color:#7dff9a" title="${c==='off'?'Basic attack dice (size, count or flat), crit, attack speed or accuracy':c==='def'?'Armor, max HP, dodge or knockback resist':'Move speed, energy regen, Luck or cooldowns'}">${V.icon} ${V.name}</button>`).join('')}<button class="cc-btn" data-lkx="1" style="padding:2px 6px;font-size:11px">✕</button></span>`:` <button class="cc-btn" data-lucky="${k}" style="margin-left:6px;padding:2px 8px;font-size:11px;border-color:#7dff9a;color:#7dff9a" title="Spend 1 Lucky Die: pick Offense, Defense or Utility. It might go up. It might go down. Good luck.">${LUCKY_ICON} Roll Lucky Die (${nL})</button>`):'';
          if(!T.length&&!lsT&&!llT&&!rollUI)return '';
          return `<div class="cc-sub" style="font-size:11px;margin:4px 0 0">${T.length?'Basic attack: '+T.map(d).join(' · '):''}${lsT?` <span class="cc-chips" style="display:inline-flex;flex-wrap:wrap">${lsT}</span>`:''}${llT}${rollUI}</div>`;})()}
        ${hv.carry&&(hv.carry.courage||hv.carry.medkit||hv.carry.defib||(hv.carry.kit||[]).length)?`<div class="cc-sub" style="font-size:11px;margin:4px 0 0">🎒 Carrying into the stage: ${[hv.carry.courage?'Liquid Courage':'',hv.carry.medkit?'Medkit':'',hv.carry.defib?'Defibrillator':'',...(hv.carry.kit||[]).map(x=>x==='bat'?'Battery':'Medicine')].filter(Boolean).join(', ')}</div>`:''}</div></div>`;}).join('')}
      ${campPanel(s,run,btn)}
      </div>
    <div class="cc-row" style="margin-top:14px">${run.team.some(k=>missingOf(run,k)&&run.heroes[k]&&!run.heroes[k].dead)?`<button class="cc-btn" data-feedall style="padding:8px 20px;font-size:24px;border-color:#ffd27a;color:#ffd27a;animation:ccTentPulse 2.2s ease-in-out infinite" title="Feed and water everyone who needs it before you head out">🥫💧 FEED EVERYONE</button>`:''}${injuredOf(run).length?`<button class="cc-btn" data-rations style="padding:8px 20px;font-size:24px;border-color:#ff9ad0;color:#ff9ad0" title="Extra Rations: a real meal for everyone injured. Each one costs ${RATION_COST.food} food + ${RATION_COST.water} water and knocks every injury they have down a stage.">🍲 EXTRA RATIONS</button>`:''}<button class="cc-btn go" data-begin>BEGIN STAGE ${run.stage} ▶</button>
      <button class="cc-btn" data-quit>Save & exit</button></div><p class="cc-sub" id="cc-campmsg" style="margin-top:8px"></p>`);
  P.querySelectorAll('[data-por]').forEach(e=>e.replaceWith(portrait(e.dataset.por,56)));{const fh=P.querySelector('.cc-firehost');if(fh)campScene(fh,run);}P.querySelectorAll('[data-helpx]').forEach(x=>x.onclick=()=>{if(x.dataset.helpx==='off'){try{localStorage.setItem('cc-camphelp','off');}catch(e){}}const el=P.querySelector('[data-camphelp]');if(el)el.remove();});
  const msg=t=>{const m=P.querySelector('#cc-campmsg');if(m)m.textContent=t;};
  const bg=P.querySelector('[data-begin]');if(bg)bg.onclick=()=>{const left=run.team.filter(k=>missingOf(run,k)&&!run.heroes[k].dead);
    if(left.length&&!bg.dataset.sure){bg.dataset.sure=1;bg.textContent='Leave hungry/thirsty/worn? '+left.map(k=>{const n=needsOf(run,k);return heroDef(k).name+(k==='robot'?' '+BOT_WEAR[n.h]:(n.h?' '+HUNGER.names[n.h]:'')+(n.t?' '+THIRST.names[n.t]:''));}).join(', ')+' ▶';return;}campDepart(run);persist();beginStage();};
  P.querySelectorAll('[data-botfix]').forEach(x=>x.onclick=()=>{if(maintainBot(s,run)){sfx('level');persist();showCamp();}});
  P.querySelectorAll('[data-rations]').forEach(rb=>rb.onclick=()=>{const n=extraRations(run);if(n){sfx('heal');persist();showCamp();}else{rb.textContent='Not enough food/water';}});   /* 0.12.394 */
  P.querySelectorAll('[data-feedall]').forEach(fa=>fa.onclick=()=>{if(feedAll(run)){sfx('level');persist();showCamp();}else{fa.textContent='Not enough supplies';}});
  P.querySelectorAll('[data-feed]').forEach(b=>b.onclick=()=>{const [k,w]=b.dataset.feed.split('|');if(feedUnit(run,k,w)){sfx('level');persist();showCamp();}});
  P.querySelectorAll('[data-treat]').forEach(b=>b.onclick=()=>{const [k,m]=b.dataset.treat.split('|');const r=treatInjury(run,k,m);if(r==='ok'){sfx('level');persist();showCamp();}else msg({none:'You have no '+MEDS[m].name+'.',clean:'Nothing for that to fix.'}[r]||'Can\'t use that.');});   /* 0.12.296 */
  P.querySelectorAll('[data-repair]').forEach(b=>b.onclick=()=>{const [k,id]=b.dataset.repair.split('|');const r=repairInjury(s,run,k,id);if(r==='ok'){sfx('level');persist();showCamp();}else msg(r==='parts'?'Not enough spare parts.':'Nothing to fix.');});   /* 0.12.297 Warhound repairs */
  P.querySelectorAll('[data-medb]').forEach(b=>b.onclick=()=>{const m=b.dataset.medb,c=MEDS[m].parts;if((s.parts||0)<c)return msg('Not enough spare parts.');s.parts-=c;run.med=run.med||{};run.med[m]=(run.med[m]||0)+1;sfx('level');persist();showCamp();});
  P.querySelectorAll('[data-lucky]').forEach(b=>b.onclick=()=>{CC.lkPick=b.dataset.lucky;showCamp();});
  P.querySelectorAll('[data-lkx]').forEach(b=>b.onclick=()=>{CC.lkPick=null;showCamp();});
  P.querySelectorAll('[data-lkc]').forEach(b=>b.onclick=()=>{if(!((s.lucky||0)>0))return;const [k,c]=b.dataset.lkc.split('|'),H=s.heroes[k];if(!H)return;const r=luckyRoll(k,H,null,c);if(!r)return;s.lucky--;H.luckyLast=r;CC.lkPick=null;persist();sfx(r.tier>=2?'level':'die');showCamp();});   /* 0.12.340 Lucky Dice v2 */
  P.querySelectorAll('[data-talrr]').forEach(b=>b.onclick=()=>{if(!(run.rerolls>=1))return;const k=b.dataset.talrr,H=s.heroes[k];if(!H||!H.offer)return;const prev=H.offer.ids.slice();let nw=talRoll(k,H);for(let i=0;i<6&&nw.ids.every(x=>prev.includes(x));i++)nw=talRoll(k,H);H.offer=nw;run.rerolls--;sfx('level');persist();showCamp();});   /* 0.12.280 dice on stat picks */
  P.querySelectorAll('[data-tree]').forEach(b=>b.onclick=()=>showTree(b.dataset.tree));
  P.querySelectorAll('[data-gear]').forEach(b=>b.onclick=()=>showGear(b.dataset.gear));
  P.querySelectorAll('[data-tal]').forEach(b=>b.onclick=()=>{const [k,...r]=b.dataset.tal.split('|');const id=r.join('|');const H=s.heroes[k];if(talTake(k,H,id)){sfx('level');persist();showCamp();}});
  P.querySelectorAll('[data-upgp]').forEach(b=>b.onclick=()=>{const id=b.dataset.upgp,pp=upgParts(run,id);run.picked=run.picked||[];if(run.picked.includes(id)||(s.parts||0)<pp)return;s.parts-=pp;run.upg=run.upg||{};run.upg[id]=(run.upg[id]||0)+1;run.upgBought=1;run.picked.push(id);sfx('level');persist();showCamp();});
  {const rb=P.querySelector('[data-reroll]');if(rb)rb.onclick=()=>{if(!(run.rerolls>=1))return;const prev=run.offers||[];let nw=campOffers(run);for(let i=0;i<6&&nw.length&&nw.every(id=>prev.includes(id));i++)nw=campOffers(run);run.offers=nw;run.rerolls--;sfx('level');persist();showCamp();};}   /* 0.12.188 camp reroll */
  P.querySelectorAll('[data-upg]').forEach(b=>b.onclick=()=>{const id=b.dataset.upg,pr=upgPrice(run,id);run.picked=run.picked||[];if(run.picked.includes(id)||(s.gold||0)<pr)return;s.gold-=pr;run.upg=run.upg||{};run.upg[id]=(run.upg[id]||0)+1;run.upgBought=1;run.picked.push(id);sfx('level');persist();showCamp();});
  {const cb=P.querySelector('[data-con]');if(cb)cb.onclick=()=>{run.conOpen=!run.conOpen;persist();showCamp();};}
  P.querySelectorAll('[data-conb]').forEach(b=>b.onclick=()=>{const id=b.dataset.conb,pr=conPrice(run,id);if((s.gold||0)<pr)return;s.gold-=pr;run.upg=run.upg||{};run.upg[id]=(run.upg[id]||0)+1;sfx('level');persist();showCamp();});
  P.querySelectorAll('[data-conp]').forEach(b=>b.onclick=()=>{const id=b.dataset.conp,pp=conParts(run,id);if((s.parts||0)<pp)return;s.parts-=pp;run.upg=run.upg||{};run.upg[id]=(run.upg[id]||0)+1;sfx('level');persist();showCamp();});
  P.querySelectorAll('[data-scout]').forEach(b=>b.onclick=()=>{const id=b.dataset.scout;if(upgT(run,'tower')>=4){let a=[].concat(run.scoutPick||[]);a=a.includes(id)?a.filter(x=>x!==id):a.concat(id).slice(-2);run.scoutPick=a.length?a:null;}else run.scoutPick=id;persist();showCamp();});   /* 0.12.105 Map Table: two roads */
  P.querySelectorAll('[data-brew]').forEach(b=>b.onclick=()=>{const k=b.dataset.brew;const r=brewCourage(run,k);if(r==='ok'){sfx('level');persist();showCamp();const m=document.querySelector('#cc-campmsg');if(m)m.textContent='🫙 Poured '+heroDef(k).name+' a jar of Liquid Courage (−'+[2,1.5,1,1][upgT(run,'still')-1]+' food, −1 water).';}else msg({max:'No more brewing this camp.',food:'Not enough food.',water:'Not enough water.',has:heroDef(k).name+' already has a jar.'}[r]||'Can\'t brew that.');});
  P.querySelectorAll('[data-tri]').forEach(b=>b.onclick=()=>{const [w,k]=b.dataset.tri.split('|');const r=triageBuild(s,run,w,k);if(r==='ok'){sfx('level');persist();showCamp();}else msg({max:'No more builds at this camp.',parts:'Not enough spare parts.',has:heroDef(k).name+' already carries one of those.'}[r]||'Can\'t build that.');});

  P.querySelector('[data-quit]').onclick=showSlots;
}
/* 0.12.239 (Kyle): every stage you finish, won or lost, charges the reroll 50% (two results = a full reroll), up to 1 banked unless you already had more */
const DICE_MAX=3;   /* 0.12.280 (Kyle): bank up to 3 reroll dice; every stage you finish, won or lost, charges 25% of a die */
function rerollRefill(run){const r=run.rerolls||0;if(r<DICE_MAX)run.rerolls=Math.min(DICE_MAX,Math.round((r+.25)*4)/4);}
const LUCKY_ICON='<span style="display:inline-block;filter:hue-rotate(95deg) saturate(2.2) drop-shadow(0 0 3px #7dff9a)">🎲</span>';   /* 0.12.281 Lucky Die: a green glowing die */
function luckyStr(s){const n=s.lucky||0;return n?`${LUCKY_ICON.repeat(Math.min(n,5))} Lucky Di${n>1?'ce':'e'} (${n})`:'';}
function diceStr(run){const r=run.rerolls||0,n=Math.floor(r),p=Math.round((r%1)*100);return `${n?'🎲'.repeat(n):'<span style="opacity:.45">🎲</span>'} (${n})${p?` <span style="opacity:.75">+${p}% charged</span>`:''}`;}
function endRun(s,victory){const r=s.run;if(!r)return;const tot=r.score;
  if(r.prestige*100+r.stage>s.best.prestige*100+s.best.stage){s.best.stage=r.stage;s.best.prestige=r.prestige;}s.best.score=Math.max(s.best.score,tot);s.run=null;persist();}
// ---------------------------------------------------------------- playing
function ufTip(h){const C=CHAR[h.key]||{};const ab=abOrder(C.abilities||[]);   /* 0.12.81: phone unit-frame tip: abilities (actives first, passives last) */
  return `<div class="tt-h">${esc(h.def.name)} · LV ${h.lvl}</div>`+ab.map(A=>`<div class="tt-b"><b>${A.passive?'✦':'⚔'} ${esc((A.name||A.id).replace(/_/g,' '))}</b>${A.passive?' <span style="opacity:.6">(passive)</span>':''}${fmtAbil(abilDesc(h.key,(SLOT()&&SLOT().heroes[h.key])||null,A.id)||'')}</div>`).join('')+`<div class="tt-b" style="opacity:.7;margin-top:4px">Tap again to close.</div>`;}
/* 0.12.99 (Kyle): when a deck gives cooldown reduction, show THIS hero's ability cooldowns before -> after so players can choose */
function cdrTable(k,d){const I=INSP[d];const r=I&&I.mod&&I.mod.cdr;if(!r)return '';const C=CHAR[k]||{};const rows=[];
  for(const A of abOrder(C.abilities||[])){if(A.passive&&!A.icd)continue;const nm=(A.name||A.id).replace(/_/g,' ');
    if(A.book){for(const [bk,B] of Object.entries(A))if(B&&typeof B==='object'&&B.cd)rows.push([nm+' · '+bk,B.cd]);continue;}
    if(A.cd)rows.push([nm,A.cd]);else if(A.icd)rows.push([nm+' (internal)',A.icd]);}
  if(!rows.length)return '';const f=v=>(Math.round(v*10)/10)+'s';
  return `<div style="margin-top:6px;font-size:11px"><b>⏱ ${esc(heroDef(k).name)} with −${r}% cooldowns</b><table style="border-collapse:collapse;margin-top:3px">${rows.map(([n,v])=>`<tr><td style="padding:1px 10px 1px 0">${esc(n)}</td><td style="opacity:.6">${f(v)}</td><td style="padding:0 6px">→</td><td style="color:#a6ff2e"><b>${f(v*(1-Math.min(.5,r/100)))}</b></td></tr>`).join('')}</table></div>`;}
function beginStage(){
  const s=SLOT(),run=s.run;panel.hidden=true;CC.paused=false;
  /* 0.12.73 (Kyle) Retry: snapshot everything at the start of the stage (heroes, HP, items, herbs, kit, buffs, gold, parts, supplies, run state) */
  if(run.retries==null)run.retries=1;try{const r2=Object.assign({},run);delete r2.snap;run.snap=JSON.stringify({run:r2,gold:s.gold||0,parts:s.parts||0,heroes:s.heroes,best:s.best});}catch(e){run.snap=null;}
  if(run.inStage===run.stage)run.retryStage=run.stage;run.inStage=run.stage;   /* 0.12.394: starting the same stage again (a loss, a restart, a quit or a refresh) means it's not a first try */
  CC.game=new Game({run,slot:s});window.__CCG=CC.game;CC.lv0=Object.fromEntries(run.team.map(k=>[k,s.heroes[k].lvl]));
  hud.style.gridTemplateColumns=`repeat(${run.team.length},minmax(0,1fr))`;
  hud.innerHTML=(CC.game.run&&!CC.game.demo?`<div class="cc-hudroles">${Object.entries(teamRoles(CC.game.run.team)).map(([r,o])=>`<span class="cc-role" style="--rc:${ROLES[r].c}" title="${esc(ROLES[r].name)} x${o.n}: ${esc(ROLES[r].txt(o.t))}">${ROLES[r].icon}${o.n>1?'×'+o.n:''}</span>`).join('')}</div>`:'')+CC.game.heroes.map(h=>`<div class="cc-hc" data-h="${h.key}"><span data-por="${h.key}"></span><div style="flex:1;min-width:0"><div class="n">${esc(h.def.name)} <span style="color:#ffd23f">${h.lvl}</span></div><div class="bar"><i></i></div>
    </div></div>`).join('');
  hud.querySelectorAll('[data-por]').forEach(e=>e.replaceWith(portrait(e.dataset.por)));
  /* 0.12.81 (Kyle) phones: small WoW-style unit frames in the top-left of the sky instead of the panels under the stage; tap one to see its abilities */
  const uf=$('.cc-uf',root);uf.innerHTML=CC.game.heroes.map(h=>{const col=(typeof CALL_COLOR!=='undefined'&&CALL_COLOR[h.key])||'#9ad0ff';return `<div class="uf" data-h="${h.key}" data-tiph="${esc(ufTip(h))}"><div class="ufb"><div class="ufn" style="color:${col}">${esc(h.def.name)} <span class="lv">${h.lvl}</span><span class="ufs"></span></div><div class="ufh"><i style="background:linear-gradient(${col},${col}aa)"></i></div><div class="ufe"><i></i></div></div></div>`;}).join('');
  uf.querySelectorAll('[data-por]').forEach(e=>e.replaceWith(portrait(e.dataset.por)));
  const st=CC.game.st;flash(`STAGE ${run.stage}`,1400);if(st.boss)setTimeout(()=>{},0);
  root.querySelector('[data-a=restart]').hidden=false;layout();CC.last=performance.now();cancelAnimationFrame(CC.raf);CC.raf=requestAnimationFrame(loop);
}
/* 0.12.217 the radio's messages: a roast of the crew or something fun. Each one plays once per browser before they repeat */
const RADIO_LINES=["This is an emergency broadcast: Shane has left his house. Repeat: Shane has left his house. It is either work or cigarettes.", "Shane spotted riding his moped through a blizzard. Survivors report the moped is in better shape than Shane.", "Shane would like you to know Dexter is the greatest show ever made. Shane would also like you to know nothing about television.", "Breaking: Shane's lungs have filed for a restraining order against his cigarettes.", "Shane thinks he's the funniest man alive. The dead disagree. And they're the only audience he's got.", "Shane once told everyone he wished he got crippled so he could game forever. The zombies are happy to help.", "Reports confirm Shane has a new girlfriend from the same state as the last one. JP says the man has a type.", "Shane tried to whisper something nasty about a guy at the bar. The guy heard it. Shane learned a new kind of running.", "Tonight's weather: a thick brown cloud over Shane's house. Cause: unknown. Smell: known.", "Zombie experts confirm they will not eat Shane. Something about the secondhand smoke.", "Bartenders across the state have been advised: watch your drink if Shane walks in. Allegedly.", "Shane's moped has more horsepower than Shane, and it's never once been winded.", "Shane says he's out of shape on purpose. Strategic. Low profile. Hides from zombies by looking like a couch.", "If you see Shane out here, don't panic. He's slow, he wheezes, and he'll stop to smoke.", "Shane is a lot like Dexter: he thinks he's hiding something cool. He's hiding a carton of Marlboros.", "Shane Sucks. This has been a public service announcement.", "Shamp is building software that blocks cell phones in prisons. Somehow the zombies still got his number.", "Shamp says the apocalypse is fine actually, and the economy has never been better. JP has thrown his headset.", "JP and Shamp are arguing politics on Discord again. The zombies have muted the channel.", "Shamp's out here detecting contraband phones. Shamp, the call is coming from inside the raid.", "Shamp says he's only a jerk out of love. The love is very well hidden.", "Wolf is taking care of grandma. Grandma is the one with the shotgun.", "Wolf's seasonal job is back. Nobody knows what it is. Wolf doesn't either.", "Wolf, roasting your friends does not count as cardio. Neither does gaming. Keep doing both.", "Wolf says the zombies are ugly. Coming from Wolf, that's a compliment.", "Bryan has been promoted at his parents' restaurant. Day one of the co-owner dream. Day one of sweeping, too.", "Bryan has adopted Meo. Meo has adopted a tablet. Nobody has adopted a plan.", "Meo was told to hold the door. Meo is watching a video about doors.", "Meo's attention span has been located. It was last seen chasing a butterfly through wave three.", "Bryan's not lazy, he's conserving energy for when something interesting happens. Any day now.", "JP stole Kyle's best friend. Kyle would like Bryan back, with interest.", "Bryan and JP: best friends, raid buddies, and the two loudest people on Discord.", "This is an emergency broadcast. JP is high again. Repeat: JP is high again.", "Breaking news: local man JP smokes entire forest, calls it a break.", "JP, your Kar98 called. It wants a sober owner.", "Vibe Raiders, report for raid night. Bryan, please stop standing in the fire.", "Bryan's a bitch!", "Hear this if you're gay!", "Dice Boys rule!", "This frequency is sponsored by Dice Boys. Roll high, die hard.", "Eddie, you can stop targeting Kyle first now. He knows. He's always known.", "Eddie says it's not personal. Eddie attacks Kyle first every single game. It's personal.", "Kenzie is the only responsible adult left. Protect her at all costs.", "Todd has been shuffling since stage one. Somebody check on Todd.", "Todd brought a new deck to game night. It's the old deck with different sleeves.", "Cheez has never once read a card before playing it.", "Cheez is legally a snack, and that is all we will say.", "Kate's official ruling stands: Cheez is the group's token Asian. Cheez accepts, for tax reasons.", "Kate, welcome to game night. Rule one: Eddie attacks Kyle. Rule two: see rule one.", "Cheez's apartment is still standing. The fridge is still stocked. Coincidence? No.", "Good news, everybody: the zombies are slow. Bad news: so is Todd's shuffle.", "Kitchen crew check-in: Kyle's on the grill, David and Davey are on the line, JT is on dish. The zombies are on the menu.", "JT was supposed to make game night but he didn't feel well. The zombies understand. The zombies also don't feel well.", "Davey says it needs more salt. Davey always says it needs more salt.", "David, JP and Kyle agree the world's gone sideways. The zombies agree too, and they're not even a theory.", "Behind! Hot! Corner! Order up! Somebody tell JT the dish pit is a war zone now. It always was.", "Kyle built this whole game just to win one argument.", "Leon, if you're listening: you're the best one in the pod.", "Leif, if you're listening: you can't tag the radio. Stop tagging the radio.", "Shoshi, turn it off and on again. The apocalypse, I mean.", "Stay hydrated. Stay strapped. Dice Boys forever."];   /* 0.12.394 (Kyle): rebooted for both crews: the Discord/WoW guys (JP, Bryan, Meo, Wolf, Shamp, and Shane, who has it coming), the Dice Boys (Eddie, Kenzie, Todd, Cheez, new: Kate) and the kitchen (David, Davey, JT) */
function playRadio(R){if(!R||R.state!=='idle')return;R.state='playing';const g=CC.game;
  let seen=[];try{seen=JSON.parse(localStorage.getItem('podrundown-crawl-radio')||'[]');}catch(_){}const SW1=new RegExp(SWEAR.source,'i'),un=!!(SLOT()&&SLOT().run&&SLOT().run.uncensored),ALL=RADIO_LINES.filter(l=>un||!SW1.test(l));let pool=ALL.filter(l=>!seen.includes(l));if(!pool.length){seen=[];pool=ALL.slice();}   /* 0.12.398 Unfiltered off: no salty radio */
  const line=pool[Math.floor(Math.random()*pool.length)];seen.push(line);try{localStorage.setItem('podrundown-crawl-radio',JSON.stringify(seen));}catch(_){}
  const sub=root.querySelector('.cc-radiosub')||(()=>{const d=document.createElement('div');d.className='cc-radiosub';root.querySelector('.cc-cvw').appendChild(d);return d;})();
  const v0=BGM?BGM.volume:0;const duck=to=>{if(!BGM)return;const from=BGM.volume,t0=performance.now();const st=()=>{const k=Math.min(1,(performance.now()-t0)/500);BGM.volume=from+(to-from)*k;if(k<1)requestAnimationFrame(st);};st();};
  let noise=null;const startStatic=()=>{if(muted)return;try{AC=AC||new (window.AudioContext||window.webkitAudioContext)();const n=AC.sampleRate*1,b=AC.createBuffer(1,n,AC.sampleRate),c=b.getChannelData(0);for(let i=0;i<n;i++)c[i]=(Math.random()*2-1)*(Math.random()<.02?1:.35);
      const s=AC.createBufferSource(),f=AC.createBiquadFilter(),gn=AC.createGain();s.buffer=b;s.loop=true;f.type='bandpass';f.frequency.value=1800;f.Q.value=.8;gn.gain.value=.05;s.connect(f);f.connect(gn);gn.connect(AC.destination);s.start();noise={s,gn};}catch(_){}};
  const end=()=>{if(noise){try{noise.gn.gain.value=0;noise.s.stop();}catch(_){}}sub.style.opacity=0;setTimeout(()=>duck(musicVol),500);R.state='dying';R.dieT=1.2;sfx('hit');};
  sub.textContent='📻 "'+line+'"';sub.style.opacity=1;duck(Math.min(v0,musicVol*.2));startStatic();
  setTimeout(()=>{let done=false;const fin=()=>{if(done)return;done=true;setTimeout(end,250);};
    try{if(!muted&&window.speechSynthesis){const u=new SpeechSynthesisUtterance(line);u.rate=.95;u.pitch=.75;u.volume=1;u.onend=fin;u.onerror=fin;speechSynthesis.cancel();speechSynthesis.speak(u);setTimeout(fin,Math.max(3500,line.length*95));}else setTimeout(fin,Math.max(2800,line.length*70));}catch(_){setTimeout(fin,3000);}},500);}
function radioClick(e){const g=CC.game;if(!g||!g.radio||g.radio.state!=='idle')return;const r=cv.getBoundingClientRect();const rot=root&&root.classList.contains('rot-side');const wx=rot?e.offsetX/cv.clientWidth*g.W:(e.clientX-r.left)/r.width*g.W,wy=rot?e.offsetY/cv.clientHeight*CFG.H:(e.clientY-r.top)/r.height*CFG.H;
  const R=g.radio;if(Math.abs(wx-R.x)<10&&Math.abs(wy-(R.gy-4))<12){e.preventDefault();playRadio(R);}}
function flash(t,ms){banner.textContent=t;banner.style.opacity=1;clearTimeout(CC.bt);CC.bt=setTimeout(()=>banner.style.opacity=0,ms||1200);}
function loop(now){
  const g=CC.game;if(!g||root.hidden)return;let dt=Math.min(.05,(now-CC.last)/1000);CC.last=now;
  /* 0.12.324 freeze fix: an error anywhere in a frame used to stop the loop for good (the game "froze").
     Now the next frame is always queued first, and a step or draw that throws is skipped and logged instead. */
  CC.raf=requestAnimationFrame(loop);
  try{loopBody(g,dt,now);}catch(err){CC.errN=(CC.errN||0)+1;if(CC.errN<20)console.error('Crypt Crawl frame error (skipped):',err);}}
function loopBody(g,dt,now){
  if(!CC.paused){for(let i=0;i<CC.speed;i++){try{g.step(dt);}catch(err){CC.errN=(CC.errN||0)+1;if(CC.errN<20)console.error('Crypt Crawl step error (skipped):',err);break;}}}
  for(const e of g.events){if(e.type==='levelup'){sfx('level');flash('LEVEL UP!',900);}if(e.type==='boss'){sfx('boss');flash(e.name.toUpperCase(),1800);}
    if(e.type==='herolevel')sfx('level');if(e.type==='enrage')flash('ENRAGED!',1400);if(e.type==='itemdrop'){sfx('level');flash('ITEM FOUND!',900);}if(e.type==='luckydrop'){sfx('level');flash('🍀 LUCKY DIE!',1200);}if(e.type==='herodown')sfx('die');if(e.type==='teegshot')sfx('teegshot');if(e.type==='teegpp')sfx('teegpp');if(e.type==='jpns')sfx('jpns');if(e.type==='kidhowl')sfx('kidhowl');if(e.type==='leiftag')sfx('leiftag');if(e.type==='gutthrow')sfx('gutthrow');if(e.type==='gutsplat')sfx('gutsplat');if(e.type==='fusebeep')sfx('fusebeep',e);if(e.type==='bloatswell')sfx('bloatswell');if(e.type==='gutblow'){sfx('boom');sfx('gutsplat');}if(e.type==='gutpop'){const n=performance.now();if(n-(sfx.gpT||0)>70){sfx.gpT=n;sfx('gutpop');}}if(e.type==='howl')sfx('howl');if(e.type==='flare')sfx('flare');if(e.type==='teegsweep')sfx('teegsweep',e);if(e.type==='gun')sfx(e.rifle?(e.soft?'riflesoft':'rifle'):e.nail?'nail':e.big?'biggun':'gun');if(e.type==='boom')sfx('boom');if(e.type==='dash')sfx('dash');if(e.type==='bow')sfx('bow');if(e.type==='heal')sfx('heal');if(e.type==='camp')sfx('camp');if(e.type==='whoosh')sfx('whoosh');if(e.type==='slash')sfx('plasma');if(e.type==='thorns')sfx('thorns');if(e.type==='bell')sfx('bell',e);if(e.type==='alarm')sfx('alarm',e);if(e.type==='clunk')sfx('clunk');if(e.type==='glass')sfx('glass',e);if(e.type==='nemesis'){sfx('boss');flash(e.back?e.name.toUpperCase()+' RETURNS! (RANK '+'I'.repeat(e.rank)+')':(e.rank>1?e.name.toUpperCase()+' GROWS STRONGER':e.name.toUpperCase()+' RISES')+(e.trait?' · '+({rav:'RAVENOUS',blood:'BLOODTHIRSTY',bulwark:'BULWARK',howl:'HOWLER',cleave:'CLEAVER'}[e.trait]||''):''),1800);}if(e.type==='nemdown'){sfx('clear');flash(e.name.toUpperCase()+' IS DEAD',1600);}if(e.type==='lazer')sfx('lazer',e);if(e.type==='flame')sfx('flame');if(e.type==='shotgun')sfx('shotgun');if(e.type==='shriek')sfx('shriek');if(e.type==='wind')sfx('wind');if(e.type==='shout')sfx('shout');}
  g.events.length=0;
  ctx.imageSmoothingEnabled=false;drawGame(ctx,g,384,0);panCam();
  const run=g.run;info.innerHTML=`<span class="px" style="font-size:10px;color:#a6ff2e">STAGE ${run.stage}${run.prestige?' ★'+run.prestige:''}</span><span>${esc(g.st.biome.name)}</span><span>Score <b>${fmt(run.score+g.stageScore)}</b></span>${run.ff?`<span title="Fall Forward: +${Math.round(FF.xp[run.ff]*100)}% XP, +${Math.round(FF.gold[run.ff]*100)}% gold piles, −${Math.round(FF.keep[run.ff]*100)}% score lost on a fall" style="color:#7dff9a">🌱${run.ff}</span>`:''}<span>💰 <b>${fmt((SLOT().gold||0)+g.stageGold)}</b></span>
`;
  bossEl.textContent=g.boss&&!g.boss.dead?g.boss.B.name.toUpperCase():'';
  const doSt=(CC.ufT=(CC.ufT||0)+1)%8===0;
  for(const h of g.heroes){const f=root.querySelector(`.cc-uf [data-h="${h.key}"]`);if(!f)continue;f.classList.toggle('dead',!h.alive);
    if(doSt){const S=[];if(!h.alive)S.push(['DOWN','#ff4a4a']);else{if(h.bleedT>0)S.push(['🩸','#ff5a5a']);if(h.injOn&&h.injOn.length)S.push([h.injOn.map(x=>INJURY[x].icon).join(''),h.numb?'#9ae6ff':'#ffb070']);if(h.stun>0)S.push(['💫','#ffe07a']);if(h.slowT>0&&h.slow>0)S.push(['🐌','#9ad0ff']);if(h.shield>0)S.push(['🛡'+Math.round(h.shield),'#cfe8ff']);if(h.highT>0)S.push(['🌿','#8fe36a']);if(h.gritT>0||h.wallT>0)S.push(['🪨','#d8c8a8']);if(h.stealthT>0)S.push(['👻','#c8c8ff']);if(h.hunger>0)S.push(['🍖','#ffb070']);if((h.moods||[]).some(m=>m.name==='roasted'))S.push(['🔥','#ffa040']);if(h.buffT>0)S.push(['⬆','#a6ff2e']);if(h.courage)S.push(['🫙','#ffd27a']);if(h.sakeB)S.push(['🍶','#b8ff7a']);if(h.bnIn)S.push(['🎲','#8cff46']);if(h.upT>0)S.push(['✨','#fff']);}
      const s=f.querySelector('.ufs');const html=S.map(([t,c])=>`<span style="color:${c}">${t}</span>`).join(' ');if(s.dataset.v!==html){s.dataset.v=html;s.innerHTML=html;}}
    f.querySelector('.ufh i').style.width=Math.max(0,h.hp/h.max*100)+'%';f.querySelector('.ufe i').style.width=h.enMax?Math.max(0,Math.min(100,(h.en||0)/h.enMax*100))+'%':'0%';}
  for(const h of g.heroes){const el=hud.querySelector(`[data-h="${h.key}"]`);if(!el)continue;el.classList.toggle('dead',!h.alive);el.querySelector('.bar i').style.width=Math.max(0,h.hp/h.max*100)+'%';
    el.querySelector('.n span').textContent=SLOT().heroes[h.key].lvl;
    }
  if(g.over){cancelAnimationFrame(CC.raf);return finishStage(g);}
}
/* 0.12.38 (Kyle): a stats brief after each stage: who did what, plus a few awards */
function statsBrief(g){const S=g.stats||{};const keys=Object.keys(S).filter(k=>k!=='?');if(!keys.length)return '';const secs=Math.max(1,g.t||1);
  const nm=k=>k==='flannel_pal'?'Traveling_Companion':(heroDef(k)?heroDef(k).name:((CHAR[k]||{}).name||k));
  const best=(f,min)=>{let b=null,bv=min||0;for(const k of keys){const v=f(S[k]);if(v>bv){bv=v;b=k;}}return b?[b,bv]:null;};
  const aw=[['💥 Most damage',best(s=>s.dmg),v=>fmt(Math.round(v))],['💚 Top healer',best(s=>s.heal,1),v=>fmt(Math.round(v))+' healed'],['💀 Most kills',best(s=>s.kills),v=>v+' kills'],
    ['🎯 Biggest hit',best(s=>s.biggest),v=>Math.round(v)],['🧠 Headshots',best(s=>s.heads),v=>v],['🛟 Revives',best(s=>s.revives),v=>v],['🔍 Searches',best(s=>s.searches),v=>v],['🤏 Sticky fingers',best(s=>s.steals||0),v=>v+' stolen from allies'],['🧨 Defused',best(s=>s.defused||0),v=>v+' mines'],['💥 Wrong wire',best(s=>s.fumbled||0),v=>v+' mines set off'],['💢 Friendly fire',best(s=>s.ff||0),v=>v+' hits on allies'],['🩸 Took the most',best(s=>s.taken),v=>fmt(Math.round(v))+' dmg']]
    .filter(a=>a[1]).map(([t,[k,v],f])=>`<span class="cc-chip" style="margin:2px">${t}: <b>${esc(nm(k))}</b> (${f(v)})</span>`).join('');
  const rows=keys.sort((a,b)=>S[b].dmg-S[a].dmg).map(k=>{const s=S[k];return `<tr><td style="text-align:left">${esc(nm(k))}</td><td>${fmt(Math.round(s.dmg))}</td><td>${(s.dmg/secs).toFixed(1)}</td><td>${fmt(Math.round(s.heal))}</td><td>${s.kills}</td><td>${s.crits}</td><td>${s.heads}</td><td>${fmt(Math.round(s.taken))}</td><td>${s.downs}</td><td>${s.revives}</td><td>${s.searches}</td></tr>`;}).join('');
  return `<div class="cc-card" style="margin-top:8px"><b>📊 Stage stats</b> <span class="cc-sub" style="font-size:11px">${Math.round(secs)}s of fighting</span>
    <div style="margin:6px 0">${aw}</div>
    <div style="overflow-x:auto"><table class="cc-stats" style="border-collapse:collapse;font-size:11px;width:100%;text-align:right"><tr style="opacity:.7"><th style="text-align:left">Unit</th><th>Damage</th><th>DPS</th><th>Healed</th><th>Kills</th><th>Crits</th><th>Heads</th><th>Taken</th><th>Downed</th><th>Revives</th><th>Searches</th></tr>${rows}</table></div></div>`;}
function finishStage(g){
  const s=SLOT(),run=s.run;const first=!g._fin;g._fin=1;   /* 0.12.73: 'give up' after a retry offer comes back through here: don't count the stage twice */
  if(first){run.eventLog=null;g.saveBack();run.score+=Math.round(g.stageScore);s.gold=(s.gold||0)+g.stageGold;
  s.parts=(s.parts||0)+(g.stageParts||0);s.lucky=(s.lucky||0)+(g.stageLucky||0);run.med=run.med||{};for(const [m,n] of Object.entries(g.stageMed||{}))run.med[m]=(run.med[m]||0)+n;injTick(run);run.food=(run.food||0)+(g.stageFood||0);run.water=(run.water||0)+(g.stageWater||0);}   /* camp supplies */
  run.lastHaul={food:g.stageFood||0,water:g.stageWater||0,parts:g.stageParts||0};
  const found=[];
  const lvls=run.team.filter(k=>s.heroes[k].lvl>CC.lv0[k]).map(k=>`${esc(heroDef(k).name)} → LV ${s.heroes[k].lvl}`);
  if(g.over==='clear'){
    sfx('clear');
    for(const k of run.team){const h=run.heroes[k];if(h.dead){h.dead=false;h.hpf=.25;}else h.hpf=Math.min(1,(h.hpf||0)+.3);}
    run.needFeed=run.team.slice();   /* 0.12.58 everyone needs food AND water at camp; 0.12.351 the Warhound needs spare parts (handled in campArrive) */
    if(run.ff)run.campLog2=(run.campLog2?run.campLog2+' ':'')+'🌱 Fall Forward cleared: you got back up and beat it.';run.ff=0;   /* 0.12.237 a clear wipes the stacks */
    if(run.retryUsed){run.retryUsed=0;run.retries=1;run.campLog2='↻ Stage beaten on the retry: you get your retry back.';}   /* 0.12.73 */
    const cleared=run.stage;run.score+=Math.round(5*cleared*(1+run.prestige));   /* 0.12.94: clear bonus 5 x stage (was 250 x stage) */
    const firstTry=run.retryStage!==cleared?Math.round(.15*(g.stageScore||0)):0;run.score+=firstTry;run.retryStage=null;run.inStage=null;   /* 0.12.394 (Kyle): +15% of the stage's score for beating it on the first try */
    if(cleared>=CFG.maxStage){persist();CC.game=null;return showVictory(lvls);}
    if(cleared===CFG.strangerStage&&run.team.length<3&&!run.strangerDone){run.strangerDone=1;const free=s.forsook?[]:DATA.heroes.filter(h=>!run.team.includes(h.key));
      if(CFG.stage(cleared,run.prestige).boss)run.shopAt=cleared+1;run.stage++;persist();CC.game=null;return showStranger(free);}
    if(CFG.stage(cleared,run.prestige).boss)run.shopAt=cleared+1;
    {const nx2=run.evNext2;delete run.evNext;delete run.evNext2;if(nx2)run.evNext={why:['25% more zombies (the bunker alarm)'],...nx2};const ek=eventKind(cleared);if(ek)run.eventPending=ek;}   /* 0.12.325 events */
    run.stage++;rerollRefill(run);   /* 0.12.239 (Kyle): a win refills the reroll 50% */
    if(run.prestige*100+run.stage-1>s.best.prestige*100+s.best.stage){s.best.stage=run.stage-1;s.best.prestige=run.prestige;}
    persist();CC.game=null;
    const rb=run.campLog2;run.campLog2=null;const P=showPanel(`<div class="cc-h">STAGE ${cleared} CLEAR!</div>${rb?`<p class="cc-sub" style="color:#a6ff2e">${rb}</p>`:''}<p class="cc-sub">+${fmt(Math.round(g.stageScore)+Math.round(5*cleared*(1+run.prestige))+firstTry)} score${firstTry?` (⭐ first try +${fmt(firstTry)})`:''} · ${g.kills} kills · 💰 +${fmt(g.stageGold)} gold${g.stageParts?' · ⚙ +'+g.stageParts+' spare parts':''}${g.stageFood?' · 🥫 +'+g.stageFood+' food':''}${g.stageWater?' · 💧 +'+g.stageWater+' water':''}${found.length?'<br>Found: '+found.map(esc).join(', '):''}${lvls.length?'<br>'+lvls.join(', '):''}</p>${statsBrief(g)}<div class="cc-row"><button class="cc-btn go" data-c>TO CAMP ▶</button></div>`);
    P.querySelector('[data-c]').onclick=showCamp;return;}
  // defeat
  /* 0.12.85 (Kyle): nobody loses a run any more. A wipe keeps EVERYTHING (gold, parts, food, water, items and XP picked up on the way),
     the party limps back to camp at half health, and you can spend it all to grind out the stage you're stuck on. */
  if(true){sfx('die');
    for(const k of run.team){const h=run.heroes[k];if(h){h.dead=false;h.hpf=Math.max(.5,h.hpf||0);}}
    run.needFeed=run.team.slice();run.snap=null;run.retries=1;run.retryUsed=0;run.falls=(run.falls||0)+1;
    /* 0.12.237 (Kyle) Fall Forward: the fall costs 10% of your total score + 75% of what this attempt earned (already added in), less 10/20/30% for the stacks you carried in; then +1 stack (max 3) */
    const att=Math.round(g.stageScore||0),keep=FF.keep[Math.min(3,run.ff||0)],lost=Math.min(run.score,Math.round((.1*run.score+.75*att)*(1-keep)));   /* 0.12.330 (Kyle): 75% of this attempt (was 50%) */run.score-=lost;const ff0=run.ff||0;run.ff=Math.min(3,ff0+1);
    const ffLine=`<br><b style="color:#7dff9a">🌱 Fall Forward (Lessons Learned) ${'●'.repeat(run.ff)}${'○'.repeat(3-run.ff)}</b> (${run.ff}/3): until you clear a stage everyone gets <b>+${FF.dmg[run.ff]} damage on basic attacks</b>, <b>+${Math.round(FF.xp[run.ff]*100)}% XP</b>, <b>+${Math.round(FF.gold[run.ff]*100)}% gold piles</b>, and the next fall costs <b>${Math.round(FF.keep[run.ff]*100)}% less score</b>.<br>📉 Score lost: −${fmt(lost)} (10% of your total + half of this attempt's ${fmt(att)}${keep?`, cut ${Math.round(keep*100)}% by your stacks`:''}).`;
    rerollRefill(run);   /* 0.12.239 (Kyle): a loss refills the reroll 50% too */
    persist();CC.game=null;
    const P=showPanel(`<div class="cc-h" style="color:#ff9a3c">THE PARTY FELL BACK</div><div class="cc-h2">Stage ${run.stage}${run.prestige?' · ★'+run.prestige:''}</div>
      <p class="cc-sub">Everything you picked up comes with you: 💰 +${fmt(g.stageGold)} gold${g.stageParts?` · 🔩 +${g.stageParts} parts`:''}${g.stageLucky?` · ${LUCKY_ICON} +${g.stageLucky} Lucky Di${g.stageLucky>1?'ce':'e'}`:''}${Object.entries(g.stageMed||{}).filter(([m,n])=>n).map(([m,n])=>` · ${MEDS[m].icon} +${n} ${MEDS[m].name}`).join('')}${(g.stageFood||g.stageWater)?` · 🍖 +${g.stageFood||0} food · 💧 +${g.stageWater||0} water`:''}${found.length?'<br>Items: '+found.map(esc).join(', '):''}${ffLine}${lvls.length?'<br>Level ups: '+lvls.join(', '):''}</p>
      <p class="cc-sub">Everyone gets back up at half health. Rest at camp, spend what you found, and take another run at stage ${run.stage}.</p>
      <div class="cc-row" style="margin-top:12px"><button class="cc-btn go" data-c>⛺ BACK TO CAMP</button></div>`);
    P.querySelector('[data-c]').onclick=showCamp;return;}
  if((run.retries==null?1:run.retries)>0&&run.snap){sfx('die');CC.game=null;   /* 0.12.73: one retry per run (doesn't stack); beating the stage gives it back */
    const P=showPanel(`<div class="cc-h" style="color:#ff5a5a">YOUR PARTY HAS FALLEN</div><div class="cc-h2">Stage ${run.stage}${run.prestige?' · ★'+run.prestige:''}</div>
      <p class="cc-sub">You have <b style="color:#a6ff2e">1 retry</b> left this run. Retrying puts everything back exactly as it was when this stage started: every hero's HP, items, herbs and kit, your gold, parts and supplies (but any med supplies you found are kept, and you stop at camp first to patch up). Beat the stage this time and you get the retry back. Fall again and the run is over.</p>
      <div class="cc-row" style="margin-top:12px"><button class="cc-btn go" data-retry>↻ RETRY STAGE ${run.stage}</button><button class="cc-btn warn" data-giveup>Give up the run</button></div>`);
    P.querySelector('[data-retry]').onclick=()=>{const S=JSON.parse(run.snap);s.run=S.run;s.run.snap=run.snap;s.run.retries=0;s.run.retryUsed=1;s.gold=S.gold;s.parts=S.parts;s.heroes=S.heroes;if(S.best)s.best=S.best;s.run.med=s.run.med||{};for(const [m,n] of Object.entries(g.stageMed||{}))s.run.med[m]=(s.run.med[m]||0)+n;persist();showCamp();};   /* 0.12.298 (Kyle): a retry goes back through camp so you can med up, and keeps the med supplies found on the failed attempt */
    P.querySelector('[data-giveup]').onclick=e=>{if(!confirmInline(e.currentTarget,'Really end the run?'))return;run.retries=0;run.snap=null;finishStage(g);};
    return;}
  sfx('die');const reached=run.stage,score=run.score,team=run.team.slice();{const M=run.med||{};if(Object.values(M).some(n=>n>0)){s.medKeep={};for(const m in M)if(M[m]>0)s.medKeep[m]=M[m];}}endRun(s,0);   /* 0.12.298 med supplies carry into the next run */CC.game=null;
  const P=showPanel(`<div class="cc-h" style="color:#ff5a5a">YOUR PARTY HAS FALLEN</div><div class="cc-h2">Stage ${reached}${run.prestige?' · ★'+run.prestige:''}</div>
    <p class="cc-sub">Score ${fmt(score)} · best ${fmt(s.best.score)}. Spells and items are gone; hero levels stay.${s.medKeep?' Your med supplies ('+Object.entries(s.medKeep).map(([m,n])=>MEDS[m].icon+'×'+n).join(' ')+') come with you into the next run.':''}${lvls.length?'<br>Level ups this stage: '+lvls.join(', '):''}</p>
    <div class="cc-load">${team.map(k=>`<div class="cc-card cc-lh"><span data-por="${k}"></span><div><b>${esc(heroDef(k).name)}</b><div class="cc-sub" style="margin:0">LV ${s.heroes[k].lvl} · ${fmt(s.heroes[k].xp)}/${fmt(needHeroXp(s.heroes[k].lvl))} XP</div></div></div>`).join('')}</div>
    <div class="cc-row" style="margin-top:12px"><button class="cc-btn go" data-again>SAME TEAM AGAIN</button><button class="cc-btn" data-saves>Saves</button></div>`);
  P.querySelectorAll('[data-por]').forEach(e=>e.replaceWith(portrait(e.dataset.por,48)));
  P.querySelector('[data-again]').onclick=()=>{s.team=team.slice();restartSameTeam(s,team);};
  P.querySelector('[data-saves]').onclick=showSlots;
}
function showStranger(free){
  const s=SLOT(),run=s.run;const bless=(forsake)=>{if(forsake){s.forsook=1;}s.lucky=(s.lucky||0)+2;sfx('level');   /* 0.12.354: the old Blessed Upgrade pick is gone; leaving the stranger be gives 2 Lucky Dice */persist();showCamp();};
  const P=showPanel(`<div class="cc-h">A MYSTERY STRANGER</div><div class="cc-h2">Freed from the castle cells</div>
    ${free.length?`<p class="cc-sub">Someone was chained up in the dungeon. Choose who it turns out to be: they join this run now and this save can bring 3 heroes from then on. Or leave them be for 🎲 2 Lucky Dice, but then <b>this save stays a 2-hero party for good</b>; later runs that clear stage 6 get the 2 Lucky Dice again instead.</p>
    <div class="cc-heroes">${free.map(h=>`<button class="cc-hero" data-k="${h.key}"><span data-por="${h.key}"></span><div class="nm"><span class="ic">${h.icon}</span><span class="tx" style="${h.name.length>12?'font-size:.86em':''}">${esc(h.name)}</span></div><div class="cc-rchips">${roleChips(h.key)}${h.key==='robot'?'<span class="cc-role" style="--rc:#9aa4b0" title="A machine: healing, potions and healing magic do nothing for it. Its own repair bots and the Builders\' Tinker (Engineer, Eddie, Shoshi) fix it.">⚙ Machine</span>':''}</div><div class="dk">Inspired by deck: <b>${esc(h.deck)}</b></div><div class="lv">LV ${s.heroes[h.key].lvl}</div></button>`).join('')}</div>
    <div class="cc-row" style="margin-top:12px"><button class="cc-btn warn" data-bless="forsake">Leave them be: 🎲 2 Lucky Dice (2 heroes for good)</button></div>`
    :`<p class="cc-sub">${s.forsook?'You swore off the stranger in this save. The empty cell still holds a gift':'The cell holds only a lingering spirit, with no hero of yours to answer the call yet'}. It leaves you a gift instead: 🎲 2 Lucky Dice.</p>
    <div class="cc-row"><button class="cc-btn go" data-bless>🎲 TAKE THE LUCKY DICE</button></div>`}`);
  P.querySelectorAll('[data-por]').forEach(e=>e.replaceWith(portrait(e.dataset.por)));
  P.querySelector('[data-bless]').onclick=e=>{const b=e.currentTarget;if(b.dataset.bless==='forsake'&&!confirmInline(b,'2 heroes for good?'))return;bless(b.dataset.bless==='forsake');};
  P.querySelectorAll('[data-k]').forEach(b=>b.onclick=()=>{const k=b.dataset.k,d=heroDef(k);s.strangerSaved=1;s.partySize=3;run.strangerJoined=1;run.team.push(k);
    run.heroes[k]={hpf:1,dead:false,spells:[],items:[]};sfx('level');persist();showCamp();});
}
function showVictory(lvls){
  const s=SLOT(),run=s.run;const np=run.prestige+1;
  if(run.prestige*100+CFG.maxStage>s.best.prestige*100+s.best.stage){s.best.stage=CFG.maxStage;s.best.prestige=run.prestige;}s.best.score=Math.max(s.best.score,run.score);persist();
  const P=showPanel(`<div class="cc-h">THE CRYPT IS CONQUERED</div><div class="cc-h2">Stage ${CFG.maxStage} cleared${run.prestige?' at ★'+run.prestige:''}</div>
    <p class="cc-sub">Score ${fmt(run.score)}.${lvls.length?' '+lvls.join(', ')+'.':''} More stages are coming. Until then you can <b>Prestige</b>: descend again from stage 1 with your build, monsters much tougher, more score, and rarer loot${np>=2?' (Legendary now possible)':''}.</p>
    <div class="cc-row"><button class="cc-btn go" data-pr>PRESTIGE ★${np}</button><button class="cc-btn" data-ret>Retire this run</button></div>`);
  P.querySelector('[data-pr]').onclick=()=>{run.prestige=np;run.stage=1;prestigeUnlocks(run);run.rerolls=Math.min(DICE_MAX,(run.rerolls||0)+1);persist();showCamp();};
  P.querySelector('[data-ret]').onclick=()=>{endRun(s,1);showSlots();};
}
function quitToCamp(silent){const g=CC.game;if(!g)return;persist();CC.game=null;if(!silent)showCamp();}   // hero XP already banked; the run restarts this stage
// ---------------------------------------------------------------- header strip (attract mode)
function demoGame(W){const keys=DATA.heroes.map(h=>h.key).sort(()=>Math.random()-.5).slice(0,3);
  const run=newRun(keys,null);run.stage=1+Math.floor(Math.random()*8);run.prestige=0;
  const g=new Game({run,slot:null,demo:true,W});for(const h of g.heroes){h.base=heroBase(h.key,8,3);}g.recalc();for(const h of g.heroes)h.hp=h.max;return g;}
let strip,scv,sctx,sg,sraf=0,svis=true,slast=0;
function updateStripTop(){if(!strip)return;const rows=Object.keys(OWNERS).map(p=>({p,b:bestOf(p)})).filter(r=>r.b.stage).sort((a,b)=>(b.b.prestige*100+b.b.stage)-(a.b.prestige*100+a.b.stage)||b.b.score-a.b.score);
  $('.cs-top',strip).textContent=rows.length?`🏆 ${OWNERS[rows[0].p]} ${rows[0].p} · stage ${Math.min(rows[0].b.stage,CFG.maxStage)}${rows[0].b.prestige?' ★'+rows[0].b.prestige:''} · ${fmt(rows[0].b.score)}`:'🏆 No runs yet. Be first.';}
function stripLoop(now){if(!strip||!svis||(root&&!root.hidden)){sraf=0;return;}
  sraf=requestAnimationFrame(stripLoop);if(now-slast<33)return;const dt=Math.min(.05,(now-slast)/1000);slast=now;
  const H=106,W=Math.max(200,Math.round(H*strip.clientWidth/Math.max(1,strip.clientHeight)));
  if(scv.width!==W*RES||!sg||sg.W!==W){scv.width=W*RES;scv.height=H*RES;sg=demoGame(W);}
  sg.step(dt);if(sg.over||!sg.alive().length)sg=demoGame(W);sg.events.length=0;
  if(IMG.complete&&BGI.complete){sctx.imageSmoothingEnabled=false;drawGame(sctx,sg,W,CFG.H-H);}}
function startStrip(){if(strip&&!sraf&&svis)sraf=requestAnimationFrame(stripLoop);}
function stopStrip(){cancelAnimationFrame(sraf);sraf=0;}
function mountStrip(){
  const nav=document.querySelector('.pagetabs');if(!nav||document.getElementById('crawl-strip'))return;
  strip=document.createElement('div');strip.id='crawl-strip';strip.innerHTML=`<canvas aria-hidden="true"></canvas><button class="cs-play" type="button">▶ PLAY CRYPT CRAWL</button><span class="cs-top"></span>`;
  nav.parentNode.insertBefore(strip,nav);scv=strip.querySelector('canvas');sctx=scv.getContext('2d');
  if(!document.getElementById('cc-style')){const st=document.createElement('style');st.id='cc-style';st.textContent=CSS;document.head.appendChild(st);}
  strip.addEventListener('click',openCrawl);updateStripTop();
  try{new IntersectionObserver(es=>{svis=es[0].isIntersecting;if(svis)startStrip();else stopStrip();}).observe(strip);}catch(e){}
  document.addEventListener('visibilitychange',()=>{if(document.hidden)stopStrip();else startStrip();});
  if(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches){svis=false;const go=()=>{const H=106,W=Math.round(H*strip.clientWidth/strip.clientHeight);scv.width=W*RES;scv.height=H*RES;sg=demoGame(W);sctx.imageSmoothingEnabled=false;drawGame(sctx,sg,W,CFG.H-H);};IMG.complete&&BGI.complete?go():BGI.addEventListener('load',go,{once:true});}
  else startStrip();
}
window.CryptCrawl={open:openCrawl,_cc:CC,
  resetPin(who){const d=Save.load();if(d.players[who]){d.players[who].pin=null;Save.write(d);CC.data=d;return who+"'s PIN cleared on this device";}return 'no such player';}};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mountStrip);else mountStrip();