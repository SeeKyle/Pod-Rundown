from PIL import Image
import numpy as np
P='/home/claude/pod2/assets/heroes/flannel_pal/'
R=Image.open(P+'ranged.png').convert('RGBA').crop((0,0,230,208))
M=Image.open(P+'melee.png').convert('RGBA')
mf=[M.crop((i*230,0,i*230+230,208)) for i in range(4)]
CUT=147
def hipx(im):
    a=np.array(im)[CUT:CUT+6,:,3]>40;xs=np.where(a.any(0))[0];return (xs.min()+xs.max())/2
# upper body with the gun arm lowered
up=np.array(R).copy();up[CUT:]=0
arm=np.zeros_like(up)
SX=124   # left of the torso: the outstretched arm + pistol
arm[70:115,:SX]=up[70:115,:SX];up[70:115,:SX]=0
# also the forearm-ish band just in front of the shoulder
armI=Image.fromarray(arm)
PIV=(132,101)
armR=armI.rotate(62,resample=Image.NEAREST,center=PIV)   # swing it down (sprite faces left: counter-clockwise lowers it)
upI=Image.fromarray(up)
def frame(legsrc,bob,armswing):
    f=Image.new('RGBA',(230,208))
    lg=np.array(legsrc).copy();lg[:CUT]=0
    dx=int(round(hipx(R)-hipx(legsrc)))
    f.alpha_composite(Image.fromarray(lg),(dx,0))
    u=Image.new('RGBA',(230,208));u.alpha_composite(upI,(0,bob))
    u.alpha_composite(armI.rotate(62+armswing,resample=Image.NEAREST,center=PIV),(0,bob))
    f.alpha_composite(u)
    return f
seq=[(mf[2],0,-6),(mf[0],1,-2),(R,0,2),(mf[3],0,6),(mf[1],1,2),(R,0,-2)]
fr=[frame(*s) for s in seq]
sheet=Image.new('RGBA',(230*len(fr),208))
for i,f in enumerate(fr):sheet.alpha_composite(f,(230*i,0))
sheet.save('/home/claude/palwalk/walk.png')
bg=Image.new('RGBA',sheet.size,(40,40,50,255));bg.alpha_composite(sheet)
bg.crop((0,50,sheet.width,208)).resize((sheet.width*2//1,316),Image.NEAREST).save('/tmp/palwalk.png')
