# 0.12.75 (Kyle): the Engineer, built from a copy of Flannel_Man's sheets (same as JP was). Recolor + re-arm:
#  green flannel -> red work shirt, blue denim overalls (bib, straps, brass buttons), grey pants -> denim overall legs,
#  a yellow hard hat drawn over his head, crowbar -> a big steel wrench, rifle -> a short dark pump shotgun. Edges softened.
import numpy as np, colorsys, os, sys
from PIL import Image, ImageFilter
from scipy.ndimage import gaussian_filter
sys.path.insert(0,'/home/claude/eng')
SRC='/home/claude/pod2/assets/heroes/flannel/';OUT='/home/claude/pod2/assets/heroes/eng/';FW=230;os.makedirs(OUT,exist_ok=True)
def hsv(c):return colorsys.rgb_to_hsv(*(np.array(c[:3])/255.))
def rgb(h,s,v):return tuple(int(255*x) for x in colorsys.hsv_to_rgb(h%1,min(1,max(0,s)),min(1,max(0,v))))
def recolor(fr,anim):
    a=fr.copy();al=a[...,3]>40
    if not al.any():return a
    ys,xs=np.nonzero(al);top,bot=ys.min(),ys.max();H=bot-top+1
    g=np.zeros(al.shape,bool)
    for y,x in zip(ys,xs):
        h,s,v=hsv(a[y,x])
        if .22<h<.42 and s>.3 and v>.08 and int(a[y,x,1])>int(a[y,x,0])+8 and int(a[y,x,1])>int(a[y,x,2])+4:g[y,x]=1
    if g.any():gy,gx=np.nonzero(g);tx0,tx1=gx.min()-3,gx.max()+3;ty0,ty1=gy.min()-2,gy.max()+2
    else:tx0,tx1,ty0,ty1=xs.min(),xs.max(),top+H*.2,top+H*.55
    tw=max(1,tx1-tx0);bibY=ty0+(ty1-ty0)*.5
    m=(g|((a[...,3]>40)&(a[...,:3].max(2)<70)))
    lum=gaussian_filter(a[...,:3].astype(float).mean(2)*m,2.2)/np.maximum(.05,gaussian_filter(m.astype(float),2.2))
    out=a.copy()
    for y,x in zip(ys,xs):
        h,s,v=hsv(a[y,x]);rel=(y-top)/H;inT=tx0<=x<=tx1 and ty0<=y<=ty1
        if g[y,x] or (inT and s<.35 and v<.25 and .18<rel<.52):
            L=lum[y,x]/255.;tone=.55 if L<.13 else .72 if L<.22 else .86;edge=v<.06
            fx=(x-tx0)/tw;strap=abs(fx-.32)<.06 or abs(fx-.68)<.06
            if edge:out[y,x,:3]=(26,10,8)
            elif y>bibY and .2<fx<.8 or (strap and y>ty0+2):out[y,x,:3]=rgb(.6,.55,tone*.78)   # denim bib + straps
            else:out[y,x,:3]=rgb(.995,.74,tone)   # red work shirt
        elif rel<.28 and v<.2 and not inT:out[y,x,:3]=rgb(.07,.35,v*1.1+.08)   # dark hair/beard
        elif rel>.5 and s<.35 and .18<v<.5:out[y,x,:3]=rgb(.6,.5,v*.95+.08)   # overall legs
        elif not inT and rel<.62 and v<.3 and s<.45:
            if anim in('melee','walk','run','idle','hurt','kneel','death','toss','throw'):out[y,x,:3]=rgb(.6,.06,min(1,v*2.2+.4))   # steel wrench
            else:out[y,x,:3]=rgb(.6,.12,v*1.2+.1)   # dark shotgun steel
    # brass buttons at the top of the bib
    for fx in (.32,.68):
        bx=int(tx0+tw*fx);by=int(bibY)+1
        if 0<=by<out.shape[0] and 0<=bx<out.shape[1] and out[by,bx,3]>40:out[by,bx,:3]=(230,190,70)
    return out
def hardhat(o,src):
    al=o[...,3]>40
    if not al.any():return o
    ys,xs=np.nonzero(al);top,bot=ys.min(),ys.max();H=bot-top+1
    sk=[]   # his face: skin pixels in the top third (from the original colours)
    for y,x in zip(ys,xs):
        if (y-top)/H<.4:
            h,s_,v=hsv(src[y,x])
            if .02<h<.12 and .2<s_<.75 and v>.38:sk.append((y,x))
    if not sk:return o
    S=np.array(sk);fy,fx=np.median(S[:,0]),np.median(S[:,1])
    ht=int(fy)
    for y in range(int(fy),max(0,int(fy)-30),-1):   # walk up while the head is still wide (a rifle barrel on his back is only 2-3 px)
        if al[y,int(fx)-6:int(fx)+10].sum()>=5:ht=y
        else:break
    cx=int(fx)+3;cy=ht+4;yy,xx=np.mgrid[0:o.shape[0],0:o.shape[1]]
    dome=(((xx-cx)/9.5)**2+((yy-cy)/7)**2<=1)&(yy<=cy+1)
    brim=(yy>=cy+1)&(yy<=cy+2)&(xx>=cx-13)&(xx<=cx+10)
    Hm=dome|brim;o=o.copy()
    o[Hm]=(236,188,28,255);o[dome&(xx<cx-2)&(yy<cy-3)]=(255,226,110,255);o[brim]=(206,154,20,255)
    o[dome&(np.abs(xx-cx)<=1)&(yy<cy)]=(214,166,22,255)
    edge=Hm&~(np.pad(Hm,1)[2:,1:-1]&np.pad(Hm,1)[:-2,1:-1]&np.pad(Hm,1)[1:-1,2:]&np.pad(Hm,1)[1:-1,:-2]);o[edge]=(40,28,6,255)
    return o
def shorten(o,src):
    # sawn-off: cut a band out of the middle of the barrel and slide the front (and any muzzle flash) back toward his hands
    al=o[...,3]>40
    if not al.any():return o
    ys,xs=np.nonzero(al);top,bot=ys.min(),ys.max();H=bot-top+1
    red=(o[...,0].astype(int)>150)&(o[...,1].astype(int)<80)&(o[...,2].astype(int)<80)&al   # his red sleeve: the hand is just past its end
    if not red.any():return o
    hx=np.nonzero(red)[1].min()-5;mx=xs.min()
    if hx-mx<30:return o
    b0=int(mx+(hx-mx)*.22);L=int((hx-mx)*.55)
    rows=np.nonzero(al[:,:b0].any(1))[0]
    o=o.copy()
    for y in rows:
        seg=o[y,:b0].copy();o[y,:b0+L]=0;o[y,L:b0+L]=seg
    return o
from swordregions import SWORD   # same crowbar regions in the melee frames (copied from JP)
def wrench(out,hand,tip):
    L=np.linalg.norm(tip-hand);d=(tip-hand)/max(1,L);n=np.array([-d[1],d[0]])
    def put(p,c):
        y,x=int(round(p[0])),int(round(p[1]))
        if 0<=y<out.shape[0] and 0<=x<out.shape[1]:out[y,x]=c
    L=L*.62
    for k in np.linspace(0,L,int(L*3)):
        p=hand+d*k
        for w in (-3,-2,-1,0,1,2,3):put(p+n*w,(30,32,38,255) if abs(w)==3 else ((206,212,220,255) if w<0 else (128,136,148,255)))
    c=hand+d*(L+6)
    yy,xx=np.mgrid[0:out.shape[0],0:out.shape[1]];P=np.stack([yy-c[0],xx-c[1]],-1).astype(float)
    along=P@d;side=P@n;r=np.sqrt(along**2+side**2)
    head=(r<=9.5)&~((along>0)&(np.abs(side)<3.2))   # a fat head with the open jaw slot facing out
    ring=head&(r>8.2)|head&((along>-1)&(np.abs(side)>=3.2)&(np.abs(side)<4.4))
    out[head]=(170,178,190,255);out[head&(side<-2)]=(214,220,228,255);out[ring]=(30,32,38,255)
def soften(img):
    r,g,b,al=img.split();al2=al.filter(ImageFilter.GaussianBlur(.6));a=np.minimum(np.array(al),np.array(al2)*1.15).astype('uint8')
    return Image.merge('RGBA',(r,g,b,Image.fromarray(a)))
for f in os.listdir(SRC):
    if not f.endswith('.png') or f.startswith(('bomb','bullet','trip')):continue
    an=f[:-4];im=np.array(Image.open(SRC+f).convert('RGBA'));n=im.shape[1]//FW;fo=[]
    for i in range(n):
        fr=im[:,i*FW:(i+1)*FW].copy()
        if an=='melee' and i in SWORD:er,hand,tip=SWORD[i];yy,xx=np.mgrid[0:fr.shape[0],0:fr.shape[1]];fr[er(xx,yy)]=0
        o=recolor(fr,an);o=hardhat(o,fr)
        if an in('ranged','walkfire','reload'):o=shorten(o,fr)
        if an=='melee' and i in SWORD:wrench(o,np.array(hand,float),np.array(tip,float))
        fo.append(o)
    Image.fromarray(np.concatenate(fo,1)).pipe(soften) if False else soften(Image.fromarray(np.concatenate(fo,1))).save(OUT+f)
    print(an,n)
