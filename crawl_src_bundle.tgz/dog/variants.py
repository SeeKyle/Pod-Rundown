# 0.12.204 (Kyle) Guard dog breeds: the shepherd sheet recoloured into breed coats. Each pixel is matched to its colour group in the shepherd
# (tan coat, light points, dark saddle, brown shade) and re-tinted, keeping its own brightness. Blue heeler gets a mottled coat.
import json,numpy as np
from PIL import Image
SH=np.array(Image.open('/home/claude/pod2/crawl_dog.png').convert('RGBA')).astype(float)
meta=json.load(open('dog.json'))
C={'tan':(202,150,84),'light':(208,168,116),'dark':(45,37,37),'brown':(108,72,52)}
BREEDS={
 'shepherd':None,
 'heeler':{'tan':(104,122,146),'light':(196,132,78),'dark':(36,40,52),'brown':(76,88,108),'mottle':1},
 'lab':{'tan':(44,40,42),'light':(70,64,64),'dark':(24,21,23),'brown':(36,33,34)},
 'golden':{'tan':(214,160,78),'light':(236,198,132),'dark':(176,118,52),'brown':(150,100,48)},
 'husky':{'tan':(150,152,162),'light':(232,232,238),'dark':(64,66,78),'brown':(108,110,122)},
 'rott':{'tan':(40,30,30),'light':(168,98,44),'dark':(24,19,20),'brown':(118,68,34)},
}
lum=lambda c:.3*c[0]+.59*c[1]+.11*c[2]
def recolor(B):
    a=SH.copy();rgb=a[...,:3];m=a[...,3]>0
    keys=list(C);cent=np.array([C[k] for k in keys],float)
    d=((rgb[...,None,:]-cent[None,None])**2).sum(-1);cls=d.argmin(-1)
    L=lum(rgb.transpose(2,0,1));out=rgb.copy()
    H,W=cls.shape;yy,xx=np.mgrid[0:H,0:W]
    for i,k in enumerate(keys):
        sel=m&(cls==i)
        if k=='dark':sel&=(L>28)   # keep outlines/paws/nose as they are
        if not sel.any():continue
        f=(L[sel]/lum(C[k]))[:,None];col=np.array(B[k],float)[None]*f
        if B.get('mottle') and k in('tan','brown'):
            n=((xx[sel]*7+yy[sel]*13)%11)
            col=np.where((n<3)[:,None],col*0.8,np.where((n>8)[:,None],np.minimum(255,col*1.15+10),col))
        out[sel]=np.clip(col,0,255)
    a[...,:3]=out;return a
# 0.12.204 (Kyle: not just a reskin) breed shapes: floppy ears (Lab, Golden, Rottweiler), curled-up tail (Husky), docked stub (Rottweiler),
# thick otter tail (Lab), feathered tail (Golden). Done on the shepherd frames before the recolour, frame by frame.
TAN=(202,150,84,255);LIGHT=(208,168,116,255);SHADE=(108,72,52,255);DARK=(45,37,37,255)
def shape(sheet,B):
    a=sheet.copy().astype('uint8')
    for an,v in meta.items():
        if an=='death':continue
        sit=an=='idle'
        for f in range(v['n']):
            x0,y0=f*v['fw'],v['y'];fr=a[y0:y0+v['fh'],x0:x0+v['fw']]
            op=fr[...,3]>0
            if not op.any():continue
            # ---- ears
            if B.get('ears')=='flop':
                cols=np.where(op[:,:30].any(0))[0];ys=np.where(op[:,:30].any(1))[0];ym=ys.min()
                ear=np.zeros_like(op);ear[ym:ym+3,:30]=op[ym:ym+3,:30]
                xs=np.where(ear.any(0))[0]
                if len(xs):
                    fr[ear]=0;ex=int(xs.min())+ (1 if sit else 0)
                    for yy in range(ym+2,ym+7):
                        for xx in range(ex,ex+3):
                            if 0<=yy<fr.shape[0]:fr[yy,xx]=SHADE if xx>ex else DARK
            # ---- tail
            T=B.get('tail')
            if T:
                yy,xx=np.mgrid[0:fr.shape[0],0:fr.shape[1]]
                tm=op&((xx>=42)&(yy>=19)&(yy<=27) if sit else (xx>=44)&(yy<=23))
                if T=='feather':
                    for (y,x) in zip(*np.where(tm)):
                        if y+1<fr.shape[0] and fr[y+1,x,3]==0:fr[y+1,x]=LIGHT
                    continue
                if T=='stub':tm&=(xx>=(45 if sit else 46));fr[tm]=0;continue
                fr[tm]=0
                if sit:bx,by=42,24
                else:
                    ys=np.where(op[:,40:44].any(1))[0];bx,by=43,(int(ys.min())+1 if len(ys) else 16)
                if T=='curl':pts=[(0,0),(1,-1),(2,-3),(3,-5),(3,-7),(2,-8),(0,-8),(-1,-7)]
                else:pts=[(i,i//3) for i in range(9)]   # otter: thick, straight back and a little down
                for i,(dx,dy) in enumerate(pts):
                    for (ox,oy) in ((0,0),(0,1),(1,0)):
                        X,Y=bx+dx+ox,by+dy+oy
                        if 0<=X<fr.shape[1] and 0<=Y<fr.shape[0]:fr[Y,X]=LIGHT if (T=='curl' and i>=len(pts)-3) else (TAN if (ox or oy) else SHADE)
    return a.astype(float)
SHAPES={'heeler':{},'lab':{'ears':'flop','tail':'otter'},'golden':{'ears':'flop','tail':'feather'},'husky':{'tail':'curl'},'rott':{'ears':'flop','tail':'stub'}}
rows=[];units={}
FH=SH.shape[0]
for j,(name,B) in enumerate(BREEDS.items()):
    key='dog' if name=='shepherd' else 'dog_'+name
    if B is None:rows.append(SH)
    else:base=SH;SH=shape(base,SHAPES.get(name,{}));rows.append(recolor(B));SH=base
    units[key]={an:dict(v,y=v['y']+j*FH) for an,v in meta.items()}
big=np.concatenate(rows,0).astype('uint8');Image.fromarray(big).save('/home/claude/pod2/crawl_dog.png',optimize=True)
json.dump(units['dog'],open('dog.json','w'))
a=json.load(open('/home/claude/pod2/crawl_atlas.json'));a['units'].update(units);json.dump(a,open('/home/claude/pod2/crawl_atlas.json','w'))
pv=Image.new('RGBA',(248,FH*len(rows)),(60,50,46,255));pv.alpha_composite(Image.fromarray(big).crop((0,0,248,big.shape[0])));pv.resize((248*3,pv.height*3),0).save('/tmp/dogvars.png')
print(list(units))
