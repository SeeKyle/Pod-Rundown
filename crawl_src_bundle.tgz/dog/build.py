# Guard Dog sheet built from Kyle's two sprites (sitting + running): cleaned to a pixel grid, legs swung for a gallop, bite / hurt / death derived.
import json,numpy as np
from PIL import Image
def clean(f,W):
    im=Image.open('src/%s.png'%f).convert('RGBA');im=im.crop(im.getbbox())
    a=np.array(im).astype(float);al=a[...,3:]/255;a[...,:3]*=al
    H=round(im.height*W/im.width);sm=np.array(Image.fromarray(a.astype('uint8')).resize((W,H),Image.BOX)).astype(float);sa=sm[...,3:]/255
    sm[...,:3]=np.where(sa>0,sm[...,:3]/np.maximum(sa,1e-6),0)
    src=np.array(im).reshape(-1,4);src=src[src[:,3]>250][:,:3]
    q=Image.fromarray(src.reshape(-1,1,3).astype('uint8')).quantize(9,method=Image.MEDIANCUT);pal=np.array(q.getpalette()[:27]).reshape(9,3).astype(float)
    flat=sm[...,:3].reshape(-1,3);d=((flat[:,None,:]-pal[None])**2).sum(2);sm[...,:3]=pal[d.argmin(1)].reshape(H,W,3)
    sm[...,3]=np.where(sm[...,3]>=120,255,0);return Image.fromarray(sm.astype('uint8'))
RUN=clean('run',48);SIT=clean('sit',36)
RUN.save('src/run48.png');SIT.save('src/sit36.png')
print(RUN.size,SIT.size)
FW,FH=62,34;OX,OY=7,6   # run sprite offset inside a frame; paws reach y=OY+26
def split(im,mask_fn):
    a=np.array(im);m=np.zeros(a.shape[:2],bool)
    for y in range(a.shape[0]):
        for x in range(a.shape[1]):m[y,x]=mask_fn(x,y) and a[y,x,3]>0
    part=a.copy();part[~m]=0;rest=a.copy();rest[m]=0;return Image.fromarray(part),Image.fromarray(rest)
HIND,BODY=split(RUN,lambda x,y:4<=x<=17 and y>=15)
FRONT,BODY=split(BODY,lambda x,y:x>=30 and y>=17)
def pose(fa,ha,bob=0,dx=0,lean=0):
    fr=Image.new('RGBA',(FW,FH))
    def put(p,ang,piv):
        big=Image.new('RGBA',(FW,FH));big.alpha_composite(p,(OX+dx,OY+bob))
        if ang:big=big.rotate(ang,resample=Image.NEAREST,center=(OX+dx+piv[0],OY+bob+piv[1]))
        fr.alpha_composite(big)
    put(HIND,ha,(13,14));put(FRONT,fa,(33,16))
    b=Image.new('RGBA',(FW,FH));b.alpha_composite(BODY,(OX+dx,OY+bob))
    if lean:b=b.rotate(lean,resample=Image.NEAREST,center=(OX+dx+24,OY+bob+16))
    fr.alpha_composite(b);return fr
A={}
A['run']=None   # 0.12.204: filled in below with drawn gallop legs (the old rotated front leg split the chest apart)
# 0.12.58 (Kyle: walk looked stiff): a real trot. The body (legs cut off) bobs, and four legs are drawn per frame:
# diagonal pairs move together, each leg bends at the knee and lifts its paw as it swings forward. Far legs are a shade darker.
_yy=np.arange(RUN.height)[:,None,None];_xx=np.arange(RUN.width)[None,:,None]
WBODY=Image.fromarray(np.where(((_yy<=14)|((_yy<=15)&(_xx>=13)&(_xx<=36)))&(np.array(RUN)[...,3:]>0),np.array(RUN),0).astype('uint8'))
import math
def legline(d,x0,y0,x1,y1,col):
    n=int(max(abs(x1-x0),abs(y1-y0))*2)+1
    for i in range(n+1):
        t=i/n;x=round(x0+(x1-x0)*t);y=round(y0+(y1-y0)*t)
        for xx in (x,x+1):
            if 0<=xx<FW and 0<=y<FH:d[y,xx]=col
def trot(ph,nf):
    fr=Image.new('RGBA',(FW,FH));bob=round(.6+.6*math.cos(2*ph*2*math.pi/nf*1))
    d=np.array(fr)
    near=(202,150,84,255);far=(150,104,58,255);paw=(45,37,37,255)
    G=OY+26
    for (hx,hy,off,col) in [(OX+15,OY+15,0.5,far),(OX+33,OY+15,0.0,far),(OX+13,OY+16,0.0,near),(OX+35,OY+16,0.5,near)]:
        a=2*math.pi*((ph/nf)+off);sw=math.sin(a)*4.5;lift=max(0,math.cos(a))*2.6
        px=hx+sw;py=G-lift;kx=(hx+px)/2+(1.5 if hx<OX+24 else -1.0)*(.4+lift*.5);ky=(hy+bob+py)/2-.5
        legline(d,hx,hy+bob,kx,ky,col);legline(d,kx,ky,px,py-1,col)
        x=round(px);y=round(py)
        for xx in (x,x+1,x+2):
            if 0<=xx<FW and 0<=y<FH:d[y,xx]=paw
    fr=Image.fromarray(d)
    b=Image.new('RGBA',(FW,FH));b.alpha_composite(WBODY,(OX,OY+bob));fr.alpha_composite(b)
    return fr
A['walk']=[trot(i,6) for i in range(6)]
# 0.12.204 (Kyle: the run's front paw looked like the body split) a real gallop: legs drawn on the cut-off body like the trot,
# hind pair and front pair each move together (slightly staggered), long reach, high lift, the body rocks.
def gallop(ph,nf):
    fr=Image.new('RGBA',(FW,FH));t=ph/nf;bob=round(-1.2*math.sin(2*math.pi*t))
    d=np.array(fr);near=(202,150,84,255);far=(150,104,58,255);paw=(45,37,37,255);G=OY+26
    for (hx,hy,off,col,front) in [(OX+15,OY+15,0.0,far,0),(OX+33,OY+15,0.5,far,1),(OX+13,OY+16,0.08,near,0),(OX+35,OY+16,0.58,near,1)]:
        a=2*math.pi*(t+off);sw=math.sin(a)*7;lift=max(0,math.cos(a))*4
        px=hx+sw;py=G-lift;kx=(hx+px)/2+(2 if not front else -1.5)*(.5+lift*.4);ky=(hy+bob+py)/2-.5
        legline(d,hx,hy+bob,kx,ky,col);legline(d,kx,ky,px,py-1,col)
        x=round(px);y=round(py)
        for xx in (x,x+1,x+2):
            if 0<=xx<FW and 0<=y<FH:d[y,xx]=paw
    fr=Image.fromarray(d);b=Image.new('RGBA',(FW,FH));b.alpha_composite(WBODY,(OX,OY+bob));fr.alpha_composite(b);return fr
A['run']=[gallop(i,4) for i in range(4)]
# idle: Kyle's sitting dog, tail wagging
def sitf(tail):
    fr=Image.new('RGBA',(FW,FH));T,R=split(SIT,lambda x,y:x<=11 and y>=17)
    t=Image.new('RGBA',(FW,FH));t.alpha_composite(T,(OX+6,FH-SIT.height-2));
    if tail:t=t.rotate(tail,resample=Image.NEAREST,center=(OX+6+11,FH-SIT.height-2+22))
    fr.alpha_composite(t);fr.alpha_composite(R,(OX+6,FH-SIT.height-2));return fr
A['idle']=[sitf(0),sitf(10),sitf(0),sitf(-8)]
# bite: gather, lunge with jaws open, recover
def jaws(fr,dx):
    d=np.array(fr);mx=OX+dx+45;my=OY+7
    for (x,y,c) in [(mx,my,(20,14,14,255)),(mx+1,my,(20,14,14,255)),(mx,my+1,(240,236,220,255)),(mx+1,my-1,(240,236,220,255)),(mx+2,my+1,(20,14,14,255)),(mx-1,my+1,(200,80,90,255))]:
        if 0<=x<FW and 0<=y<FH:d[y,x]=c
    return Image.fromarray(d)
A['melee']=[pose(-50,44,-1,-1),jaws(pose(8,-6,0,4,-4),4),pose(-20,18,0,1)]
# hurt: flinch back
A['hurt']=[pose(-35,30,-1,-2,6)]
# death: collapses onto its side
def dead(k):
    fr=pose(-12*k,10*k,0)
    if k>=1:   # collapsed on its side: squashed down onto the ground, a little tilted head-down
        a=fr.crop(fr.getbbox());w,h=a.size;a=a.resize((w,max(4,round(h*.62))),Image.NEAREST).rotate(-4,resample=Image.NEAREST,expand=True)
        fr=Image.new('RGBA',(FW,FH));fr.alpha_composite(a,(OX,OY+26-a.height+1));return fr
    return fr.rotate(-12,resample=Image.NEAREST,center=(OX+24,OY+26))
A['death']=[dead(.5),dead(1)]
rows=list(A.items());SH=Image.new('RGBA',(FW*max(len(v) for _,v in rows),FH*len(rows)));meta={}
for r,(n,ims) in enumerate(rows):
    for i,im in enumerate(ims):SH.alpha_composite(im.transpose(Image.FLIP_LEFT_RIGHT),(i*FW,r*FH))
    meta[n]=dict(fw=FW,fh=FH,n=len(ims),ax=FW-(OX+24),ay=OY+26,x=0,y=r*FH,img='dog')
SH.save('/home/claude/pod2/crawl_dog.png');json.dump(meta,open('dog.json','w'))
pv=Image.new('RGBA',SH.size,(60,50,46,255));pv.alpha_composite(SH);pv.resize((SH.width*5,SH.height*5),Image.NEAREST).save('/tmp/dog2.png')
