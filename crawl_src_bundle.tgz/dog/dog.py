# Original pixel-art guard dog (shepherd mutt) for Crypt Crawl: idle 2, walk 4, run 4, melee (bite) 3, hurt 1, death 2. Faces RIGHT.
from PIL import Image, ImageDraw
import json, math
FW,FH=44,30
OUT=(24,18,14);TAN=(196,140,72);TAND=(150,100,48);TANL=(232,190,120);SAD=(40,34,40);SADL=(70,62,72);PINK=(226,140,140);CREAM=(240,214,160);NOSE=(16,12,10);EYE=(250,230,120);TONG=(204,80,90);WH=(236,228,212);COL=(170,40,36)
def dog(d,ox,oy,legs,head=0,tail=0,body=0,mouth=0,squash=0,lie=0,pant=0):
    by=oy+12+body
    if lie:   # lying on its side (death)
        d.ellipse([ox+6,by+4,ox+34,by+13],fill=TAN,outline=OUT);d.ellipse([ox+12,by+4,ox+30,by+9],fill=SAD)
        d.ellipse([ox+30,by+3,ox+41,by+11],fill=TAN,outline=OUT);d.polygon([(ox+33,by+3),(ox+36,by-1),(ox+37,by+4)],fill=SAD,outline=OUT)
        for lx in (10,15,24,29):d.line([(ox+lx,by+12),(ox+lx+3,by+15)],fill=OUT,width=2)
        d.line([(ox+6,by+8),(ox+1,by+10)],fill=TAND,width=2);d.point((ox+38,by+6),fill=OUT);return
    # tail (wagging)
    tx,ty=ox+8,by+1;sw=tail*.6
    pts=[(tx,ty),(tx-4,ty-1+sw),(tx-7,ty-4+sw),(tx-8,ty-8+sw)]
    d.line(pts,fill=OUT,width=6);d.line(pts,fill=TAN,width=4);d.line(pts[:3],fill=TANL,width=1);d.line([(tx-1,ty-2),(tx-5,ty-3+sw)],fill=SAD,width=2);d.point((pts[-1][0],pts[-1][1]-1),fill=SAD)
    # legs: (x offset, lift) per leg back-far, back-near, front-far, front-near
    for i,(lx,lift,fwd) in enumerate(legs):
        x=ox+lx;top=by+6;bot=oy+FH-2-lift;col=TAND if i%2==0 else TAN
        d.line([(x,top),(x+fwd,bot)],fill=OUT,width=4);d.line([(x,top),(x+fwd,bot-1)],fill=col,width=2);d.point((x+fwd+1,bot),fill=OUT)
    # body + dark saddle
    d.polygon([(ox+8,by+1),(ox+14,by-2),(ox+26,by-4),(ox+32,by-2),(ox+33,by+5),(ox+30,by+10-squash),(ox+20,by+9-squash),(ox+10,by+8-squash),(ox+7,by+5)],fill=TAN,outline=OUT)
    d.polygon([(ox+9,by+1),(ox+14,by-1),(ox+26,by-3),(ox+30,by-1),(ox+28,by+3),(ox+22,by+4),(ox+15,by+4),(ox+10,by+3)],fill=SAD);d.line([(ox+15,by-1),(ox+26,by-2)],fill=SADL)
    d.polygon([(ox+27,by+4),(ox+32,by+3),(ox+31,by+9-squash),(ox+27,by+9-squash)],fill=CREAM)   # chest
    d.line([(ox+12,by+8-squash),(ox+24,by+8-squash)],fill=TANL)
    # neck + collar
    hx,hy=ox+30,by-6+head
    d.polygon([(ox+27,by),(hx+1,hy+3),(hx+5,hy+5),(ox+32,by+5)],fill=TAN,outline=OUT);d.line([(ox+29,by-1),(ox+32,by+3)],fill=COL,width=2)
    # head, ears, snout
    d.ellipse([hx-2,hy-3,hx+7,hy+6],fill=TAN,outline=OUT);d.ellipse([hx+3,hy-1,hx+7,hy+4],fill=SADL)   # dark mask
    d.polygon([(hx-1,hy-1),(hx,hy-10),(hx+3,hy-2)],fill=SAD,outline=OUT);d.polygon([(hx+3,hy-2),(hx+5,hy-10),(hx+7,hy-1)],fill=SAD,outline=OUT);d.line([(hx+1,hy-6),(hx+1,hy-4)],fill=PINK);d.line([(hx+5,hy-7),(hx+5,hy-4)],fill=PINK)
    if mouth:   # jaws open (bite)
        d.polygon([(hx+5,hy),(hx+13,hy-1-mouth),(hx+13,hy+1-mouth),(hx+6,hy+2)],fill=SAD,outline=OUT)
        d.polygon([(hx+5,hy+3),(hx+12,hy+4+mouth),(hx+12,hy+6+mouth),(hx+5,hy+5)],fill=SAD,outline=OUT);d.line([(hx+6,hy+3),(hx+11,hy+4+mouth)],fill=TONG)
        for k in range(3):d.point((hx+8+k*2,hy+1-mouth+1),fill=WH);d.point((hx+8+k*2,hy+4+mouth),fill=WH)
        d.point((hx+13,hy-1-mouth),fill=NOSE)
    else:
        d.polygon([(hx+5,hy),(hx+13,hy+1),(hx+13,hy+4),(hx+5,hy+5)],fill=SAD,outline=OUT);d.rectangle([hx+12,hy,hx+13,hy+1],fill=NOSE);d.point((hx+6,hy+4),fill=TAND)
        d.line([(hx+7,hy+4),(hx+11,hy+4)],fill=TAND)
        if pant:d.rectangle([hx+8,hy+5,hx+9,hy+6+pant],fill=PINK);d.point((hx+8,hy+7+pant),fill=OUT)
    d.point((hx+4,hy+1),fill=EYE);d.point((hx+4,hy+2),fill=OUT)
anims={}
def frames(name,specs):
    ims=[]
    for sp in specs:
        im=Image.new('RGBA',(FW,FH));d=ImageDraw.Draw(im);dog(d,0,0,**sp);ims.append(im)
    anims[name]=ims
L0=[(11,0,0),(14,0,0),(26,0,0),(29,0,0)]
frames('idle',[dict(legs=L0,tail=0,pant=0),dict(legs=L0,tail=3,body=0,head=1,pant=1)])
W=[[(11,0,-2),(14,2,2),(26,2,2),(29,0,-2)],[(11,1,0),(14,0,0),(26,0,0),(29,1,0)],[(11,2,2),(14,0,-2),(26,0,-2),(29,2,2)],[(11,0,0),(14,1,0),(26,1,0),(29,0,0)]]
frames('walk',[dict(legs=l,tail=i%2*2,body=(i%2)) for i,l in enumerate(W)])
R=[[(9,4,-7),(12,3,-6),(27,3,7),(30,4,8)],[(11,1,-2),(14,0,-1),(26,2,2),(29,1,3)],[(13,2,5),(16,3,6),(24,3,-5),(27,4,-6)],[(11,0,1),(14,1,0),(26,0,-1),(29,1,0)]]
frames('run',[dict(legs=l,tail=[-4,-2,-3,-2][i],body=[-1,0,1,0][i],head=[1,0,1,0][i],squash=[2,0,1,0][i],pant=1) for i,l in enumerate(R)])
frames('melee',[dict(legs=L0,head=2,mouth=1,body=1),dict(legs=[(9,0,-3),(12,0,-2),(28,1,3),(31,1,3)],head=-1,mouth=3,body=-1),dict(legs=L0,head=1,mouth=1)])
frames('hurt',[dict(legs=[(11,0,-1),(14,0,-1),(26,0,-2),(29,0,-2)],head=3,squash=2,tail=-2)])
frames('death',[dict(legs=[(11,0,-2),(14,0,-2),(26,1,-3),(29,1,-3)],head=4,squash=3,tail=-3),dict(legs=L0,lie=1)])
# sheet: one row per animation, frames face LEFT like every other unit sheet (the game flips by facing)
rows=list(anims.items());SH=Image.new('RGBA',(FW*max(len(v) for _,v in rows),FH*len(rows)));meta={}
for r,(n,ims) in enumerate(rows):
    for i,im in enumerate(ims):SH.alpha_composite(im.transpose(Image.FLIP_LEFT_RIGHT),(i*FW,r*FH))
    meta[n]=dict(fw=FW,fh=FH,n=len(ims),ax=FW-21,ay=FH-2,x=0,y=r*FH,img='dog')
SH.save('/home/claude/pod2/crawl_dog.png');json.dump(meta,open('dog.json','w'))
prev=Image.new('RGBA',(SH.width,SH.height),(60,50,46,255));prev.alpha_composite(SH);prev.resize((SH.width*5,SH.height*5),Image.NEAREST).save('/tmp/dog.png')
