import json, sys
sys.path.insert(0, '/home/claude/pod2')
from takeaways_text import TEXTS
from build_data import build
d, res, divs = build(TEXTS)
json.dump(d, open('/home/claude/pod2/data.json', 'w'), ensure_ascii=False)
t = open('/home/claude/pod2/template.html').read()
import time as _t; t = t.replace('crawl.js?v=0.12.1', 'crawl.js?v=%d' % int(_t.time()))   # 0.12.23: cache-bust the game script on every build so new art/code always loads
a = t.index("      <h2>What's new</h2>"); b = t.index('    </section>\n  </div>\n</div>\n\n<script>')
def _notes_tabs(html):   # 0.12.346 (Kyle): notes split into Website / Crypt Crawl tabs
    import re
    WEB = re.compile(r"\b(life tracker|lands matters|snow matters|matters formula|matters flats|matters retune|garage|needs repair|kenzie joins|primary directive|themes?|string lights|ratings?|salt|pod sim|bone zone|takeaways?|rundown|spinner|dice roller|scryfall|player key|tags?|new decks|decks retuned|scoring|status-bar faces|website)\b")
    head, sep, rest = html.partition('<h3>')
    if not sep: return html
    parts = re.split(r'(?=<h3>)', sep + rest)
    out = []
    for p in parts:
        m = re.match(r'<h3>(.*?)</h3>', p, re.S)
        title = (m.group(1) if m else '').lower()
        k = 'web' if WEB.search(title) and not re.search(r'inspiration|boss|crypt|crawl|camp|hero', title) else 'crawl'
        out.append('<div class="nt-e" data-k="%s">%s</div>' % (k, p))
    tabs = ('<div class="nt-tabs" style="display:flex;gap:6px;margin:6px 0 10px">'
            '<button class="nt-tab on" data-nt="crawl" style="padding:5px 14px;border-radius:8px;border:1px solid #a6ff2e;background:#1a2a10;color:#a6ff2e;font-weight:700;cursor:pointer">⚰️ Crypt Crawl</button>'
            '<button class="nt-tab" data-nt="web" style="padding:5px 14px;border-radius:8px;border:1px solid #555;background:#141018;color:#ddd;font-weight:700;cursor:pointer">🌐 Website</button></div>')
    js = ('<script>(function(){const T=document.querySelectorAll(".nt-tab"),E=document.querySelectorAll(".nt-e");'
          'function go(k){E.forEach(e=>e.style.display=e.dataset.k===k?"":"none");T.forEach(b=>{const on=b.dataset.nt===k;b.classList.toggle("on",on);'
          'b.style.borderColor=on?"#a6ff2e":"#555";b.style.color=on?"#a6ff2e":"#ddd";b.style.background=on?"#1a2a10":"#141018";});}'
          'T.forEach(b=>b.onclick=()=>go(b.dataset.nt));go("crawl");})();</script>')
    return head + tabs + ''.join(out) + js
t = t[:a] + _notes_tabs(open('/home/claude/pod2/notes.html').read()) + t[b:]
import re as _re   # 0.12.0: the old Clock/⛔ patches now live in template.html itself

from stat_page import STATDOCS, RATING_MATH
t = t.replace('__STATDOCS__', json.dumps(dict(stats=STATDOCS, math=RATING_MATH), ensure_ascii=False).replace('</', '<\\/'))
from story_kit import KIT, PAIR
GATE = False   # 0.12.1: members-only login page. Off for now (Kyle's call); flip to True to turn it back on.
if not GATE:
    t = _re.sub(r'<!--GATE-->.*?<!--/GATE-->', '', t, flags=_re.S)
_D = json.load(open('/home/claude/pod2/data.json'))['decks']
_top = sorted(_D, key=lambda r: -r['total'])[:8]
t = t.replace('__HISCORE__', ''.join(f"<span>{i+1:02d}</span><span>{r['deck'][:16].upper()}</span><span>{int(r['total']*100):06d}</span>" for i, r in enumerate(_top)))
t = t.replace('__DECKCOUNT__', str(len(_D)))
t = t.replace('__TICKER__', ' ★ '.join(f"{r['icon']} {r['deck'].upper()}" for r in sorted(_D, key=lambda r: r['deck'])) + ' ★ HIGH ROLLERS WELCOME ★ ')
import json as _json
_sd = _json.load(open('/tmp/claude-0/simdata.json')); _sd.pop('Primary Directive', None)   # 0.12.102: original list retired (2.0 is the deck)
t = t.replace('__SIMDATA__', _json.dumps(_sd).replace('</', '<\\/'))
t = t.replace('__SIMENGINE__', open('/home/claude/pod2/sim_engine.js').read())
t = t.replace('__STORYKIT__', json.dumps(dict(KIT, __pair=PAIR), ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/'))
t = t.replace('__OUTCOMES__', open('/home/claude/pod2/pod_outcomes.json').read().replace('</', '<\\/'))
t = t.replace('__DATA__', json.dumps(d, ensure_ascii=False).replace('</', '<\\/'))
open('/home/claude/pod2/index.html', 'w').write(t)
for k in d['takeaways']: print(k['deck'], [(x['card'], x['read']) for x in k['repair']])
