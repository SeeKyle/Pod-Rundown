# Region-based pixel painter: draw flat regions, then every region is shaded on its own (light from the upper right),
# seams between regions get a dark line, and the whole figure gets a soft-black outline.
from PIL import Image, ImageDraw
W,H=56,76
class Fig:
    def __init__(s):s.reg=Image.new('L',(W,H),0);s.d=ImageDraw.Draw(s.reg);s.pal={0:None};s.soft=set();s.n=0;s.extra=[]
    def mat(s,c,soft=False,light=1.18,dark=.66):
        s.n+=1;s.pal[s.n]=(c,light,dark);(s.soft.add(s.n) if soft else None);return s.n
    def rect(s,m,x0,y0,x1,y1):s.d.rectangle([x0,y0,x1,y1],fill=m)
    def poly(s,m,pts):s.d.polygon(pts,fill=m)
    def ell(s,m,b):s.d.ellipse(b,fill=m)
    def line(s,m,a,b,w=1):s.d.line([a,b],fill=m,width=w)
    def px(s,m,x,y):s.d.point((x,y),fill=m)
    def dot(s,c,x,y):s.extra.append((x,y,c))   # raw colored pixel painted after shading (eyes, glints, rivets)
    def render(s):
        R=s.reg.load();im=Image.new('RGBA',(W,H),(0,0,0,0));P=im.load()
        g=lambda x,y:R[x,y] if 0<=x<W and 0<=y<H else 0
        def tone(c,k):return tuple(max(0,min(255,int(v*k))) for v in c[:3])+(255,)
        for y in range(H):
            for x in range(W):
                m=R[x,y]
                if not m:continue
                c,lt,dk=s.pal[m]
                L,Rt,U,D=g(x-1,y),g(x+1,y),g(x,y-1),g(x,y+1)
                k=1.0
                if Rt!=m or U!=m:k=lt           # lit rim (upper right)
                if L!=m or D!=m:k=dk            # shadow rim (lower left)
                if (Rt!=m and U!=m):k=lt*1.06
                # seam line where two materials meet (drawn on the darker side, skipped for soft materials)
                for n in (L,Rt,U,D):
                    if n and n!=m and m not in s.soft:
                        nc=s.pal[n][0]
                        if sum(c[:3])<=sum(nc[:3]) or n in s.soft:k=min(k,.52)
                P[x,y]=tone(c,k)
        for x,y,c in s.extra:
            if 0<=x<W and 0<=y<H:P[x,y]=c
        # figure outline
        o=im.copy();Q=o.load()
        for y in range(H):
            for x in range(W):
                if P[x,y][3]==0 and any(0<=x+dx<W and 0<=y+dy<H and P[x+dx,y+dy][3] for dx,dy in((1,0),(-1,0),(0,1),(0,-1))):Q[x,y]=(16,12,20,255)
        return o
def frame(fig_img,ax=67):
    f=Image.new('RGBA',(128,128),(0,0,0,0));f.alpha_composite(fig_img,(ax-W//2,128-H));return f
