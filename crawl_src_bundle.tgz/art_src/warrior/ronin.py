import sys;sys.path.insert(0,'/home/claude/pod2/art_src/warrior')
from engine import Fig,frame,W,H
from PIL import Image
def ronin(v=0):
    """Straw-hat wanderer: a wide kasa hat that hides the eyes, a pale gi with the sleeves tied back, wide charcoal hakama,
       bare feet, katana drawn and held low and forward, the empty saya angled behind the hip. v picks a palette."""
    PAL=[dict(hat=(222,178,72),band=(120,70,40),gi=(214,226,236),giS=(150,170,196),hak=(70,84,110),obi=(150,40,36),sash=(196,60,48)),
         dict(hat=(206,170,96),band=(60,50,44),gi=(232,226,210),giS=(176,164,140),hak=(48,48,56),obi=(40,90,80),sash=(70,140,120)),
         dict(hat=(190,150,70),band=(150,30,30),gi=(70,70,90),giS=(50,50,66),hak=(140,40,40),obi=(30,30,34),sash=(220,190,90))][v]
    f=Fig();x=14
    skin=f.mat((222,170,128));skinD=f.mat((180,128,96))
    hat=f.mat(PAL['hat'],light=1.15,dark=.7);band=f.mat(PAL['band']);gi=f.mat(PAL['gi'],light=1.08);giS=f.mat(PAL['giS'])
    hak=f.mat(PAL['hak']);hakD=f.mat(tuple(int(c*.75) for c in PAL['hak']));obi=f.mat(PAL['obi']);sash=f.mat(PAL['sash'],soft=True)
    steel=f.mat((206,214,226),light=1.25,dark=.75);guard=f.mat((70,60,40));hilt=f.mat((40,36,44));saya=f.mat((30,28,34),light=1.4);shadowF=f.mat((60,40,36))
    # bare feet in a wide stance
    f.rect(skin,x-4,70,x+2,74);f.rect(skin,x+12,70,x+19,74)
    # hakama: wide pleated trousers flaring out, front leg forward
    f.poly(hak,[(x+1,46),(x+14,46),(x+20,70),(x+12,70),(x+8,56),(x+4,70),(x-5,70)])
    f.line(hakD,(x+7,48),(x+8,62));f.line(hakD,(x+2,50),(x-2,68));f.line(hakD,(x+13,50),(x+17,68))   # pleats
    f.rect(hakD,x-5,69,x+3,70);f.rect(hakD,x+11,69,x+20,70)                                         # tied ankles
    # gi top, sleeves tied back with a cord
    f.poly(gi,[(x,28),(x+14,28),(x+15,47),(x-1,47)]);f.poly(giS,[(x+5,28),(x+9,28),(x+7,40)])        # V of the collar
    f.line(giS,(x+2,30),(x+7,41));f.line(giS,(x+12,30),(x+8,41))
    f.rect(obi,x-1,44,x+15,47);f.poly(sash,[(x-1,45),(x-6,52),(x-4,53),(x+1,47)])                    # obi + trailing sash end
    # back arm (holding nothing, pulled back)
    f.poly(gi,[(x-1,29),(x-6,40),(x-3,42),(x+2,33)]);f.rect(skin,x-6,40,x-3,44)
    # front arm reaching forward-down to the katana grip
    f.poly(gi,[(x+13,29),(x+20,38),(x+18,41),(x+12,34)]);f.rect(skin,x+18,39,x+22,43)
    # katana held low and forward, edge down
    f.line(hilt,(x+19,42),(x+24,44),2);f.rect(guard,x+24,42,x+25,46);f.line(steel,(x+26,45),(x+36,50),2);f.line(steel,(x+36,50),(x+40,51))
    # saya angled behind the back hip
    f.line(saya,(x-2,46),(x-14,56),2)
    # head: chin and jaw under the hat brim, the hat hides the eyes
    f.rect(skin,x+3,19,x+12,28);f.rect(skinD,x+3,19,x+12,21)                                          # shadow under the brim
    f.rect(f.mat((40,32,30)),x+2,22,x+3,27)                                                           # a bit of hair at the back
    f.poly(hat,[(x-9,20),(x+7,6),(x+24,20),(x+22,22),(x-7,22)])                                       # wide kasa
    f.line(band,(x-1,15),(x+15,15))                                                                   # cord around the crown
    f.line(band,(x+4,22),(x+3,28))                                                                    # chin cord
    for i in range(-6,22,4):f.dot((176,136,52,255),x+i,19)                                            # straw weave ticks
    f.dot((255,255,255,255),x+38,50);f.dot((255,255,255,255),x+32,48)                                 # blade glints
    f.dot((90,60,50,255),x+9,26)                                                                       # mouth
    return f.render()
if __name__=='__main__':
    S=4;names=['Sky-blue gi','White gi / jade sash','Night gi / red hakama']
    sh=Image.new('RGBA',(W*3*S+40,H*S+30),(196,196,200,255))
    for v in range(3):sh.alpha_composite(ronin(v).resize((W*S,H*S),Image.NEAREST),(10+v*(W*S+10),20))
    sh.save('/tmp/ronin_big.png')
    import json
    A=json.load(open('/home/claude/pod2/crawl_atlas.json'))['units']
    def idle(k):
        a=A[k]['idle'];im=Image.open('/home/claude/pod2/crawl_%s.png'%a.get('img',k)).convert('RGBA').crop((a['x'],a['y'],a['x']+a['fw'],a['y']+a['fh']))
        return im if im.size==(128,128) else im.resize((128,128),Image.NEAREST)
    row=Image.new('RGBA',(128*5,128),(30,26,38,255))
    for i,im in enumerate([idle('chibi'),frame(ronin(0)),frame(ronin(1)),frame(ronin(2)),idle('soldier')]):row.alpha_composite(im,(i*128,0))
    row.crop((0,40,640,128)).resize((1280,176),Image.NEAREST).save('/tmp/ronin_scale.png')
