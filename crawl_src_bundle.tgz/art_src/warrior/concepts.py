# 0.12.399 concept sheets for a new warrior to replace Chibi_Warrior (same 128px frame, feet at x=67)
from PIL import Image, ImageDraw
W,H=48,72
def canvas():return Image.new('RGBA',(W,H),(0,0,0,0))
def R(d,x0,y0,x1,y1,c):d.rectangle([x0,y0,x1,y1],fill=c)
def P(d,x,y,c):d.point((x,y),fill=c)
def outline(im,c=(18,14,22,255)):
    px=im.load();o=im.copy();q=o.load()
    for y in range(H):
        for x in range(W):
            if px[x,y][3]==0 and any(0<=x+dx<W and 0<=y+dy<H and px[x+dx,y+dy][3]>0 for dx,dy in((1,0),(-1,0),(0,1),(0,-1))):q[x,y]=c
    return o
def shade(im,amt=.72):
    # darken the back (left) column of every filled run and the underside, a cheap rim of form
    px=im.load();o=im.copy();q=o.load()
    for y in range(H):
        for x in range(W):
            p=px[x,y]
            if p[3] and (x==0 or px[x-1,y][3]==0 or (y+1<H and px[x,y+1][3]==0)):q[x,y]=(int(p[0]*amt),int(p[1]*amt),int(p[2]*amt),255)
    return o
SK=(232,184,150,255);SK2=(196,146,116,255)
def legs(d,x,y,c,boot,stance=0):
    R(d,x,y,x+4,y+16,c);R(d,x+7,y,x+11,y+16,c);R(d,x-1,y+15,x+4,y+19,boot);R(d,x+7,y+15,x+12,y+19,boot)
def ronin():
    im=canvas();d=ImageDraw.Draw(im);x=18
    legs(d,x,48,(70,60,58,255),(40,32,30,255))
    R(d,x-2,28,x+13,49,(150,40,40,255))                 # red haori
    R(d,x+1,28,x+10,47,(220,210,190,255))               # cream under-robe
    R(d,x-2,40,x+13,42,(30,30,34,255))                  # obi
    R(d,x-5,29,x-2,44,(150,40,40,255));R(d,x-5,44,x-3,47,SK)    # back arm
    R(d,x+13,29,x+16,43,(150,40,40,255));R(d,x+14,43,x+16,46,SK) # front arm
    R(d,x+1,17,x+10,28,SK);R(d,x+1,17,x+10,19,(30,26,30,255));R(d,x+8,22,x+9,23,(20,20,24,255))   # face, hair, eye
    R(d,x+2,26,x+9,28,(60,50,50,255))                   # stubble jaw
    d.polygon([(x-7,18),(x+5,8),(x+18,18)],fill=(206,170,92,255));R(d,x-7,17,x+18,18,(170,136,70,255))  # straw kasa hat
    d.line([(x+16,46),(x+30,32)],fill=(214,220,232,255),width=1);d.line([(x+16,47),(x+19,44)],fill=(40,30,30,255),width=2)  # katana
    R(d,x-4,44,x+0,46,(60,40,30,255))                   # scabbard tip
    return im
def gladiator():
    im=canvas();d=ImageDraw.Draw(im);x=18
    legs(d,x,48,SK,(110,70,40,255))
    R(d,x,49,x+11,53,(150,110,60,255))                  # leather greaves strap
    R(d,x-1,40,x+12,50,(160,40,36,255))                 # red kilt
    for i in range(0,13,3):R(d,x-1+i,46,x+i,50,(120,30,28,255))
    R(d,x,27,x+11,40,SK);R(d,x+1,30,x+10,31,SK2)        # bare chest
    d.line([(x,27),(x+11,40)],fill=(110,70,40,255),width=2)  # chest strap
    R(d,x-3,27,x+2,32,(190,190,200,255))                # shoulder pauldron
    R(d,x-4,30,x-1,44,SK);R(d,x+12,29,x+15,42,SK)
    R(d,x+1,14,x+10,27,(190,190,200,255));R(d,x+3,19,x+10,24,(30,26,30,255));R(d,x+5,20,x+6,21,(250,220,120,255))  # helmet + visor slit
    R(d,x+3,9,x+8,14,(200,40,40,255));R(d,x+2,8,x+9,10,(220,60,60,255))  # crest
    d.ellipse([x+10,30,x+24,46],fill=(150,110,60,255));d.ellipse([x+14,34,x+20,41],fill=(210,180,90,255))  # round shield
    d.line([(x-4,44),(x-4,32)],fill=(214,220,232,255),width=2);R(d,x-6,44,x-2,45,(110,70,40,255))  # gladius
    return im
def roadwarrior():
    im=canvas();d=ImageDraw.Draw(im);x=18
    legs(d,x,48,(60,66,80,255),(50,40,34,255))
    R(d,x+7,52,x+11,55,(90,90,96,255))                  # knee pad
    R(d,x-1,28,x+12,49,(96,74,56,255))                  # brown leather jacket
    R(d,x+3,28,x+8,44,(70,90,70,255))                   # olive tee
    R(d,x-4,26,x+3,31,(34,34,36,255));R(d,x-3,27,x+2,30,(50,50,52,255))  # tire-tread shoulder armor
    for i in range(-3,3,2):P(d,x+i,28,(20,20,22,255))
    R(d,x-4,29,x-1,44,(96,74,56,255));R(d,x+12,29,x+15,42,(96,74,56,255));R(d,x+13,42,x+15,45,SK)
    R(d,x+1,16,x+10,28,SK);R(d,x+1,14,x+10,18,(40,30,26,255))   # face, hair
    R(d,x+1,23,x+10,28,(180,40,40,255))                 # red bandana mask
    R(d,x+2,18,x+10,21,(40,40,44,255));R(d,x+7,19,x+9,20,(250,190,60,255))  # goggles
    d.line([(x+15,43),(x+29,29)],fill=(200,206,214,255),width=2);R(d,x+14,43,x+17,46,(40,30,26,255))  # machete
    R(d,x-1,40,x+12,41,(40,30,26,255))                  # belt
    return im
def barbarian():
    im=canvas();d=ImageDraw.Draw(im);x=18
    legs(d,x,48,(90,70,50,255),(70,50,36,255))
    R(d,x-1,40,x+12,48,(110,84,60,255))                 # fur loincloth
    R(d,x-1,27,x+12,40,SK);R(d,x+2,32,x+9,33,SK2);R(d,x+5,28,x+6,39,SK2)
    R(d,x-3,25,x+14,30,(130,104,80,255));R(d,x-3,30,x+0,32,(130,104,80,255))  # fur mantle
    R(d,x-4,29,x-1,44,SK);R(d,x+12,29,x+15,42,SK)
    R(d,x+1,15,x+10,27,SK);R(d,x+8,20,x+9,21,(30,30,40,255))
    R(d,x-1,11,x+12,17,(200,150,60,255));R(d,x-2,15,x+1,30,(200,150,60,255))  # long blond hair
    R(d,x+2,23,x+10,28,(190,140,56,255))                # beard
    d.line([(x+14,44),(x+14,10)],fill=(200,206,214,255),width=3);R(d,x+11,42,x+17,43,(110,84,60,255));R(d,x+13,43,x+15,48,(80,60,40,255))  # greatsword
    return im
def finish(im):
    im=shade(im);im=outline(im);f=Image.new('RGBA',(128,128),(0,0,0,0));f.alpha_composite(im,(67-24,128-H));return f
names=[('Ronin','ronin'),('Gladiator','gladiator'),('Road Warrior','roadwarrior'),('Barbarian','barbarian')]
frames=[finish(globals()[f]()) for _,f in names]
sheet=Image.new('RGBA',(128*4,128),(34,30,42,255))
for i,f in enumerate(frames):sheet.alpha_composite(f,(i*128,0))
sheet.resize((128*4*3,128*3),Image.NEAREST).save('/tmp/warrior_concepts.png')
