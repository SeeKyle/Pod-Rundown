import sys;sys.path.insert(0,'/home/claude/pod2/art_src/warrior')
from engine import Fig,frame,W,H
from PIL import Image
SKIN=(226,178,140);
def stopsign():
    """THE STOP-SIGN PALADIN: a hockey-masked road knight. Shield is a real octagonal STOP sign on its pole-bolts,
       sword is a sharpened length of rebar with a duct-taped grip, shoulder armor cut from a traffic cone."""
    f=Fig();x=22
    boot=f.mat((58,46,40));jean=f.mat((62,84,126));knee=f.mat((40,40,44));
    jack=f.mat((52,58,52));vest=f.mat((222,150,40));refl=f.mat((214,222,226),soft=True)
    cone=f.mat((240,104,36));coneW=f.mat((236,236,232),soft=True)
    mask=f.mat((230,226,214));hood=f.mat((44,48,56));glove=f.mat((36,34,36))
    sign=f.mat((196,30,36));signW=f.mat((240,236,230));pole=f.mat((150,156,164))
    reb=f.mat((120,96,82),light=1.3);tape=f.mat((170,170,176))
    # legs
    f.rect(jean,x,48,x+5,70);f.rect(jean,x+8,48,x+13,70);f.rect(knee,x+8,55,x+13,58);f.rect(knee,x,56,x+5,58)
    f.rect(boot,x-1,69,x+5,74);f.rect(boot,x+8,69,x+14,74)
    # torso: jacket under a hi-vis vest
    f.rect(jack,x-2,29,x+15,49);f.rect(vest,x,30,x+13,47);f.rect(refl,x,38,x+13,39);f.rect(refl,x+3,30,x+4,47);f.rect(refl,x+9,30,x+10,47)
    f.rect(knee,x-1,46,x+14,48)   # belt
    # traffic-cone pauldron on the back shoulder
    f.poly(cone,[(x+11,31),(x+16,21),(x+21,31)]);f.rect(coneW,x+13,26,x+18,27)
    # arms
    f.rect(jack,x-5,33,x-1,45);f.rect(glove,x-5,45,x-1,48)
    f.rect(jack,x+14,30,x+18,42);f.rect(glove,x+14,42,x+18,45)
    # head: hood + goalie mask
    f.ell(hood,(x,10,x+14,28));f.ell(mask,(x+3,12,x+14,27))
    for (a,b) in [(x+9,17),(x+12,17)]:f.rect(hood,a,b,a+1,b+1)    # eye holes
    for i in range(4):f.px(hood,x+8+i*2,23)                       # breathing holes
    f.line(hood,(x+5,13),(x+5,26))                                # mask strap seam
    # rebar sword held up and forward
    f.line(reb,(x+17,44),(x+30,8),3)
    rib=f.mat((84,68,60))
    for i in range(1,11):t=i/11;f.px(rib,round(x+17+13*t)+1,round(44-36*t))
    f.poly(f.mat((196,190,184),light=1.3),[(x+29,10),(x+33,1),(x+31,11)])
    f.rect(tape,x+15,41,x+19,47)
    # STOP sign shield on the back arm, slightly in front of the body
    cx,cy,r=x-4,40,11
    import math
    pts=[(cx+r*math.cos(math.pi/8+i*math.pi/4),cy+r*math.sin(math.pi/8+i*math.pi/4)) for i in range(8)]
    f.poly(signW,pts);pts2=[(cx+(r-2)*math.cos(math.pi/8+i*math.pi/4),cy+(r-2)*math.sin(math.pi/8+i*math.pi/4)) for i in range(8)];f.poly(sign,pts2)
    f.rect(signW,cx-6,cy-1,cx+6,cy+1)                            # the word, as a white bar at this size
    for (a,b) in [(-4,-1),(-1,-1),(2,-1),(5,-1)]:f.dot((196,30,36,255),cx+a,cy+b+1) # letter gaps
    f.dot((255,255,255,255),x+12,18);f.dot((255,255,255,255),x+9,18)
    f.dot((255,250,235,255),x+32,2);f.dot((255,250,235,255),x+31,4)   # rebar tip glint
    return f.render()
def gravedigger():
    """THE GRAVEDIGGER: a cemetery caretaker who never stopped working. Fights with a shovel sharpened into a glaive,
       a coffin-lid shield nailed with crosses, a lantern on his belt with a pale green flame, wide-brimmed hat and long coat."""
    f=Fig();x=22
    boot=f.mat((46,36,32));pant=f.mat((70,64,60));coat=f.mat((54,48,64));coatL=f.mat((70,62,82))
    shirt=f.mat((180,170,150));vest=f.mat((96,60,44));belt=f.mat((40,30,26))
    skin=f.mat(SKIN);beard=f.mat((120,118,112));hat=f.mat((40,34,38))
    wood=f.mat((112,76,48));woodD=f.mat((84,56,36));iron=f.mat((120,124,132),light=1.35)
    lamp=f.mat((60,60,52));glass=f.mat((150,255,170),soft=True,light=1.1,dark=.9)
    f.rect(pant,x+1,50,x+5,70);f.rect(pant,x+8,50,x+12,70);f.rect(boot,x,69,x+6,74);f.rect(boot,x+7,69,x+13,74)
    # long coat with tails
    f.poly(coat,[(x-3,28),(x+16,28),(x+18,62),(x+11,58),(x+6,62),(x+1,58),(x-5,62)])
    f.rect(shirt,x+4,29,x+9,46);f.rect(vest,x+3,32,x+10,46);f.rect(coatL,x+2,29,x+3,48);f.rect(coatL,x+10,29,x+11,48)
    f.rect(belt,x-1,46,x+14,48)
    # arms
    f.rect(coat,x-5,31,x-1,46);f.rect(skin,x-5,46,x-2,48);f.rect(coat,x+15,30,x+19,43);f.rect(skin,x+16,43,x+19,46)
    # head: gaunt face, grey stubble beard, wide hat
    f.rect(skin,x+3,15,x+12,27);f.rect(beard,x+3,23,x+12,28);f.rect(hat,x+1,12,x+13,15);f.poly(hat,[(x-4,16),(x+19,16),(x+17,14),(x-2,14)]);f.rect(hat,x+3,7,x+11,12)
    f.rect(f.mat((150,40,40)),x+3,11,x+11,12)    # faded hat band
    # sharpened shovel-glaive
    f.line(wood,(x+18,46),(x+28,14),2);f.rect(f.mat((60,58,62)),x+26,13,x+30,15)
    f.poly(iron,[(x+25,13),(x+31,15),(x+34,6),(x+33,0),(x+30,-1),(x+26,4)])
    f.line(f.mat((90,92,100)),(x+28,12),(x+31,2))
    # coffin-lid shield
    f.poly(wood,[(x-12,30),(x-4,27),(x+2,30),(x+0,52),(x-6,55),(x-11,52)]);f.rect(woodD,x-6,31,x-4,51);f.rect(woodD,x-10,38,x+0,40)   # nailed cross
    for (a,b) in [(x-9,31),(x-1,31),(x-9,50),(x-1,50)]:f.dot((200,200,210,255),a,b)
    # lantern on the hip
    f.rect(lamp,x+12,47,x+16,53);f.rect(glass,x+13,48,x+15,52)
    f.dot((20,16,20,255),x+9,19);f.dot((20,16,20,255),x+6,19);f.dot((235,255,240,255),x+14,49)
    return f.render()
def bonewarden():
    """THE BONE WARDEN: a warrior who armors himself in the zombies he's put down. Skull pauldron, rib-cage chest plate,
       a jaw-bone necklace, a femur-handled butcher cleaver, and one glowing eye under a war-paint mask of ash."""
    f=Fig();x=22
    boot=f.mat((60,44,36));wrap=f.mat((150,128,100));fur=f.mat((90,72,58));skin=f.mat((196,160,128))
    bone=f.mat((226,216,190),light=1.12);boneD=f.mat((180,168,140));ash=f.mat((70,70,76));hair=f.mat((30,26,30))
    cleav=f.mat((150,158,168),light=1.3);blood=f.mat((130,20,24),soft=True);cloth=f.mat((110,36,36))
    f.rect(fur,x+1,48,x+5,70);f.rect(fur,x+8,48,x+12,70);f.rect(wrap,x+1,58,x+5,66);f.rect(wrap,x+8,58,x+12,66)
    f.rect(boot,x,69,x+6,74);f.rect(boot,x+7,69,x+13,74)
    f.poly(cloth,[(x-1,44),(x+14,44),(x+16,56),(x+9,52),(x+4,56),(x-3,54)])          # tattered waist cloth
    f.rect(skin,x-1,28,x+14,45)
    for i in range(4):f.rect(bone,x+1,31+i*3,x+12,31+i*3)                              # ribs
    f.rect(boneD,x+6,30,x+7,43)                                                        # sternum
    f.ell(bone,(x-7,24,x+3,34));f.rect(ash,x-5,28,x-4,29);f.rect(ash,x-1,28,x+0,29);f.rect(boneD,x-4,32,x+0,33)   # skull pauldron, eye sockets, teeth
    f.rect(skin,x-5,33,x-1,45);f.rect(wrap,x-5,41,x-1,45);f.rect(skin,x+15,30,x+18,42);f.rect(wrap,x+15,38,x+18,42);f.poly(bone,[(x+18,38),(x+22,36),(x+18,40)]);f.poly(bone,[(x-5,42),(x-9,40),(x-5,44)])
    f.rect(skin,x+3,14,x+12,27);f.rect(ash,x+3,17,x+12,21);f.poly(hair,[(x+4,14),(x+6,4),(x+8,9),(x+10,3),(x+12,10),(x+13,14)]);f.rect(hair,x+2,13,x+3,22)
    for i in range(5):f.px(boneD,x+3+i*2,27)                                           # jaw-bone necklace
    # cleaver with a femur handle
    f.line(bone,(x+17,44),(x+22,30),2);f.poly(cleav,[(x+20,32),(x+31,20),(x+35,26),(x+25,36)]);f.poly(blood,[(x+31,21),(x+34,25),(x+33,27),(x+30,23)])
    f.dot((120,255,120,255),x+10,19);f.dot((200,255,200,255),x+11,19)               # the one glowing eye
    f.dot((20,16,20,255),x+6,19)
    return f.render()
if __name__=='__main__':
    D=[('Stop-Sign Paladin',stopsign()),('Gravedigger',gravedigger()),('Bone Warden',bonewarden())]
    import json
    A=json.load(open('/home/claude/pod2/crawl_atlas.json'))['units']
    def idle(k):
        a=A[k]['idle'];im=Image.open('/home/claude/pod2/crawl_%s.png'%a.get('img',k)).convert('RGBA').crop((a['x'],a['y'],a['x']+a['fw'],a['y']+a['fh']))
        return im if im.size==(128,128) else im.resize((128,128),Image.NEAREST)
    # sheet 1: the three designs big
    S=4;sh=Image.new('RGBA',(W*3*S+40,H*S+30),(30,26,38,255))
    for i,(n,im) in enumerate(D):sh.alpha_composite(im.resize((W*S,H*S),Image.NEAREST),(10+i*(W*S+10),20))
    sh.save('/tmp/warrior_big.png')
    # sheet 2: in-game scale next to the Knight and the Soldier
    row=Image.new('RGBA',(128*5,128),(30,26,38,255))
    for i,im in enumerate([idle('knight')]+[frame(d[1]) for d in D]+[idle('soldier')]):row.alpha_composite(im,(i*128,0))
    row.crop((0,40,640,128)).resize((640*2,88*2),Image.NEAREST).save('/tmp/warrior_scale.png')
