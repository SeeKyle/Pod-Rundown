# 0.12.510 (Kyle): Crimson_Knight reworked into an unholy knight: blackened iron armor, grave-violet cloth, sickly green hellfire where the crimson glow was.
import sys,colorsys
from PIL import Image
src,dst=sys.argv[1],sys.argv[2]
im=Image.open(src).convert('RGBA');px=im.load()
def lerp(a,b,t):return tuple(int(a[i]+(b[i]-a[i])*t) for i in range(3))
def ramp(stops,t):
  t=max(0,min(1,t))
  for i in range(len(stops)-1):
    t0,c0=stops[i];t1,c1=stops[i+1]
    if t<=t1:return lerp(c0,c1,(t-t0)/(t1-t0) if t1>t0 else 0)
  return stops[-1][1]
IRON=[(0,(12,13,16)),(.25,(46,48,58)),(.5,(84,88,98)),(.75,(128,134,140)),(1,(186,196,190))]
CLOTH=[(0,(6,3,9)),(.4,(32,14,40)),(1,(78,36,92))]
FIRE=[(0,(30,90,40)),(.5,(90,200,80)),(1,(200,255,140))]
cache={}
def conv(c):
  r,g,b=c[:3]
  if (r,g,b) in cache:return cache[(r,g,b)]
  h,s,v=colorsys.rgb_to_hsv(r/255,g/255,b/255);L=(0.3*r+0.59*g+0.11*b)/255
  if v<.06:o=(r,g,b)                                  # outline
  elif 0.03<h<0.14 and s>.55 and v>.55:o=ramp(FIRE,(v-.55)/.45)  # orange glow -> green hellfire
  elif (h>0.93 or h<0.03) and s>.6:o=ramp(CLOTH,v/.55)          # crimson cloth -> grave violet
  else:o=ramp(IRON,L**.9)                              # armor/steel -> blackened iron
  cache[(r,g,b)]=o;return o
for y in range(im.height):
  for x in range(im.width):
    p=px[x,y]
    if p[3]:px[x,y]=conv(p)+(p[3],)
# faint unholy aura: 1px of translucent green around the silhouette
A=im.copy().load();W,H=im.size
for y in range(H):
  for x in range(W):
    if A[x,y][3]==0 and any(0<=x+dx<W and 0<=y+dy<H and A[x+dx,y+dy][3]>200 for dx,dy in ((1,0),(-1,0),(0,1),(0,-1))):px[x,y]=(110,230,120,80)
im.save(dst)
