#!/bin/bash
# usage: pub2.sh VER "commit msg"  (build_site.py's text modules aren't in the backup, so index.html only gets its cache-bust bumped)
set -e
cd /home/claude/pod2
sed -i "s/v0\.12\.[0-9]*<\/span><\/span>/v$1<\/span><\/span>/" crawl_ui.js
python3 build_crawl.py >/dev/null && node --check crawl.js
cp notes.html crawl.js /home/claude/pod-rundown/
for f in crawl_*.png; do cmp -s $f /home/claude/pod-rundown/$f || cp $f /home/claude/pod-rundown/; done
cd /home/claude/pod-rundown && sed -i "s/crawl\.js?v=[0-9]*/crawl.js?v=$(date +%s)/" index.html
git add -A && git commit -q -m "$2

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_01MWfQtYETLAVggCvxhpGuJg" && git push -q https://github.com/SeeKyle/Pod-Rundown.git HEAD && git log --oneline | head -1
