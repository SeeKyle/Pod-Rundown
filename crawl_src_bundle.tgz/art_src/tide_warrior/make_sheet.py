# 0.12.399 (Kyle) Tide_Warrior art: "Animated Warrior" by calciumtrice (free, CC-BY 3.0, credit kept in the patch notes).
# The source is 10x10 frames of 32x32: rows 0-4 face right (idle, taunt, walk, attack, death), rows 5-9 repeat them turned to camera.
# Each frame is doubled to 64x64 and dropped into our 128x128 frame with the feet on the same spot the old sheet used (x=67, bottom).
import json
from PIL import Image
SRC='/home/claude/pod2/art_src/tide_warrior/warrior_spritesheet_calciumtrice.png'
im=Image.open(SRC).convert('RGBA')
def fr(r,c):return im.crop((c*32,r*32,c*32+32,r*32+32)).resize((64,64),Image.NEAREST)
# feet center of the first idle frame sets one fixed offset for every frame (so nothing jitters)
f0=im.crop((0,0,32,32));px=f0.load();xs=[x for x in range(32) for y in range(28,32) if px[x,y][3]]
cx=(min(xs)+max(xs)+1)/2;OX=round(67-2*cx)
ROWS=[('idle',0,range(10)),('walk',2,range(10)),('run',2,range(10)),('attack1',3,range(10)),('attack2',3,range(10)),('runatk',3,range(10)),
      ('hurt',4,range(3)),('death',4,range(10)),('ranged',1,range(10)),('rangedUp',1,range(10)),('rangedDown',1,range(10))]
sheet=Image.new('RGBA',(128*10,128*len(ROWS)),(0,0,0,0))
A=json.load(open('/home/claude/pod2/crawl_atlas.json'));U=A['units']['chibi'];base=dict(U['idle'])
for i,(name,r,cols) in enumerate(ROWS):
    for j,c in enumerate(cols):sheet.alpha_composite(fr(r,c),(j*128+OX,i*128+64))
    U[name]=dict(base,n=len(cols),x=0,y=i*128)
for k in list(U):
    if k not in dict((n,1) for n,_,_ in ROWS):del U[k]
A['_aimBase']['chibi']=128*len(ROWS)
sheet.save('/home/claude/pod2/crawl_chibi.png');json.dump(A,open('/home/claude/pod2/crawl_atlas.json','w'),separators=(',',':'))
print('sheet',sheet.size,'offset',OX,'rows',[r[0] for r in ROWS])
