import re,time,sys
src=open('/home/claude/pod2/build_site.py').read()
i=src.index('def _notes_tabs');j=src.index('t = t[:a] + _notes_tabs')
exec(src[i:j])
p='/home/claude/pod-rundown/index.html';t=open(p).read()
a=t.index("      <h2>What's new</h2>");b=t.index('    </section>\n  </div>\n</div>\n\n<script>')
t=t[:a]+_notes_tabs(open('/home/claude/pod2/notes.html').read())+t[b:]
t=re.sub(r'crawl\.js\?v=\d+','crawl.js?v=%d'%int(time.time()),t)
open(p,'w').write(t)
