# 0.12.427 (Kyle) 200+ new items: ~70% potions (new P slot) and trinkets, plus the new GODLY red tier.
# Icons come from Kyle's CraftPix packs (liquids recolored into many potions; loot and herbs for trinkets), shrunk to 32px and appended to crawl_gear.png.
import json,random,re,glob,os,colorsys
from PIL import Image,ImageEnhance
random.seed(427)
A='/home/claude/assets'
def pack(d):
  fs=glob.glob(f'{A}/{d}/PNG/without_shadow/*.png');fs.sort(key=lambda x:int(re.findall(r'\d+',os.path.basename(x))[0]));return fs
LIQ,HERB,LOOT,PLANT=pack('LiquidIcons'),pack('AlchemyHerbs'),pack('CurrencyLootIcons'),pack('PlantIcons')
src=open('/home/claude/pod2/crawl_src.js').read();i=src.find('const GEAR_DB=');j=src.find(';\n',i);DB=json.loads(src[i+len('const GEAR_DB='):j])
DB=[d for d in DB if d['id']<311]   # rebuildable: drop anything this script added before
start=len(DB)
def icon(path,hue=0,sat=1.0):
  im=Image.open(path).convert('RGBA');im=im.resize((32,32),Image.LANCZOS)
  if hue or sat!=1:
    px=im.load()
    for y in range(32):
      for x in range(32):
        r,g,b,a=px[x,y]
        if a==0:continue
        h,l,s=colorsys.rgb_to_hls(r/255,g/255,b/255)
        if s>.18:h=(h+hue)%1;s=min(1,s*sat)
        r2,g2,b2=colorsys.hls_to_rgb(h,l,s);px[x,y]=(int(r2*255),int(g2*255),int(b2*255),a)
  return ImageEnhance.Sharpness(im).enhance(1.6)
icons=[]
# ---------------- potions
PT={# key: (mode, base power, base cd, nouns, icon picks)
 'heal':('drink',18,22,['Healing Draught','Mending Tonic','Red Remedy','Bandage Brew','Field Elixir']),
 'regen':('drink',30,28,['Regrowth Brew','Troll Blood','Slow Mend Syrup','Green Tea Tincture']),
 'shield':('drink',20,26,['Ironskin Philter','Bark Tonic','Tin Can Tonic','Shell Brew']),
 'haste':('drink',25,24,['Quickdraw Brew','Jitter Juice','Rocket Cola','Espresso Shot']),
 'rage':('drink',25,26,['Berserker Grog','Bloodrage Ale','Hot Sauce Shot','Angry Juice']),
 'iron':('drink',6,26,['Stoneskin Draught','Gravel Gargle','Plate Polish']),
 'focus':('drink',10,24,['Hawkeye Drops','Clear Mind Tea','Sniper Syrup']),
 'swift':('drink',30,20,['Sprinter Syrup','Fleetfoot Fizz','Track Star Soda']),
 'mana':('drink',25,22,['Blue Fizz','Mana Water','Energy Drink','Battery Acid (Safe)']),
 'cleanse':('drink',8,20,['Antidote','Purifying Salts','Clean Bill Tonic']),
 'vamp':('drink',12,30,['Blood Wine','Leech Liqueur','Crimson Cordial']),
 'fire':('throw',1.2,18,['Firebomb','Dragon Breath Flask','Molotov','Hellfire Jar']),
 'acid':('throw',.8,18,['Acid Flask','Bile Jar','Corrosive Vial']),
 'frost':('throw',.5,20,['Frost Vial','Cold Snap Jar','Ice Water Bomb']),
 'holy':('throw',1.6,26,['Holy Water','Blessed Oil','Church Bottle']),
 'boom':('throw',1.2,20,['Blasting Jelly','Nitro Flask','Shaken Soda Bomb']),
 'stunf':('throw',.4,24,['Thunder Flask','Flashbang Jar','Shock Tonic']),
 'web':('throw',0,24,['Spider Silk Jar','Glue Bomb','Tar Bottle']),
 'mist':('team',10,30,['Mending Mist','Healing Incense','Group Hug Spray']),
 'cheer':('team',15,32,['Rallying Ale','Pep Talk Punch','Victory Mead']),
 'ward':('team',12,34,['Warding Incense','Shield Smoke','Guardian Censer'])}
HUE={'heal':0,'regen':.3,'shield':.12,'haste':.15,'rage':0,'iron':.55,'focus':.5,'swift':.45,'mana':.6,'cleanse':.35,'vamp':.95,'fire':.05,'acid':.25,'frost':.55,'holy':.14,'boom':.08,'stunf':.17,'web':.75,'mist':.32,'cheer':.1,'ward':.62}
PREF=[['Watery','Cloudy','Old','Flat','Expired'],['Plain','Small','Corner Store','Basic',''],['Strong','Brewed','Fresh','Double'],['Potent','Concentrated','Master','Triple'],['Superior','Arcane','Witch\'s','Alchemist\'s'],['Legendary','Ancient','Royal','Sage\'s'],['Mythic','Starborn','Eldritch','Void-Touched'],['Godly']]
GODLY_N={'heal':'Ambrosia of the Red Saint','rage':'Wrath of the Crimson God','fire':'Sunfire Phial','holy':'Tears of the Martyr','mist':'Breath of the Living God','vamp':'Heart\'s Blood Chalice','boom':'Red Star Cocktail','haste':'Quicksilver Sacrament'}
RCNT=[20,28,30,26,20,12,6,5]   # potions per rarity
POW=[.6,.8,1,1.3,1.7,2.2,2.9,3.8]
liq_bottles=[3,10,36,47,16,49,1,6,11,13,14,22,24,30,33,34,40,42,44,46,48,8,9,12,2,4,5]
keys=list(PT.keys());items=[];k=0;used=set()
godly_keys=list(GODLY_N.keys())
for r,c in enumerate(RCNT):
  for n in range(c):
    key=godly_keys[n%len(godly_keys)] if r==7 else keys[(k*7+r*3)%len(keys)];k+=1
    mode,bp,bcd,nouns=PT[key]
    if r==7:name=GODLY_N[key]
    else:
      for tries in range(30):
        p=random.choice(PREF[r]);name=(p+' '+random.choice(nouns)).strip()
        if name not in used:break
    used.add(name)
    pw=round(bp*POW[r],2) if mode!='throw' else round(bp*POW[r],2);cd=round(bcd*(1-.05*r),1)
    st={}
    if r>=4:st[random.choice(['hpPct','luck','enRegen','cdr'])]= {'hpPct':2+r,'luck':2+r,'enRegen':round(.2+.1*r,1),'cdr':1+r//2}
    li=liq_bottles[(k*5)%len(liq_bottles)]
    ic=icon(LIQ[(li-1)%len(LIQ)],hue=HUE[key]+((n%3)-1)*.03,sat=1.25 if r>=5 else 1.0)
    if r==7:
      ic=icon(LIQ[(li-1)%len(LIQ)],hue=0,sat=1.4)
      # godly: a red-gold rim
      px=ic.load()
      for y in range(32):
        for x in range(32):
          if px[x,y][3]>0 and any(0<=x+dx<32 and 0<=y+dy<32 and px[x+dx,y+dy][3]==0 for dx,dy in((1,0),(-1,0),(0,1),(0,-1))):px[x,y]=(255,200,60,255) if (x+y)%3 else (200,20,30,255)
    items.append({'n':name,'s':'P','r':r,'k':'potion','st':st,'p':[],'u':{'e':key,'m':mode,'pw':pw,'cd':cd}});icons.append(ic)
# ---------------- trinkets (loot + herbs)
TN={'ring':'Ring','gem':'Gem','coin':'Coin','key':'Key','amulet':'Amulet','scroll':'Scroll','herb':'Charm'}
LOOT_KIND=['bag','gem','gem','key','herb','scroll','chest','chest','coin','bag','bag','gem','bag','coin','coin','chest','bag','bag','coin','coin','coin','herb','ring','gem','amulet','gem','herb','coin','ring','scroll','gem','gem','orb','cup','gem','coin','gem','ring','ring','scale','scale','scale','herb','gem','ring','amulet','gem','gem']
TRK=[6,10,13,12,10,6,3,4]
STATS=['crit','acc','dmgPct','hpPct','dodge','armor','luck','enRegen','cdr','move','xp','kbRes']
SV={'crit':[1,1,2,3,4,5,6,8],'acc':[2,2,4,6,8,10,12,16],'dmgPct':[2,2,3,5,6,8,10,14],'hpPct':[2,3,4,6,8,10,14,18],'dodge':[1,1,2,3,4,5,6,8],'armor':[1,1,2,2,3,4,5,7],'luck':[2,3,4,6,8,10,12,16],'enRegen':[.2,.3,.4,.5,.6,.8,1,1.4],'cdr':[1,1,2,3,4,5,6,8],'move':[2,2,3,4,5,6,8,10],'xp':[3,4,5,6,8,10,12,15],'kbRes':[3,4,6,8,10,14,18,24]}
TRIG=['crit','hit','taken','low','every5','cast','kill','healOther','dodge','start']
EFF=['haste','heal','dmgbuff','energy','armor','shield','bleed','healTeam','burn','blast','mark','block','stun','move','poison','bloom','banner','gold','chain','root']
PCH=[(3,5),(3,6),(7,10),(9,12),(11,15),(14,19),(18,29),(25,35)];PCH2=[None,None,None,None,None,(8,11),(10,14),(14,18)]
ADJ=[['Chipped','Tarnished','Bent','Cracked'],['Plain','Old','Pocket','Worn'],['Lucky','Polished','Shiny','Sturdy'],['Gleaming','Runed','Hunter\'s','Blessed'],['Arcane','Shadow','Witch\'s','Storm'],['Ancient','Royal','Dragon','Sage\'s'],['Mythic','Starforged','Eldritch','Void'],['Godly']]
GT=['Crown of the Red God','Bloodgold Sigil','Heart of the Crimson Sun','Ember Saint\'s Reliquary']
li=0;herbs=[2,4,7,9,13,14,16,18,21,24,25,30,33,36,43,47]
for r,c in enumerate(TRK):
  for n in range(c):
    use_herb=(n%3==2)
    if use_herb:path=HERB[herbs[(r*5+n)%len(herbs)]-1];kind='herb'
    else:
      idx=(r*11+n*7)%len(LOOT);path=LOOT[idx];kind=LOOT_KIND[idx] if idx<len(LOOT_KIND) else 'gem'
    noun={'herb':'Herb Charm','ring':'Ring','gem':'Gem','coin':'Coin','key':'Key','amulet':'Amulet','scroll':'Scroll','chest':'Lockbox','bag':'Pouch','orb':'Orb','cup':'Chalice','scale':'Scales'}.get(kind,'Trinket')
    if r==7:name=GT[n%len(GT)]
    else:
      for tries in range(30):
        name=random.choice(ADJ[r])+' '+noun
        if name not in used:break
        name=random.choice(ADJ[r])+' '+random.choice(['Lucky','Odd','Little','Bone','Glass','Copper','Silver','Gold'])+' '+noun
        if name not in used:break
    used.add(name)
    ns=1+(r>=3)+(r>=5)+(r>=7);ks=random.sample(STATS,ns);st={x:SV[x][r] for x in ks}
    p=[{'t':random.choice(TRIG),'e':random.choice(EFF),'lo':PCH[r][0],'hi':PCH[r][1]}]
    if PCH2[r]:p.append({'t':random.choice(TRIG),'e':random.choice(EFF),'lo':PCH2[r][0],'hi':PCH2[r][1]})
    if r==7:p.append({'t':'cast','e':random.choice(['healTeam','banner','blastSelf']),'lo':12,'hi':16})
    ic=icon(path,sat=1.3 if r>=5 else 1)
    if r==7:
      px=ic.load()
      for y in range(32):
        for x in range(32):
          if px[x,y][3]>0 and any(0<=x+dx<32 and 0<=y+dy<32 and px[x+dx,y+dy][3]==0 for dx,dy in((1,0),(-1,0),(0,1),(0,-1))):px[x,y]=(255,200,60,255) if (x+y)%3 else (200,20,30,255)
    items.append({'n':name,'s':'T','r':r,'k':'trinket','st':st,'p':p});icons.append(ic)
for n,d in enumerate(items):d['id']=start+n
DB+=items
# sheet: 16 per row, 32px
sh=Image.open('/home/claude/pod2/art_src/items/crawl_gear_base.png').convert('RGBA')
# fix: the 53 Crappy items (ids 258-310) never had icons; each is a beat-up copy of item id-258, so it gets that icon, dulled and grimy
base=Image.new('RGBA',(512,max(sh.height,((311+15)//16)*32)),(0,0,0,0));base.paste(sh,(0,0))
for cid in range(258,311):
  src_id=cid-258;ic=base.crop(((src_id%16)*32,(src_id//16)*32,(src_id%16)*32+32,(src_id//16)*32+32))
  ic=ImageEnhance.Color(ic).enhance(.35);ic=ImageEnhance.Brightness(ic).enhance(.8);px=ic.load()
  for k in range(14):
    x,y=random.randint(6,25),random.randint(6,25)
    if px[x,y][3]>0:px[x,y]=(90,70,45,255)
  base.paste(ic,((cid%16)*32,(cid//16)*32))
sh=base
rows=(len(DB)+15)//16;out=Image.new('RGBA',(512,rows*32),(0,0,0,0));out.paste(sh.crop((0,0,512,min(sh.height,((start+15)//16)*32))),(0,0))
for n,ic in enumerate(icons):i2=start+n;out.paste(ic,((i2%16)*32,(i2//16)*32),ic)
out.save('/home/claude/pod2/crawl_gear.png')
src=src[:i]+'const GEAR_DB='+json.dumps(DB,separators=(',',':'),ensure_ascii=False)+src[j:]
open('/home/claude/pod2/crawl_src.js','w').write(src)
import collections
print('added',len(items),'potions',sum(1 for d in items if d['s']=='P'),'trinkets',sum(1 for d in items if d['s']=='T'),'by rarity',collections.Counter(d['r'] for d in items),'total',len(DB))
