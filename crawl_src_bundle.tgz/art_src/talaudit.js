const A=require('/home/claude/pod2/crawl.js');
const sig=n=>n.parts.map(p=>p.eff?(p.eff.ab?p.eff.ab+':'+Object.keys(p.eff.mul||p.eff.add||{}).join(',')+(p.eff.face?'face':''):'st:'+Object.keys(p.eff.st||{}).filter(k=>k!=='mod').concat(Object.keys((p.eff.st||{}).mod||{})).join(',')):p.tal||p.abil&&'abil'||p.ult&&'ult'||p.pas||'?').filter(x=>!/^st:hpPct$|^st:$/.test(x)||true).join('|');
let dupI=0,dupE=0,out=[];
for(const k of Object.keys(A.TREES)){const T=A.TREES[k];if(!T)continue;const icons={};
  T.forEach((B,bi)=>{const rows={};for(const n of B.nodes){(icons[n.icon]=icons[n.icon]||[]).push(B.name+':'+n.name);(rows[n.row]=rows[n.row]||[]).push(n);}
    for(const [r,L] of Object.entries(rows)){const m={};for(const n of L){const s0=n.parts.filter(p=>p.eff).map(p=>sig({parts:[p]}))[0];if(!s0)continue;(m[s0]=m[s0]||[]).push(n.name);}
      for(const [s0,ns] of Object.entries(m))if(ns.length>1){dupE++;out.push(`EFF ${k} ${B.name} r${r} ${s0}: ${ns.join(' / ')}`);}}});
  for(const [ic,ns] of Object.entries(icons))if(ns.length>1){dupI++;out.push(`ICON ${k} ${ic}: ${ns.join(' / ')}`);}}
console.log('icon dup groups',dupI,'effect dup groups',dupE);console.log(out.join('\n'));
