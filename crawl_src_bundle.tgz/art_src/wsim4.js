const A=require(process.argv[2]);const all=['alchemist','edward','cheez','jp','teeg','knight','soldier','druid','archer','robot','chibi','flannel'];
const N=+process.argv[3]||36;let win=0,tsum=0,heroW={},heroN={};
for(let i=0;i<N;i++){const off=Math.floor(i/12);const team=[all[i%12],all[(i+4+off)%12],all[(i+8+2*off)%12]];const slot=A.newSlot('t');const run=A.newRun(team,slot);run.stage=1;const g=new A.Game({run,slot});
 let t=0;while(!g.over&&t<900){g.step(1/30);t+=1/30;if(!g.alive().length)break;}const w=g.over==='clear';if(w){win++;tsum+=t;}
 for(const k of team){heroN[k]=(heroN[k]||0)+1;heroW[k]=(heroW[k]||0)+(w?1:0);}}
console.log('stage1 wins',win,'/',N,'avg clear time',win?(tsum/win).toFixed(0)+'s':'-');
console.log(Object.keys(heroN).map(k=>k+' '+heroW[k]+'/'+heroN[k]).join('  '));
