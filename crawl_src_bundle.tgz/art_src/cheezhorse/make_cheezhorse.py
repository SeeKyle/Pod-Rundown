# 0.12.452 (Kyle) Cheez on horseback. Horse frames from the Full_Pack horse sheets (brown horse, black saddle) at x2 so the horse
# matches Cheez's sprite density (horse's back ~90% of his height, like a real horse). Cheez's upper body sits in the saddle; his near
# leg is drawn over the horse's side (thigh forward over the flank, knee bent, boot in the stirrup) with his long coat draped over the
# horse, so his legs read as kicked over the horse. The far leg is hidden behind the horse.
# Attack: a big overhead-to-low beam katana chop off the side of the horse (Dynasty Warriors / Mount & Blade style mounted slash),
# with a sweeping green arc. Frame 160x128, horse feet on the bottom edge.
from PIL import Image, ImageDraw
import math
HS='/home/claude/assets/Full_Pack/Full_Pack/Horse_Sprite_Asset/Horses_equipped_bigsaddle/Horse_fullcolor_brown_blacksaddled_bigsaddle.png'
HR='/home/claude/assets/Full_Pack/Full_Pack/Horse_Sprite_Rearing_Asset/Only_Horse/Horses_equiped_bigsaddle/Horse_fullcolor_brown_blacksaddled_bigsaddle_rearing.png'
CZ='/home/claude/pod2/crawl_cheez.png'
horse=Image.open(HS).convert('RGBA');rear=Image.open(HR).convert('RGBA');cz=Image.open(CZ).convert('RGBA')
FW,FH=160,160   # 32px of headroom over the horse for the raised blade
PL=(30,32,46);PLL=(58,62,82);PLD=(18,18,28);NEON=(130,255,70);CYAN=(58,240,255)
def coat(p):r,g,b,a=p;return a>0 and r>=40 and r>g>=b and g>=15 and r-b>=20
def armor(hf):
  # (Kyle) neon-dynasty barding: lacquered plates on the face (chamfron), neck (crinet), chest (peytral) and rump (crupper),
  # lamellar rows, neon-green trim along each plate's lower edge and cyan studs. Only the coat is painted: eyes, mane, tail, legs stay.
  hf=hf.copy();px=hf.load();bb=hf.getbbox();x0,y0,x1,y1=bb
  S=[(x,y) for y in range(15,48) for x in range(15,55) if px[x,y][3] and 28<=max(px[x,y][:3])<90 and max(px[x,y][:3])-min(px[x,y][:3])<8]
  sx0=min(p[0] for p in S);sx1=max(p[0] for p in S)
  def ctop(x):
    for y in range(64):
      if coat(px[x,y]):return y
    return None
  hx0=x1-12
  zones=[(sx0-12,sx0-1,6),(sx1+1,hx0-1,7),(hx0,x1-2,4)]
  for k,(a,b,dep) in enumerate(zones):
    for x in range(max(0,a),min(80,b+1)):
      t=ctop(x)
      if t is None:continue
      col=[]
      for y in range(t,min(64,t+dep)):
        if not coat(px[x,y]):break
        col.append(y)
      if len(col)<2:continue
      for i,y in enumerate(col):px[x,y]=(PLL if i==0 else (PLD if (y-t)%3==2 else PL))+(255,)
      yb=col[-1]+1
      if yb<64 and px[x,yb][3]:px[x,yb]=NEON+(255,)
      if x%3==0:px[x,col[min(2,len(col)-1)]]=CYAN+(255,)
  return hf
def hframe(r,c):return armor(horse.crop((c*80,r*64,c*80+80,r*64+64)))
def czf(y,c):return cz.crop((c*96,y,c*96+96,y+96))
def seat(hf):
  px=hf.load();S=[(x,y) for y in range(15,48) for x in range(15,55) if px[x,y][3] and 28<=max(px[x,y][:3])<90 and max(px[x,y][:3])-min(px[x,y][:3])<8]
  cx=sum(p[0] for p in S)/len(S);top=min(p[1] for p in S if abs(p[0]-cx)<4)
  st=[(x,y) for y in range(top+4,64) for x in range(10,60) if px[x,y][3] and min(px[x,y][:3])>150]
  if st:
    lo=max(p[1] for p in st);bot=[p for p in st if p[1]>=lo-2];sx=sum(p[0] for p in bot)/len(bot);sy=lo-1   # foot goes in the bottom of the stirrup
  else:sx,sy=cx,top+16
  return cx,top,sx,sy
def belt(f):
  px=f.load();bb=f.getbbox();hair=[x for x in range(96) for y in range(bb[1],bb[1]+4) if px[x,y][3]];hx=sum(hair)/len(hair)
  best=None
  for y in range(40,78):
    n=sum(1 for x in range(int(hx)-9,int(hx)+9) if px[x,y][3] and px[x,y][1]>170 and px[x,y][0]<170)
    if n>=4 and (best is None or n>best[1]):best=(y,n)
  return hx,(best[0] if best else 52)
# Cheez's colours
ROBE=(26,32,46);ROBE2=(40,50,68);ROBED=(14,18,28);DOT=(90,220,240);BOOT=(140,240,60);BOOTD=(70,150,30);SKIN=(214,160,120)
def upper(f,lean=0):
  hx,by=belt(f);u=f.crop((0,0,96,by+2));c=Image.new('RGBA',(96,96),(0,0,0,0));c.paste(u,(0,0))
  if lean:c=c.rotate(lean,resample=Image.NEAREST,center=(hx,by))
  return c,hx,by
def leg(img,H,F):
  # (Kyle) detailed riding leg: coat draped over the horse's side with folds and a neon hem, thigh forward over the flank,
  # bent knee, shin down to a neon sneaker in the stirrup. Shaded like his coat: light along the top, shadow underneath,
  # dark outline, fold creases and his cyan dots.
  K=(H[0]+13,H[1]+10)
  m=Image.new('L',img.size,0);md=ImageDraw.Draw(m)
  md.line([H,K],fill=255,width=10);md.line([K,(F[0]+1,F[1]-3)],fill=255,width=7);md.ellipse([K[0]-5,K[1]-5,K[0]+5,K[1]+5],fill=255)
  dr=Image.new('L',img.size,0);dd=ImageDraw.Draw(dr)
  dd.polygon([(H[0]-9,H[1]-3),(H[0]+5,H[1]-3),(K[0]+1,K[1]+6),(H[0]+3,H[1]+25),(H[0]-12,H[1]+21)],fill=255)
  px=img.load();M=m.load();D=dr.load();W,Hh=img.size
  def inn(L,x,y):return 0<=x<W and 0<=y<Hh and L[x,y]>0
  # the draped coat tail (behind the leg)
  for y in range(Hh):
    for x in range(W):
      if D[x,y] and not M[x,y]:
        if not inn(D,x,y+1):c=NEON          # neon hem
        elif not inn(D,x-1,y) or not inn(D,x,y-1):c=(10,12,20)
        else:c=ROBED if (x+y//3)%5 else (32,40,58)   # vertical folds
        if c!=NEON and (x*7+y*13)%37==0:c=DOT
        px[x,y]=c+(255,)
  # the leg
  for y in range(Hh):
    for x in range(W):
      if not M[x,y]:continue
      if not inn(M,x,y-1):c=(62,76,100)                 # light along the top of the thigh/shin
      elif not inn(M,x,y-2):c=ROBE2
      elif not inn(M,x,y+1) or not inn(M,x+1,y) and y>K[1]:c=(12,14,24)   # shadow underside
      else:c=ROBE
      if (x*5+y*11)%29==0:c=DOT
      px[x,y]=c+(255,)
  for y in range(Hh):                                    # outline
    for x in range(W):
      if not M[x,y] and not D[x,y] and any(inn(M,x+dx,y+dy) for dx,dy in ((1,0),(-1,0),(0,1),(0,-1))):px[x,y]=(6,8,14,255)
  for t in (.35,.6):                                     # fold creases along the thigh and behind the knee
    cx,cy=round(H[0]+(K[0]-H[0])*t),round(H[1]+(K[1]-H[1])*t)
    for k in range(3):
      if inn(M,cx-k,cy+k):px[cx-k,cy+k]=(14,16,26,255)
  for k in range(3):
    if inn(M,K[0]-3+k,K[1]+3+k):px[K[0]-3+k,K[1]+3+k]=(14,16,26,255)
  px[K[0]+2,K[1]-3]=(90,110,140,255);px[K[0]+3,K[1]-2]=(90,110,140,255)   # knee shine
  # neon sneaker in the stirrup
  SN=[".OOOOOO...",
      "OGGgGgGOO.",
      "OGGGGGGGGO",
      "OWWWWWWWWO",
      ".OOOOOOOO."]
  C={'O':(10,20,8),'G':BOOT,'g':(30,60,20),'W':(235,240,230)}
  bx,by=F[0]-4,F[1]-3
  for ry,row in enumerate(SN):
    for rx,ch in enumerate(row):
      if ch!='.' and 0<=bx+rx<W and 0<=by+ry<Hh:px[bx+rx,by+ry]=C[ch]+(255,)
def sword(img,sh,ang,glow=1):
  d=ImageDraw.Draw(img);a=math.radians(ang);ex,ey=sh[0]+14*math.cos(a),sh[1]-14*math.sin(a)
  d.line([sh,(ex,ey)],fill=ROBE,width=5);d.ellipse([ex-2,ey-2,ex+2,ey+2],fill=SKIN)   # sleeve and hand
  tx,ty=ex+36*math.cos(a),ey-36*math.sin(a)
  d.line([(ex,ey),(tx,ty)],fill=(120,255,90,170) if glow else (90,200,70,255),width=4);d.line([(ex,ey),(tx,ty)],fill=(235,255,220,255),width=2)   # beam katana: green glow, white-hot core
  d.line([(ex-2*math.cos(a),ey+2*math.sin(a)),(ex+3*math.cos(a),ey-3*math.sin(a))],fill=(40,40,40,255),width=3)   # hilt
def arc(img,sh,a0,a1,alpha):
  ov=Image.new('RGBA',img.size,(0,0,0,0));d=ImageDraw.Draw(ov)
  for r,w,c in ((48,7,(110,255,80)),(46,3,(230,255,210))):
    d.arc([sh[0]-r,sh[1]-r,sh[0]+r,sh[1]+r],start=-max(a0,a1),end=-min(a0,a1),fill=c+(alpha,),width=w)
  img.alpha_composite(ov)
def rider(hf,up,lean=0,sw=None,arcs=None):
  img=Image.new('RGBA',(FW,FH),(0,0,0,0));img.alpha_composite(hf.resize((160,128),Image.NEAREST),(0,32))
  cx,top,sx,sy=seat(hf);H=(round(cx*2)+1,round(top*2)+3+32);F=(round(sx*2)-1,round(sy*2)+32)
  leg(img,H,F)
  u,hx,by=upper(up,lean);img.alpha_composite(u,(round(H[0]-hx),round(H[1]-by)))
  sh=(round(H[0]+3),round(H[1]-by+ (by-30)))   # near shoulder ~22px above the belt
  sh=(H[0]+2,H[1]-13)   # (Kyle) arm and slash brought down 8px
  if arcs:arc(img,sh,*arcs)
  if sw is not None:sword(img,sh,sw)
  return img
ROWS=[]
idle=[czf(0,i%6) for i in range(9)]
ROWS.append(('idle',[rider(hframe(0,i),idle[i]) for i in range(9)]))
ROWS.append(('walk',[rider(hframe(2,i),idle[i%6]) for i in range(9)]))
ROWS.append(('run',[rider(hframe(4,i),idle[i%6],lean=-8) for i in range(6)]))
# the big chop: raise the blade high behind the head, then bring it down hard past the horse's shoulder
A=[(0,-6,125,None),(1,-4,150,(125,150,90)),(2,-10,60,(150,60,200)),(3,-16,-20,(150,-20,230)),(4,-12,-55,(60,-55,150)),(5,-6,-40,None)]
ROWS.append(('melee',[rider(hframe(4,c),czf(0,0),lean=l,sw=s,arcs=a) for c,l,s,a in A]))
ROWS.append(('hurt',[rider(hframe(0,0),czf(672,i)) for i in range(2)]))
def pad(im):c=Image.new('RGBA',(FW,FH),(0,0,0,0));c.alpha_composite(im,(0,32));return c
ROWS.append(('horse_run',[pad(hframe(4,i).resize((160,128),Image.NEAREST)) for i in range(6)]))
rr=[];
for i in range(12):
  f=rear.crop((i*88,0,i*88+88,66));c=Image.new('RGBA',(80,64),(0,0,0,0));c.alpha_composite(f.crop((4,2,84,66)));c=armor(c);rr.append(pad(c.resize((160,128),Image.NEAREST)))
ROWS.append(('horse_rear',rr))
W=max(len(f) for _,f in ROWS)
sheet=Image.new('RGBA',(W*FW,len(ROWS)*FH),(0,0,0,0))
for r,(n,fr) in enumerate(ROWS):
  for i,f in enumerate(fr):sheet.paste(f,(i*FW,r*FH))
sheet.save('/home/claude/pod2/crawl_cheezhorse.png')
print(sheet.size,[(n,len(f)) for n,f in ROWS])
