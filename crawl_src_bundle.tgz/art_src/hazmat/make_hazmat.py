# 0.12.402 (Kyle) Hazmat zombie: from the free hazmat-suit sheet Kyle sent (same site as the warrior), cut out, made bloodier,
# shrunk back to its pixel size and laid out in 128x128 frames with the feet at x=64, bottom.
import random,json
from PIL import Image
im=Image.open('/home/claude/pod2/art_src/hazmat/hazmat_src.png').convert('RGBA');W,H=im.size;px=im.load();bg=px[5,5][:3]
def isfg(x,y):return sum(abs(px[x,y][i]-bg[i]) for i in range(3))>30
ROWS=[('idle',56,210),('walk',294,442),('attack',510,658),('hurt',726,874),('death',940,1083)]
SC=4   # the sheet is drawn at 4x
out={}
for name,y0,y1 in ROWS:
    segs=[];inb=False
    for x in range(240,W):
        on=any(isfg(x,y) for y in range(y0,y1,2))
        if on and not inb:a=x;inb=True
        if not on and inb:
            if segs and a-segs[-1][1]<28:segs[-1]=(segs[-1][0],x)
            else:segs.append((a,x))
            inb=False
    frames=[]
    for a,b in segs:
        if b-a<20:continue
        f=Image.new('RGBA',(b-a,y1-y0));fp=f.load()
        for y in range(y0,y1):
            for x in range(a,b):
                if isfg(x,y):fp[x-a,y-y0]=px[x,y]
        frames.append(f.resize(((b-a)//SC,(y1-y0)//SC),Image.NEAREST))
    out[name]=frames
# blood: dark red stains on the yellow suit, a few drips; same spots every frame of a row so it doesn't flicker
rng=random.Random(7)
spots=[(rng.uniform(.25,.75),rng.uniform(.3,.85),rng.choice([0,0,1])) for _ in range(6)]
def bloody(f):
    bb=f.getbbox();p=f.load()
    if not bb:return f
    x0,y0,x1,y1=bb
    for sx,sy,r in spots:
        cx=int(x0+sx*(x1-x0));cy=int(y0+sy*(y1-y0))
        for dx in range(-r,r+1):
            for dy in range(-r,r+2):
                x,y=cx+dx,cy+dy
                if 0<=x<f.width and 0<=y<f.height:
                    c=p[x,y]
                    if c[3] and c[0]>150 and c[1]>100:p[x,y]=(130,18,22,255) if (dx+dy)%2==0 else (96,12,16,255)
    return f
sheet=Image.new('RGBA',(64*8,64*5),(0,0,0,0));A={}
for i,(name,_,_) in enumerate(ROWS):
    fr=[bloody(f) for f in out[name]]
    for j,f in enumerate(fr):
        bb=f.getbbox();f=f.crop((0,0,f.width,bb[3]))
        g=f
        sheet.alpha_composite(g,(j*64+32-g.width//2,i*64+63-g.height))
    A[name]=len(fr)
sheet.save('/home/claude/pod2/crawl_hazmat.png');print(A,sheet.size)
json.dump(A,open('/home/claude/pod2/art_src/hazmat/counts.json','w'))

# atlas: drawn the size of a regular zombie (the suit is ~36px tall here, a zombie ~46)
At=json.load(open('/home/claude/pod2/crawl_atlas.json'))
base=dict(fw=64,fh=64,ax=32,ay=63,img='hazmat',pre=.69)
At['units']['hazmat']={'walk':dict(base,n=A['walk'],x=0,y=64),'atk':dict(base,n=A['attack'],x=0,y=128),'idle':dict(base,n=A['idle'],x=0,y=0),
  'hurt':dict(base,n=A['hurt'],x=0,y=192),'die':dict(base,n=A['death'],x=0,y=256,pre=.69)}
json.dump(At,open('/home/claude/pod2/crawl_atlas.json','w'),separators=(',',':'))
