# 0.12.489 (Kyle) BROOD_BOT: an original pixel-art robot on tank treads that builds and launches spider-bots.
# Drawn from scratch here with simple shapes (no reference image was copied, traced or recolored; Kyle's refs were only
# used for the general idea: a yellow tread robot with a visor head, and dark little spider-bots with a green eye).
from PIL import Image, ImageDraw
import json, math
FW,FH=112,100; AX,AY=52,97
Y1=(240,190,40,255);Y2=(200,150,28,255);Y3=(150,104,22,255);YL=(255,226,120,255)
G0=(22,22,28,255);G1=(44,44,52,255);G2=(74,74,84,255);G3=(112,112,124,255);G4=(160,160,172,255)
VIS=(16,16,22,255);EYE=(90,240,255,255);EYEd=(40,150,200,255);ORA=(255,140,30,255);RED=(230,60,40,255);WH=(240,240,230,255)
SPG=(54,58,66,255);SPG2=(86,92,102,255);SPD=(28,30,36,255);GRN=(90,255,140,255);GRNd=(30,160,80,255)
def R(d,x0,y0,x1,y1,c):d.rectangle([x0,y0,x1,y1],fill=c)
def treads(d,ox,oy,ph):
  # tread belt, 64 wide, 20 tall, rounded ends
  x0,x1,y0,y1=ox-32,ox+32,oy-20,oy
  d.rounded_rectangle([x0,y0,x1,y1],radius=9,fill=G0)
  d.rounded_rectangle([x0+2,y0+2,x1-2,y1-2],radius=7,fill=G1)
  for i in range(-1,14):                                    # tread teeth (scroll with ph)
    tx=x0+4+((i*5+ph)%62)
    if x0+5<tx<x1-5:R(d,tx,y0,tx+1,y0+1,G2);R(d,tx,y1-1,tx+1,y1,G2)
  for wx in (x0+10,ox-6,ox+6,x1-10):                       # road wheels
    d.ellipse([wx-5,y0+5,wx+5,y0+15],fill=G2);d.ellipse([wx-2,y0+8,wx+2,y0+12],fill=G4)
    a=ph*.5;R(d,int(wx+math.cos(a)*3),int(y0+10+math.sin(a)*3),int(wx+math.cos(a)*3),int(y0+10+math.sin(a)*3),G1)
  R(d,x0+8,y0+3,x1-8,y0+3,G3)
def body(d,ox,oy,hatch=0):
  # chassis box on the treads
  x0,x1,y0,y1=ox-24,ox+20,oy-48,oy-20
  R(d,x0,y0,x1,y1,Y2);R(d,x0,y0,x1,y0+3,YL);R(d,x0+2,y0+4,x1-2,y1-8,Y1);R(d,x0,y1-6,x1,y1,Y3)
  for i in range(0,44,6):d.polygon([(x0+i,y1-6),(x0+i+3,y1-6),(x0+i+6,y1),(x0+i+3,y1)],fill=G0)   # hazard stripe
  for (rx,ry) in ((x0+3,y0+6),(x1-3,y0+6),(x0+3,y1-10),(x1-3,y1-10)):R(d,rx,ry,rx,ry,Y3)
  R(d,x1-14,y0+8,x1-5,y0+14,G1);R(d,x1-13,y0+9,x1-6,y0+13,EYEd);R(d,x1-12,y0+10,x1-10,y0+10,EYE)   # chest panel light
  # spider-bot bay on the back
  bx0,by0=x0-9,y0+2
  R(d,bx0,by0,x0,by0+22,G1);R(d,bx0+1,by0+1,x0-1,by0+21,G2)
  if hatch:
    R(d,bx0-3-hatch*2,by0-2,bx0+6,by0,G3)                # lid flips up
  else:R(d,bx0,by0,x0,by0+1,G3)
  R(d,bx0+3,by0+18,bx0+5,by0+19,ORA)
def head(d,ox,oy,blink=0,tilt=0,drop=0):
  hx,hy=ox-2+tilt,oy-74+drop
  R(d,hx-2,oy-50+drop//2,hx+4,oy-47,G3)                    # neck piston
  R(d,hx-1,hy+20,hx+3,oy-50+drop//2,G2)
  d.rounded_rectangle([hx-15,hy,hx+17,hy+22],radius=9,fill=Y2)
  d.rounded_rectangle([hx-14,hy+1,hx+16,hy+18],radius=8,fill=Y1)
  R(d,hx-10,hy+2,hx+8,hy+3,YL)
  d.rounded_rectangle([hx-4,hy+6,hx+19,hy+15],radius=4,fill=VIS)     # visor sticks out the front
  if not blink:R(d,hx+11,hy+9,hx+15,hy+12,EYE);R(d,hx+12,hy+10,hx+13,hy+10,WH)
  else:R(d,hx+11,hy+11,hx+15,hy+11,EYEd)
  d.ellipse([hx-17,hy+7,hx-9,hy+15],fill=G2);d.ellipse([hx-15,hy+9,hx-11,hy+13],fill=G4)  # ear bolt
  R(d,hx-4,hy-7,hx-3,hy,G3);R(d,hx-5,hy-9,hx-2,hy-7,RED)                                 # antenna
def gun_arm(d,ox,oy,recoil=0,flash=0):
  sx,sy=ox+14,oy-38
  d.ellipse([sx-5,sy-5,sx+5,sy+5],fill=G2);R(d,sx-1,sy-1,sx+1,sy+1,G4)
  R(d,sx+2-recoil,sy-2,sx+16-recoil,sy+3,G1);R(d,sx+2-recoil,sy-2,sx+16-recoil,sy-2,G3)   # forearm
  R(d,sx+16-recoil,sy-4,sx+30-recoil,sy+2,G0);R(d,sx+16-recoil,sy-4,sx+30-recoil,sy-3,G3)  # rivet gun barrel
  R(d,sx+18-recoil,sy+3,sx+22-recoil,sy+6,Y3);R(d,sx+24-recoil,sy-6,sx+27-recoil,sy-4,ORA)
  if flash:
    d.polygon([(sx+31,sy-1),(sx+38,sy-6),(sx+36,sy-1),(sx+42,sy-1),(sx+36,sy+1),(sx+38,sy+5)],fill=(255,220,90,255));R(d,sx+31,sy-2,sx+35,sy,WH)
  return (sx+30-recoil-AX, AY-(sy-1))
def claw_arm(d,ox,oy,ang):
  """claw arm on his shoulder; ang 0 = hanging back, .5 = raised overhead, 1 = slammed forward"""
  sx,sy=ox-6,oy-42
  a=math.radians(230-240*ang)
  ex,ey=sx+math.cos(a)*16,sy-math.sin(a)*16
  d.line([(sx,sy),(ex,ey)],fill=G1,width=5);d.line([(sx,sy),(ex,ey)],fill=G3,width=1)
  d.ellipse([sx-5,sy-5,sx+5,sy+5],fill=G2);d.ellipse([sx-2,sy-2,sx+2,sy+2],fill=G4)
  tx,ty=ex+math.cos(a)*13,ey-math.sin(a)*13
  d.line([(ex,ey),(tx,ty)],fill=G2,width=4)
  for sg in (-.7,.7):
    c=a+sg;d.line([(tx,ty),(tx+math.cos(c)*8,ty-math.sin(c)*8)],fill=G4,width=2)
  d.ellipse([ex-3,ey-3,ex+3,ey+3],fill=Y3)
def robot(ph=0,bob=0,claw=0,recoil=0,flash=0,hatch=0,blink=0,tilt=0,drop=0,smoke=0,dead=0):
  im=Image.new('RGBA',(FW,FH));d=ImageDraw.Draw(im);ox,oy=AX,AY
  if claw<.3:claw_arm(d,ox,oy+bob,claw)
  treads(d,ox,oy,ph)
  body(d,ox,oy+bob,hatch)
  if drop<30:head(d,ox,oy+bob,blink,tilt,drop)
  mz=gun_arm(d,ox,oy+bob,recoil,flash)
  if claw>=.3:claw_arm(d,ox,oy+bob,claw)
  if dead:
    head(d,ox+22,oy+bob+34,1,0,0)                          # head knocked off, lying beside him
  if smoke:
    for i in range(smoke):
      sx=ox-6+(i*7)%18;sy=oy-58-i*6;r=3+i
      d.ellipse([sx-r,sy-r,sx+r,sy+r],fill=(70,70,76,200-i*25))
  return im,mz
FR={}
FR['idle']=[robot(blink=0)[0],robot(bob=1)[0],robot(bob=1,blink=1)[0],robot()[0]]
FR['walk']=[robot(ph=i*3,bob=(i%2))[0] for i in range(6)]
FR['run']=FR['walk']
FR['melee']=[robot(claw=c,tilt=t)[0] for c,t in ((0,0),(.35,-1),(.8,1),(1,2),(.5,1))]
r0,mz=robot(recoil=0);FR['ranged']=[r0,robot(recoil=2,flash=1)[0],robot(recoil=1)[0]]
FR['throw']=[robot(hatch=h)[0] for h in (0,1,2,2,1)]
FR['hurt']=[robot(tilt=-2,bob=1)[0],robot(tilt=-1)[0]]
FR['death']=[robot(tilt=-2,smoke=2)[0],robot(tilt=-3,smoke=3,bob=2)[0],robot(drop=40,dead=1,smoke=4,bob=3)[0],robot(drop=40,dead=1,smoke=2,bob=4)[0]]
# spider-bot: 4 frames skitter, 1 frame lunge, made 2x so it stays crisp; 24x16
SW,SH=24,16
def spider(f,lunge=0,lit=0):
  im=Image.new('RGBA',(SW,SH));d=ImageDraw.Draw(im);cx,cy=12+lunge,7-lunge//2
  legs=[(-1,7,11,0),(-1,4,6,1),(1,4,6,0),(1,7,11,1)]          # side, knee out, foot out, gait pair
  for side,ko,fo,pair in legs:
    up=2 if (f+pair)%2 else 0
    kx,ky=cx+side*ko,cy-5;fx,fy=cx+side*fo,SH-1-up
    d.line([(cx+side*2,cy),(kx,ky)],fill=SPD,width=1);d.line([(kx,ky),(fx,fy)],fill=SPD,width=1);R(d,kx,ky,kx,ky,SPG2);R(d,fx,fy,fx,fy,G3)
  d.ellipse([cx-6,cy-4,cx+5,cy+3],fill=SPD);d.ellipse([cx-5,cy-3,cx+4,cy+2],fill=SPG);R(d,cx-3,cy-3,cx+1,cy-3,SPG2)
  L=RED if lit else ORA
  R(d,cx-4,cy,cx-3,cy,L);R(d,cx-1,cy+1,cx,cy+1,L)
  d.ellipse([cx+1,cy-3,cx+7,cy+3],fill=G0);d.ellipse([cx+2,cy-2,cx+6,cy+2],fill=(255,90,60,255) if lit else GRNd);R(d,cx+4,cy-1,cx+5,cy,(255,220,120,255) if lit else GRN)
  return im
SP=[spider(i) for i in range(4)]+[spider(0,lunge=2),spider(1,lit=1),spider(0,lit=1)]
ANIM=['idle','walk','run','melee','ranged','throw','hurt','death']
rows=[a for a in ANIM if a!='run']
sheet=Image.new('RGBA',(FW*6,FH*len(rows)+SH))
at={}
for r,nm in enumerate(rows):
  for i,f in enumerate(FR[nm]):sheet.alpha_composite(f,(i*FW,r*FH))
  at[nm]={'fw':FW,'fh':FH,'n':len(FR[nm]),'ax':AX,'ay':AY,'x':0,'y':r*FH,'img':'broodbot','pre':0.55,'faceR':1}
at['run']=dict(at['walk'])
y=FH*len(rows)
for i,f in enumerate(SP):sheet.alpha_composite(f,(i*SW,y))
at['bot']={'fw':SW,'fh':SH,'n':4,'ax':12,'ay':15,'x':0,'y':y,'img':'broodbot','pre':0.55,'faceR':1}
at['botlunge']={'fw':SW,'fh':SH,'n':1,'ax':12,'ay':15,'x':4*SW,'y':y,'img':'broodbot','pre':0.55,'faceR':1}
at['botlit']={'fw':SW,'fh':SH,'n':2,'ax':12,'ay':15,'x':5*SW,'y':y,'img':'broodbot','pre':0.55,'faceR':1}
sheet.save('/home/claude/pod2/crawl_broodbot.png')
a=json.load(open('/home/claude/pod2/crawl_atlas.json'));a['units']['broodbot']=at;json.dump(a,open('/home/claude/pod2/crawl_atlas.json','w'),separators=(',',':'))
print('ok',sheet.size,'muzzle px from anchor',mz)
prev=Image.new('RGBA',sheet.size,(70,70,80,255));prev.alpha_composite(sheet);prev.save('/tmp/w/bb_prev.png')
