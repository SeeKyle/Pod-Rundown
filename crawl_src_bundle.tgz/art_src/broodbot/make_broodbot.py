# 0.12.489 (Kyle) BROOD_BOT: an original pixel-art robot on tank treads that builds and launches spider-bots.
# Drawn from scratch here with simple shapes (no reference image was copied, traced or recolored; Kyle's refs were only
# used for the general idea: a yellow tread robot with a visor head, and dark little spider-bots with a green eye).
from PIL import Image, ImageDraw
import json, math
FW,FH=112,100; AX,AY=52,97
Y1=(88,94,106,255);Y2=(62,66,78,255);Y3=(38,40,50,255);YL=(140,148,160,255)   # 0.12.514 (Kyle) badass: gunmetal armor
HZ=(244,186,30,255);HZd=(170,120,16,255);SCR=(176,184,196,255);EMB=(255,120,40,255)
G0=(22,22,28,255);G1=(44,44,52,255);G2=(74,74,84,255);G3=(112,112,124,255);G4=(160,160,172,255)
VIS=(16,16,22,255);EYE=(90,240,255,255);EYEd=(40,150,200,255);ORA=(255,140,30,255);RED=(230,60,40,255);WH=(240,240,230,255)
SPG=(54,58,66,255);SPG2=(86,92,102,255);SPD=(28,30,36,255);GRN=(90,255,140,255);GRNd=(30,160,80,255)
def R(d,x0,y0,x1,y1,c):d.rectangle([x0,y0,x1,y1],fill=c)
def treads(d,ox,oy,ph):
  # tread belt, 64 wide, 20 tall, rounded ends
  x0,x1,y0,y1=ox-32,ox+32,oy-20,oy
  d.rounded_rectangle([x0,y0,x1,y1],radius=9,fill=G0)
  d.rounded_rectangle([x0+2,y0+2,x1-2,y1-2],radius=7,fill=G1)
  for i in range(-1,14):                                    # tread teeth (scroll with ph)
    tx=x0+4+((i*5+ph)%62)
    if x0+5<tx<x1-5:R(d,tx,y0,tx+1,y0+1,G2);R(d,tx,y1-1,tx+1,y1,G2)
  for wx in (x0+10,ox-6,ox+6,x1-10):                       # road wheels
    d.ellipse([wx-5,y0+5,wx+5,y0+15],fill=G2);d.ellipse([wx-2,y0+8,wx+2,y0+12],fill=G4)
    a=ph*.5;R(d,int(wx+math.cos(a)*3),int(y0+10+math.sin(a)*3),int(wx+math.cos(a)*3),int(y0+10+math.sin(a)*3),G1)
  R(d,x0+8,y0+3,x1-8,y0+3,G3)
def body(d,ox,oy,hatch=0):
  # chassis box on the treads
  x0,x1,y0,y1=ox-24,ox+20,oy-48,oy-20
  R(d,x0,y0,x1,y1,Y2);R(d,x0,y0,x1,y0+3,YL);R(d,x0+2,y0+4,x1-2,y1-8,Y1);R(d,x0,y1-6,x1,y1,Y3)
  R(d,x0,y1-6,x1,y1,HZ)
  for i in range(0,44,6):d.polygon([(x0+i,y1-6),(x0+i+3,y1-6),(x0+i+6,y1),(x0+i+3,y1)],fill=G0)   # hazard stripe
  for (rx,ry) in ((x0+2,y0+5),(x0+10,y0+5),(x0+18,y0+5),(x0+26,y0+5),(x0+34,y0+5),(x1-3,y0+5)):R(d,rx,ry,rx,ry,YL)   # rivets
  d.line([(x0+6,y0+12),(x0+13,y0+17)],fill=SCR);d.line([(x0+9,y0+11),(x0+15,y0+15)],fill=SCR);d.line([(x0+26,y0+18),(x0+31,y0+15)],fill=SCR)   # battle scratches
  for k,ex in enumerate((x0+4,x0+10)):                     # twin exhaust stacks, embers at the lips
    R(d,ex,y0-10-k*3,ex+3,y0,G1);R(d,ex,y0-11-k*3,ex+3,y0-10-k*3,G0);R(d,ex+1,y0-11-k*3,ex+2,y0-11-k*3,EMB)
  d.polygon([(x1-4,y0),(x1+4,y0-3),(x1+3,y0+4)],fill=G1);d.polygon([(x1-2,y0),(x1+3,y0-2),(x1+2,y0+2)],fill=YL)   # shoulder spike
  for (rx,ry) in ((x0+3,y0+6),(x1-3,y0+6),(x0+3,y1-10),(x1-3,y1-10)):R(d,rx,ry,rx,ry,Y3)
  R(d,x1-14,y0+8,x1-5,y0+14,G1);R(d,x1-13,y0+9,x1-6,y0+13,(120,20,16,255));R(d,x1-12,y0+10,x1-10,y0+10,(255,70,40,255))   # chest panel light
  # spider-bot bay on the back
  bx0,by0=x0-9,y0+2
  R(d,bx0,by0,x0,by0+22,G1);R(d,bx0+1,by0+1,x0-1,by0+21,G2)
  if hatch:
    R(d,bx0-3-hatch*2,by0-2,bx0+6,by0,G3)                # lid flips up
  else:R(d,bx0,by0,x0,by0+1,G3)
  R(d,bx0+3,by0+18,bx0+5,by0+19,ORA)
def head(d,ox,oy,blink=0,tilt=0,drop=0):
  hx,hy=ox-2+tilt,oy-74+drop
  R(d,hx-2,oy-50+drop//2,hx+4,oy-47,G3)                    # neck piston
  R(d,hx-1,hy+20,hx+3,oy-50+drop//2,G2)
  helm=[(hx-14,hy+20),(hx-16,hy+8),(hx-8,hy),(hx+10,hy),(hx+19,hy+7),(hx+19,hy+16),(hx+12,hy+21)]   # angular war helmet
  d.polygon(helm,fill=Y3);d.polygon([(x+(1 if x<hx else -1),y+(1 if y<hy+10 else -1)) for x,y in helm],fill=Y2)
  d.polygon([(hx-10,hy+2),(hx+9,hy+2),(hx+16,hy+8),(hx-13,hy+8)],fill=Y1);R(d,hx-8,hy+2,hx+8,hy+2,YL)
  d.polygon([(hx-6,hy+12),(hx+19,hy+9),(hx+19,hy+15),(hx-6,hy+15)],fill=VIS)                         # visor, brow slanting down to the front
  if not blink:d.polygon([(hx+4,hy+12),(hx+18,hy+10),(hx+18,hy+12),(hx+4,hy+13)],fill=(255,50,34,255));R(d,hx+13,hy+11,hx+16,hy+11,(255,200,150,255))   # angry red slit
  else:R(d,hx+4,hy+13,hx+18,hy+13,(120,20,16,255))
  R(d,hx-5,hy+17,hx+12,hy+17,G0)
  for k in range(3):R(d,hx+1+k*4,hy+18,hx+2+k*4,hy+20,G1)                                             # jaw grille
  d.polygon([(hx-8,hy),(hx-12,hy-7),(hx-4,hy)],fill=Y2);d.polygon([(hx+2,hy),(hx+1,hy-8),(hx+7,hy)],fill=Y2)   # horn fins
  R(d,hx-15,hy+10,hx-11,hy+14,HZ);R(d,hx-14,hy+11,hx-12,hy+13,HZd)                                    # hazard ear plate
  R(d,hx-4,hy-7,hx-3,hy,G3);R(d,hx-5,hy-9,hx-2,hy-7,RED)                                               # antenna
def gun_arm(d,ox,oy,recoil=0,flash=0):
  sx,sy=ox+14,oy-38
  d.ellipse([sx-5,sy-5,sx+5,sy+5],fill=G2);R(d,sx-1,sy-1,sx+1,sy+1,G4)
  R(d,sx+2-recoil,sy-2,sx+16-recoil,sy+3,G1);R(d,sx+2-recoil,sy-2,sx+16-recoil,sy-2,G3)   # forearm
  R(d,sx+16-recoil,sy-4,sx+30-recoil,sy+2,G0);R(d,sx+16-recoil,sy-4,sx+30-recoil,sy-3,G3)  # rivet gun barrel
  R(d,sx+18-recoil,sy+3,sx+22-recoil,sy+6,Y3);R(d,sx+24-recoil,sy-6,sx+27-recoil,sy-4,ORA)
  if flash:
    d.polygon([(sx+31,sy-1),(sx+38,sy-6),(sx+36,sy-1),(sx+42,sy-1),(sx+36,sy+1),(sx+38,sy+5)],fill=(255,220,90,255));R(d,sx+31,sy-2,sx+35,sy,WH)
  return (sx+30-recoil-AX, AY-(sy-1))
def claw_arm(d,ox,oy,ang):
  """claw arm on his shoulder; ang 0 = hanging back, .5 = raised overhead, 1 = slammed forward"""
  sx,sy=ox-6,oy-42
  a=math.radians(230-240*ang)
  ex,ey=sx+math.cos(a)*16,sy-math.sin(a)*16
  d.line([(sx,sy),(ex,ey)],fill=G1,width=5);d.line([(sx,sy),(ex,ey)],fill=G3,width=1)
  d.ellipse([sx-5,sy-5,sx+5,sy+5],fill=G2);d.ellipse([sx-2,sy-2,sx+2,sy+2],fill=G4)
  tx,ty=ex+math.cos(a)*13,ey-math.sin(a)*13
  d.line([(ex,ey),(tx,ty)],fill=G2,width=4)
  for sg in (-.7,.7):
    c=a+sg;d.line([(tx,ty),(tx+math.cos(c)*8,ty-math.sin(c)*8)],fill=G4,width=2)
  d.ellipse([ex-3,ey-3,ex+3,ey+3],fill=Y3)
def flag(d,ox,oy,wv):
  """0.12.517 (Kyle) the Dice Boys flag, fastened along the slanted pole like real cloth: the hoist edge runs down the top
  of the pole, the fly end streams back from it, rippling harder and drooping a little the farther it gets from the pole."""
  bx,by=ox-12,oy-50;px,top=ox-25,oy-80
  L=math.hypot(bx-px,by-top);ux,uy=(bx-px)/L,(by-top)/L          # unit vector down the pole
  W,H=17,11
  pix={}
  for j in range(H):                                              # j: along the hoist (down the pole)
    hx,hy=px+ux*(j+1),top+uy*(j+1)
    for i in range(W):                                            # i: out from the pole toward the fly end
      k=i/(W-1);wave=math.sin(wv*1.6-i*.5)*(.3+2.4*k);droop=k*k*2.5
      x=int(round(hx-1-i));y=int(round(hy+wave+droop))
      if j>=H-1-int(k*2.5):continue                               # fly end tapers a touch
      shade=math.cos(wv*1.6-i*.5)                                 # folds: light on the rise, dark in the trough
      c=(112,62,150,255) if shade>.55 else (46,16,68,255) if shade<-.55 else (78,34,112,255)
      if j==0:c=(128,78,168,255)
      pix[(x,y)]=c;pix.setdefault((x,y+1),c)
  for (x,y),c in pix.items():R(d,x,y,x,y,c)
  for j in range(H):                                              # stitched hoist hem against the pole
    R(d,int(round(px+ux*(j+1)))-1,int(round(top+uy*(j+1))),int(round(px+ux*(j+1)))-1,int(round(top+uy*(j+1))),(36,12,52,255))
  i0=7;j0=5;k=i0/(W-1)                                            # the die rides the cloth
  cx=int(round(px+ux*(j0+1)-1-i0));cy=int(round(top+uy*(j0+1)+math.sin(wv*1.6-i0*.5)*(.3+2.4*k)+k*k*2.5))
  R(d,cx-3,cy-3,cx+3,cy+3,(20,10,30,255));R(d,cx-2,cy-2,cx+2,cy+2,(244,240,232,255))
  for (a,b) in ((-1,-1),(1,1),(0,0)):R(d,cx+a,cy+b,cx+a,cy+b,(20,10,30,255))
  d.line([(bx,by),(px,top)],fill=G1,width=2);d.line([(bx,by),(px,top)],fill=G3,width=1);R(d,px-1,top-2,px+1,top,HZ)   # pole over the hem, gold finial
def robot(ph=0,bob=0,claw=0,recoil=0,flash=0,hatch=0,blink=0,tilt=0,drop=0,smoke=0,dead=0,wv=None):
  im=Image.new('RGBA',(FW,FH));d=ImageDraw.Draw(im);ox,oy=AX,AY
  if not dead:flag(d,ox,oy+bob,ph*.35 if wv is None else wv)
  if claw<.3:claw_arm(d,ox,oy+bob,claw)
  treads(d,ox,oy,ph)
  body(d,ox,oy+bob,hatch)
  if drop<30:head(d,ox,oy+bob,blink,tilt,drop)
  mz=gun_arm(d,ox,oy+bob,recoil,flash)
  if claw>=.3:claw_arm(d,ox,oy+bob,claw)
  if dead:
    head(d,ox+22,oy+bob+34,1,0,0)                          # head knocked off, lying beside him
  if smoke:
    for i in range(smoke):
      sx=ox-6+(i*7)%18;sy=oy-58-i*6;r=3+i
      d.ellipse([sx-r,sy-r,sx+r,sy+r],fill=(70,70,76,200-i*25))
  return im,mz
FR={}
FR['idle']=[robot(blink=0,wv=0)[0],robot(bob=1,wv=1)[0],robot(bob=1,blink=1,wv=2)[0],robot(wv=3)[0]]
FR['walk']=[robot(ph=i*3,bob=(i%2),wv=i*4/6*1.5)[0] for i in range(6)]
FR['run']=FR['walk']
FR['melee']=[robot(claw=c,tilt=t)[0] for c,t in ((0,0),(.35,-1),(.8,1),(1,2),(.5,1))]
r0,mz=robot(recoil=0);FR['ranged']=[r0,robot(recoil=2,flash=1)[0],robot(recoil=1)[0]]
FR['throw']=[robot(hatch=h)[0] for h in (0,1,2,2,1)]
FR['hurt']=[robot(tilt=-2,bob=1)[0],robot(tilt=-1)[0]]
FR['death']=[robot(tilt=-2,smoke=2)[0],robot(tilt=-3,smoke=3,bob=2)[0],robot(drop=40,dead=1,smoke=4,bob=3)[0],robot(drop=40,dead=1,smoke=2,bob=4)[0]]
# spider-bot: 4 frames skitter, 1 frame lunge, made 2x so it stays crisp; 24x16
SW,SH=24,16
def spider(f,lunge=0,lit=0):
  """faces RIGHT: small armored head with a cluster of red eyes and mandibles at the front, big plated abdomen at the back"""
  im=Image.new('RGBA',(SW,SH));d=ImageDraw.Draw(im);cx,cy=11+lunge,8-lunge//2
  EY=(255,236,150,255) if lit else (255,50,34,255);EYd=(255,140,40,255) if lit else (150,20,16,255)
  legs=[(-1,7,11,0),(-1,4,7,1),(1,1,4,0),(1,3,8,1)]   # back legs splay behind, front legs tuck under the head
  for side,ko,fo,pair in legs:
    up=2 if (f+pair)%2 else 0
    kx,ky=cx-2+side*ko,cy-6;fx,fy=cx-2+side*fo,SH-1-up
    d.line([(cx-2,cy),(kx,ky)],fill=SPD,width=1);d.line([(kx,ky),(fx,fy)],fill=SPD,width=1)
    R(d,kx,ky-1,kx,ky-1,SPG2);R(d,fx,fy,fx,fy,(200,206,216,255))     # knee spike, steel claw tip
  d.ellipse([cx-9,cy-4,cx+1,cy+3],fill=SPD);d.ellipse([cx-8,cy-3,cx,cy+2],fill=SPG)       # abdomen (back)
  R(d,cx-7,cy-3,cx-2,cy-3,SPG2);R(d,cx-8,cy-1,cx-1,cy-1,SPD);R(d,cx-6,cy+1,cx-5,cy+1,EYd)  # armor plate seams, hazard light
  d.polygon([(cx-6,cy-4),(cx-5,cy-6),(cx-4,cy-4)],fill=SPD)                                 # back spine
  d.ellipse([cx,cy-3,cx+6,cy+2],fill=G0);d.ellipse([cx+1,cy-2,cx+5,cy+1],fill=SPG)         # head (front)
  R(d,cx+3,cy-2,cx+3,cy-2,EY);R(d,cx+5,cy-2,cx+5,cy-2,EY);R(d,cx+4,cy-1,cx+4,cy-1,EY);R(d,cx+5,cy,cx+5,cy,EYd)   # eye cluster
  R(d,cx+6,cy+1,cx+6,cy+2,(200,206,216,255));R(d,cx+5,cy+2,cx+5,cy+3,G3)                                           # little mandibles
  return im
SP=[spider(i) for i in range(4)]+[spider(0,lunge=2),spider(1,lit=1),spider(0,lit=1)]
ANIM=['idle','walk','run','melee','ranged','throw','hurt','death']
rows=[a for a in ANIM if a!='run']
sheet=Image.new('RGBA',(FW*6,FH*len(rows)+SH))
at={}
for r,nm in enumerate(rows):
  for i,f in enumerate(FR[nm]):sheet.alpha_composite(f,(i*FW,r*FH))
  at[nm]={'fw':FW,'fh':FH,'n':len(FR[nm]),'ax':AX,'ay':AY,'x':0,'y':r*FH,'img':'broodbot','pre':0.55,'faceR':1}
at['run']=dict(at['walk'])
y=FH*len(rows)
for i,f in enumerate(SP):sheet.alpha_composite(f,(i*SW,y))
at['bot']={'fw':SW,'fh':SH,'n':4,'ax':12,'ay':15,'x':0,'y':y,'img':'broodbot','pre':0.55,'faceR':1}
at['botlunge']={'fw':SW,'fh':SH,'n':1,'ax':12,'ay':15,'x':4*SW,'y':y,'img':'broodbot','pre':0.55,'faceR':1}
at['botlit']={'fw':SW,'fh':SH,'n':2,'ax':12,'ay':15,'x':5*SW,'y':y,'img':'broodbot','pre':0.55,'faceR':1}
sheet.save('/home/claude/pod2/crawl_broodbot.png')
a=json.load(open('/home/claude/pod2/crawl_atlas.json'));a['units']['broodbot']=at;json.dump(a,open('/home/claude/pod2/crawl_atlas.json','w'),separators=(',',':'))
print('ok',sheet.size,'muzzle px from anchor',mz)
prev=Image.new('RGBA',sheet.size,(70,70,80,255));prev.alpha_composite(sheet);prev.save('/tmp/w/bb_prev.png')
