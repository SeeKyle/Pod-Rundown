from PIL import Image
import sys
src=Image.open('art_src/broodbot/broodbot_unpainted.png').convert('RGBA');im=src.copy();px=im.load();W,H=im.size
MAP={(88,94,106):(200,148,30),(112,112,124):(160,114,26)}
def h(x,y):return ((x%112)*73856093^(y%100)*19349663)&1023
for y in range(min(H,700)):
  for x in range(W):
    r,g,b,a=px[x,y]
    if a<200 or not (47<=y%100<=72):continue   # the hull box only: head, wheels, spikes stay gunmetal
    if 600<=y<700 and x//112>=2 and x%112>=54:continue   # death frames: the fallen head keeps its gunmetal
    c=MAP.get((r,g,b))
    if not c:continue
    k=h(x,y)
    if k<70:continue                      # chipped paint: bare metal shows through
    if k<150:c=tuple(int(v*.82) for v in c)   # grime
    px[x,y]=c+(a,)
out=sys.argv[1] if len(sys.argv)>1 else '/tmp/w/bb_new.png'
im.save(out)
