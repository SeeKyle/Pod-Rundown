#!/bin/bash
# usage: pubfast.sh VER "msg"  (site-data builder files missing from bundle; patches live index.html notes + cache-bust instead)
set -e
cd /home/claude/pod2
sed -i "s/v0\.12\.[0-9]*<\/span><\/span>/v$1<\/span><\/span>/" crawl_ui.js
python3 build_crawl.py >/dev/null && node --check crawl.js
cd /home/claude/pod-rundown && git pull -q --rebase
python3 /tmp/patch_index.py
cp /home/claude/pod2/notes.html /home/claude/pod2/crawl.js /home/claude/pod-rundown/
cd /home/claude/pod2; for f in crawl_*.png crawl_*.mp3 crawl_*.ogg; do [ -e "$f" ] || continue; cmp -s $f /home/claude/pod-rundown/$f || cp $f /home/claude/pod-rundown/; done
cd /home/claude/pod-rundown && git add -A && git commit -q -m "$2

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_01MWfQtYx8bXS25trwJBZRwP" && git push -q https://github.com/SeeKyle/Pod-Rundown.git HEAD && git log --oneline | head -1
