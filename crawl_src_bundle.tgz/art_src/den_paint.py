from PIL import Image,ImageDraw,ImageFilter,ImageChops
import random
random.seed(11)
W,H=512,288;FLOOR=200
im=Image.new('RGB',(W,H),(14,12,20));d=ImageDraw.Draw(im)
fg=Image.new('RGBA',(W,H),(0,0,0,0));f=ImageDraw.Draw(fg)
glow=Image.new('RGB',(W,H),(0,0,0));gd=ImageDraw.Draw(glow)
def noise(dr,box,base,amt=5,step=2):
  x0,y0,x1,y1=box
  for y in range(y0,y1,step):
    for x in range(x0,x1,step):
      v=random.randint(-amt,amt);dr.rectangle([x,y,x+step-1,y+step-1],fill=tuple(max(0,min(255,b+v)) for b in base))
# ceiling, wall
noise(d,(0,0,W,30),(13,11,19),3)
for x0,x1 in [(20,200),(250,490)]:
  d.rectangle([x0,6,x1,16],fill=(26,23,34));d.rectangle([x0,6,x1,7],fill=(38,34,48))
  for x in range(x0+8,x1,30):d.rectangle([x,6,x+1,16],fill=(20,18,28))
d.rectangle([0,22,W,23],fill=(34,28,36));d.rectangle([0,28,W,30],fill=(22,19,30))
noise(d,(0,30,W,FLOOR),(30,28,36),4)
for py in range(30,FLOOR,34):   # cast concrete panels with seams, tone shifts and chipped edges
  for px in range(0,300,50):
    t=random.randint(-5,5);pw=min(50,300-px)
    for yy in range(py+1,min(FLOOR,py+34)):
      for xx in range(px+1,px+pw,2):
        if random.random()<.55:c=im.getpixel((xx,yy));d.rectangle([xx,yy,xx+1,yy],fill=tuple(max(0,min(255,v+t)) for v in c))
    d.line([(px,py),(px+pw,py)],fill=(18,16,22));d.line([(px,py+1),(px+pw,py+1)],fill=(42,40,48))
    d.line([(px,py),(px,min(FLOOR,py+34))],fill=(18,16,22));d.line([(px+1,py),(px+1,min(FLOOR,py+34))],fill=(40,38,46))
    for k in range(3):cx=px+random.randint(2,pw-3);cy=py+random.choice([1,2,31,32]);d.rectangle([cx,cy,cx+random.randint(1,3),cy+1],fill=(20,18,24))
    for k in range(4):d.point((px+random.randint(4,pw-4),py+random.randint(4,30)),fill=(22,20,26))   # bolt holes / pits
# brick bar wall (right)
BX=296
for row,y in enumerate(range(34,FLOOR,6)):
  off=0 if row%2 else 7
  for x in range(BX-off,W,14):
    d.rectangle([max(BX,x),y,x+12,y+4],fill=random.choice([(70,30,32),(62,26,30),(78,34,34),(56,24,28)]))
d.rectangle([BX-3,30,BX,FLOOR],fill=(20,16,24))
# --- left side: boarded window, couch, door
d.rectangle([22,70,70,112],fill=(18,24,44))
for i in range(20):d.point((random.randint(24,68),random.randint(72,110)),fill=random.choice([(200,210,255),(70,80,120),(70,80,120)]))
d.ellipse([56,74,64,82],fill=(220,225,240));d.ellipse([59,74,66,81],fill=(18,24,44))
for y,a in [(78,-3),(92,3),(104,-2)]:
  d.polygon([(19,y),(73,y+a),(73,y+a+6),(19,y+6)],fill=(72,52,36));d.line([(19,y),(73,y+a)],fill=(96,72,50))
d.rectangle([19,67,73,70],fill=(46,36,30));d.rectangle([19,112,73,115],fill=(46,36,30))
# door (heavy steel, framed, clear of the couch)
DX=100
d.rectangle([DX-4,124,DX+28,FLOOR],fill=(34,30,34));d.rectangle([DX-2,126,DX+26,FLOOR],fill=(24,22,26))
d.rectangle([DX,128,DX+24,FLOOR-1],fill=(52,54,60))
for yy in (140,162,184):d.rectangle([DX+2,yy,DX+22,yy+1],fill=(40,42,48))
d.rectangle([DX+2,FLOOR-10,DX+22,FLOOR-2],fill=(64,66,72))
d.rectangle([DX+19,150,DX+21,158],fill=(150,140,110));d.rectangle([DX+19,140,DX+21,142],fill=(120,112,90))
for x in range(DX+2,DX+23,4):d.point((x,130),fill=(80,82,90));d.point((x,FLOOR-12),fill=(80,82,90))
d.rectangle([DX+4,144,DX+20,149],fill=(150,120,40));d.line([(DX+6,146),(DX+18,146)],fill=(40,30,20))
d.rectangle([DX-2,FLOOR,DX+26,FLOOR+1],fill=(150,120,70))
# couch (sized to a ~60px-tall person: seat ~16px, back ~30px, ~84px long)
d.rectangle([4,182,86,200],fill=(58,30,46));d.rectangle([4,170,86,184],fill=(70,36,54));d.rectangle([1,178,9,202],fill=(64,32,50));d.rectangle([81,178,89,202],fill=(64,32,50))
d.line([(44,186),(44,199)],fill=(46,24,38));d.rectangle([14,190,34,193],fill=(84,46,62))
d.rectangle([3,202,7,205],fill=(30,20,26));d.rectangle([83,202,87,205],fill=(30,20,26))
for k in range(12):d.point((random.randint(6,84),random.randint(172,198)),fill=(40,20,32))
# job board
d.rectangle([126,72,206,128],fill=(40,28,20));d.rectangle([129,75,203,125],fill=(104,74,46))
for i in range(160):d.point((random.randint(129,203),random.randint(75,125)),fill=random.choice([(90,62,38),(118,86,54)]))
pins=[];items=[(133,79,'p',(170,60,60)),(151,90,'n',None),(166,78,'p',(60,70,90)),(185,82,'p',(120,90,60)),(134,104,'n',None),(152,108,'p',(70,110,70)),(172,102,'p',(150,130,170)),(189,108,'n',None),(170,91,'d',None)]
for x,y,k,c in items:
  if k=='p':d.rectangle([x,y,x+9,y+11],fill=(220,216,204));d.rectangle([x+1,y+1,x+8,y+7],fill=c);d.ellipse([x+3,y+2,x+6,y+5],fill=(30,26,30))
  elif k=='n':d.rectangle([x,y,x+8,y+8],fill=(232,190,90));[d.line([(x+1,y+2+j*2),(x+7,y+2+j*2)],fill=(150,110,50)) for j in range(3)]
  else:d.rectangle([x,y,x+11,y+8],fill=(200,200,196));[d.line([(x+1,y+2+j*2),(x+10,y+2+j*2)],fill=(110,110,120)) for j in range(3)]
  pins.append((x+4,y))
for a,b in [(0,2),(2,3),(0,4),(4,5),(5,6),(6,3),(2,8),(8,6),(1,8)]:d.line([pins[a],pins[b]],fill=(190,30,36))
for p in pins:d.point(p,fill=(255,60,60))
# shelves + guitar
for sy in (100,124):
  d.rectangle([222,sy,268,sy+2],fill=(70,52,38));x=224
  while x<264:
    k=random.random()
    if k<.45:d.rectangle([x,sy-6,x+3,sy-1],fill=random.choice([(150,150,160),(170,60,50),(60,110,150)]));x+=5
    elif k<.75:d.rectangle([x,sy-8,x+4,sy-1],fill=(60,130,90));d.rectangle([x+1,sy-9,x+3,sy-8],fill=(200,200,200));x+=6
    else:d.rectangle([x,sy-5,x+6,sy-1],fill=(110,90,50));x+=8
d.line([(228,52),(240,70)],fill=(60,44,34),width=2);d.rectangle([225,49,230,53],fill=(40,34,40))
d.ellipse([234,66,248,80],fill=(150,30,44));d.ellipse([238,61,250,73],fill=(150,30,44));d.rectangle([240,70,243,73],fill=(30,26,30));d.line([(228,52),(243,76)],fill=(200,190,170))
# --- the bar: back shelf with bottles, neon sign
d.rectangle([310,112,500,115],fill=(80,58,40));d.rectangle([310,140,500,143],fill=(80,58,40))
for sy in (112,140):
  x=314
  while x<496:
    c=random.choice([(60,140,90),(150,80,40),(120,40,60),(170,150,60),(70,90,160)]);h=random.randint(9,14)
    d.rectangle([x,sy-h,x+3,sy-1],fill=c);d.rectangle([x+1,sy-h-3,x+2,sy-h],fill=c);d.point((x+1,sy-h+2),fill=(230,230,220));x+=random.randint(6,9)
gd.rectangle([310,96,500,146],fill=(30,16,20))
# radio on the back counter end
d.rectangle([470,150,486,166],fill=(48,50,56));d.rectangle([472,152,484,161],fill=(170,110,230));d.line([(484,150),(490,140)],fill=(150,150,160))
gd.ellipse([462,142,494,172],fill=(60,24,90))
NEON1=(255,70,150);NEON2=(170,110,255)
F={'D':[(0,0),(0,10),(4,10),(6,7),(6,3),(4,0),(0,0)],'I':[(2,0),(2,10)],'C':[(6,0),(0,0),(0,10),(6,10)],'E':[(6,0),(0,0),(0,10),(6,10)],'B':[(0,10),(0,0),(5,0),(6,2),(4,5),(6,8),(5,10),(0,10)],'O':[(0,0),(6,0),(6,10),(0,10),(0,0)],'Y':[(0,0),(3,5),(6,0)],'S':[(6,0),(0,0),(0,5),(6,5),(6,10),(0,10)]}
def neon(txt,x,y,col):
  for ch in txt:
    if ch==' ':x+=6;continue
    segs=[F[ch]]
    if ch=='E':segs.append([(0,5),(5,5)])
    if ch=='Y':segs.append([(3,5),(3,10)])
    for sg in segs:
      pts=[(x+a,y+b) for a,b in sg];gd.line(pts,fill=col,width=5);d.line(pts,fill=tuple(min(255,c+90) for c in col),width=1)
    x+=10
neon('DICE BOYS',336,52,NEON1)
# neon die
dx,dy=436,48;gd.rectangle([dx,dy,dx+16,dy+16],outline=NEON2,width=5);d.rectangle([dx,dy,dx+16,dy+16],outline=(220,200,255))
for px,py in [(4,4),(12,12),(8,8),(12,4),(4,12)]:d.rectangle([dx+px-1,dy+py-1,dx+px,dy+py],fill=(230,215,255));gd.ellipse([dx+px-3,dy+py-3,dx+px+3,dy+py+3],fill=NEON2)
d.line([(330,70),(424,70)],fill=(60,50,70))
# purple wall lanterns
for lx,ly in [(46,54),(112,108),(290,90)]:
  d.rectangle([lx-1,ly-5,lx+1,ly-2],fill=(50,44,56));d.rectangle([lx-3,ly-2,lx+3,ly+7],fill=(36,30,44));d.rectangle([lx-1,ly,lx+1,ly+5],fill=(220,140,255))
  gd.ellipse([lx-16,ly-12,lx+16,ly+20],fill=(90,30,120))
# hanging lamp
d.line([(166,30),(166,52)],fill=(40,36,44));d.polygon([(158,52),(174,52),(178,59),(154,59)],fill=(46,42,58));d.rectangle([162,59,170,61],fill=(255,220,120))
# floor
for y in range(FLOOR,H):
  b=int(20+14*(y-FLOOR)/(H-FLOOR))
  for x in range(0,W,2):
    v=random.randint(-4,4);d.rectangle([x,y,x+1,y],fill=(b+v,b-3+v,b+6+v))
d.rectangle([0,FLOOR-1,W,FLOOR],fill=(12,10,16))
for i in range(7):
  x=random.randint(10,480);y=random.randint(FLOOR+8,H-8);pts=[(x,y)]
  for j in range(5):x+=random.randint(3,8);y+=random.randint(-2,2);pts.append((x,y))
  d.line(pts,fill=(14,12,18))
# rug
d.polygon([(110,226),(240,226),(258,256),(92,256)],fill=(52,30,66));d.polygon([(114,229),(236,229),(252,253),(98,253)],outline=(90,56,110))
# small card table + chairs
d.rectangle([196,206,236,210],fill=(92,66,44));d.rectangle([200,210,202,232],fill=(60,42,30));d.rectangle([230,210,232,232],fill=(60,42,30))
for dx2,col in [(202,(230,230,230)),(208,(200,40,50)),(214,(120,60,170))]:d.rectangle([dx2,202,dx2+4,206],fill=col)
d.rectangle([222,203,232,206],fill=(180,160,120))
# mushrooms, cans, paper, floor lantern, crates
for mx,my in [(82,214),(88,217),(78,218),(286,206),(292,208),(504,262)]:
  d.line([(mx,my),(mx,my-3)],fill=(220,200,170));d.pieslice([mx-3,my-6,mx+3,my],180,360,fill=(240,110,60))
  gd.ellipse([mx-7,my-10,mx+7,my+3],fill=(120,50,20))
for cx,cy in [(120,262),(126,266),(270,250),(60,270),(300,276)]:
  d.rectangle([cx,cy-4,cx+2,cy],fill=random.choice([(170,60,50),(150,150,160),(60,110,150)]))
d.polygon([(30,240),(48,237),(52,245),(34,248)],fill=(170,168,156))
d.rectangle([64,226,70,236],fill=(40,36,30));d.rectangle([65,228,69,234],fill=(255,190,90));gd.ellipse([50,214,84,248],fill=(110,70,20))
d.rectangle([258,182,282,FLOOR+4],fill=(60,64,46));d.line([(258,188),(282,188)],fill=(40,44,30))


# ---- DETAIL PASS (Kyle: grimy detail like the alley / bunker references)
import math
def scrawl(x,y,w,h,col,n=5):   # loopy spray tag
  pts=[];cx=x
  for i in range(n*4):
    cx+=w/(n*4);pts.append((cx,y+h/2+math.sin(i*1.7+random.random())*h/2*random.uniform(.5,1)))
  d.line(pts,fill=col,width=1)
  for i in range(n):px=x+i*w/n;d.arc([px,y,px+w/n+2,y+h],random.randint(0,180),random.randint(200,360),fill=col)
for gx,gy,gw,gh,col in [(8,120,40,10,(120,118,128)),(150,140,34,8,(90,130,140)),(206,182,40,9,(140,140,150)),(46,150,24,7,(150,90,110)),(232,40,30,8,(110,110,122)),(160,40,24,7,(100,100,112))]:
  scrawl(gx,gy,gw,gh,col)
# pipes along the wall with brackets, and one dropping to the floor
d.rectangle([0,36,292,39],fill=(52,50,58));d.line([(0,36),(292,36)],fill=(78,76,86));d.line([(0,39),(292,39)],fill=(26,24,30))
for bx in range(14,292,40):d.rectangle([bx,35,bx+3,41],fill=(36,34,40));d.point((bx+1,42),fill=(110,60,30))
d.rectangle([284,39,288,FLOOR],fill=(50,48,56));d.line([(284,39),(284,FLOOR)],fill=(74,72,82))
for jy in (80,140):d.rectangle([283,jy,289,jy+3],fill=(40,38,44))
for k in range(8):x=random.choice([random.randint(0,290),286]);y=random.randint(40,60) if x!=286 else random.randint(60,190);d.line([(x,y),(x,y+random.randint(3,10))],fill=(96,52,28))
# sagging cables from the ceiling
for x0,x1,sag in [(10,120,16),(120,230,10),(250,400,14),(400,505,9)]:
  pts=[(x0+(x1-x0)*t/20,30+sag*math.sin(math.pi*t/20)) for t in range(21)];d.line(pts,fill=(16,14,18),width=1)
# a taped-up map
d.rectangle([222,134,262,160],fill=(150,140,108));d.polygon([(258,134),(262,134),(262,139)],fill=(30,28,36))
for k in range(30):d.point((random.randint(224,260),random.randint(136,158)),fill=random.choice([(110,130,90),(90,110,140),(130,110,80)]))
d.line([(228,140),(240,150),(252,144)],fill=(190,40,40));d.rectangle([222,134,225,136],fill=(210,210,190));d.rectangle([259,157,262,160],fill=(210,210,190))
# floor slabs (perspective) + crack network
for y in (206,216,230,248,270):d.line([(0,y),(W,y)],fill=(16,14,20))
for k in range(-10,22):
  x0=256+k*26;d.line([(256+(x0-256)*.55,FLOOR),(256+(x0-256)*1.6,H)],fill=(17,15,21))
for i in range(14):
  x=random.randint(0,W);y=random.randint(FLOOR+6,H-4);pts=[(x,y)]
  for j in range(random.randint(4,9)):
    x+=random.randint(-6,9);y+=random.randint(-3,4);pts.append((x,y))
    if random.random()<.3:d.line([pts[-1],(x+random.randint(-6,6),y+random.randint(-4,4))],fill=(12,10,14))
  d.line(pts,fill=(11,9,13))
# trash: papers, butts, caps, cans, a pizza box
for i in range(10):
  cx,cy=random.randint(6,500),random.randint(FLOOR+6,H-4);d.polygon([(cx,cy),(cx+6,cy-2),(cx+8,cy+2),(cx+2,cy+4)],fill=random.choice([(150,148,136),(170,160,120),(120,110,96)]))
for i in range(40):
  cx,cy=random.randint(0,W-2),random.randint(FLOOR+4,H-2);d.point((cx,cy),fill=random.choice([(200,190,170),(170,60,40),(150,150,160),(90,70,50)]))
for cx,cy in [(150,270),(330,246),(480,280)]:
  d.rectangle([cx,cy-2,cx+4,cy],fill=random.choice([(170,60,50),(150,150,160)]))
d.polygon([(20,262),(44,258),(48,266),(24,270)],fill=(120,90,60));
# rug
d.polygon([(110,226),(240,226),(258,256),(92,256)],fill=(52,30,66));d.polygon([(114,229),(236,229),(252,253),(98,253)],outline=(90,56,110))
# small card table + chairs
d.rectangle([196,206,236,210],fill=(92,66,44));d.rectangle([200,210,202,232],fill=(60,42,30));d.rectangle([230,210,232,232],fill=(60,42,30))
for dx2,col in [(202,(230,230,230)),(208,(200,40,50)),(214,(120,60,170))]:d.rectangle([dx2,202,dx2+4,206],fill=col)
d.rectangle([222,203,232,206],fill=(180,160,120))

d.line([(22,264),(44,260)],fill=(160,40,30))

# ---- GRIME PASS (Kyle: more realistic and grimy, still pixel art)
gr=Image.new('RGBA',(W,H),(0,0,0,0));g2=ImageDraw.Draw(gr)
for i in range(46):   # water stains streaking down from the ceiling
  x=random.randint(0,W-1);y0=30;L2=random.randint(20,140);w=random.choice([1,1,2,3])
  for y in range(y0,min(FLOOR,y0+L2)):
    a=int(105*(1-(y-y0)/L2));g2.rectangle([x,y,x+w-1,y],fill=(10,8,6,a))
    if random.random()<.04:x+=random.choice([-1,1])
for i in range(14):   # mold / damp blotches
  cx,cy=random.randint(0,W),random.choice([random.randint(34,70),random.randint(160,198)]);r=random.randint(5,14)
  for j in range(r*6):
    a=random.uniform(0,6.28);rr=random.random()*r;x=int(cx+rr*__import__('math').cos(a));y=int(cy+rr*.6*__import__('math').sin(a))
    if 30<y<FLOOR:g2.point((x,y),fill=(24,34,20,random.randint(60,140)))
for y in range(FLOOR-26,FLOOR):   # dirt build-up along the bottom of the walls
  a=int(150*((y-(FLOOR-26))/26)**1.6)
  for x in range(0,W,2):
    if random.random()<.85:g2.rectangle([x,y,x+1,y],fill=(18,14,10,a))
for cx,cy,w2,h2 in [(64,40,22,14),(214,150,16,10),(14,140,12,18)]:   # peeled plaster showing brick
  g2.rectangle([cx,cy,cx+w2,cy+h2],fill=(60,28,28,255))
  for yy in range(cy,cy+h2,4):g2.line([(cx,yy),(cx+w2,yy)],fill=(30,16,18,255))
  for yy in range(cy,cy+h2,8):
    for xx in range(cx+(4 if (yy//4)%2 else 0),cx+w2,9):g2.line([(xx,yy),(xx,yy+3)],fill=(30,16,18,255))
  g2.rectangle([cx-1,cy-1,cx+w2+1,cy+h2+1],outline=(52,48,58,255))
for x0,x1 in [(20,200),(250,490)]:   # rust on the ducts
  for i in range(30):x=random.randint(x0,x1);y=random.randint(8,16);g2.point((x,y),fill=(110,56,30,200));g2.point((x,y+1),fill=(80,40,24,140))
for (cx,cy,dx,dy) in [(0,30,1,1),(W-1,30,-1,1)]:   # cobwebs in the corners
  for k in range(5):g2.line([(cx,cy),(cx+dx*(30-k*5),cy+dy*(k*6))],fill=(150,150,160,70))
  for r in (8,15,22):g2.arc([cx-r,cy-r,cx+r,cy+r],0 if dx>0 else 90,90 if dx>0 else 180,fill=(150,150,160,60))
for i in range(26):   # floor stains
  cx,cy=random.randint(0,W),random.randint(FLOOR+4,H);rw,rh=random.randint(6,26),random.randint(2,6)
  g2.ellipse([cx-rw,cy-rh,cx+rw,cy+rh],fill=(8,6,10,random.randint(40,100)))
# puddle reflecting the neon
g2.ellipse([352,258,432,272],fill=(16,14,26,220));g2.ellipse([362,261,420,269],fill=(120,40,100,120));g2.line([(370,265),(400,265)],fill=(255,120,190,150))
for i in range(300):   # dust specks
  x,y=random.randint(0,W-1),random.randint(30,H-1);g2.point((x,y),fill=(90,84,96,random.randint(30,90)))
im=im.convert('RGBA');im.alpha_composite(gr);im=im.convert('RGB');d=ImageDraw.Draw(im)

# ---- FOREGROUND bar counter (drawn over heroes standing behind it)
BT=176  # bar top
f.rectangle([304,BT,508,BT+5],fill=(110,74,46,255));f.rectangle([304,BT,508,BT],fill=(150,110,70,255))
f.rectangle([308,BT+6,504,222],fill=(62,40,32,255))
for x in range(312,504,24):f.rectangle([x,BT+10,x+19,218],outline=(80,54,40,255))
f.rectangle([304,218,508,224],fill=(40,28,24,255))
for x in range(312,504,8):f.point((x,BT+3),fill=(170,130,90,255))
# glasses on the bar
for gx in (330,372,420,456):
  f.rectangle([gx,BT-6,gx+3,BT-1],fill=(200,220,230,200));f.rectangle([gx+1,BT-4,gx+2,BT-2],fill=(200,150,60,230))
# stools
STOOLS=1
for sx in ():   # (moved below) so heroes can stand in front of them
  d.rectangle([sx-6,226,sx+6,229],fill=(120,40,60));d.line([(sx-6,226),(sx+6,226)],fill=(160,70,90));d.rectangle([sx-1,229,sx+1,252],fill=(70,70,80));d.rectangle([sx-5,252,sx+5,254],fill=(70,70,80));d.ellipse([sx-8,252,sx+8,257],fill=(10,8,12))
for i in range(40):
  x=random.randint(308,504);y=random.randint(BT+8,220);f.point((x,y),fill=(30,20,16,255))
for x in range(310,504,3):
  if random.random()<.5:f.line([(x,214),(x,218)],fill=(28,20,16,255))
# neon reflection strip under the bar top
gd.rectangle([308,BT+6,504,BT+10],fill=(60,20,50))
for sx in (334,398,462):   # bar stools (back layer, so heroes can stand in front of them)
  d.ellipse([sx-8,251,sx+8,257],fill=(10,8,12));d.rectangle([sx-6,226,sx+6,229],fill=(120,40,60));d.line([(sx-6,226),(sx+6,226)],fill=(160,70,90));d.rectangle([sx-1,229,sx+1,252],fill=(70,70,80));d.rectangle([sx-5,252,sx+5,254],fill=(70,70,80))
# ---- lighting
L=Image.new('RGB',(W,H),(0,0,0));ld=ImageDraw.Draw(L)
ld.polygon([(160,61),(172,61),(250,272),(84,272)],fill=(80,62,32));ld.ellipse([100,236,236,292],fill=(60,46,24))
L=L.filter(ImageFilter.GaussianBlur(12));glow=glow.filter(ImageFilter.GaussianBlur(4))
im=ImageChops.add(im,L);im=ImageChops.add(im,glow)
V=Image.new('L',(W,H),0);vd=ImageDraw.Draw(V);vd.ellipse([-90,-70,W+90,H+100],fill=255);V=V.filter(ImageFilter.GaussianBlur(40))
im=Image.composite(im,Image.new('RGB',(W,H),(4,3,8)),V)
# shade the fg with the same vignette
fgs=fg.copy();px=fgs.load();vp=V.load()
for y in range(H):
  for x in range(W):
    r,g,b,a=px[x,y]
    if a:k=.35+.65*vp[x,y]/255;px[x,y]=(int(r*k),int(g*k),int(b*k),a)
im.save('/home/claude/pod2/crawl_denbg.png');fgs.save('/home/claude/pod2/crawl_denfg.png')
comp=im.convert('RGBA');comp.alpha_composite(fgs);comp.resize((W*2,H*2),Image.NEAREST).save('/tmp/w/den/den2.png')
