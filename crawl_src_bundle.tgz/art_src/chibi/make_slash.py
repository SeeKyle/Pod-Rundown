# 0.12.459 (Kyle) Tide_Warrior's sword swing: his arm brings the sword up behind his head, then slashes it DOWN in front of him
# (the move that throws his water wave). Built on his idle body; the old low-held sword, hilt and hand are erased first.
from PIL import Image, ImageDraw
import math
base=Image.open('/home/claude/pod2/art_src/chibi/crawl_chibi_base.png').convert('RGBA')
sheet=base.copy()
LAV=[(183,163,225),(160,140,210),(220,205,250)];COAT=(36,35,38);COAT2=(65,64,68);SKIN=(207,183,168);HILT=(189,68,70)
def body():
  f=base.crop((0,0,128,128));px=f.load()
  for y in range(128):
    for x in range(128):
      r,g,b,a=px[x,y]
      if not a:continue
      lav=b>190 and b>r+20 and b>g+20          # blade and its glow
      red=r>150 and g<100 and y>92              # hilt (the scarf is higher up)
      hand=y>92 and x<70 and abs(r-207)<25 and abs(g-183)<25
      trail=r>200 and g>180 and b>170 and y>90
      if lav or red or hand or trail:px[x,y]=(0,0,0,0)
  return f
B=body()
SH=(80,91)     # his front shoulder
ANG=[100,128,145,112,62,12,-32,-55,-55,-42]
TRAIL={4:(145,62),5:(145,12),6:(112,-32),7:(62,-55)}
def frame(i):
  f=B.copy();d=ImageDraw.Draw(f);a=math.radians(ANG[i])
  ex,ey=SH[0]+12*math.cos(a),SH[1]-12*math.sin(a)
  if i in TRAIL:   # a lavender smear along the blade's path
    a0,a1=TRAIL[i];ov=Image.new('RGBA',f.size,(0,0,0,0));od=ImageDraw.Draw(ov)
    for r,w,c in ((30,6,(183,163,225,90)),(32,2,(235,225,255,170))):od.arc([SH[0]-r,SH[1]-r,SH[0]+r,SH[1]+r],start=-max(a0,a1),end=-min(a0,a1),fill=c,width=w)
    f.alpha_composite(ov);d=ImageDraw.Draw(f)
  d.line([SH,(ex,ey)],fill=COAT,width=5);d.line([SH,(ex,ey)],fill=COAT2,width=2)   # sleeve
  d.ellipse([ex-2,ey-2,ex+2,ey+2],fill=SKIN)                                        # hand
  gx,gy=ex+2*math.cos(a),ey-2*math.sin(a)
  d.line([(gx-3*math.sin(a),gy-3*math.cos(a)),(gx+3*math.sin(a),gy+3*math.cos(a))],fill=HILT,width=2)   # red guard
  tx,ty=ex+24*math.cos(a),ey-24*math.sin(a)
  d.line([(gx,gy),(tx,ty)],fill=LAV[0],width=3);d.line([(gx,gy),(tx,ty)],fill=LAV[2],width=1)   # blade with a bright edge
  return f
for row in (384,512,640):           # attack1, attack2, runatk all get the downward slash
  for i in range(10):
    sheet.paste(Image.new('RGBA',(128,128),(0,0,0,0)),(i*128,row));sheet.alpha_composite(frame(i),(i*128,row))
sheet.save('/home/claude/pod2/crawl_chibi.png')
prev=Image.new('RGBA',(10*64,64),(60,64,80,255))
for i in range(10):prev.alpha_composite(frame(i).crop((40,40,104,104)),(i*64,0))
prev.resize((prev.width*3,prev.height*3),Image.NEAREST).save('/tmp/chslash.png')
fr=[]
for i in list(range(10))*3:
  b=Image.new('RGBA',(96,96),(40,44,60,255));b.alpha_composite(frame(i).crop((16,24,112,120)));fr.append(b.resize((288,288),Image.NEAREST).convert('P',palette=Image.ADAPTIVE,colors=64))
fr[0].save('/home/claude/tide_swing.gif',save_all=True,append_images=fr[1:],duration=[90]*len(fr),loop=0,disposal=2)
