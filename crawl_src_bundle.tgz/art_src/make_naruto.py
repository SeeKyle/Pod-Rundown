"""0.12.394 (Kyle): Leon's Naruto run: lean forward, both arms trailing straight back. Built from his run frames; appended to crawl_kids.png."""
from PIL import Image
import numpy as np,json
IM=Image.open('/home/claude/pod2/crawl_kids.png').convert('RGBA')
if IM.height>312:IM=IM.crop((0,0,IM.width,312))
src=IM.crop((0,208,320,260));out=Image.new('RGBA',(320,52),(0,0,0,0))
for f in range(8):
    fr=np.array(src.crop((f*40,0,f*40+40,52)))
    a=fr[:,:,3]>0;ys=np.where(a.any(1))[0];top,bot=ys.min(),ys.max()
    green=(fr[:,:,1]>110)&(fr[:,:,0]<90)&a
    gy=np.where(green.any(1))[0];t0,t1=gy.min(),gy.max()
    skin=np.array(fr[top+6,:,:3]);sk=None
    for x in range(40):
        c=fr[top+6,x]
        if c[3] and c[0]>200 and c[1]>150:sk=tuple(int(v) for v in c);break
    sk=sk or (232,190,160,255)
    # remove hands hanging at the front/sides of the torso
    for y in range(t0,t1+3):
        for x in range(40):
            c=fr[y,x]
            if c[3] and c[0]>200 and c[1]>150 and c[2]>120:fr[y,x]=(0,0,0,0)
    new=np.zeros_like(fr)
    for y in range(52):
        sh=0 if y>t1 else int(round(2*(t1-y)/max(1,t1-top)))
        for x in range(40):
            if fr[y,x,3] and 0<=x+sh<40:new[y,x+sh]=fr[y,x]
    gx=np.where((new[t0:t1+1,:,3]>0).any(0))[0];lx=gx.min()
    sleeve=tuple(int(v) for v in fr[(t0+t1)//2,np.where(green[(t0+t1)//2])[0][0]]) if green[(t0+t1)//2].any() else (40,120,50,255)
    dark=tuple(max(0,int(v*.7)) if i<3 else 255 for i,v in enumerate(sleeve))
    for arm,dy in ((0,2),(1,4)):
        sx,sy=lx+1,t0+dy
        for i in range(8):
            x=sx-i;y=sy+i//3
            col=sk if i>=6 else (dark if arm else sleeve)
            for t in range(2):
                if 0<=x<40 and 0<=y+t<52:new[y+t,x]=col
            if i<6 and 0<=x<40:new[y-1 if arm==0 else y+2,x]=(18,14,20,255) if False else new[y-1 if arm==0 else y+2,x]
    # outline the new arms
    m=new[:,:,3]>0
    for y in range(1,51):
        for x in range(1,39):
            if not m[y,x] and (m[y-1,x] or m[y+1,x] or m[y,x-1] or m[y,x+1]) and x<lx+1 and t0-1<=y<=t0+8:new[y,x]=(18,14,20,255)
    out.paste(Image.fromarray(new),(f*40,0))
full=Image.new('RGBA',(320,364),(0,0,0,0));full.alpha_composite(IM,(0,0));full.alpha_composite(out,(0,312));full.save('/home/claude/pod2/crawl_kids.png',optimize=True)
A=json.load(open('/home/claude/pod2/crawl_atlas.json'));L=A['units']['kid_leon'];nr=dict(L['run']);nr['y']=312;L['naruto']=nr;json.dump(A,open('/home/claude/pod2/crawl_atlas.json','w'))
pv=Image.new('RGBA',(320,52),(40,40,50,255));pv.alpha_composite(out);pv.resize((1280,208),Image.NEAREST).save('/tmp/naruto.png');print('ok')
