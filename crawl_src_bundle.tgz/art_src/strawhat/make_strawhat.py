# 0.12.521 (Kyle): Tide_Warrior's new body: the straw-hat wanderer from Kyle's two sheets, recolored to the sea.
# The sheets are ~2x upscaled pixel art on flat gray with a little blur, so: key out the background, take each frame at half
# resolution (back to roughly native pixels), and recolor: straw cloak -> sea-green/teal, hat -> weathered pale straw.
import json,colorsys
from PIL import Image
import numpy as np
D='/home/claude/pod2/art_src/new_unit_refs/strawhat/'
SA=np.array(Image.open(D+'strawhat_sheet_a.png').convert('RGB')).astype(float)
SB=np.array(Image.open(D+'strawhat_sheet_b.png').convert('RGB')).astype(float)
BG=np.array([109,116,134.])
ROWS={'idle':(SA,(64,207),6),'walk':(SA,(289,423),8),'run':(SA,(528,655),6),'attack1':(SA,(745,871),6),'attack2':(SA,(960,1079),4),
      'jump':(SB,(40,207),8),'disguise':(SB,(304,423),8),'shot':(SB,(585,655),7),'hurt':(SB,(744,870),2),'dead':(SB,(969,1079),4)}
C=128;AX,AY=64,124
def recolor(r,g,b,yrel):
  h,s,v=colorsys.rgb_to_hsv(r/255,g/255,b/255)
  if v<.16 or not(.02<h<.19) or s<.45:return (r,g,b)              # outline, dark cloth, skin and steel stay
  if yrel<.24:                                                     # the hat: weathered, sun-bleached straw
    s2=s*.62;v2=v*.9;h2=.1
  else:                                                            # the cloak: sea-green straw, deeper in the folds
    h2=.48+(h-.1)*.5;s2=min(1,s*.82);v2=v*.74
  R,G,B=colorsys.hsv_to_rgb(h2,s2,v2);return (int(R*255),int(G*255),int(B*255))
def frame(S,y0,y1,k):
  cx=335+192.2*k;x0=int(cx-128);x1=int(cx+128);yy0=max(0,y1+1-2*C+8)
  crop=S[yy0:y1+1,x0:x1]
  key=(np.abs(crop-BG).sum(2)>42)
  key[:max(0,y0-4-yy0),:]=False                                   # only this row's band (no feet from the row above)
  if x0<255:key[:,:255-x0]=False                                    # never the row label
  h,w=key.shape;h2,w2=h//2,w//2
  im=Image.new('RGBA',(C,C))
  # figure top for the hat/cloak split
  ys=np.nonzero(key.any(1))[0];top=ys.min() if len(ys) else 0;hgt=max(1,h-top)
  for j in range(h2):
    for i in range(w2):
      blk=key[2*j:2*j+2,2*i:2*i+2]
      if blk.sum()<3:continue
      px=crop[2*j:2*j+2,2*i:2*i+2][blk].mean(0)
      # snap toward the darkest pixel in the block for crisp outlines
      dk=crop[2*j:2*j+2,2*i:2*i+2][blk];d=dk[dk.sum(1).argmin()]
      if d.sum()<120:px=d
      c=recolor(*[int(v) for v in px],((2*j)-top)/hgt)
      X=i-(w2//2)+AX;Y=j-h2+AY+1
      if 0<=X<C and 0<=Y<C:im.putpixel((X,Y),c+(255,))
  return im
ANIM=[('idle','idle'),('walk','walk'),('run','run'),('attack1','attack1'),('attack2','attack2'),('runatk','jump'),('hurt','hurt'),('death','dead'),
      ('ranged','attack2'),('rangedUp','attack2'),('rangedDown','attack2'),('disguise','disguise'),('shot','shot'),('jump','jump')]
cache={}
for _,src in ANIM:
  if src in cache:continue
  S,(y0,y1),n=ROWS[src];cache[src]=[frame(S,y0,y1,k) for k in range(n)]
sheet=Image.new('RGBA',(C*8,C*len(ANIM)));at={}
for r,(nm,src) in enumerate(ANIM):
  for i,f in enumerate(cache[src]):sheet.alpha_composite(f,(i*C,r*C))
  at[nm]={'fw':C,'fh':C,'n':len(cache[src]),'ax':AX,'ay':AY+4,'x':0,'y':r*C,'img':'chibi','pre':0.49,'faceR':1,'pk':1.5}
at['death']['fall']=0
for k in at:at[k]['pk']=1.78   # card portrait crop: the whole figure, hat brim to bare feet
sheet.save('/home/claude/pod2/crawl_chibi.png')
A=json.load(open('/home/claude/pod2/crawl_atlas.json'));A['units']['chibi']=at;json.dump(A,open('/home/claude/pod2/crawl_atlas.json','w'),separators=(',',':'))
prev=Image.new('RGBA',sheet.size,(70,76,90,255));prev.alpha_composite(sheet);prev.save('/tmp/w/straw_prev.png')
print('ok',sheet.size,{k:v['n'] for k,v in at.items()})
