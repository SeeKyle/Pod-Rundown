# 0.12.451 (Kyle) Husky sitting tail: the old frames had a thin detached curl floating behind it plus a flat tail on the ground.
# Replace both with one fluffy sickle tail curling up off the hip, like a real husky's.
from PIL import Image
import sys
sh=Image.open(sys.argv[1]).convert('RGBA');px=sh.load()
Y=884   # husky idle (sitting) row
from collections import Counter
TAIL=["...ddd.",
      "..dmmmd",
      ".dm.eem",
      "..d..em",
      ".....em",
      "...dmem",
      "ddmmee.",
      "mmeee..",
      "eee...."]
for f in range(4):
  X=f*62
  fr=[(x,y) for y in range(Y,Y+34) for x in range(X,X+62) if px[x,y][3]>0]
  cols=Counter(px[p][:3] for p in fr if X+20<=p[0]<X+34)
  ranked=sorted(cols,key=lambda c:sum(c))
  dark=ranked[len(ranked)//5];mid=ranked[len(ranked)//2];light=ranked[-2]
  C={'d':dark,'m':mid,'e':light}
  for (x,y) in fr:   # wipe the old tails: everything right of the body's back edge
    if x-X>=36 and y-Y>=14:px[x,y]=(0,0,0,0)
  ax,ay=X+35,Y+31
  for ry,row in enumerate(TAIL):
    for rx,ch in enumerate(row):
      if ch!='.':px[ax+rx,ay-len(TAIL)+1+ry]=C[ch]+(255,)
sh.save(sys.argv[2])
