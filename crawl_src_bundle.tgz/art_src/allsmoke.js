const A=require('/home/claude/pod2/crawl.js');const keys=Object.keys(A.TREES);let err=0;
for(let i=0;i<keys.length;i+=3){const team=keys.slice(i,i+3);const s=A.newSlot('t');
 for(const k of team){const H=s.heroes[k];if(!H)continue;H.lvl=30;H.tk=k;A.treeInit(H);const T=A.TREES[k];for(let bi=0;bi<3;bi++)for(const n of T[bi].nodes)H.tree[n.id]=n.max;}  // everything maxed (illegal but exercises every effect)
 try{const run=A.newRun(team.filter(k=>s.heroes[k]),s);run.stage=6;const g=new A.Game({run,slot:s});let t=0;while(t<90&&!g.over){g.step(1/30);t+=1/30;}console.log(team.join(','),'ok',Math.round(t))}catch(e){err++;console.log(team.join(','),'ERR',e.message)}}
console.log('errors',err);
