# 0.12.395 talent tree backdrops: 9 dark pixel scenes, 96x176 each, in one strip (crawl_talbg.png)
from PIL import Image, ImageDraw
import random, math
W,H=96,176
def grad(d,top,bot):
    for y in range(H):
        t=y/(H-1);d.line([(0,y),(W,y)],fill=tuple(int(top[i]+(bot[i]-top[i])*t) for i in range(3)))
def stars(d,r,n,c=(200,190,230)):
    for _ in range(n):
        x,y=r.randrange(W),r.randrange(H//2);d.point((x,y),fill=c if r.random()<.7 else (255,255,255))
def moon(d,x,y,rad,c=(230,225,190)):
    d.ellipse([x-rad-3,y-rad-3,x+rad+3,y+rad+3],fill=(c[0]//4,c[1]//4,c[2]//3));d.ellipse([x-rad,y-rad,x+rad,y+rad],fill=c)
    d.ellipse([x-rad//2,y-rad//3,x-rad//2+3,y-rad//3+2],fill=(c[0]-30,c[1]-30,c[2]-30))
def hills(d,r,base,amp,c,seed_step=7):
    ph=r.random()*6
    for x in range(W):
        y=int(base+amp*math.sin(x/seed_step+ph)+amp*.5*math.sin(x/3.1+ph*2));d.line([(x,y),(x,H)],fill=c)
def tomb(d,x,y,c):
    d.rectangle([x,y-9,x+6,y],fill=c);d.ellipse([x,y-12,x+6,y-6],fill=c)
def cross(d,x,y,c):
    d.rectangle([x+2,y-12,x+3,y],fill=c);d.rectangle([x,y-9,x+5,y-8],fill=c)
def deadtree(d,r,x,y,h,c):
    d.line([(x,y),(x,y-h)],fill=c,width=2)
    for i in range(5):
        yy=y-h+i*h//6;L=r.randint(4,10)*(1 if i%2 else -1);d.line([(x,yy),(x+L,yy-r.randint(2,6))],fill=c)
def pine(d,x,y,h,c):
    for i in range(h):d.line([(x-(h-i)//3,y-i),(x+(h-i)//3,y-i)],fill=c)
def house(d,x,y,w,h,c,win):
    d.rectangle([x,y-h,x+w,y],fill=c);d.polygon([(x-2,y-h),(x+w//2,y-h-w//2),(x+w+2,y-h)],fill=c)
    d.rectangle([x+3,y-h+4,x+6,y-h+7],fill=win)
def fog(img,y0,y1,c,a):
    o=Image.new('RGBA',img.size,(0,0,0,0));od=ImageDraw.Draw(o)
    for y in range(y0,y1):od.line([(0,y),(W,y)],fill=c+(int(a*(1-abs((y-(y0+y1)/2)/((y1-y0)/2)))),))
    img.alpha_composite(o)
def vignette(img):
    o=Image.new('RGBA',img.size,(0,0,0,0));od=ImageDraw.Draw(o)
    for i in range(14):od.rectangle([i,i,W-1-i,H-1-i],outline=(0,0,0,int(150*(1-i/14))))
    img.alpha_composite(o)
def scene(i):
    r=random.Random(i*31+5);img=Image.new('RGBA',(W,H));d=ImageDraw.Draw(img)
    P=[((38,14,52),(12,6,18)),((10,22,40),(4,8,14)),((14,34,24),(4,10,8)),((44,16,16),(12,4,6)),((18,18,44),(6,6,14)),((40,26,10),(12,8,4)),((12,30,36),(4,10,12)),((30,10,40),(8,4,12)),((24,24,24),(6,6,8))][i]
    grad(d,*P);stars(d,r,40)
    if i in(0,3,4,6,8):moon(d,r.randint(22,74),r.randint(16,34),r.randint(6,10))
    sil=tuple(max(0,c//2-4) for c in P[1]);mid=tuple(min(255,c+10) for c in P[1])
    hills(d,r,120,6,mid);
    if i==0:  # graveyard
        for x in range(4,W,13):(tomb if r.random()<.6 else cross)(d,x+r.randint(-2,2),136+r.randint(-3,3),sil)
        deadtree(d,r,80,140,46,sil)
    elif i==1:  # dead forest
        for x in range(6,W,14):deadtree(d,r,x,150,r.randint(40,70),sil)
    elif i==2:  # pines + lake
        for x in range(0,W,9):pine(d,x,128,r.randint(20,34),sil)
        d.rectangle([0,130,W,H],fill=(10,24,30));[d.line([(r.randrange(W),y),(r.randrange(W),y)],fill=(40,70,80)) for y in range(134,H,6)]
    elif i==3:  # burning skyline
        for x in range(0,W,12):d.rectangle([x,140-r.randint(20,70),x+10,H],fill=sil)
        for _ in range(30):d.point((r.randrange(W),r.randint(60,130)),fill=(255,120,40))
    elif i==4:  # suburb
        for x in range(2,W,30):house(d,x,140,22,18,sil,(220,180,80) if r.random()<.5 else (60,50,40))
        d.line([(0,141),(W,141)],fill=(30,30,40))
        for x in range(0,W,4):d.line([(x,141),(x,136)],fill=sil)
    elif i==5:  # campfire
        for x in range(0,W,10):pine(d,x,120,r.randint(18,30),sil)
        d.polygon([(44,146),(48,128),(52,146)],fill=(255,140,30));d.polygon([(46,146),(48,136),(50,146)],fill=(255,230,120))
        o=Image.new('RGBA',img.size,(0,0,0,0));od=ImageDraw.Draw(o);od.ellipse([18,110,78,170],fill=(255,120,30,40));img.alpha_composite(o);d=ImageDraw.Draw(img)
    elif i==6:  # radio tower
        d.line([(48,40),(36,150)],fill=sil,width=2);d.line([(48,40),(60,150)],fill=sil,width=2)
        for y in range(50,150,12):d.line([(48-(y-40)//9,y),(48+(y-40)//9,y)],fill=sil)
        d.point((48,38),fill=(255,60,60))
    elif i==7:  # crypt arches
        for x in range(0,W,32):d.rectangle([x,40,x+6,H],fill=sil);d.arc([x+3,30,x+35,80],180,360,fill=sil,width=4)
        for _ in range(8):x=r.randrange(W);d.rectangle([x,150,x+1,152],fill=(255,200,90))
    else:  # ruins
        for x in range(0,W,16):d.rectangle([x,150-r.randint(10,50),x+8,H],fill=sil)
    hills(d,r,150,4,sil,5)
    fog(img,118,160,(150,140,190),70);vignette(img);return img
strip=Image.new('RGBA',(W*9,H))
for i in range(9):strip.paste(scene(i),(i*W,0))
strip.save('/home/claude/pod2/crawl_talbg.png');print('ok')
