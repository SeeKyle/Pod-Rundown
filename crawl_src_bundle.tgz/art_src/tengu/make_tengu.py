# 0.12.522 (Kyle) the Karasu-Tengu: a crow-headed swordsman with great black wings, from Kyle's two crow sheets.
# The sheets are ~2x upscaled pixel art with a little blur: key out the gray, take each frame at half resolution.
import json
from PIL import Image
import numpy as np
D='/home/claude/pod2/art_src/new_unit_refs/crow/'
SA=np.array(Image.open(D+'crow_sheet_a.png').convert('RGB')).astype(float)
SB=np.array(Image.open(D+'crow_sheet_b.png').convert('RGB')).astype(float)
BG=np.array([109,116,134.])
# (sheet, band y0..y1 = feet line, frame centres in sheet px)
ROWS={'idle':(SB,(24,207),[315,506,698,894,1087,1274]),
      'walk':(SB,(242,423),[308,500,694,890,1072,1266,1462,1661]),
      'run':(SB,(504,655),[323,530,731,925,1114,1308,1495,1674]),
      'jump':(SB,(658,887),[320,540,734,913,1095,1292,1483,1673]),
      'atk1':(SB,(904,1079),[313,503,697,897,1090,1300]),
      'atk2':(SA,(24,207),[341,528,742,990]),
      'atk3':(SA,(248,423),[333,520,750]),
      'idle2':(SA,(480,655),[323,519,715,907,1098]),
      'hurt':(SA,(696,871),[314,506,707]),
      'dead':(SA,(920,1079),[320,515,711,907,1110,1300])}
C=144;AX,AY=72,138
def frame(S,y0,y1,cx,half=140):
  x0=int(cx-half);x1=int(cx+half);yy0=max(0,y1+1-2*C+4)
  crop=S[yy0:y1+1,x0:x1]
  key=(np.abs(crop-BG).sum(2)>42)
  key[:max(0,y0-4-yy0),:]=False
  if x0<240:key[:,:240-x0]=False
  h,w=key.shape;h2,w2=h//2,w//2
  im=Image.new('RGBA',(C,C))
  for j in range(h2):
    for i in range(w2):
      blk=key[2*j:2*j+2,2*i:2*i+2]
      if blk.sum()<3:continue
      px=crop[2*j:2*j+2,2*i:2*i+2][blk];c=px.mean(0);d=px[px.sum(1).argmin()]
      if d.sum()<110:c=d
      X=i-(w2//2)+AX;Y=j-h2+AY+1
      if 0<=X<C and 0<=Y<C:im.putpixel((X,Y),tuple(int(v) for v in c)+(255,))
  # keep only this frame's own figure: the biggest connected piece plus anything big joined to it (drops neighbours' wingtips and beaks)
  from scipy import ndimage
  al=np.array(im)[:,:,3]>0;lab,n=ndimage.label(al,structure=np.ones((3,3)))
  if n>1:
    sizes=ndimage.sum(al,lab,range(1,n+1));big=sizes.max();keep=[i+1 for i,z in enumerate(sizes) if z>=big*.3]
    arr=np.array(im);arr[~np.isin(lab,keep)]=0;im=Image.fromarray(arr)
  return im
def halfw(xs,i):
  g=[abs(xs[i]-xs[j]) for j in (i-1,i+1) if 0<=j<len(xs)];return int(min(140,min(g)*.5+4)) if g else 140
F={k:[frame(S,y0,y1,cx,halfw(xs,i)) for i,cx in enumerate(xs)] for k,(S,(y0,y1),xs) in ROWS.items()}
# enemy rows: walk, atk (the big overhead cleave), jump (rising wingbeats), fall (the dive), die, idle, plus spares
ANIM=[('walk',F['walk']),('atk',F['atk2']),('jump',F['jump'][:4]),('fall',F['jump'][4:]),('die',F['dead']),('idle',F['idle']),
      ('hurt',F['hurt']),('atk1',F['atk1']),('atk3',F['atk3']),('run',F['run']),('idle2',F['idle2'])]
sheet=Image.new('RGBA',(C*8,C*len(ANIM)));at={}
for r,(nm,fs) in enumerate(ANIM):
  for i,f in enumerate(fs):sheet.alpha_composite(f,(i*C,r*C))
  at[nm]={'fw':C,'fh':C,'n':len(fs),'ax':AX,'ay':AY+5,'x':0,'y':r*C,'img':'tengu','pre':1.7,'art':1,'faceR':1}
sheet.save('/home/claude/pod2/crawl_tengu.png')
A=json.load(open('/home/claude/pod2/crawl_atlas.json'));A['units']['tengu']=at;json.dump(A,open('/home/claude/pod2/crawl_atlas.json','w'),separators=(',',':'))
prev=Image.new('RGBA',sheet.size,(70,76,90,255));prev.alpha_composite(sheet);prev.save('/tmp/w/tengu_prev.png')
print('ok',sheet.size,{k:v['n'] for k,v in at.items()})
