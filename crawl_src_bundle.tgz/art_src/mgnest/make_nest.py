# 0.12.425 MG Nest pixel art (Kyle's sketch): sandbag mound, belt-fed gun, camo net. Drawn at 2 art px per world px.
from PIL import Image, ImageDraw
import random
random.seed(7)
OUT='/home/claude/pod2/crawl_mgnest.png'
W,H=80,60            # one cell: 40x30 world px
sheet=Image.new('RGBA',(W*3,H),(0,0,0,0))
# ---------- cell 0: sandbag mound (front layer)
m=Image.new('RGBA',(W,H),(0,0,0,0));d=ImageDraw.Draw(m)
OUTL=(58,40,20,255);BASE=[(176,138,78),(196,156,92),(212,174,108)];LITE=(236,206,146);DARK=(140,104,56);SEAM=(120,88,46)
def bag(cx,cy,w,h,shade):
  c=BASE[shade]
  d.ellipse([cx-w//2,cy-h//2,cx+w//2,cy+h//2],fill=c+(255,),outline=OUTL)
  d.arc([cx-w//2+1,cy-h//2+1,cx+w//2-1,cy+h//2-1],200,330,fill=LITE+(255,))      # lit top edge
  d.arc([cx-w//2+1,cy-h//2+1,cx+w//2-1,cy+h//2-1],20,160,fill=DARK+(255,))        # shaded belly
  d.line([cx+w//2-3,cy-h//2+2,cx+w//2-3,cy+h//2-2],fill=SEAM+(255,))             # tied end
  d.point([cx+w//2-2,cy-1],fill=OUTL);d.point([cx+w//2-2,cy+1],fill=OUTL)
  for k in range(3):                                                               # burlap weave flecks
    d.point([cx-w//2+3+random.randint(0,w-7),cy-1+random.randint(-1,2)],fill=(160,124,70,255))
rows=[(H-6,[-26,-13,0,13,26],14,9,0),(H-13,[-19,-6,7,20],14,9,1),(H-20,[-12,1,14],14,9,2),(H-26,[-5,8],13,8,2)]
for y,xs,w,h,sh in rows:
  for dx in xs: bag(W//2+dx,y,w,h,sh)
for x in range(4,W-4):                                                             # dirt at the foot
  if random.random()<.5: m.putpixel((x,H-1),(70,50,30,255))
sheet.paste(m,(0,0))
# ---------- cell 1: the gun, pointing right, pivot at (24,30) in the cell
g=Image.new('RGBA',(W,H),(0,0,0,0));d=ImageDraw.Draw(g)
GM=(46,48,54);GD=(28,29,33);GL=(86,90,100);WOOD=(110,78,40);WOODL=(146,106,58)
px,py=24,30
d.rectangle([px-14,py-3,px-7,py+2],fill=WOOD+(255,));d.line([px-14,py-3,px-8,py-3],fill=WOODL+(255,))   # stock
d.rectangle([px-7,py-5,px+8,py+2],fill=GM+(255,),outline=GD+(255,))                                       # receiver
d.line([px-6,py-4,px+7,py-4],fill=GL+(255,))
d.rectangle([px-3,py-8,px+3,py-5],fill=GD+(255,));d.line([px-2,py-7,px+2,py-7],fill=GL+(255,))            # feed cover
d.rectangle([px+8,py-3,px+30,py-1],fill=GD+(255,));d.line([px+8,py-3,px+30,py-3],fill=GL+(255,))          # barrel
for k in range(9,20,3):d.rectangle([px+k,py-4,px+k+1,py],fill=GM+(255,))                                  # cooling jacket ribs
d.rectangle([px+30,py-4,px+33,py],fill=GD+(255,))                                                         # muzzle
d.rectangle([px+22,py-6,px+23,py-4],fill=GD+(255,))                                                       # front sight
d.rectangle([px-2,py+2,px+1,py+6],fill=GD+(255,))                                                         # grip
for i in range(6):                                                                                        # ammo belt hanging off the left
  x0=px-1-i*2;y0=py+1+i*2;d.rectangle([x0,y0,x0+1,y0+3],fill=(212,170,70,255));d.point([x0,y0],fill=(250,220,130,255))
sheet.paste(g,(W,0))
# ---------- cell 2: camo net canopy (see-through mesh)
n=Image.new('RGBA',(W,H),(0,0,0,0))
import math
def inside(x,y):
  # a full canopy: hangs to the ground at the back (left), arches over the gunner, drapes over the right shoulder of the mound
  xl,xr=1,64
  if x<xl or x>xr:return False
  t=(x-xl)/(xr-xl)
  upper=4+(1-math.sin(min(1,t*1.05)*math.pi*.9))*30*(1 if t<.45 else .55)
  lower=upper+15+5*math.sin(t*math.pi)
  if t<.18: lower=H-4                      # back curtain down to the dirt
  if t>.8: lower=upper+15+(t-.8)*55
  return upper<=y<=min(lower,H-4) and not (t>.25 and t<.8 and y>upper+17)
NETC=[(64,88,40),(80,108,48),(52,72,32),(98,92,52)]
for y in range(H):
  for x in range(W):
    if not inside(x,y):continue
    if (x+y)%3==0 or (x-y)%3==0:                       # diamond mesh cords
      n.putpixel((x,y),NETC[(x*7+y*3)%3]+(235,))
for k in range(80):                                     # leaf / burlap scraps tied into the net
  x=random.randint(2,62);y=random.randint(4,H-10)
  if inside(x,y):
    c=random.choice(NETC+[(122,116,64),(46,64,28)])
    for dx,dy in [(0,0),(1,0),(0,1),(1,1)][:random.randint(2,4)]:
      if inside(x+dx,y+dy):n.putpixel((x+dx,y+dy),c+(255,))
for x in range(W):                                      # a darker rope edge along the top of the arch
  for y in range(H):
    if inside(x,y) and not inside(x,y-1):
      n.putpixel((x,y),(36,52,22,255));break
sheet.paste(n,(W*2,0))
sheet.save(OUT);sheet.resize((sheet.width*4,sheet.height*4),Image.NEAREST).save('/tmp/nest_sheet_big.png');print('ok',sheet.size)
