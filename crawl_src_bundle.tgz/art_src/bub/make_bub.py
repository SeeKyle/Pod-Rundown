# 0.12.488 (Kyle) BUB: a Day of the Dead zombie hero, built from the game's own zombie enemy art (crawl_units.png 'zombie' rows).
# Original edit: flipped to face right, plaid shirt + dark jacket, sugar-skull face paint, a marigold, a pistol drawn by hand.
# Kyle's reference photos were only used for the general idea (jacket over red flannel, pistol), nothing copied from them.
from PIL import Image
import json
U=Image.open('/home/claude/pod2/crawl_units.png').convert('RGBA')
walk=[U.crop((i*28,0,i*28+28,42)) for i in range(6)]
atk=[U.crop((168+i*56,0,168+i*56+56,50)) for i in range(5)]
CW,CH,AX,AY=56,50,21,49           # native canvas, anchor (facing right)
def place(fr,ax,ay):
  c=Image.new('RGBA',(CW,CH));f=fr.transpose(Image.FLIP_LEFT_RIGHT);fax=fr.width-ax;c.alpha_composite(f,(AX-fax,AY-ay));return c
W=[place(f,15,41) for f in walk];A=[place(f,35,49) for f in atk]
SKIN={(118,130,125):'m',(163,171,154):'l',(84,94,94):'d',(188,196,176):'L',(216,220,203):'L'}
BLUE={(95,111,132),(69,84,104),(122,138,158)};BLUE_D=(47,58,74)
BLOOD={(58,12,14),(94,18,22),(138,26,30)}
BONE={'L':(240,236,222,255),'l':(226,222,206,255),'m':(204,200,186,255),'d':(160,156,148,255)}
RED=(168,40,40,255);REDD=(104,22,26,255);JACK=(34,32,36,255);JACK2=(56,52,58,255)
BLK=(14,12,16,255);MAG=(230,60,170,255);TEAL=(60,210,210,255);ORA=(255,150,30,255);YEL=(255,220,70,255)
def head_box(fr):
  """the head is the dark blob at the top of the body; returns (y0, front x, run per row)"""
  px=fr.load();dark=lambda x,y:px[x,y][3] and px[x,y][:3] not in SKIN and px[x,y][:3] not in BLOOD and px[x,y][:3] not in BLUE and px[x,y][:3]!=BLUE_D
  y0=next(y for y in range(CH) if sum(1 for x in range(CW) if dark(x,y))>=4)
  xs=[x for x in range(CW) if dark(x,y0)];cx=xs[len(xs)//2]
  runs={}
  for y in range(y0,y0+9):
    if not px[cx,y][3]:
      c2=[x for x in range(cx-4,cx+5) if 0<=x<CW and px[x,y][3]]
      if not c2:continue
      c0=c2[len(c2)//2]
    else:c0=cx
    l=c0;r=c0
    while l-1>=0 and px[l-1,y][3] and c0-(l-1)<=5:l-=1
    while r+1<CW and px[r+1,y][3] and (r+1)-c0<=5:r+=1
    runs[y]=(l,r)
  fx=max(runs[y][1] for y in range(y0+2,y0+6) if y in runs)
  return (y0,fx,runs)
def recolor(fr):
  px=fr.load()
  for y in range(CH):
    for x in range(CW):
      p=px[x,y]
      if not p[3]:continue
      c=p[:3]
      if c in BLOOD:
        n=sum(1 for dx,dy in((1,0),(-1,0),(0,1),(0,-1)) if 0<=x+dx<CW and 0<=y+dy<CH and px[x+dx,y+dy][3] and px[x+dx,y+dy][:3] not in BLOOD)
        px[x,y]=(0,0,0,0) if n==0 else (REDD if c!=(138,26,30) else RED)
      elif c in BLUE:px[x,y]=REDD if (x+y)%3==0 or y%3==0 else RED      # red flannel, plaid lines
      elif c==BLUE_D:px[x,y]=JACK
  return fr
def face_paint(fr,hb):
  y0,fx,runs=hb;px=fr.load()
  S=lambda x,y,c:(0<=x<CW and 0<=y<CH and px[x,y][3]) and px.__setitem__((x,y),c)
  for y in range(y0+2,y0+7):
    if y not in runs:continue
    l,r=runs[y]
    for x in range(max(l,fx-5),r+1):S(x,y,BONE['d'] if x==fx-5 else BONE['m'] if y==y0+6 else BONE['L'] if x>=fx-1 else BONE['l'])
  ey=y0+3
  S(fx-3,ey,BLK);S(fx-2,ey,BLK);S(fx-3,ey+1,BLK);S(fx-2,ey+1,BLK)       # eye socket
  S(fx-3,ey-1,MAG);S(fx-2,ey-1,MAG);S(fx-4,ey,TEAL);S(fx-4,ey+1,TEAL)  # painted petals round the eye
  S(fx,ey+2,BLK)                                                        # nose
  for dx in range(0,5):S(fx-dx,y0+6,BLK if dx%2==0 else BONE['L'])      # stitched grin
  S(fx-4,ey+3,MAG)                                                      # cheek dot
  hx=fx-5;hy=y0+1                                                       # marigold tucked in the hair
  S(hx,hy,ORA);S(hx+1,hy,YEL);S(hx+2,hy,ORA);S(hx+1,hy-1,ORA);S(hx+1,hy+1,ORA)
def bub(fr,face=True):
  fr=fr.copy();hb=head_box(fr);recolor(fr)
  if face:face_paint(fr,hb)
  return fr
def pistol(fr,arm_y,x_sh,x_end,flash=0,recoil=0):
  """his gun arm straight out from the shoulder at arm_y, a pistol in the hand"""
  fr=fr.copy();px=fr.load()
  sx=x_sh;ex=x_end-recoil
  for x in range(sx,ex+1):
    px[x,arm_y]=JACK if x<sx+3 else (118,130,125,255)
    px[x,arm_y+1]=JACK2 if x<sx+3 else (84,94,94,255)
  gx=ex+1
  for i in range(4):px[gx+i,arm_y-1]=(80,80,88,255)
  for i in range(4):px[gx+i,arm_y]=(36,36,42,255)
  px[gx,arm_y+1]=(36,36,42,255);px[gx,arm_y+2]=(70,48,30,255);px[gx+1,arm_y+1]=(36,36,42,255)
  if flash:
    for (dx,dy,c) in ((4,-1,YEL),(5,-1,(255,255,220,255)),(6,-1,ORA),(5,-2,ORA),(5,0,ORA),(7,-1,YEL)):px[gx+dx,arm_y+dy]=c
  return fr
def kneel(fr,k):
  """squash toward the ground (kneeling / sinking), anchored at the feet"""
  bb=fr.getbbox();h=bb[3]-bb[1];nh=max(4,int(h*k));c=Image.new('RGBA',(CW,CH))
  part=fr.crop((0,bb[1],CW,bb[3])).resize((CW,nh),Image.NEAREST);c.alpha_composite(part,(0,bb[3]-nh));return c
def lie(fr):
  bb=fr.getbbox();p=fr.crop(bb).rotate(-90,expand=True);c=Image.new('RGBA',(CW,CH));c.alpha_composite(p,(max(0,AX-p.width//2),AY+1-p.height));return c
Wb=[bub(f) for f in W];Ab=[bub(f) for f in A]
# shooting pose: the standing walk frame with his arm up and out
st=Wb[0];y0,fx,_=head_box(W[0]);armY=y0+9;pxs=st.load();row=[x for x in range(CW) if pxs[x,armY][3]];shX=(min(row)+max(row))//2;eX=fx+2
R=[pistol(st,armY,shX,eX),pistol(st,armY,shX,eX,flash=1,recoil=1),pistol(st,armY,shX,eX)]
print('muzzle (native, from anchor):',eX+5-AX,AY-(armY-1))
hurt=[Wb[0].transform((CW,CH),Image.AFFINE,(1,0,1,0,1,0)),Wb[3]]
D0=Ab[4];bbD=D0.getbbox()
death=[Ab[0],kneel(D0,.86),kneel(D0,.72),lie(Wb[0])]
# a light "flinch" tint on hurt frame 0
ANIM=[('idle',[Wb[0],Wb[3]]),('walk',Wb),('run',Wb),('melee',Ab),('ranged',R),('hurt',hurt),('death',death)]
S=3;FW,FH=CW*S,CH*S
sheet=Image.new('RGBA',(FW*6,FH*len(ANIM)))
at={}
for r,(nm,fs) in enumerate(ANIM):
  for i,f in enumerate(fs):sheet.alpha_composite(f.resize((FW,FH),Image.NEAREST),(i*FW,r*FH))
  at[nm]={'fw':FW,'fh':FH,'n':len(fs),'ax':AX*S+1,'ay':AY*S+2,'x':0,'y':r*FH,'img':'bub','pre':0.70,'faceR':1}
at['death']['fall']=0
sheet.save('/home/claude/pod2/crawl_bub.png')
a=json.load(open('/home/claude/pod2/crawl_atlas.json'));a['units']['bub']=at;json.dump(a,open('/home/claude/pod2/crawl_atlas.json','w'),separators=(',',':'))
prev=Image.new('RGBA',sheet.size,(70,70,80,255));prev.alpha_composite(sheet);prev.resize((sheet.width//2,sheet.height//2),Image.NEAREST).save('/tmp/w/bub_prev.png')
print('ok',sheet.size)
