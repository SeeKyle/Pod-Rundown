# 0.12.512 (Kyle) BUB as Romero's Day of the Dead zombie, from Kyle's cleaner sheet. (0.12.492: first built from Kyle's own zombie sheet (art_src/bub/kyle_zombie_base_sheet.png).
# The sheet is an upscaled screenshot (~2.655x), so it is sampled back to its native pixels on that grid, snapped to its palette,
# then given Bub's sugar-skull face, a marigold, a pistol (shoot anim) and an eating anim (the sheet's first 3 death frames).
import numpy as np, json
from PIL import Image
SRC='/home/claude/pod2/art_src/bub/kyle_zombie_base_sheet_v2.png'   # 0.12.512 (Kyle): his cleaner copy of the sheet (~4.38x)
im=np.array(Image.open(SRC).convert('RGB')).astype(float);H,W,_=im.shape
s,ox,oy=4.38,1.9,2.66   # pixel grid (edges at o + k*s)
nw=int((W-ox)/s);nh=int((H-oy)/s);a=np.zeros((nh,nw,3))
for j in range(nh):
  for i in range(nw):
    yy=int(oy+(j+.5)*s);xx=int(ox+(i+.5)*s);a[j,i]=im[yy-1:yy+2,xx-1:xx+2].reshape(-1,3).mean(0)
BG=np.array([179,175,189])
PAL={'out':(0,0,2),'pant':(54,1,43),'skin':(131,151,64),'shirt':(88,107,139),'shirtd':(35,43,92),'teal':(22,137,104),'red':(210,47,30),'spark':(250,240,170),'white':(255,255,255)}
names=list(PAL);P=np.array([PAL[n] for n in names],float)
def classify(px):
  if np.abs(px-BG).sum()<40:return None
  n=names[((P-px)**2).sum(1).argmin()];return None if n in('spark','white') else n
bandsI=[(40,250),(270,460),(490,670),(690,880),(900,1090)];rowsN=['attack','death','hurt','idle','walk'];counts=[6,6,2,4,6]
CW,CH=48,40
F={};foot={}
for (y0,y1),nm,n in zip(bandsI,rowsN,counts):
  ny0=int(y0/s);ny1=int(y1/s)+1;fr=[]
  for k in range(n):
    x0=int((440+210*k)/s);x1=int((440+210*(k+1))/s)
    d={}
    for y in range(ny0,min(ny1,nh)):
      for x in range(x0,min(x1,nw)):
        c=classify(a[y,x])
        if c:d[(x-x0,y-ny0)]=c
    fr.append(d)
  F[nm]=fr;foot[nm]=max(y for f in fr for (x,y) in f)
i0=F['idle'][0];fy=foot['idle'];fx=[x for (x,y),c in i0.items() if y>=fy-1];AXs=(min(fx)+max(fx))//2
AX,AY=16,CH-1
def canvas(d,row):
  g={}
  for (x,y),c in d.items():
    X=x-AXs+AX;Y=y-foot[row]+AY
    if 0<=X<CW and 0<=Y<CH:g[(X,Y)]=c
  return g
for k in F:F[k]=[canvas(d,k) for d in F[k]]
COL=dict(PAL);COL.update({'skin':(124,138,112),'skin2':(94,106,88),'shirt':(66,74,92),'shirtd':(38,42,56),'pant':(34,34,48),'pant2':(56,60,80),'flan':(176,40,38),'flan2':(110,22,28),'flan3':(84,20,26),'jak':(92,104,128),'jakd':(62,70,92),'bone':(236,232,216),'bone2':(206,200,186),'blk':(10,8,12),'mag':(232,62,172),'tealp':(64,214,214),'ora':(255,150,30),'yel':(255,220,70),'gun':(30,30,36),'gun2':(130,130,144),'grip':(92,60,34),'fl1':(255,240,170),'fl2':(255,170,40),'blood':(150,20,28)})
def head(d):
  """head = skin pixels in the 6 rows under the top of the figure, nearest the top pixel's column"""
  ys=[y for (x,y) in d];top=min(ys);tx=[x for (x,y) in d if y==top];cx=sum(tx)/len(tx)
  hs=[(x,y) for (x,y),c in d.items() if c in('skin','skin2','bone','bone2','blk','mag','tealp') and top<=y<top+6 and abs(x-cx)<=3]
  return top,hs
def face(d):
  top,hs=head(d)
  if len(hs)<6:return d
  d=dict(d);fx=max(x for x,y in hs);bx=min(x for x,y in hs)
  for (x,y) in hs:d[(x,y)]='bone2' if x==bx and fx-bx>=3 else 'bone'
  rows=sorted(set(y for x,y in hs));ey=rows[min(2,len(rows)-1)]
  def S(x,y,c):
    if (x,y) in d:d[(x,y)]=c
  S(fx-1,ey,'blk');S(fx-1,ey-1,'mag');S(fx-2,ey,'tealp')            # eye socket + painted petals
  S(fx,ey+1,'blk')                                                    # nose
  ty=rows[-1]
  for x in range(fx-2,fx+1):S(x,ty,'blk' if (fx-x)%2==0 else 'bone') # stitched grin
  hx=bx;hy=rows[0];d[(hx,hy-1)]='ora';d[(hx+1,hy-1)]='yel';d[(hx-1,hy)]='ora'   # marigold in the hair
  return d
def with_gun(d,flash=0,rec=0):
  d=dict(d);tip=max(x for (x,y),c in d.items() if c in('teal','teald','skin','skin2'));ty=max(y for (x,y),c in d.items() if x==tip and c in('teal','teald','skin','skin2'))
  if rec:
    for (x,y) in [k for k in d if k[0]>=tip-1 and abs(k[1]-ty)<=1]:d[(x-1,y)]=d.pop((x,y))
    tip-=1
  gx=tip+1
  for i in range(4):d[(gx+i,ty-1)]='gun2';d[(gx+i,ty)]='gun'
  d[(gx,ty+1)]='grip';d[(gx,ty+2)]='grip';d[(gx-1,ty)]='gun'
  if flash:
    for dx,dy,c in((3,-1,'fl1'),(4,-1,'fl2'),(3,-2,'fl2'),(3,0,'fl2'),(5,-1,'fl1')):d[(gx+dx,ty+dy)]=c
  return d
def bob(d,dy=1):
  """eating: head dips into the meal; a little blood at the mouth"""
  top,hs=head(d);hset=set(hs);n={}
  for k,c in d.items():
    if k in hset:n[(k[0],k[1]+dy)]=c
  for k,c in d.items():
    if k not in hset and k not in n:n[k]=c
  fx=max(x for x,y in hs);by=max(y for x,y in hs)+dy;n[(fx,by+1)]='blood';n[(fx+1,by+2)]='blood';return n

def tilt_arm(d,k):
  """0.12.503: raise (k>0) or lower (k<0) the shooting arm by shearing the pixels right of the shoulder"""
  SX,SY=SHO
  arm={(x,y):c for (x,y),c in d.items() if x>=SX and SY-3<=y<=SY+3}
  n={k2:v for k2,v in d.items() if k2 not in arm}
  for (x,y),c in arm.items():
    ny=y-int(round((x-SX)*k))
    if (x,ny) not in n or n[(x,ny)] in ('out',):n[(x,ny)]=c
  return n
def with_gun_t(d,k,flash=0,rec=0):
  d=tilt_arm(d,k);SX,SY=SHO
  arm=[(x,y) for (x,y),c in d.items() if x>=SX and c in('teal','teald','skin','skin2')]
  tip=max(arm);tx=tip[0];ty=min(y for x,y in arm if x==tx)
  if rec:tx-=1
  pts=[(tx+1+i,ty-int(round((i+1)*k))) for i in range(4)]
  for (x,y) in pts:d[(x,y)]='gun';d[(x,y-1)]='gun2'
  d[(tx,ty+1)]='grip';d[(tx,ty+2)]='grip'
  if flash:
    fx,fy=pts[-1];step=-1 if k>0 else 1
    for dx,dy,c in((1,0,'fl1'),(2,step,'fl2'),(1,-1,'fl2'),(1,1,'fl2'),(2,0,'fl1')):d[(fx+dx,fy+dy)]=c
  return d
# 0.12.511 (Kyle): Bub is Romero's Day of the Dead zombie, not a sugar skull. Keep the sheet's own zombie face; dress him like the film:
# gray-green rotting skin, dark denim jacket, red plaid flannel, dark jeans.
def plaid(d):
  """Bub's clothes: rotten gray-green head and hands, open denim jacket with red plaid flannel showing down the front, dark jeans"""
  if not d:return d
  ys=[y for (x,y) in d];top=min(ys);hb=top+6
  waist=max(ys)-13
  tor={}
  for (x,y),c in d.items():
    if hb<=y<waist and c=='shirt':tor.setdefault(y,[]).append(x)
    if hb<=y<waist and c=='pant':tor.setdefault(y,[]).append(x)
  arms=[(x,y) for (x,y),c in d.items() if c=='teal'];tipx=max(x for x,y in arms) if arms else None
  n={}
  for (x,y),c in d.items():
    if c=='teal':c='skin' if x>=tipx-1 else 'jakd'                  # far arm: dark sleeve, rotten hand
    elif c=='skin' and y>=hb:
      c='jak' if y<waist else 'pant2'                                # near arm -> denim sleeve; leg patches -> worn jeans
    elif c=='shirt' and hb<=y<waist:
      xs=tor[y];lo,hi=min(xs),max(xs);w=hi-lo+1
      if w>=3 and lo+w*.28<=x<=lo+w*.7:c='flan2' if (x%2==0 and y%3==0) or y%3==1 else 'flan'   # flannel front
      else:c='jak'
    elif c=='shirt':c='pant'
    elif c=='pant' and hb<=y<waist:c='jakd'
    n[(x,y)]=c
  return n
FA={k:[plaid(f) for f in v] for k,v in F.items()}
# shoulder pivot for aiming up/down, found from the idle pose: the outstretched hand's row, a couple px right of the head
_i=FA['idle'][0];_tip=max(x for (x,y),c in _i.items() if c=='skin');_ty=min(y for (x,y),c in _i.items() if x==_tip and c=='skin')
_top=min(y for x,y in _i);_hx=[x for (x,y) in _i if y==_top];SHO=((min(_hx)+max(_hx))//2+3,_ty)
print('shoulder',SHO,'hand',_tip,_ty)
idle=FA['idle'];D=FA['death']
ANIM=[('idle',idle),('walk',FA['walk']),('run',FA['walk']),('melee',FA['attack']),
      ('ranged',[with_gun(idle[0]),with_gun(idle[0],1,1),with_gun(idle[0])]),
      ('rangedUp',[with_gun_t(idle[0],.6),with_gun_t(idle[0],.6,1,1),with_gun_t(idle[0],.6)]),
      ('rangedDown',[with_gun_t(idle[0],-.45),with_gun_t(idle[0],-.45,1,1),with_gun_t(idle[0],-.45)]),
      ('hurt',FA['hurt']),('death',D),('eat',[D[0],D[1],D[2],bob(D[2])])]
S=5;FW,FH=CW*S,CH*S
sheet=Image.new('RGBA',(FW*6,FH*len(ANIM)))
at={}
for r,(nm,fs) in enumerate(ANIM):
  for i,d in enumerate(fs):
    f=Image.new('RGBA',(CW,CH))
    for (x,y),c in d.items():
      if 0<=x<CW and 0<=y<CH:f.putpixel((x,y),COL[c]+(255,))
    sheet.alpha_composite(f.resize((FW,FH),Image.NEAREST),(i*FW,r*FH))
  at[nm]={'fw':FW,'fh':FH,'n':len(fs),'ax':AX*S+S//2,'ay':AY*S+S,'x':0,'y':r*FH,'img':'bub','pre':1.4583,'faceR':1}   # 0.12.512: new sheet is 1.46x more pixels tall; keep his on-screen size
at['death']['fall']=0
# muzzle position (sheet px from anchor) for the bullet origin
d=with_gun(idle[0]);tip=max(x for (x,y),c in d.items() if c=='gun');ty=min(y for (x,y),c in d.items() if c=='gun')
print('muzzle native from anchor:',tip-AX,AY-ty)
sheet.save('/home/claude/pod2/crawl_bub.png')
A=json.load(open('/home/claude/pod2/crawl_atlas.json'));A['units']['bub']=at;json.dump(A,open('/home/claude/pod2/crawl_atlas.json','w'),separators=(',',':'))
prev=Image.new('RGBA',sheet.size,(70,70,80,255));prev.alpha_composite(sheet);prev.resize((sheet.width//2,sheet.height//2),Image.NEAREST).save('/tmp/w/bub_prev.png')
print('ok',sheet.size)
