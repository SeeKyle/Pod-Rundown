# 0.12.492 (Kyle) BUB rebuilt from Kyle's own zombie sheet (art_src/bub/kyle_zombie_base_sheet.png).
# The sheet is an upscaled screenshot (~2.655x), so it is sampled back to its native pixels on that grid, snapped to its palette,
# then given Bub's sugar-skull face, a marigold, a pistol (shoot anim) and an eating anim (the sheet's first 3 death frames).
import numpy as np, json
from PIL import Image
SRC='/home/claude/pod2/art_src/bub/kyle_zombie_base_sheet.png'
im=np.array(Image.open(SRC).convert('RGB')).astype(float);H,W,_=im.shape
s,ox,oy=2.655,0.4,0.0   # best-fit pixel grid of the screenshot
nw=int((W-ox)/s);nh=int((H-oy)/s);a=np.zeros((nh,nw,3))
for j in range(nh):
  for i in range(nw):
    c=im[int(oy+j*s+.7):int(oy+j*s+s-.7)+1,int(ox+i*s+.7):int(ox+i*s+s-.7)+1];a[j,i]=np.median(c.reshape(-1,3),0)
BG=np.array([180,175,188])
PAL={'out':(26,20,32),'pant':(52,12,44),'skin':(128,148,74),'skin2':(100,120,66),'shirt':(93,104,127),'shirtd':(44,44,80),'teal':(35,124,97),'teald':(30,78,66),'red':(196,48,34),'spark':(226,222,190)}
names=list(PAL);P=np.array([PAL[n] for n in names],float)
def classify(px):
  if np.abs(px-BG).sum()<55:return None
  if px.max()-px.min()<22 and px.mean()>95:return None if px.mean()>125 else 'out'
  n=names[((P-px)**2).sum(1).argmin()];return None if n=='spark' else n
bands=[(36,115),(128,199),(220,287),(299,371),(384,459)];rowsN=['attack','death','hurt','idle','walk'];counts=[6,6,2,4,6]
CW,CH=40,34       # native canvas
F={}
foot={}
for (y0,y1),nm,n in zip(bands,rowsN,counts):
  ny0=int(y0/s)-1;ny1=int(np.ceil(y1/s))+1;fr=[]
  for i in range(n):
    x0=int(round((160+86.6*i-ox)/s));x1=int(round((160+86.6*(i+1)-ox)/s))
    fr.append({(x-x0,y-ny0):classify(a[y,x]) for y in range(ny0,ny1) for x in range(x0,x1) if classify(a[y,x])})
  F[nm]=fr;foot[nm]=max(y for f in fr for (x,y) in f)
# anchor: idle frame 0 feet center
i0=F['idle'][0];fy=foot['idle'];fx=[x for (x,y),c in i0.items() if y>=fy-1];AXs=(min(fx)+max(fx))//2
AX,AY=13,CH-1
def canvas(d,row):
  g={}
  for (x,y),c in d.items():
    X=x-AXs+AX;Y=y-foot[row]+AY
    if 0<=X<CW and 0<=Y<CH:g[(X,Y)]=c
  return g
for k in F:F[k]=[canvas(d,k) for d in F[k]]
COL=dict(PAL);COL.update({'bone':(236,232,216),'bone2':(206,200,186),'blk':(10,8,12),'mag':(232,62,172),'tealp':(64,214,214),'ora':(255,150,30),'yel':(255,220,70),'gun':(44,44,52),'gun2':(96,96,108),'grip':(92,60,34),'fl1':(255,240,170),'fl2':(255,170,40),'blood':(150,20,28)})
def head(d):
  """head = skin pixels in the 6 rows under the top of the figure, nearest the top pixel's column"""
  ys=[y for (x,y) in d];top=min(ys);tx=[x for (x,y) in d if y==top];cx=sum(tx)/len(tx)
  hs=[(x,y) for (x,y),c in d.items() if c in('skin','skin2','bone','bone2','blk','mag','tealp') and top<=y<top+6 and abs(x-cx)<=3]
  return top,hs
def face(d):
  top,hs=head(d)
  if len(hs)<6:return d
  d=dict(d);fx=max(x for x,y in hs);bx=min(x for x,y in hs)
  for (x,y) in hs:d[(x,y)]='bone2' if x==bx and fx-bx>=3 else 'bone'
  rows=sorted(set(y for x,y in hs));ey=rows[min(2,len(rows)-1)]
  def S(x,y,c):
    if (x,y) in d:d[(x,y)]=c
  S(fx-1,ey,'blk');S(fx-1,ey-1,'mag');S(fx-2,ey,'tealp')            # eye socket + painted petals
  S(fx,ey+1,'blk')                                                    # nose
  ty=rows[-1]
  for x in range(fx-2,fx+1):S(x,ty,'blk' if (fx-x)%2==0 else 'bone') # stitched grin
  hx=bx;hy=rows[0];d[(hx,hy-1)]='ora';d[(hx+1,hy-1)]='yel';d[(hx-1,hy)]='ora'   # marigold in the hair
  return d
def with_gun(d,flash=0,rec=0):
  d=dict(d);tip=max(x for (x,y),c in d.items() if c in('teal','teald','skin','skin2'));ty=max(y for (x,y),c in d.items() if x==tip and c in('teal','teald','skin','skin2'))
  if rec:
    for (x,y) in [k for k in d if k[0]>=tip-1 and abs(k[1]-ty)<=1]:d[(x-1,y)]=d.pop((x,y))
    tip-=1
  gx=tip+1
  for i in range(3):d[(gx+i,ty-1)]='gun2';d[(gx+i,ty)]='gun'
  d[(gx,ty+1)]='grip';d[(gx-1,ty)]='gun'
  if flash:
    for dx,dy,c in((3,-1,'fl1'),(4,-1,'fl2'),(3,-2,'fl2'),(3,0,'fl2'),(5,-1,'fl1')):d[(gx+dx,ty+dy)]=c
  return d
def bob(d,dy=1):
  """eating: head dips into the meal; a little blood at the mouth"""
  top,hs=head(d);hset=set(hs);n={}
  for k,c in d.items():
    if k in hset:n[(k[0],k[1]+dy)]=c
  for k,c in d.items():
    if k not in hset and k not in n:n[k]=c
  fx=max(x for x,y in hs);by=max(y for x,y in hs)+dy;n[(fx,by+1)]='blood';n[(fx+1,by+2)]='blood';return n

def tilt_arm(d,k):
  """0.12.503: raise (k>0) or lower (k<0) the shooting arm by shearing the pixels right of the shoulder"""
  SX,SY=AX+4,AY-17   # shoulder (native)
  arm={(x,y):c for (x,y),c in d.items() if x>=SX and SY-3<=y<=SY+2}
  n={k2:v for k2,v in d.items() if k2 not in arm}
  for (x,y),c in arm.items():
    ny=y-int(round((x-SX)*k))
    if (x,ny) not in n or n[(x,ny)] in ('out',):n[(x,ny)]=c
  return n
def with_gun_t(d,k,flash=0,rec=0):
  d=tilt_arm(d,k);SX,SY=AX+4,AY-17
  arm=[(x,y) for (x,y),c in d.items() if x>=SX and c in('teal','teald','skin','skin2')]
  tip=max(arm);tx=tip[0];ty=min(y for x,y in arm if x==tx)
  if rec:tx-=1
  pts=[(tx+1+i,ty-int(round((i+1)*k))) for i in range(3)]
  for (x,y) in pts:d[(x,y)]='gun';d[(x,y-1)]='gun2'
  d[(tx,ty+1)]='grip'
  if flash:
    fx,fy=pts[-1];step=-1 if k>0 else 1
    for dx,dy,c in((1,0,'fl1'),(2,step,'fl2'),(1,-1,'fl2'),(1,1,'fl2'),(2,0,'fl1')):d[(fx+dx,fy+dy)]=c
  return d
FA={k:[face(f) for f in v] for k,v in F.items()}
idle=FA['idle'];D=FA['death']
ANIM=[('idle',idle),('walk',FA['walk']),('run',FA['walk']),('melee',FA['attack']),
      ('ranged',[with_gun(idle[0]),with_gun(idle[0],1,1),with_gun(idle[0])]),
      ('rangedUp',[with_gun_t(idle[0],.6),with_gun_t(idle[0],.6,1,1),with_gun_t(idle[0],.6)]),
      ('rangedDown',[with_gun_t(idle[0],-.45),with_gun_t(idle[0],-.45,1,1),with_gun_t(idle[0],-.45)]),
      ('hurt',FA['hurt']),('death',D),('eat',[D[0],D[1],D[2],bob(D[2])])]
S=5;FW,FH=CW*S,CH*S
sheet=Image.new('RGBA',(FW*6,FH*len(ANIM)))
at={}
for r,(nm,fs) in enumerate(ANIM):
  for i,d in enumerate(fs):
    f=Image.new('RGBA',(CW,CH))
    for (x,y),c in d.items():
      if 0<=x<CW and 0<=y<CH:f.putpixel((x,y),COL[c]+(255,))
    sheet.alpha_composite(f.resize((FW,FH),Image.NEAREST),(i*FW,r*FH))
  at[nm]={'fw':FW,'fh':FH,'n':len(fs),'ax':AX*S+S//2,'ay':AY*S+S,'x':0,'y':r*FH,'img':'bub','pre':1.0,'faceR':1}
at['death']['fall']=0
# muzzle position (sheet px from anchor) for the bullet origin
d=with_gun(idle[0]);tip=max(x for (x,y),c in d.items() if c=='gun');ty=min(y for (x,y),c in d.items() if c=='gun')
print('muzzle native from anchor:',tip-AX,AY-ty)
sheet.save('/home/claude/pod2/crawl_bub.png')
A=json.load(open('/home/claude/pod2/crawl_atlas.json'));A['units']['bub']=at;json.dump(A,open('/home/claude/pod2/crawl_atlas.json','w'),separators=(',',':'))
prev=Image.new('RGBA',sheet.size,(70,70,80,255));prev.alpha_composite(sheet);prev.resize((sheet.width//2,sheet.height//2),Image.NEAREST).save('/tmp/w/bub_prev.png')
print('ok',sheet.size)
