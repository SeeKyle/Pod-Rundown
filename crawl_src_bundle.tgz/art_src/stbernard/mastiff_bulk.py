# 0.12.448 (Kyle) make the English Mastiff a different SHAPE from the Cane Corso: higher, rounder back, thick tree-trunk legs,
# a stubby tail and heavy jowls hanging below the jaw. Runs on mastiff.png after make_mastiff.py (+ chest pass).
from PIL import Image
import sys
src=sys.argv[1];m=Image.open(src).convert('RGBA')
OUT=(26,24,30);G1=(200,156,100);G2=(164,120,74);G3=(122,86,52);GL=(228,190,136);MASK=(30,24,22)
ROWS=[('run',4),('walk',6),('idle',4),('melee',3),('hurt',1),('death',2)]
for r,(nm,n) in enumerate(ROWS):
  for f in range(n):
    fr=m.crop((f*62,r*34,f*62+62,r*34+34));px=fr.load()
    for y in range(34):
      for x in range(62):
        if px[x,y][3] and px[x,y][:3]==OUT:px[x,y]=(0,0,0,0)
    bb=fr.getbbox()
    if not bb:continue
    x0,y0,x1,y1=bb;W=x1-x0;H=y1-y0;sit=nm=='idle';dead=nm=='death'
    op=lambda x,y:0<=x<62 and 0<=y<34 and px[x,y][3]>0
    if not sit and not dead:
      # stubby tail: cut the tail back
      for y in range(y0,y0+int(H*.55)):
        for x in range(x1-4,x1):
          if op(x,y):px[x,y]=(0,0,0,0)
      bb=fr.getbbox();x0,y0,x1,y1=bb;W=x1-x0;H=y1-y0
      # higher, rounder back over the shoulders and hips
      for x in range(x0+int(W*.3),x0+int(W*.95)):
        ys=[y for y in range(34) if op(x,y)]
        if not ys:continue
        t=ys[0]
        if t-1>=0:px[x,t-1]=GL+(255,);px[x,t]=G1+(255,)
      # thick legs
      for y in range(y0+int(H*.6),y1):
        x=0
        while x<62:
          if op(x,y):
            s=x
            while x<62 and op(x,y):x+=1
            if x-s<=3 and x<62:px[x,y]=G2+(255,)
            x+=1
          else:x+=1
    if sit:
      # sitting: tuck the tail in and bulk up the back and chest
      for y in range(y1-5,y1):
        for x in range(x1-7,x1):
          if op(x,y):px[x,y]=(0,0,0,0)
      bb=fr.getbbox();x0,y0,x1,y1=bb;W=x1-x0;H=y1-y0
      for y in range(y0+int(H*.3),y1-2):
        xs=[x for x in range(62) if op(x,y)]
        if not xs:continue
        a,b=xs[0],xs[-1]
        if b+1<62:px[b+1,y]=G2+(255,)
        if y>y0+int(H*.45) and a-1>=0:px[a-1,y]=G1+(255,)
    # heavy jowls hanging under the jaw
    hx=x0+2;jy=None
    for y in range(y0,y0+int(H*.6)):
      if op(hx,y):jy=y
    if jy is not None and not dead:
      for dx in (0,1,2):
        if jy+1<34:px[hx+dx,jy+1]=MASK+(255,)
      if jy+2<34:px[hx+1,jy+2]=MASK+(255,)
    seen=set()
    for y in range(34):
      for x in range(62):
        if op(x,y) and (x,y) not in seen:
          st=[(x,y)];comp=[]
          seen.add((x,y))
          while st:
            q=st.pop();comp.append(q)
            for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)):
              n2=(q[0]+dx,q[1]+dy)
              if op(*n2) and n2 not in seen:seen.add(n2);st.append(n2)
          if len(comp)<8:
            for q in comp:px[q]=(0,0,0,0)   # drop stray bits (old tail tips)
    snap=fr.copy();sp=snap.load()
    o2=lambda x,y:0<=x<62 and 0<=y<34 and sp[x,y][3]>0
    for y in range(34):
      for x in range(62):
        if sp[x,y][3]==0 and any(o2(x+dx,y+dy) for dx,dy in ((1,0),(-1,0),(0,1),(0,-1))):px[x,y]=OUT+(255,)
    m.paste(fr,(f*62,r*34))
m.save(sys.argv[2])
