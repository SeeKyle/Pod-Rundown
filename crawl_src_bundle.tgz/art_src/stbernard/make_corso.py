# 0.12.434 (Kyle) Cane Corso: from the Rottweiler frames (same 62x34 grid, faces left): slate-grey coat, blocky head with cropped ears, studded collar, deep chest.
import os
from PIL import Image
import colorsys
base=Image.open('/home/claude/pod2/art_src/stbernard/crawl_dog_base.png').convert('RGBA')
Y0=1020;ROWS=[('run',4),('walk',6),('idle',4),('melee',3),('hurt',1),('death',2)]
G1=(118,124,134);G2=(92,98,108);G3=(68,72,82);GL=(150,156,166);MASK=(34,34,40);OUT=(26,24,30)
out=Image.new('RGBA',(62*6,34*6),(0,0,0,0))
HEAD=["...O..O.....",
      "..OGO.OGO...",
      ".OGGGOGGGO..",
      "OMGGEeGGGgO.",
      "OMMGGGGGggO.",
      "ONMMGGGGgggO",
      "OMMMMGGGgggO",
      ".OmMMGgggggO",
      "..OOmOOggOO.",
      "....O..OO..."]
CC={'B':(116,64,32),'b':(84,44,22),'W':(214,214,224)}
COL_STAND=[(12, 2, 'W'), (11, 3, 'B'), (12, 3, 'W'), (11, 4, 'B'), (12, 4, 'b'), (11, 5, 'W'), (12, 5, 'W'), (10, 6, 'B'), (11, 6, 'b'), (9, 7, 'B'), (10, 7, 'b'), (8, 8, 'B'), (9, 8, 'W'), (8, 9, 'W'), (9, 9, 'b'), (7, 10, 'W'), (8, 10, 'b'), (6, 11, 'W'), (7, 11, 'b')]
COL_SIT=[(12, 8, 'B'), (13, 8, 'W'), (11, 9, 'B'), (12, 9, 'W'), (13, 9, 'W'), (5, 10, 'B'), (6, 10, 'W'), (7, 10, 'B'), (8, 10, 'W'), (9, 10, 'b'), (10, 10, 'W'), (11, 10, 'b'), (12, 10, 'W'), (6, 11, 'W'), (8, 11, 'W'), (10, 11, 'W')]
HC={'O':OUT,'G':G1,'g':G2,'M':MASK,'m':(56,56,64),'E':(12,10,10),'e':(240,240,240),'N':(10,10,12)}
for r,(nm,n) in enumerate(ROWS):
  for f in range(n):
    fr=base.crop((f*62,Y0+r*34,f*62+62,Y0+r*34+34));px=fr.load();bb=fr.getbbox()
    if not bb:continue
    x0,y0,x1,y1=bb;W=x1-x0;H=y1-y0;sit=nm=='idle'
    for y in range(34):
      for x in range(62):
        p=px[x,y]
        if p[3]==0:continue
        lum=(p[0]+p[1]+p[2])/3
        c=G1 if lum>70 else (G2 if lum>40 else G3)
        px[x,y]=c+(p[3],)
    snap=fr.copy();sp=snap.load()
    op=lambda x,y:0<=x<62 and 0<=y<34 and sp[x,y][3]>0
    for y in range(34):
      for x in range(62):
        if not op(x,y):continue
        if not op(x,y-1):px[x,y]=GL+(255,)                     # light along the top line (muscle sheen)
        elif not op(x,y+1):px[x,y]=G3+(255,)
    # deep chest
    if not sit:
      for x in range(x0+int(W*.15),x0+int(W*.48)):   # (Kyle) barrel chest
        ys=[y for y in range(y0,34) if px[x,y][3]>0]
        if not ys:continue
        y=ys[0]
        while y+1<34 and px[x,y+1][3]>0 and y<int(y0+H*.55):y+=1
        for k in (1,2,3):
          if y+k<33 and px[x,y+k][3]==0:px[x,y+k]=(G1 if k==1 else G2 if k==2 else G3)+(255,)
    # head stamp
    hx0,hy0=(x0-1,y0-2) if not sit else (x0-1,y0-2)
    for ry,row in enumerate(HEAD):
      for rx,ch in enumerate(row):
        if ch=='.':continue
        X,Y=hx0+rx,hy0+ry
        if 0<=X<62 and 0<=Y<34:px[X,Y]=HC[ch]+(255,)
    # spiked leather collar (Kyle drew it, 0.12.438): B/b leather, W spikes, offsets from the head stamp
    if os.environ.get('OLDCOLLAR'):
      for k in range(9):
        t=k/8;x,y=(round(hx0+4+7*t),round(hy0+10+2.5*t-2*t*(1-t)*2)) if sit else (round(hx0+12-5*t),round(hy0+2+8*t))
        for dx,c in ((0,(116,64,32)),(1,(84,44,22))):
          if 0<=y<34 and 0<=x+dx<62 and px[x+dx,y][3]>0:px[x+dx,y]=c+(255,)
        if k in (2,5) and 0<=y<34 and px[x,y][3]>0:px[x,y]=(214,214,224,255)
    else:
      for (cx,cy,ch) in (COL_SIT if sit else COL_STAND):
        X,Y=hx0+cx,hy0+cy
        if 0<=X<62 and 0<=Y<34:px[X,Y]=CC[ch]+(255,)
    # outline
    snap=fr.copy();sp=snap.load()
    for y in range(34):
      for x in range(62):
        if sp[x,y][3]==0 and any(op(x+dx,y+dy) for dx,dy in ((1,0),(-1,0),(0,1),(0,-1))):px[x,y]=OUT+(255,)
    out.paste(fr,(f*62,r*34))
out.save(os.environ.get('OUT','/home/claude/pod2/art_src/stbernard/corso.png'))
frames=[];durs=[]
for r,(n,d) in enumerate([(4,.1),(6,.13),(4,.3),(3,.12)]):
  for rep in range(3):
    for f in range(n):
      c=out.crop((f*62,r*34,f*62+62,r*34+34));bg=Image.new('RGBA',(62,34),(40,44,60,255));bg.alpha_composite(c)
      frames.append(bg.resize((62*6,34*6),Image.NEAREST).convert('P',palette=Image.ADAPTIVE,colors=64));durs.append(int(d*1000))
frames[0].save('/home/claude/cane_corso.gif',save_all=True,append_images=frames[1:],duration=durs,loop=0,disposal=2)
prev=Image.new('RGBA',(62*4,34*2),(40,44,60,255))
for i,(r,f) in enumerate([(0,0),(1,2),(2,0),(3,1),(0,2),(1,4),(2,2),(5,0)]):c=out.crop((f*62,r*34,f*62+62,r*34+34));prev.alpha_composite(c,((i%4)*62,(i//4)*34))
prev.resize((prev.width*5,prev.height*5),Image.NEAREST).save('/home/claude/corso_preview.png');print('ok')
