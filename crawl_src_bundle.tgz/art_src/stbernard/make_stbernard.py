# 0.12.431 (Kyle) Saint Bernard: repainted from the Golden's frames (same 62x34 grid, faces left), heavier, with the rescue barrel under the chin.
from PIL import Image
SRC='/home/claude/pod2/crawl_dog.png'
im=Image.open(SRC).convert('RGBA')
Y0=612   # the Golden block
ROWS=[('run',4),('walk',6),('idle',4),('melee',3),('hurt',1),('death',2)]
WH=(244,238,226);WHs=(214,206,190);CH=(176,84,34);CHd=(130,58,24);CHl=(204,112,52);DK=(58,34,22);NOSE=(28,20,18)
BAR=(150,96,48);BARd=(96,58,26);RED=(214,34,34);BAND=(70,70,76)
out=Image.new('RGBA',(62*6,34*6),(0,0,0,0))
def frame(r,f):return im.crop((f*62,Y0+r*34,f*62+62,Y0+r*34+34))
for r,(nm,n) in enumerate(ROWS):
  for f in range(n):
    fr=frame(r,f);px=fr.load();bb=fr.getbbox()
    if not bb:continue
    x0,y0,x1,y1=bb;W=x1-x0;H=y1-y0
    # 1) heavier: thicken the torso downward by 1px (not legs/head)
    base=fr.copy();bp=base.load()
    if nm!='idle':
      for x in range(x0+int(W*.22),x0+int(W*.85)):
        col=[y for y in range(y0,y1) if bp[x,y][3]>0]
        if col:
          top=col[0]
          for y in range(top,min(top+int(H*.5),33)):
            if bp[x,y][3]==0 and y>top and bp[x,y-1][3]>0 and y<y0+int(H*.62):px[x,y]=bp[x,y-1];break
    # 1b) (Kyle) shorter snout and a snub tail: trim the muzzle tip and dock the tail
    for y in range(34):
      for x in range(62):
        if px[x,y][3]==0:continue
        rx=(x-x0)/max(1,W);ry=(y-y0)/max(1,H)
        if nm=='idle':
          if rx>.78:px[x,y]=(0,0,0,0)
        else:
          if rx<.05 and ry<.65:px[x,y]=(0,0,0,0)
          if rx>.9:px[x,y]=(0,0,0,0)
    bb=fr.getbbox() or bb;x0,y0,x1,y1=bb;W=x1-x0;H=y1-y0
    # 2) repaint by region
    sit=nm=='idle'
    for y in range(34):
      for x in range(62):
        p=px[x,y]
        if p[3]==0:continue
        lum=(p[0]+p[1]+p[2])/3
        rx=(x-x0)/max(1,W);ry=(y-y0)/max(1,H)
        if sit: head=ry<.38 and rx<.6; legs=ry>.72 and rx<.6; tail=rx>.6 and ry>.55
        else: head=rx<.27 and ry<.62; legs=ry>.62; tail=rx>.84
        if head:
          if rx<(.1 if not sit else .2) and ry>(.25 if not sit else .2): c=WH                  # muzzle
          elif abs(rx-(.14 if not sit else .3))<.035: c=WH                                       # white blaze
          elif ry<.3 and rx>(.17 if not sit else .38): c=DK                                       # ear
          else: c=CH if lum>120 else CHd
          if lum<70: c=NOSE if rx<.08 else DK                                                    # eye / nose / mask
        elif legs: c=WH if lum>110 else WHs
        elif tail: c=WH if rx>(.94 if not sit else .85) else CHl
        else:
          if sit: c=WH if rx<.45 else (CH if lum>110 else CHd)                                    # sitting: white chest, chestnut back
          else: c=(CH if lum>115 else CHd) if ry<.42 else (WH if lum>100 else WHs)                # saddle on top, white belly
          if not sit and rx<.36 and ry>.3: c=WH                                                   # white chest/ruff
        px[x,y]=c+(p[3],)
    # 3) (Kyle: give it a real face) a hand-drawn Saint Bernard head, stamped on every frame: white blaze, dark masks, an eye with a glint,
    #    black nose, droopy white jowls and big hanging chestnut ears. Faces left like the sheet.
    HEAD=[".....OOOOO...",
          "....OCWCCCO..",
          "...OCWMMCCcO.",
          "..OWWMEeCccO.",
          ".OWWWMMMCcccO",
          "ONWWWWWWCcccO",
          "ONNWwWWWCcccO",
          ".OwWWWWwOcccO",
          "..OwwWwO.OcO.",
          "...OOOO...O.."]
    HC={'O':(46,26,16),'W':WH,'w':WHs,'C':CH,'c':CHd,'M':(70,36,22),'E':(14,10,8),'e':(250,250,250),'N':(20,16,16)}
    hx0,hy0=(x0-1,y0-2) if not sit else (x0-1,y0-1)
    for ry,row in enumerate(HEAD):
      for rx,ch in enumerate(row):
        if ch=='.':continue
        X,Y=hx0+rx,hy0+ry
        if 0<=X<62 and 0<=Y<34:px[X,Y]=HC[ch]+(255,)
    bx,by=hx0+3,hy0+10
    for x in range(bx-1,bx+5):
      for y in range(by,by+4):
        if 0<=x<62 and 0<=y<34:px[x,y]=(BARd if x in (bx-1,bx+4) or y in (by,by+3) else BAR)+(255,)
    for (x,y) in [(bx+1,by+1),(bx+2,by+1),(bx+1,by+2),(bx+2,by+2)]:
      if 0<=y<34:px[x,y]=RED+(255,)
    for x in range(bx,bx+4):
      if 0<=by-1<34:px[x,by-1]=(150,30,24,255)                                         # red collar
    # 4) detail pass (Kyle: more detail): shading, jowls, a nicer barrel, then a dark outline that also bulks him up
    snap=fr.copy();sp=snap.load()
    def op(x,y):return 0<=x<62 and 0<=y<34 and sp[x,y][3]>0
    for y in range(34):
      for x in range(62):
        if not op(x,y):continue
        c=sp[x,y][:3]
        if c in (CH,CHd) and not op(x,y-1):px[x,y]=CHl+(255,)                       # sunlit top of the back
        elif c==CH and not op(x,y+1):px[x,y]=CHd+(255,)
        elif c==WH and (not op(x,y+1) or (op(x,y+1) and sp[x,y+1][:3] in (CH,CHd))):px[x,y]=WHs+(255,)   # fur shadow under the white
        elif c==WH and (x+y)%7==0:px[x,y]=(232,224,210,255)                          # fur texture
    if not sit:                                                                        # droopy jowls under the muzzle
      mx=[x for x in range(x0,x0+int(W*.12)) for y in range(34) if op(x,y)]
      if mx:
        jx=min(mx)+1;jy=max(y for y in range(34) if op(jx,y))
        for dx in range(0,3):
          if jy+1<34:px[jx+dx,jy+1]=WHs+(255,)
        if jy+2<34:px[jx+1,jy+2]=(200,190,176,255)
    for x in range(bx-1,bx+5):                                                         # barrel: bands, highlight, grain
      if 0<=by<34:px[x,by]=(178,120,62,255)
    for y in range(by+1,by+3):px[bx-1,y]=(62,62,70,255);px[bx+4,y]=(62,62,70,255)
    px[bx+3,by+2]=(120,78,38,255)
    snap=fr.copy();sp=snap.load()
    for y in range(34):
      for x in range(62):
        if sp[x,y][3]==0 and any(op(x+dx,y+dy) for dx,dy in ((1,0),(-1,0),(0,1),(0,-1))):px[x,y]=(48,28,18,255)
    out.paste(fr,(f*62,r*34))
out.save('/home/claude/pod2/art_src/stbernard/stbernard.png')
prev=Image.new('RGBA',out.size,(40,44,60,255));prev.alpha_composite(out);prev.resize((out.width*3,out.height*3),Image.NEAREST).save('/home/claude/stbernard_preview.png')
print('ok')
