#!/bin/bash
# usage: pub.sh VER "commit msg"
set -e
cd /home/claude/pod2
sed -i "s/v0\.12\.[0-9]*<\/span><\/span>/v$1<\/span><\/span>/" crawl_ui.js
python3 build_crawl.py >/dev/null && node --check crawl.js && python3 build_site.py >/dev/null
cp index.html notes.html crawl.js /home/claude/pod-rundown/
for f in crawl_*.png crawl_*.mp3 crawl_*.ogg; do [ -e "$f" ] || continue; cmp -s $f /home/claude/pod-rundown/$f || cp $f /home/claude/pod-rundown/; done
cd /home/claude/pod-rundown && git add -A && git commit -q -m "$2

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_01MWfQtWHAkWRB7cpKUKLhiR" && git push -q https://github.com/SeeKyle/Pod-Rundown.git HEAD && git log --oneline | head -1
