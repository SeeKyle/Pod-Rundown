# 0.12.450 (Kyle) Black Lab gets floppy drop ears; Rottweiler gets cropped ears (tall narrow points) so it stands apart from the Shepherd.
from PIL import Image
import sys
sh=Image.open(sys.argv[1]).convert('RGBA');px=sh.load()
ROWS=[4,6,4,3,1,2]
def frames(Y0):
  for r,n in enumerate(ROWS):
    for f in range(n):yield f*62,Y0+r*34,r
def opq(x,y):return px[x,y][3]>0
for X,Y,r in frames(408):          # LAB
  if r==5:continue
  pts=[(x,y) for y in range(Y,Y+34) for x in range(X,X+62) if opq(x,y)]
  if not pts:continue
  t0=min(p[1] for p in pts);ex=[p[0] for p in pts if p[1]==t0];ex=sorted(ex)[len(ex)//2]
  for y in (t0,t0+1):
    for x in range(ex-3,ex+4):
      if opq(x,y):px[x,y]=(0,0,0,0)
  EAR=["RRR.",       # a soft fold on top of the skull
       "RddR",
       "Rddr",
       "Rddr",
       ".ddr",
       ".dr."]
  C={'R':(60,60,68,255),'d':(14,14,18,255),'r':(44,44,52,255)}
  for ry,row in enumerate(EAR):
    for rx,ch in enumerate(row):
      if ch!='.':px[ex-1+rx,t0+1+ry]=C[ch]
for X,Y,r in frames(1020):          # ROTT
  if r==5:continue
  pts=[(x,y) for y in range(Y,Y+34) for x in range(X,X+62) if opq(x,y)]
  if not pts:continue
  t0=min(p[1] for p in pts);ex=[p[0] for p in pts if p[1]==t0];ex=sorted(ex)[len(ex)//2]
  for x in range(ex-3,ex+4):
    if opq(x,t0):px[x,t0]=(0,0,0,0)
  D=(20,16,14,255);T=(150,90,40,255)
  for dy,xs in ((-2,[0]),(-1,[0]),(0,[0,1]),(1,[-1,0,1])):
    for dx in xs:
      y=t0+dy
      if Y<=y:px[ex+dx,y]=D
  px[ex+1,t0+1]=T
sh.save(sys.argv[2])
