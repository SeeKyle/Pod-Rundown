"""compose the neighborhood like the game draws it (layers at 0.75 scale, parallax) for a preview"""
from PIL import Image
D='/home/claude/pod2/art_src/hood/'
sky,far,mid,gr=[Image.open(D+n+'.png').convert('RGBA') for n in ('sky','far','mid','ground')]
def sc(im):return im.resize((round(im.width*.75),round(im.height*.75)),Image.NEAREST)
sky,far,mid,gr=map(sc,(sky,far,mid,gr))
W,H=384,232;oy=0
def frame(d):
    o=Image.new('RGBA',(W,H),(22,14,38,255))
    for (im,y,sp) in ((far,-38,.12),(mid,-38,.35),(gr,181,1.0)):
        off=int(d*sp)%im.width
        x=-off
        while x<W:o.alpha_composite(im,(x,y)) if y>=0 else o.alpha_composite(im.crop((0,-y,im.width,im.height)),(x,0));x+=im.width
    return o
for i,d in enumerate((0,900,1900,2900)):frame(d).resize((W*3,H*3),Image.NEAREST).save(f'/tmp/hood_game{i}.png')
