"""0.12.387 neighborhood houses. Each fn draws on a Canvas and returns lock-point info: (door_center_x, building_width, door_top_y)."""
from hood_lib import *
WHITE=[(70,70,90),(104,104,124),(132,132,152),(158,158,178)]       # Kyle's white siding at night
TAN=[(60,52,56),(86,76,76),(108,98,94),(132,122,114)]               # Cheez's tan siding
SHUT_BLUE=[(28,40,70),(44,60,98)]
def kyle_house(c,x0,base,ground):
    """Kyle's place: a white 1.5-story cape with a steep shingle roof, an attached garage on the right, a cracked driveway with
    the utility trailer still in it, big shade trees either side, a scraggly young tree out front. Overgrown and beat up."""
    R=c.R;hx0,hx1=x0+12,x0+84;gx0,gx1=x0+84,x0+134
    c.tree(x0+150,base,34,30,lean=-.1,dense=1.3)                      # the big overgrown tree/bush on the right (behind)
    c.chimney(x0+30,base-62,base-38)
    c.roof_band(hx0,hx1,base-30,26,moss=.5,holes=.35)                   # main roof
    c.gable_front(x0+48,x0+66,base-30,10,WHITE,vent=False,over=2)       # little front dormer peak
    c.window(x0+54,base-36,6,5,'broken',trim=TRIM)
    c.siding(hx0,base-30,hx1,base,WHITE,wear=.55)
    c.roof_band(gx0,gx1,base-22,13,moss=.4,holes=.25)                   # garage roof
    c.siding(gx0,base-22,gx1,base,WHITE,wear=.6)
    # garage door: panels, dented, stuck a little open at the bottom
    gd0,gd1=gx0+16,gx1-5
    c.rect(gd0-1,base-18,gd1+1,base,TRIM[1])
    for y in range(base-17,base-2):
        for x in range(gd0,gd1+1):c.put(x,y,(122,122,142) if (y-(base-17))%4 else (92,92,110))
    for x in range(gd0,gd1+1):c.put(x,base-2,(6,4,10));c.put(x,base-1,(6,4,10));c.put(x,base,(6,4,10))
    for (dx,dy) in((6,-11),(7,-10),(6,-10),(20,-6),(21,-6)):c.put(gd0+dx,base+dy,(70,70,88))   # dents
    c.door(gx0+5,base-17,7,17,(122,122,142),'closed');c.window(gx0+6,base-15,5,4,'dark',glow=False)
    # house front: two windows, the front door with a little stoop, a porch rail on the left
    c.window(hx0+8,base-22,9,11,'boarded');c.window(hx0+46,base-22,9,11,'lit',shut=None)
    door=(hx0+30,base-19,8,19)
    c.door(*door,(58,52,70),'closed')
    c.rect(hx0+27,base-1,hx0+41,base,TRIM[0])
    for x in range(hx0-6,hx0+24,4):
        if R.random()<.8:c.rect(x,base-8,x,base,BOARD[1])
    c.rect(hx0-7,base-9,hx0+24,base-9,BOARD[2]);c.rect(hx0+10,base-9,hx0+15,base-9,(0,0,0,0))   # broken rail
    c.ivy(gx1-3,base,20,8);c.ivy(hx0+2,base,24,6)
    # driveway (cracked concrete into the yard) + the utility trailer
    for x in range(gx0+10,gx1+12):
        for y in range(base+1,ground):c.put(x,y,(74,74,88) if R.random()<.85 else (54,54,66))
    for i in range(6):
        cx=R.randint(gx0+12,gx1+8)
        for y in range(base+1,ground):cx+=R.choice([-1,0,1]);c.put(cx,y,(30,30,40))
    tx=gx0+20;ty=base+2
    c.rect(tx,ty-6,tx+26,ty-5,(46,46,56));c.rect(tx,ty-4,tx+26,ty-4,(30,30,38))
    for x in range(tx,tx+27,3):c.rect(x,ty-11,x,ty-6,(60,60,72))
    c.rect(tx,ty-11,tx+26,ty-11,(84,84,98));c.rect(tx-8,ty-4,tx,ty-4,(46,46,56))
    for (wx) in (tx+10,):
        for dx in range(-3,4):
            for dy in range(-3,4):
                if dx*dx+dy*dy<=9:c.put(wx+dx,ty-1+dy,(16,14,20) if dx*dx+dy*dy>2 else (90,90,100))
    # yard: tall grass, a brush pile, the young tree, the big shade tree on the left (in front)
    c.trampled(x0+6,gx0+8,base,ground,paths=(door[0]+4,))
    for i in range(30):c.line(x0+18+R.randint(0,14),ground-1-R.randint(0,3),x0+18+R.randint(0,14),ground-5-R.randint(0,4),DRY[R.randint(0,2)])
    c.tree(x0+60,ground-1,22,9,lean=.05,dense=.5)
    c.tree(x0-4,ground-2,26,18,lean=.06,dense=1.1)
    c.mailbox(x0+92,ground-1,lean=1)
    for (dx,dy,col) in ((0,-12,(130,90,170)),(1,-12,(130,90,170)),(-1,-11,(110,70,150)),(0,-11,(150,110,190)),(1,-11,(110,70,150))):c.put(x0+92+dx+1,ground-1+dy,col)   # a little purple d20 sticker
    return dict(door=(door[0]+door[2]/2,door[1]),bw=hx1-hx0,cx=(hx0+hx1)/2,x0=hx0,x1=gx1,drect=door,feat=[('garage',gd0,base-17,gd1-gd0+1,17)])
def cheez_house(c,x0,base,ground):
    """Cheez's building: a tan 2-story with a front-gabled left half, a dormer on the right half, a full-width porch on columns
    with two front doors, big round shrubs, the two blue bins at the curb, a big bare tree on the right. Gone to seed."""
    R=c.R;L0,L1=x0+8,x0+58;R0,R1=x0+58,x0+112
    c.tree(x0+122,base,46,30,dead=True)                                  # the big bare tree
    c.roof_band(R0,R1,base-48,16,moss=.4,holes=.4)
    c.gable_front(R0+20,R0+36,base-48,9,TAN,vent=False,over=2)            # dormer
    c.window(R0+25,base-55,6,5,'dark')
    c.siding(R0,base-48,R1,base,TAN,wear=.6)
    c.gable_front(L0,L1,base-48,20,TAN,over=3)
    c.siding(L0,base-48,L1,base,TAN,wear=.5)
    c.chimney(R1-14,base-72,base-58)
    # windows (blue shutters), one lit with a tiny cheese wedge in it
    c.window(L0+9,base-42,8,11,'dark',shut=SHUT_BLUE);c.window(L0+33,base-42,8,11,'lit',shut=SHUT_BLUE)
    for (dx,dy) in((0,0),(1,0),(2,0),(1,-1),(2,-1),(2,-2)):c.put(L0+36+dx,base-34+dy,(255,214,60))
    c.window(R0+10,base-42,8,11,'broken');c.window(R0+34,base-42,8,11,'boarded')
    c.window(L0+10,base-20,9,12,'curtain',shut=SHUT_BLUE)
    # porch: roof band across the front, columns (one gone), railing, two doors, steps
    py=base-26
    for x in range(L0-2,R1+3):
        for y in range(py-3,py+1):c.put(x,y,ROOF[2] if y<py else TRIM[1])
        c.put(x,py-4,MOON if R.random()<.6 else ROOF[3])
    cols=[L0,L0+26,R0+2,R0+28,R1-1]
    for i,cx_ in enumerate(cols):
        if i==3:c.line(cx_,base,cx_+9,base-4,TRIM[2]);continue            # the fallen column
        c.rect(cx_,py+1,cx_+1,base-2,TRIM[2]);c.rect(cx_,py+1,cx_,base-2,TRIM[3]);c.rect(cx_-1,base-2,cx_+2,base,TRIM[1])
    for x in range(L0,R1,3):
        if R.random()<.75 and not (L0+28<x<R0+14):c.rect(x,base-7,x,base-2,TRIM[1])
    c.rect(L0,base-8,L0+24,base-8,TRIM[2]);c.rect(R0+30,base-8,R1,base-8,TRIM[2])
    d1=(L0+40,base-19,8,19);d2=(R0+16,base-19,8,19)
    c.door(*d1,(70,44,48),'closed');c.door(*d2,(56,62,84),'open')
    for k in range(3):c.rect(R0+12-k*2,base+1+k,R0+28+k*2,base+1+k,TRIM[1-(k%2)])
    c.ivy(L0+2,base,30,6);c.ivy(R1-4,base,22,6)
    c.trampled(x0+2,x0+118,base,ground,paths=(d1[0]+4,d2[0]+4))
    c.bush(L0+8,ground-1,13,12);c.bush(L0+30,ground-1,10,10,dark=.4);c.bush(R1-6,ground-1,11,9)
    c.bins(x0+96,ground-1)
    for i in range(40):c.put(x0+R.randint(0,120),ground-1-R.randint(0,2),R.choice([(120,70,40),(140,90,44),(96,52,34)]))   # fallen leaves
    return dict(door=(d1[0]+d1[2]/2,d1[1]),bw=R1-L0,cx=(L0+R1)/2,x0=L0,x1=R1,drect=d1,feat=[('doorway',)+tuple(d2)])
BLUE=[(34,40,64),(48,56,86),(62,72,106),(80,92,128)];MAUVE=[(50,36,52),(70,52,72),(90,68,90),(112,88,110)]
SAGE=[(36,46,42),(52,64,58),(68,82,74),(86,100,90)];GREY=[(40,42,52),(56,58,70),(72,74,88),(92,94,108)]
MUST=[(56,48,30),(80,70,42),(102,90,54),(124,110,66)];ROSE=[(58,40,46),(80,58,64),(100,74,80),(122,94,98)]
OLIVE=[(46,48,34),(64,66,46),(82,86,60),(102,106,74)];PALEG=[(52,62,58),(72,84,80),(92,106,100),(114,128,120)]
CHAR=[(14,12,14),(24,20,22),(34,28,28),(46,38,36)]
def townhouses(c,x0,base,ground,units):
    """attached narrow townhouses: tall, cornices with brackets, bay windows, raised stoops. units: [(w,floors,pal,top)]"""
    R=c.R;x=x0;locks=[]
    for (w,fl,pal,top) in units:
        H=fl*24+4;y0=base-H
        if top=='gable':c.gable_front(x,x+w,y0,16,pal,over=2)
        elif top=='mansard':
            for y in range(y0-12,y0+1):
                ins=int((y0-y)*.45)
                for xx in range(x-1+ins,x+w+2-ins):c.put(xx,y,ROOF[2] if (y-y0)%3 else ROOF[1])
            c.window(x+w//2-3,y0-9,6,7,R.choice(['dark','broken']))
        c.siding(x,y0,x+w,base,pal,wear=.65)
        if top!='gable':                                              # cornice with brackets
            c.rect(x-2,y0-3,x+w+2,y0,TRIM[1]);c.rect(x-2,y0-3,x+w+2,y0-3,MOON)
            for bx in range(x,x+w+1,5):c.rect(bx,y0+1,bx+1,y0+2,TRIM[0])
        for f in range(1,fl):                                          # upper floors: two tall windows each
            wy=base-f*24-20
            for k,wx in enumerate((x+5,x+w-12)):c.window(wx,wy,7,13,R.choice(['dark','dark','broken','boarded','curtain','lit' if R.random()<.12 else 'dark']))
        bay=w>=34 and R.random()<.7
        sd=R.choice([-1,1]);dx=x+4 if sd<0 else x+w-12
        if bay:                                                       # a bay window box on the ground floor
            bx0=x+(15 if sd<0 else 3);bx1=bx0+w-20
            c.rect(bx0,base-21,bx1,base-5,pal[1]);c.rect(bx0,base-22,bx1,base-22,TRIM[2])
            for k in range(3):c.window(bx0+2+k*((bx1-bx0-4)//3),base-19,max(3,(bx1-bx0-4)//3-2),11,R.choice(['dark','broken','boarded']),glow=False)
        else:c.window(x+(16 if sd<0 else 4),base-19,10,12,R.choice(['dark','boarded','broken']))
        dy=base-22;c.door(dx,dy,8,18,R.choice([(60,40,44),(40,46,60),(54,50,40)]),R.choice(['closed','closed','open','boarded']))
        for k in range(4):c.rect(dx-1-k,base-4+k,dx+8+k,base-4+k,TRIM[1] if k%2 else TRIM[0])   # stoop
        c.rect(dx-5,base-12,dx-5,base-1,(40,40,50));c.rect(dx-5,base-12,dx-1,base-12,(40,40,50))
        if R.random()<.6:c.ivy(x+R.randint(2,w-2),base,R.randint(18,H),7)
        locks.append(dict(door=(dx+4,dy),bw=w,cx=x+w/2,x0=x,x1=x+w,drect=(dx,dy,8,18),feat=[('door',dx,dy,8,18)]))
        x+=w+1
    c.lawn(x0,x,base+1,1);c.weeds(x0,x,ground-1,3,12,.9,.3)
    return locks
def victorian(c,x0,base,ground,pal=None,word='HELP'):
    R=c.R;w=56;H=58;y0=base-H;MUST_=pal or MUST
    c.gable_front(x0,x0+w,y0,24,MUST_,over=3)
    for y in range(y0-16,y0-4):                                        # fish-scale shingles in the gable
        for x in range(x0+10,x0+w-10):
            if c.get(x,y)[:3] in [tuple(v) for v in MUST_] and (x+(y//3)%2*2)%4==0 and y%3==0:c.put(x,y,MUST_[0])
    c.siding(x0,y0,x0+w,base,MUST_,wear=.7)
    c.window(x0+10,y0+6,8,13,'boarded');c.window(x0+w-18,y0+6,8,13,'broken');c.window(x0+w//2-3,y0-11,6,8,'dark')
    c.window(x0+8,base-21,10,13,'curtain');d=(x0+w-18,base-20,8,20);c.door(*d,(52,30,34),'closed')
    py=base-27                                                         # porch with turned posts, sagging roof
    for x in range(x0-4,x0+w+5):
        sag=int(math.sin((x-x0+4)/(w+8)*math.pi)*3)
        for y in range(py-3+sag,py+1+sag):c.put(x,y,ROOF[2] if y<py+sag else TRIM[1])
    for cx_ in (x0-2,x0+20,x0+w+2):c.rect(cx_,py+2,cx_+1,base-1,TRIM[2])
    c.picket(x0-8,x0+w+10,ground-1,9,miss=.3,lean=.4)
    c.text(x0+6,base-36,word,(150,30,36),wob=1,drip=.5) if word else None
    c.ivy(x0+3,base,40,8);c.lawn(x0-8,x0+w+10,base+1,1);c.weeds(x0-8,x0+w+10,ground-2,4,14,.9,.4)
    return [dict(door=(d[0]+4,d[1]),bw=w,cx=x0+w/2,x0=x0,x1=x0+w,drect=d,feat=[('door',)+tuple(d),('window',x0+8,base-21,10,13)])]
def burned(c,x0,base,ground):
    """a burned-out house: black frame, the roof caved in, soot plumes above the windows, a scorched tree"""
    R=c.R;w=70;H=44;y0=base-H
    c.tree(x0+w+8,base,30,20,dead=True)
    c.siding(x0,y0,x0+w,base,CHAR,wear=1.4)
    for x in range(x0-2,x0+w+3):                                      # what's left of the roof: a broken ridge, rafters against the sky
        if R.random()<.55:
            top=y0-R.randint(0,14) if (x-x0)%9<3 else y0-R.randint(0,4)
            for y in range(top,y0+1):c.put(x,y,CHAR[R.randint(0,2)])
    for rx in range(x0+4,x0+w-2,8):c.line(rx,y0,rx+6,y0-14,CHAR[1])
    for x in range(x0,x0+w+1):                                       # sky through the caved-in middle
        for y in range(y0,y0+10):
            if abs(x-(x0+w*.55))<10-(y-y0)*.6 and R.random()<.9:c.P[x,y]=(0,0,0,0)
    for wx in (x0+8,x0+30,x0+52):
        c.rect(wx,base-36,wx+8,base-25,(6,4,6))
        for y in range(base-48,base-36):
            for x in range(wx-2,wx+11):
                if R.random()<.5*(1-(base-36-y)/12):c.shade(x,y,.55)
        c.rect(wx,base-18,wx+8,base-7,(6,4,6))
    c.rect(x0+22,base-20,x0+29,base,(4,2,4))
    for i in range(60):c.put(x0+R.randint(-6,w+6),base-R.randint(0,3),R.choice(CHAR+[(70,60,56),(90,40,30)]))   # rubble
    c.lawn(x0-4,x0+w+6,base+1,1);c.weeds(x0-4,x0+w+6,ground-1,3,10,.8,.6)
    return []
def ranch(c,x0,base,ground,pal=None,tarp=True):
    """a low ranch house: blue tarp on the roof, a collapsed carport, a smashed picture window; kiddie pool and a tire swing"""
    R=c.R;w=78;H=24;y0=base-H
    c.tree(x0+w+18,base,30,24,dense=1.2)
    for i in range(14):c.put(x0+w+14,base-30+i,(30,26,24))                # tire swing rope
    for dx in range(-3,4):
        for dy in range(-3,4):
            if 4<=dx*dx+dy*dy<=10:c.put(x0+w+14+dx,base-13+dy,(20,18,22))
    c.roof_band(x0,x0+w,y0,12,inset=10,moss=.5,holes=.2,tarp=(x0+22,x0+48) if tarp else None)
    c.siding(x0,y0,x0+w,base,pal or SAGE,wear=.7)
    c.rect(x0+6,base-18,x0+30,base-7,TRIM[1]);c.window(x0+7,base-17,22,9,'broken')
    d=(x0+38,base-18,8,18);c.door(*d,(60,52,40),'closed');c.window(x0+54,base-17,9,9,'boarded')
    cx0=x0+w;c.line(cx0,y0+2,cx0+26,base-2,ROOF[3]);c.line(cx0,y0+3,cx0+26,base-1,ROOF[1])   # carport roof slid off its posts
    c.rect(cx0+24,base-14,cx0+25,base,(60,60,72));c.line(cx0+8,base,cx0+14,base-12,(60,60,72))
    for x in range(x0+4,x0+22):c.put(x,ground-2,(40,90,130));c.put(x,ground-1,(30,60,96))   # kiddie pool
    c.rect(x0+4,ground-3,x0+21,ground-3,(70,130,170))
    c.lawn(x0-4,x0+w+30,base+1,1);c.weeds(x0-4,x0+w+30,ground-1,4,16,.95,.3)
    c.privacy(x0+w+2,x0+w+28,ground-1,12)
    return [dict(door=(d[0]+4,d[1]),bw=w,cx=x0+w/2,x0=x0,x1=x0+w,drect=d,feat=[('door',)+tuple(d),('window',x0+54,base-17,9,9)])]
def duplex(c,x0,base,ground,pal=None,word='KEEP OUT'):
    """a foreclosed grey duplex: everything boarded up, KEEP OUT sprayed across it, the FOR SALE sign face down in the weeds"""
    R=c.R;w=84;H=50;y0=base-H
    c.roof_band(x0,x0+w,y0,15,moss=.3,holes=.5)
    c.siding(x0,y0,x0+w,base,pal or GREY,wear=.6)
    for wx in (x0+8,x0+28,x0+50,x0+70):c.window(wx,y0+8,8,12,'boarded')
    c.window(x0+8,base-20,9,12,'boarded');c.window(x0+68,base-20,9,12,'broken')
    d1=(x0+28,base-20,8,20);d2=(x0+48,base-20,8,20);c.door(*d1,(56,56,64),'boarded');c.door(*d2,(56,56,64),'closed')
    c.text(x0+12,y0+25,word,(170,40,44),wob=1,drip=.3) if word else None
    c.bush(x0+10,ground-1,14,12,dark=.2);c.bush(x0+w-6,ground-1,16,14)
    c.line(x0+40,ground-2,x0+52,ground-6,(150,40,40));c.line(x0+40,ground-1,x0+52,ground-5,(170,170,180))   # FOR SALE sign down
    c.lawn(x0-4,x0+w+6,base+1,1);c.weeds(x0-4,x0+w+6,ground-1,4,15,.95,.35)
    return [dict(door=(d2[0]+4,d2[1]),bw=w,cx=x0+w/2,x0=x0,x1=x0+w,drect=d2,feat=[('door',)+tuple(d2)])]
def farmhouse(c,x0,base,ground,pal=None):
    """a tall pale-green farmhouse: a tree came down through the roof, the porch has given way"""
    R=c.R;w=60;H=54;y0=base-H
    c.gable_front(x0,x0+w,y0,22,pal or PALEG,over=3)
    c.siding(x0,y0,x0+w,base,pal or PALEG,wear=.7)
    c.window(x0+10,y0+8,8,13,'broken');c.window(x0+w-18,y0+8,8,13,'dark');c.window(x0+w//2-3,y0-12,6,7,'broken')
    c.window(x0+8,base-21,9,13,'broken');d=(x0+w-20,base-21,8,21);c.door(*d,(48,52,44),'closed')
    for x in range(x0-6,x0+w+6):                                      # the porch roof has dropped at one end
        y=base-27+int((x-(x0-6))/(w+12)*14)
        for t in range(3):c.put(x,y+t,ROOF[2] if t<2 else TRIM[1])
    tx,ty=x0+w+26,base                                                 # the fallen tree
    c.line(tx,ty,x0+w//2,y0-14,BARK[1]);c.line(tx+1,ty,x0+w//2+1,y0-14,BARK[0]);c.line(tx+2,ty,x0+w//2+2,y0-13,BARK[1])
    for i in range(6):
        bx,by=x0+w//2+R.randint(-14,10),y0-14+R.randint(-10,6)
        for j in range(int(60)):
            a=R.uniform(0,6.28);r=R.uniform(0,7);c.put(bx+math.cos(a)*r,by+math.sin(a)*r*.8,G[R.randint(1,4)])
    c.lawn(x0-6,x0+w+30,base+1,1);c.weeds(x0-6,x0+w+30,ground-1,5,17,.95,.3)
    c.chainlink(x0+w+4,x0+w+34,ground-1,11,holes=1,vines=.7)
    return [dict(door=(d[0]+4,d[1]),bw=w,cx=x0+w/2,x0=x0,x1=x0+w,drect=d,feat=[('door',)+tuple(d),('window',x0+8,base-21,9,13)])]
def vacant(c,x0,x1,base,ground):
    """a vacant lot behind a sagging chain-link fence: a dumped mattress, a rusted swing set, waist-high weeds"""
    R=c.R
    sx=x0+14
    for (a,b) in ((sx,sx+8),(sx+30,sx+22)):c.line(a,ground-1,b,base-22,(70,56,50));
    c.line(sx+8,base-22,sx+22,base-22,(84,68,60));c.line(sx+12,base-22,sx+11,base-10,(50,50,60));c.rect(sx+9,base-10,sx+14,base-10,(70,56,50))
    c.rect(x0+40,ground-5,x0+58,ground-2,(120,112,120));c.rect(x0+40,ground-5,x0+58,ground-5,(150,144,156))
    for i in range(10):c.put(x0+41+R.randint(0,16),ground-4+R.randint(0,2),(90,60,60))
    c.lawn(x0,x1,base+1,1);c.weeds(x0,x1,ground-1,6,20,1,.45)
    c.chainlink(x0,x1,ground-1,14,holes=2,vines=.8,sag=(x0+20,x0+44))
    return []
