"""0.12.387 neighborhood: sky tile, far layer (distant rooftops, a water tower, a steeple, tree lines, smoke), and the street (ground tile)."""
import sys;sys.path.insert(0,'/home/claude/pod2/art_src/hood')
from hood_lib import *
OUTD='/home/claude/pod2/art_src/hood/'
# ---- sky tile 48x160: deep violet with faint haze bands
sky=Canvas(48,160,1)
for y in range(160):
    for x in range(48):
        sky.put(x,y,(22,14,38))
        if y%9==0 and y>50 and (x+(y//9))%2==0:sky.put(x,y,(30,20,50))
sky.im.save(OUTD+'sky.png')
# ---- far layer 544x300 (tiles): a low skyline of rooftops and tree lines, a water tower, a church steeple, smoke from a fire
f=Canvas(544,300,23);R=f.R;S1=(38,28,60);S2=(42,32,66);S3=(50,38,78);RIM=(86,70,122)
x=0
while x<544:                                               # far rooftops: gables and flat tops, a few with a lit window
    w=R.randint(22,46);top=R.randint(205,240);kind=R.random()
    if kind<.55:
        ph=R.randint(8,16)
        for y in range(top-ph,300):
            hw=w/2 if y>=top else w/2*(y-(top-ph))/ph
            for xx in range(int(x+w/2-hw),int(x+w/2+hw)+1):f.put(xx%544,y,S1)
        for i in range(ph):f.put((x+w//2-int(w/2*i/ph))%544,top-ph+i,RIM)
    else:
        for y in range(top,300):
            for xx in range(x,x+w):f.put(xx%544,y,S1)
        for xx in range(x,x+w):f.put(xx%544,top,RIM)
    if R.random()<.3:
        wx=x+R.randint(4,w-6);wy=top+R.randint(8,18);f.rect(wx,wy,wx+1,wy+1,(104,78,56))
    x+=w+R.randint(-6,6)
x=0
while x<544:                                               # tree lines in front of the far roofs
    r=R.randint(8,18);cx=x;cy=R.randint(238,262)
    for i in range(r*r*3):
        a=R.uniform(0,6.28);rr=math.sqrt(R.random())*r;px=cx+math.cos(a)*rr;py=cy+math.sin(a)*rr*.8
        if py<300:f.put(int(px)%544,py,S2 if (py-cy)>-r*.4 else S3)
    for yy in range(cy,300):f.put(cx%544,yy,S2)
    x+=R.randint(8,16)
for yy in range(cy,300):pass
for y in range(262,300):                                   # fill under the trees
    for xx in range(544):
        if not f.get(xx,y)[3]:f.put(xx,y,S2)
# water tower
tx,ty=150,170
for (a,b) in ((tx-8,tx-4),(tx+8,tx+4)):f.line(a,262,b,ty+14,S3);
f.line(tx-6,240,tx+6,222,S3);f.line(tx+6,240,tx-6,222,S3)
f.rect(tx-12,ty,tx+12,ty+14,S3);f.poly([(tx-13,ty),(tx,ty-9),(tx+13,ty)],S3);f.rect(tx-12,ty+14,tx+12,ty+15,S2)
for i in range(13):f.put(tx-12+i,ty-i*9/13,RIM)
f.text(tx-9,ty+5,'MAPLE',(60,50,86))
# church steeple
sx=390
f.rect(sx-6,214,sx+6,262,S3);f.poly([(sx-7,214),(sx,182),(sx+7,214)],S3);f.line(sx,182,sx,174,S3);f.line(sx-3,177,sx+3,177,S3)
for i in range(32):f.put(sx-int(7*i/32),182+i,RIM)
f.rect(sx-2,224,sx+2,232,(18,12,26))
# smoke from a distant fire, and its glow on the underside
for (sx_,sw) in ((260,26),(470,18)):
    for yy in range(0,140):
        cx_=sx_+int(math.sin(yy*.05)*6)+int(yy*.15);ww=sw*(1-yy/170)
        for xx in range(int(cx_-ww/2),int(cx_+ww/2)):
            if R.random()<.45:f.put(xx%544,240-yy,(46,34,58,70))
    for xx in range(sx_-14,sx_+14):
        for yy in range(236,250):
            if R.random()<.35:f.put(xx%544,yy,(150,70,40,60))
f.im.save(OUTD+'far.png')
# ---- the street (272x48 tile, sp 1.0): grass verge and a heaved, weedy sidewalk on top; curb; cracked, patched asphalt
g=Canvas(272,48,31);R=g.R
for x in range(272):
    for y in range(48):g.put(x,y,(26,22,32) if R.random()<.8 else (32,28,38))
for x in range(272):                                         # rows 0-1: grass verge spilling over
    for y in range(0,2):g.put(x,y,G[R.randint(1,3)])
    if R.random()<.5:g.put(x,2,G[R.randint(1,2)])
for sx in range(0,272,17):                                   # rows 2-6: sidewalk slabs, some heaved and cracked, weeds in the joints
    tilt=R.choice([0,0,0,1]);c0=R.choice([(70,68,82),(76,74,88),(64,62,76)])
    for x in range(sx,min(272,sx+16)):
        for y in range(2,7):g.put(x,y,c0 if (y>2 or R.random()<.8) else (96,94,110))
        g.put(x,2,(100,98,116) if R.random()<.6 else c0)
    for y in range(2,7):g.put(sx+16 if sx+16<272 else 271,y,(30,28,36))
    if R.random()<.7:
        for y in range(2,7):g.put(sx+16 if sx+16<272 else 271,y,G[R.randint(2,4)])
    if R.random()<.5:
        cx=sx+R.randint(3,12)
        for y in range(2,7):cx+=R.choice([-1,0,1]);g.put(cx,y,(36,34,44))
    if tilt:
        for x in range(sx,sx+16):g.put(x,2,(120,118,136))
for x in range(272):g.put(x,7,(50,48,60));g.put(x,8,(14,12,18))   # curb + gutter shadow
for i in range(14):                                           # cracks webbing across the asphalt, weeds growing in them
    x=R.randint(0,271);y=R.randint(10,46)
    for j in range(R.randint(6,22)):
        x+=R.choice([-1,0,1]);y+=R.choice([-1,0,1,1])
        if 9<y<48:g.put(x%272,y,(12,10,16))
        if R.random()<.18 and 9<y<47:g.put(x%272,y-1,G[R.randint(2,4)])
for (px_,py_,pw,ph_) in ((40,22,10,4),(150,34,14,5),(220,16,8,3)):   # potholes and a patch
    for x in range(px_,px_+pw):
        for y in range(py_,py_+ph_):
            if ((x-px_-pw/2)/(pw/2))**2+((y-py_-ph_/2)/(ph_/2))**2<1:g.put(x,y,(14,12,18) if R.random()<.8 else (40,36,46))
for x in range(96,128):
    for y in range(12,20):g.put(x,y,(34,32,40) if R.random()<.9 else (40,38,48))
for x in range(0,272,34):                                    # a faded center line, mostly worn away
    for xx in range(x+4,x+18):
        if R.random()<.45:g.put(xx,27,(96,92,70))
for i in range(60):g.put(R.randint(0,271),R.randint(9,47),R.choice([(110,62,36),(130,84,40),(90,48,30)]))   # dead leaves
for (bx,by) in ((60,40),(196,20)):                            # blood stains
    for i in range(18):g.put(bx+R.randint(-6,6),by+R.randint(-1,2),BLOOD[R.randint(0,2)])
g.rect(176,9,186,10,(20,18,24));g.rect(176,9,186,9,(60,58,70))   # storm drain at the curb
for x in range(177,186,2):g.put(x,10,(6,4,8))
g.im.save(OUTD+'ground.png')
print('ok')
