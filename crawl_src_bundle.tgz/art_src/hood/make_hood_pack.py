"""0.12.387 pack the neighborhood layers into crawl_bg_hood.png and add BGA.hood to the atlas"""
import json
from PIL import Image
D='/home/claude/pod2/art_src/hood/'
mid,far,sky,gr=[Image.open(D+n+'.png').convert('RGBA') for n in ('mid','far','sky','ground')]
M=json.load(open(D+'mid.json'))
out=Image.new('RGBA',(mid.width,302+300),(0,0,0,0))
out.alpha_composite(mid,(0,0));out.alpha_composite(far,(0,302));out.alpha_composite(sky,(546,302));out.alpha_composite(gr,(596,302))
out.save('/home/claude/pod2/crawl_bg_hood.png',optimize=True)
s=.75
mid_l={'r':[0,0,mid.width,300],'y':-38.0,'sp':.35,'w':mid.width*s,'h':225.0,'tile':mid.width*s,'img':'bghood','lamps':M['lamps'],'ground':M['ground'],'houses':M['houses']}
A=json.load(open('/home/claude/pod2/crawl_atlas.json'))
A['bg']['hood']={'fill':'#160e26','top':'#07040e','artTop':67,'layers':[
  {'r':[546,302,48,160],'y':-38.0,'sp':.04,'w':36.0,'h':120.0,'tile':36.0,'img':'bghood'},
  {'r':[0,302,544,300],'y':-38.0,'sp':.12,'w':408.0,'h':225.0,'tile':408.0,'img':'bghood'},
  mid_l,
  {'r':[596,302,272,48],'y':181.0,'sp':1.0,'w':204.0,'h':36.0,'tile':204.0,'img':'bghood'}]}
json.dump(A,open('/home/claude/pod2/crawl_atlas.json','w'))
print(out.size,'houses',len(M['houses']))
