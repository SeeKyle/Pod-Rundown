"""0.12.393 (Kyle) Maple Hollow Ominous trail: grass knocked flat in a path leading back into the weeds between houses, a bloody drag
trail fading as it goes. 40x28, drawn 1:1 in world px like the other Ominous sprites; appended to crawl_portals.png at x=204."""
import sys,math,random;sys.path.insert(0,'/home/claude/pod2/art_src/hood')
from hood_lib import *
from PIL import Image
W,H=40,12;c=Canvas(W,H,393);R=c.R
top=(22,2);bot=(19,11)
def cx(y):return bot[0]+(top[0]-bot[0])*(bot[1]-y)/(bot[1]-top[1])
def hw(y):return 1.5+10*(y-top[1])/(bot[1]-top[1])
# the walls: the same weeds as the lot, bent outward and broken over the edges of the path (no taller than the weeds around it)
for y in range(top[1],H):
    for x in range(W):
        d=abs(x-cx(y))
        if hw(y)-.5<d<=hw(y)+3 and R.random()<.55:
            h=R.randint(1,3)+int(2*(y-top[1])/(bot[1]-top[1]));sd=1 if x>cx(y) else -1
            for j in range(h):c.put(x+sd*j*.5,y-j,(DRY+G[2:5])[R.randint(0,5)] if j<h-1 else (DRY[2] if R.random()<.5 else G[4]))
# the flattened floor: a pale lane of grass laid flat (streaks running back along it), worn to dirt in the middle
for y in range(top[1],H):
    for x in range(W):
        d=abs(x-cx(y))
        if d<=hw(y):
            k=d/max(1,hw(y));st=((x-int(cx(y))+y//2)%3==0)
            col=(70,60,50) if k<.25 and R.random()<.5 else (DRY[1] if st else DRY[0]) if R.random()<.7 else (G[4] if st else G[3])
            c.put(x,y,col)
# the drag: two smears down the middle, thick and wet by the sidewalk, thinning out toward the back
for y in range(top[1]+1,H):
    k=(y-top[1])/(bot[1]-top[1]);a=int(30+225*k**1.2)
    for off in(-2,2):
        x=cx(y)+off*(.4+.8*k)
        c.put(x,y,BLOOD[2] if k>.5 else BLOOD[1],a)
        if k>.45:c.put(x+(1 if off>0 else -1),y,BLOOD[1],a)
for i in range(18):
    y=R.randint(H-5,H-1);x=cx(y)+R.uniform(-hw(y)*.7,hw(y)*.7);c.put(x,y,BLOOD[2] if R.random()<.5 else BLOOD[1],230)
for x in range(int(cx(H-1))-6,int(cx(H-1))+7):
    if R.random()<.8:c.put(x,H-1,BLOOD[1],230)
for (dx,dy) in((0,0),(1,0),(2,0),(0,-1),(1,-1),(2,-1),(-1,-2),(0,-2),(1,-3),(2,-2),(3,-1)):c.put(cx(9)+5+dx,9+dy,BLOOD[2],230)   # a smeared handprint
# the dark gap at the back where the path disappears into the deep grass
for y in range(0,top[1]+2):
    for x in range(W):
        if ((x-top[0])/3.2)**2+((y-top[1]+.3)/1.8)**2<=1:c.put(x,y,(8,6,12))
for x in range(top[0]-4,top[0]+5):                  # blades hanging over the top of the gap
    for j in range(1):c.put(x,max(0,top[1]-2+j),(DRY+G[2:4])[R.randint(0,4)])
# night grade to sit with the street art
for y in range(H):
    for x in range(W):
        p=c.P[x,y]
        if p[3]:c.P[x,y]=(int(p[0]*.86),int(p[1]*.85),int(min(255,p[2]*.92+4)),p[3])
c.im.save(D:='/home/claude/pod2/art_src/hood/grasstrail.png')
P=Image.open('/home/claude/pod2/crawl_portals.png').convert('RGBA');print('portals sheet',P.size)
base=P.crop((0,0,204,76));out=Image.new('RGBA',(244,76),(0,0,0,0));out.alpha_composite(base,(0,0));out.alpha_composite(c.im,(204,0))
out.save('/home/claude/pod2/crawl_portals.png',optimize=True)
pv=Image.new('RGBA',(W,H),(30,22,40,255));pv.alpha_composite(c.im);pv.resize((W*10,H*10),Image.NEAREST).save('/tmp/grasstrail_pv.png')
