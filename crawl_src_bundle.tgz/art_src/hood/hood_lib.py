"""0.12.387 (Kyle) The neighborhood level: drawing kit. Side-on elevation like the city, night palette (purple sky, moonlight from the
upper left), everything worn down and overgrown. Art px; the game draws the backdrop at 0.75 scale."""
import random, math
from PIL import Image
MOON=(178,166,214);OUT=(10,8,16)
WIN_DARK=(12,10,22);WIN_GLASS=(34,36,62);WIN_REFL=(84,90,134)
WARM=(255,204,120);WARM2=(236,156,76);WARM3=(160,92,48)
G=[(14,22,20),(20,32,26),(30,46,32),(42,62,38),(58,82,46),(82,104,56),(108,126,66)]
DRY=[(88,80,50),(112,102,60),(138,124,72)]
BARK=[(24,20,24),(36,30,32),(52,44,44),(70,60,56)]
ROOF=[(22,20,30),(32,30,42),(44,42,56),(58,56,72),(74,72,90)]
MOSS=[(40,54,36),(54,72,42),(70,90,50)]
BOARD=[(70,54,42),(98,78,56),(124,100,70)]
TRIM=[(70,68,86),(104,102,122),(140,138,160),(176,174,194)]
BLOOD=[(70,12,20),(100,18,26),(130,28,32)]
class Canvas:
    def __init__(s,W,H,seed=1):
        s.W,s.H=W,H;s.im=Image.new('RGBA',(W,H),(0,0,0,0));s.P=s.im.load();s.R=random.Random(seed)
    def put(s,x,y,c,a=255):
        x,y=int(round(x)),int(round(y))
        if 0<=x<s.W and 0<=y<s.H:
            if len(c)==4:a=c[3];c=c[:3]
            if a>=255:s.P[x,y]=c+(255,)
            elif a>0:
                o=s.P[x,y]
                if o[3]==0:s.P[x,y]=c+(a,)
                else:k=a/255;s.P[x,y]=tuple(int(o[i]*(1-k)+c[i]*k) for i in range(3))+(max(o[3],a),)
    def get(s,x,y):
        x,y=int(x),int(y)
        return s.P[x,y] if 0<=x<s.W and 0<=y<s.H else (0,0,0,0)
    def rect(s,x0,y0,x1,y1,c,a=255):
        for y in range(int(y0),int(y1)+1):
            for x in range(int(x0),int(x1)+1):s.put(x,y,c,a)
    def shade(s,x,y,k):
        c=s.get(x,y)
        if c[3]:s.P[int(x),int(y)]=tuple(max(0,min(255,int(v*k))) for v in c[:3])+(c[3],)
    def tintto(s,x,y,c,k):
        o=s.get(x,y)
        if o[3]:s.P[int(x),int(y)]=tuple(int(o[i]*(1-k)+c[i]*k) for i in range(3))+(o[3],)
    def line(s,x0,y0,x1,y1,c,a=255):
        n=int(max(abs(x1-x0),abs(y1-y0)))+1
        for i in range(n+1):t=i/max(1,n);s.put(x0+(x1-x0)*t,y0+(y1-y0)*t,c,a)
    def poly(s,pts,c):
        ys=[p[1] for p in pts];
        for y in range(int(min(ys)),int(max(ys))+1):
            xs=[]
            for i in range(len(pts)):
                (x1,y1),(x2,y2)=pts[i],pts[(i+1)%len(pts)]
                if (y1<=y+.5<y2) or (y2<=y+.5<y1):xs.append(x1+(y+.5-y1)*(x2-x1)/(y2-y1))
            xs.sort()
            for i in range(0,len(xs)-1,2):
                for x in range(int(math.ceil(xs[i]-.5)),int(math.floor(xs[i+1]-.5))+1):s.put(x,y,c)
    # ------------------------------------------------------------------ building parts
    def siding(s,x0,y0,x1,y1,pal,wear=.5,lap=4,vertical=False):
        """lap siding (rows of boards), moonlit left edge, grime toward the ground, missing boards, peeling paint, rust/water streaks"""
        R=s.R
        for y in range(y0,y1+1):
            for x in range(x0,x1+1):
                b=(x-x0) if vertical else (y-y0)
                ph=b%lap;c=pal[2] if ph not in(lap-1,) else pal[1]
                if ph==0 and R.random()<.6:c=pal[3]
                if R.random()<.05:c=pal[1] if c==pal[2] else pal[2]
                s.put(x,y,c)
        for y in range(y0,y1+1):s.put(x0,y,MOON,120);s.put(x1,y,pal[0])
        for y in range(y1-14,y1+1):                                     # grime and damp near the ground
            k=(y-(y1-14))/14
            for x in range(x0,x1+1):
                if R.random()<k*.8:s.shade(x,y,.78)
        for i in range(int((x1-x0)*(y1-y0)/260*wear)):                   # missing or split boards: dark sheathing showing
            bw=R.randint(4,12);by=y0+lap*R.randint(0,max(0,(y1-y0)//lap-1));bx=R.randint(x0+1,max(x0+1,x1-bw-1))
            for x in range(bx,bx+bw):
                for y in range(by,by+lap-1):s.put(x,y,(40,30,30) if R.random()<.8 else (28,20,22))
            s.put(bx+bw,by,pal[0])
        for i in range(int((x1-x0)*wear/3)):                             # peeling paint flecks
            s.put(R.randint(x0,x1),R.randint(y0,y1),pal[3] if R.random()<.5 else (pal[0]))
        for i in range(int((x1-x0)*wear/18)):                            # water streaks running down
            sx=R.randint(x0+1,x1-1);sy=R.randint(y0,y1-10);L=R.randint(6,24)
            for y in range(sy,min(y1,sy+L)):s.shade(sx,y,.8)
    def window(s,x,y,w,h,kind='dark',shut=None,trim=None,glow=True):
        trim=trim or TRIM;R=s.R
        s.rect(x-1,y-1,x+w,y+h,trim[1]);s.rect(x-1,y-1,x+w,y-1,trim[2]);s.rect(x-2,y+h,x+w+1,y+h+1,trim[2]);s.rect(x-2,y+h+1,x+w+1,y+h+1,trim[0])
        if kind=='lit':
            for yy in range(y,y+h):
                k=(yy-y)/max(1,h-1);c=tuple(int(WARM3[i]*(1-k)+WARM[i]*k*.95) for i in range(3))
                for xx in range(x,x+w):s.put(xx,yy,c)
            cx=x+R.randint(1,max(1,w-3))                                  # a figure / furniture shape in the light
            for yy in range(y+h-R.randint(3,6),y+h):s.put(cx,yy,WARM3);s.put(cx+1,yy,WARM3)
            if glow:
                for yy in range(y-6,y+h+7):
                    for xx in range(x-6,x+w+6):
                        d=max(0,max(x-xx,xx-(x+w-1),0)+max(y-yy,yy-(y+h-1),0))
                        if 0<d<=6 and s.get(xx,yy)[3]:s.tintto(xx,yy,WARM2,.32*(1-d/6.5))
        else:
            s.rect(x,y,x+w-1,y+h-1,WIN_DARK)
            for i in range(min(w,h)):                                    # moon reflection streak
                if R.random()<.8 and kind=='dark':s.put(x+w-2-i,y+i+1,WIN_GLASS)
            if kind=='broken':
                for i in range(R.randint(3,6)):                          # jagged shards stuck in the frame
                    side=R.choice('tblr');L=R.randint(1,max(1,min(w,h)//2))
                    for j in range(L):
                        if side=='t':s.put(x+R.randint(0,w-1),y+j,WIN_REFL)
                        elif side=='b':s.put(x+R.randint(0,w-1),y+h-1-j,WIN_REFL)
                        elif side=='l':s.put(x+j,y+R.randint(0,h-1),WIN_REFL)
                        else:s.put(x+w-1-j,y+R.randint(0,h-1),WIN_REFL)
            if kind=='curtain':
                for xx in range(x,x+w):
                    L=h-1 if (xx-x)<w//2 else R.randint(h//3,h-2)
                    for yy in range(y,y+L):s.put(xx,yy,(76,66,90) if (xx+yy)%3 else (96,84,110))
            if kind=='boarded':
                s.rect(x,y,x+w-1,y+h-1,(20,16,22))
                rows=[y+1,y+h//2,y+h-3] if h>8 else [y+1,y+h-3]
                for i,by in enumerate(rows):
                    tilt=R.choice([-1,0,0,1]);bx0=x-2;bx1=x+w+1
                    for xx in range(bx0,bx1+1):
                        yy=by+int(tilt*(xx-bx0)/max(1,bx1-bx0)*2)
                        s.put(xx,yy,BOARD[1]);s.put(xx,yy+1,BOARD[0]);
                        if xx==bx0+1 or xx==bx1-1:s.put(xx,yy,(30,26,26))
                    s.put(bx0,by,BOARD[2])
            if kind not in('boarded','curtain','broken'):
                s.rect(x+w//2,y,x+w//2,y+h-1,trim[0]);s.rect(x,y+h//2,x+w-1,y+h//2,trim[0])
        if shut:
            for sx in (x-4,x+w+1):
                if R.random()<.15:continue                                 # one gone
                drop=R.choice([0,0,0,2])
                for yy in range(y-1+drop,y+h+drop):
                    s.put(sx,yy,shut[1]);s.put(sx+1,yy,shut[1] if (yy%3) else shut[0]);s.put(sx+2,yy,shut[0])
    def door(s,x,y,w,h,col,state='closed',trim=None,lit=False):
        trim=trim or TRIM;s.rect(x-1,y-1,x+w,y+h-1,trim[1]);s.rect(x-1,y-1,x+w,y-1,trim[2])
        if state=='open':
            s.rect(x,y,x+w-1,y+h-1,(6,4,10));s.rect(x-3,y,x-1,y+h-1,col);s.rect(x-3,y,x-3,y+h-1,(col[0]//2,col[1]//2,col[2]//2))
        else:
            s.rect(x,y,x+w-1,y+h-1,col);c2=tuple(max(0,v-18) for v in col)
            s.rect(x+1,y+h//2+1,x+w-2,y+h-3,c2);s.rect(x+1,y+2,x+w-2,y+h//2-1,c2) if not lit else None
            if lit:s.rect(x+1,y+2,x+w-2,y+5,WARM2);s.rect(x+2,y+3,x+w-3,y+4,WARM)
            s.put(x+w-2,y+h//2+1,(190,170,110))
            if state=='boarded':
                for i in range(3):
                    yy=y+3+i*(h//3);s.line(x-1,yy,x+w,yy+R.choice([-1,1]) if (R:=s.R) else yy,BOARD[1])
    def gable_front(s,x0,x1,ye,ph,pal,roof=ROOF,vent=True,over=3,moss=0):
        """a gable end facing the street: siding triangle + thick rakes"""
        cx=(x0+x1)/2;top=ye-ph
        for y in range(int(top),ye+1):
            k=(y-top)/ph;hw=(x1-x0)/2*k
            for x in range(int(cx-hw),int(cx+hw)+1):
                c=pal[2] if (y-top)%4!=3 else pal[1]
                if s.R.random()<.05:c=pal[1]
                s.put(x,y,c)
        if vent:
            vy=int(top+ph*.45);s.rect(cx-2,vy,cx+2,vy+4,TRIM[1]);
            for yy in range(vy+1,vy+4):s.rect(cx-1,yy,cx+1,yy,(20,18,28) if yy%2 else TRIM[0])
        for side in(-1,1):                                               # rakes
            for i in range(int(ph)+over+1):
                x=cx+side*((x1-x0)/2+over)*i/(ph+over);y=top+i*(ph+over)/(ph+over) - 1
                for t in range(3):s.put(x,y+t,roof[1] if t else (MOON if side<0 else roof[3]))
                s.put(x,y+3,roof[0])
        for yy in range(int(top)-2,int(top)+1):s.put(cx,yy,roof[3])
    def roof_band(s,x0,x1,ye,h,roof=ROOF,inset=0,moss=.3,holes=.3,tarp=None):
        """a side-gabled (ridge along the street) or hipped roof seen face on: shingle courses, moonlit ridge, moss, missing shingles"""
        R=s.R
        for y in range(ye-h,ye+1):
            k=(y-(ye-h))/h;ins=int(inset*(1-k))
            for x in range(x0-2+ins,x1+3-ins):
                row=(y-(ye-h))//3;c=roof[2] if (y-(ye-h))%3 else roof[1]
                if ((x+row*3)%7==0) and (y-(ye-h))%3:c=roof[1]
                if R.random()<.06:c=roof[3]
                s.put(x,y,c)
        for x in range(x0-2+inset,x1+3-inset):s.put(x,ye-h,MOON if R.random()<.7 else roof[4]);s.put(x,ye-h+1,roof[3])
        for x in range(x0-3,x1+4):s.put(x,ye+1,TRIM[1]);s.put(x,ye+2,TRIM[0])   # fascia + gutter
        for i in range(int((x1-x0)*moss/6)):                                     # moss carpets
            mx=R.randint(x0,x1);my=R.randint(ye-h+3,ye-1);r=R.randint(2,5)
            for dx in range(-r,r+1):
                for dy in range(-1,2):
                    if R.random()<.7 and s.get(mx+dx,my+dy)[3]:s.put(mx+dx,my+dy,MOSS[R.randint(0,2)])
        for i in range(int((x1-x0)*holes/14)):                                    # missing shingles: dark holes and bare boards
            hx=R.randint(x0+2,x1-6);hy=R.randint(ye-h+3,ye-4);hw=R.randint(2,6)
            for dx in range(hw):
                for dy in range(R.randint(1,3)):s.put(hx+dx,hy+dy,(14,10,14) if R.random()<.6 else BOARD[0])
        if tarp:
            tx0,tx1=tarp;
            for y in range(ye-h+2,ye-2):
                for x in range(tx0,tx1):
                    if s.R.random()<.97:s.put(x,y,(44,62,110) if (x+y)%5 else (60,82,138))
            for x in range(tx0,tx1,6):s.put(x,ye-h+2,(20,20,24))
    def chimney(s,x,ytop,ybot,w=6):
        for y in range(ytop,ybot):
            for xx in range(x,x+w):s.put(xx,y,(58,40,44) if (y//2+xx//3)%2 else (72,48,50))
            s.put(x,y,(96,80,110))
        s.rect(x-1,ytop-2,x+w,ytop-1,(40,36,46));s.rect(x-1,ytop-2,x+w,ytop-2,MOON)
    def gutter_hang(s,x,ye,L,side=1):
        for i in range(L):s.put(x+side*i//3,ye+2+i,TRIM[0])
    # ------------------------------------------------------------------ plants
    def weeds(s,x0,x1,base,hmin=4,hmax=14,dens=.9,dry=.25):
        R=s.R
        for x in range(x0,x1+1):
            n=1 if R.random()<dens else 0
            if R.random()<dens*.6:n+=1
            for k in range(n):
                h=R.randint(hmin,hmax);lean=R.uniform(-.35,.35);isdry=R.random()<dry
                pal=DRY if isdry else G[2:]
                for j in range(h):
                    xx=x+lean*j;c=pal[min(len(pal)-1,int(j/h*len(pal)))]
                    s.put(xx,base-j,c)
                if R.random()<.18:s.put(x+lean*h,base-h-1,(150,140,96) if isdry else (120,140,90))   # seed head
    def lawn(s,x0,x1,base,h):
        R=s.R
        for y in range(base-h,base+1):
            for x in range(x0,x1+1):s.put(x,y,G[R.randint(1,3)])
    def bush(s,cx,base,rw,rh,dark=0):
        R=s.R
        for i in range(int(rw*rh/2.2)):
            a=R.uniform(0,6.283);r=math.sqrt(R.random())
            x=cx+math.cos(a)*rw*r;y=base-rh+math.sin(a)*rh*r*.95
            if y>base:continue
            k=(-(x-cx)/rw-(y-(base-rh))/rh)*.5+.5+R.uniform(-.25,.25)-dark*.3
            c=G[max(0,min(5,int(1+k*4)))]
            for dx,dy in((0,0),(1,0),(0,1)):s.put(x+dx,y+dy,c)
        for i in range(int(rw*1.2)):                                     # moonlit top-left leaves
            a=R.uniform(3.4,4.9);x=cx+math.cos(a)*rw*R.uniform(.7,1);y=base-rh+math.sin(a)*rh*R.uniform(.7,1)
            s.put(x,y,G[5] if R.random()<.6 else (120,136,150))
    def tree(s,cx,base,th,cr,lean=0,dense=1.0,dead=False):
        R=s.R;tw=max(3,int(cr/5))
        for j in range(th):                                              # trunk
            k=j/th;w=tw*(1-.4*k);x=cx+lean*k*th
            for dx in range(-int(w/2),int(w/2)+1):s.put(x+dx,base-j,BARK[1] if dx<0 else BARK[0]);
            s.put(x-int(w/2),base-j,BARK[2])
        top=(cx+lean*th,base-th)
        for b in range(R.randint(3,5)):                                  # main limbs
            a=-math.pi/2+R.uniform(-1.1,1.1);L=cr*R.uniform(.5,.9);x,y=top
            for i in range(int(L)):x+=math.cos(a);y+=math.sin(a)*.8;a+=R.uniform(-.15,.15);s.put(x,y,BARK[1]);s.put(x+1,y,BARK[0]) if i<L*.5 else None
        if dead:
            for b in range(14):
                a=-math.pi/2+R.uniform(-1.4,1.4);L=cr*R.uniform(.3,1);x,y=top[0]+R.uniform(-cr*.3,cr*.3),top[1]+R.uniform(-cr*.3,cr*.1)
                for i in range(int(L)):
                    x+=math.cos(a);y+=math.sin(a)*.8;a+=R.uniform(-.25,.25);s.put(x,y,BARK[2] if i%4 else BARK[1])
                    if R.random()<.12:s.put(x+R.choice([-1,1]),y-1,BARK[1])
            return
        blobs=[(top[0]+R.uniform(-cr*.8,cr*.8),top[1]-cr*.3+R.uniform(-cr*.7,cr*.5),cr*R.uniform(.35,.6)) for _ in range(int(10*dense))]
        for (bx,by,br) in sorted(blobs,key=lambda b:b[1]):
            for i in range(int(br*br*2.2)):
                a=R.uniform(0,6.283);r=math.sqrt(R.random())*br;x=bx+math.cos(a)*r;y=by+math.sin(a)*r*.85
                k=(-(math.cos(a)*r)/br*.5-(math.sin(a)*r)/br*.6)*.5+.42+R.uniform(-.2,.2)+(top[1]-y)/(cr*4)
                c=G[max(0,min(5,int(k*5)))];s.put(x,y,c);s.put(x+1,y,c)
            for i in range(int(br*1.4)):
                a=R.uniform(3.5,4.9);x=bx+math.cos(a)*br*R.uniform(.75,1);y=by+math.sin(a)*br*.85*R.uniform(.75,1)
                s.put(x,y,(116,132,150) if R.random()<.4 else G[5])
    def ivy(s,x,ybase,h,w=6,only_on=True):
        R=s.R
        for v in range(max(2,w//2)):
            px_,py=x+R.randint(-w//2,w//2),ybase
            for i in range(h):
                px_+=R.choice([-1,0,0,1]);py-=1
                if only_on and not s.get(px_,py)[3]:break
                if R.random()<.8:s.put(px_,py,G[R.randint(1,3)])
                if R.random()<.45:s.put(px_+R.choice([-1,1]),py,G[R.randint(2,4)])
    # ------------------------------------------------------------------ fences and junk
    def chainlink(s,x0,x1,base,h=12,holes=1,vines=.4,sag=None):
        R=s.R;post=(84,86,100);mesh=(70,72,92)
        for x in range(x0,x1+1):
            top=base-h
            if sag and sag[0]<=x<=sag[1]:top+=int(math.sin((x-sag[0])/(sag[1]-sag[0])*math.pi)*4)
            for y in range(top+1,base):
                if ((x+y)%3==0 or (x-y)%3==0) and R.random()<.92:s.put(x,y,mesh,200)
            s.put(x,top,post);s.put(x,top+1,(50,52,66))
        for x in range(x0,x1+1,R.randint(16,22)):s.rect(x,base-h-1,x+1,base,post);s.put(x,base-h-1,MOON)
        for i in range(holes):
            hx=R.randint(x0+4,max(x0+5,x1-8));hy=base-R.randint(4,h-2);rw=R.randint(2,4)
            for xx in range(hx-rw,hx+rw+1):
                for yy in range(hy-rw,hy+rw+1):
                    if (xx-hx)**2+(yy-hy)**2<=rw*rw and s.get(xx,yy)[:3]==mesh:s.P[xx,yy]=(0,0,0,0)
        for i in range(int((x1-x0)*vines/8)):s.ivy(R.randint(x0,x1),base,R.randint(4,h+2),4,False)
    def picket(s,x0,x1,base,h=10,col=(112,108,126),miss=.15,lean=.2):
        R=s.R;c2=tuple(max(0,v-30) for v in col)
        s.rect(x0,base-h+3,x1,base-h+3,c2);s.rect(x0,base-3,x1,base-3,c2)
        x=x0
        while x<=x1:
            if R.random()>miss:
                ln=R.choice([0]*6+[-1,1]) if R.random()<lean else 0;hh=h-R.choice([0,0,0,1,3])
                for j in range(hh):
                    xx=x+ln*j//4;s.put(xx,base-j,col if (j%5) else c2);s.put(xx+1,base-j,c2)
                s.put(x+ln*hh//4,base-hh,MOON)
            x+=3
    def privacy(s,x0,x1,base,h=14,col=(66,52,46)):
        R=s.R
        for x in range(x0,x1+1,3):
            if R.random()<.12:continue
            hh=h-(R.randint(2,7) if R.random()<.2 else 0)
            for j in range(hh):
                s.put(x,base-j,col);s.put(x+1,base-j,tuple(v+10 for v in col));s.put(x+2,base-j,tuple(max(0,v-16) for v in col))
            s.put(x+1,base-hh,(118,104,96))
    def mailbox(s,x,base,col=(60,62,80),lean=0):
        for j in range(9):s.put(x+lean*j//6,base-j,BOARD[0])
        s.rect(x-3+lean,base-13,x+3+lean,base-9,col);s.rect(x-3+lean,base-13,x+3+lean,base-13,MOON);s.put(x+3+lean,base-12,(150,40,40))
    def bins(s,x,base,col=(40,70,140)):
        for b in range(2):
            bx=x+b*9
            s.rect(bx,base-11,bx+6,base,col);s.rect(bx-1,base-12,bx+7,base-11,tuple(int(v*1.25) for v in col));s.rect(bx,base-11,bx,base,tuple(min(255,int(v*1.5)) for v in col))
            s.rect(bx+1,base-8,bx+5,base-8,tuple(int(v*.7) for v in col));s.put(bx+6,base,(20,20,24));s.put(bx+1,base,(20,20,24))
FONT={'A':'010101111101101','B':'110101110101110','C':'011100100100011','D':'110101101101110','E':'111100110100111','F':'111100110100100',
 'G':'011100101101011','H':'101101111101101','I':'111010010010111','K':'101101110101101','L':'100100100100111','M':'101111111101101',
 'N':'110101101101101','O':'010101101101010','P':'110101110100100','R':'110101110101101','S':'011100010001110','T':'111010010010010',
 'U':'101101101101111','W':'101101111111101','Y':'101101010010010','Z':'111001010100111','!':'010010010000010',' ':'000000000000000',
 '2':'110001010100111','0':'111101101101111','X':'101101010101101','V':'101101101101010'}
def _text(c,x,y,s_,col,wob=0,drip=0):
    R=c.R
    for ch in s_:
        g=FONT.get(ch,FONT[' ']);oy=R.choice([0,0,1]) if wob else 0
        for k in range(15):
            if g[k]=='1':c.put(x+k%3,y+k//3+oy,col)
        if drip and R.random()<drip:
            dx=R.randint(0,2)
            for j in range(R.randint(1,4)):c.put(x+dx,y+5+oy+j,col)
        x+=4
Canvas.text=_text
def _lamp_post(c,ax,ay,ground,side=1):
    """a residential street light: pole, a short arm, the head housing (the game lights the lens live)"""
    px=ax+side*9
    for y in range(ay-3,ground):c.put(px,y,(44,44,58));c.put(px+side,y,(30,30,40))
    c.put(px,ay-3,MOON)
    for x in range(min(ax,px),max(ax,px)+1):c.put(x,ay-3,(52,52,68));c.put(x,ay-4,(36,36,48))
    c.rect(ax-3,ay-3,ax+4,ay-1,(40,40,52));c.rect(ax-3,ay-3,ax+4,ay-3,(84,84,104))
Canvas.lamp_post=_lamp_post
def _pole(c,x,top,ground):
    for y in range(top,ground):c.put(x,y,(48,38,36));c.put(x+1,y,(34,26,26))
    c.rect(x-9,top+3,x+10,top+4,(44,34,32));
    for ix in (x-8,x-3,x+4,x+9):c.put(ix,top+2,(120,130,150));c.put(ix,top+1,(90,100,120))
    if c.R.random()<.6:c.rect(x+2,top+8,x+5,top+14,(54,56,64));c.put(x+2,top+8,MOON)    # a transformer can
Canvas.pole=_pole
def _wires(c,poles,top):
    for i in range(len(poles)-1):
        a,b=poles[i],poles[i+1]
        for k,(ox,sag) in enumerate(((-8,9),(4,12),(9,10))):
            x0,x1=a+ox,b+ox
            if c.R.random()<.15 and k==2:            # a snapped line hanging down
                for t in range(int((x1-x0)*.4)):c.put(x0+t,top+2+t*t/(x1-x0)*2.2,(14,12,18))
                continue
            for x in range(x0,x1+1):
                u=(x-x0)/max(1,x1-x0);c.put(x,top+2+sag*4*u*(1-u),(26,22,34))
Canvas.wires=_wires
def _trampled(c,x0,x1,base,ground,paths=()):
    """0.12.387 (Kyle): grass trampled flat in front of the two lived-in places: blades lying over, a few short tufts, a worn footpath to the door"""
    R=c.R
    for y in range(base+1,ground):
        for x in range(x0,x1+1):
            if not c.get(x,y)[3] or c.get(x,y)[:3] in [tuple(v) for v in G+DRY]:c.put(x,y,G[R.randint(1,2)])
    for i in range(int((x1-x0)*2.2)):                       # flattened blades: short strokes lying almost sideways
        x=R.randint(x0,x1);y=R.randint(base+1,ground-1);L_=R.randint(3,6);d=R.choice([-1,1]);col=R.choice(G[2:5]+DRY[:2])
        for j in range(L_):c.put(x+d*j,y-(j//3),col)
    for i in range(int((x1-x0)*.35)):                       # a few short tufts still standing
        x=R.randint(x0,x1)
        for j in range(R.randint(2,4)):c.put(x,ground-1-j,G[2+j])
    for px_ in paths:                                        # a worn dirt path where everyone walks in and out
        for y in range(base+1,ground):
            w=3+(y-base)//3
            for x in range(int(px_-w),int(px_+w)+1):
                if R.random()<.85:c.put(x,y,(52,44,40) if R.random()<.7 else (64,54,48))
Canvas.trampled=_trampled
