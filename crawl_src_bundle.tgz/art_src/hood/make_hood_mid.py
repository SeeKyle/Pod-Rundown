"""0.12.387 (Kyle) the neighborhood street (mid layer): about twice the length of the downtown loop. Writes mid.png + mid.json."""
import sys,json;sys.path.insert(0,'/home/claude/pod2/art_src/hood')
from hood_houses import *
W,H=2176,300;GROUND=292;BASE=283
c=Canvas(W,H,seed=387)
R=c.R
# ---- big trees and dead trees behind the houses, so the roofline breaks up against the sky
for x in range(30,W,R.randint(70,110)):
    xx=x+R.randint(-20,20)
    if 150<xx<262:continue   # keep the sky open over Kyle's place
    if R.random()<.25:c.tree(xx,BASE-6,60,26,dead=True)
    else:c.tree(xx,BASE-6,56+R.randint(0,16),30+R.randint(0,12),lean=R.uniform(-.1,.1),dense=1.2)
L=[]   # lock points: (door x, kind, building width, door top)
def add(locks,kind='house'):
    for d in locks:L.append(dict(x=round(d['door'][0],1),kind=kind,bw=round(d['bw'],1),door=list(d['drect']),feat=[list(f) for f in d['feat']]))
add(townhouses(c,6,BASE,GROUND,[(36,3,BLUE,'mansard'),(32,2,MAUVE,'gable'),(38,3,SAGE,'flat')]))
k=kyle_house(c,128,BASE,GROUND);add([k],'kyle')
vacant(c,304,372,BASE,GROUND)
add(victorian(c,392,BASE,GROUND,MUST,'HELP'))
add(ranch(c,476,BASE,GROUND,SAGE,True))
add(townhouses(c,616,BASE,GROUND,[(40,3,ROSE,'flat'),(36,2,GREY,'mansard')]))
burned(c,702,BASE,GROUND)
z=cheez_house(c,800,BASE,GROUND);add([z],'cheez')
add(duplex(c,948,BASE,GROUND,GREY,'KEEP OUT'))
add(farmhouse(c,1052,BASE,GROUND,PALEG))
add(townhouses(c,1162,BASE,GROUND,[(34,2,OLIVE,'gable'),(38,3,BLUE,'flat'),(32,3,ROSE,'mansard')]))
add(ranch(c,1290,BASE,GROUND,MAUVE,False))
add(victorian(c,1430,BASE,GROUND,ROSE,None))
vacant(c,1508,1574,BASE,GROUND)
add(duplex(c,1586,BASE,GROUND,OLIVE,'NO'))
add(townhouses(c,1684,BASE,GROUND,[(38,3,GREY,'mansard'),(36,2,SAGE,'gable')]))
add(farmhouse(c,1776,BASE,GROUND,BLUE))
burned(c,1878,BASE,GROUND)
add(townhouses(c,1974,BASE,GROUND,[(36,3,MUST,'flat'),(34,2,PALEG,'gable'),(36,3,MAUVE,'mansard')]))
c.weeds(2088,W-1,GROUND-1,5,18,1,.45)
# ---- 0.12.387 (Kyle: way more worn down and overgrown): fences along every yard (gates left open at the doors), waist-high weeds,
#      ivy up the walls, vines hanging off the gutters, saplings growing out of the roofs
doors=[d['x'] for d in L]+[f[1]+f[3]/2 for d in L for f in d['feat']]
x=0;FT=['picket','chain','privacy','picket','none','chain','picket','privacy']
while x<W-10:
    seg=R.randint(40,90);kind=FT[R.randint(0,len(FT)-1)];x1=min(W-4,x+seg)
    if x1>124 and x<300:x1=min(x1,124)
    if x1>796 and x<930:x1=min(x1,796)
    if 124<=x<300 or 796<=x<930:x=x+6;continue   # Kyle's and Cheez's: no fence out front, they stand apart
    if kind!='none':
        pieces=[];a0=x
        for dx in sorted(d for d in doors if x<d<x1):pieces.append((a0,int(dx-7)));a0=int(dx+7)
        pieces.append((a0,x1))
        for (p0,p1) in pieces:
            if p1-p0<6:continue
            if kind=='picket':c.picket(p0,p1,GROUND-1,R.randint(8,11),col=R.choice([(104,100,118),(92,96,110),(110,96,100)]),miss=.25,lean=.35)
            elif kind=='chain':c.chainlink(p0,p1,GROUND-1,R.randint(10,13),holes=1,vines=.9)
            else:c.privacy(p0,p1,GROUND-1,R.randint(11,15),col=R.choice([(66,52,46),(56,46,44),(70,60,52)]))
    x=x1+R.randint(2,10)
for (a0,a1,hm,dn) in ((0,124,22,.4),(300,796,22,.4),(930,W-1,22,.4)):c.weeds(a0,a1,GROUND-1,7,hm,dn,.4)   # (not in front of Kyle's and Cheez's: trampled there)   # the tall stuff, in front of the fences (lower in front of Kyle's and Cheez's)
for i in range(70):
    bx=R.randint(0,W-1)
    if 128<bx<300 or 796<bx<930:continue
    c.bush(bx,GROUND-1,R.randint(5,11),R.randint(5,10),dark=R.random()*.5)
for i in range(160):                                   # ivy: start anywhere along the base of a wall and climb
    xx=R.randint(0,W-1)
    if 140<xx<290 or 806<xx<925:continue
    c.ivy(xx,BASE,R.randint(10,46),R.randint(4,9))
for y in range(150,BASE-10):                          # vines draping off gutters: under any roof-edge pixel with sky below
    for xx in range(0,W):
        p=c.P[xx,y];q=c.P[xx,y+1]
        if p[3] and p[:3]==TRIM[0] and q[3] and R.random()<.035:
            L_=R.randint(3,11)
            for j in range(1,L_):c.put(xx+(j//4)*R.choice([0,1]),y+j,G[R.randint(1,3)])
for i in range(40):                                   # saplings and weeds out of the roofs and gutters
    xx=R.randint(0,W-1)
    for y in range(140,BASE-20):
        if c.P[xx,y][3] and c.P[xx,y][:3] in (ROOF[1],ROOF[2],ROOF[3],TRIM[1]) and not c.P[xx,y-1][3]:
            h=R.randint(3,9)
            for j in range(h):c.put(xx+R.choice([0,0,1,-1])*(j>2),y-1-j,G[2+min(3,j//2)])
            if h>6:c.bush(xx,y-h+3,3,3)
            break
# ---- street lights and power poles along the curb (wires run across the seam so the loop is clean)
LAMPS=[];st=['ok','flicker','dead','ok','dying','broken','ok','sputter','flicker','ok']
for i,ax in enumerate(range(100,W,230)):
    ay=GROUND-44;c.lamp_post(ax,ay,GROUND,side=1 if i%2 else -1);LAMPS.append([ax+.5,ay,st[i%len(st)],round(R.random(),3)])
poles=list(range(60,W,272))
for p in poles:c.pole(p,GROUND-92,GROUND)
c.wires([poles[-1]-W]+poles+[poles[0]+W],GROUND-92)
# ---- final grade: a touch darker and cooler so it sits at night with the other levels
for y in range(H):
    for x in range(W):
        p=c.P[x,y]
        if p[3]:c.P[x,y]=(int(p[0]*.86),int(p[1]*.85),int(min(255,p[2]*.92+4)),p[3])
c.im.save('/home/claude/pod2/art_src/hood/mid.png')
json.dump(dict(lamps=LAMPS,houses=L,ground=GROUND,base=BASE),open('/home/claude/pod2/art_src/hood/mid.json','w'))
print(len(L),'lock points',len(LAMPS),'lamps')
