"""0.12.394 (Kyle): aim-up / aim-down versions of every hero's ranged attack. The upper body (arms + gun) tilts around the hips; the legs stay
planted. Rows are appended to each hero's sheet; atlas gets 'rangedUp' and 'rangedDown'. Re-runnable (strips rows it added before)."""
import json,numpy as np
from PIL import Image
P='/home/claude/pod2/';A=json.load(open(P+'crawl_atlas.json'));U=A['units']
UP,DOWN=22,18
done={}
for k,v in U.items():
    R=v.get('ranged')
    if not R or 'img' not in R or k.startswith(('zombie','werewolf','screamer','skarcher','bloater','dog','kid','tentacle')):continue
    img=R['img'];fn=P+'crawl_'+img+'.png'
    if img not in done:
        im=Image.open(fn).convert('RGBA')
        base_h=A.get('_aimBase',{}).get(img,im.height)
        done[img]=[im.crop((0,0,im.width,base_h)),base_h,[]]
    sheet,base_h,adds=done[img]
    fw,fh,n,x0,y0=R['fw'],R['fh'],R['n'],R['x'],R['y']
    frames=[sheet.crop((x0+i*fw,y0,x0+(i+1)*fw,y0+fh)) for i in range(n)]
    m=np.zeros((fh,fw),bool)
    for f in frames:m|=np.array(f)[:,:,3]>0
    ys=np.where(m.any(1))[0];top,bot=ys.min(),ys.max();hip=int(top+(bot-top)*.56)
    xs=np.where(m[hip])[0];px=int(xs.mean()) if len(xs) else fw//2
    faceR=bool(R.get('faceR'))
    rows=[]
    for ang in (UP,-DOWN):
        a=ang if faceR else -ang
        row=[]
        for f in frames:
            arr=np.array(f);lower=arr.copy();lower[:hip-1]=0
            upper=arr.copy();upper[hip+1:]=0
            ui=Image.fromarray(upper).rotate(a,resample=Image.NEAREST,center=(px,hip))
            o=Image.fromarray(lower);o.alpha_composite(ui);row.append(o)
        rows.append(row)
    adds.append((k,R,rows))
for img,(sheet,base_h,adds) in done.items():
    W=sheet.width;need=sum(2*R['fh'] for k,R,rows in adds);out=Image.new('RGBA',(max(W,max(R['fw']*R['n'] for k,R,_ in adds)),base_h+need),(0,0,0,0))
    out.alpha_composite(sheet,(0,0));y=base_h
    for k,R,rows in adds:
        for nm,row in zip(('rangedUp','rangedDown'),rows):
            for i,f in enumerate(row):out.alpha_composite(f,(i*R['fw'],y))
            e=dict(R);e['x']=0;e['y']=y;U[k][nm]=e;y+=R['fh']
    out.save(P+'crawl_'+img+'.png',optimize=True);A.setdefault('_aimBase',{})[img]=base_h
    print(img,'+',len(adds),'heroes',out.size)
json.dump(A,open(P+'crawl_atlas.json','w'))
