exec(open('/tmp/abom/anims.py').read())
walk,toss,death=make();globs=glob_frames();spl=splash_frames()
S=5
rows=[('WALK',walk),('TOSS',toss),('DEATH (bursts)',death)]
cw=W*S+8;sheet=Image.new('RGBA',(cw*8+120,(H*S+24)*3+80),(40,44,54,255));d=ImageDraw.Draw(sheet)
for r,(n,fr) in enumerate(rows):
    y=r*(H*S+24)+20;d.text((6,y-16),n,fill=(255,230,120,255))
    for i,f in enumerate(fr):sheet.alpha_composite(f.resize((W*S,H*S),Image.NEAREST),(i*cw+4,y))
y=3*(H*S+24)+10;d.text((6,y),'glob in flight + splash',fill=(255,230,120,255))
x=200
for g in globs:sheet.alpha_composite(g.resize((g.width*S,g.height*S),Image.NEAREST),(x,y+10));x+=g.width*S+10
for s_ in spl:sheet.alpha_composite(s_.resize((s_.width*S,s_.height*S),Image.NEAREST),(x,y+10));x+=s_.width*S+10
sheet.save('/tmp/abom/Bloater_frames.png')
# animated GIFs (3x) on a dark backdrop, walk loops, toss + glob, death
def gif(frames,name,dur):
    bg=(30,30,38)
    out=[]
    for f in frames:
        b=Image.new('RGBA',(f.width*4,f.height*4),bg+(255,));b.alpha_composite(f.resize((f.width*4,f.height*4),Image.NEAREST));out.append(b.convert('P',palette=Image.ADAPTIVE))
    out[0].save(f'/tmp/abom/{name}.gif',save_all=True,append_images=out[1:],duration=dur,loop=0,disposal=2)
gif(walk,'Bloater_walk',170)
# toss with the glob flying off to the left and splashing
seq=[]
for f in toss:seq.append(f)
fly=[]
for k in range(5):
    c=Image.new('RGBA',(W*2,H),(0,0,0,0));c.alpha_composite(toss[-1],(W,0));g=globs[k%2]
    c.alpha_composite(g,(W-6-k*12,6+k*k*2));fly.append(c)
sp=[]
for s_ in spl:
    c=Image.new('RGBA',(W*2,H),(0,0,0,0));c.alpha_composite(toss[-1],(W,0));c.alpha_composite(s_,(W-70,GY-9));sp.append(c)
wide=[Image.new('RGBA',(W*2,H),(0,0,0,0)) for _ in seq]
for w_,f in zip(wide,seq):w_.alpha_composite(f,(W,0))
gif(wide+fly+sp+[wide[-1]]*3,'Bloater_toss',[140,140,170,110,140,160]+[70]*5+[110]*3+[300]*3 and 120)
gif(death+[death[-1]]*4,'Bloater_death',150)
print('ok')
