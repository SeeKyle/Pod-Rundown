from PIL import Image, ImageDraw
import random, math
OUT=(18,12,14,255)
M=[(54,10,14,255),(86,16,20,255),(122,24,28,255),(160,40,38,255),(196,74,64,255)]       # meat, dark -> light
PINK=[(150,70,84,255),(196,108,118,255),(232,156,160,255)]                               # intestine
WASTE=[(64,52,22,255),(96,78,30,255),(126,104,44,255)]                                    # brown/olive muck
BONE=[(170,160,136,255),(222,212,186,255)]
BLOOD=(120,20,24,255);BLOOD2=(80,14,18,255);BLOOD3=(170,30,32,255);BRIGHT=(214,40,40,255)
def outline(im,col=OUT):
    p=im.load();W,H=im.size;edge=[]
    for y in range(H):
        for x in range(W):
            if p[x,y][3]==0 and any(0<=x+a<W and 0<=y+b<H and p[x+a,y+b][3]>0 and p[x+a,y+b]!=col for a,b in((1,0),(-1,0),(0,1),(0,-1))):edge.append((x,y))
    for x,y in edge:p[x,y]=col
def gutball():
    """13x13: a lumpy ball of meat with a loop of intestine, a smear of brown muck and a bone shard poking out"""
    S=13;im=Image.new('RGBA',(S,S),(0,0,0,0));p=im.load();R=random.Random(4);c=6
    for y in range(S):
        for x in range(S):
            dx,dy=x-c,y-c;r=math.hypot(dx,dy);lump=4.6+.7*math.sin(math.atan2(dy,dx)*3+1)+.3*math.sin(math.atan2(dy,dx)*5)
            if r<=lump:
                l=.55-.18*dx/5-.22*dy/5-.25*(r/lump)**2+R.uniform(-.12,.12);p[x,y]=M[max(0,min(4,int(l*5)))]
    # intestine loop
    for t in range(0,64):
        a=t/64*math.pi*2;x=c+math.cos(a)*2.6+math.cos(a*2)*.8;y=c-1+math.sin(a)*1.9
        xi,yi=round(x),round(y)
        if p[xi,yi][3]:p[xi,yi]=PINK[1] if math.sin(a)<.2 else PINK[2]
        if p[xi,yi+1][3] and math.sin(a)>.3:p[xi,yi+1]=PINK[0]
    # waste smear (lower right)
    for (x,y) in ((8,8),(9,8),(8,9),(9,9),(10,8),(7,9),(9,10)):
        if p[x,y][3]:p[x,y]=WASTE[R.randint(0,2)]
    # bone shard poking out top-right
    for (x,y,k) in ((9,3,1),(10,2,1),(11,1,1),(10,3,0),(11,2,0)):p[x,y]=BONE[k]
    # wet highlights + drips
    p[4,3]=M[4];p[3,4]=M[4];p[5,3]=(230,120,110,255)
    for (x,y) in ((5,11),(5,12),(7,12)):p[x,y]=BLOOD3 if y<12 else BLOOD
    outline(im)
    return im
def spin(base,n=4):
    return [base.rotate(-90*i,resample=Image.NEAREST) for i in range(n)]
def splash_frames():
    """72x48 ground-anchored burst, bottom centre at (36,46). Sampled from a little particle sim: a wet blob explodes,
    globs of blood and chunks of meat/gut/bone fly out in a fan, fall back and land in a spreading pool."""
    W,H=72,48;cx,gy=36,45;R=random.Random(31);G=520.0
    P=[]
    for i in range(46):    # blood globs
        a=R.uniform(math.pi*.06,math.pi*.94);sp=R.uniform(70,190);P.append(dict(x=cx+R.uniform(-3,3),y=gy-3,vx=math.cos(a)*sp*1.2,vy=-math.sin(a)*sp,r=R.choice([0,0,1,1,1,2]),c=R.choice([BLOOD3,BRIGHT,BLOOD,BLOOD3]),chunk=0))
    for i in range(14):    # chunks
        a=R.uniform(math.pi*.12,math.pi*.88);sp=R.uniform(80,170);P.append(dict(x=cx,y=gy-4,vx=math.cos(a)*sp*1.25,vy=-math.sin(a)*sp,w=R.choice([2,3,2]),h=R.choice([2,2,1]),c=[M[1],PINK[1],M[2],WASTE[1],BONE[1],PINK[2],M[3]][i%7],chunk=1))
    times=[.015,.05,.1,.17,.26,.38]
    out=[]
    for k,t in enumerate(times):
        im=Image.new('RGBA',(W,H),(0,0,0,0));p=im.load();d=ImageDraw.Draw(im)
        def put(x,y,c):
            x,y=round(x),round(y)
            if 0<=x<W and 0<=y<H:p[x,y]=c
        # pool on the ground
        w=[7,13,19,23,26,27][k]
        for x in range(cx-w,cx+w+1):
            f=1-abs(x-cx)/max(1,w)
            for y in range(gy-int(1+2.2*f),gy+2):put(x,y,BLOOD2 if y>=gy-1 or abs(x-cx)>w-2 else BLOOD)
        # the burst cloud: an irregular wet blob that swells and tears apart
        if k<=2:
            rr=[5,8,10][k];cy=gy-[4,7,9][k]
            for y in range(cy-rr,cy+rr+1):
                for x in range(cx-int(rr*1.5),cx+int(rr*1.5)+1):
                    nx=(x-cx)/(rr*1.5);ny=(y-cy)/rr;q=nx*nx+ny*ny+.35*math.sin(x*1.3+k)*math.sin(y*1.1)
                    if q<1 and (k==0 or (k==1 and (q>.45 or (x+y)%3==0)) or (k==2 and q>.7 and (x*7+y*3)%3==0)):
                        put(x,y,(BRIGHT if q<.3 else BLOOD3 if q<.65 else BLOOD) if k<2 else (BLOOD3 if q<.7 else BLOOD))
            if k==0:
                for x in range(cx-3,cx+4):put(x,gy-6,PINK[2]);put(x,gy-5,PINK[1])
        # particles
        for q in P:
            x=q['x']+q['vx']*t;y=q['y']+q['vy']*t+.5*G*t*t
            landed=y>=gy
            if landed:y=gy-R.choice([0,1]);
            if q['chunk']:
                for a2 in range(q['w']):
                    for b2 in range(q['h'] if not landed else 1):put(x+a2,y-b2,q['c'])
            else:
                r=q['r'] if not landed else 0
                if r==0:put(x,y,q['c'] if not landed else BLOOD2)
                elif r==1:
                    for a2 in (0,1):
                        for b2 in (0,1):put(x+a2,y+b2,q['c'])
                    put(x,y,(236,96,90,255))
                else:
                    for a2 in range(-1,2):
                        for b2 in range(-1,2):
                            if abs(a2)+abs(b2)<2 or (a2,b2)==(1,1):put(x+a2,y+b2,q['c'])
                    put(x-1,y-1,(236,96,90,255))
                    vy=q['vy']+G*t
                    if abs(vy)>40:put(x,y-r-1 if vy>0 else y+r+1,BLOOD)   # streak
        # outline the chunks/globs so they read on any ground
        out.append(im)
    CH={M[1],PINK[1],M[2],WASTE[1],BONE[1],PINK[2],M[3]}
    for im in out:
        p=im.load();edge=[]
        for y in range(H):
            for x in range(W):
                if p[x,y][3]==0 and any(0<=x+a<W and 0<=y+b<H and p[x+a,y+b] in CH for a,b in((1,0),(-1,0),(0,1),(0,-1))):edge.append((x,y))
        for x,y in edge:p[x,y]=(30,8,10,230)
    return out
def splat():
    """56x12 decal: blood pool with bits of meat, intestine and muck; drawn on the ground and faded out over time"""
    W,H=56,12;im=Image.new('RGBA',(W,H),(0,0,0,0));p=im.load();R=random.Random(9);cx,cy=28,6
    for y in range(H):
        for x in range(W):
            nx=(x-cx)/27;ny=(y-cy)/5.3;r=nx*nx+ny*ny+.18*math.sin(x*.9)*math.sin(y*1.7)
            if r<1:p[x,y]=BLOOD2 if r>.55 else (BLOOD if R.random()<.8 else BLOOD3)
    for i in range(22):
        x=R.randint(6,49);y=R.randint(2,9)
        if p[x,y][3]:
            c=R.choice([M[1],M[2],PINK[1],PINK[2],WASTE[1],WASTE[2],BONE[1],M[3]]);p[x,y]=c
            if R.random()<.4 and x+1<W:p[x+1,y]=c
    for (x,y) in ((3,6),(2,7),(53,5),(54,6),(10,1),(46,10)):p[x,y]=BLOOD2
    return im
if __name__=='__main__':
    b=gutball();fr=spin(b);sp=splash_frames();sl=splat()
    S=8;sheet=Image.new('RGBA',(920,520),(46,50,60,255))
    x=10
    for f in fr:sheet.alpha_composite(f.resize((f.width*S,f.height*S),Image.NEAREST),(x,10));x+=f.width*S+12
    for i,f in enumerate(sp):sheet.alpha_composite(f.resize((f.width*4,f.height*4),Image.NEAREST),(10+(i%3)*(72*4+12),110+(i//3)*200))
    sheet.alpha_composite(sl.resize((sl.width*4,sl.height*4),Image.NEAREST),(500,20))
    sheet.save('/tmp/abom/gut_test.png')
