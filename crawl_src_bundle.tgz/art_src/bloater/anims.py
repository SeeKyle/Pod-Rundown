exec(open('/tmp/abom/bloater.py').read())
FA0=[(12,23),(8,34),(7,44)];EA0=[(40,22),(47,31),(49,41)]
def sw(pts,dx,dy=0,k=1):return [(x+dx*(i/(len(pts)-1))**k,y+dy*(i/(len(pts)-1))) for i,(x,y) in enumerate(pts)]
WALK=[
 dict(fl=(-2,0),bl=(2,0),dy=1,jig=1,fa=sw(FA0,2),ea=sw(EA0,-2),gutarm=(0,0),head=(0,1)),
 dict(fl=(-1,0),bl=(1,2),dy=0,jig=0,fa=sw(FA0,1),ea=sw(EA0,-1),gutarm=(1,-1),head=(0,0)),
 dict(fl=(0,0),bl=(0,1),dy=-1,jig=-1,fa=sw(FA0,0),ea=sw(EA0,0),gutarm=(0,-1),head=(0,-1)),
 dict(fl=(2,0),bl=(-2,0),dy=1,jig=1,fa=sw(FA0,-2),ea=sw(EA0,2),gutarm=(-1,0),head=(0,1)),
 dict(fl=(1,2),bl=(-1,0),dy=0,jig=0,fa=sw(FA0,-1),ea=sw(EA0,1),gutarm=(0,1),head=(0,0)),
 dict(fl=(0,1),bl=(0,0),dy=-1,jig=-1,fa=sw(FA0,0),ea=sw(EA0,0),gutarm=(1,0),head=(0,-1)),
]
TOSS=[
 dict(lean=1,fa=[(12,23),(16,32),(24,38)],head=(1,0),mouth=1,gutarm=(1,1)),
 dict(lean=2,dy=-1,fa=[(12,23),(16,30),(22,33)],glob=(22,31,2.6),spin=1,head=(1,-1),gutarm=(1,0)),
 dict(lean=3,dy=-1,fa=[(13,22),(19,13),(26,7)],glob=(27,5,3),spin=2,ea=[(40,22),(50,26),(56,32)],head=(2,-1),gutarm=(0,-1)),
 dict(lean=-2,dy=1,squash=1,fa=[(12,23),(5,15),(1,9)],ea=[(40,22),(47,29),(50,37)],head=(-2,1),gutarm=(-1,0)),
 dict(lean=-1,dy=1,fa=[(12,23),(4,30),(2,38)],head=(-1,1),gutarm=(-1,1)),
 dict(lean=0,fa=FA0,head=(0,0),gutarm=(0,0)),
]
DEATH=[
 dict(lean=2,head=(2,-2),mouth=1,fa=[(12,23),(6,30),(2,35)],ea=[(40,22),(50,27),(56,30)]),
 dict(lean=1,jig=3,head=(1,-2),mouth=1,fa=[(12,23),(4,27),(0,30)],ea=[(40,22),(51,25),(58,27)]),
 dict(lean=1,jig=2,burst=1,head=(1,-1),fa=[(12,23),(4,29),(1,33)],ea=[(40,22),(50,28),(55,33)]),
 dict(lean=0,dy=5,burst=1,head=(0,1),fa=[(12,23),(7,32),(5,40)]),
 dict(lean=-2,dy=10,burst=1,head=(-2,2),fa=[(12,23),(5,30),(1,36)]),
 dict(lean=-3,dy=14,burst=1,head=(-3,3),fa=[(12,23),(4,28),(0,32)]),
]
def burst_fx(im,P,k):
    """gut explodes: bile + blood spray out of the wound"""
    R=random.Random(11+k);p=im.load();d=ImageDraw.Draw(im);dy=P.get('dy',0)
    cx,cy=32,38+dy
    d.ellipse([cx-6,cy-5,cx+5,cy+5],fill=BLOOD2);d.ellipse([cx-4,cy-3,cx+3,cy+3],fill=(40,10,12,255))
    n=[60,30,14][min(2,k)];rr=[12,16,18][min(2,k)]
    for i in range(n):
        a=R.uniform(-math.pi*.95,math.pi*.15);r=R.uniform(3,rr)
        x=round(cx+math.cos(a)*r);y=round(cy+math.sin(a)*r*.8)
        if 0<=x<W and 0<=y<H:p[x,y]=R.choice([BLOOD,BLOOD3,GUT.PINK[1],GUT.PINK[2],BLOOD2,GUT.M[2],GUT.WASTE[1]])
def puddle(im,k):
    p=im.load();R=random.Random(5)
    w=[16,22,26][k]
    for x in range(28-w,28+w):
        for y in range(GY-1,GY+2):
            if 0<=x<W and abs(x-28)<w-R.randint(0,3):
                p[x,y]=R.choice([BLOOD2,BLOOD,GUT.WASTE[0],BLOOD2]) if y>GY-1 or R.random()<.5 else p[x,y]
def make():
    walk=[frame(P,seed=7) for P in WALK]
    toss=[frame(P,seed=7) for P in TOSS]
    death=[]
    for i,P in enumerate(DEATH):
        f=frame(P,seed=7)
        if P.get('burst'):burst_fx(f,P,i-2)
        if i>=3:puddle(f,min(2,i-3))
        death.append(f)
    # last two: slumps into a heap in the puddle (no tipping over)
    for k,(dyy,ln,hd) in enumerate(((17,-4,(-4,5)),(19,-4,(-5,7)))):
        P=dict(lean=ln,dy=dyy,burst=1,head=hd,mouth=0,fa=[(12,23),(4,26),(1,28)],ea=[(40,22),(48,25),(53,27)],jig=-1)
        f=frame(P,seed=7);q=f.load()
        for y in range(GY+1,H):
            for x in range(W):q[x,y]=(0,0,0,0)
        burst_fx(f,P,2)
        g=Image.new('RGBA',(W,H),(0,0,0,0));puddle(g,2);
        if k==1:
            gq=g.load()
            for x in range(0,W):
                if gq[x,GY][3]:gq[x,GY-2 if x%5==0 else GY-1]=BLOOD2
        g.alpha_composite(f);death.append(g)
    return walk,toss,death
def glob_frames():
    out=[]
    for k in range(2):
        g=Image.new('RGBA',(9,9),(0,0,0,0));q=g.load()
        for y in range(9):
            for x in range(9):
                dx=x-4+(k*.5);dy=y-4;r=3.4 if k==0 else 3.1
                if dx*dx/(1.1 if k else 1)+dy*dy*(1.1 if k else 1)<=r*r:q[x,y]=BILE[1] if dx+dy>1 else BILE[2]
        q[3,2]=BILE[3];q[5,6]=BLOOD;q[4,6]=BLOOD2
        out.append(g)
    return out
def splash_frames():
    out=[];R=random.Random(3)
    for k in range(3):
        s=Image.new('RGBA',(24,10),(0,0,0,0));q=s.load()
        for i in range([40,30,18][k]):
            a=R.uniform(math.pi,2*math.pi);r=R.uniform(1,[6,10,11][k])
            x=round(12+math.cos(a)*r*1.1);y=round(8+math.sin(a)*r*.6)
            if 0<=x<24 and 0<=y<10:q[x,y]=R.choice([BILE[1],BILE[2],BILE[0],BLOOD])
        for x in range(12-[4,7,9][k],12+[4,7,9][k]):q[x,9]=BILE[0] if x%2 else BILE[1]
        out.append(s)
    return out

IDLE=[dict(),dict(jig=1),dict(dy=1,jig=1,head=(0,1)),dict(dy=1,jig=0,head=(0,1))]
