exec(open('/tmp/abom/anims.py').read())
import json
walk,toss,death=make();idle=[frame(P,seed=7) for P in IDLE]
balls=GUTBALL;burst=GUT.splash_frames();spl=GUT.splat()
FW,FH=64,68;Y0=4*FH
sheet=Image.new('RGBA',(8*FW,Y0+16+48),(0,0,0,0))
for r,fr in enumerate((walk,toss,idle,death)):
    for i,f in enumerate(fr):sheet.alpha_composite(f,(i*FW,r*FH))
for i,b in enumerate(balls):sheet.alpha_composite(b,(i*13,Y0))
sheet.alpha_composite(spl,(60,Y0+2))
for i,b in enumerate(burst):sheet.alpha_composite(b,(i*72,Y0+16))
sheet.save('/home/claude/pod2/crawl_bloater.png',optimize=True)
U=dict(fw=FW,fh=FH,ax=26,ay=66,img='bloater',pre=.88)
meta={'walk':dict(U,n=6,x=0,y=0),'atk':dict(U,n=6,x=0,y=FH),'idle':dict(U,n=4,x=0,y=2*FH),'die':dict(U,n=8,x=0,y=3*FH,pre=round(.88*.88,4)),
      'ball':dict(fw=13,fh=13,n=4,ax=6,ay=6,x=0,y=Y0,img='bloater'),'splat':dict(fw=56,fh=12,n=1,ax=28,ay=6,x=60,y=Y0+2,img='bloater'),
      'burst':dict(fw=72,fh=48,n=6,ax=36,ay=46,x=0,y=Y0+16,img='bloater')}
A=json.load(open('/home/claude/pod2/crawl_atlas.json'));A['units']['bloater']=meta;json.dump(A,open('/home/claude/pod2/crawl_atlas.json','w'))
# preview
S=4;pv=Image.new('RGBA',(sheet.width*S,sheet.height*S),(46,50,60,255));pv.alpha_composite(sheet.resize((sheet.width*S,sheet.height*S),Image.NEAREST));pv.save('/tmp/abom/sheet_pv.png')
print(sheet.size)
