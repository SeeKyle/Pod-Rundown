from PIL import Image, ImageDraw
import random, math
OUT=(18,20,26,255)
SKIN=[(54,62,64,255),(78,90,90,255),(104,118,114,255),(134,148,140,255),(164,176,164,255)]
PEACH=[(104,66,58,255),(150,100,84,255),(196,142,112,255),(222,178,146,255)]
PANTS=[(34,30,34,255),(52,46,48,255),(72,62,60,255),(92,80,74,255)]
SHIRT=[(58,44,72,255),(84,64,102,255),(112,88,132,255),(140,116,156,255)]
GINGER=[(110,46,22,255),(158,74,34,255),(198,108,52,255)]
STITCH=(186,176,150,255);STD=(40,34,34,255);BLOOD=(120,20,24,255);BLOOD2=(80,14,18,255);BLOOD3=(160,34,34,255)
BILE=[(70,88,30,255),(110,132,40,255),(158,176,62,255),(200,214,110,255)]
W,H=64,68;GY=65   # canvas; feet rest on row GY
SRC=Image.open('/tmp/abom/zb_atk1.png').convert('RGBA')
FACE=SRC.crop((33,13,41,21))
import importlib.util as _u
_sp=_u.spec_from_file_location('gut','/tmp/abom/gut.py');GUT=_u.module_from_spec(_sp);_sp.loader.exec_module(GUT)
GUTBALL=GUT.spin(GUT.gutball())
GUTARM=SRC.crop((38,8,51,23)).transpose(Image.FLIP_LEFT_RIGHT)
def _clean_arm(a):
    a=a.copy();q=a.load();w,h=a.size
    for y in range(h):
        for x in range(w):
            r,g,b,al=q[x,y]
            if al and (r>150 and g>110 and b<90 and abs(r-g)<70):q[x,y]=(0,0,0,0)    # drop the blonde hair strands
    big=Image.new('RGBA',(w+2,h+2),(0,0,0,0));big.alpha_composite(a,(1,1));q=big.load()
    edge=[(x,y) for y in range(h+2) for x in range(w+2) if q[x,y][3]==0 and any(0<=x+i<w+2 and 0<=y+j<h+2 and q[x+i,y+j][3] for i,j in((1,0),(-1,0),(0,1),(0,-1)))]
    for x,y in edge:q[x,y]=OUT
    return big
GUTARM=_clean_arm(GUTARM)   # the creepy reaching arm from concept A, now coming out of the gut, reaching toward the middle
def stitches(d,pts):
    for i in range(len(pts)-1):
        (x0,y0),(x1,y1)=pts[i],pts[i+1];n=max(abs(x1-x0),abs(y1-y0))
        for k in range(n+1):
            x=round(x0+(x1-x0)*k/max(1,n));y=round(y0+(y1-y0)*k/max(1,n));d.point((x,y),fill=STD)
            if k%3==1:
                a=math.atan2(y1-y0,x1-x0)+math.pi/2;d.point((round(x+math.cos(a)),round(y+math.sin(a))),fill=STITCH);d.point((round(x-math.cos(a)),round(y-math.sin(a))),fill=STITCH)
def outline(im):
    p=im.load();edge=[]
    for y in range(H):
        for x in range(W):
            if p[x,y][3]==0 and any(0<=x+a<W and 0<=y+b<H and p[x+a,y+b][3]>0 and p[x+a,y+b]!=OUT for a,b in((1,0),(-1,0),(0,1),(0,-1))):edge.append((x,y))
    for x,y in edge:p[x,y]=OUT
def frame(P,seed=7):
    """P: pose dict. dy body bob; fl/bl front/back leg (dx, lift); fa front arm points; ea extra arm points; head (dx,dy,mouth); jig gut jiggle;
       extra drawing hooks: glob (x,y,r) held/thrown, burst (0..1), lean (px)"""
    R=random.Random(seed);im=Image.new('RGBA',(W,H),(0,0,0,0));p=im.load();d=ImageDraw.Draw(im)
    dy=P.get('dy',0);lean=P.get('lean',0);sq=P.get('squash',0)
    def put(x,y,c):
        x,y=round(x),round(y)
        if 0<=x<W and 0<=y<H:p[x,y]=c
    def fill(mask,pal,cx,cy,rx,ry,box,noise=.1):
        for y in range(max(0,box[1]),min(H,box[3])):
            for x in range(max(0,box[0]),min(W,box[2])):
                if mask(x,y):
                    nx=(x-cx)/rx;ny=(y-cy)/ry;l=.5+(nx*.7+ny*.7)*-.45-.25*(nx*nx+ny*ny)+R.uniform(-noise,noise)
                    p[x,y]=pal[max(0,min(len(pal)-1,int(l*len(pal))))]
    def poly(pts):
        def f(x,y):
            c=False;n=len(pts)
            for i in range(n):
                x1,y1=pts[i];x2,y2=pts[(i+1)%n]
                if (y1>y)!=(y2>y) and x<(x2-x1)*(y-y1)/(y2-y1)+x1:c=not c
            return c
        return f
    def ell(cx,cy,rx,ry):return lambda x,y:((x-cx)/rx)**2+((y-cy)/ry)**2<=1
    def leg(x0,dx,lift,dark):
        top=46+dy;bot=GY-lift;xa=x0+dx
        pal=PANTS[:3] if dark else PANTS
        m=poly([(x0,top),(x0+10,top),(xa+9,bot-8),(xa,bot-8)]);fill(m,pal,x0+5,top+5,6,7,(0,top,W,bot))
        for x in range(round(xa)-1,round(xa)+11):   # torn hem
            j=R.choice([0,1,1,2])
            for y in range(bot-9+j,bot-7):
                if m(x,y):p[x,y]=(0,0,0,0)
        for y in range(bot-7,bot-1):
            for x in range(round(xa)+1,round(xa)+8):p[x,y]=SKIN[2] if x<xa+4 else SKIN[1]
        for x in range(round(xa)-1,round(xa)+9):put(x,bot-1,SKIN[1]);put(x,bot,SKIN[0])
        if dark:  # the borrowed boot on the back foot
            for x in range(round(xa),round(xa)+10):put(x,bot-1,(30,30,36,255));put(x,bot,(20,20,24,255))
            put(xa+2,bot-2,(220,200,60,255));put(xa+3,bot-2,(220,200,60,255))
    fl=P.get('fl',(0,0));bl=P.get('bl',(0,0))
    leg(27,bl[0],bl[1],True)
    # body
    T=poly([(15+lean,21+dy+sq),(30+lean,16+dy+sq),(40+lean,19+dy+sq),(44,32+dy),(41,46+dy),(12,46+dy),(8+lean*.5,36+dy)])
    fill(T,SKIN,24+lean,30+dy,16,16,(0,0,W,H))
    fill(ell(34+lean,22+dy+sq,9,7),SKIN,32+lean,20+dy,9,7,(0,0,W,H))
    j=P.get('jig',0)
    gut=ell(22,39+dy+j*.5,15+j*.3,10-j*.3);fill(gut,SKIN,17,35+dy,15,10,(0,0,W,H))
    leg(14,fl[0],fl[1],False)
    # waistband
    for x in range(12,40):
        for y in range(45+dy,47+dy):
            if p[x,y][3]:p[x,y]=PANTS[1]
    # ripped shirt
    rag=[R.choice([0,1,2,3,4]) for _ in range(W)]
    for y in range(12+dy,36+dy):
        for x in range(5,47):
            if 0<=y<H and p[x,y][3] and p[x,y] in SKIN and (y<28+dy+rag[x]-(2 if 16<x<26 else 0) or (x in (13,14,32,33,34) and y<33+dy+rag[x])) and not (x>38+lean and y<17+dy):
                nx=(x-26)/18;ny=(y-22-dy)/9;l=.55-.28*nx-.2*ny+R.uniform(-.1,.1);p[x,y]=SHIRT[max(0,min(3,int(l*4)))]
    for (x,y,w,h) in ((30,20,3,2),(19,23,2,2),(36,25,2,3)):
        for yy in range(y+dy,y+dy+h):
            for xx in range(x+lean,x+lean+w):
                if p[xx,yy][3]:p[xx,yy]=SKIN[2]
    for (cx,cy,n) in ((24,27,7),(36,30,6),(17,30,4)):
        for _ in range(n):
            x=cx+R.randint(-2,2);y=cy+dy+R.randint(-1,3)
            if p[x,y][3]:p[x,y]=R.choice([BLOOD,BLOOD2])
    # stitches: Y on the gut, seam over the hunch
    stitches(d,[(14,31+dy),(19,36+dy)]);stitches(d,[(27,31+dy),(21,36+dy)]);stitches(d,[(20,36+dy),(20,44+dy)])
    stitches(d,[(29+lean,18+dy+sq),(35+lean,17+dy+sq),(40+lean,21+dy+sq)])
    # face pushing out of the gut
    if P.get('burst',0)<.3:
        d.ellipse([28,34+dy,36,42+dy],fill=BLOOD2);d.ellipse([29,35+dy,35,41+dy],fill=BLOOD);ga=P.get('gutarm',(0,0));im.alpha_composite(GUTARM,(20+ga[0],23+dy+ga[1]))
        for (x,y) in ((31,38),(33,39),(30,40)):put(x,y+dy,BLOOD3)
    # extra (peach) arm sewn on the back
    def limb(pts,w0,w1,pal):
        n=len(pts)-1
        for i in range(n):
            (x0,y0),(x1,y1)=pts[i],pts[i+1];L=max(1,int(max(abs(x1-x0),abs(y1-y0))*2))
            for k in range(L+1):
                t=k/L;x=x0+(x1-x0)*t;y=y0+(y1-y0)*t;w=w0+(w1-w0)*((i+t)/n)
                for a in range(-int(w),int(w)+1):
                    for b in (-1,0):put(x+a,y+b,pal[3] if a<-w/3 else pal[2] if a<w/3 else pal[1])
    def hand(x,y,pal,claws=1):
        for i in range(6):
            for j in range(2):put(x+i,y+j,pal[2])
        for i in (0,2,4):
            for j in (2,3):put(x+i,y+j,pal[1] if j<3 else pal[0])
    ea=P.get('ea',[(40,22),(47,31),(49,41)])
    ea=[(x+lean*(1-i/len(ea)),y+dy) for i,(x,y) in enumerate(ea)]
    limb(ea,3.0,2.2,PEACH+[PEACH[-1]]);hand(ea[-1][0]-3,ea[-1][1]+1,PEACH)
    stitches(d,[(38+lean,24+dy),(42+lean,20+dy)])
    # head: centered on the shoulders, bald stitched scalp with patchy ginger tufts, open jaw
    hx,hy=P.get('head',(0,0));hx+=21+lean;hy+=8+dy;mo=P.get('mouth',1)
    # neck
    for x in range(int(hx)+2,int(hx)+10):
        for y in range(int(hy)+9,int(hy)+14):put(x,y,SKIN[2] if x<hx+6 else SKIN[1])
    hm=ell(hx+6,hy+5,6,6);fill(hm,SKIN,hx+4,hy+3,6,6,(0,0,W,H),.06)
    for x in range(int(hx)+1,int(hx)+11):   # brow ridge
        if hm(x,hy+4):put(x,hy+4,SKIN[1])
    put(hx+3,hy+5,(230,220,150,255));put(hx+2,hy+5,(30,20,20,255))     # one milky eye (facing left)
    put(hx+6,hy+5,BLOOD2);put(hx+7,hy+5,(20,16,16,255))                   # the other eye sewn shut
    put(hx+6,hy+4,STITCH);put(hx+7,hy+6,STITCH)
    for x in range(int(hx)+1,int(hx)+6):put(x,hy+8,(20,14,14,255))       # jaw / mouth
    if mo:
        for x in range(int(hx)+1,int(hx)+6):put(x,hy+9,BLOOD2)
        for x in (hx+1,hx+3,hx+5):put(x,hy+8,(214,206,170,255))
        put(hx+2,hy+10,BLOOD);put(hx+2,hy+11,BLOOD)
    stitches(d,[(hx+4,hy),(hx+8,hy+1),(hx+11,hy+4)])                    # scalp seam
    for (tx,ty) in ((hx+2,hy+1),(hx+9,hy+2),(hx+10,hy+5),(hx+6,hy-1)):   # patchy ginger tufts
        put(tx,ty,GINGER[1]);put(tx+1,ty,GINGER[2]);put(tx,ty-1,GINGER[0])
    # front arm: shoulder -> elbow -> hand
    fa=P.get('fa',[(12,23),(8,34),(7,44)]);fa=[(x+(lean if i==0 else lean*.5),y+dy) for i,(x,y) in enumerate(fa)]
    limb(fa,3.6,2.6,SKIN);hand(fa[-1][0]-3,fa[-1][1]+1,SKIN);stitches(d,[(14+lean,22+dy),(9+lean,26+dy)])
    for (x,y) in ((fa[-1][0]-1,fa[-1][1]+5),(fa[-1][0]+1,fa[-1][1]+5)):put(x,y,BLOOD)
    if P.get('glob'):
        gx,gy,gr=P['glob'];B=GUTBALL[P.get('spin',0)%4];im.alpha_composite(B,(round(gx-6),round(gy-6)))
    outline(im)
    return im
