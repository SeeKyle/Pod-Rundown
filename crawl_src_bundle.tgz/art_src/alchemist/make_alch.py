# 0.12.435 (Kyle) the Alchemist: the CraftPix Countess Vampire (faces right), dressed up as an alchemist from Kyle's concepts:
# brass goggles on her head, a glowing blue pendant, a potion belt with green/purple/blue vials. Her throw is an overhand pitch with a flask in hand.
from PIL import Image
SRC='/home/claude/assets/VampireSprites/Countess_Vampire/'
def frames(n):im=Image.open(SRC+n+'.png').convert('RGBA');return [im.crop((i*128,0,i*128+128,128)) for i in range(im.width//128)]
ANIM={'idle':frames('Idle'),'walk':frames('Walk'),'run':frames('Run'),'hurt':frames('Hurt'),'death':frames('Dead')[:6],
      'throw':frames('Attack_2')+frames('Attack_3')+[frames('Attack_1')[5]]}   # wind up overhead -> release -> follow-through
BR=(176,138,58,255);BRd=(120,90,36,255);LENS=(122,216,255,255);GEM=(90,200,255,255);GEMl=(200,245,255,255);BELT=(92,58,30,255);BUCK=(210,180,90,255)
VIAL=[(90,210,90,255),(170,90,230,255),(80,170,255,255)];GLASS=(230,240,245,255);CORK=(140,100,60,255)
import colorsys
def recolor(fr):
  px=fr.load();bb=fr.getbbox();lower=bb[1]+(bb[3]-bb[1])*.35 if bb else 0
  for y in range(128):
    for x in range(128):
      r,g,b,a=px[x,y]
      if a==0:continue
      h,l,s=colorsys.rgb_to_hls(r/255,g/255,b/255)
      if s<.12 or (h<.07 and s<.62 and l>.4):continue                       # keep skin (and its shading), whites, greys
      if .07<h<.2 and y<lower:continue                                       # keep her blonde hair
      if .68<h<.9:nh,ns=.38,max(.25,s*.8)                                     # purple gown -> deep alchemist green
      elif .07<h<.2 and l>.4:nh,ns,l=.07,.55,l*.62                          # gold panel -> leather apron
      elif h>.93 or h<.04:nh,ns=.06,s*.75;l=l*.85                              # red gloves/ruffles -> brown leather and brass
      else:continue
      r2,g2,b2=colorsys.hls_to_rgb(nh,l,ns);px[x,y]=(int(r2*255),int(g2*255),int(b2*255),a)
  return fr
def dress(fr,name,i):
  px=fr.load();bb=fr.getbbox()
  if not bb:return fr
  apron=[y for y in range(128) for x in range(128) if px[x,y][3]>0 and px[x,y][0]>200 and px[x,y][1]>160 and px[x,y][2]<110]
  waist=min(apron) if apron else None
  recolor(fr)
  if name=='death':return fr
  x0,y0,x1,y1=bb;H=y1-y0
  skin=[(x,y) for y in range(y0,y0+int(H*.35)) for x in range(x0,x1) if px[x,y][3]>0 and px[x,y][0]>205 and px[x,y][1]>150 and px[x,y][2]>150 and px[x,y][0]-px[x,y][2]<80]
  if not skin:return fr
  fx=sorted(p[0] for p in skin);fy=sorted(p[1] for p in skin);cx=fx[len(fx)//2];ft=fy[0];fb=min(fy[-1],ft+9)
  # goggles across the hairline, right above the face
  gy=ft-1
  for x in range(cx-5,cx+5):
    if px[x,gy][3]>0:px[x,gy]=BRd
  for lx in (cx-4,cx+1):
    for dx in (0,1,2):
      px[lx+dx,gy-3]=BRd;px[lx+dx,gy-2]=LENS;px[lx+dx,gy-1]=LENS if dx else (200,240,255,255)
    px[lx-1,gy-2]=BRd;px[lx+3,gy-2]=BRd
  # pendant on the chest
  py=fb+5
  if px[cx,py][3]>0:px[cx-1,py-1]=(200,200,210,255);px[cx+1,py-1]=(200,200,210,255);px[cx,py]=GEM;px[cx,py+1]=GEMl
  # potion belt at the waist: the narrowest row of the body below the chest
  best=None
  if waist:
    row=[x for x in range(128) if px[x,waist-1][3]>0]
    if row:best=(waist-1,0,min(row),max(row))
  for y in ([] if best else range(fb+9,min(fb+24,126))):
    row=[x for x in range(cx-12,cx+12) if 0<=x<128 and px[x,y][3]>0]
    if len(row)>=4 and (best is None or len(row)<best[1]):best=(y,len(row),min(row),max(row))
  if best:
    by,_,a,b=best
    for x in range(a,b+1):
      for yy in (by,by+1):
        if yy<128 and px[x,yy][3]>0:px[x,yy]=BELT if yy==by else (64,40,20,255)
    mid=(a+b)//2;px[mid,by]=BUCK;px[mid+1,by]=BUCK;px[mid,by+1]=BUCK
    for k,vx in enumerate((a+1,(a+b)//2+2,b-2)):
      c=VIAL[k]
      for yy in range(by+2,by+6):
        if yy<128:px[vx,yy]=c;px[vx+1,yy]=c
      if by+6<128:px[vx,by+6]=(30,30,36,255);px[vx+1,by+6]=(30,30,36,255)
      px[vx,by+2]=GLASS;px[vx,by+1]=CORK;px[vx+1,by+1]=CORK
  # a flask in her hand while she winds up the throw
  if name=='throw' and i<3:
    hand=[(x,y) for y in range(y0,y0+30) for x in range(x0,x1) if px[x,y][3]>0]
    if hand:
      hx,hy=min(hand,key=lambda p:p[1])
      for dx in (-1,0,1):
        for dy in (0,1):
          if 0<=hx+dx<128 and 0<=hy-2+dy<128:px[hx+dx,hy-2+dy]=(90,210,90,255)
      px[hx,hy-3]=GLASS;px[hx,hy-4]=CORK
  return fr
order=['idle','walk','run','throw','hurt','death']
W=max(len(ANIM[k]) for k in order)
sheet=Image.new('RGBA',(W*128,len(order)*128),(0,0,0,0))
for r,k in enumerate(order):
  for i,fr in enumerate(ANIM[k]):sheet.paste(dress(fr.copy(),k,i),(i*128,r*128))
sheet.save('/home/claude/pod2/crawl_alch.png')
prev=Image.new('RGBA',(8*80,2*96),(40,44,60,255))
pick=[('idle',0),('walk',2),('run',1),('throw',0),('throw',1),('throw',2),('throw',3),('throw',4)]
for i,(k,f) in enumerate(pick):
  fr=sheet.crop((f*128,order.index(k)*128,f*128+128,order.index(k)*128+128)).crop((24,32,104,128));prev.alpha_composite(fr,(i*80,0))
prev=prev.crop((0,0,640,96)).resize((640*2,96*2),Image.NEAREST);prev.save('/home/claude/alch_preview.png')
print(sheet.size,{k:len(ANIM[k]) for k in order})
