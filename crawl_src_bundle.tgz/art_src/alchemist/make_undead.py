# 0.12.511 (Kyle) Undead_Alchemist: pale grave-white skin and dead white hair over the existing Alchemist sheet.
import sys,colorsys
from PIL import Image
src,dst=sys.argv[1],sys.argv[2]
im=Image.open(src).convert('RGBA');px=im.load();W,H=im.size
SKIN={(233,181,163):(198,208,216),(189,106,98):(134,148,160),(186,117,106):(144,158,168),(142,82,82):(94,106,118)}   # pale, a touch darker, faint blue
def hair(l):  # white ramp by lightness
  t=max(0,min(1,(l-.3)/.5));return tuple(int(a+(b-a)*t) for a,b in zip((118,124,126),(240,242,238)))
for fy in range(0,H,128):
  for fx in range(0,W,128):
    bb=im.crop((fx,fy,fx+128,fy+128)).getbbox()
    if not bb:continue
    top=bb[1]+(bb[3]-bb[1])*.34
    for y in range(fy+bb[1],fy+bb[3]):
      for x in range(fx+bb[0],fx+bb[2]):
        r,g,b,a=px[x,y]
        if not a:continue
        if (r,g,b) in SKIN:px[x,y]=SKIN[(r,g,b)]+(a,);continue
        h,l,s=colorsys.rgb_to_hls(r/255,g/255,b/255)
        if y-fy<top and .05<h<.14 and s>.4 and l>.4:px[x,y]=hair(l)+(a,)
im.save(dst)
