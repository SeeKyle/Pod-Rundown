import numpy as np, os
from PIL import Image
from scipy import ndimage as nd
OUT='/home/claude/pod2/assets/heroes/chibi/';os.makedirs(OUT,exist_ok=True)
L,R,U=150,170,200
JOBS={'a.jpg':{'attack1':(270,450),'attack2':(500,665),'hurt':(705,880),'death':(925,1090)},
      'b.jpg':{'idle':(40,215),'walk':(490,665),'run':(705,880),'runatk':(920,1090)}}
CUTS={'attack2':[612]}   # frames 2 and 3 touch through the sword trail
for f,rows in JOBS.items():
    S=np.array(Image.open(f).convert('RGBA')).astype(np.uint8);RGB=S[...,:3].astype(int)
    fg=np.abs(RGB-162).sum(2)>45;fg[:,:240]=False
    for name,(y0,y1) in rows.items():
        m0=fg.copy();m0[:y0]=False;m0[y1:]=False
        for cx in CUTS.get(name,[]):m0[:,cx-4:cx+4]=False
        lab,n=nd.label(nd.binary_dilation(m0,iterations=2)&m0|m0);lab,n=nd.label(nd.binary_dilation(m0,iterations=2))
        objs=nd.find_objects(lab);comps=[]
        for i,sl in enumerate(objs):
            if not sl:continue
            mm=(lab[sl]==i+1)&m0[sl]
            if mm.sum()<5:continue
            comps.append((i,sl,mm.sum(),(sl[1].start+sl[1].stop)/2))
        bodies=sorted([c for c in comps if c[2]>3000],key=lambda c:c[3])
        groups=[[b] for b in bodies]
        for c in comps:
            if c in bodies:continue
            k=int(np.argmin([abs(c[3]-b[3]) for b in bodies]));groups[k].append(c)
        frames=[]
        for g in groups:
            m=np.zeros(fg.shape,bool)
            for j,(i,sl,_,_) in enumerate(g):
                mm=(lab[sl]==i+1)&m0[sl]
                if j==0:mm=nd.binary_fill_holes(mm)
                m[sl]|=mm
            ys,xs=np.nonzero(m);gy=ys.max();fy,fx=np.nonzero(m[gy-30:gy+1]);ax=int(np.median(fx))
            x0,yb=ax-L,gy-U;c=np.zeros((U+8,L+R,4),np.uint8)
            for yy in range(max(0,yb),min(S.shape[0],gy+8)):
                row=m[yy,max(0,x0):x0+L+R];px=S[yy,max(0,x0):x0+L+R].copy();px[...,3]=np.where(row,255,0)
                c[yy-yb,max(0,x0)-x0:max(0,x0)-x0+len(row)]=px
            frames.append(np.ascontiguousarray(c[:,::-1]))
        Image.fromarray(np.concatenate(frames,1)).save(OUT+name+'.png');print(name,len(frames))
