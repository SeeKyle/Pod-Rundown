import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage as nd
from skimage.color import rgb2hsv
D='/home/claude/pod2/assets/heroes/chibi/'
for n in ['attack1','attack2','runatk','idle','walk','run','hurt','death']:
    im=Image.open(D+n+'.png').convert('RGBA');A=np.array(im).astype(int)
    a=A[...,3]>0;hsv=rgb2hsv(A[...,:3]/255.);S,V=hsv[...,1],hsv[...,2]
    light=a&(S<.35)&(V>.4)
    # the blade and its black outline together: thin, long, light-cored structure
    lab,k=nd.label(light,structure=np.ones((3,3)));sl=nd.find_objects(lab)
    nearT=nd.binary_dilation(~a,structure=np.ones((3,3)))
    dr=ImageDraw.Draw(im);cnt=0
    for i,s in enumerate(sl):
        cm=lab[s]==i+1;ys,xs=np.nonzero(cm)
        if len(ys)<12:continue
        fr=(nearT[s]&cm).sum()/cm.sum()
        P=np.stack([xs+s[1].start,ys+s[0].start],1).astype(float);c=P.mean(0);u,sv,vt=np.linalg.svd(P-c,full_matrices=False)
        d=vt[0];proj=(P-c)@d;L=proj.max()-proj.min();wid=sv[1]/max(1,np.sqrt(len(P)))
        ratio=sv[0]/max(sv[1],1e-6)
        if L<20 or ratio<5 or (fr>=.45 and ratio<9):continue   # long and straight = blade; curvy edge fringe is skipped
        p0=c+d*proj.min();p1=c+d*proj.max()
        dr.line([tuple(p0),tuple(p1)],fill=(40,42,54,255),width=6)      # outline
        dr.line([tuple(p0),tuple(p1)],fill=(168,176,198,255),width=4)   # steel
        nrm=np.array([-d[1],d[0]]);hl=0.9*nrm
        dr.line([tuple(p0-hl),tuple(p1-hl)],fill=(222,228,240,255),width=1)  # edge glint
        cnt+=1
    im.save(D+n+'.png');print(n,cnt)
