import re, json, sys
sys.path.insert(0, '/home/claude/work')
from tagindex import index
P = '/home/claude/pod2/'
BASICS = {'Plains','Island','Swamp','Mountain','Forest'}
def parse(block):
    out = []
    for l in block.split('\n'):
        m = re.match(r'^(\d+) (.+?)\s*(\((.*?)\))?\s*$', l.strip())
        if m: out.append((int(m[1]), m[2].strip(), (m[4] or '').strip()))
    return out
def sections():
    txt = open('/home/claude/bundle/bundle/02_Whats_Next_UPDATED_with_status.txt', encoding='utf-8').read()
    secs = {}
    for s in re.split(r'\n---', txt):
        lst = parse(s)
        if len(lst) > 50: secs[s.split('\n')[0][:40]] = lst
    secs['mothman'] = parse(open('/home/claude/data/mothman_list.txt', encoding='utf-8').read())
    return secs
def draft(lst, prefer=()):
    idx = index(); have = {}; todo = []
    for q, n, note in lst:
        if n in BASICS: continue
        v = idx.get(n)
        if v:
            pick = [s for k, s in v if k in prefer] or [s for k, s in v]
            have[n] = pick[0]
        else:
            todo.append(n)
    return have, todo
if __name__ == '__main__':
    for k, lst in sections().items():
        have, todo = draft(lst)
        print(k, sum(q for q, _, _ in lst), 'reused', len(have), 'todo', len(todo))

def make(key, meta, lst, newtags, header='', prefer=()):
    from deckedit import set_raw
    have, todo = draft(lst, prefer)
    have = {n: v for n, v in have.items() if n not in newtags}
    miss = [n for n in todo if n not in newtags]
    extra = [n for n in newtags if n not in {x[1] for x in lst}]
    C = meta['colors']
    lines = ['from formulas import *', f'C = {C}', 'META = ' + repr(meta)]
    if header: lines.append(header)
    lines.append('TAGS = {')
    for q, n, note in lst:
        if n in BASICS: continue
        src = newtags.get(n) or have.get(n)
        if src: lines.append(f' {json.dumps(n, ensure_ascii=False)}: {src},')
    lines.append('}')
    open(P + 'decks/' + key + '.py', 'w', encoding='utf-8').write('\n'.join(lines) + '\n')
    set_raw(meta['file'], lst)
    return miss, extra
