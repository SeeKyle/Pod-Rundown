import ast, json
P = '/home/claude/pod2/'
def _load(key):
    f = P + 'decks/' + key + '.py'
    return f, open(f, encoding='utf-8').read()
def edit(key, remove=(), add=None, replace=None):
    """remove: names; add/replace: {name: "T(...)" source}"""
    add = add or {}; replace = replace or {}
    f, src = _load(key)
    tree = ast.parse(src)
    tags = [n for n in tree.body if isinstance(n, ast.Assign) and getattr(n.targets[0], 'id', '') == 'TAGS'][0].value
    lines = src.split('\n')
    spans = {}
    for k, v in zip(tags.keys, tags.values):
        spans[k.value] = (k.lineno - 1, v.end_lineno - 1)
    drop = set()
    for n in list(remove) + list(replace):
        if n not in spans: raise KeyError(f'{key}: {n} not in TAGS')
        a, b = spans[n]
        if any(a2 <= b and a <= b2 for m, (a2, b2) in spans.items() if m != n and m not in remove and m not in replace):
            raise ValueError(f'shared line for {n}')
        drop.update(range(a, b + 1))
    out = [l for i, l in enumerate(lines) if i not in drop]
    end = max(i for i, l in enumerate(out) if l.strip() == '}')
    new = [f" {json.dumps(n, ensure_ascii=False)}: {s}," for n, s in {**replace, **add}.items()]
    out = out[:end] + new + out[end:]
    open(f, 'w', encoding='utf-8').write('\n'.join(out))
    ast.parse('\n'.join(out))
def set_raw(file, cards):
    """cards: list of (q, name, note)"""
    r = json.load(open(P + 'raw_lists.json', encoding='utf-8'))
    r[file] = [dict(q=q, name=n, note=note) for q, n, note in cards]
    json.dump(r, open(P + 'raw_lists.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
def raw_swap(file, out=(), into=()):
    """out: [(name, q)], into: [(name, q)]"""
    r = json.load(open(P + 'raw_lists.json', encoding='utf-8'))
    L = r[file]
    for n, q in out:
        c = [c for c in L if c['name'] == n][0]
        c['q'] -= q
        if c['q'] <= 0: L.remove(c)
    for n, q in into:
        c = [c for c in L if c['name'] == n]
        if c: c[0]['q'] += q
        else: L.append(dict(q=q, name=n, note=''))
    json.dump(r, open(P + 'raw_lists.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
    return sum(c['q'] for c in L)
