import sys, json, importlib
sys.path.insert(0, '/home/claude/work'); sys.path.insert(0, '/home/claude/pod2'); sys.path.insert(0, '/home/claude/pod2/decks')
from repair_draft import R
info = {}
for l in open('/home/claude/data/swapinfo.txt', encoding='utf-8'):
    p = l.strip().split('|'); info[p[0]] = (p[1], float(p[2]), len(p) > 3)
CI = json.load(open('/home/claude/data/cmdr_ci.json')); raw = json.load(open('/home/claude/pod2/raw_lists.json'))
POOL = {
 'draw': [("Night's Whisper", "draw two for 2"), ("Sign in Blood", "draw two for 2"), ("Read the Bones", "scry 2, draw 2"), ("Painful Truths", "draw up to three"),
          ("Harmonize", "draw three"), ("Fact or Fiction", "instant card advantage"), ("Mulldrifter", "a flier that draws two"), ("Thought Monitor", "an artifact that draws two"),
          ("Tireless Tracker", "Clues on every land drop"), ("Garruk's Uprising", "draws on big creatures and gives trample"), ("Mask of Memory", "draws two every hit"),
          ("Rogue's Gloves", "a card every hit"), ("Commander's Sphere", "ramp that cashes in for a card"), ("Mind Stone", "ramp that cashes in for a card"), ("Curiosity", "a card every hit"),
          ("Phyrexian Arena", "an extra card every upkeep"), ("Skullclamp", "creatures die into two cards"), ("Beast Whisperer", "every creature spell draws"),
          ("Rishkar's Expertise", "draw equal to your biggest creature's power"), ("Kindred Discovery", "draw on every creature of your type"), ("Mystic Remora", "cards off their noncreature spells"),
          ("Faerie Mastermind", "draws off their extra cards"), ("Black Market Connections", "cards, Treasure or tokens every turn"),
          ("Rhystic Study", "a card every time an opponent doesn't pay"), ("Sylvan Library", "pick the best of three every turn"), ("The One Ring", "protection plus a growing card engine")],
 'removal': [("Swords to Plowshares", "1-mana exile"), ("Path to Exile", "1-mana exile"), ("Generous Gift", "an answer to any permanent"), ("Beast Within", "instant answer to anything"),
          ("Chaos Warp", "an answer to any permanent"), ("Abrade", "kills a creature or an artifact"), ("Lightning Helix", "kill and gain 3"), ("Putrefy", "instant kill a creature or artifact"),
          ("Assassin's Trophy", "instant answer to any permanent"), ("Infernal Grasp", "instant kill for 2"), ("Feed the Swarm", "kill a creature or enchantment"), ("Fatal Push", "1-mana kill"),
          ("Vindicate", "destroy any permanent"), ("Anguished Unmaking", "instant exile anything"), ("Fateful Absence", "instant destroy, they get a Clue"), ("Austere Command", "a wipe you pick the halves of"),
          ("Wrath of the Skies", "a wipe by mana value"), ("Toxic Deluge", "a cheap wipe you control"), ("Farewell", "pick what gets exiled; keep your side"),
          ("Delayed Blast Fireball", "one-sided wipe"), ("Cyclonic Rift", "overload clears every opponent's board")],
 'ramp': [("Arcane Signet", "any commander color for 2"), ("Fellwar Stone", "a 2-mana rock that fixes"), ("Talisman of Conviction", "a 2-mana R/W rock"), ("Talisman of Creativity", "a 2-mana U/R rock"),
          ("Talisman of Indulgence", "a 2-mana B/R rock"), ("Talisman of Progress", "a 2-mana W/U rock"), ("Orzhov Signet", "a 2-mana W/B rock"), ("Gruul Signet", "a 2-mana R/G rock"), ("Simic Signet", "a 2-mana G/U rock"),
          ("Mind Stone", "a rock that cashes in for a card"), ("Commander's Sphere", "a rock that cashes in for a card"), ("Rampant Growth", "a basic onto the battlefield"), ("Farseek", "fetches a dual"),
          ("Nature's Lore", "an untapped Forest-type land"), ("Kodama's Reach", "two basics"), ("Wood Elves", "a Forest onto the battlefield"), ("Farhaven Elf", "a basic on a body"),
          ("Coldsteel Heart", "a rock that fixes"), ("Thought Vessel", "ramp and no hand-size limit"), ("Three Visits", "an untapped dual at instant speed"), ("Birds of Paradise", "any color on turn one"),
          ("Elves of Deep Shadow", "a B dork for 1"), ("Deathrite Shaman", "mana, hate and drain"), ("Noble Hierarch", "mana and exalted"), ("Bloom Tender", "mana of every color you have"),
          ("Dryad of the Ilysian Grove", "an extra land each turn"), ("Smothering Tithe", "Treasure every time an opponent draws"), ("Mana Vault", "three mana right away")],
 'finish': [("Inspired Charge", "team +2/+1 for the swing"), ("Rally of Wings", "untap fliers and +2/+2"), ("Overwhelming Stampede", "team pump and trample"), ("Return of the Wildspeaker", "draw or overrun"),
          ("Bastion of Remembrance", "drains on every death"), ("Impact Tremors", "1 to each opponent per creature"), ("Goblin Bombardment", "fling creatures at a player"), ("Comet Storm", "X damage split anywhere"),
          ("Shared Animosity", "attackers pump each other"), ("Coat of Arms", "creatures grow per shared type"), ("Akroma's Will", "team flying, double strike, protection"), ("Triumph of the Hordes", "infect overrun"),
          ("Moonshaker Cavalry", "team flying and +X/+X"), ("Embercleave", "flash double strike and trample"), ("Pathbreaker Ibex", "attacking gives the team +X/+X and trample"),
          ("Aetherflux Reservoir", "life from spells, then shoot 50"), ("Craterhoof Behemoth", "one swing ends the game"), ("Purphoros, God of the Forge", "2 to each opponent per creature"),
          ("Sword of Fire and Ice", "damage, a card and protection every hit"), ("Finale of Devastation", "tutor a finisher onto the battlefield"), ("Terror of the Peaks", "damage for every creature entering")],
 'protect': [("Swiftfoot Boots", "hexproof and haste"), ("Snakeskin Veil", "instant hexproof and a counter"), ("Whispersilk Cloak", "shroud and unblockable"), ("Wall of Omens", "a blocker that draws"),
          ("Arachnogenesis", "fog plus Spiders"), ("Lightning Greaves", "shroud and haste, equip 0"), ("Boros Charm", "team indestructible"), ("Tamiyo's Safekeeping", "1-mana hexproof and indestructible"),
          ("Heroic Intervention", "team hexproof and indestructible"), ("Flawless Maneuver", "free team indestructible"), ("Ghostly Prison", "taxes attacks on you"),
          ("Teferi's Protection", "saves board and life for a turn"), ("The One Ring", "a turn of protection and cards")],
}
ROLE = {
 'grim': ['finish', 'draw', 'removal', 'ramp', 'keep'], 'felothar': ['finish', 'finish', 'ramp', 'ramp', 'finish'], 'vile': ['finish', 'draw', 'finish', 'ramp', 'finish'],
 'modular': ['removal', 'finish', 'draw', 'ramp', 'finish'], 'depala': ['protect', 'finish', 'draw', 'ramp', 'ramp'], 'thing': ['protect', 'ramp', 'removal', 'draw', 'finish'],
 'kykar': ['draw', 'removal', 'ramp', 'removal', 'finish'], 'dragons': ['finish', 'protect', 'draw', 'finish', 'finish'], 'joel': ['finish', 'finish', 'draw', 'finish', 'finish'],
 'kotis': ['finish', 'draw', 'protect', 'draw', 'finish'], 'casino': ['draw', 'removal', 'draw', 'removal', 'ramp'], 'mathas': ['protect', 'protect', 'protect', 'removal', 'draw'],
 'turtle': ['draw', 'finish', 'finish', 'finish', 'draw'], 'marina': ['draw', 'finish', 'draw', 'draw', 'ramp'], 'korvold': ['finish', 'finish', 'ramp', 'draw', 'draw'],
 'family': ['removal', 'finish', 'finish', 'ramp', 'draw'], 'thranduil': ['finish', 'finish', 'protect', 'draw', 'finish'], 'robots': ['draw', 'removal', 'finish', 'removal', 'draw'],
 'blood': ['removal', 'finish', 'ramp', 'draw', 'finish'], 'spider': ['draw', 'ramp', 'finish', 'draw', 'ramp'], 'mech': ['draw', 'finish', 'removal', 'draw', 'finish'],
 'mothman': ['removal', 'ramp', 'finish', 'ramp', 'removal'], 'weather': ['protect', 'ramp', 'finish', 'finish', 'draw'], 'scare': ['protect', 'finish', 'protect', 'draw', 'ramp'],
 'zurgo': ['protect', 'protect', 'finish', 'finish', 'ramp'],
}
def band(p):
    return 0 if p <= 2.5 else 1 if p <= 25 else 2
def ok(s, ids, deck):
    if s not in info: return False
    c, p, ban = info[s]
    return not ban and set(c) <= ids and s not in deck
def fix_all():
    out = {}; G = {}
    for k, v in R.items():
        M = importlib.import_module(k).META; ids = set(''.join(CI[c] for c in M['cmdr'])); deck = {c['name'] for c in raw[M['file']]}
        rows = []
        used_deck = set()
        for idx, (card, rd, why, sw) in enumerate(v):
            good = [(s, r) for s, r in sw if ok(s, ids, deck) and s not in used_deck]
            slots = [None, None, None, None]   # b, b, m, a
            def place(s, r):
                p = info[s][1]
                order = [0, 1] if p <= 2.5 else [2] + ([3] if p >= 9 else []) if 4.5 <= p <= 22 else [3] if p > 22 else []
                for i in order:
                    if slots[i] is None and all(x is None or x[0] != s for x in slots):
                        slots[i] = (s, r); return True
                return False
            for s, r in good: place(s, r)
            role = ROLE[k][idx]
            pool = POOL.get(role, []) + [x for rr in ('draw', 'removal', 'ramp', 'finish', 'protect') if rr != role for x in POOL[rr]]
            for cap in (2, 4, 99):
                for s, r in pool:
                    if all(x is not None for x in slots): break
                    if ok(s, ids, deck) and s not in used_deck and G.get(s, 0) < cap and all(x is None or x[0] != s for x in slots): place(s, r)
            for x in slots:
                if x: used_deck.add(x[0]); G[x[0]] = G.get(x[0], 0) + 1
            rows.append((card, rd, why, slots))
        out[k] = rows
    return out
if __name__ == '__main__':
    o = fix_all()
    for k, rows in o.items():
        for card, rd, why, slots in rows:
            miss = [i for i, x in enumerate(slots) if x is None]
            print(k, '|', card, '|', ' / '.join(f"{x[0]} ${info[x[0]][1]:g}" if x else 'NONE' for x in slots))
