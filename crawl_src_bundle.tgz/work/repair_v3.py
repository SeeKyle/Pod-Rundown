"""0.12.1 Needs Repair: 4 picks per deck (repair_v2.PICKS), 4 swaps each, EDHREC-first.
Checks both faces of double-faced cards against the deck, keeps enchantment swaps enchantments for House on Haunted Hill,
and keeps Ominous Weather swaps on its winter-storm theme."""
import sys, json, importlib, re
sys.path.insert(0, '/home/claude/work'); sys.path.insert(0, '/home/claude/pod2'); sys.path.insert(0, '/home/claude/pod2/decks')
from repair_fix import POOL, CI, raw
from repair_edh import info, cand, PH, SHORT, band_ok
from repair_v2 import PICKS
CT = json.load(open('/home/claude/pod2/card_text.json'))
def faces(n): return {n} | set(n.split(' // '))
THEME = re.compile(r'Snow|Ice|Icy|Frost|Winter|Cold|Blizzard|Glacia|Rime|Boreal|Avalanche|Hail|Storm|Freez|Frozen|Arctic|Tundra|Sleet|Squall|Berg|Polar|Yeti|Chill|Sculptor of Winter|Marit Lage|Aldergard|Coldsteel|Into the North', re.I)
SKIP = {'Kykar, Zephyr Awakener'}
POOLROLE = {r: [n for n, _ in v] for r, v in POOL.items()}
POOLWHY = {n: w for v in POOL.values() for n, w in v}
TIERS = ['Super budget', 'Super budget', 'Medium', 'Any cost']
def does(n, role):
    i = info.get(n, {}); ro = i.get('roles', '')
    if role == 'keep': return True
    if role == 'finish': return 'F' in ro or ('K' in ro and 'M' not in ro)
    if role == 'ramp': return 'M' in ro and 'W' not in ro and i.get('mv', 0) <= 4
    if role == 'removal': return any(c in ro for c in 'RWC')
    if role == 'draw': return 'D' in ro
    if role == 'protect': return 'P' in ro
    return False
def run():
    out = {}; G = {}; log = []
    for k, picks in PICKS.items():
        M = importlib.import_module(k).META; ids = set(''.join(CI[c] for c in M['cmdr']))
        deckfaces = set()
        for c in raw[M['file']]: deckfaces |= faces(c['name'])
        for c in M['cmdr'] + M.get('secret', []): deckfaces |= faces(c)
        names = {c['name'] for c in raw[M['file']]}
        for p, *_ in picks: assert p in names, (k, p)
        who = SHORT(M['cmdr'][0])
        def legal(n):
            i = info.get(n)
            if not i or i['ban'] or n in SKIP or not set(i['ci']) <= ids or faces(n) & deckfaces: return False
            return True
        C = [(n, i, s) for n, i, s in cand.get(k, []) if legal(n)]
        THEMEW = re.compile(r'\b(Snow|Ice|Icy|Frost|Winter|Cold|Blizzard|Glacial|Rime|Boreal|Avalanche|Hail|Storm|Frozen|Freeze|Arctic|Sleet|Squall|Berg|Polar|Yeti|Chill)', re.I)
        C.sort(key=lambda x: -(x[1] + x[2] / 2 + (25 if k == 'weather' and (THEMEW.search(x[0]) or 'Snow' in CT.get(x[0], '').split('\n')[1:2][0] if '\n' in CT.get(x[0], '') else False) else 0)))
        used = set(); rows = []
        for card, role, rd, why in picks:
            ench = k == 'marina' and 'Enchantment' in CT.get(card, '\n').split('\n')[1]
            ok_t = (lambda n: info.get(n, {}).get('t') == 'E') if ench else (lambda n: True)
            fit = [x for x in C if does(x[0], role) and ok_t(x[0]) and x[1] + x[2] / 2 >= 15]
            wild = [x for x in C if ok_t(x[0]) and x[2] >= 25 and role != 'removal']
            prole = [n for n in POOLROLE.get(role, []) if legal(n) and ok_t(n)]
            pother = [n for r in POOLROLE for n in POOLROLE[r] if r != role and legal(n) and ok_t(n)]
            if ench: prole = [n for n in prole if info.get(n, {}).get('t') == 'E']; pother = [n for n in pother if info.get(n, {}).get('t') == 'E']
            sw = []
            for tier in TIERS:
                pick = None
                def try_edh(src):
                    for n, i, s in src:
                        if n in used or G.get(n, 0) >= 4 or not band_ok(tier, info[n]['usd']): continue
                        if tier == 'Any cost' and info[n]['usd'] < 4.5 and any(info[x[0]]['usd'] >= 4.5 and x[0] not in used and G.get(x[0], 0) < 4 for x in src): continue
                        return (n, f"{' and '.join(PH[ch] for ch in info[n]['roles'][:2]) or 'a key piece for this commander'}; on {i:.0f}% of {who} decks on EDHREC" + (f" (+{s:.0f}% synergy)" if s >= 5 else ''))
                def try_pool(src):
                    for n in src:
                        if n in used or G.get(n, 0) >= 4 or not band_ok(tier, info[n]['usd']): continue
                        return (n, POOLWHY.get(n, ''))
                pick = try_edh(fit) or try_pool(prole) or try_edh(wild) or try_pool(pother)
                if not pick:
                    for n, i, s in C:   # last resort: any legal EDHREC card in band
                        if n in used or not band_ok(tier, info[n]['usd']) or not ok_t(n): continue
                        pick = (n, f"on {i:.0f}% of {who} decks on EDHREC"); break
                n, w = pick if pick else ('??', '')
                sw.append(dict(tier=tier, card=n, why=w, usd=round(info.get(n, {}).get('usd', 0), 2)))
                used.add(n); G[n] = G.get(n, 0) + 1
            rows.append(dict(card=card, read=rd, why=why, swaps=sw))
            log.append((k, card, role, [(x['card'], x['usd']) for x in sw]))
        out[k] = rows
    return out, log
if __name__ == '__main__':
    out, log = run()
    for k, c, role, sw in log: print(k, '|', c[:26], f'[{role}]', '|', ' / '.join(f'{n} ${u:g}' for n, u in sw))
    json.dump(out, open('/home/claude/data/repair_v3.json', 'w'), indent=1, ensure_ascii=False)
