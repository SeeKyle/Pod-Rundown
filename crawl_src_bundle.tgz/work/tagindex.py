import ast, glob, json, os, sys
def index():
    out = {}
    for f in sorted(glob.glob('/home/claude/pod2/decks/*.py')):
        key = os.path.basename(f)[:-3]
        src = open(f, encoding='utf-8').read()
        tree = ast.parse(src)
        for node in tree.body:
            if isinstance(node, ast.Assign) and getattr(node.targets[0], 'id', '') == 'TAGS':
                for k, v in zip(node.value.keys, node.value.values):
                    out.setdefault(k.value, []).append((key, ast.get_source_segment(src, v)))
    return out
if __name__ == '__main__':
    idx = index()
    for n in sys.argv[1:]:
        print(n, '=>', idx.get(n))
