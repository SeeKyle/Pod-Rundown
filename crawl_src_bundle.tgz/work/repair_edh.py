"""0.12.0 Needs Repair, EDHREC pass: each weak card keeps its hand-picked read and why; swap slots are
filled with the commander's high-inclusion / high-synergy EDHREC cards that do the job the weak slot needs
(role), in the right price band. Hand picks stay where no EDHREC card fits."""
import sys, json, importlib
sys.path.insert(0, '/home/claude/work'); sys.path.insert(0, '/home/claude/pod2'); sys.path.insert(0, '/home/claude/pod2/decks')
from repair_fix import ROLE, CI, raw
from repair_data import REPAIR as OLD
from repair_draft import R as DRAFT
SKIP = {'Kykar, Zephyr Awakener'}
info = {}
for l in open('/home/claude/data/swapinfo.txt', encoding='utf-8'):
    p = l.strip().split('|'); info[p[0]] = dict(ci=p[1], usd=float(p[2]), ban=len(p) > 3, roles='', t='')
for l in open('/home/claude/data/edh_info.txt', encoding='utf-8'):
    n, ci, usd, ban, t, roles, mv = l.rstrip('\n').split('|')
    old = info.get(n, {})
    info[n] = dict(ci=ci, usd=old.get('usd', float(usd)) if old else float(usd), ban=bool(ban) or old.get('ban', False), roles=roles, t=t, mv=float(mv))
cand = json.load(open('/home/claude/data/edh_cand.json'))
NEED = {'draw': 'D', 'removal': 'RWC', 'ramp': 'M', 'finish': 'FK', 'protect': 'P', 'keep': 'DRWCMFKP'}
PH = {'D': 'card draw', 'R': 'removal', 'W': 'a board wipe', 'C': 'a counterspell', 'M': 'ramp', 'P': 'protection',
      'F': 'a finisher', 'K': 'makes bodies', 'U': 'a tutor', 'G': 'recursion'}
SHORT = lambda c: c.split(',')[0].split(' // ')[0]
def band_ok(tier, p):
    return p <= 2.5 if tier == 'Super budget' else 4.5 <= p <= 22 if tier == 'Medium' else True
def run():
    out = {}; G = {}; log = []
    for k, rows in OLD.items():
        M = importlib.import_module(k).META; ids = set(''.join(CI[c] for c in M['cmdr']))
        deck = {c['name'] for c in raw[M['file']]} | set(M['cmdr']) | set(M.get('secret', []))
        who = SHORT(M['cmdr'][0])
        C = [(n, i, s) for n, i, s in cand[k] if n in info and not info[n]['ban'] and set(info[n]['ci']) <= ids and n not in deck]
        C.sort(key=lambda x: -(x[1] + x[2] / 2))
        used = set(); new_rows = []
        for idx, r in enumerate(rows):
            role = ROLE[k][idx]; need = NEED[role]
            def does(n):
                ro = info[n]['roles']
                if n in SKIP: return False
                if role == 'finish': return 'F' in ro or ('K' in ro and 'M' not in ro)
                if role == 'ramp': return 'M' in ro and 'W' not in ro and info[n].get('mv', 0) <= 4
                return any(ch in ro for ch in need)
            fit = [x for x in C if does(x[0]) and x[1] + x[2] / 2 >= 20]
            wild = [x for x in C if x[0] not in SKIP and x[2] >= 30 and x[1] + x[2] / 2 >= 40] if role not in ('removal',) else []
            hand = [n for n, _ in DRAFT[k][idx][3]] if idx < len(DRAFT[k]) else []
            sw = []
            for slot in r['swaps']:
                tier = slot['tier']; pick = None
                for n, i, s in fit:
                    if n in used or any(x['card'] == n for x in sw) or G.get(n, 0) >= 4: continue
                    if not band_ok(tier, info[n]['usd']): continue
                    if tier == 'Any cost' and info[n]['usd'] < 4.5 and any(info[x[0]]['usd'] >= 4.5 and x[0] not in used for x in fit): continue
                    pick = (n, i, s); break
                if not pick:
                    for n in hand:
                        if n in info and n not in used and n not in deck and not info[n]['ban'] and set(info[n]['ci']) <= ids and band_ok(tier, info[n]['usd']) and not any(x['card'] == n for x in sw) and G.get(n, 0) < 4:
                            hr = dict(DRAFT[k][idx][3])[n]; pick = ('H', n, hr); break
                if not pick:
                    for n, i, s in wild:
                        if n in used or any(x['card'] == n for x in sw) or G.get(n, 0) >= 4 or not band_ok(tier, info[n]['usd']): continue
                        pick = (n, i, s); break
                if pick and pick[0] == 'H':
                    _, n, hr = pick
                    sw.append(dict(tier=tier, card=n, why=hr, usd=round(info[n]['usd'], 2))); used.add(n); G[n] = G.get(n, 0) + 1
                elif pick:
                    n, i, s = pick; ro = info[n]['roles']
                    what = ' and '.join(PH[ch] for ch in ro[:2]) if ro else 'a core piece of this commander\'s plan'
                    sw.append(dict(tier=tier, card=n, why=f"{what}; on {i:.0f}% of {who} decks on EDHREC (+{s:.0f}% synergy)", usd=round(info[n]['usd'], 2), edh=1))
                    used.add(n); G[n] = G.get(n, 0) + 1
                elif slot['card'] not in used and slot['card'] not in deck and not any(x['card'] == slot['card'] for x in sw):
                    sw.append(dict(slot)); used.add(slot['card']); G[slot['card']] = G.get(slot['card'], 0) + 1
                else:
                    sw.append(dict(slot, card='??'))
            new_rows.append(dict(r, swaps=sw))
            log.append((k, r['card'], role, [(x['card'], x['usd'], 'E' if x.get('edh') else 'h') for x in sw]))
        out[k] = new_rows
    return out, log
if __name__ == '__main__':
    out, log = run()
    for k, c, role, sw in log: print(k, '|', c, f'[{role}]', '|', ' / '.join(f'{n} ${u:g}{t}' for n, u, t in sw))
    json.dump(out, open('/home/claude/data/repair_edh.json', 'w'), indent=1, ensure_ascii=False)
