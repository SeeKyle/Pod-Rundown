# Moss_Mech: an original chunky little mech, drawn from shapes at native pixel size (64x56 frames, facing LEFT like the druid sheet).
from PIL import Image, ImageDraw
import numpy as np, math, random
FW,FH=64,56;OX,OY=33,53
P=dict(  # palette
 out=(12,20,16),g0=(22,48,33),g1=(37,84,56),g2=(62,124,78),g3=(118,178,104),stripe=(196,226,182),
 m0=(28,32,38),m1=(52,58,68),m2=(92,100,112),rust0=(98,52,26),rust1=(150,82,36),moss0=(84,112,34),moss1=(140,176,62),
 eye0=(20,110,170),eye1=(58,210,255),eye2=(230,255,255),b0=(18,96,200),b1=(70,190,255),b2=(220,250,255),fire0=(255,170,60),fire1=(255,240,170))
def rot(pts,ang,c):
    ca,sa=math.cos(ang),math.sin(ang);return [(c[0]+(x-c[0])*ca-(y-c[1])*sa,c[1]+(x-c[0])*sa+(y-c[1])*ca) for x,y in pts]
def rect(x0,y0,x1,y1):return [(x0,y0),(x1,y0),(x1,y1),(x0,y1)]
def seg(a,b,w):   # quad along a->b of width w
    dx,dy=b[0]-a[0],b[1]-a[1];L=math.hypot(dx,dy) or 1;nx,ny=-dy/L*w/2,dx/L*w/2
    return [(a[0]+nx,a[1]+ny),(b[0]+nx,b[1]+ny),(b[0]-nx,b[1]-ny),(a[0]-nx,a[1]-ny)]
PATCH=[(-7,-49,2.6,'m'),(2,-50,2.2,'m'),(6,-41,1.8,'r'),(-11,-37,1.4,'r'),(4,-24,2.0,'r'),(-6,-33,1.6,'m'),(-2,-22,1.3,'m'),(-8,-2,1.6,'r'),(-4,-12,1.2,'r')]
def make(pose):
    """pose: dict of joint params; returns RGBA frame"""
    g=pose.get;bob=g('bob',0);body_rot=g('tilt',0);sink=g('sink',0)
    parts=[]   # (pts, kind) kinds: plate (green), metal, dark, eye, blade, pod, fire
    T=lambda pts:pts
    hip=(0,-19+bob+sink)
    # legs (far leg first, darker)
    for side,(fx,lift),tone in [(1,g('farFoot',(3,0)),'metalD'),(-1,g('nearFoot',(-3,0)),'metal')]:
        hp=(hip[0]+side*-1+ (2 if side>0 else -1),hip[1]+3);foot=(fx,-1-lift)
        knee=((hp[0]+foot[0])/2-1,(hp[1]+foot[1])/2-1)
        parts.append((seg(hp,knee,6),tone));parts.append((seg(knee,foot,6),tone))
        parts.append((rect(foot[0]-6,foot[1]-3,foot[0]+4,foot[1]+1),'plateD' if side>0 else 'plate'))   # big flat foot (toe forward = left)
        parts.append((rect(knee[0]-3,knee[1]-3,knee[0]+3,knee[1]+2),'plateD' if side>0 else 'plate'))   # knee guard
    # far arm: gatling
    sh=(4,-28+bob+sink);ga=g('gat',1.35)   # angle from +x axis (pointing down = pi/2); forward (left) = pi
    el=(sh[0]+math.cos(ga)*6,sh[1]+math.sin(ga)*6)
    front_gun=g('gunFront',False)
    gunparts=[]
    gunparts.append((seg(sh,el,5),'metalD'))
    gun_end=(el[0]+math.cos(ga)*g('gunLen',12),el[1]+math.sin(ga)*g('gunLen',12))
    gunparts.append((seg(el,gun_end,6),'gun'))
    gunparts.append((seg(el,(el[0]+math.cos(ga)*4,el[1]+math.sin(ga)*4),8),'plateD'))   # gun housing
    if not front_gun:parts+=gunparts
    # missile pod on the back
    pod=g('pod',0)
    parts.append((rect(6,-47+bob+sink-pod,13,-31+bob+sink-pod),'pod'))
    # pelvis + torso
    parts.append((rect(-6,-23+bob+sink,6,-17+bob+sink),'metal'))
    parts.append(([(-9,-35+bob+sink),(8,-35+bob+sink),(7,-21+bob+sink),(-8,-21+bob+sink)],'plate'))
    parts.append((rect(-4,-31+bob+sink,2,-26+bob+sink),'metalL'))   # chest vent
    # head (big, rounded) with visor
    hy=-51+bob+sink+g('head',0)
    parts.append(([(-13,hy+4),(-10,hy),(6,hy),(9,hy+3),(9,hy+15),(-13,hy+15)],'plate'))
    parts.append((rect(-11,hy+2,-1,hy+3),'stripe'));parts.append((rect(-11,hy+5,-3,hy+6),'stripe'))
    parts.append((rect(-14,hy+8,-3,hy+12),'dark'))   # visor band
    if front_gun:parts+=gunparts
    # near arm: blade
    ba=g('blade',1.9);sh2=(-6,-31+bob+sink)
    el2=(sh2[0]+math.cos(ba+.25)*6,sh2[1]+math.sin(ba+.25)*6);fist=(el2[0]+math.cos(ba)*5,el2[1]+math.sin(ba)*5)
    parts.append((seg(sh2,el2,5),'metal'));parts.append((seg(el2,fist,5),'metal'))
    parts.append((rect(sh2[0]-4,sh2[1]-3,sh2[0]+3,sh2[1]+3),'plate'))   # shoulder pad
    bl=g('bladeLen',15);tip=(fist[0]+math.cos(ba)*bl,fist[1]+math.sin(ba)*bl)
    parts.append((seg(fist,tip,3.2),'blade'))
    parts.append((rect(fist[0]-2.5,fist[1]-2.5,fist[0]+2.5,fist[1]+2.5),'dark'))
    # transform whole body (death tilt) around the feet
    if body_rot:parts=[([(x-math.sin(body_rot)*24,y) for x,y in rot(p,body_rot,(4,0))],k) for p,k in parts]
    im=Image.new('RGBA',(FW,FH));kid=np.zeros((FH,FW),np.int16)
    KIND={'plate':1,'plateD':2,'metal':3,'metalD':4,'metalL':5,'dark':6,'stripe':7,'gun':8,'pod':9,'blade':10}
    for i,(pts,k) in enumerate(parts):
        m=Image.new('L',(FW,FH));ImageDraw.Draw(m).polygon([(OX+x,OY+y) for x,y in pts],fill=255)
        mm=np.array(m)>0;kid[mm]=KIND[k]*100+i
    return kid,pose
def paint(kid,pose,seed=0):
    rnd=random.Random(seed);H,W=kid.shape;out=np.zeros((H,W,4),np.uint8)
    kind=kid//100;part=kid%100
    base={1:P['g1'],2:P['g0'],3:P['m1'],4:P['m0'],5:P['m2'],6:P['m0'],7:P['stripe'],8:P['m1'],9:P['g0'],10:P['b1']}
    for y in range(H):
        for x in range(W):
            k=kind[y,x]
            if not kid[y,x]:continue
            c=base[k]
            up=kid[y-1,x] if y>0 else 0;dn=kid[y+1,x] if y<H-1 else 0;lf=kid[y,x-1] if x>0 else 0;rt=kid[y,x+1] if x<W-1 else 0
            if k in(1,2,9):
                if up!=kid[y,x]:c=P['g3'] if k==1 else P['g2']   # top rim light
                elif dn!=kid[y,x] or rt!=kid[y,x]:c=P['g0'] if k==1 else (14,32,22)
                bx,by=x-OX,y-OY-pose.get('bob',0)-pose.get('sink',0)
                if not pose.get('tilt'):
                    hsh=((bx*73856093)^(by*19349663))%100
                    for (px,py,r,kd) in PATCH:
                        d=math.hypot(bx-px,(by-py)*1.3)
                        if d<r-.4 or (d<r+.8 and hsh<45):
                            c=(P['rust1'] if hsh%3 else P['rust0']) if kd=='r' else (P['moss1'] if hsh%3 else P['moss0']);break
            if k in(3,4,5,6,8):
                if up!=kid[y,x] and k!=6:c=P['m2']
            if k==8:
                c=(150,160,172) if (x+y+pose.get('spin',0))%3==0 else ((92,100,112) if (x+y+pose.get('spin',0))%3==1 else (44,50,58))   # gatling barrels (spin = shift the stripes)
            if k==10:
                lum=(x*13+y*7+pose.get('spark',0)*5)%11
                c=P['b2'] if (up!=kid[y,x] or lum<2) else (P['b0'] if dn!=kid[y,x] else P['b1'])
            out[y,x]=(*c,255)
    # moss tufts on top surfaces of the head and shoulders
    for x in range(W):
        for y in range(1,H):
            if kind[y,x]==1 and kid[y-1,x]==0 and not pose.get('tilt'):
                bx=x-OX
                if -10<=bx<=-4 or 0<=bx<=4:
                    if (bx*7)%5<2:out[y-1,x]=(*P['moss1'],255)   # a few moss tufts poking up off the head
    # eye
    hy=pose.get('eyeY',None)
    a=out[...,3]>0
    # outline
    pad=np.pad(a,1);ring=(~a)&(pad[:-2,1:-1]|pad[2:,1:-1]|pad[1:-1,:-2]|pad[1:-1,2:])
    out[ring]=(*P['out'],255)
    return out
def eye(out,pose):
    hy=-51+pose.get('bob',0)+pose.get('sink',0)+pose.get('head',0);ex,ey=OX-10,OY+hy+9
    if pose.get('tilt'):return
    c=[P['eye0'],P['eye1'],P['eye2']] if not pose.get('dim') else [(20,40,50),(30,60,70),(40,80,90)]
    for dx,dy,k in [(0,0,1),(1,0,1),(0,1,1),(1,1,0),(-1,0,0),(-1,1,0),(0,-1,0),(1,-1,0),(0,0,2)]:
        out[ey+dy,ex+dx]=(*c[k],255)
def fire(out,pose):
    if not pose.get('flash'):return
    ga=pose.get('gat',1.35);L=pose.get('gunLen',12)+1;sh=(4,-28+pose.get('bob',0));el=(sh[0]+math.cos(ga)*6,sh[1]+math.sin(ga)*6);e=(el[0]+math.cos(ga)*L,el[1]+math.sin(ga)*L)
    x,y=int(round(OX+e[0])),int(round(OY+e[1]))
    for dx,dy,c in [(0,0,'fire1'),(-1,0,'fire1'),(-2,0,'fire0'),(-3,0,'fire0'),(-1,-1,'fire0'),(-1,1,'fire0'),(-4,0,'fire0')]:
        if 0<=x+dx<FW and 0<=y+dy<FH:out[y+dy,x+dx]=(*P[c],255)
def pod_open(out,pose):
    if pose.get('pod',0)<2:return
    y0=OY-47+pose.get('bob',0)-pose.get('pod',0)
    for i,x in enumerate((7,10)):
        for yy in range(y0-3,y0):out[yy,OX+x]=(*P['m2'],255);out[yy,OX+x+1]=(*P['m1'],255)
        out[y0-4,OX+x]=(*P['fire0'],255);out[y0-4,OX+x+1]=(220,60,40,255)
def frame(**pose):
    kid,pose=make(pose);o=paint(kid,pose,pose.get('seed',0));eye(o,pose);fire(o,pose);pod_open(o,pose);return o
REST_B=1.95;REST_G=1.45
rows={}
rows['idle']=[frame(bob=b,spark=i) for i,b in enumerate([0,0,1,1])]
walk=[];
for i in range(8):
    ph=i/8*2*math.pi;nf=(-3+5*math.cos(ph),max(0,2*math.sin(ph)));ff=(3-5*math.cos(ph),max(0,-2*math.sin(ph)))
    walk.append(frame(bob=0 if i%4 in(0,2) else -1,nearFoot=nf,farFoot=ff,spark=i,blade=REST_B+.08*math.sin(ph),gat=REST_G-.08*math.sin(ph)))
rows['walk']=walk
rows['melee']=[frame(blade=-1.2,spark=1),frame(blade=-2.2,head=0,spark=2),frame(blade=math.pi+.05,bladeLen=17,spark=3,nearFoot=(-5,0)),frame(blade=2.6,spark=4)]
rows['ranged']=[frame(gat=math.pi-.04,gunFront=True,gunLen=20,spin=s,flash=f,spark=s,blade=2.25) for s,f in [(0,0),(1,1),(2,0),(0,1)]]
rows['missile']=[frame(pod=p,gat=REST_G,head=0) for p in (0,2,3,2)]
rows['throw']=[frame(blade=-1.6),frame(blade=-2.6),frame(blade=math.pi+.4)]
rows['hurt']=[frame(tilt=.12,blade=2.3),frame(tilt=.05)]
rows['death']=[frame(tilt=.2,dim=0),frame(tilt=.5,sink=2),frame(tilt=.9,sink=3,dim=1),frame(tilt=1.25,sink=4,dim=1),frame(tilt=1.45,sink=5,dim=1)]
order=['walk','idle','melee','ranged','missile','throw','hurt','death']
S=Image.new('RGBA',(FW*8,FH*len(order)));meta={}
for r,n in enumerate(order):
    for i,f in enumerate(rows[n]):S.alpha_composite(Image.fromarray(f,'RGBA'),(i*FW,r*FH))
    meta[n]=dict(n=len(rows[n]),y=r*FH)
S.save('/home/claude/pod2/crawl_robot.png',optimize=True)
import json;json.dump(meta,open('meta.json','w'));print(meta)
bg=Image.new('RGBA',S.size,(40,40,50,255));bg.alpha_composite(S);bg.resize((S.width*3,S.height*3),Image.NEAREST).save('/tmp/robot.png')
