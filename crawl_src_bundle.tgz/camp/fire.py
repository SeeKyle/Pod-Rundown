from PIL import Image, ImageDraw
import random, math
W,H=34,40;GY=37
K=(20,14,12,255);LOG=(112,70,38,255);LOGD=(72,44,24,255);RING=(186,142,92,255);STONE=(118,116,124,255);STONED=(70,70,80,255)
CH=(42,36,34,255);CHL=(70,60,56,255);EMB=(255,120,40,255)
def base(d,charred=False):
    for i,x in enumerate(range(3,W-3,5)):            # stone ring
        c=STONED if i%2 else STONE;d.ellipse([x,GY-3,x+5,GY+2],fill=K);d.ellipse([x+1,GY-2,x+4,GY+1],fill=c)
    lc,ld=(CH,CHL) if charred else (LOG,LOGD)
    d.line([(7,GY-1),(27,GY-6)],fill=K,width=5);d.line([(7,GY-1),(27,GY-6)],fill=lc,width=3)   # crossed logs
    d.line([(8,GY-6),(27,GY-1)],fill=K,width=5);d.line([(8,GY-6),(27,GY-1)],fill=ld,width=3)
    if not charred:
        for (x,y) in [(6,GY-3),(28,GY-7),(7,GY-8),(28,GY-2)]:d.point((x,y),fill=RING)
    d.line([(17,GY-2),(14,GY-12)],fill=K,width=3);d.line([(17,GY-2),(14,GY-12)],fill=ld,width=1)   # kindling teepee
    d.line([(17,GY-2),(20,GY-12)],fill=K,width=3);d.line([(17,GY-2),(20,GY-12)],fill=lc,width=1)
def flame(d,h,seed,wide=1.0):
    r=random.Random(seed);cx=17
    layers=[((236,84,30,255),1.0),((252,160,44,255),.72),((255,226,110,255),.45),((255,248,210,255),.2)]
    for col,s in layers:
        hh=h*s;pts=[]
        n=9
        for i in range(n+1):
            t=i/n;ang=math.pi*t;rad=(6*wide)*s+1
            x=cx-math.cos(ang)*rad;y=GY-3-math.sin(ang)*rad*0.6
            pts.append((x,y))
        tip=(cx+r.uniform(-2,2),GY-3-hh)
        poly=[pts[0]]+[(cx-(6*wide*s+1)*.6+r.uniform(-1,1),GY-3-hh*.55),tip,(cx+(6*wide*s+1)*.6+r.uniform(-1,1),GY-3-hh*.5)]+[pts[-1]]+list(reversed(pts[1:-1]))
        d.polygon(poly,fill=col)
        if s==1.0:   # little side tongues
            d.polygon([(cx-5*wide,GY-5),(cx-7*wide+r.uniform(-1,1),GY-5-hh*.45),(cx-2,GY-7)],fill=col)
            d.polygon([(cx+5*wide,GY-5),(cx+7*wide+r.uniform(-1,1),GY-5-hh*.4),(cx+2,GY-7)],fill=col)
def frame(kind,i):
    im=Image.new('RGBA',(W,H));d=ImageDraw.Draw(im)
    if kind=='unlit':base(d)
    elif kind=='start':base(d);flame(d,[4,8,13][i],[.45,.65,.85][i],seed=100+i) if False else (base(d),flame(d,[4,8,13][i],100+i,[.45,.65,.85][i]))
    elif kind=='burn':base(d);flame(d,[22,20,23,21][i],200+i)
    elif kind=='dying':base(d,charred=i>=1);flame(d,[12,7,3][i],300+i,[.8,.6,.4][i])
    elif kind=='dead':
        base(d,charred=True)
        for p in [(13,GY-4),(19,GY-5),(22,GY-3),(16,GY-6)]:d.point(p,fill=EMB)
    return im
frames=[('unlit',0)]+[('start',i) for i in range(3)]+[('burn',i) for i in range(4)]+[('dying',i) for i in range(3)]+[('dead',0)]
sheet=Image.new('RGBA',(W*len(frames),H))
for j,(k,i) in enumerate(frames):sheet.alpha_composite(frame(k,i),(j*W,0))
sheet.save('/home/claude/pod2/crawl_campfire.png')
pv=Image.new('RGBA',sheet.size,(40,34,44,255));pv.alpha_composite(sheet);pv.resize((sheet.width*4,sheet.height*4),Image.NEAREST).save('/tmp/fire.png')
