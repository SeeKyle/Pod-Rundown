import numpy as np
from PIL import Image, ImageDraw
im=Image.open('/home/claude/pod2/assets/heroes/flannel/idle.png').convert('RGBA')
base=im.crop((0,0,230,208)).transpose(Image.FLIP_LEFT_RIGHT)   # facing right
HIP,G=152,201
def piece(img,x0,x1,y0,y1):return img.crop((x0,y0,x1,y1))
def kneel(D,lighter=0):
    f=Image.new('RGBA',base.size)
    upper=base.crop((0,0,230,HIP));f.alpha_composite(upper,(0,D))
    nh=HIP+D
    if D==0:f.alpha_composite(base.crop((0,HIP,230,208)),(0,HIP));return f
    full=D>=22
    bthigh=piece(base,66,92,HIP,176);bshin=piece(base,66,92,176,205)
    fthigh=piece(base,92,124,HIP,176);fshin=piece(base,92,124,176,205)
    if not full:   # half crouch: legs squashed under the lowered body
        legs=base.crop((60,HIP,130,205));h=205-HIP;nhh=h-D
        f.alpha_composite(legs.resize((70,nhh),Image.NEAREST),(60,nh));return f
    # back leg: thigh straight down to the knee on the ground, shin folded back along the ground
    f.alpha_composite(bthigh,(66,nh-2))
    sh=bshin.rotate(-90,expand=True);f.alpha_composite(sh,(66-sh.width+14,G-sh.height+3))
    # front leg: thigh forward (horizontal), shin straight down to the foot
    th=fthigh.rotate(90,expand=True);f.alpha_composite(th,(96,nh-th.height//2+2))
    knee=96+th.width-14;f.alpha_composite(fshin,(knee,G-fshin.height+3))
    d=ImageDraw.Draw(f)
    if lighter:
        hx,hy=80,147+D-2   # his hand at his side, now lowered with the kneel
        d.rectangle([hx+2,hy-7,hx+6,hy],fill=(30,30,36,255));d.rectangle([hx+3,hy-6,hx+5,hy-1],fill=(150,154,170,255))   # the lighter
        if lighter>=2:
            fl=[(255,236,150,255),(255,170,50,255),(240,90,30,255)]
            hgt=5 if lighter==2 else 8
            d.ellipse([hx+1,hy-7-hgt,hx+7,hy-6],fill=fl[2]);d.ellipse([hx+2,hy-6-hgt+2,hx+6,hy-6],fill=fl[1]);d.ellipse([hx+3,hy-6-hgt+4,hx+5,hy-6],fill=fl[0])
        else:
            for p in [(hx+5,hy-9),(hx+7,hy-11),(hx+3,hy-10)]:d.point(p,fill=(255,220,120,255))
    return f
frames=[kneel(0),kneel(12),kneel(24),kneel(24,1),kneel(24,2),kneel(24,3)]
row=Image.new('RGBA',(230*len(frames),208))
for i,fr in enumerate(frames):row.alpha_composite(fr.transpose(Image.FLIP_LEFT_RIGHT),(i*230,0))
row.save('/home/claude/pod2/assets/heroes/flannel/kneel.png')
b=Image.new('RGBA',(230*len(frames),208),(94,107,100,255))
for i,fr in enumerate(frames):b.alpha_composite(fr,(i*230,0))
b.crop((0,30,230*6,208)).save('/tmp/kneel.png');b.crop((230*5+30,60,230*5+170,208)).resize((420,444),Image.NEAREST).save('/tmp/kneelz.png')
