import numpy as np, os
from PIL import Image
from scipy import ndimage as nd
from skimage.color import rgb2hsv
S=np.array(Image.open('s.jpg').convert('RGBA')).astype(np.uint8);RGB=S[...,:3].astype(int)
BG=np.array([109,116,134]);fg=np.abs(RGB-BG).sum(2)>48;fg[:,:250]=False
dk0=RGB.sum(2)<150;dl,dn=nd.label(dk0);
for i,sl in enumerate(nd.find_objects(dl)):
    if sl and sl[1].stop-sl[1].start>400: fg[sl]&=~(dl[sl]==i+1)   # the slanted black row separators
# reds a smidgen darker, except a thin highlight strip along the top of each red patch (Kyle)
hsv=rgb2hsv(RGB/255.);H,Sa,V=hsv[...,0]*360,hsv[...,1],hsv[...,2]
red=fg&((H>=335)|(H<=12))&(Sa>=.4)&(V>=.25)
lab,n=nd.label(red);keep=np.zeros_like(red)
up=np.roll(red,3,axis=0);keep=red&~up      # the top 3px of each red patch stays bright
dk=red&~keep
S[dk,:3]=(S[dk,:3].astype(float)*np.array([.84,.8,.82])).astype(np.uint8)
ROWS={'idle':(0,262),'walk':(265,473),'run':(476,681),'melee':(684,943),'ranged':(946,1264),'hurt':(1267,1465),'death':(1468,1859)}
L,R,U=170,200,250;OUT='/home/claude/pod2/assets/heroes/archer/';os.makedirs(OUT,exist_ok=True)
info={}
for name,(y0,y1) in ROWS.items():
    m0=fg.copy();m0[:y0]=False;m0[y1:]=False
    lab,n=nd.label(nd.binary_dilation(m0,iterations=2));objs=nd.find_objects(lab);comps=[]
    for i,sl in enumerate(objs):
        if not sl:continue
        mm=(lab[sl]==i+1)&m0[sl]
        if mm.sum()<5:continue
        comps.append((i,sl,mm.sum(),(sl[1].start+sl[1].stop)/2))
    bodies=sorted([c for c in comps if c[2]>2500 and (c[1][0].stop-c[1][0].start)>40],key=lambda c:c[3])
    groups=[[b] for b in bodies]
    for c in comps:
        if c in bodies:continue
        k=int(np.argmin([abs(c[3]-b[3]) for b in bodies]));groups[k].append(c)
    frames=[];anch=[]
    for g in groups:
        m=np.zeros(fg.shape,bool)
        for j,(i,sl,_,_) in enumerate(g):
            mm=(lab[sl]==i+1)&m0[sl]
            if j==0:
                hole=nd.binary_fill_holes(mm)&~mm;hl,hn=nd.label(hole);sz=nd.sum(hole,hl,range(1,hn+1))
                small=np.isin(hl,[k+1 for k,v in enumerate(sz) if v<120]);mm=mm|small   # plug pin-holes only (not the gap inside the bow)
            m[sl]|=mm
        ys,xs=np.nonzero(m);gy=ys.max()
        band=m[gy-150:gy-60] if name in ('walk','run','hurt') else m[gy-30:gy+1];fy,fx=np.nonzero(band);ax=int(np.median(fx))   # walk/run: anchor on the torso so strides don't jitter
        x0,yb=ax-L,gy-U;c=np.zeros((U+8,L+R,4),np.uint8)
        for yy in range(max(0,yb),min(S.shape[0],gy+8)):
            row=m[yy,max(0,x0):x0+L+R];px=S[yy,max(0,x0):x0+L+R].copy();px[...,3]=np.where(row,255,0)
            c[yy-yb,max(0,x0)-x0:max(0,x0)-x0+len(row)]=px
        frames.append(np.ascontiguousarray(c[:,::-1]));anch.append((ax,gy))
    Image.fromarray(np.concatenate(frames,1)).save(OUT+name+'.png');info[name]=(len(frames),anch)
print(info)
