import numpy as np, math
from PIL import Image, ImageDraw
from skimage.color import rgb2hsv
src=Image.open('/home/claude/pod2/assets/heroes/archer/ranged.png').convert('RGBA')
base=src.crop((3*370,0,4*370,258)).transpose(Image.FLIP_LEFT_RIGHT)   # full-draw pose: both arms forward, rear hand at his chin
A=np.array(base).astype(int);H,W=A.shape[:2];al=A[...,3]>0
hsv=rgb2hsv(np.clip(A[...,:3],0,255)/255.);hue,sat,val=hsv[...,0]*360,hsv[...,1],hsv[...,2]
Y,X=np.mgrid[0:H,0:W]
skin=al&(hue>=12)&(hue<=40)&(sat>.25)&(val>.55)
orange=al&(hue>=18)&(hue<=45)&(sat>.45)&(val>.45)
# 1) take the bow, its string and the arrow out
arm=(X>=192)&(X<=232)&(Y>=139)&(Y<=161)                 # both forearms and hands
erase=al&(((X>=223)&(Y>=139)&(Y<=163)&~skin)|((X>=196)&(Y<139))|((X>=233)&(Y<230))|((X>=204)&(Y>=161)&(Y<232)&~orange)|((X>=201)&(X<=206)&~arm&(Y<232)))
above=(Y<138+0.342*(X-176)-3.5)&(X>=186)&(X<=245)&(Y>=128)&~skin   # arrow, string and grip leftovers above the tube
erase|=al&above
A[erase,3]=0
hands=skin&arm                                          # keep the hands to paint back over the tube
handpx=A.copy()
im=Image.fromarray(A.astype(np.uint8))
OUT=(16,44,30,255);G1=(62,152,74,255);G2=(110,200,108,255);G3=(36,104,56,255);NODE=(24,74,40,255)
def tube(d,x0,y0,x1,y1,th=6):
    L=math.hypot(x1-x0,y1-y0);dx,dy=(x1-x0)/L,(y1-y0)/L;nx,ny=-dy,dx
    P=lambda t,o:(x0+dx*t+nx*o,y0+dy*t+ny*o)
    d.polygon([P(0,-th/2-1),P(L,-th/2-1),P(L,th/2+1),P(0,th/2+1)],fill=OUT)
    d.polygon([P(1,-th/2),P(L-1,-th/2),P(L-1,th/2),P(1,th/2)],fill=G1)
    d.line([P(2,-th/2+1),P(L-2,-th/2+1)],fill=G2,width=2)
    d.line([P(2,th/2-.5),P(L-2,th/2-.5)],fill=G3,width=1)
    for t in range(14,int(L)-6,16):
        d.polygon([P(t-1,-th/2-2),P(t+2,-th/2-2),P(t+2,th/2+2),P(t-1,th/2+2)],fill=OUT)
        d.line([P(t+.5,-th/2-1),P(t+.5,th/2+1)],fill=NODE,width=2)
    d.polygon([P(L-1,-th/2-1),P(L+1,-th/2),P(L+1,th/2),P(L-1,th/2+1)],fill=OUT)   # open end
    return P(L+2,0)
frames=[];tip=None
for k,puff in enumerate([0,0,1,2]):
    f=im.copy();d=ImageDraw.Draw(f)
    lift=[1,0,0,-1][k]                                  # a tiny rise as he blows
    tip=tube(d,176,138+lift,258,166+lift)   # mouth -> rear hand -> front hand, angled down along his arms
    fa=np.array(f).astype(int);fa[hands]=handpx[hands];f=Image.fromarray(fa.astype(np.uint8));d=ImageDraw.Draw(f)   # fingers wrap over the tube
    if puff:
        r=3+2*puff;a=210 if puff==1 else 120
        for j in range(3):d.ellipse([tip[0]+j*4-r+3,tip[1]-r+(j%2),tip[0]+j*4+r+1,tip[1]+r-(j%2)],fill=(232,238,228,a))
    frames.append(f.transpose(Image.FLIP_LEFT_RIGHT))
row=Image.new('RGBA',(370*len(frames),258))
for i,f in enumerate(frames):row.alpha_composite(f,(i*370,0))
row.save('/home/claude/pod2/assets/heroes/archer/blowgun.png');print('tip',tip)
b=Image.new('RGBA',row.size,(94,107,100,255));b.alpha_composite(row);bb=b.transpose(Image.FLIP_LEFT_RIGHT)
bb.crop((370*3+100,90,370*3+300,258)).resize((600,504),Image.NEAREST).save('/tmp/bgz.png')
bb.crop((370*1+100,90,370*1+300,258)).resize((600,504),Image.NEAREST).save('/tmp/bgz2.png')
