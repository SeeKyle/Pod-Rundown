from eng import *
import random
RB=ramp((18,8,28),(38,16,56),(62,28,92),(92,48,132),(132,84,176))      # 0.12.22: deep purple robe
HD=ramp((6,5,10),(14,12,20),(26,22,34),(42,36,54),(66,58,84))      # black hood / mantle
BN=ramp((40,36,44),(84,78,90),(132,124,140),(170,162,178),(204,198,212))   # ashen bone mask
LT=ramp((10,8,14),(22,18,30),(38,32,50),(58,50,74),(84,74,104))   # black leather sash, boots
SK=ramp((40,34,46),(78,68,88),(118,106,128),(152,140,164),(186,176,198))   # pale hands
DG=ramp((30,32,38),(60,64,74),(110,116,130),(170,176,190),(230,234,244))    # dagger
VI=(176,92,255)
def cultist(p):
    g=p.get;b=g('bob',0)+g('sink',0);ln=g('lean',0);f=F(g('tilt',0));sw=g('sw',0);hem=g('hem',0)
    # far arm (sleeve) behind the body
    fa=g('far',1.75-.3*sw);fsh=(5+ln,-36+b);fe=pol(fsh,fa,9);fh=pol(fe,fa-.15,6)
    f.add(seg(fsh,fe,7,8),dk(RB));f.add(seg(fe,fh,7,4),dk(RB));f.add(ell(fh[0],fh[1],2.2,2.2,10),dk(SK),'sph')
    # feet peeking under the hem
    for side,key in ((1,'ff'),(-1,'nf')):
        fx,lift=g(key,(side*3,0));f.add(oct(fx-4,-3-lift,fx+3,0-lift,1),LT if side<0 else dk(LT))
    # robe: long, flaring, tattered hem that sways
    top=-40+b;hemy=-2
    pts=[(-8+ln,top),(7+ln,top),(11+hem*.6,hemy-2),(9+hem,hemy+1),(6+hem,hemy-1),(3+hem*.5,hemy+1),(0,hemy-1),(-3-hem*.3,hemy+1),(-6-hem*.5,hemy-1),(-9-hem*.7,hemy+1),(-12-hem*.4,hemy-2)]
    f.add(pts,RB)
    f.add([(-3+ln,top+2),(1+ln,top+2),(1+hem*.3,hemy-1),(-3+hem*.2,hemy)],dk(RB,.85))   # front panel
    f.line((-3+ln,top+3),(-2+hem*.2,hemy-2),RB[0]);f.line((1+ln,top+3),(1+hem*.3,hemy-2),RB[0])
    # sash with brass clasp
    f.add([(-9+ln,-25+b),(8+ln,-25+b),(8+ln,-21+b),(-9+ln,-21+b)],LT)
    f.add(rect(-3+ln,-25+b,1+ln,-21+b),ramp((50,20,70),(90,40,130),(140,70,200),(190,120,240),(230,190,255)))
    f.line((5+ln,-21+b),(6+ln+hem*.2,-14+b),LT[2]);f.line((6+ln,-21+b),(7+ln+hem*.3,-15+b),LT[1])   # hanging sash tail
    # mantle / hood
    f.add([(-11+ln,-41+b),(10+ln,-42+b),(12+ln,-34+b),(6+ln,-31+b),(-8+ln,-31+b),(-13+ln,-35+b)],HD)   # shoulder mantle
    f.add([(-8+ln,-56+b),(-2+ln,-60+b),(5+ln,-58+b),(9+ln,-50+b),(8+ln,-41+b),(-9+ln,-40+b),(-11+ln,-48+b)],HD)   # hood
    f.add([(-10+ln,-53+b),(-3+ln,-53+b),(-2+ln,-44+b),(-6+ln,-42+b),(-10+ln,-46+b)],[(6,6,12)]*5,'flat')   # the dark inside of the hood
    # bone mask
    f.add([(-10+ln,-52+b),(-4+ln,-52+b),(-3+ln,-46+b),(-6+ln,-43+b),(-9+ln,-45+b)],BN)
    # 0.12.22: two small glowing red eyes in the dark eye holes (a hot core, a dim ember ring)
    for ex in (-8,-5):
        f.dot(ex-1+ln,-49+b,(70,8,12));f.dot(ex+1+ln,-49+b,(70,8,12))
        f.dot(ex+ln,-49+b,(255,70,60) if not g('dim') else (50,14,16));f.dot(ex+ln,-50+b,(150,20,24) if not g('dim') else (30,10,12))
    f.line((-7+ln,-46+b),(-5+ln,-46+b),BN[0]);f.dot(-6+ln,-45+b,BN[0])
    # near arm: sleeve + hand + curved ritual dagger
    na=g('near',1.95+.35*sw);nsh=(-6+ln,-37+b);ne=pol(nsh,na,9);nh=pol(ne,g('fore',na-.2),6)
    f.add(seg(nsh,ne,7,8),RB);f.add(seg(ne,nh,8,4),RB)
    f.add(ell(nh[0],nh[1],2.4,2.4,10),SK,'sph')
    if not g('nodagger'):
        da=g('dag',g('fore',na-.2));t1=pol(nh,da,5);t2=pol(t1,da+.5,5)
        f.add([pol(nh,da+1.57,1.2),pol(t1,da+1.57,1.4),t2,pol(t1,da-1.57,.6),pol(nh,da-1.57,1.2)],DG)
    # glowing sigil in the casting hand
    if g('orb'):
        r=g('orb');f.add(ell(nh[0]-1,nh[1]-1,r,r,12),ramp((40,10,70),(80,30,140),(130,60,220),(180,110,255),(230,200,255)),'sph',seam=False)
    if g('orb2'):
        r=g('orb2');f.add(ell(fh[0],fh[1]-1,r,r,12),ramp((40,10,70),(80,30,140),(130,60,220),(180,110,255),(230,200,255)),'sph',seam=False)
    return f
def ash(out,k,seed):   # death: the body crumbles to ash from the top down
    rnd=random.Random(seed);H,W,_=out.shape
    ys,xs=np.nonzero(out[...,3]>0)
    if not len(ys):return out
    y0,y1=ys.min(),ys.max();cut=y0+(y1-y0)*k
    for y,x in zip(ys,xs):
        if y<cut or rnd.random()<k*.5:
            out[y,x,3]=0
            if rnd.random()<.12:
                ny=min(H-1,int(y+(y1-y)*k*rnd.random()));nx=min(W-1,max(0,x+rnd.randint(-2,2)));c=rnd.choice([(40,36,44),(70,60,66),(150,70,255)]);out[ny,nx]=(*c,255)
    return out
def poses():
    R={}
    R['idle']=[dict(bob=[0,0,1,1][i],sw=.1*math.sin(i*1.57),hem=math.sin(i*1.57)) for i in range(4)]
    R['walk']=[]
    for i in range(8):
        ph=i/8*2*math.pi;R['walk'].append(dict(bob=-round(abs(math.sin(ph))),sw=math.sin(ph),hem=2*math.sin(ph+.8),nf=(-3+5*math.cos(ph),max(0,2*math.sin(ph))),ff=(3-5*math.cos(ph),max(0,-2*math.sin(ph)))))
    R['melee']=[dict(near=-1.2,fore=-1.0,lean=1,hem=1),dict(near=-2.1,fore=-2.4,lean=1,hem=1.5),dict(near=math.pi-.2,fore=math.pi+.15,lean=-2,hem=-2,nf=(-6,0)),dict(near=2.6,fore=2.2,lean=-1,hem=-1)]
    R['ranged']=[dict(near=2.7,fore=2.9,orb=1.5,lean=1),dict(near=math.pi-.1,fore=math.pi,orb=2.5,lean=0),dict(near=math.pi-.05,fore=math.pi+.05,orb=3.2,lean=-1,hem=-1),dict(near=2.8,fore=2.9,orb=1.2)]
    R['summon']=[dict(near=-1.9,fore=-1.9,far=-1.3,orb=1.5,orb2=1.5,nodagger=1,bob=0),dict(near=-2.0,fore=-2.1,far=-1.2,orb=2.4,orb2=2.4,nodagger=1,bob=-1,hem=1),dict(near=-2.05,fore=-2.2,far=-1.15,orb=3,orb2=3,nodagger=1,bob=-1,hem=-1),dict(near=2.3,fore=2.2,far=1.0,orb=1.6,orb2=1.6,nodagger=1,lean=-1,bob=1)]
    R['hurt']=[dict(tilt=.1,lean=2,near=2.4,hem=2),dict(tilt=.04,lean=1,hem=1)]
    R['death']=[dict(tilt=.08,sink=1,hem=1),dict(sink=2,dim=1,k=.15),dict(sink=3,dim=1,k=.35),dict(sink=3,dim=1,k=.6),dict(sink=3,dim=1,k=.85)]
    return R
ORDER=('walk','idle','melee','ranged','summon','hurt','death')
R=poses();rows={}
for k,v in R.items():
    rows[k]=[]
    for j,p in enumerate(v):
        o=cultist(p).render()
        if p.get('k'):o=ash(o,p['k'],j*7+3)
        rows[k].append(o)
S=Image.new('RGBA',(FW*8,FH*len(ORDER)))
for r,n in enumerate(ORDER):
    for i,fr in enumerate(rows[n]):S.alpha_composite(Image.fromarray(fr,'RGBA'),(i*FW,r*FH))
S.save('/home/claude/cult/cultist.png')
bg=Image.new('RGBA',S.size,(30,26,38,255));bg.alpha_composite(S);bg.resize((S.width*3,S.height*3),Image.NEAREST).save('/tmp/cult.png')
import json;json.dump({n:dict(n=len(rows[n]),y=r*FH) for r,n in enumerate(ORDER)},open('cult_meta.json','w'))
seq=[]
for n,rep,dur in [('idle',2,180),('walk',2,100),('melee',1,110),('ranged',1,120),('summon',1,160),('hurt',1,140),('death',1,180)]:
    for _ in range(rep):
        for fr in rows[n]:
            im=Image.new('RGBA',(FW,FH),(30,26,38,255));im.alpha_composite(Image.fromarray(fr,'RGBA'));seq.append((im.resize((FW*5,FH*5),Image.NEAREST).convert('P',palette=Image.ADAPTIVE,colors=128),dur))
seq[0][0].save('/home/claude/cult/cultist.gif',save_all=True,append_images=[a for a,_ in seq[1:]],duration=[d for _,d in seq],loop=0,disposal=2)
