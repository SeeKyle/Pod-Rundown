from PIL import Image, ImageDraw
import numpy as np, math
FW,FH=64,66;OX,OY=32,63
def rot(pts,ang,c):
    ca,sa=math.cos(ang),math.sin(ang);return [(c[0]+(x-c[0])*ca-(y-c[1])*sa,c[1]+(x-c[0])*sa+(y-c[1])*ca) for x,y in pts]
def rect(x0,y0,x1,y1):return [(x0,y0),(x1,y0),(x1,y1),(x0,y1)]
def oct(x0,y0,x1,y1,c=2):return [(x0+c,y0),(x1-c,y0),(x1,y0+c),(x1,y1-c),(x1-c,y1),(x0+c,y1),(x0,y1-c),(x0,y0+c)]
def seg(a,b,w,w2=None):
    w2=w if w2 is None else w2;dx,dy=b[0]-a[0],b[1]-a[1];L=math.hypot(dx,dy) or 1;nx,ny=-dy/L,dx/L
    return [(a[0]+nx*w/2,a[1]+ny*w/2),(b[0]+nx*w2/2,b[1]+ny*w2/2),(b[0]-nx*w2/2,b[1]-ny*w2/2),(a[0]-nx*w/2,a[1]-ny*w/2)]
def ell(cx,cy,rx,ry,n=16):return [(cx+rx*math.cos(t*2*math.pi/n),cy+ry*math.sin(t*2*math.pi/n)) for t in range(n)]
def pol(a,ang,L):return (a[0]+math.cos(ang)*L,a[1]+math.sin(ang)*L)
def shiftp(pts,dx,dy):return [(x+dx,y+dy) for x,y in pts]
OUTC=(12,10,14)
def ramp(*cs):return [tuple(c) for c in cs]
class F:
    def __init__(s,tilt=0):s.parts=[];s.dec=[];s.tilt=tilt
    def add(s,pts,pal,mode='box',axis=0,seam=True):s.parts.append(dict(pts=pts,pal=pal,mode=mode,axis=axis,seam=seam))
    def cyl(s,a,b,w,pal,w2=None):s.add(seg(a,b,w,w2),pal,'cyl',math.atan2(b[1]-a[1],b[0]-a[0]))
    def dot(s,x,y,c):s.dec.append((x,y,c))
    def line(s,a,b,c):
        n=int(max(abs(b[0]-a[0]),abs(b[1]-a[1])))+1
        for i in range(n+1):t=i/max(1,n);s.dot(a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,c)
    def rivet(s,x,y,pal):s.dot(x,y,pal[4]);s.dot(x+1,y+1,pal[1])
    def seamline(s,a,b,pal):s.line(a,b,pal[1]);s.line((a[0],a[1]+1),(b[0],b[1]+1),pal[3])
    def T(s,pts):
        if s.tilt:pts=rot(pts,s.tilt,(6,0))
        return [(OX+x-math.sin(s.tilt)*24,OY+y) for x,y in pts]
    def render(s,dim=False):
        H,W=FH,FW;kid=np.full((H,W),-1,np.int32);bbs=[]
        for i,P in enumerate(s.parts):
            m=Image.new('L',(W,H));ImageDraw.Draw(m).polygon(s.T(P['pts']),fill=255);mm=np.array(m)>0;kid[mm]=i
            ys,xs=np.nonzero(mm);bbs.append((xs.min(),ys.min(),xs.max(),ys.max()) if len(xs) else (0,0,1,1))
            P['T']=s.T(P['pts'])
        out=np.zeros((H,W,4),np.uint8)
        same=lambda y,x,i:0<=y<H and 0<=x<W and kid[y,x]==i
        for y in range(H):
            for x in range(W):
                i=kid[y,x]
                if i<0:continue
                P=s.parts[i];pal=P['pal']
                if P['mode']=='flat':out[y,x]=(*pal[2],255);continue
                x0,y0,x1,y1=bbs[i]
                if P['mode']=='cyl':
                    ax=P['axis']+s.tilt;nx,ny=-math.sin(ax),math.cos(ax)
                    # coordinate across the tube, 0 = top-left side
                    ds=[(px-OX)*nx+(py-OY)*ny for px,py in P['T']];lo,hi=min(ds),max(ds);u=((x-OX)*nx+(y-OY)*ny-lo)/max(1,hi-lo)
                    if ny<0:u=1-u
                    k=0 if u>.86 else 1 if u>.66 else 2 if u>.38 else 4 if .16<u<.3 else 3
                elif P['mode']=='sph':
                    cx,cy=(x0+x1)/2,(y0+y1)/2;r=max(1,(x1-x0+y1-y0)/4);d=math.hypot(x-(cx-r*.35),y-(cy-r*.35))/r
                    k=4 if d<.28 else 3 if d<.62 else 2 if d<1.05 else 1 if d<1.35 else 0
                else:
                    t=(x-x0)/max(1,x1-x0)*.4+(y-y0)/max(1,y1-y0)*.6
                    k=3 if t<.22 else 2 if t<.62 else 1 if t<.86 else 0
                    if not same(y-1,x,i):k=4 if t<.55 else 3     # lit top rim
                    elif not same(y,x-1,i) and t<.6:k=max(k,3)
                    if not same(y+1,x,i) or not same(y,x+1,i):k=min(k,1) if t>.3 else k
                    if not same(y+1,x,i):k=0
                c=pal[k]
                if P['seam']:
                    for dy,dx in((-1,0),(0,-1),(1,0),(0,1)):
                        j=kid[y+dy,x+dx] if 0<=y+dy<H and 0<=x+dx<W else -1
                        if j>i and s.parts[j]['seam'] and s.parts[j]['mode']!='flat':c=tuple(int(v*.5) for v in pal[0]);break
                out[y,x]=(*c,255)
        for x,y,c in s.dec:
            X,Y=s.T([(x,y)])[0];X,Y=int(round(X)),int(round(Y))
            if 0<=X<W and 0<=Y<H and out[Y,X,3]:out[Y,X]=(*c,255)
        a=out[...,3]>0;pad=np.pad(a,1);ring=(~a)&(pad[:-2,1:-1]|pad[2:,1:-1]|pad[1:-1,:-2]|pad[1:-1,2:])
        out[ring]=(*OUTC,255)
        return out
def poses():
    R={}
    # idle: breathing, the blade arm drifts, the cannon sways, exhaust puffs
    R['idle']=[dict(bob=b,i=i,sw=.16*math.sin(i*math.pi/2),lean=[0,0,1,1][i]*.5) for i,b in enumerate([0,0,1,1])]
    R['walk']=[]
    for i in range(8):
        ph=i/8*2*math.pi;sw=math.sin(ph)
        R['walk'].append(dict(bob=-round(1.8*abs(math.sin(ph))),nf=(-8+11*math.cos(ph),max(0,5*math.sin(ph))),ff=(8-11*math.cos(ph),max(0,-5*math.sin(ph))),i=i,sw=sw,lean=-1+.8*math.cos(2*ph)))
    R['melee']=[dict(blade=-1.0,lean=2,i=0),dict(blade=-2.35,lean=3,bob=-1,i=1),dict(blade=math.pi+.08,lean=-5,nf=(-14,0),ff=(9,1),i=2),dict(blade=2.45,lean=-3,nf=(-12,0),i=3)]
    R['ranged']=[dict(aim=1,spin=s,flash=f,lean=1+(1 if f else 0),jit=(.035 if f else -.02),i=s) for s,f in [(0,0),(1,1),(2,0),(3,1)]]
    R['missile']=[dict(pod=p,sink=k,i=j,lean=-k*.5) for j,(p,k) in enumerate([(0,0),(1,1),(2,2),(1,1)])]
    R['throw']=[dict(blade=-1.4,lean=2,i=0),dict(blade=-2.6,lean=3,bob=-1,i=1),dict(blade=math.pi+.4,lean=-4,nf=(-12,0),i=2)]
    R['hurt']=[dict(tilt=.1,lean=3,bob=1,sw=-.4),dict(tilt=.04,lean=1,sw=-.2)]
    R['death']=[dict(tilt=.18,sw=-.5),dict(tilt=.5,sink=2,sw=-.8),dict(tilt=.9,sink=3,dim=1,blade=math.pi+.25-.9),dict(tilt=1.28,sink=4,dim=1,blade=math.pi+.2-1.28),dict(tilt=1.5,sink=5,dim=1,blade=math.pi+.15-1.5)]   # the blade arm flops down flat as he falls
    return R
ORDER=('walk','idle','melee','ranged','missile','throw','hurt','death')
def build(name,fn):
    R=poses();rows={k:[fn(p).render() for p in v] for k,v in R.items()}
    S=Image.new('RGBA',(FW*8,FH*len(ORDER)));meta={}
    for r,n in enumerate(ORDER):
        for i,f in enumerate(rows[n]):S.alpha_composite(Image.fromarray(f,'RGBA'),(i*FW,r*FH))
        meta[n]=dict(n=len(rows[n]),y=r*FH)
    S.save(f'/home/claude/robot3/{name}.png')
    seq=[]
    for n,rep,dur in [('idle',2,180),('walk',2,95),('melee',1,110),('ranged',3,50),('missile',1,160),('throw',1,130),('hurt',1,140),('death',1,200)]:
        for _ in range(rep):
            for f in rows[n]:
                im=Image.new('RGBA',(FW,FH),(30,26,38,255));im.alpha_composite(Image.fromarray(f,'RGBA'));seq.append((im.resize((FW*4,FH*4),Image.NEAREST).convert('P',palette=Image.ADAPTIVE,colors=128),dur))
    seq[0][0].save(f'/home/claude/robot3/{name}.gif',save_all=True,append_images=[a for a,_ in seq[1:]],duration=[d for _,d in seq],loop=0,disposal=2)
    return S,meta
def dk(p,f=.78):return [tuple(int(v*f) for v in c) for c in p]
