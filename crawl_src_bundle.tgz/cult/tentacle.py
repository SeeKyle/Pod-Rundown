import eng
eng.FW,eng.FH,eng.OX,eng.OY=112,88,78,84
from eng import *
import random
SKN=ramp((10,6,14),(24,14,32),(42,26,56),(66,44,86),(104,78,132))
BELLY=ramp((18,12,22),(34,22,40),(54,36,62),(80,56,88),(112,86,120))
CLAW=ramp((60,54,46),(120,110,92),(176,166,140),(214,206,184),(240,236,220))
SUCK=(120,70,120);SUCKC=(20,8,22)
EARTH=ramp((16,12,10),(32,24,20),(52,40,32),(76,60,46),(100,82,64))
class TentFrame:
    def __init__(s,pts,claw):s.pts=pts;s.claw=claw
    def render(s):
        W,H=eng.FW,eng.FH;out=np.zeros((H,W,4),np.uint8);OX,OY=eng.OX,eng.OY
        P=np.array([(OX+x,OY+y,r,a) for x,y,r,a in s.pts]);yy,xx=np.mgrid[0:H,0:W]
        best=np.full((H,W),9e9);u=np.zeros((H,W));idx=np.zeros((H,W),int)
        for i,(px,py,r,a) in enumerate(P):
            dx,dy=xx-px,yy-py;d=np.hypot(dx,dy)/r
            nx,ny=-math.sin(a),math.cos(a);side=(dx*nx+dy*ny)/r
            m=d<best;best[m]=d[m];u[m]=side[m];idx[m]=i
        inside=best<1
        # earth mound
        em=((xx-OX)/12)**2+((yy-(OY-1))/3.5)**2<1
        out[em]=(*EARTH[2],255);out[em&(yy<OY-1)]=(*EARTH[3],255);hole=((xx-OX)/8)**2+((yy-(OY-2))/2.2)**2<1;out[hole]=(8,6,8,255)
        # tube shading: lit from the upper-left side, a soft highlight band, dark under-side
        k=np.where(u<-.78,2,np.where(u<-.42,4,np.where(u<-.1,3,np.where(u<.45,2,np.where(u<.8,1,0)))))
        k=np.where(u<-.92,2,k)
        pal=np.array(SKN);col=pal[k]
        # belly with suckers along the inner side
        bel=(u>.35)&(u<.85)
        col[bel]=np.array(BELLY)[np.clip(k[bel]+1,0,4)]
        n=len(P)
        for i in range(2,n-3,3):
            px,py,r,a=P[i]
            if r<1.8:continue
            nx,ny=-math.sin(a),math.cos(a);cx,cy=px+nx*r*.6,py+ny*r*.6;rr=max(1.0,r*.28)
            d=np.hypot(xx-cx,yy-cy);ring=(d<rr+.6)&inside
            col[ring]=SUCK;col[(d<rr-.4)&inside]=SUCKC
        # ridge nubs on the back
        for i in range(3,n-4,4):
            px,py,r,a=P[i];nx,ny=-math.sin(a),math.cos(a);cx,cy=int(round(px-nx*r*.8)),int(round(py-ny*r*.8))
            if 0<=cy<H and 0<=cx<W:col[cy,cx]=SKN[4]
        out[inside,:3]=col[inside];out[inside,3]=255
        # claw
        a_=out[...,3]>0;pad=np.pad(a_,1);ringm=(~a_)&(pad[:-2,1:-1]|pad[2:,1:-1]|pad[1:-1,:-2]|pad[1:-1,2:]);out[ringm]=(10,8,14,255)
        return out
def tent(L=67,phase=0,A=.42,base=-math.pi/2,curl=1.1,droop=0,lean=0):
    n=max(4,int(L/1.2));x,y=0.0,-2.0;pts=[]
    for i in range(n+1):
        s_=i/n;ang=base+lean*s_+A*math.sin(2.4*math.pi*s_+phase)*(.3+s_)+curl*s_**3+droop*s_**2
        r=6.5*(1-s_)**.7+.9;pts.append((x,y,r,ang));x+=math.cos(ang)*L/n;y+=math.sin(ang)*L/n
    x,y,r,a=pts[-2];t1=pol((x,y),a,6);t2=pol(t1,a+1.25,4.5)
    claw=[pol((x,y),a+1.57,2.2),t1,t2,pol(t1,a-.2,-1.5),pol((x,y),a-1.57,2.2)]
    return TentFrame(pts,claw)
rows={}
rows['emerge']=[tent(L=l,phase=.5*i,A=.2) for i,l in enumerate([9,21,37,53,67])]
rows['idle']=[tent(phase=i/8*2*math.pi) for i in range(8)]
rows['attack']=[tent(lean=.5,curl=1.6,A=.2,phase=0),tent(lean=.8,curl=2.0,A=.15,phase=.4),tent(base=-math.pi/2-.9,lean=-.8,curl=.2,A=.1,phase=.8),
                tent(base=-math.pi+.35,lean=-.15,curl=-.1,A=.08,phase=1.2,L=71),tent(base=-math.pi+.25,lean=-.05,curl=-.2,A=.1,phase=1.6,L=71),tent(base=-math.pi/2-.6,lean=0,curl=.6,A=.25,phase=2)]
rows['hit']=[tent(lean=.6,A=.5,phase=1),tent(lean=.3,A=.4,phase=1.5)]
rows['death']=[tent(droop=d,L=l,A=.1,phase=i) for i,(d,l) in enumerate([(.6,67),(1.3,64),(2.0,57),(2.4,46),(2.6,30),(2.8,14)])]
ORDER=('emerge','idle','attack','hit','death')
S=Image.new('RGBA',(eng.FW*8,eng.FH*len(ORDER)));meta={}
for r,n in enumerate(ORDER):
    for i,F_ in enumerate(rows[n]):
        o=F_.render()
        if n=='death' and i>=3:o[...,3]=(o[...,3]*(1-(i-2)*.22)).astype(np.uint8)
        S.alpha_composite(Image.fromarray(o,'RGBA'),(i*eng.FW,r*eng.FH))
    meta[n]=dict(n=len(rows[n]),y=r*eng.FH)
S.save('/home/claude/cult/tentacle.png');import json;json.dump(meta,open('tent_meta.json','w'))
bg=Image.new('RGBA',S.size,(30,26,38,255));bg.alpha_composite(S);bg.resize((S.width*2,S.height*2),Image.NEAREST).save('/tmp/tent.png')
seq=[]
for n,rep,dur in [('emerge',1,90),('idle',3,110),('attack',1,90),('idle',1,110),('hit',1,120),('death',1,130)]:
    for _ in range(rep):
        for i in range(meta[n]['n']):
            im=Image.new('RGBA',(eng.FW,eng.FH),(30,26,38,255));im.alpha_composite(S.crop((i*eng.FW,meta[n]['y'],(i+1)*eng.FW,meta[n]['y']+eng.FH)));seq.append((im.resize((eng.FW*4,eng.FH*4),Image.NEAREST).convert('P',palette=Image.ADAPTIVE,colors=96),dur))
seq[0][0].save('/home/claude/cult/tentacle.gif',save_all=True,append_images=[a for a,_ in seq[1:]],duration=[d for _,d in seq],loop=0,disposal=2)
