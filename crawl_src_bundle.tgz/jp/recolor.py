# 0.12.66 (Kyle): JP, built from a copy of Flannel_Man's sheets. Recolor: green flannel + dark tee -> big orange hoodie, grey pants -> dark blue
# jeans, tan skin -> white skin, black hair/beard -> brown (kept short), crowbar -> steel sword, rifle -> Kar98-style wood stock.
# A homemade wooden shield (planks, rope-tied, nail heads) is drawn on his off arm. Edges are softened at the end.
import numpy as np, colorsys, sys
from PIL import Image, ImageFilter
SRC='/home/claude/pod2/assets/heroes/flannel/';OUT='/home/claude/pod2/assets/heroes/jp/';FW=230
import os;os.makedirs(OUT,exist_ok=True)
def hsv(c):return colorsys.rgb_to_hsv(*(np.array(c[:3])/255.))
def rgb(h,s,v):return tuple(int(255*x) for x in colorsys.hsv_to_rgb(h%1,min(1,max(0,s)),min(1,max(0,v))))
def recolor(fr,anim):
    a=fr.copy();al=a[...,3]>40
    if not al.any():return a
    ys,xs=np.nonzero(al);top,bot=ys.min(),ys.max();H=bot-top+1
    g=np.zeros(al.shape,bool)
    for y,x in zip(ys,xs):
        h,s,v=hsv(a[y,x]);
        if .22<h<.42 and s>.3 and v>.08 and int(a[y,x,1])>int(a[y,x,0])+8 and int(a[y,x,1])>int(a[y,x,2])+4:g[y,x]=1
    if g.any():gy,gx=np.nonzero(g);tx0,tx1=gx.min()-3,gx.max()+3;ty0,ty1=gy.min()-2,gy.max()+2
    else:tx0,tx1,ty0,ty1=xs.min(),xs.max(),top+H*.2,top+H*.55
    out=a.copy();crow=[]
    # flatten the plaid: hoodie shade comes from a blurred brightness map, quantized to 3 tones
    from scipy.ndimage import gaussian_filter
    lum=gaussian_filter(a[...,:3].astype(float).mean(2)*(g|((a[...,3]>40)&(a[...,:3].max(2)<70))),2.2)/np.maximum(.05,gaussian_filter((g|((a[...,3]>40)&(a[...,:3].max(2)<70))).astype(float),2.2))
    F=faceOf(a);FY,FX=F if F is not None else (-99,-99)
    for y,x in zip(ys,xs):
        r,gg,b,A=a[y,x];h,s,v=hsv(a[y,x]);rel=(y-top)/H;inT=tx0<=x<=tx1 and ty0<=y<=ty1
        inHead=FY-14<=y<=FY+16 and FX-12<=x<=FX+12
        if False:pass
        elif inHead and v<.32 and not (.02<h<.12 and .2<s<.75 and v>.38):out[y,x,:3]=rgb(.075,.5,min(.85,.36+v*1.3))   # 0.12.79: hair AND beard the same light brown
        elif inT and rel<.58 and tx0+1<=x<=tx0+(tx1-tx0)*.75 and (s<.3 or .5<h<.78) and not (.02<h<.12 and .2<s<.75 and v>.38) and not g[y,x] and v<.35:L=lum[y,x]/255.;tone=.62 if L<.13 else .78 if L<.22 else .92;out[y,x,:3]=rgb(.065,.86,tone)   # 0.12.79: zipped up, no open front
        elif g[y,x] or (inT and s<.35 and v<.25 and .18<rel<.52):L=lum[y,x]/255.;tone=.62 if L<.13 else .78 if L<.22 else .92;edge=v<.06 and (a[max(0,y-1):y+2,max(0,x-1):x+2,3]<40).any();out[y,x,:3]=(30,16,8) if edge else rgb(.065,.86,tone)   # flannel + tee -> one solid orange hoodie (3 tones)
        elif .02<h<.12 and .2<s<.75 and v>.38 and rel<.5:out[y,x,:3]=rgb(.06,.24,min(1,v*1.1+.16))   # skin -> white
        elif rel<.28 and v<.2 and not inT:out[y,x,:3]=rgb(.07,.55,v*1.2+.13)   # hair/beard -> brown
        elif rel>.5 and s<.35 and .18<v<.5:out[y,x,:3]=rgb(.6,.55,v*.85)   # grey pants -> dark blue jeans
        elif not inT and rel<.62 and v<.3 and s<.45:   # dark thin things outside the torso = weapons
            if anim in('melee','walk','run','idle','hurt','kneel','death','toss','throw'):out[y,x,:3]=rgb(.58,.08,min(1,v*2.4+.45))   # steel sword
            else:out[y,x,:3]=rgb(.07,.65,v*1.3+.2)   # Kar98 wood
    if len(crow)>=15:   # draw a real sword along the crowbar's line: grip + crossguard at the hand end, a long steel blade to the tip
        P=np.array(crow,float);c0=P.mean(0);u,sv,vt=np.linalg.svd(P-c0);d=vt[0];t=(P-c0)@d;e1=c0+d*t.min();e2=c0+d*t.max()
        hx=(tx0+tx1)/2;hand,tip=(e1,e2) if abs(e1[1]-hx)<abs(e2[1]-hx) else (e2,e1);L=np.linalg.norm(tip-hand);dirv=(tip-hand)/max(1,L);nrm=np.array([-dirv[1],dirv[0]])
        def put(p,c):
            y,x=int(round(p[0])),int(round(p[1]))
            if 0<=y<out.shape[0] and 0<=x<out.shape[1]:out[y,x]=c
        for k in np.linspace(0,L*1.1,int(L*3)):
            p=hand+dirv*k
            if k<6:put(p,(70,42,22,255));put(p+nrm,(40,24,12,255))   # grip
            else:
                for w in (-1.5,-.5,.5,1.5):put(p+nrm*w,(30,32,38,255) if abs(w)>1 else ((214,220,228,255) if w<0 else (160,168,178,255)))   # blade with a bright edge
        for w in np.linspace(-5,5,21):put(hand+dirv*6+nrm*w,(180,150,60,255));put(hand+dirv*7+nrm*w,(110,90,30,255))   # crossguard
    return out
def shield(fr,anim):
    a=fr;al=a[...,3]>40
    if not al.any() or anim in('ranged','walkfire','reload','death'):return a
    ys,xs=np.nonzero(al);top,bot=ys.min(),ys.max();H=bot-top+1
    # torso: columns where most of the body is, at chest height
    row=int(top+H*.42);cols=np.nonzero(al[row])[0]
    if len(cols)==0:return a
    row2=int(top+H*.5);c2=np.nonzero(al[row2])[0];cx=int(c2.min())+9 if len(c2) else int(np.median(cols));cy=row2;R=11   # on his off arm at the front of his body (he faces left)
    yy,xx=np.mgrid[0:a.shape[0],0:a.shape[1]];d=np.sqrt(((xx-cx)/1.0)**2+((yy-cy)/1.15)**2)
    disk=d<=R;rim=(d>R-2.2)&disk
    planks=((xx-cx+40)//6)%2==0
    col=np.zeros(a.shape,np.uint8);col[...,3]=255
    col[...,:3]=np.where(planks[...,None],np.array([139,94,52]),np.array([120,78,42]))
    seam=((xx-cx+40)%6==0)&disk;col[seam,:3]=(70,44,24)
    col[rim,:3]=(64,46,30)
    rope=(np.abs(yy-cy)<=1)&disk;col[rope,:3]=(196,170,110)   # rope band tying the planks
    for nx,ny in [(-6,-6),(6,-6),(-6,6),(6,6),(0,-9),(0,9)]:
        if 0<=cy+ny<a.shape[0] and 0<=cx+nx<a.shape[1]:col[cy+ny,cx+nx,:3]=(200,200,190)
    o=a.copy();o[disk]=col[disk]
    edge=disk&~np.pad(disk,1)[2:,1:-1]|disk&~np.pad(disk,1)[:-2,1:-1]|disk&~np.pad(disk,1)[1:-1,2:]|disk&~np.pad(disk,1)[1:-1,:-2]
    o[edge,:3]=(20,14,10)
    return o
_TPL=None
def faceOf(src):
    # 0.12.79: find his head by matching a head template cut from Flannel_Man's first idle frame (face centre at (80,132) there)
    global _TPL
    if _TPL is None:
        _TPL=[]
        for an,f,fy,fx in [('idle',0,77,133),('ranged',0,78,135),('melee',1,82,143),('melee',4,77,110)]:   # head templates (face centres picked by eye)
            I=np.array(Image.open(SRC+an+'.png').convert('RGBA'))[:,f*230:(f+1)*230].astype(float);y0,x0=fy-18,fx-14;_TPL.append((I[y0:y0+38,x0:x0+28,:3],I[y0:y0+38,x0:x0+28,3]>40))
    al=src[...,3]>40
    if not al.any():return None
    ys,xs=np.nonzero(al);A=src[...,:3].astype(float);best=None;bv=1e18
    for y in range(max(0,ys.min()-6),min(src.shape[0]-38,ys.min()+16)):
        for x in range(max(0,xs.min()-5),min(src.shape[1]-28,xs.max()-10)):
            W=A[y:y+38,x:x+28];Wa=al[y:y+38,x:x+28]
            for T,M in _TPL:
                v=(((W-T)**2).sum(-1)*M).sum()/M.sum()+60*(M&~Wa).sum()
                if v<bv:bv=v;best=(y,x)
    global _LASTF
    if best is None:return None
    if bv>21000 and '_LASTF' in globals() and _LASTF:return _LASTF   # a poor match (an arm across his face): keep the last frame's head
    _LASTF=(float(best[0]+18),float(best[1]+14));return _LASTF
def hood(o,src):
    # 0.12.79 (Kyle): hood UP. An orange hood wraps the top and back of his head; his face, fringe and beard stick out of the front opening.
    F=faceOf(src)
    if F is None:return o
    fy,fx=F;yy,xx=np.mgrid[0:o.shape[0],0:o.shape[1]]
    outer=(((xx-(fx+4))/12.5)**2+((yy-(fy-3))/13)**2<=1)|((yy>=fy+2)&(yy<=fy+16)&(xx>=fx+5)&(xx<=fx+14))
    face=(((xx-(fx-3))/7.5)**2+((yy-(fy+3))/11)**2<=1)
    H=outer&~face;o=o.copy()
    o[H]=(*rgb(.065,.86,.86),255);o[H&(xx>fx+6)]=(*rgb(.065,.86,.72),255)
    rim=H&(((xx-(fx-3))/9)**2+((yy-(fy+3))/12.5)**2<=1);o[rim]=(*rgb(.06,.9,.5),255)   # shadowed inner edge of the hood
    edge=H&~(np.pad(H,1)[2:,1:-1]&np.pad(H,1)[:-2,1:-1]&np.pad(H,1)[1:-1,2:]&np.pad(H,1)[1:-1,:-2])&~face;o[edge]=(30,16,8,255)
    return o
def backshield(o,src,draw=True):
    # 0.12.79 (Kyle): when he isn't using it, the homemade shield hangs on his BACK (replaces the old backpack)
    al=o[...,3]>40
    if not al.any():return o
    ys,xs=np.nonzero(al);top,bot=ys.min(),ys.max();H=bot-top+1
    tan=np.zeros(al.shape,bool)
    for y,x in zip(ys,xs):
        h,s_,v=hsv(src[y,x]);rel=(y-top)/H
        if .04<h<.16 and .08<s_<.85 and .3<v<.8 and .15<rel<.68:tan[y,x]=1
    F=faceOf(src)
    if F is not None:
        yy0,xx0=np.mgrid[0:o.shape[0],0:o.shape[1]];tan[(((xx0-F[1])/13)**2+((yy0-F[0])/15)**2)<=1]=0   # never touch his face
    sk=np.zeros(al.shape,bool)
    for y,x in zip(ys,xs):
        h,s_,v=hsv(src[y,x])
        if .02<h<.12 and .2<s_<.75 and v>.78 and (y-top)/H>.3:sk[y,x]=1   # hands (bright skin; the brown pack is darker)
    from scipy.ndimage import binary_dilation
    tan&=~binary_dilation(sk,iterations=1)
    o=o.copy()
    if tan.sum()>=10:o[tan]=(*rgb(.065,.86,.62),255)   # the pack is gone (hoodie shows there)
    if not draw or F is None:return o
    cy,cx=int(F[0]+27),int(F[1]+21)   # hung high on his back, behind the shoulders
    yy,xx=np.mgrid[0:o.shape[0],0:o.shape[1]];d=np.sqrt(((xx-cx)/7.5)**2+((yy-cy)/11.5)**2);disk=d<=1
    planks=((yy-cy+40)//5)%2==0
    o[disk&planks]=(139,94,52,255);o[disk&~planks]=(120,78,42,255);o[disk&((yy-cy+40)%5==0)]=(70,44,24,255)
    o[disk&(np.abs(xx-cx)<=1)]=(196,170,110,255)   # the rope band (now vertical, seen from the side)
    o[disk&(d>.8)]=(64,46,30,255)
    for ny in (-7,0,7):
        if 0<=cy+ny<o.shape[0]:o[cy+ny,cx-3]=(200,200,190,255)
    e=disk&~(np.pad(disk,1)[2:,1:-1]&np.pad(disk,1)[:-2,1:-1]&np.pad(disk,1)[1:-1,2:]&np.pad(disk,1)[1:-1,:-2]);o[e]=(20,14,10,255)
    sy=cy-12   # a strap over the shoulder
    for k in range(9):
        y,x=cy-11+k,cx-8+k//2
        if 0<=y<o.shape[0] and 0<=x<o.shape[1] and o[y,x,3]>40:o[y,x]=(60,40,22,255)
    return o
def idlesword(o,src):
    # 0.12.79: his own idle (not Flannel_Man's): sword held point-down at his side, shield on his back
    al=src[...,3]>40
    if not al.any():return o
    ys,xs=np.nonzero(al);top,bot=ys.min(),ys.max();H=bot-top+1
    hd=[(y,x) for y,x in zip(ys,xs) if .38<(y-top)/H<.65 and .02<hsv(src[y,x])[0]<.12 and .2<hsv(src[y,x])[1]<.75 and hsv(src[y,x])[2]>.38]
    if not hd:return o
    hy=np.median([p[0] for p in hd]);hx=min(p[1] for p in hd)+2
    o=o.copy();sword(o,np.array([hy-3,hx],float),np.array([hy+38,hx-15],float));return o
SWORD={0:(lambda x,y:(x<99)&(y>128)&(y<190),(99,146),(48,186)),
       1:(lambda x,y:((y<=67)&(x<150))|((y>=68)&(y<=78)&(x<126)),(158,60),(100,54)),
       2:(lambda x,y:((x<133)&(y<100)&(y>40))|((y<57)&(x<150)),(152,60),(112,100))}
SWORD={k:(e,(h[1],h[0]),(t[1],t[0])) for k,(e,h,t) in SWORD.items()}
def sword(out,hand,tip):
    L=np.linalg.norm(tip-hand);d=(tip-hand)/max(1,L);nrm=np.array([-d[1],d[0]])
    def put(p,c):
        y,x=int(round(p[0])),int(round(p[1]))
        if 0<=y<out.shape[0] and 0<=x<out.shape[1]:out[y,x]=c
    for k in np.linspace(0,L,int(L*3)):
        p=hand+d*k
        if k<7:
            for w in (-1,0,1):put(p+nrm*w,(30,18,10,255) if w else (92,58,30,255))   # leather-wrapped grip
        else:
            taper=1 if k<L-6 else max(0,(L-k)/6)
            for w in (-2,-1,0,1,2):
                if abs(w)>1+taper*1:continue
                put(p+nrm*w,(24,26,32,255) if abs(w)==2 or (abs(w)==1 and taper<.5) else ((226,232,238,255) if w<=0 else (150,160,172,255)))   # steel blade, bright edge, dark outline
    for w in np.linspace(-6,6,25):
        for t in (7,8):put(hand+d*t+nrm*w,(196,160,64,255) if t==7 else (30,22,10,255))   # crossguard
def soften(img):
    # smooth the blocky outer edge: a slightly blurred alpha so edge pixels fade instead of stair-stepping
    r,g,b,al=img.split();al2=al.filter(ImageFilter.GaussianBlur(.6));a=np.minimum(np.array(al),np.array(al2)*1.15).astype('uint8')
    return Image.merge('RGBA',(r,g,b,Image.fromarray(a)))
for f in os.listdir(SRC):
    if not f.endswith('.png') or f.startswith(('bomb','bullet','trip')):continue
    an=f[:-4];im=np.array(Image.open(SRC+f).convert('RGBA'));n=im.shape[1]//FW;fr_out=[]
    for i in range(n):
        fr=im[:,i*FW:(i+1)*FW].copy()
        if an=='melee' and i in SWORD:er,hand,tip=SWORD[i];yy,xx=np.mgrid[0:fr.shape[0],0:fr.shape[1]];fr[er(xx,yy)]=0
        o=recolor(fr,an)
        if an!='death':o=hood(o,fr)
        if an in('melee',):o=backshield(o,fr,False);o=shield(o,an)
        elif an!='death':o=backshield(o,fr)
        if an=='idle':o=idlesword(o,fr)
        if an=='melee' and i in SWORD:sword(o,np.array(hand,float),np.array(tip,float))
        fr_out.append(o)
    sheet=Image.fromarray(np.concatenate(fr_out,1));sheet=soften(sheet);sheet.save(OUT+f)
    print(an,n)
# dodge roll (for later skills): his crouch tucked into a ball and spun a full turn over 6 frames, travelling forward (left)
K=Image.open(OUT+'kneel.png');fr=K.crop((2*FW,0,3*FW,208));bb=fr.getbbox();body=fr.crop(bb)
ball=body.resize((int(body.width*.85),int(body.height*.62)),Image.LANCZOS)
R=Image.new('RGBA',(FW*6,208))
for i in range(6):
    rot=ball.rotate(60*i,resample=Image.BICUBIC,expand=True);cx=140-i*6-rot.width//2;cy=200-rot.height
    R.alpha_composite(rot,(i*FW+max(0,cx),max(0,cy)))
R.save(OUT+'roll.png')
