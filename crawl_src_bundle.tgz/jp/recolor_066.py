# 0.12.66 (Kyle): JP, built from a copy of Flannel_Man's sheets. Recolor: green flannel + dark tee -> big orange hoodie, grey pants -> dark blue
# jeans, tan skin -> white skin, black hair/beard -> brown (kept short), crowbar -> steel sword, rifle -> Kar98-style wood stock.
# A homemade wooden shield (planks, rope-tied, nail heads) is drawn on his off arm. Edges are softened at the end.
import numpy as np, colorsys, sys
from PIL import Image, ImageFilter
SRC='/home/claude/pod2/assets/heroes/flannel/';OUT='/home/claude/pod2/assets/heroes/jp/';FW=230
import os;os.makedirs(OUT,exist_ok=True)
def hsv(c):return colorsys.rgb_to_hsv(*(np.array(c[:3])/255.))
def rgb(h,s,v):return tuple(int(255*x) for x in colorsys.hsv_to_rgb(h%1,min(1,max(0,s)),min(1,max(0,v))))
def recolor(fr,anim):
    a=fr.copy();al=a[...,3]>40
    if not al.any():return a
    ys,xs=np.nonzero(al);top,bot=ys.min(),ys.max();H=bot-top+1
    g=np.zeros(al.shape,bool)
    for y,x in zip(ys,xs):
        h,s,v=hsv(a[y,x]);
        if .22<h<.42 and s>.3 and v>.08 and int(a[y,x,1])>int(a[y,x,0])+8 and int(a[y,x,1])>int(a[y,x,2])+4:g[y,x]=1
    if g.any():gy,gx=np.nonzero(g);tx0,tx1=gx.min()-3,gx.max()+3;ty0,ty1=gy.min()-2,gy.max()+2
    else:tx0,tx1,ty0,ty1=xs.min(),xs.max(),top+H*.2,top+H*.55
    out=a.copy();crow=[]
    # flatten the plaid: hoodie shade comes from a blurred brightness map, quantized to 3 tones
    from scipy.ndimage import gaussian_filter
    lum=gaussian_filter(a[...,:3].astype(float).mean(2)*(g|((a[...,3]>40)&(a[...,:3].max(2)<70))),2.2)/np.maximum(.05,gaussian_filter((g|((a[...,3]>40)&(a[...,:3].max(2)<70))).astype(float),2.2))
    for y,x in zip(ys,xs):
        r,gg,b,A=a[y,x];h,s,v=hsv(a[y,x]);rel=(y-top)/H;inT=tx0<=x<=tx1 and ty0<=y<=ty1
        if False:pass
        elif g[y,x] or (inT and s<.35 and v<.25 and .18<rel<.52):L=lum[y,x]/255.;tone=.62 if L<.13 else .78 if L<.22 else .92;edge=v<.06;out[y,x,:3]=(30,16,8) if edge else rgb(.065,.86,tone)   # flannel + tee -> one solid orange hoodie (3 tones)
        elif .02<h<.12 and .2<s<.75 and v>.38 and rel<.5:out[y,x,:3]=rgb(.06,.24,min(1,v*1.1+.16))   # skin -> white
        elif rel<.28 and v<.2 and not inT:out[y,x,:3]=rgb(.07,.55,v*1.2+.13)   # hair/beard -> brown
        elif rel>.5 and s<.35 and .18<v<.5:out[y,x,:3]=rgb(.6,.55,v*.85)   # grey pants -> dark blue jeans
        elif not inT and rel<.62 and v<.3 and s<.45:   # dark thin things outside the torso = weapons
            if anim in('melee','walk','run','idle','hurt','kneel','death','toss','throw'):out[y,x,:3]=rgb(.58,.08,min(1,v*2.4+.45))   # steel sword
            else:out[y,x,:3]=rgb(.07,.65,v*1.3+.2)   # Kar98 wood
    if len(crow)>=15:   # draw a real sword along the crowbar's line: grip + crossguard at the hand end, a long steel blade to the tip
        P=np.array(crow,float);c0=P.mean(0);u,sv,vt=np.linalg.svd(P-c0);d=vt[0];t=(P-c0)@d;e1=c0+d*t.min();e2=c0+d*t.max()
        hx=(tx0+tx1)/2;hand,tip=(e1,e2) if abs(e1[1]-hx)<abs(e2[1]-hx) else (e2,e1);L=np.linalg.norm(tip-hand);dirv=(tip-hand)/max(1,L);nrm=np.array([-dirv[1],dirv[0]])
        def put(p,c):
            y,x=int(round(p[0])),int(round(p[1]))
            if 0<=y<out.shape[0] and 0<=x<out.shape[1]:out[y,x]=c
        for k in np.linspace(0,L*1.1,int(L*3)):
            p=hand+dirv*k
            if k<6:put(p,(70,42,22,255));put(p+nrm,(40,24,12,255))   # grip
            else:
                for w in (-1.5,-.5,.5,1.5):put(p+nrm*w,(30,32,38,255) if abs(w)>1 else ((214,220,228,255) if w<0 else (160,168,178,255)))   # blade with a bright edge
        for w in np.linspace(-5,5,21):put(hand+dirv*6+nrm*w,(180,150,60,255));put(hand+dirv*7+nrm*w,(110,90,30,255))   # crossguard
    return out
def shield(fr,anim):
    a=fr;al=a[...,3]>40
    if not al.any() or anim in('ranged','walkfire','reload','death'):return a
    ys,xs=np.nonzero(al);top,bot=ys.min(),ys.max();H=bot-top+1
    # torso: columns where most of the body is, at chest height
    row=int(top+H*.42);cols=np.nonzero(al[row])[0]
    if len(cols)==0:return a
    row2=int(top+H*.5);c2=np.nonzero(al[row2])[0];cx=int(c2.min())+9 if len(c2) else int(np.median(cols));cy=row2;R=11   # on his off arm at the front of his body (he faces left)
    yy,xx=np.mgrid[0:a.shape[0],0:a.shape[1]];d=np.sqrt(((xx-cx)/1.0)**2+((yy-cy)/1.15)**2)
    disk=d<=R;rim=(d>R-2.2)&disk
    planks=((xx-cx+40)//6)%2==0
    col=np.zeros(a.shape,np.uint8);col[...,3]=255
    col[...,:3]=np.where(planks[...,None],np.array([139,94,52]),np.array([120,78,42]))
    seam=((xx-cx+40)%6==0)&disk;col[seam,:3]=(70,44,24)
    col[rim,:3]=(64,46,30)
    rope=(np.abs(yy-cy)<=1)&disk;col[rope,:3]=(196,170,110)   # rope band tying the planks
    for nx,ny in [(-6,-6),(6,-6),(-6,6),(6,6),(0,-9),(0,9)]:
        if 0<=cy+ny<a.shape[0] and 0<=cx+nx<a.shape[1]:col[cy+ny,cx+nx,:3]=(200,200,190)
    o=a.copy();o[disk]=col[disk]
    edge=disk&~np.pad(disk,1)[2:,1:-1]|disk&~np.pad(disk,1)[:-2,1:-1]|disk&~np.pad(disk,1)[1:-1,2:]|disk&~np.pad(disk,1)[1:-1,:-2]
    o[edge,:3]=(20,14,10)
    return o
SWORD={0:(lambda x,y:(x<99)&(y>128)&(y<190),(99,146),(48,186)),
       1:(lambda x,y:((y<=67)&(x<150))|((y>=68)&(y<=78)&(x<126)),(158,60),(100,54)),
       2:(lambda x,y:((x<133)&(y<100)&(y>40))|((y<57)&(x<150)),(152,60),(112,100))}
SWORD={k:(e,(h[1],h[0]),(t[1],t[0])) for k,(e,h,t) in SWORD.items()}
def sword(out,hand,tip):
    L=np.linalg.norm(tip-hand);d=(tip-hand)/max(1,L);nrm=np.array([-d[1],d[0]])
    def put(p,c):
        y,x=int(round(p[0])),int(round(p[1]))
        if 0<=y<out.shape[0] and 0<=x<out.shape[1]:out[y,x]=c
    for k in np.linspace(0,L,int(L*3)):
        p=hand+d*k
        if k<7:
            for w in (-1,0,1):put(p+nrm*w,(30,18,10,255) if w else (92,58,30,255))   # leather-wrapped grip
        else:
            taper=1 if k<L-6 else max(0,(L-k)/6)
            for w in (-2,-1,0,1,2):
                if abs(w)>1+taper*1:continue
                put(p+nrm*w,(24,26,32,255) if abs(w)==2 or (abs(w)==1 and taper<.5) else ((226,232,238,255) if w<=0 else (150,160,172,255)))   # steel blade, bright edge, dark outline
    for w in np.linspace(-6,6,25):
        for t in (7,8):put(hand+d*t+nrm*w,(196,160,64,255) if t==7 else (30,22,10,255))   # crossguard
def soften(img):
    # smooth the blocky outer edge: a slightly blurred alpha so edge pixels fade instead of stair-stepping
    r,g,b,al=img.split();al2=al.filter(ImageFilter.GaussianBlur(.6));a=np.minimum(np.array(al),np.array(al2)*1.15).astype('uint8')
    return Image.merge('RGBA',(r,g,b,Image.fromarray(a)))
for f in os.listdir(SRC):
    if not f.endswith('.png') or f.startswith(('bomb','bullet','trip')):continue
    an=f[:-4];im=np.array(Image.open(SRC+f).convert('RGBA'));n=im.shape[1]//FW;fr_out=[]
    for i in range(n):
        fr=im[:,i*FW:(i+1)*FW].copy()
        if an=='melee' and i in SWORD:er,hand,tip=SWORD[i];yy,xx=np.mgrid[0:fr.shape[0],0:fr.shape[1]];fr[er(xx,yy)]=0
        o=recolor(fr,an);o=shield(o,an)
        if an=='melee' and i in SWORD:sword(o,np.array(hand,float),np.array(tip,float))
        fr_out.append(o)
    sheet=Image.fromarray(np.concatenate(fr_out,1));sheet=soften(sheet);sheet.save(OUT+f)
    print(an,n)
# dodge roll (for later skills): his crouch tucked into a ball and spun a full turn over 6 frames, travelling forward (left)
K=Image.open(OUT+'kneel.png');fr=K.crop((2*FW,0,3*FW,208));bb=fr.getbbox();body=fr.crop(bb)
ball=body.resize((int(body.width*.85),int(body.height*.62)),Image.LANCZOS)
R=Image.new('RGBA',(FW*6,208))
for i in range(6):
    rot=ball.rotate(60*i,resample=Image.BICUBIC,expand=True);cx=140-i*6-rot.width//2;cy=200-rot.height
    R.alpha_composite(rot,(i*FW+max(0,cx),max(0,cy)))
R.save(OUT+'roll.png')
