# "Night Shift" - original dark synthwave loop with a synth sax lead, for Crypt Crawl. 88 bpm, D minor.
import numpy as np
from scipy.signal import butter, sosfilt, fftconvolve, iirpeak, lfilter
SR=44100; BPM=88; B=60/BPM; BAR=4*B; NB=32; L=int(NB*BAR*SR); TAIL=int(4*SR)
rng=np.random.default_rng(7)
def buf():return np.zeros(L+TAIL)
def mtof(m):return 440*2**((m-69)/12)
def lp(x,f,o=2):return sosfilt(butter(o,f,'low',fs=SR,output='sos'),x)
def hp(x,f,o=2):return sosfilt(butter(o,f,'high',fs=SR,output='sos'),x)
def bp(x,a,b,o=2):return sosfilt(butter(o,[a,b],'band',fs=SR,output='sos'),x)
def saw_phase(phi,f0,maxf=9000,tilt=1.0):
    K=max(1,int(maxf/max(f0,20)));out=np.zeros_like(phi)
    for k in range(1,K+1):out+=np.sin(k*phi)/k**tilt
    return out
def add(dst,x,t0):
    i=int(t0*SR);n=min(len(x),len(dst)-i)
    if n>0:dst[i:i+n]+=x[:n]
def env(n,a,d,s,r,hold):
    t=np.arange(n)/SR;e=np.ones(n)*s
    e[t<a]=t[t<a]/a
    m=(t>=a)&(t<a+d);e[m]=1-(1-s)*(t[m]-a)/d
    rel=t>hold;e[rel]=s*np.exp(-(t[rel]-hold)/max(r,1e-3))
    return e
def reverb(x,secs=2.4,damp=4500,wet=.3,pre=.02):
    n=int(secs*SR);t=np.arange(n)/SR;ir=rng.standard_normal(n)*np.exp(-t*6.9/secs);ir=lp(ir,damp);ir[:int(pre*SR)]=0;ir/=np.sqrt((ir**2).sum())
    return x+wet*fftconvolve(x,ir)[:len(x)]
CH=[[50,53,57,62],[46,50,53,58],[43,46,50,55],[45,49,52,57]]   # Dm, Bb, Gm, A (pads)
ROOT=[38,34,43,45]
# ---------------- drums ----------------
kick=buf();snare=buf();hat=buf();tom=buf()
def mk_kick():
    n=int(.45*SR);t=np.arange(n)/SR;f=45+85*np.exp(-t*28);ph=2*np.pi*np.cumsum(f)/SR
    x=np.sin(ph)*np.exp(-t*7.5);x[:int(.004*SR)]+=rng.standard_normal(int(.004*SR))*.4;return np.tanh(2.2*x)
def mk_snare():
    n=int(.5*SR);t=np.arange(n)/SR;x=bp(rng.standard_normal(n),900,7000)*np.exp(-t*16)*.9+np.sin(2*np.pi*185*t)*np.exp(-t*30)*.6
    g=bp(rng.standard_normal(int(.24*SR)),700,6000)*np.linspace(1,.8,int(.24*SR))   # gated reverb: dense, then cut hard
    g[-int(.012*SR):]*=np.linspace(1,0,int(.012*SR));wet=fftconvolve(x,g)[:n+len(g)];wet/=np.abs(wet).max()
    y=np.zeros(len(wet));y[:n]+=x;y+=wet*.55;return np.tanh(1.6*y)
def mk_hat(o=False):
    n=int((.16 if o else .045)*SR);t=np.arange(n)/SR;return hp(rng.standard_normal(n),7000,4)*np.exp(-t*(18 if o else 70))
def mk_tom(m):
    n=int(.5*SR);t=np.arange(n)/SR;f=mtof(m)*(1+.5*np.exp(-t*20));return np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-t*6)
K,S,H,HO=mk_kick(),mk_snare(),mk_hat(),mk_hat(True)
for bar in range(NB):
    t0=bar*BAR;sec=bar//8;sparse=bar>=28
    for b in (0,2):add(kick,K,t0+b*B)
    if not sparse and bar%2==1:add(kick,K*.7,t0+3.5*B)
    for b in (1,3):add(snare,S,t0+b*B)
    for e in range(8):
        sw=.04*B if e%2 else 0
        if sparse and e%2==0:continue
        add(hat,(HO if e==7 and bar%4==3 else H)*(.55 if e%2 else .35),t0+e*B/2+sw)
    if bar%8==7:   # tom fill into the next section
        for i,m in enumerate([50,47,45,43]):add(tom,mk_tom(m)*.6,t0+3*B+i*B/4)
# ---------------- bass: pulsing 8ths, gritty ----------------
bass=buf()
for bar in range(NB):
    r=ROOT[bar%4]
    for e in range(8):
        m=r+(12 if (e==3 or e==7) and bar%2 else 0);f=mtof(m);dur=B/2*.92;n=int(dur*SR);t=np.arange(n)/SR
        ph=2*np.pi*f*t;x=saw_phase(ph,f,3000)
        bright=lp(x,1600)*np.exp(-t*14);dark=lp(x,380)
        e1=np.minimum(1,t/.004)*np.exp(-t*2.5);e1[-int(.01*SR):]*=np.linspace(1,0,int(.01*SR))
        y=(dark+.8*bright)*e1+np.sin(ph/2)*.25*e1    # sub
        add(bass,np.tanh(1.8*y)*(.9 if e%2 else 1.0),bar*BAR+e*B/2)
# ---------------- pads: detuned saws, slow filter ----------------
pad=buf()
for bar in range(NB):
    n=int((BAR+.6)*SR);t=np.arange(n)/SR;x=np.zeros(n)
    for m in CH[bar%4]:
        for dt in (-.09,0,.09):
            f=mtof(m+dt);x+=saw_phase(2*np.pi*f*t+rng.uniform(0,6),f,5000)
    x=lp(x,1300+500*(bar>=8),2)
    e=np.minimum(1,t/.35)*np.where(t>BAR,np.exp(-(t-BAR)/.18),1)
    add(pad,x*e*.06,bar*BAR)
# ---------------- arp (second half): soft plucks, 16ths ----------------
arp=buf()
for bar in range(16,28):
    ch=CH[bar%4];notes=[ch[0]+12,ch[1]+12,ch[2]+12,ch[3]+12,ch[2]+12,ch[1]+12]
    for s in range(16):
        m=notes[s%len(notes)];f=mtof(m);n=int(.25*SR);t=np.arange(n)/SR
        x=lp(saw_phase(2*np.pi*f*t,f,6000)+.5*np.sign(np.sin(2*np.pi*f*t)),2200)*np.exp(-t*16)
        add(arp,x*.07,bar*BAR+s*B/4)
# ---------------- sax: additive reed tone + formants + breath, scoops, vibrato, growl ----------------
sax=buf()
MEL=[ # (bar, beat, midi, beats)  phrases A B A' D over bars 8-23
 (8,0,69,1.5),(8,1.5,67,.5),(8,2,65,1),(8,3,64,.5),(8,3.5,62,.5),
 (9,0,65,2),(9,2,62,1),(9,3,65,.5),(9,3.5,67,.5),
 (10,0,70,1.5),(10,1.5,69,.5),(10,2,67,1),(10,3,65,1),
 (11,0,64,2),(11,3,69,.5),(11,3.5,73,.5),
 (12,0,74,1.5),(12,1.5,72,.5),(12,2,69,1),(12,3,65,1),
 (13,0,74,1),(13,1,77,1.5),(13,2.5,74,.5),(13,3,72,1),
 (14,0,70,1),(14,1,74,1),(14,2,79,2),
 (15,0,77,.5),(15,.5,76,.5),(15,1,73,1),(15,2,69,2),
 (16,0,69,1.5),(16,1.5,67,.5),(16,2,65,1),(16,3,64,.5),(16,3.5,62,.5),
 (17,0,65,2),(17,2,70,1),(17,3,69,1),
 (18,0,67,1.5),(18,1.5,65,.5),(18,2,62,1),(18,3,65,1),
 (19,0,64,3),(19,3.5,69,.5),
 (20,0,74,2),(20,2,72,1),(20,3,69,1),
 (21,0,70,1.5),(21,1.5,69,.5),(21,2,65,2),
 (22,0,67,1),(22,1,65,1),(22,2,64,1),(22,3,61,1),
 (23,0,62,3.5)]
F1=[iirpeak(f,f/q,fs=SR) for f,q in ((620,3),(1450,4),(2700,5))]
for i,(bar,beat,m,dur) in enumerate(MEL):
    nxt=MEL[i+1] if i+1<len(MEL) else None
    hold=dur*B*(.98 if nxt and abs((nxt[0]*4+nxt[1])-(bar*4+beat+dur))<1e-6 else .85);n=int((hold+.25)*SR);t=np.arange(n)/SR
    f0=mtof(m);sc=-.45*np.exp(-t/.05)                                   # scoop up into the note
    vib=np.clip((t-.22)/.3,0,1)*.16*np.sin(2*np.pi*5.4*t)              # delayed vibrato
    fall=np.where(t>hold-.12,-1.2*np.clip((t-(hold-.12))/.25,0,1),0) if dur>=2 and (nxt is None or nxt[0]>bar+1 or i==len(MEL)-1) else 0
    f=f0*2**((sc+vib+fall)/12);ph=2*np.pi*np.cumsum(f)/SR
    reed=saw_phase(ph,f0,8000,1.05)+.35*saw_phase(2*ph,2*f0,8000,1.3)
    y=sum(lfilter(b,a,reed) for b,a in F1)*.9+lp(reed,900)*.5
    br=bp(rng.standard_normal(n),1800,5200)*.18                          # breath
    growl=1+.18*np.sin(2*np.pi*31*t)*(m>=74)                            # rasp on the high notes
    e=env(n,.035,.15,.82,.07,hold)*(1+.15*np.clip(t/.6,0,1))
    y=np.tanh(2.2*(y*growl+br)*e)*.55
    add(sax,y,bar*BAR+beat*B)
d=int(.75*B*SR);dl=np.zeros_like(sax);dl[d:]=sax[:-d]*.32;dl[2*d:]+=sax[:-2*d]*.12   # dotted-8th delay
sax=reverb(sax+lp(dl,3000),2.6,5000,.38)
# ---------------- mix ----------------
drums=kick*.9+snare*.62+hat*.18+tom*.5
mix=drums+bass*.42+reverb(pad,3.2,3500,.5)+reverb(arp,2.5,4000,.45)+sax*.8
mix=reverb(mix,1.2,6000,.06)
# grime: tape wow, hiss, crunchy top cut, glue saturation
t=np.arange(len(mix))/SR;idx=np.arange(len(mix))+SR*.0011*np.sin(2*np.pi*.45*t)+SR*.0003*np.sin(2*np.pi*3.1*t)
mix=np.interp(idx,np.arange(len(mix)),mix)
hiss=hp(lp(rng.standard_normal(len(mix)),9000),2000)*.006
mix=lp(mix,10500,2)+hiss
mix=np.tanh(mix/np.percentile(np.abs(mix),99.7)*1.1)*.9
# seamless loop: fold the tail back onto the start
out=mix[:L].copy();out[:TAIL]+=mix[L:L+TAIL]
out/=np.abs(out).max()/.95
st=np.stack([out,np.roll(out,int(.0007*SR))*.97],1)   # a touch of width
import wave
w=wave.open('nightshift.wav','wb');w.setnchannels(2);w.setsampwidth(2);w.setframerate(SR);w.writeframes((st*32767).astype('<i2').tobytes());w.close()
print('len',L/SR,'rms',np.sqrt((out**2).mean()))
