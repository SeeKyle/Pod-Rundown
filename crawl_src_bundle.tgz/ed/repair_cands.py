# weak link -> (read, why, [(swap, why), ...])  tiers assigned from real prices afterwards
C = {
'eddie_vivi': [
 ('Fog Bank', 2, "A defensive wall in a deck that wins by attacking with Vivi; it never grows him or pings.", [
   ('Izzet Signet', "2-mana rock; Mana is the deck's weakest stat"), ('Ponder', "1-mana cantrip: grows Vivi and digs"),
   ('Talisman of Creativity', "2-mana U/R rock"), ('Third Path Iconoclast', "every noncreature spell makes a Soldier"),
   ('Rhystic Study', "draws all game"), ('Mana Vault', "huge early burst for the big spell turn")]),
 ('Staff of the Flame Magus', 2, "3 mana for 1 life per red spell; it doesn't touch the board or grow Vivi.", [
   ('Expressive Iteration', "2-mana dig that grows Vivi"), ('Fellwar Stone', "2-mana rock"),
   ('Arcane Signet', "2-mana any-color rock"), ('Ledger Shredder', "connives on your second spell each turn"),
   ('Mystic Remora', "1-mana draw engine"), ('Jeweled Lotus', "a free turn-3 Vivi plus a spell")]),
 ('Staff of the Mind Magus', 2, "Same as the Flame Magus: small life gain for 3 mana.", [
   ('Consider', "1-mana cantrip"), ('Mind Stone', "2-mana rock that cashes in for a card"),
   ('Swiftfoot Boots', "hexproof and haste keep Vivi alive"), ('Lightning Greaves', "free haste and shroud for Vivi"),
   ('Archmage Emeritus', "every spell draws a card"), ('Mana Crypt', "the best rock there is")]),
 ('Lightning Talons', 3, "+3/+0 first strike aura: fine, but an aura that dies with Vivi and doesn't draw.", [
   ('Rogue\'s Passage', "makes Vivi unblockable from a land slot"), ('Kessig Flamebreather', "pings on every noncreature spell"),
   ('Sword of Fire and Ice', "protection, damage and a card each hit"), ('Shadowspear', "trample, lifelink and +1/+1"),
   ('Mirrorshell Crab', "ward 3 creature that also counters"), ('Sword of Feast and Famine', "protection and untaps your lands")]),
],
'eddie_bruce': [
 ('Fated Firepower', 2, "XRRR for a damage boost; the deck rarely deals that many separate hits.", [
   ('Three Visits', "a dual land into play for 2"), ('Nature\'s Lore', "Forest-type land into play for 2"),
   ('Beast Within', "instant answer to anything"), ('Growth Spiral', "draw and an extra land"),
   ('Tatyova, Steward of Tides', "lands become 5/5s once you have seven"), ('Field of the Dead', "Zombies from every land drop")]),
 ('Cavalcade of Calamity', 2, "Pings with 1-power attackers; this deck's creatures are big.", [
   ('Rampant Growth', "basic land into play"), ('Harrow', "two lands, both landfall triggers"),
   ('Lotus Cobra', "landfall mana"), ('Tireless Provisioner', "landfall Treasure or Food"),
   ('Avenger of Zendikar', "landfall army"), ('Amulet of Vigor', "bounce lands and tapped lands untap")]),
 ('Hawkeye\'s Bow', 3, "A 1-mana ping equipment; fine but small next to the deck's threats.", [
   ('Explore', "extra land and a card"), ('Ranger\'s Path', "two Forests into play"),
   ('Rites of Flourishing', "everyone plays an extra land and draws"), ('Omnath, Locus of Rage', "landfall Elementals"),
   ('Mosswort Bridge', "free spell when you have 10 power"), ('Oracle of Mul Daya', "lands off the top")]),
 ('Treasure Nabber', 3, "Only works if opponents tap artifacts on your turn.", [
   ('Kodama\'s Reach', "two basics"), ('Farseek', "a typed dual into play"),
   ('Ohran Frostfang', "attacking creatures draw on hit"), ('Rishkar\'s Expertise', "draw equal to the Hulk's power"),
   ('Greater Good', "sac the Hulk to draw 8"), ('Return of the Wildspeaker', "draw equal to greatest power")]),
],
'eddie_cloud': [
 ('Ultimate Magic: Meteor', 2, "Hits your own team as hard as theirs in a deck that wants a big board.", [
   ('Swords to Plowshares', "1-mana instant exile"), ('Path to Exile', "1-mana instant exile"),
   ('Chaos Warp', "answers anything"), ('Generous Gift', "destroy any permanent"),
   ('Austere Command', "pick the modes that spare your equipment"), ('Farewell', "one-sided if you pick")]),
 ('Ashe, Princess of Dalmasca', 3, "A 3/2 that digs for an artifact only when it attacks.", [
   ('Stoneforge Mystic', "tutors an Equipment and cheats it in"), ('Sigarda\'s Aid', "flash Equipment that auto-attach"),
   ('Steelshaper\'s Gift', "1-mana Equipment tutor"), ('Open the Armory', "Equipment or aura tutor"),
   ('Sram, Senior Edificer', "draws on every Equipment"), ('Godo, Bandit Warlord', "fetches Equipment and gives an extra combat")]),
 ('Seifer Almasy', 3, "Double strike only for a lone attacker, and Cloud wants several equipped attackers.", [
   ('Mirror Entity', "makes the whole team huge"), ('Reconnaissance', "free untaps after combat"),
   ('Fervent Champion', "1-drop with cheaper equip"), ('Kemba, Kha Regent', "Cat tokens from equipment"),
   ('Sword of Hearth and Home', "protection and ramp"), ('Sword of Feast and Famine', "untap lands and discard")]),
 ('Cartographer\'s Survey', 3, "4 mana for two tapped lands; slow ramp next to the rocks.", [
   ('Rampant Growth', "2-mana ramp"), ('Nature\'s Lore', "2-mana ramp untapped"),
   ('Three Visits', "2-mana dual into play"), ('Farseek', "2-mana dual into play"),
   ('Wayfarer\'s Bauble', "colorless ramp"), ('Jeweled Lotus', "a free turn-3 Cloud")]),
],
'eddie_kasla': [
 ('Cathartic Reunion', 2, "Discard two to draw three; the deck has better card flow through Kasla.", [
   ('Faithless Looting', "cheap filtering"), ('Inspiring Overseer', "a flier and a card"),
   ('Welcoming Vampire', "draws when small creatures enter"), ('Tocasia\'s Welcome', "draws on small creatures"),
   ('Esper Sentinel', "taxes their spells for cards"), ('Rhystic Study', "draws all game")]),
 ('Venerated Loxodon', 3, "Counters on the convokers; fine but small.", [
   ('Intangible Virtue', "tokens +1/+1 and vigilance"), ('Anointed Procession', "doubles tokens"),
   ('Divine Visitation', "tokens become 4/4 fliers"), ('Cathars\' Crusade', "counters on every creature entering"),
   ('Adeline, Resplendent Cathar', "a token per opponent every attack"), ('Parallel Lives', "doubles tokens")]),
 ('Shatter the Source', 3, "6 mana convoke removal; fine but narrow.", [
   ('Swords to Plowshares', "1-mana instant exile"), ('Path to Exile', "1-mana instant exile"),
   ('Lightning Helix', "kill and life"), ('Chaos Warp', "answers anything"),
   ('Teferi\'s Protection', "saves the board from anything"), ('Flawless Maneuver', "free team indestructible")]),
 ('Temporal Cleansing', 3, "A convoke tuck; slow for what it does.", [
   ('Generous Gift', "destroy any permanent"), ('Chord of Calling', "convoke creature tutor"),
   ('March of the Multitudes', "convoke X tokens at instant speed"), ('Skyclave Apparition', "exiles a cheap permanent"),
   ('Mentor of the Meek', "draws on every small creature"), ('Smothering Tithe', "Treasure whenever they draw")]),
],
'eddie_splinter': [
 ('Unexpected Fangs', 2, "One counter and lifelink for 2; small.", [
   ('Changeling Outcast', "unblockable 1-drop changeling: a Ninja for Splinter"), ('Mist-Syndicate Naga', "copies itself on every hit (twice with Splinter)"),
   ('Ingenious Mastery', "draw three"), ('Prosperous Thief', "Treasure on every Ninja hit"),
   ('Thousand-Faced Shadow', "ninjutsu flier that copies an attacker"), ('Fierce Guardianship', "free counterspell")]),
 ('Arcane Adaptation', 2, "Makes everything a Ninja, but most of the deck already is one.", [
   ('Gingerbrute', "evasive haste 1-drop for ninjutsu"), ('Mistblade Shinobi', "ninjutsu that bounces a creature"),
   ('Ninja of the Deep Hours', "classic ninjutsu draw"), ('Sakashima\'s Student', "ninjutsu clone"),
   ('Throat Slitter', "ninjutsu that kills a creature"), ('Smothering Tithe', "Treasure whenever they draw")]),
 ('Vanquish the Horde', 3, "An 8-mana wipe in a deck of small creatures.", [
   ('Swords to Plowshares', "1-mana instant exile"), ('Fatal Push', "1-mana kill"),
   ('Anguished Unmaking', "instant exile anything"), ('Toxic Deluge', "flexible wipe"),
   ('Damnation', "2-mana-cheaper wipe"), ('Teferi\'s Protection', "saves your board")]),
 ('Executioner\'s Hood', 3, "Intimidate equipment; Splinter already makes Ninjas unblockable.", [
   ('Whispersilk Cloak', "unblockable and shroud"), ('Arcane Signet', "2-mana any-color rock"),
   ('Talisman of Dominance', "2-mana U/B rock"), ('Fellwar Stone', "2-mana rock"),
   ('Rhystic Study', "draws all game"), ('Bitterblossom', "a flying Faerie every turn: ninjutsu fodder")]),
],
'eddie_miles': [
 ('Web-Shooters', 3, "+1/+1 reach and a tap on attack; small in a counters deck.", [
   ('Rampant Growth', "ramp; only 45% reach 5 by turn 6"), ('Nature\'s Lore', "untapped ramp"),
   ('Inspiring Call', "draws per countered creature"), ('Guardian Project', "draws on every new creature"),
   ('Kodama\'s Reach', "two basics"), ('Rishkar, Peema Renegade', "counters and mana dorks")]),
 ('Nyxborn Wolf', 3, "A 3/1 or a +3/+1 bestow; plain.", [
   ('Kami of Whispered Hopes', "doubles the counter-mana"), ('Conclave Mentor', "an extra counter and life"),
   ('Branching Evolution', "doubles counters"), ('Walking Ballista', "counter sink and removal"),
   ('Corpsejack Menace', "doubles counters"), ('Doubling Season', "doubles counters")]),
 ('Path of Discovery', 3, "Every creature explores: slow card flow for 4 mana.", [
   ('Elemental Bond', "draws on every 3-power creature"), ('Shamanic Revelation', "draw per creature"),
   ('Return of the Wildspeaker', "draw equal to greatest power"), ('Rishkar\'s Expertise', "draw equal to your biggest creature"),
   ('The Great Henge', "draws and counters every creature"), ('Sylvan Library', "card selection every turn")]),
 ('Friendly Neighborhood', 3, "Three 1/1s and a pump land; slow.", [
   ('Cultivate', "two basics"), ('Three Visits', "a dual into play"),
   ('Swords to Plowshares', "1-mana instant exile"), ('Generous Gift', "destroy any permanent"),
   ('Beast Within', "answers anything"), ('Heroic Intervention', "saves the board")]),
],
'eddie_narset': [
 ('Soulfire Grand Master', 3, "Lifelink spells and a buyback; little to do with Narset's free spells.", [
   ('Talisman of Conviction', "2-mana R/W rock"), ('Azorius Signet', "2-mana W/U rock"),
   ('Fellwar Stone', "2-mana rock"), ('Jeskai Charm', "removal or a team pump"),
   ('Relentless Assault', "an extra combat Narset can cast free"), ('Mana Crypt', "turn-3 Narset")]),
 ('Chain Reaction', 3, "Damage-based wipe that also hits your few creatures.", [
   ('Blasphemous Act', "13 damage wipe, usually 1 mana"), ('Hour of Revelation', "destroy all nonland permanents"),
   ('Cyclonic Rift', "one-sided bounce"), ('Farewell', "choose what to exile"),
   ('Comet Storm', "flexible burn"), ('Insurrection', "steal their whole board free off Narset")]),
 ('Combat Celebrant', 3, "4/1 that only gives an extra combat if it survives; fragile.", [
   ('Relentless Assault', "an extra combat"), ('Seize the Day', "an extra combat with flashback"),
   ('World at War', "two extra combats with rebound"), ('Aurelia, the Warleader', "an extra combat on attack"),
   ('Moraug, Fury of Akoum', "extra combat on landfall"), ('Hellkite Charger', "flying extra combats")]),
 ('Clash of Titans', 3, "5-mana fight; your creatures are few and small.", [
   ('Swords to Plowshares', "1-mana instant exile"), ('Chaos Warp', "answers anything"),
   ('Lightning Helix', "kill and life"), ('Generous Gift', "destroy any permanent"),
   ('Teferi\'s Protection', "saves Narset from anything")]),
],
}
