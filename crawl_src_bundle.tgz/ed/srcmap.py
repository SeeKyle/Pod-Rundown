import ast,glob,json
out={}
for f in sorted(glob.glob('/home/claude/pod2/decks/*.py')):
    src=open(f).read();tree=ast.parse(src)
    for node in tree.body:
        if isinstance(node,ast.Assign) and getattr(node.targets[0],'id',None)=='TAGS' and isinstance(node.value,ast.Dict):
            for k,v in zip(node.value.keys,node.value.values):
                try:name=ast.literal_eval(k)
                except:continue
                seg=ast.get_source_segment(src,v)
                if name not in out:out[name]=(f.split('/')[-1],seg)
json.dump(out,open('/tmp/ed/srcmap.json','w'))
print(len(out))
