import sys;sys.path.insert(0,'/home/claude/pod2');sys.path.insert(0,'/home/claude/pod2/decks')
import score
res,divs=score.run()
for r in res:
  if not r['key'].startswith('eddie'): continue
  cs=r['cards'];nl=[c for c in cs if not c['is_land']]
  tot=lambda c:sum(e['pts'] for e in c['entries'])
  lands=sum(1 for c in cs if c['is_land'])
  tapped=sum(1 for c in cs if c['is_land'] and any(e.get('entry')=='T' for e in c['entries']))
  rem=[c['name'] for c in nl if any(e['stat']=='interaction' for e in c['entries'])]
  print('##',r['key'],r['meta']['deck'],'lands',lands,'tapped',tapped,{k:v for k,v in r['rating'].items()})
  print(' TOP:',' | '.join(f"{c['name']}({tot(c):.1f})" for c in sorted(nl,key=tot,reverse=True)[:9]))
  print(' LOW:',' | '.join(f"{c['name']}({tot(c):.2f},{c['mv']:.0f},{''.join(sorted(c['plan']))})" for c in sorted(nl,key=tot)[:8]))
  print(' REM:',', '.join(rem))
