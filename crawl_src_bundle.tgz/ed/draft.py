import json,re,sys
P='/home/claude/pod2/'
raw=json.load(open(P+'raw_lists.json')); CT=json.load(open(P+'card_text.json')); M=json.load(open('/tmp/ed/srcmap.json'))
INC=json.load(open(P+'inclusion.json'))
B={'Plains','Island','Swamp','Mountain','Forest','Wastes'}|{'Snow-Covered '+x for x in ['Plains','Island','Swamp','Mountain','Forest']}
key=sys.argv[1]; L=raw[key]
mode=sys.argv[2] if len(sys.argv)>2 else 'dump'
names=[c['name'] for c in L if c['name'] not in B]
if mode=='dump':
  for n in names:
    if n in M: continue
    t=re.sub(r' ?\([^()]*\)','',CT[n]); t=t.replace('\n----\n',' // ').replace('\n',' | ')
    print('*',t)
  print('basics',sum(c['q'] for c in L if c['name'] in B),'lands',sum(1 for n in names if 'Land' in CT[n].split('\n')[1] and '//' not in n))
else:
  for n in names:
    if n in M: print(f" {n!r}: {M[n][1]},")
