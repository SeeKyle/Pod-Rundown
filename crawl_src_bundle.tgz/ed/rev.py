import sys;sys.path.insert(0,'/home/claude/pod2');sys.path.insert(0,'/home/claude/pod2/decks')
import score
info=score.load_info();r=score.score_deck(sys.argv[1],info)
print('missing',r['missing'],'extra',r['extra'])
for c in sorted(r['cards'],key=lambda c:sum(e['pts'] for e in c['entries'])):
  if c['is_land']: continue
  p=sum(e['pts'] for e in c['entries'])
  if p<0.45: print(f"{p:.2f} {c['name']} {sorted(c['plan'])}")
