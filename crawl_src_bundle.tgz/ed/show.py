import sys;sys.path.insert(0,'/home/claude/pod2');sys.path.insert(0,'/home/claude/pod2/decks')
import score
info=score.load_info();r=score.score_deck(sys.argv[1],info)
for c in sorted(r['cards'],key=lambda c:-sum(e['pts'] for e in c['entries'])):
  if c['is_land']: continue
  st={}
  for e in c['entries']: st[e['stat'][:4]]=round(st.get(e['stat'][:4],0)+e['pts'],2)
  print(f"{sum(st.values()):.2f} {c['name'][:30]:30} {''.join(sorted(c['plan'])):2} {st}")
