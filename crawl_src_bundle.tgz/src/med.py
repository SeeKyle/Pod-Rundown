from playwright.sync_api import sync_playwright
STUB="(function(){const f=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:k==='length'?0:f,apply:()=>f});window.d3=f;})();"
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox']);pg=b.new_page();errs=[]
    pg.route('**/d3.min.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=STUB))
    pg.on('pageerror',lambda e:errs.append(str(e)[:300]))
    pg.goto('file:///home/claude/pod2/index.html');pg.wait_for_timeout(1500)
    res=pg.evaluate("""()=>{const S=window.__SIM;const out={};
      for(const deck of [null,'Build a Scare']){let heal=0,rv=0,err=null;
        for(let r=0;r<120;r++){const team=['druid','flannel','lumberjack'];const slot=S.newSlot('Kyle');for(const k of team)slot.heroes[k].lvl=3;if(deck)slot.heroes.druid.insp=deck;
          const run=S.newRun(team,slot);run.stage=2;let g;try{g=new S.Game({run,slot});let t=0;while(!g.over&&t<200){g.step(1/30);t+=1/30;}
          const d=g.heroes.find(h=>h.key==='druid');heal+=g.st8(d).heal;rv+=g.st8(d).revives;}catch(e){err=String(e).slice(0,200);break;}}
        out[deck||'none']={heal:Math.round(heal/120),rv,err};}
      return out;}""")
    print(res,errs[:3]);b.close()
