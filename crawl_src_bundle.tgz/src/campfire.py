import sys
from playwright.sync_api import sync_playwright
STUB="(function(){const f=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:k==='length'?0:f,apply:()=>f});window.d3=f;})();"
vp={'width':int(sys.argv[1]),'height':int(sys.argv[2])} if len(sys.argv)>2 else {'width':1280,'height':800}
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    ctxt=b.new_context(viewport=vp);pg=ctxt.new_page();errs=[]
    pg.route('**/d3.min.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=STUB))
    pg.on('pageerror',lambda e:errs.append(str(e.stack)[:600]));pg.on('console',lambda m:errs.append(m.text[:200]) if m.type=='error' else None)
    pg.goto('file:///home/claude/pod2/index.html');pg.wait_for_timeout(1500)
    pg.click('.cs-play');pg.wait_for_timeout(500);pg.click('[data-p="Kyle"]');pg.wait_for_timeout(300)
    def pin():
        for d in '1234': pg.get_by_role('button',name=d,exact=True).click(); pg.wait_for_timeout(60)
        pg.wait_for_timeout(350)
    pin();pin()
    pg.click('[data-new="0"]');pg.wait_for_timeout(600)
    pg.screenshot(path='/tmp/cf_party.png')
    for k in ['flannel','robot','druid']:pg.click(f'.cc-hero[data-k="{k}"]')
    pg.click('[data-go]');pg.wait_for_timeout(600)
    pg.screenshot(path='/tmp/cf_pre.png');print('E0',errs)
    pg.get_by_text('BEGIN STAGE 1').click();pg.wait_for_timeout(2500)
    pg.evaluate("window.__GM.over='clear'");pg.wait_for_timeout(1500)
    for t in ['Continue','CONTINUE','TO CAMP','Camp']:
        try:pg.get_by_text(t,exact=False).first.click(timeout=800);break
        except Exception:pass
    pg.wait_for_timeout(1500);pg.screenshot(path='/tmp/cf1.png');pg.wait_for_timeout(300)
    el=pg.query_selector('canvas.cc-fire')
    if el:el.screenshot(path='/tmp/cf2.png')
    print('fire',bool(el),'ERRS',errs);b.close()
