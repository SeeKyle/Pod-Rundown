from playwright.sync_api import sync_playwright
STUB="(function(){const f=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:k==='length'?0:f,apply:()=>f});window.d3=f;})();"
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    for name,vp in [('desk',{'width':1280,'height':800}),('port',{'width':390,'height':844}),('land',{'width':844,'height':390})]:
        mob=name!='desk'
        ctxt=b.new_context(viewport=vp,is_mobile=mob,has_touch=mob,device_scale_factor=2 if mob else 1)
        pg=ctxt.new_page();errs=[]
        pg.route('**/d3.min.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=STUB))
        pg.on('pageerror',lambda e:errs.append(str(e)[:300]))
        pg.goto('file:///home/claude/pod2/index.html');pg.wait_for_timeout(1500)
        pg.evaluate("localStorage.setItem('podrundown-sideways','0')")
        pg.click('.cs-play');pg.wait_for_timeout(500);pg.click('[data-p="Kyle"]');pg.wait_for_timeout(300)
        def pin():
            for d in '1234': pg.get_by_role('button',name=d,exact=True).click(); pg.wait_for_timeout(60)
            pg.wait_for_timeout(350)
        pin();pin()
        pg.click('[data-new="0"]');pg.wait_for_timeout(600)
        box='.cc-insp[data-ik="flannel"]'
        pg.select_option(box+' [data-ip]','Kyle');pg.select_option(box+' [data-id]','The Grim Throne');pg.wait_for_timeout(100)
        if name=='desk':print(pg.inner_text(box+' .cc-ibx'))
        for k in ['flannel','robot','druid']:pg.click(f'.cc-hero[data-k="{k}"]')
        pg.click('[data-go]');pg.wait_for_timeout(600)
        pg.get_by_text('BEGIN STAGE 1').click();pg.wait_for_timeout(9000)
        pg.screenshot(path=f'/tmp/ph_{name}.png')
        print(name,pg.evaluate("JSON.stringify([document.querySelector('#cc-cv').style.cssText,document.querySelector('.cc-cvw').style.cssText])"))
        if name=='desk':
            pg.evaluate("(()=>{const g=window.__GM;g.over='clear';})()");pg.wait_for_timeout(1500)
            for t in ['Continue','CONTINUE','TO CAMP','Camp']:
                try:pg.get_by_text(t,exact=False).first.click(timeout=800);break
                except Exception:pass
            pg.wait_for_timeout(800)
            pg.evaluate("document.querySelectorAll('details.cc-skills').forEach(d=>d.open=true)")
            n=pg.evaluate("document.querySelectorAll('details.cc-skills').length");print('skills tabs',n)
            if n:
                el=pg.query_selector('details.cc-skills');el.scroll_into_view_if_needed()
                ch=pg.query_selector_all('details.cc-skills .cc-chip');print([c.inner_text() for c in ch])
                ch[-1].hover();pg.wait_for_timeout(300);pg.screenshot(path='/tmp/ph_skills.png')
        print('ERRS',errs);ctxt.close()
    b.close()
