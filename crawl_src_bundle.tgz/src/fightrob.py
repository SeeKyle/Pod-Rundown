from playwright.sync_api import sync_playwright
STUB="(function(){const f=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:k==='length'?0:f,apply:()=>f});window.d3=f;})();"
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=b.new_page(viewport={'width':1280,'height':800});errs=[]
    pg.route('**/d3.min.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=STUB))
    pg.on('pageerror',lambda e:errs.append(str(e)[:300]))
    pg.goto('file:///home/claude/pod2/index.html');pg.wait_for_timeout(1500)
    pg.click('.cs-play');pg.wait_for_timeout(500);pg.click('[data-p="Kyle"]');pg.wait_for_timeout(300)
    def pin():
        for d in '1234': pg.get_by_role('button',name=d,exact=True).click(); pg.wait_for_timeout(60)
        pg.wait_for_timeout(350)
    pin();pin()
    pg.click('[data-new="0"]');pg.wait_for_timeout(600)
    for k in ['robot','archer','chibi']:pg.click(f'.cc-hero[data-k="{k}"]')
    pg.screenshot(path='/tmp/rob_party.png')
    pg.click('[data-go]');pg.wait_for_timeout(600)
    pg.get_by_text('BEGIN STAGE 1').click();pg.wait_for_timeout(1500)
    pg.evaluate("(()=>{const g=window.__GM;const R=g.heroes.find(h=>h.key==='robot');R.hp=R.max*.6;})()")
    shots=0;seen=set()
    for i in range(300):
        st=pg.evaluate("(()=>{const g=window.__GM;if(!g)return null;const R=g.heroes.find(h=>h.key==='robot');return {lz:!!(R&&R.lz&&R.lz.t>.6),ch:!!(R&&R.lz&&R.lz.t<.5),jet:!!(R&&R.jet),nano:!!(R&&R.nano),fl:!!(R&&R.animM>.2),st:g.heroes.some(h=>h.stealthT>0),over:g.over}})()")
        if st:
            for k in ['lz','ch','jet','nano','fl','st']:
                if st[k] and k not in seen and shots<8:
                    seen.add(k);pg.screenshot(path=f'/tmp/rob_{k}.png',clip={'x':0,'y':40,'width':1280,'height':720});print(i,k);shots+=1
            if i==60:pg.evaluate("(()=>{const g=window.__GM;const R=g.heroes.find(h=>h.key==='robot');g.hurtHero(R,R.hp-R.max*.25,null);})()")
            if st['over']:break
        if len(seen)>=6:break
        pg.wait_for_timeout(150)
    print('ERRS',errs);b.close()
