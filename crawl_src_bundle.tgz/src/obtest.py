exec(open('/tmp/fmtest9.py').read().split("    for i in range(3):")[0])
pg.evaluate("1")
for i in range(5):
    pg.wait_for_timeout(8000); pg.screenshot(path=f'/tmp/ob{i}.png')
print(pg.evaluate("(()=>{try{return JSON.stringify(window.__ob||null)}catch(e){return String(e)}})()"))
print('ERRS',errs)
b.close()
