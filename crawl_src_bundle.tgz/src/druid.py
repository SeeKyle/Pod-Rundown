from playwright.sync_api import sync_playwright
STUB="(function(){const f=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:k==='length'?0:f,apply:()=>f});window.d3=f;})();"
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=b.new_page(viewport={'width':1280,'height':900}); errs=[]
    pg.route('**/d3.min.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=STUB))
    pg.on('pageerror',lambda e:errs.append(str(e)[:300]))
    pg.goto('file:///home/claude/pod2/index.html'); pg.wait_for_timeout(1500)
    pg.click('.cs-play'); pg.wait_for_timeout(500); pg.click('[data-p="Kyle"]'); pg.wait_for_timeout(300)
    def pin():
        for d in '1234': pg.get_by_role('button',name=d,exact=True).click(); pg.wait_for_timeout(60)
        pg.wait_for_timeout(350)
    pin(); pin()
    pg.click('[data-new="0"]'); pg.wait_for_timeout(600)
    box='.cc-insp[data-ik="flannel"]'
    pg.select_option(box+' [data-ip]','Kyle'); pg.wait_for_timeout(100)
    print(pg.evaluate(f"[...document.querySelectorAll('{box} [data-id] option')].map(o=>o.textContent).join('\\n')"))
    pg.select_option(box+' [data-id]','Dice Boys Casino'); pg.wait_for_timeout(100)
    print(pg.inner_text(box+' .cc-ibx'))
    print(pg.get_attribute('.cc-hero[data-k="flannel"]','title'))
    pg.screenshot(path='/tmp/pick.png')
    pg.click('.cc-hero[data-k="druid"]'); pg.click('.cc-hero[data-k="robot"]'); pg.click('.cc-hero[data-k="flannel"]'); pg.click('[data-go]'); pg.wait_for_timeout(600)
    pg.get_by_text('BEGIN STAGE 1').click(); pg.wait_for_timeout(500)
    
    pg.wait_for_timeout(500)
    pg.evaluate("(()=>{const g=window.__GM;window.__st={};setInterval(()=>{const h=g.heroes.find(x=>x.key==='druid');if(!h||!h.alive)return;const mov=h.moving||g.scroll;if(!mov){window.__st.still=(window.__st.still||0)+1;return;}const why=h.riseT>0?'rise':h.animM>0?'melee':h.animR>0?'ranged':(h.casting>0||h.animC>0)?'cast':h.hitFlash>0?'hurt':h.cast?'aim':h.search?'search':'walk';window.__st[why]=(window.__st[why]||0)+1;window.__st.mvonly=(window.__st.mvonly||0)+(h.moving?1:0);},50);})()")
    pg.wait_for_timeout(25000)
    print(pg.evaluate("JSON.stringify(window.__st)"))
    print('ERRS',errs);b.close()
