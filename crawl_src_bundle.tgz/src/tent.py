from playwright.sync_api import sync_playwright
STUB="(function(){const f=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:k==='length'?0:f,apply:()=>f});window.d3=f;})();"
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=b.new_page(viewport={'width':1280,'height':900}); errs=[]
    pg.route('**/d3.min.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=STUB))
    pg.on('pageerror',lambda e:errs.append(str(e)[:300]))
    pg.goto('file:///home/claude/pod2/index.html'); pg.wait_for_timeout(1500)
    pg.click('.cs-play'); pg.wait_for_timeout(500); pg.click('[data-p="Kyle"]'); pg.wait_for_timeout(300)
    def pin():
        for d in '1234': pg.get_by_role('button',name=d,exact=True).click(); pg.wait_for_timeout(60)
        pg.wait_for_timeout(350)
    pin(); pin()
    pg.click('[data-new="0"]'); pg.wait_for_timeout(600)
    box='.cc-insp[data-ik="flannel"]'
    pg.select_option(box+' [data-ip]','Kyle'); pg.wait_for_timeout(100)
    print(pg.evaluate(f"[...document.querySelectorAll('{box} [data-id] option')].map(o=>o.textContent).join('\\n')"))
    pg.select_option(box+' [data-id]','Dice Boys Casino'); pg.wait_for_timeout(100)
    print(pg.inner_text(box+' .cc-ibx'))
    print(pg.get_attribute('.cc-hero[data-k="flannel"]','title'))
    pg.screenshot(path='/tmp/pick.png')
    pg.click('.cc-hero[data-k="druid"]'); pg.click('.cc-hero[data-k="robot"]'); pg.click('.cc-hero[data-k="flannel"]'); pg.click('[data-go]'); pg.wait_for_timeout(600)
    pg.get_by_text('BEGIN STAGE 1').click(); pg.wait_for_timeout(500)
    
    pg.wait_for_timeout(14000)
    pg.evaluate("(()=>{const g=window.__GM;g.stageFood=1;g.stageWater=1;g.stageParts=30;g.stageGold=900;const S=window.__SLOTF();S.heroes.robot.lvl=3;S.run.upg={tower:1,still:1,kennel:2,radio:1};S.run.food=4;S.heroes.robot.insp='The Grim Throne';g.over='clear';})()")
    pg.wait_for_timeout(1500)
    pg.screenshot(path='/tmp/clear.png',full_page=True)
    print(pg.inner_text('.cc-panel')[:1500])
    pg.click('[data-c]');pg.wait_for_timeout(800)
    print([e.inner_text() for e in pg.query_selector_all('[data-upg]')])
    pg.hover('.cc-tent');pg.wait_for_timeout(400)
    tip=pg.evaluate("(()=>{const t=[...document.querySelectorAll('div')].filter(d=>d.innerText&&d.innerText.startsWith('⛺ Every camp upgrade'));return t.length?t[t.length-1].innerText:'NO TIP'})()")
    print(tip)
    pg.screenshot(path='/tmp/tent.png')
    print('ERRS',errs);b.close()
