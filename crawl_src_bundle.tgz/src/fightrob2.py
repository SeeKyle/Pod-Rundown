from playwright.sync_api import sync_playwright
STUB="(function(){const f=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:k==='length'?0:f,apply:()=>f});window.d3=f;})();"
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=b.new_page(viewport={'width':1280,'height':800});errs=[]
    pg.route('**/d3.min.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=STUB))
    pg.on('pageerror',lambda e:errs.append(str(e)[:300]))
    pg.goto('file:///home/claude/pod2/index.html');pg.wait_for_timeout(1500)
    pg.click('.cs-play');pg.wait_for_timeout(500);pg.click('[data-p="Kyle"]');pg.wait_for_timeout(300)
    def pin():
        for d in '1234': pg.get_by_role('button',name=d,exact=True).click(); pg.wait_for_timeout(60)
        pg.wait_for_timeout(350)
    pin();pin()
    pg.click('[data-new="0"]');pg.wait_for_timeout(600)
    for k in ['robot','archer','chibi']:pg.click(f'.cc-hero[data-k="{k}"]')
    pg.screenshot(path='/tmp/rob_party.png')
    pg.click('[data-go]');pg.wait_for_timeout(600)
    pg.get_by_text('BEGIN STAGE 1').click();pg.wait_for_timeout(1500)
    pg.wait_for_timeout(4000)
    pg.evaluate("(()=>{const g=window.__GM;const R=g.heroes.find(h=>h.key==='robot');R.x=150;g.startJet(R);})()")
    pg.wait_for_timeout(900);pg.screenshot(path='/tmp/rob_jet.png',clip={'x':0,'y':40,'width':1280,'height':720})
    pg.wait_for_timeout(3000)
    pg.evaluate("(()=>{const g=window.__GM;const R=g.heroes.find(h=>h.key==='robot');R.nano={t:0};const C=g.heroes.find(h=>h.key==='chibi');C.stealthT=5;})()")
    pg.wait_for_timeout(700);pg.screenshot(path='/tmp/rob_nano.png',clip={'x':0,'y':40,'width':1280,'height':720})
    print('ERRS',errs);b.close()
