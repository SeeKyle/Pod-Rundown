from playwright.sync_api import sync_playwright
import json
STUB="(function(){const f=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:k==='length'?0:f,apply:()=>f});window.d3=f;})();"
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox']);pg=b.new_page();errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)[:200]))
    pg.route('**/d3.min.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=STUB))
    pg.goto('file:///home/claude/pod2/index.html');pg.wait_for_timeout(1500)
    d=pg.evaluate("JSON.stringify(window.__INSP)");print(errs)
    for k,v in json.loads(d).items():
        parts=[]
        if v.get('passive'):parts.append('P:'+v['passive'])
        if v.get('perk'):parts.append('K:'+v['perk'])
        for kk in ('mod','sl','stash'):
            for a,bv in (v.get(kk) or {}).items():parts.append(f'{kk}.{a}={bv}')
        print(len(parts),v['o'],k,'|',', '.join(parts))
    b.close()
