from playwright.sync_api import sync_playwright
STUB="(function(){const f=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:k==='length'?0:f,apply:()=>f});window.d3=f;})();"
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=b.new_page(viewport={'width':1280,'height':900}); errs=[]
    pg.route('**/d3.min.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=STUB))
    pg.on('pageerror',lambda e:errs.append(str(e)[:300]))
    pg.goto('file:///home/claude/pod2/index.html'); pg.wait_for_timeout(1500)
    pg.click('.cs-play'); pg.wait_for_timeout(500); pg.click('[data-p="Kyle"]'); pg.wait_for_timeout(300)
    def pin():
        for d in '1234': pg.get_by_role('button',name=d,exact=True).click(); pg.wait_for_timeout(60)
        pg.wait_for_timeout(350)
    pin(); pin()
    pg.click('[data-new="0"]'); pg.wait_for_timeout(600)

    I=pg.evaluate("Object.fromEntries(Object.entries(window.__I.INSP).map(([d,v])=>[d,{o:v.o,mod:v.mod||{},sl:v.sl||{},passive:v.passive||null,txt:window.__I.inspText(d)}]))")
    SL=pg.evaluate("window.__I.SLIDERS.map(s=>[s[0],s[1],s[2]])"); SLD={s[0]:s for s in SL}
    PN=pg.evaluate("Object.fromEntries(Object.entries(window.__I.INSP_PASSIVE).map(([k,v])=>[k,v[0]]))")
    box='.cc-insp[data-ik="flannel"]'; bad=[]
    for d,v in list(I.items())[:0]:
        pg.select_option(box+' [data-ip]',v['o']); pg.wait_for_timeout(40)
        opt=pg.evaluate(f"[...document.querySelectorAll('{box} [data-id] option')].find(o=>o.value==={repr(d)}).textContent")
        pg.select_option(box+' [data-id]',d); pg.wait_for_timeout(40)
        ib=pg.inner_text(box+' .cc-ibx'); tip=pg.get_attribute('.cc-hero[data-k="flannel"]','data-tiph')
        exp=[]
        if v['passive']:exp.append(PN[v['passive']])
        for k,x in v['sl'].items():exp.append(f"{SLD[k][2] if x>0 else SLD[k][1]} +{abs(x)}")
        miss=[e for e in exp if e not in opt or e not in ib]
        print(f"{d[:24]:24} | {v['txt']:58} | option+box ok:{not miss} | tip has deck:{d in (tip or '') or 'n/a'}")
        if miss:bad.append((d,miss))
    print("UI MISMATCH:",bad)
    pg.select_option(box+' [data-ip]','Kyle'); pg.select_option(box+' [data-id]','')
    pg.click('.cc-hero[data-k="flannel"]'); pg.click('.cc-hero[data-k="robot"]'); pg.click('.cc-hero[data-k="cultist"]'); pg.click('[data-go]'); pg.wait_for_timeout(600)
    pg.get_by_text('BEGIN STAGE 1').click(); pg.wait_for_timeout(1500)
    pg.evaluate("cancelAnimationFrame(window.__CC.raf)")
    res=pg.evaluate("""(()=>{const g=window.__GM,I=window.__I,out={};
      const snap=h=>({acc:h.acc,crit:h.crit,dodge:h.dodge,armorPts:h.armorPts,max:h.max,xpBonus:h.xpBonus,kbRes:h.kbRes,enMaxB:h.enMaxB,enRegenB:h.enRegenB,lifesteal:h.lifesteal,mvMul:h.mvMul,meleeDmg:h.meleeDmg,rangedDmg:h.rangedDmg,meleeSpd:h.meleeSpd,rangedSpd:h.rangedSpd,kbAdd:h.kbAdd});
      g.heroes.forEach(h=>{h.insp=null;h.persona=null;});g.recalc();const base=g.heroes.map(h=>[snap(h),{...I.personaOf(h)}]);
      for(const d of Object.keys(I.INSP)){const v=I.INSP[d];window.__pc={};
        g.heroes.forEach(h=>{h.insp=d;h.persona=null;h.herbs=0;h.kit=[];h.medkit=0;});g.recalc();
        const s=snap(g.heroes[0]),b=base[0][0],dm={};for(const k in s)if(Math.abs(s[k]-b[k])>1e-9)dm[k]=+(s[k]-b[k]).toFixed(3);
        const p=I.personaOf(g.heroes[0]),dp={};for(const k in p)if(p[k]!==base[0][1][k])dp[k]=p[k]-base[0][1][k];
        // a few searchable things + cars nearby, everyone hurt, run 30 game-seconds
        const hx=Math.max(...g.alive().map(h=>h.x));for(const [k,o] of [['rock_1',20],['car_hatch',50],['log_1',80],['car_sedan',110]]){const D=window.__OB[k]||window.__OB[Object.keys(window.__OB).find(q=>q.startsWith(k.split('_')[0]+'_'))];if(D)g.obst.push({k:window.__OB[k]?k:Object.keys(window.__OB).find(q=>q.startsWith(k.split('_')[0]+'_')),x:hx+o,lanes:[1],blk:D.blk});}
        for(let t=0;t<30*30;t++){g.over=null;if(t%60===0&&g.enemies.filter(e=>!e.dead).length<4){const hx2=Math.max(...g.alive().map(h=>h.x));for(let i=0;i<3;i++)g.spawnEnemy(i==0&&t%300===0?'werewolf':'zombie',{x:hx2+30+i*12});}if(t%150===0)g.heroes.forEach(h=>{if(!h.alive){h.alive=true;h.downed=0;}h.hp=Math.max(1,h.max*.35);h.dead=false;});try{g.step(1/30);}catch(e){out[d]={err:String(e)};break;}}
        if(!out[d])out[d]={pc:{...window.__pc},E:g.enemies.filter(e=>!e.dead).length,dist:Math.round(g.dist),hx:g.heroes.map(h=>Math.round(h.x)+(h.alive?'':'x')),over:g.over||g.done||null};}
      return out;})()""")
    for d,r in res.items():
        v=I[d];print(f"{d[:24]:24}",r)
    print('ERRS',errs)
    b.close()
