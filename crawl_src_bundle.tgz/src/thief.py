from playwright.sync_api import sync_playwright
STUB="(function(){const f=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:k==='length'?0:f,apply:()=>f});window.d3=f;})();"
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=b.new_page(viewport={'width':1280,'height':900}); errs=[]
    pg.route('**/d3.min.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=STUB))
    pg.on('pageerror',lambda e:errs.append(str(e)[:300]))
    pg.goto('file:///home/claude/pod2/index.html'); pg.wait_for_timeout(1500)
    pg.click('.cs-play'); pg.wait_for_timeout(500); pg.click('[data-p="Kyle"]'); pg.wait_for_timeout(300)
    def pin():
        for d in '1234': pg.get_by_role('button',name=d,exact=True).click(); pg.wait_for_timeout(60)
        pg.wait_for_timeout(350)
    pin(); pin()
    pg.click('[data-new="0"]'); pg.wait_for_timeout(600)
    box='.cc-insp[data-ik="flannel"]'
    pg.select_option(box+' [data-ip]','Kyle'); pg.wait_for_timeout(100)
    print(pg.evaluate(f"[...document.querySelectorAll('{box} [data-id] option')].map(o=>o.textContent).join('\\n')"))
    pg.select_option(box+' [data-id]','Dice Boys Casino'); pg.wait_for_timeout(100)
    print(pg.inner_text(box+' .cc-ibx'))
    print(pg.get_attribute('.cc-hero[data-k="flannel"]','title'))
    pg.screenshot(path='/tmp/pick.png')
    pg.click('.cc-hero[data-k="cultist"]'); pg.click('.cc-hero[data-k="robot"]'); pg.click('.cc-hero[data-k="druid"]'); pg.click('[data-go]'); pg.wait_for_timeout(600)
    pg.get_by_text('BEGIN STAGE 1').click(); pg.wait_for_timeout(500)
    
    pg.wait_for_timeout(800)
    pg.evaluate("(()=>{const g=window.__GM;const t=g.heroes.find(h=>h.key==='cultist');t.insp='Armed Robbery';t.persona=null;g.recalc();window.__log=[];setInterval(()=>{for(const h of g.heroes)if(h.key!=='cultist'){h.medkit=1;h.defib=1;h.x=t.x+4;h.gy=t.gy;}},400);setInterval(()=>{for(const c of (g.calls||[]))if(!c._seen){c._seen=1;window.__log.push(c.u.key+': '+c.s);}},100);})()")
    pg.wait_for_timeout(40000)
    print(pg.evaluate("JSON.stringify({steals:window.__GM.stats.cultist,log:window.__log.filter(s=>!/Woof/.test(s)).slice(-14),self:window.__GM.heroes.find(h=>h.key==='cultist').persona.self})"))
    print('ERRS',errs);b.close()
