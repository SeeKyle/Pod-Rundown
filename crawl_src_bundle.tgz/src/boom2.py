from playwright.sync_api import sync_playwright
STUB="(function(){const f=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:k==='length'?0:f,apply:()=>f});window.d3=f;})();"
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=b.new_page(viewport={'width':1280,'height':900}); errs=[]
    pg.route('**/d3.min.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=STUB))
    pg.on('pageerror',lambda e:errs.append(str(e)[:300]))
    pg.goto('file:///home/claude/pod2/index.html'); pg.wait_for_timeout(1500)
    pg.click('.cs-play'); pg.wait_for_timeout(500); pg.click('[data-p="Kyle"]'); pg.wait_for_timeout(300)
    def pin():
        for d in '1234': pg.get_by_role('button',name=d,exact=True).click(); pg.wait_for_timeout(60)
        pg.wait_for_timeout(350)
    pin(); pin()
    pg.click('[data-new="0"]'); pg.wait_for_timeout(600)
    box='.cc-insp[data-ik="flannel"]'
    pg.select_option(box+' [data-ip]','Kyle'); pg.wait_for_timeout(100)
    print(pg.evaluate(f"[...document.querySelectorAll('{box} [data-id] option')].map(o=>o.textContent).join('\\n')"))
    pg.select_option(box+' [data-id]','Dice Boys Casino'); pg.wait_for_timeout(100)
    print(pg.inner_text(box+' .cc-ibx'))
    print(pg.get_attribute('.cc-hero[data-k="flannel"]','title'))
    pg.screenshot(path='/tmp/pick.png')
    pg.click('.cc-hero[data-k="lumberjack"]'); pg.click('.cc-hero[data-k="robot"]'); pg.click('.cc-hero[data-k="cultist"]'); print(pg.text_content('[data-go]')); pg.click('[data-go]'); pg.wait_for_timeout(600)
    pg.get_by_text('BEGIN STAGE 1').click(); pg.wait_for_timeout(500)
    
    pg.wait_for_timeout(800)
    print(pg.evaluate("(()=>{const g=window.__GM;const h=g.heroes[0];h.mine=1;h.mineCd=0;for(let i=0;i<3;i++)g.spawnEnemy('zombie',{x:g.heroX(h)+50+i*6});for(const e of g.enemies)e.gy=h.gy;return 'ok'})()"));pg.wait_for_timeout(5000);print(pg.evaluate("JSON.stringify([(window.__GM.mines||[]).map(m=>[!!m.owner,m.armed,+(m.mult||0).toFixed(2)]),window.__GM.stats[window.__GM.heroes[0].key]])"));print(pg.evaluate("(()=>{const g=window.__GM;const h=g.heroes[0];const hp0=g.heroes.map(o=>Math.round(o.hp));g.spawnEnemy('zombie',{x:g.heroX(h)+10});const e=g.enemies[g.enemies.length-1];e.gy=h.gy;const M={x:g.heroX(h)+4,l:h.laneI,gy:h.gy,t:0,armed:true,spotted:true,chk:0};(g.mines=g.mines||[]).push(M);g.mineBoom(M);return JSON.stringify({before:hp0,after:g.heroes.map(o=>Math.round(o.hp)),zombie:[Math.round(e.hp),e.dead]});})()"))
    print('ERRS',errs);b.close()
