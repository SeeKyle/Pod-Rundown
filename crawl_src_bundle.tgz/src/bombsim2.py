from playwright.sync_api import sync_playwright
STUB="(function(){const f=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:k==='length'?0:f,apply:()=>f});window.d3=f;})();"
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox']);pg=b.new_page();errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e.stack)[:400]))
    pg.route('**/d3.min.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=STUB))
    pg.goto('file:///home/claude/pod2/index.html');pg.wait_for_timeout(1500)
    r=pg.evaluate("""()=>{const S=window.__SIM;const ev={throw:0,toss:0,plant:0,early:0,live:0,impact:0,mineboom:0};let err=null;
      for(let r=0;r<30;r++){const team=['flannel','lumberjack','druid'];const slot=S.newSlot('Kyle');const run=S.newRun(team,slot);run.stage=1+r%4;const g=new S.Game({run,slot});
        const tb=g.tripBoom.bind(g);g.tripBoom=T=>{if(T.impact)ev.impact++;else if(T.early)ev.early++;else ev.live++;return tb(T);};const mb=g.mineBoom.bind(g);g.mineBoom=M=>{ev.mineboom++;return mb(M);};
        let seen=new Set(),t=0;try{while(!g.over&&t<300){g.step(1/30);t+=1/30;for(const T of g.traps||[]){if(!seen.has(T)){seen.add(T);ev[T.how]++;}}}}catch(e){err=String(e.stack).slice(0,300);break;}}
      return {ev,err};}""")
    print(r,errs[:2]);b.close()
