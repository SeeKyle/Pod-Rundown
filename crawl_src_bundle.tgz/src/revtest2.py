from playwright.sync_api import sync_playwright
STUB="(function(){const f=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:k==='length'?0:f,apply:()=>f});window.d3=f;})();"
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=b.new_page(viewport={'width':1280,'height':900}); errs=[]
    pg.route('**/d3.min.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=STUB))
    pg.on('pageerror',lambda e:errs.append(str(e)[:300]))
    pg.goto('file:///home/claude/pod2/index.html'); pg.wait_for_timeout(1500)
    pg.click('.cs-play'); pg.wait_for_timeout(500); pg.click('[data-p="Kyle"]'); pg.wait_for_timeout(300)
    def pin():
        for d in '1234': pg.get_by_role('button',name=d,exact=True).click(); pg.wait_for_timeout(60)
        pg.wait_for_timeout(350)
    pin(); pin()
    pg.click('[data-new="0"]'); pg.wait_for_timeout(600)
    box='.cc-insp[data-ik="flannel"]'
    pg.select_option(box+' [data-ip]','Kyle'); pg.wait_for_timeout(100)
    print(pg.evaluate(f"[...document.querySelectorAll('{box} [data-id] option')].map(o=>o.textContent).join('\\n')"))
    pg.select_option(box+' [data-id]','Dice Boys Casino'); pg.wait_for_timeout(100)
    print(pg.inner_text(box+' .cc-ibx'))
    print(pg.get_attribute('.cc-hero[data-k="flannel"]','title'))
    pg.screenshot(path='/tmp/pick.png')
    pg.click('.cc-hero[data-k="lumberjack"]'); pg.click('.cc-hero[data-k="cultist"]'); pg.click('[data-go]'); pg.wait_for_timeout(600)
    pg.get_by_text('BEGIN STAGE 1').click(); pg.wait_for_timeout(500)
    
    pg.wait_for_timeout(6000)
    print(pg.evaluate("(()=>{const g=window.__GM;const h=g.heroes[0];h.hp=0;g.heroDown(h);const r=[h.alive,h.downed];let n=0;const o=h;Object.defineProperty(o,'alive',{get(){return this._al},set(v){if(v)window.__st=new Error().stack;this._al=v},configurable:true});o._al=r[0];return JSON.stringify(r)})()"))
    for i in range(16):
        pg.wait_for_timeout(700); pg.screenshot(path=f'/tmp/rv{i}.png'); print(i,pg.evaluate("JSON.stringify(window.__GM.heroes.map(h=>[h.key,h.alive,!!h.downed,+(h.riseT||0).toFixed(2),+(h.revT||0).toFixed(1)]))"))
    print(pg.evaluate('window.__st||"none"'))
    print(pg.evaluate("JSON.stringify(window.__GM.heroes.map(h=>[h.key,h.alive,!!h.downed,+(h.revT||0).toFixed(1),h.plan&&h.plan.intent]))"))
    print(pg.evaluate('JSON.stringify(window.__ab||{})'));print('ERRS',errs)
    b.close()
