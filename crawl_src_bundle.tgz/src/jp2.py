c=open('/home/claude/pod2/crawl_src.js').read()
def rep(a,b,n=1):
    global c
    assert c.count(a)==n,(c.count(a),a[:70]); c=c.replace(a,b)
rep("  flannel:{name:'Aimed Shot · Proximity_Bomb · Traveling_Companion',","  jp:{name:'Toke_Break · Protect_the_Familia · Shield_Bash · Trash_Talk',cd:20,txt:'Smokes up to get HIGH (Wake_n_Bake), rushes in to shield family in trouble, bashes with a homemade shield and talks trash to pull zombies onto himself.'},\n  flannel:{name:'Aimed Shot · Proximity_Bomb · Traveling_Companion',")
rep("  flannel:'Careful, team-first marksman.","  jp:'Loud, lovable menace. A good guy who picks on everybody, games all day and smokes even more. Kar98 at range, sword and a homemade wooden shield up close, and the first one in when family is in trouble. Keep him high or he gets grumpy.',\n  flannel:'Careful, team-first marksman.")
rep("  aimed:'Aimed Shot ·","""  toke:'Toke_Break · no energy · 22s · 2s. He sparks up a big one and keeps walking but does nothing else while he smokes; then he\\'s HIGH for 30s (see Wake_n_Bake) and feels 6% better.',
  familia:'Protect_the_Familia · 40 energy · 20s. When an ally is under 45% with zombies on them, he sprints over (can\\'t be hurt while rushing). Then they both get a shield worth 50% of his max HP for 5s, and he shoves the ally 75px back toward safety.',
  bash:'Shield_Bash · 20 energy · 8s. A face full of homemade shield: 1d6, a big shove and a 1s stun.',
  trash:'Trash_Talk · 25 energy · 18s. He roasts every zombie within 70px until they all come for HIM for 4s, hiding behind the shield (30% less damage). His friends laugh it off: +5% crit for 6s.',
  baked:'Wake_n_Bake · Passive. While HIGH: +10% dodge, 10% less damage taken, +1 energy per second, +10% sword speed. Sober for 10s+: -6 accuracy, -10% move and attack speed, and he gets grumpy.',
  aimed:'Aimed Shot ·""")
# taunt hold
rep("          if(!e.plan&&!e.E.backline&&(!e.target||!e.target.alive))e.target=nearestIn(inLane)||nearestIn(al);",
    "          if(!e.plan&&!e.E.backline&&(!e.target||!e.target.alive))e.target=nearestIn(inLane)||nearestIn(al);\n          if(e.tauntT>0){e.tauntT-=dt;if(e.tauntBy&&e.tauntBy.alive){e.target=e.tauntBy;e.plan=null;}}   /* Trash_Talk: they only want JP */")
# damage taken modifiers
rep("    if(h.gritT>0)amt*=1-(h.gritDR||0);","    if(h.gritT>0)amt*=1-(h.gritDR||0);\n    if(h.key==='jp'){if(h.highT>0)amt*=.9;if(h.trashT>0)amt*=.7;if(h.rushT>0)return false;}   /* JP: high 10% less, Trash_Talk 30% less, immune while rushing to family */")
rep("function dynMv(h){let m=1;","function dynMv(h){let m=1;if(h.key==='jp'&&!(h.highT>0)&&(h.soberT||0)>10)m-=.1;")
# melee speed buff/penalty
rep("    h.mT=(h.mT||0)+dt*h.meleeSpd*spdB*(h.cozyT>0?1+COZY.melee:1);","    h.mT=(h.mT||0)+dt*h.meleeSpd*spdB*(h.cozyT>0?1+COZY.melee:1)*(h.key==='jp'?(h.highT>0?1.1:(h.soberT||0)>10?.9:1):1);")
# crit from trash talk laughs
rep("if(src&&!opt.nocrit&&this.rng()<src.crit+(opt.critAdd||0)+.01*(src.inevN||0)){","if(src&&!opt.nocrit&&this.rng()<src.crit+(opt.critAdd||0)+.01*(src.inevN||0)+(src.laughT>0?.05:0)){")
# ability block in gunner
rep("    // ---- Call Companion (Flannel_Man)","""    // ---- JP (0.12.66)
    if(h.key==='jp'){const AJ=id=>(C.abilities||[]).find(a=>a.id===id);const TK=AJ('toke'),FM=AJ('familia'),BS=AJ('bash'),TT=AJ('trash'),BK=AJ('baked');
      for(const [A,k] of [[TK,'tkT'],[FM,'fmT'],[BS,'bsT'],[TT,'ttT']])if(A){if(h[k]==null)h[k]=A.cd*.2;if(h[k]>0)h[k]-=dt;}
      if(h.highT>0){h.highT-=dt;h.soberT=0;h.en=Math.min(h.enMax||100,(h.en||0)+BK.en*dt);}else{h.soberT=(h.soberT||0)+dt;if(h.soberT>BK.soberAfter&&!h._grump){h._grump=1;Comms.bubble(this,h,Comms.pick(['Ugh, I need a break.','Who touched my lighter?','Not now, I\\'m sober.','Everybody shut up for a sec.']));}}
      h.dodgeB=h.dodgeB==null?h.dodge:h.dodgeB;h.dodge=h.dodgeB+(h.highT>0?BK.dodge:0);h._accBonus=(h._accBonus||0);if(h.trashT>0)h.trashT-=dt;
      // smoking: 2s, can walk, nothing else
      if(h.smoking){const S=h.smoking;S.t+=dt;if(S.t>=TK.dur){h.smoking=null;h.highT=TK.high;h._grump=0;this.healHero(h,h.max*TK.heal,true,h);Comms.bubble(this,h,Comms.pick(['Ahh. Okay. Okay, I\\'m good.','Now THAT\\'S the stuff.','Alright, who wants some? ...No? More for me.','Lag\\'s gone. Let\\'s go.']));}return;}
      // rushing to family
      if(h.rush){const R=h.rush,o=R.ally;if(!o.alive){h.rush=null;h.rushT=0;}else{const tx=this.heroX(o)+6,d=tx-h.x;const st=Math.sign(d)*Math.min(Math.abs(d),FM.spd*dt);h.x+=st;h.gy+=Math.sign((o.gy||this.G)-h.gy)*Math.min(Math.abs((o.gy||this.G)-h.gy),40*dt);h.face=d<0?-1:1;
          if(Math.abs(d)<3){h.rush=null;h.rushT=0;for(const u of [h,o]){u.shield=Math.max(u.shield||0,h.max*FM.shield);u.shieldT=FM.shieldT;}o.x=Math.max(10,o.x-FM.push);o.thinkT=0;this.fx.push({k:'ring',x:o.x,y:(o.gy||this.G)-10,t:0,r:12,c:'#ffa040'});Comms.bubble(this,h,Comms.pick(['Get behind me!','Not my family!','Back up, I got this!','Nobody touches them!']),true);}}return;}
      // Protect_the_Familia
      if(FM&&h.fmT<=0&&(h.en||0)>=FM.en){const o=this.alive().filter(a=>a!==h&&!a.pet&&a.hp/a.max<.45&&Math.abs(this.heroX(a)-h.x)<=FM.range&&this.enemies.filter(e=>!e.dead&&Math.abs(e.x-this.heroX(a))<25).length>=2).sort((p,q)=>p.hp/p.max-q.hp/q.max)[0];
        if(o&&spendEnergy(h,FM.en)){h.fmT=FM.cd*(1-(h.cdr||0));h.rush={ally:o};h.rushT=9;Comms.bubble(this,h,Comms.pick(['FAMILIA!','Hold on, I\\'m coming!','HEY! That\\'s my people!']),true);return;}}
      // Shield_Bash
      if(BS&&h.bsT<=0&&mt&&!mt.dead&&(h.en||0)>=BS.en&&spendEnergy(h,BS.en)){h.bsT=BS.cd*(1-(h.cdr||0));h.animM=.35;h.face=mt.x>=h.x?1:-1;const d=this.hitEnemy(mt,(this.rollDice(BS.dice)+(h.flatMelee||0))*(h.atk/h.base.atk)*h.meleeDmg,h,{kb:1});
        if(d&&!mt.dead){mt.stun=Math.max(mt.stun||0,BS.stun*(mt.boss?.3:1));const res=mt.boss?.9:((mt.E&&mt.E.kbRes)||0);mt.kbv=Math.max(mt.kbv||0,BS.kb/100*40*8*(1-res));mt.kbDir=mt.x>=h.x?1:-1;}this.ev('hit',{});return;}
      // Trash_Talk
      if(TT&&h.ttT<=0&&(h.en||0)>=TT.en){const near=this.enemies.filter(e=>!e.dead&&!e.boss&&Math.abs(e.x-h.x)<=TT.r);const onAlly=this.alive().some(a=>a!==h&&!a.pet&&this.enemies.filter(e=>!e.dead&&Math.abs(e.x-this.heroX(a))<22).length>=2);
        if(near.length>=2&&onAlly&&spendEnergy(h,TT.en)){h.ttT=TT.cd*(1-(h.cdr||0));h.trashT=TT.dur;for(const e of near){e.tauntT=TT.dur;e.tauntBy=h;e.target=h;}for(const a of this.alive())if(!a.pet)a.laughT=TT.critT;
          Comms.bubble(this,h,Comms.pick(['Your mom walks faster than that!','Bro, you smell worse than my gaming chair.','Is that your best? My kids hit harder!','Come here, you rotten nerds!','Zero kills, all deaths. Classic.']),true);return;}}
      // Toke_Break
      if(TK&&h.tkT<=0&&!(h.highT>3)&&!this.enemies.some(e=>!e.dead&&Math.abs(e.x-h.x)<45)){h.tkT=TK.cd*(1-(h.cdr||0));h.smoking={t:0};if(Math.random()<.7)Comms.bubble(this,h,Comms.pick(['Hold up, smoke break.','Pause the game, I gotta hit this.','One sec, one sec...','Medicinal. Totally medicinal.']));return;}}
    // ---- Call Companion (Flannel_Man)""")
open('/home/claude/pod2/crawl_src.js','w').write(c);print('ok')
