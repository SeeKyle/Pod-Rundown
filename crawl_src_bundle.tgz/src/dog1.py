c=open('/home/claude/pod2/crawl_src.js').read()
def rep(a,b,n=1):
    global c
    assert c.count(a)==n,(c.count(a),a[:70]); c=c.replace(a,b)
# downed bodies list includes downed dogs (heroes revive them; dogs never revive anyone: dogs return early in their own brain branch)
rep("    {const D=g.heroes.filter(o=>!o.alive&&o.downed&&o!==h).sort(","    {const D=g.heroes.concat((g.pets||[]).filter(p=>p.dog)).filter(o=>!o.alive&&o.downed&&o!==h).sort(")
rep("  stepRevive(dt){const downs=this.heroes.filter(h=>!h.alive&&h.downed);if(!downs.length)return;",
    "  stepRevive(dt){const downs=this.heroes.concat((this.pets||[]).filter(p=>p.dog)).filter(h=>!h.alive&&h.downed);if(!downs.length)return;")
# dog hits: 5 hits before down; no HP damage; can't be healed
rep("  hurtHero(h,amt,from){\n    if(!h||!h.alive)return;",
    """  hurtHero(h,amt,from){
    if(!h||!h.alive)return;
    /* 0.12.65 (Kyle) Guard Dog: no HP, he can take 5 hits (6 with a Tier III Kennel) before he goes down; one hit comes back every 15s (10s at Tier III).
       He can't be healed, but anyone can help him up (dogs never help others up: no hands). */
    if(h.dog){if(this.rng()<h.dodge){this.text(h.x,this.G-30,'dodge','#9ae6ff');return false;}if(h.invulnT>0)return false;h.hits=(h.hits||0)-1;h.hitFlash=.12;h.hitRegT=0;h.hp=h.max*Math.max(0,h.hits)/h.hitsMax;
      if(h.hits<=0){h.alive=false;h.downed=1;h.revT=0;h.downT=this.t;h.hp=0;h.plan=null;this.fx.push({k:'poof',x:h.x,y:this.G-14,t:0});Comms.bubble(this,h,'*yelp*',true);if(this.slot)this.st8(h).downs++;}return true;}""")
rep("  healHero(h,amt,quiet,by){if(!h||!h.alive||amt<=0)return;","  healHero(h,amt,quiet,by){if(!h||!h.alive||amt<=0||h.dog)return;")
rep("  revive(h,med){h.alive=true;h.downed=0;h.hp=Math.max(1,h.max*(med?.35:.25));",
    "  revive(h,med){if(h.dog){h.alive=true;h.downed=0;h.hits=2;h.hp=h.max*2/h.hitsMax;h.revT=0;h.revCall=0;h.invulnT=1.3;h.plan=null;h.thinkT=0;this.fx.push({k:'ring',x:h.x,y:(h.gy||this.G)-8,t:0,r:10,c:'#ffe08a'});Comms.bubble(this,h,'*happy bark*',true);return;}   /* back up with 2 hits */\n    h.alive=true;h.downed=0;h.hp=Math.max(1,h.max*(med?.35:.25));")
# spawn: tiers, hits, two dogs at tier IV
rep("  spawnDog(t){this.pets=this.pets||[];if(this.pets.some(p=>p.key==='dog'&&p.alive))return;","  spawnDog(t,i){this.pets=this.pets||[];if(!i&&t>=4&&!this._dog2){this._dog2=1;this.spawnDog(t,1);}if(!i&&this.pets.some(p=>p.key==='dog'&&!p.second))return;")
rep("const hm=[1,1.25,1.5][t-1],dm=[1,1.15,1.3][t-1];const h0=this.heroes[0];","const hm=1,dm=[1,1.2,1.3,1.4][t-1];const h0=this.heroes[i?Math.min(1,this.heroes.length-1):0];")
rep("const dg={key,def:{key,name:'Guard_Dog'},style:STYLE[key],lvl:lv,base:b,spells:[],items:[],alive:true,owner:h0,pet:1,dog:1,x:(h0?h0.x:60)-10,",
    "const hitsMax=t>=3?6:5;const dg={key,def:{key,name:i?'Guard_Dog 2':'Guard_Dog'},style:STYLE[key],lvl:lv,base:b,spells:[],items:[],alive:true,owner:h0,pet:1,dog:1,second:!!i,hits:hitsMax,hitsMax,hitRegEvery:t>=3?10:15,hitRegT:0,x:(h0?h0.x:60)-10-(i?14:0),")
rep("  kennel:{name:'Guard Dog Kennel',icon:'🐕',tiers:[125,200,300],txt:t=>t===1?'A German Shepherd joins every stage. He guards whoever is in the most trouble and bites anything that gets close. Only ever one dog.':`Your dog gets tougher and bites harder: +${[0,25,50][t-1]}% HP, +${[0,15,30][t-1]}% damage, a little quicker.`},",
    "  kennel:{name:'Guard Dog Kennel',icon:'🐕',tiers:[125,200,300,450],txt:t=>['A German Shepherd joins every stage. He takes 5 hits before going down, gets a hit back every 15s, and your people can help him up.','Your dog bites 20% harder and a little quicker, and dodges more.','Your dog takes 6 hits, gets one back every 10s, and bites 30% harder.','A second German Shepherd joins the pack (both bite 40% harder).'][t-1]},   // 0.12.65 (Kyle): 4 tiers, two dogs at the top")
open('/home/claude/pod2/crawl_src.js','w').write(c);print('ok')
