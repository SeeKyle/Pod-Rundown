from playwright.sync_api import sync_playwright
STUB="(function(){const f=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:k==='length'?0:f,apply:()=>f});window.d3=f;})();"
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=b.new_page(viewport={'width':1280,'height':800});errs=[]
    pg.route('**/d3.min.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=STUB))
    pg.on('pageerror',lambda e:errs.append(str(e)[:300]))
    pg.goto('file:///home/claude/pod2/index.html');pg.wait_for_timeout(1500)
    pg.click('.cs-play');pg.wait_for_timeout(500);pg.click('[data-p="Kyle"]');pg.wait_for_timeout(300)
    def pin():
        for d in '1234': pg.get_by_role('button',name=d,exact=True).click(); pg.wait_for_timeout(60)
        pg.wait_for_timeout(350)
    pin();pin()
    pg.click('[data-new="0"]');pg.wait_for_timeout(600)
    for k in ['flannel','lumberjack','druid']:pg.click(f'.cc-hero[data-k="{k}"]')
    pg.click('[data-go]');pg.wait_for_timeout(600)
    pg.get_by_text('BEGIN STAGE 1').click();pg.wait_for_timeout(1500)
    shots=0
    for i in range(80):
        st=pg.evaluate("(()=>{const g=window.__GM;if(!g)return null;const f=g.heroes.find(h=>h.key==='flannel');const L=g.heroes.find(h=>h.key==='lumberjack');return {toss:!!(f&&f.tossing),traps:(g.traps||[]).map(t=>[t.how,!!t.fly,Math.round(t.rollLeft||0)]),logs:(g.logs||[]).length,chop:!!(L&&L.chopping),rage:!!(L&&L.rageT>0),over:g.over}})()")
        if st and (st['toss'] or any(t[1] for t in st['traps']) or st['logs'] or st['chop'] or st['rage']) and shots<6:
            pg.screenshot(path=f'/tmp/fight{shots}.png',clip={'x':0,'y':40,'width':1280,'height':720});print(i,st);shots+=1
        if st and st['over']:break
        pg.wait_for_timeout(700)
    print('ERRS',errs);b.close()
