c=open('/home/claude/pod2/crawl_src.js').read()
def rep(a,b,n=1):
    global c
    assert c.count(a)==n,(c.count(a),a[:70]); c=c.replace(a,b)
rep("      hpMul:Math.pow(1.08,n-1)*Math.pow(2.2,P),\n      dmgMul:Math.pow(1.05,n-1)*Math.pow(1.8,P),",
    "      // 0.12.65 (Kyle): enemies get +3% health, armor and damage per stage (rounded down), nothing else\n      hpMul:Math.pow(1.03,n-1)*Math.pow(2.2,P),\n      dmgMul:Math.pow(1.03,n-1)*Math.pow(1.8,P),")
rep("      countMul:1+.04*(n-1),","      countMul:1,")
rep("    const hp=E.hp*st.hpMul*(elite?2.6:1);","    const hp=Math.floor(E.hp*st.hpMul)*(elite?2.6:1);")
rep("walkT:this.rng(),anim:0,animT:0,slow:0,slowT:0,stun:0,burn:0,burnT:0,shred:0,elite,","walkT:this.rng(),anim:0,animT:0,slow:0,slowT:0,stun:0,burn:0,burnT:0,shred:0,elite,armorPts:Math.floor((E.armorPts||0)*Math.pow(1.03,(st.n||1)-1)),")
rep("  const pts=(target.E&&target.E.armorPts)||(target.B&&target.B.armorPts)||target.armorPts||0;","  const pts=target.E&&target.armorPts!=null?target.armorPts:((target.E&&target.E.armorPts)||(target.B&&target.B.armorPts)||target.armorPts||0);   /* enemies carry their own stage-scaled armor */")
rep("const d=e.E.dmgDie?(1+Math.floor(this.rng()*e.E.dmgDie))*e.dmgMul:e.dmg;","const d=e.E.dmgDie?Math.max(1,Math.floor((1+Math.floor(this.rng()*e.E.dmgDie))*e.dmgMul)):e.dmg;",2)
rep("    fireman: {undead:1,scale:.88,aimScale:.88,hp:31,dmgDie:7,spd:8.3,","    // 0.12.65 (Kyle): now 4x a zombie's health (100) and armor (12) at 2/5 its speed\n    fireman: {undead:1,scale:.88,aimScale:.88,hp:100,dmgDie:7,spd:3.5,")
rep("armorPts:9,kbRes:.45,bleed:{chance:.25,dmg:20,dur:5},fireImmune:1,name:'Fireman_Zombie',","armorPts:12,kbRes:.6,bleed:{chance:.25,dmg:20,dur:5},fireImmune:1,name:'Fireman_Zombie',")
rep("goldAmt:[3,7],stack:true,xp:3,pts:14,cost:1.6,","goldAmt:[3,7],stack:true,xp:5,pts:30,cost:3.2,")
rep("const WOLVES_PER_STAGE=n=>Math.min(7,2+Math.floor((n-1)*.4));","const WOLVES_PER_STAGE=n=>Math.min(9,3+Math.floor((n-1)*.5));   // 0.12.65 (Kyle: too weak / too few): 3 on stage 1, one more about every 2 stages")
rep("    werewolf:{hp:30,dmgDie:6,spd:44,atk:1.25,reach:12,armorPts:3,","    werewolf:{hp:38,dmgDie:7,spd:44,atk:1.2,reach:12,armorPts:4,   /* 0.12.65: a bit sturdier and meaner (was 30 HP, 1d6, 3 armor) */")
open('/home/claude/pod2/crawl_src.js','w').write(c);print('ok')
