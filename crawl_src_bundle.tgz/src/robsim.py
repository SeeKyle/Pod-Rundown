import json,sys
from playwright.sync_api import sync_playwright
STUB="(function(){const f=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:k==='length'?0:f,apply:()=>f});window.d3=f;})();"
N=int(sys.argv[1]) if len(sys.argv)>1 else 20
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox']);pg=b.new_page();errs=[]
    pg.route('**/d3.min.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=STUB))
    pg.on('pageerror',lambda e:errs.append(str(e)[:300]))
    pg.goto('file:///home/claude/pod2/index.html');pg.wait_for_timeout(1500)
    res=pg.evaluate("""(N)=>{const S=window.__SIM,HE=['flannel','chibi','archer','druid','lumberjack','cultist','jp'];const out=[];
      for(let r=0;r<N;r++){const team=['robot'].concat(HE.slice().sort(()=>Math.random()-.5).slice(0,2));const stage=1+(r%6);
        const slot=S.newSlot('Kyle');for(const k of team){slot.heroes[k].lvl=1+Math.floor((stage-1)*.8);}const run=S.newRun(team,slot);run.stage=stage;
        let g;try{g=new S.Game({run,slot});}catch(e){out.push({err:String(e)});continue;}
        let t=0,c={lz:0,jet:0,nano:0,stealth:0,surge:0,flame:0};let pl=null,pj=null,pn=null,ps=0;
        try{while(!g.over&&t<300){g.step(1/30);t+=1/30;const R=g.heroes.find(h=>h.key==='robot');if(R){if(R.lz&&R.lz!==pl)c.lz++;pl=R.lz;if(R.jet&&R.jet!==pj)c.jet++;pj=R.jet;if(R.nano&&R.nano!==pn)c.nano++;pn=R.nano;if(R.surgeT>0&&!ps)c.surge++;ps=R.surgeT>0;}
          for(const h of g.heroes)if(h.stealthT>0)c.stealth+=1/30;}}catch(e){out.push({err:String(e).slice(0,300),stack:String(e.stack).slice(0,400),team});continue;}
        const st=g.stats;out.push({team,stage,over:g.over||'timeout',t:+t.toFixed(1),c,dmg:st&&st.robot?Math.round(st.robot.dmg||0):null});}
      return out;}""",N)
    json.dump(res,open('/tmp/robres.json','w'))
    print(len(res),'runs; errors:',sum(1 for r in res if 'err' in r),errs[:3])
    for r in res:
        if 'err' in r:print(r);break
    from collections import Counter
    print(Counter(r.get('over') for r in res))
    for r in res[:12]:print(r.get('team'),r.get('stage'),r.get('over'),r.get('t'),r.get('c'),r.get('dmg'))
    b.close()
