c=open('/home/claude/pod2/crawl_src.js').read()
L=c.split('\n')
s=next(i for i,l in enumerate(L) if l.startswith("    if(h.setting){const S=h.setting"))
e=next(i for i,l in enumerate(L) if "if(near&&!live.some(e=>Math.abs(e.x-hx)<45)" in l)
new=r"""    /* 0.12.64 Proximity_Bomb casts. PLACE: kneel 3s, no moving (a hit on him in crowbar range breaks it). TOSS / THROW: he keeps walking while the cast fills. */
    if(h.setting){const S=h.setting;if(mt){h.setting=null;this.text(h.x,this.G-70,'interrupted','#9aa');}
      else{S.t+=dt;h.pauseT=Math.max(h.pauseT||0,.1);
        if(S.t>=S.T){h.setting=null;if(spendEnergy(h,TB.en)){h.tbT=TB.cd*(1-(h.cdr||0));const P=TB.place;
          (this.traps=this.traps||[]).push({x:h.x+(h.face<0?-P.off:P.off),gy:h.gy!=null?h.gy:this.G,t:0,A:TB,owner:h,how:'plant',live:1,dice:P.dmg[0],flat:P.dmg[1],blast:{w0:P.w0,w1:P.w1}});Comms.onTrap(this,h,h.x);}}
        return;}}
    if(h.tossing){const K=h.tossing;K.t+=dt;   // no pauseT: he can move while it winds up
      if(K.t>=K.T){h.tossing=null;if(spendEnergy(h,TB.en)){h.tbT=TB.cd*(1-(h.cdr||0));const gy=K.gy,x0=h.x+(h.face<0?-8:8);
          const T={x:x0,gy,t:0,A:TB,owner:h,how:K.kind,air:0};
          if(K.kind==='toss'){const Lb=TB.lob;T.fly={t:0,T:Lb.dur,x0,x1:x0+Lb.dist,h:Lb.h};T.rollLeft=Lb.roll;T.roll0=Lb.roll;T.dice=Lb.early[0];T.flat=Lb.early[1];}
          else{const H=TB.hurl;const tx=Math.max(h.x+H.min,Math.min(h.x+H.max,K.tx));T.fly={t:0,T:H.dur,x0,x1:tx,h:H.h};T.rollLeft=0;T.impact=1;T.dice=H.dmg[0];T.flat=H.dmg[1];T.blast={w0:TB.blast.w0,w1:H.w1};}
          (this.traps=this.traps||[]).push(T);this.ev('whoosh',{});if(Math.random()<.55)Comms.bubble(this,h,K.kind==='toss'?Comms.pick(['Rolling one in!','Fire in the hole!','Bowling!']):Comms.pick(['Catch!','Heads up!','Present for you!']),true);}}}
    /* 0.12.64 Proximity_Bomb choice (Kyle): he knows PLACING is the strongest (6d4+2, wider) but slow (3s on his knees), tossing/throwing is quick.
       IF a zombie is close or on him THEN he can't afford to kneel: quick only.
       IF a bunch / a big one sits 100-150px out THEN THROW it right on them (2d4+6 on impact) when he wants quick results.
       IF zombies are 25-60px ahead in his lane THEN TOSS it so it lands short and rolls into them.
       IF the nearest threat is still far (>70px) THEN he invests: PLACE it (Careful and Calculated lean this way).
       IF nothing is near at all THEN he randomly scouts a spot to place or to toss for later. */
    if(TB&&!h.cast&&!h.setting&&!h.tossing&&!mt&&h.tbT<=0&&!(this.traps||[]).some(t=>t.owner===h)&&(h.en||0)>=TB.en*(1+.3*trait(h,'energy')-.15)){
      const hx=h.x,gy0=h.gy!=null?h.gy:this.G,live=this.enemies.filter(e=>!e.dead&&!e.fly&&e.x<this.W-4);
      const H=TB.hurl;let best=null;for(const e of live){const d=e.x-hx;if(d<H.min||d>H.max)continue;const n=live.filter(o=>Math.abs(o.x-e.x)<16&&Math.abs((o.gy||this.G)-(e.gy||this.G))<10).length;const sc=n+(e.boss||e.max>=40?2:0);if(!best||sc>best.sc)best={e,sc,n};}
      const near1=live.reduce((m,e)=>Math.min(m,Math.abs(e.x-hx)),999),inLane=live.filter(e=>e.x-hx>=25&&e.x-hx<=60&&Math.abs((e.gy!=null?e.gy:this.G)-gy0)<=9);
      const aggr=trait(h,'aggr'),plan=trait(h,'plan'),wantQuick=near1<45||(h.hp/h.max<.5)||aggr>.65;
      if(best&&best.sc>=2&&(wantQuick||near1<70||Math.random()<.5)){const cx=live.filter(o=>Math.abs(o.x-best.e.x)<16).reduce((s,o)=>s+o.x,0)/Math.max(1,best.n);h.tossing={t:0,T:H.cast,kind:'throw',tx:cx-4,gy:best.e.gy!=null?best.e.gy:gy0};return;}
      if(inLane.length&&near1>=18){h.tossing={t:0,T:TB.lob.cast,kind:'toss',gy:gy0};return;}
      if(near1>70&&near1<260&&!wantQuick&&Math.random()<.35+.4*(1-aggr)+.2*plan){h.setting={t:0,T:TB.place.cast};return;}
      if(!live.length&&!this._clear===false&&Math.random()<dt*.25){if(Math.random()<.5)h.setting={t:0,T:TB.place.cast};else h.tossing={t:0,T:TB.lob.cast,kind:'toss',gy:gy0};return;}}"""
L[s:e+1]=new.split('\n')
c='\n'.join(L)
def rep(a,b,n=1):
    global c
    assert c.count(a)==n,(c.count(a),a[:70]); c=c.replace(a,b)
# trap life cycle with Kyle's trigger zones
rep("""        const near=()=>this.enemies.find(e=>!e.dead&&!e.fly&&!e.boss&&Math.abs((e.gy!=null?e.gy:this.G)-T.gy)<=A.depth&&e.x<=T.x+14&&e.x>=T.x-6);
        if(T.rollLeft>0){const L=A.lob,v=L.rollSpd*Math.max(.25,T.rollLeft/T.roll0);const s=Math.min(T.rollLeft,v*dt);T.x+=s;T.rollLeft-=s;T.spin=(T.spin||0)+s*.6;
          if(near()){T.early=1;T.dice=A.diceRoll;if(T.owner&&T.owner.tbT>0)T.owner.tbT*=.5;this.tripBoom(T);continue;}   /* caught one mid-roll: 3d4, cooldown halved */
          if(T.rollLeft<=.05){T.rollLeft=0;T.settleT=0;}continue;}
        if(T.how==='toss'&&!T.live){T.settleT=(T.settleT||0)+dt;if(T.settleT>=A.lob.settle){T.live=1;T.dice=A.diceLive;T.t=A.arm;this.fx.push({k:'ring',x:T.x,y:T.gy-3,t:0,r:6,c:'#ff4030'});}continue;}   /* stopped: a moment later it activates (6d4) */
        if(T.t<A.arm)continue;""",
"""        const near=()=>bombTrig(this,T.x,T.gy,A.trig);
        if(T.rollLeft>0){const Lb=A.lob,v=Lb.rollSpd*Math.max(.3,T.rollLeft/T.roll0);const s=Math.min(T.rollLeft,v*dt);T.x+=s;T.rollLeft-=s;T.spin=(T.spin||0)+s*.6;
          if(T.rollLeft<=.05){T.rollLeft=0;T.settleT=0;}}
        if(T.how==='toss'&&!T.live){if(near()){T.early=1;if(T.owner&&T.owner.tbT>0)T.owner.tbT=Math.max(0,T.owner.tbT-A.lob.refund);this.tripBoom(T);continue;}   /* tripped before it truly activated: 2d4+2, 2s back on the cooldown */
          if(!(T.rollLeft>0)){T.settleT=(T.settleT||0)+dt;if(T.settleT>=A.lob.settle){T.live=1;T.dice=A.lob.live[0];T.flat=A.lob.live[1];this.fx.push({k:'ring',x:T.x,y:T.gy-3,t:0,r:6,c:'#ff4030'});}}continue;}   /* truly activated: 2d4+6 */""")
rep("""        const hit=this.enemies.find(e=>!e.dead&&!e.fly&&!e.boss&&Math.abs((e.gy!=null?e.gy:this.G)-T.gy)<=A.depth&&e.x<=T.x+14&&e.x>=T.x-6);
        if(hit)this.tripBoom(T);}""","""        if(near())this.tripBoom(T);}""")
rep("function dynMv(h){","""/* 0.12.64 (Kyle): proximity zone shared by Proximity_Bomb and the enemy rust mines: half-width w0 in its own lane, w1 one lane up or down */
function bombTrig(g,x,gy,Z,who){Z=Z||{w0:6.7,w1:3.3};for(const e of (who||g.enemies)){if(e.dead||e.fly)continue;const ex=e.key?g.heroX(e):e.x,dz=Math.abs(((e.gy!=null?e.gy:g.G))-gy),dx=Math.abs(ex-x)-(e.boss?e.w*.5:0);
    if((dz<=3.5&&dx<=Z.w0)||(dz>3.5&&dz<=11.5&&dx<=Z.w1))return e;}return null;}
function dynMv(h){""")
open('/home/claude/pod2/crawl_src.js','w').write(c)
print('ok')
