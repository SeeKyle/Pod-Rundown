c=open('/home/claude/pod2/crawl_src.js').read()
def rep(a,b,n=1):
    global c
    assert c.count(a)==n,(c.count(a),a[:70]); c=c.replace(a,b)
rep("      {id:'trip',name:'Proximity_Bomb',en:35,cd:10,cast:1,arm:.6,lob:{dist:25,h:7,dur:.6,roll:[17,25],rollSpd:30,settle:.5},hurl:{min:117,max:133,h:42,dur:.95},dice4:[4,4],diceRoll:[3,4],diceLive:[6,4],dice:[3,6],flat:0,depth:12,cross:{long:36,thin:4,across:14,wide:12},shock:{r:56,depth:20,kbMul:1.6},kb:45,bleed:{chance:.5,dmg:12,dur:4},life:40}]},",
"""      // 0.12.64 (Kyle's hard stats, screen px / 3 = world px): 40 energy, 10s.
      //   Trigger: 40px wide in its own lane (+-6.7), 20px wide one lane up and one down (+-3.3).
      //   Blast: 100px wide in its own lane (+-16.7), 40px wide one lane up/down (+-6.7).
      //   OVERHAND: 1s cast (can walk), lands exactly where he picks 300-450px (100-150) away, blows on impact: 2d4+6, lanes up/down 60px wide (+-10).
      //   UNDERHAND: 0.5s cast (can walk), lands 100px (33) ahead, rolls 50px (17), then 0.5s to truly activate (flashing).
      //     Tripped before that: 2d4+2 and 2s back on the cooldown. Activated: 2d4+6.
      //   PLACE: 3s kneeling (no moving), put 5px (1.7) in front, active at once: 6d4+2, blast +20px wide (+-20) and +10px in the side lanes (+-8.3).
      //   Left behind off screen: what's left of the cooldown is halved.
      {id:'trip',name:'Proximity_Bomb',en:40,cd:10,arm:0,trig:{w0:6.7,w1:3.3},blast:{w0:16.7,w1:6.7},
        hurl:{min:100,max:150,h:42,dur:.95,cast:1,dmg:[[2,4],6],w1:10},lob:{dist:33,h:7,dur:.55,roll:16.7,rollSpd:26,settle:.5,cast:.5,early:[[2,4],2],live:[[2,4],6],refund:2},
        place:{cast:3,off:1.7,dmg:[[6,4],2],w0:20,w1:8.3},kb:45,bleed:{chance:.5,dmg:12,dur:4},life:40}]},""")
rep("""      // cross-shaped blast (Kyle): a long arm along the lane (side to side) and a long arm across the lanes (up and down)
      const C2=A.cross;const inRow=dx<=C2.long&&dz<=C2.thin,inCol=dz<=C2.across&&dx<=C2.wide;if(!inRow&&!inCol)continue;
      const fall=1-.5*Math.min(1,Math.min(inRow?dx/C2.long:9,inCol?dz/C2.across:9));""",
"""      // 0.12.64 (Kyle): blast covers its own lane wide and the lanes just above and below narrower
      const BW=T.blast||A.blast;const own=dz<=3.5,side=dz>3.5&&dz<=11.5;const lim=own?BW.w0:side?BW.w1:-1;if(dx>lim)continue;
      const fall=1-.45*Math.min(1,dx/Math.max(1,lim));""")
rep("const dx=Math.abs(e.x-(T.x+6)),dz=Math.abs((e.gy!=null?e.gy:this.G)-T.gy);","const dx=Math.abs(e.x-T.x),dz=Math.abs((e.gy!=null?e.gy:this.G)-T.gy);",2)
rep("const base=this.rollDice(T.dice||A.dice)+(A.flat||0)+((h&&h.flatRanged)||0);","const base=this.rollDice(T.dice||[2,4])+(T.flat||0)+((h&&h.flatRanged)||0);")
rep("tripBoom(T){const A=T.A,h=T.owner;T.done=1;this.fx.push({k:'boom',x:T.x+6,","tripBoom(T){const A=T.A,h=T.owner;T.done=1;this.fx.push({k:'boom',x:T.x,")
rep("    if(this.hardcore)for(const o of this.alive()){const dx=Math.abs(this.heroX(o)-(T.x+6)),dz=Math.abs((o.gy||this.G)-T.gy);const C2=A.cross;const inR=dx<=C2.long&&dz<=C2.thin,inC=dz<=C2.across&&dx<=C2.wide;\n      if(inR||inC){",
    "    if(this.hardcore)for(const o of this.alive()){const dx=Math.abs(this.heroX(o)-T.x),dz=Math.abs((o.gy||this.G)-T.gy);const BW=T.blast||A.blast;const lim=dz<=3.5?BW.w0:dz<=11.5?BW.w1:-1;\n      if(dx<=lim){")
open('/home/claude/pod2/crawl_src.js','w').write(c)
print('ok')
