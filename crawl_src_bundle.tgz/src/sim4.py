import json,sys
from playwright.sync_api import sync_playwright
STUB="(function(){const f=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:k==='length'?0:f,apply:()=>f});window.d3=f;})();"
N=int(sys.argv[1]) if len(sys.argv)>1 else 120
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox']);pg=b.new_page();errs=[]
    pg.route('**/d3.min.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=STUB))
    pg.on('pageerror',lambda e:errs.append(str(e)[:300]))
    pg.goto('file:///home/claude/pod2/index.html');pg.wait_for_timeout(1500)
    res=pg.evaluate("""(N)=>{const S=window.__SIM,HE=['flannel','chibi','archer','druid','lumberjack','robot','cultist'];const out=[];
      for(let r=0;r<N;r++){const team=HE.slice().sort(()=>Math.random()-.5).slice(0,3);const stage=1+(r%6);
        const slot=S.newSlot('Kyle');for(const k of team){slot.heroes[k].lvl=1+Math.floor((stage-1)*.8);}const run=S.newRun(team,slot);run.stage=stage;if(r%2){run.hardcore=true;run.dnd=true;run.rolls={};for(const k of team){const o={};for(const sl of ['aggr','aware','pace','lane','self','range','plan','energy','size','exec','grudge','pack','flair','talk','tech','perc','listen','nerve','noise','cover'])o[sl]=Math.floor(Math.random()*6)+Math.floor(Math.random()*6);run.rolls[k]=o;}}
        let g;try{g=new S.Game({run,slot});}catch(e){out.push({err:String(e)});continue;}
        let t=0;try{while(!g.over&&t<300){g.step(1/30);t+=1/30;}}catch(e){out.push({err:String(e).slice(0,200),team});continue;}
        out.push({team,stage,over:g.over||'timeout',t:+t.toFixed(1),stats:g.stats,alive:g.heroes.filter(h=>h.alive).map(h=>h.key)});}
      return out;}""",N)
    json.dump(res,open('/tmp/simres.json','w'))
    print(len(res),'runs; errors:',sum(1 for r in res if 'err' in r),errs[:3])
    for r in res:
        if 'err' in r:print(r);break
    b.close()
