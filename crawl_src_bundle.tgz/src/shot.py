from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=b.new_page(viewport={'width':1200,'height':900}); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('file:///home/claude/pod2/index.html'); pg.wait_for_timeout(2500)
    pg.screenshot(path='/tmp/top.png',clip={'x':0,'y':0,'width':1200,'height':700})
    pg.click('[data-page="garage"]'); pg.wait_for_timeout(1200)
    el=pg.query_selector('.g-repair'); el.scroll_into_view_if_needed(); pg.wait_for_timeout(300)
    el.screenshot(path='/tmp/rep.png')
    pg.click('[data-page="spinner"]'); pg.wait_for_timeout(1000)
    print('errors',errs)
    b.close()
