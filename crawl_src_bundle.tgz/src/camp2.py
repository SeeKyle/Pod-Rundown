from playwright.sync_api import sync_playwright
STUB="(function(){const f=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:k==='length'?0:f,apply:()=>f});window.d3=f;})();"
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=b.new_page(viewport={'width':1280,'height':900}); errs=[]
    pg.route('**/d3.min.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=STUB))
    pg.on('pageerror',lambda e:errs.append(str(e)[:300]))
    pg.goto('file:///home/claude/pod2/index.html'); pg.wait_for_timeout(1500)
    pg.click('.cs-play'); pg.wait_for_timeout(500); pg.click('[data-p="Kyle"]'); pg.wait_for_timeout(300)
    def pin():
        for d in '1234': pg.get_by_role('button',name=d,exact=True).click(); pg.wait_for_timeout(60)
        pg.wait_for_timeout(350)
    pin(); pin()
    pg.click('[data-new="0"]'); pg.wait_for_timeout(600)
    box='.cc-insp[data-ik="flannel"]'
    pg.select_option(box+' [data-ip]','Kyle'); pg.wait_for_timeout(100)
    print(pg.evaluate(f"[...document.querySelectorAll('{box} [data-id] option')].map(o=>o.textContent).join('\\n')"))
    pg.select_option(box+' [data-id]','Dice Boys Casino'); pg.wait_for_timeout(100)
    print(pg.inner_text(box+' .cc-ibx'))
    print(pg.get_attribute('.cc-hero[data-k="flannel"]','title'))
    pg.screenshot(path='/tmp/pick.png')
    pg.click('.cc-hero[data-k="druid"]'); pg.click('.cc-hero[data-k="robot"]'); pg.click('.cc-hero[data-k="flannel"]'); pg.click('[data-go]'); pg.wait_for_timeout(600)
    pg.get_by_text('BEGIN STAGE 1').click(); pg.wait_for_timeout(500)
    
    pg.wait_for_timeout(14000)
    pg.evaluate("(()=>{const g=window.__GM;g.stageFood=1;g.stageWater=1;g.stageParts=30;g.stageGold=900;const S=window.__SLOTF();S.heroes.robot.lvl=3;S.run.upg={tower:1,still:1,kennel:2};S.run.food=4;g.over='clear';})()")
    pg.wait_for_timeout(1500)
    pg.screenshot(path='/tmp/clear.png',full_page=True)
    print(pg.inner_text('.cc-panel')[:1500])
    pg.click('[data-c]');pg.wait_for_timeout(800)
    print(pg.inner_text('.cc-panel')[-1300:])
    pg.click('[data-scout]');pg.wait_for_timeout(300)
    pg.click('[data-brew=\"robot\"]');pg.wait_for_timeout(300)
    print('---');print(pg.inner_text('.cc-panel')[-700:])
    pg.click('[data-begin]');pg.wait_for_timeout(300);pg.click('[data-begin]');pg.wait_for_timeout(1500)
    print(pg.evaluate("JSON.stringify([window.__GM.mods,window.__GM.heroes.map(h=>[h.key,!!h.courage,Math.round(h.acc)]),(window.__GM.pets||[]).map(p=>[p.key,Math.round(p.max)])])"))
    print('ERRS',errs);b.close()
