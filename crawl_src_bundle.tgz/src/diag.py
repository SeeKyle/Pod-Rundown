from playwright.sync_api import sync_playwright
STUB="(function(){const f=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:k==='length'?0:f,apply:()=>f});window.d3=f;})();"
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox']);pg=b.new_page()
    pg.route('**/d3.min.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=STUB))
    pg.goto('file:///home/claude/pod2/index.html');pg.wait_for_timeout(1500)
    res=pg.evaluate("""()=>{const S=window.__SIM;const outs=[];
      for(let r=0;r<12;r++){const team=['flannel','chibi','archer','druid','lumberjack','robot'].sort(()=>Math.random()-.5).slice(0,3);const slot=S.newSlot('Kyle');const run=S.newRun(team,slot);run.stage=1+r%4;
        const g=new S.Game({run,slot});let t=0,log=[],sc=0,dn=0,bl=0,np=0;
        while(!g.over&&t<420){g.step(1/30);t+=1/30;if(g.scroll)sc++;else if(g.heroes.some(h=>!h.alive&&h.downed))dn++;else{const al=g.alive().filter(h=>!h.pet);if(al.filter(h=>h.x>g.W/2).length>al.length/2)bl++;else np++;}
          if(Math.abs(t%30)<1/30)log.push([Math.round(t),Math.round(g.dist),g.st.len,g.alive().filter(h=>!h.pet).map(h=>Math.round(h.x)+':'+(h.plan&&h.plan.intent||'-')).join(' '),g.enemies.filter(e=>!e.dead).length]);}
        outs.push({team,over:g.over||'timeout',t:Math.round(t),scroll:Math.round(sc/30),down:Math.round(dn/30),blocked:Math.round(bl/30),notpast:Math.round(np/30),log:g.over?[]:log});}
      return outs;}""")
    for r in res:
        print(r['team'],r['over'],r['t'],'scroll',r['scroll'],'down',r['down'],'blocked',r['blocked'],'notpast',r['notpast'])
        for l in r['log'][-6:]:print('   ',l)
    b.close()
