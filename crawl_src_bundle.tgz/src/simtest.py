from playwright.sync_api import sync_playwright
STUB="(function(){const f=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:k==='length'?0:f,apply:()=>f});window.d3=f;})();"
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=b.new_page(viewport={'width':1200,'height':1000}); errs=[]
    pg.route('**/d3.min.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=STUB))
    pg.on('pageerror',lambda e:errs.append(str(e)[:300]))
    pg.goto('file:///home/claude/pod2/index.html'); pg.wait_for_timeout(1500)
    pg.click('[data-page="sim"]'); pg.wait_for_timeout(600)
    pg.emulate_media(reduced_motion='reduce')
    pg.click('.tv-btn.play'); pg.wait_for_timeout(800)
    txt=pg.inner_text('.crt-in'); print(txt[:4000])
    el=pg.query_selector('.tv'); el.scroll_into_view_if_needed(); pg.screenshot(path='/tmp/sim.png',full_page=False)
    print('errors',errs); b.close()
