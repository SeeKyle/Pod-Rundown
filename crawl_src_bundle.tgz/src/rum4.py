from playwright.sync_api import sync_playwright
STUB="(function(){const f=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:k==='length'?0:f,apply:()=>f});window.d3=f;})();"
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=b.new_page(viewport={'width':1280,'height':900}); errs=[]
    pg.route('**/d3.min.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=STUB))
    pg.on('pageerror',lambda e:errs.append(str(e.stack)[:900]))
    pg.goto('file:///home/claude/pod2/index.html'); pg.wait_for_timeout(1500)
    pg.click('.cs-play'); pg.wait_for_timeout(500); pg.click('[data-p="Kyle"]'); pg.wait_for_timeout(300)
    def pin():
        for d in '1234': pg.get_by_role('button',name=d,exact=True).click(); pg.wait_for_timeout(60)
        pg.wait_for_timeout(350)
    pin(); pin()
    pg.click('[data-new="0"]'); pg.wait_for_timeout(600)
    box='.cc-insp[data-ik="flannel"]'
    pg.select_option(box+' [data-ip]','Kyle'); pg.wait_for_timeout(100)
    print(pg.evaluate(f"[...document.querySelectorAll('{box} [data-id] option')].map(o=>o.textContent).join('\\n')"))
    pg.select_option(box+' [data-id]','Dice Boys Casino'); pg.wait_for_timeout(100)
    print(pg.inner_text(box+' .cc-ibx'))
    print(pg.get_attribute('.cc-hero[data-k="flannel"]','title'))
    pg.screenshot(path='/tmp/pick.png')
    pg.click('.cc-hero[data-k="flannel"]'); pg.click('.cc-hero[data-k="robot"]'); pg.click('[data-go]'); pg.wait_for_timeout(600)
    pg.get_by_text('BEGIN STAGE 1').click(); pg.wait_for_timeout(500)
    
    pg.wait_for_timeout(1500)
    pg.evaluate("(()=>{const g=window.__GM;g.heroes.forEach(h=>{h.insp='The Last of Us';h.persona=null;});g.recalc();const hx=Math.max(...g.alive().map(h=>h.x));const D=window.__OB.car_sedan;g.obst.push({k:'car_sedan',x:hx+25,lanes:[1,2],blk:D.blk});const R=Object.keys(window.__OB).find(k=>/^rock_/.test(k));g.obst.push({k:R,x:hx+90,lanes:[0],blk:window.__OB[R].blk});window.__log=[];setInterval(()=>{for(const h of g.heroes)if(h.search)window.__log.push([h.key,h.search.o.k,+h.search.t.toFixed(2),Math.round(h.x-g.searchSpot(h.search.o).x),h.laneI,g.searchSpot(h.search.o).lane,h.search.o.lanes.join('')]);},250);})()")
    for i in range(8):
        pg.wait_for_timeout(700)
        print(pg.evaluate("(()=>{const g=window.__GM;return JSON.stringify(g.heroes.map(h=>[h.key,h.plan&&h.plan.intent,h.srDecide&&[h.srDecide.o.k,h.srDecide.go],h.search&&h.search.t,Math.round(h.x),h.laneI]).concat([g.obst.map(o=>[o.k,Math.round(o.x),o.lanes.join(''),o.searched?Object.keys(o.searched).join(','):''])]))})()"))
    print('ERRS',errs);b.close()
