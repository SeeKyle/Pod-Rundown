from playwright.sync_api import sync_playwright
STUB="(function(){const f=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:k==='length'?0:f,apply:()=>f});window.d3=f;})();"
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox']);pg=b.new_page();errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e.stack)[:400]))
    pg.route('**/d3.min.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=STUB))
    pg.goto('file:///home/claude/pod2/index.html');pg.wait_for_timeout(1500)
    r=pg.evaluate("""()=>{const S=window.__SIM;const out={downs:0,revives:0,dogs:0,over:{}};let err=null;
      for(let r=0;r<20;r++){const team=['jp',['flannel','robot','chibi','archer'][r%4],'druid'];const slot=S.newSlot('Kyle');const run=S.newRun(team,slot);run.stage=1+r%5;const g=new S.Game({run,slot});
        let t=0,wasDown=new Set();try{while(!g.over&&t<300){g.step(1/30);t+=1/30;for(const p of g.pets||[])if(p.dog){if(p.downed&&!wasDown.has(p)){wasDown.add(p);out.downs++;}if(p.alive&&wasDown.has(p)){wasDown.delete(p);out.revives++;}}}}catch(e){err=String(e.stack).slice(0,300);break;}
        const j=g.heroes.find(h=>h.key==='jp');out.dogs+=(g.st8?g.st8(j).dmg:0);out.over[g.over||'timeout']=(out.over[g.over||'timeout']||0)+1;}
      return {out,err};}""")
    print(r,errs[:2]);b.close()
