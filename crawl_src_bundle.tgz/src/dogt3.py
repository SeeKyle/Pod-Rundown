from playwright.sync_api import sync_playwright
STUB="(function(){const f=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:k==='length'?0:f,apply:()=>f});window.d3=f;})();"
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=b.new_page(viewport={'width':1280,'height':900}); errs=[]
    pg.route('**/d3.min.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=STUB))
    pg.on('pageerror',lambda e:errs.append(str(e)[:300]))
    pg.goto('file:///home/claude/pod2/index.html'); pg.wait_for_timeout(1500)
    pg.click('.cs-play'); pg.wait_for_timeout(500); pg.click('[data-p="Kyle"]'); pg.wait_for_timeout(300)
    def pin():
        for d in '1234': pg.get_by_role('button',name=d,exact=True).click(); pg.wait_for_timeout(60)
        pg.wait_for_timeout(350)
    pin(); pin()
    pg.click('[data-new="0"]'); pg.wait_for_timeout(600)
    box='.cc-insp[data-ik="flannel"]'
    pg.select_option(box+' [data-ip]','Kyle'); pg.wait_for_timeout(100)
    print(pg.evaluate(f"[...document.querySelectorAll('{box} [data-id] option')].map(o=>o.textContent).join('\\n')"))
    pg.select_option(box+' [data-id]','Dice Boys Casino'); pg.wait_for_timeout(100)
    print(pg.inner_text(box+' .cc-ibx'))
    print(pg.get_attribute('.cc-hero[data-k="flannel"]','title'))
    pg.screenshot(path='/tmp/pick.png')
    pg.click('.cc-hero[data-k="druid"]'); pg.click('.cc-hero[data-k="robot"]'); pg.click('.cc-hero[data-k="flannel"]'); pg.click('[data-go]'); pg.wait_for_timeout(600)
    pg.get_by_text('BEGIN STAGE 1').click(); pg.wait_for_timeout(500)
    
    pg.evaluate("(()=>{const g=window.__GM;setInterval(()=>{const h=g.heroes[0];if(g.enemies.filter(e=>!e.dead).length<3)g.spawnEnemy('zombie',{x:h.x+40});},800);})()")
    for i in range(6):
        pg.wait_for_timeout(2500);pg.screenshot(path='/tmp/dogf%d.png'%i)
        print(pg.evaluate("(()=>{const g=window.__GM;const d=(g.pets||[]).find(p=>p.dog);const e=g.enemies.filter(e=>!e.dead).sort((a,b)=>Math.abs(a.x-d.x)-Math.abs(b.x-d.x))[0];return JSON.stringify({dx:Math.round(d.x),home:Math.round(g.home(d)),xoff:d.plan&&Math.round(d.plan.xoff),lane:d.laneI,gy:Math.round(d.gy),pl:d.plan&&d.plan.lane,ex:e&&Math.round(e.x),egy:e&&Math.round(e.gy),ward:d.owner&&d.owner.key,wx:d.owner&&Math.round(g.heroX(d.owner)),mv:d.moving,pause:d.pauseT,atk:d.mT})})()"))
    print('ERRS',errs);b.close()
