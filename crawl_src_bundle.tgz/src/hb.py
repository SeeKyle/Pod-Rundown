from playwright.sync_api import sync_playwright
STUB="(function(){const f=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:k==='length'?0:f,apply:()=>f});window.d3=f;})();"
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox']);pg=b.new_page()
    pg.route('**/d3.min.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=STUB))
    pg.goto('file:///home/claude/pod2/index.html');pg.wait_for_timeout(1500)
    print(pg.evaluate("JSON.stringify(['flannel','chibi','archer','druid','lumberjack','robot','cultist'].map(k=>[k,window.__AP(k)]))"))
    b.close()
