c=open('/home/claude/pod2/crawl_src.js').read()
def rep(a,b,n=1):
    global c
    assert c.count(a)==n,(c.count(a),a[:70]); c=c.replace(a,b)
rep("const CHAR={\n  flannel:{name:'Flannel_Man',",
"""const CHAR={
  // 0.12.66 (Kyle) JP: big orange hoodie, dark jeans, Kar98 + a real sword and a homemade wooden shield. A good guy who loves picking on people,
  //   games all day and smokes a lot of weed (not a drinker). Plays sword-fight with his kids. Mixes jokey and sensible.
  jp:{name:'JP',role:'Kar98 + Sword & Board',flatHp:0,stamina:9,hpPerStamina:5,armorPts:7,dodge:.05,kbRes:.35,
    melee:{dice:[1,8],every:1.1,reach:18,kb:18,hitAt:.15},                    // sword: medium speed, low-medium damage
    ranged:{dice:[1,10],flat:1,every:2.4,range:290,clip:1,reload:2.4,pellets:1},   // Kar98: more damage and range than Flannel_Man's rifle, slower between shots
    acc:20,walkPenalty:12,crit:.12,critMul:2,luck:18,xp:0,run:2,turn:.22,enMax:100,enRegen:5,
    abilities:[
      // Toke_Break: 2s, he can keep walking but does nothing else, then he's HIGH for 30s and patched up 6%. No energy, 22s.
      //   IF I'm not high (or nearly down) AND nothing is within 45px THEN spark one up.
      {id:'toke',name:'Toke_Break',en:0,cd:22,dur:2,high:30,heal:.06},
      // Protect_the_Familia: IF an ally is under 45% with 2+ zombies on them (within ~160px of me) THEN rush to them, immune while rushing;
      //   on arrival we both get a shield worth 50% of my max HP for 5s and I shove them 75px back toward the left edge. 40 energy, 20s.
      {id:'familia',name:'Protect_the_Familia',en:40,cd:20,range:160,spd:120,shield:.5,shieldT:5,push:25},
      // Shield_Bash: the homemade shield to the face: 1d6, a big shove and a 1s stun. 20 energy, 8s.
      {id:'bash',name:'Shield_Bash',en:20,cd:8,dice:[1,6],stun:1,kb:45},
      // Trash_Talk: he picks on the zombies (and his friends). Every zombie within 70px comes for HIM for 4s while he hides behind the shield
      //   (30% less damage); his friends laugh it off: +5% crit for 6s. IF 2+ zombies are on an ally near me THEN talk trash. 25 energy, 18s.
      {id:'trash',name:'Trash_Talk',en:25,cd:18,r:70,dur:4,dr:.3,crit:.05,critT:6},
      // Wake_n_Bake (passive): HIGH = +10% dodge, 10% less damage taken, +1 energy/s, +10% sword speed. Sober (not high for 10s+) =
      //   -6 accuracy, -10% move and attack speed, and he gets grumpy.
      {id:'baked',name:'Wake_n_Bake',passive:1,dodge:.1,dr:.1,en:1,mspd:.1,soberAfter:10,acc:-6,slow:.1}]},
  flannel:{name:'Flannel_Man',""")
rep("const MOVE={dog:24,","const MOVE={jp:16,dog:24,")
rep("HERO_HB={dog:{w:16,h:22},","HERO_HB={jp:{w:20,h:46},dog:{w:16,h:22},")
rep("const MUZZLE={cultist:[10,11],","const MUZZLE={jp:[13,14],cultist:[10,11],")
rep("  flannel:{atk:'gunner',proj:'bullet',reach:20,range:250,hp:1,dmg:1},","  jp:{atk:'gunner',proj:'bullet',reach:18,range:290,hp:1,dmg:1},\n  flannel:{atk:'gunner',proj:'bullet',reach:20,range:250,hp:1,dmg:1},")
rep(" flannel:{aggr:3,aware:7,pace:5,lane:4,self:1,range:4,"," jp:{aggr:6,aware:5,pace:6,lane:5,self:2,range:5,plan:4,energy:5,size:5,exec:5,grudge:3,pack:2,flair:8,talk:10,listen:4,perc:5,tech:5,nerve:6,noise:7,cover:5},   // JP: loud, social, picks on everyone, steps in for family\n flannel:{aggr:3,aware:7,pace:5,lane:4,self:1,range:4,")
open('/home/claude/pod2/crawl_src.js','w').write(c);print('ok')
