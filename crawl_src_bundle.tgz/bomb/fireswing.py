# 0.12.62 (Kyle): the Fireman_Zombie's attack is a hand swing shaped like our other zombies' claw swipe (arm back over the head,
# a big overhead swipe with a pale smear, follow-through), built from his own idle frame: his hanging arm is cut away and a new
# turnout-coat arm (navy sleeve, yellow reflective band, red glove) is drawn at each angle. Frames face LEFT.
import numpy as np, math
from PIL import Image
P='/home/claude/pod2/assets/enemies/zombie_fire/';FW,FH=56,54
idle=np.array(Image.open(P+'fire_idle_sheet.png').convert('RGBA'))[:, :FW].copy()
yy,xx=np.mgrid[0:FH,0:FW]
body=idle.copy();body[(xx>=37)&(yy>=26)&(yy<=42)]=0
OUT=(12,14,22,255);NAVY=(34,40,62,255);NAVY2=(48,56,84,255);YEL=(236,220,46,255);GLV=(140,34,42,255);GLV2=(96,20,30,255)
def disc(d,x,y,r,c):
    for j in range(int(y-r-1),int(y+r+2)):
        for i in range(int(x-r-1),int(x+r+2)):
            if 0<=i<FW and 0<=j<FH and (i-x)**2+(j-y)**2<=r*r:d[j,i]=c
def arm(d,sx,sy,ang,L=15,smear=None,lean=0):
    if smear:
        a0,a1=smear
        for k in range(60):
            t=k/59;a=a0+(a1-a0)*t;r=L+3
            for w in range(int(1+5*t)):
                px=sx+math.cos(a)*(r-w);py=sy+math.sin(a)*(r-w)
                if 0<=int(px)<FW and 0<=int(py)<FH and d[int(py),int(px),3]==0:d[int(py),int(px)]=(205,214,196,int(110+90*t))
    ex,ey=sx+math.cos(ang)*L,sy+math.sin(ang)*L
    n=24
    for k in range(n+1):
        t=k/n;x=sx+(ex-sx)*t;y=sy+(ey-sy)*t;disc(d,x,y,2.6,OUT)
    for k in range(n+1):
        t=k/n;x=sx+(ex-sx)*t;y=sy+(ey-sy)*t;disc(d,x,y,1.7,YEL if .45<t<.62 else (NAVY2 if k%3==0 else NAVY))
    disc(d,ex,ey,2.4,OUT);disc(d,ex,ey,1.6,GLV);d[int(ey),int(ex)]=GLV2
def frame(ang,lean=0,smear=None,front=False,sh=0,L=15):
    d=np.zeros_like(body)
    b=body.copy()
    if lean:   # upper body leans into the swing (toward the left)
        up=b.copy();up[27:]=0;lo=b.copy();lo[:27]=0;b=np.where(np.roll(up,lean,1)[...,3:]>0,np.roll(up,lean,1),lo)
    if front:d[:]=b;arm(d,33+lean-sh,21+sh*.3,ang,L=L,smear=smear)
    else:arm(d,33+lean-sh,21,ang,L=L,smear=smear);m=b[...,3]>0;d[m]=b[m]
    return d
R=math.radians
F=[frame(R(-60),0),           # arm swinging up behind his head
   frame(R(-100),0),          # high overhead, the hand above the helmet
   frame(R(170),-3,smear=(R(-115),R(-190)),front=True,sh=6,L=19),   # (Kyle) shoulder thrown way forward so the hand reaches out far   # the big swipe down in front of him, pale smear behind the hand
   frame(R(158),-2,front=True,sh=5,L=19)]   # follow-through, arm hanging forward
sh=Image.new('RGBA',(FW*len(F),FH))
for i,f in enumerate(F):sh.alpha_composite(Image.fromarray(f),(i*FW,0))
sh.save(P+'fire_atk_sheet.png')
pv=Image.new('RGBA',sh.size,(94,107,100,255));pv.alpha_composite(sh);pv.resize((sh.width*5,sh.height*5),Image.NEAREST).save('/tmp/fswing.png')
