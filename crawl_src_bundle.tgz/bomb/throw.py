# 0.12.58 (Kyle): Flannel_Man's Proximity_Bomb throws, built from his own melee frames:
#  underhand toss/roll: crouch low with the bomb at his hands (melee 3) -> swing it forward low (melee 0) -> follow through -> settle (idle 0)
#  overhand throw:      bomb raised behind his head (melee 1, 2) -> arm whips forward, release (melee 4) -> recover (melee 5)
# The crowbar is erased from each frame and the bomb (cut from his trip-bomb art: just the ball) is put in his hands.
import numpy as np
from PIL import Image
D='/home/claude/pod2/assets/heroes/flannel/';FW,FH=230,208
M=np.array(Image.open(D+'melee.png').convert('RGBA'));I=np.array(Image.open(D+'idle.png').convert('RGBA'))
fr=lambda A,i:A[:,i*FW:(i+1)*FW].copy()
TB=np.array(Image.open(D+'tripbomb_hd.png').convert('RGBA'))
ys,xs=np.nonzero(TB[...,3]>0)
ball=TB[0:15,0:19].copy()   # just the bomb ball (with its spikes), no wire or stake
Image.fromarray(ball).save(D+'bomb_ball.png')
def erase(F,cond):
    yy,xx=np.mgrid[0:FH,0:FW];F[cond(xx,yy)]=0;return F
def put(F,cx,cy):
    h,w=ball.shape[:2];x0,y0=int(cx-w/2),int(cy-h/2)
    for y in range(h):
        for x in range(w):
            if ball[y,x,3]>0 and 0<=y0+y<FH and 0<=x0+x<FW:F[y0+y,x0+x]=ball[y,x]
    return F
m0=erase(fr(M,0),lambda x,y:(x<99)&(y>128)&(y<190))
m1=erase(fr(M,1),lambda x,y:((y<=67)&(x<150))|((y>=68)&(y<=78)&(x<126)))
m2=erase(fr(M,2),lambda x,y:((x<133)&(y<100)&(y>40))|((y<57)&(x<150)))
m3=erase(fr(M,3),lambda x,y:(x<112)&(y>150)&(y<190));m4=erase(fr(M,4),lambda x,y:(x<93)&(y>60)&(y<150));m5=fr(M,5);i0=fr(I,0)
def show(name,A):
    o=Image.new('RGBA',(FW,FH),(70,70,80,255));o.alpha_composite(Image.fromarray(A));return o
# find hand spots by eye on the source frames
under=[put(m3.copy(),115,150),put(m0.copy(),97,146),m0.copy()]
over=[put(m1.copy(),160,52),put(m2.copy(),170,48),m4.copy(),m5.copy()]
np.save('/tmp/m4.npy',m4)
for nm,L in [('toss',under),('throw',over)]:
    o=Image.new('RGBA',(FW*len(L),FH));[o.alpha_composite(Image.fromarray(a),(i*FW,0)) for i,a in enumerate(L)];o.save(D+nm+'.png')
    pv=Image.new('RGBA',o.size,(70,70,80,255));pv.alpha_composite(o);pv.crop((0,40,o.width,208)).save('/tmp/'+nm+'_pv.png')
