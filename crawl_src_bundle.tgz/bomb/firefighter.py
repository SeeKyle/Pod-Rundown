# 0.12.62 (Kyle's firefighter zombie sheet): cut each frame out of the 3x upscaled sheet, sample it back to its 1x pixel grid,
# drop the green-grey background, snap to the sprite's palette, flip to face LEFT like our other units, and save one sheet per animation.
import numpy as np
from PIL import Image
from scipy import ndimage
SRC='/mnt/user-data/uploads/dcf158ee-image.webp';OUT='/home/claude/pod2/assets/enemies/zombie_fire/'
a=np.array(Image.open(SRC).convert('RGB')).astype(int);bg=np.array([94,107,100])
fg=np.abs(a-bg).sum(2)>50;fg[:,:240]=False
ROWS={'idle':(50,225),'walk':(280,455),'atk':(500,675),'hurt':(715,890),'die':(930,1100)}
lab,n=ndimage.label(ndimage.binary_dilation(fg,iterations=6))
S=3;FW,FH=56,54
def cells(y0,y1):
    m=fg[y0:y1];cols=m.any(0);L,k=ndimage.label(ndimage.binary_dilation(cols,iterations=14));out=[]
    for i in range(1,k+1):
        xs=np.where(L==i)[0];xs=xs[cols[xs]]
        if len(xs)>15:out.append((xs.min(),xs.max()+1))
    return out
for an,(y0,y1) in ROWS.items():
    frames=[]
    for (x0,x1) in cells(y0,y1):
        blk=a[y0:y1,x0:x1];msk=fg[y0:y1,x0:x1]
        h=(blk.shape[0]//S)*S;w=(blk.shape[1]//S)*S;blk=blk[:h,:w];msk=msk[:h,:w]
        # 1x grid: the median colour of each 3x3 block, kept if most of it is sprite
        B=blk.reshape(h//S,S,w//S,S,3).transpose(0,2,1,3,4).reshape(h//S,w//S,S*S,3);M=msk.reshape(h//S,S,w//S,S).transpose(0,2,1,3).reshape(h//S,w//S,S*S)
        col=np.median(B,2);al=(M.mean(2)>=.5)
        img=np.zeros((h//S,w//S,4),np.uint8);img[...,:3]=np.clip(col,0,255);img[...,3]=al*255
        frames.append(img)
    # palette snap across the whole animation
    allpx=np.concatenate([f[f[...,3]>0][:,:3] for f in frames]);q=Image.fromarray(allpx.reshape(-1,1,3).astype('uint8')).quantize(20,method=Image.MEDIANCUT)
    pal=np.array(q.getpalette()[:60]).reshape(20,3).astype(int)
    sheet=Image.new('RGBA',(FW*len(frames),FH))
    for i,f in enumerate(frames):
        px=f[...,:3].reshape(-1,3).astype(int);d=((px[:,None,:]-pal[None])**2).sum(2);f[...,:3]=pal[d.argmin(1)].reshape(f.shape[0],f.shape[1],3)
        im=Image.fromarray(f).transpose(Image.FLIP_LEFT_RIGHT);bb=im.getbbox();im=im.crop(bb)
        # feet on the bottom row of the cell, body centred
        al=np.array(im)[...,3]>0;rows=al[max(0,al.shape[0]-14):] if an!='die' else al;lx=np.nonzero(rows)[1];c0=int(np.median(lx)) if len(lx) else im.width//2   # line frames up on the legs so the body doesn't jitter
        cx=FW//2-c0;sheet.alpha_composite(im,(i*FW+max(0,min(FW-im.width,cx)),FH-im.height))
    sheet.save(OUT+'fire_%s_sheet.png'%an);print(an,len(frames),sheet.size)
pv=Image.new('RGBA',(FW*8,FH*5),(94,107,100,255))
for r,an in enumerate(ROWS):pv.alpha_composite(Image.open(OUT+'fire_%s_sheet.png'%an),(0,r*FH))
pv.resize((pv.width*4,pv.height*4),Image.NEAREST).save('/tmp/fire_pv.png')
