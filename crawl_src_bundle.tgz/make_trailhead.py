from PIL import Image, ImageDraw
import random
src=Image.open('/home/claude/pod2/assets/biome1_lake/midle.png').convert('RGBA');sp=src.load()
top=[next((y for y in range(160) if sp[x,y][3]>200),160) for x in range(544)]
peaks=[x for x in range(232,520) if top[x]<=min(top[x-6:x+7]) and top[x]<70]
# dedupe
P=[];[P.append(x) for x in peaks if not P or x-P[-1]>8]
print('peaks',[(x,top[x]) for x in P])
def cone(px,slope=.55,bottom=106):
  y0=top[px];h=bottom-y0;w=int(h*slope)+3
  im=Image.new('RGBA',(2*w+1,h),(0,0,0,0));p=im.load()
  for y in range(h):
    half=(y)*slope+1.5
    for dx in range(-w,w+1):
      if abs(dx)<=half:
        c=sp[px+dx,y0+y]
        if c[3]>200:p[dx+w,y]=c
  return im,w
NAVY=(0,27,39,255);GB=(32,47,52,255);BLK=(2,3,6,255);DIRT=(96,62,40,255);DIRT2=(122,80,50,255);OR=(251,91,41,255);RU=(142,62,37,255)
# pick two tall peaks
cand=sorted(P,key=lambda x:top[x])[:6];print('tall',[(x,top[x]) for x in cand])
L,wl=cone(406);R,wr=cone(363)
sep=34;W=wl+sep+wr+2;H=max(L.height,R.height)
im=Image.new('RGBA',(W,H),(0,0,0,0));d=ImageDraw.Draw(im)
cx=wl+sep//2
# dark undergrowth mound tying the trees into the treeline
d.chord([wl-14,H-30,wl+sep+14,H+26],180,360,fill=NAVY)
im.alpha_composite(L,(0,H-L.height));im.alpha_composite(R,(wl+sep-wr,H-R.height))
d=ImageDraw.Draw(im)
for r in range(13,0,-1):
  t=r/13;c=tuple(int(BLK[i]+(NAVY[i]-BLK[i])*t**1.6) for i in range(3))+(255,)
  d.chord([cx-r-1,H-5-r*2.0,cx+r+1,H-5+r*.5],180,360,fill=c);d.rectangle([cx-r-1,H-5-r*.5,cx+r+1,H],fill=c)
random.seed(7)
for a in range(-13,14):
  x=cx+a;y=int(H-5-((13**2-a*a)**.5)*2.0)
  for k in range(random.randint(1,3)):d.point((x,y-k),fill=GB if k else NAVY)
# 0.12.358 dirt path made from the real ground texture, narrowing in perspective and sinking into the dark
tex=Image.open('/home/claude/pod2/assets/biome1_lake/trail.png').convert('RGBA');tp=tex.load();ipx=im.load();random.seed(5)
D=14
for k in range(D):   # k=0 at the bottom (near), D-1 at the mouth (far)
  y=H-1-k;f=k/(D-1);half=10.5-8*f**.9;dark=min(1,.03+.95*f**1.7)
  for x in range(int(cx-half-1),int(cx+half+2)):
    e=abs(x-cx)-half
    if e>0.6 or (e>-.6 and random.random()<.5):continue   # dithered, uneven edges
    c=tp[(x*2+k*7)%tex.width,(8+int(k*1.6))%tex.height]
    c=tuple(int(c[i]*(1-dark)+BLK[i]*dark) for i in range(3))+(255,)
    ipx[x,y]=c
for (x,y) in [(cx-6,H-2),(cx+5,H-3),(cx+2,H-6),(cx-2,H-9)]:
  c=ipx[x,y]; ipx[x,y]=(min(255,c[0]+60),min(255,c[1]+55),min(255,c[2]+45),255)   # a few pebbles catching light
for pts in [[(cx-16,H-34),(cx-10,H-31),(cx-5,H-32),(cx-1,H-28)],[(cx+16,H-35),(cx+10,H-32),(cx+5,H-33),(cx+1,H-29)]]:
  d.line(pts,fill=NAVY);d.point(pts[1],fill=RU)
# 0.12.358 round off the dark grass ends: lift the base toward both sides on a curve, with little grass tufts
px=im.load();random.seed(11)
cols=[x for x in range(W) if any(px[x,y][3]>0 for y in range(H-4,H))]
x0,x1=min(cols),max(cols);R0=16
for x in range(W):
  d=min(x-x0,x1-x)
  if d<R0:
    lift=int(round(R0*0.55*(1-(d/R0))**1.6*1.0+ (1 if random.random()<.35 else 0)))
    for y in range(H-lift,H):px[x,y]=(0,0,0,0)
    if lift and px[x,H-lift-1][3]>0 and random.random()<.5:px[x,H-lift-1]=GB
im.save('/tmp/trail/trailhead.png');print('size',im.size)
bg=Image.open('/tmp/f_game.png').convert('RGBA').crop((64,380,1216,720));b=bg.copy();spr=im.resize((im.width*3,im.height*3),Image.NEAREST);b.alpha_composite(spr,(520,262-im.height*3))
b.convert('RGB').save('/tmp/trail/trailhead_preview.png')
